using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using FrpMapper.Shared.Models;

namespace FrpMapper.Platform.Hosting
{
    /// <summary>What the sign-in page shows.</summary>
    public sealed class SignInView
    {
        public SignInView()
        {
            Users = new List<DevelopmentUserDto>();
        }

        public AuthenticationMode Mode { get; set; }

        public string ReturnUrl { get; set; }

        public string UserName { get; set; }

        public string AntiforgeryToken { get; set; }

        public string SignedOutMessage { get; set; }

        /// <summary>Why a correct sign-in was refused (locked, disabled, deactivated, delayed).</summary>
        public string Refusal { get; set; }

        public string Error { get; set; }

        public string Notice { get; set; }

        public IReadOnlyList<DevelopmentUserDto> Users { get; set; }
    }

    /// <summary>The pages the server writes itself: sign-in, the application page, errors.</summary>
    public static class Pages
    {
        public const int MaxUserNameLength = 256;
        public const int MaxPasswordLength = 256;

        /// <summary>The page every screen of the application runs in (the screens are drawn by js/app.js).</summary>
        public static string Shell(HttpContextBase context, string sessionJson, int idleMinutes, IDictionary<string, string> versions)
        {
            var html = new StringBuilder();
            Head(html, context, "FRP Mapper", versions, true);
            html.Append("<body class=\"bg-canvas font-body text-ink\" data-idle-minutes=\"").Append(idleMinutes).Append("\">\n");
            // Data for the page (not a script that runs, so the Content-Security-Policy allows it).
            html.Append("<script type=\"application/json\" id=\"frp-session\">").Append(sessionJson).Append("</script>\n");
            html.Append("<div id=\"app\"><div class=\"px-8 py-10 text-sm text-muted\">Loading…</div></div>\n");
            html.Append("<noscript><p class=\"px-8 py-10 text-sm\">FRP Mapper needs JavaScript. Turn it on in your browser and reload the page.</p></noscript>\n");
            foreach (var script in Scripts)
            {
                html.Append("<script src=\"").Append(script).Append("?v=").Append(Version(versions, script)).Append("\"></script>\n");
            }

            html.Append("</body>\n</html>\n");
            return html.ToString();
        }

        /// <summary>The application's scripts, in load order.</summary>
        public static readonly string[] Scripts =
        {
            "js/toast.js", "js/core.js", "js/components.js", "js/pages-projects.js", "js/pages-project.js", "js/pages-project-sheet.js", "js/pages-validate.js",
            "js/pages-admin.js", "js/pages-sandbox.js", "js/app.js"
        };

        /// <summary>The script of the ASP.NET Web Forms pages (Site.Master).</summary>
        public static readonly string[] WebFormsScripts = { "js/toast.js", "js/webforms.js" };

        public static readonly string[] Styles = { "css/app.css", "css/tailwind.css" };

        public static string SignIn(HttpContextBase context, SignInView view, IDictionary<string, string> versions)
        {
            var html = new StringBuilder();
            Head(html, context, "Sign in", versions, true, true);
            html.Append("<body class=\"bg-canvas font-body text-ink\">\n");
            if (view.Mode == AuthenticationMode.ActiveDirectory)
            {
                // The login screen names neither the organization nor the system and does not describe valid user names
                // (Application Security Checklist: Login and User Authentication).
                html.Append("<main class=\"flex min-h-screen items-center justify-center px-4 py-12 sm:px-6\">\n");
                html.Append("<div class=\"w-full max-w-md rounded-app border border-line bg-surface p-8 shadow-sm sm:p-10\">\n");
                html.Append("<span class=\"grid h-11 w-11 place-items-center rounded-app bg-accent-soft text-accent\" aria-hidden=\"true\"><i class=\"ph ph-lock-simple text-xl\"></i></span>\n");
                html.Append("<h1 class=\"mt-5 font-display text-3xl font-bold tracking-tight text-ink\">Sign in</h1>\n");
                html.Append("<p class=\"mt-2 text-sm leading-6 text-muted\">Use the user name and password you sign in to your computer with.</p>\n");
                if (view.SignedOutMessage != null)
                {
                    html.Append("<div class=\"mt-6 flex gap-3 rounded-app border border-amber-200 bg-amber-50 px-4 py-3 text-sm leading-6 text-amber-900\" role=\"status\">")
                        .Append("<i class=\"ph ph-clock mt-0.5 text-lg\" aria-hidden=\"true\"></i><p>").Append(Http.Encode(view.SignedOutMessage)).Append("</p></div>\n");
                }

                var problem = view.Refusal ?? view.Error;
                if (problem != null)
                {
                    html.Append("<div class=\"mt-6 flex gap-3 rounded-app border border-red-200 bg-red-50 px-4 py-3 text-sm leading-6 text-red-900\" role=\"alert\">")
                        .Append("<i class=\"ph ph-x-circle mt-0.5 text-lg text-red-700\" aria-hidden=\"true\"></i><p>").Append(Http.Encode(problem)).Append("</p></div>\n");
                }

                html.Append("<form method=\"post\" action=\"account/signin?handler=Directory\" class=\"mt-6 space-y-5\" autocomplete=\"off\">\n");
                Hidden(html, "ReturnUrl", view.ReturnUrl);
                Hidden(html, "__RequestVerificationToken", view.AntiforgeryToken);
                var focusUser = string.IsNullOrEmpty(view.UserName);
                html.Append("<div><label for=\"UserName\" class=\"block text-sm font-semibold text-ink\">User name</label>")
                    .Append("<input id=\"UserName\" name=\"UserName\" value=\"").Append(Http.Encode(view.UserName)).Append("\" type=\"text\" required maxlength=\"").Append(MaxUserNameLength)
                    .Append("\" autocomplete=\"off\" autocapitalize=\"none\" spellcheck=\"false\"").Append(focusUser ? " autofocus" : "")
                    .Append(" class=\"mt-2 h-11 w-full rounded-app border border-line bg-surface px-3 text-sm outline-none transition placeholder:text-subtle hover:border-slate-300 focus:border-accent focus:ring-2 focus:ring-accent-line\" /></div>\n");
                html.Append("<div><label for=\"Password\" class=\"block text-sm font-semibold text-ink\">Password</label>")
                    .Append("<input id=\"Password\" name=\"password\" type=\"password\" required maxlength=\"").Append(MaxPasswordLength).Append("\" autocomplete=\"off\"").Append(focusUser ? "" : " autofocus")
                    .Append(" class=\"mt-2 h-11 w-full rounded-app border border-line bg-surface px-3 text-sm outline-none transition hover:border-slate-300 focus:border-accent focus:ring-2 focus:ring-accent-line\" /></div>\n");
                html.Append("<button type=\"submit\" class=\"inline-flex h-11 w-full items-center justify-center gap-2 rounded-app bg-accent px-5 text-sm font-semibold text-white transition hover:bg-accent-hover focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent\">")
                    .Append("<i class=\"ph ph-sign-in\" aria-hidden=\"true\"></i> Sign in</button>\n</form>\n");
                html.Append("<p class=\"mt-4 text-xs leading-5 text-subtle\">Forgot your password or locked out? Contact your IT service desk.</p>\n");
                if (view.Notice != null)
                {
                    html.Append("<p class=\"mt-8 border-t border-line pt-5 text-xs leading-5 text-muted\" role=\"note\">").Append(Http.Encode(view.Notice)).Append("</p>\n");
                }

                html.Append("</div>\n</main>\n");
            }
            else
            {
                html.Append("<main class=\"mx-auto flex min-h-screen max-w-5xl flex-col justify-center px-6 py-16\">\n");
                html.Append("<p class=\"text-sm font-semibold text-accent\">FRP Mapper · Development sign-in</p>\n");
                html.Append("<h1 class=\"mt-3 font-display text-4xl font-bold tracking-tight text-ink\">Choose a test user</h1>\n");
                html.Append("<p class=\"mt-4 max-w-[62ch] text-base leading-7 text-muted\">This page exists only in the Development environment, for machines without Active Directory. ")
                    .Append("In production people sign in with their Active Directory account, and their AD groups decide their roles.</p>\n");
                if (view.SignedOutMessage != null)
                {
                    html.Append("<p class=\"mt-6 max-w-[62ch] rounded-app border border-amber-200 bg-amber-50 px-4 py-3 text-sm leading-6 text-amber-900\" role=\"status\">")
                        .Append(Http.Encode(view.SignedOutMessage)).Append("</p>\n");
                }

                if (view.Refusal != null)
                {
                    html.Append("<p class=\"mt-6 max-w-[62ch] rounded-app border border-red-200 bg-red-50 px-4 py-3 text-sm leading-6 text-red-900\" role=\"alert\">")
                        .Append(Http.Encode(view.Refusal)).Append("</p>\n");
                }

                if (view.Notice != null)
                {
                    html.Append("<p class=\"mt-6 max-w-[62ch] text-xs leading-5 text-muted\" role=\"note\">").Append(Http.Encode(view.Notice)).Append("</p>\n");
                }

                if (view.Error != null)
                {
                    html.Append("<div class=\"mt-10 max-w-[62ch] rounded-app border border-red-200 bg-red-50 p-5 text-sm leading-6 text-red-800\" role=\"alert\">")
                        .Append("<p class=\"font-semibold\">The test users could not be loaded</p><p class=\"mt-1\">").Append(Http.Encode(view.Error)).Append("</p></div>\n");
                }
                else if (view.Users.Count == 0)
                {
                    html.Append("<p class=\"mt-10 max-w-[62ch] rounded-app border border-line bg-surface p-5 text-sm leading-6 text-muted\">")
                        .Append("No development users are set up. Add them to the database tables <code>frp.DevelopmentUser</code> and <code>frp.DevelopmentUserRole</code>.</p>\n");
                }
                else
                {
                    html.Append("<form method=\"post\" action=\"account/signin\" class=\"mt-10 grid gap-3 sm:grid-cols-2\">\n");
                    Hidden(html, "ReturnUrl", view.ReturnUrl);
                    Hidden(html, "__RequestVerificationToken", view.AntiforgeryToken);
                    foreach (var user in view.Users)
                    {
                        html.Append("<button name=\"userName\" value=\"").Append(Http.Encode(user.Name))
                            .Append("\" class=\"group flex items-center justify-between gap-4 rounded-app border border-line bg-surface px-5 py-4 text-left transition hover:border-accent hover:bg-accent-soft focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent\">")
                            .Append("<span><span class=\"block font-semibold text-ink\">").Append(Http.Encode(user.Name)).Append("</span>")
                            .Append("<span class=\"mt-1 block text-sm text-muted\">")
                            .Append(Http.Encode(user.Roles.Count == 0 ? "No role (to see the access-denied page)" : string.Join(" · ", user.Roles))).Append("</span></span>")
                            .Append("<i class=\"ph ph-arrow-right text-lg text-muted transition group-hover:translate-x-0.5 group-hover:text-accent\"></i></button>\n");
                    }

                    html.Append("</form>\n");
                }

                html.Append("</main>\n");
            }

            html.Append("</body>\n</html>\n");
            return html.ToString();
        }

        /// <summary>
        /// Shown for an unexpected error: no exception, stack trace or path reaches the browser (the error itself is in the log).
        /// </summary>
        public static string Error(HttpContextBase context, IDictionary<string, string> versions)
        {
            return Message(context, versions, "Something went wrong", "The request could not be completed. It has been logged. Try again, or go back to the start page.", "Start page", "");
        }

        /// <summary>A request whose form token was missing or wrong (an old page, or a request from another site).</summary>
        public static string FormExpired(HttpContextBase context, IDictionary<string, string> versions)
        {
            return Message(context, versions, "The page expired", "The form was sent without a valid security token. Go back, reload the page and try again.", "Start page", "");
        }

        /// <summary>Windows sign-in without a Windows user (IIS's Windows Authentication is off or Anonymous Authentication is on).</summary>
        public static string WindowsSignInMissing(HttpContextBase context, IDictionary<string, string> versions)
        {
            return Message(context, versions, "Sign in to continue", "Your Windows sign-in was not received. Reload the page or contact your administrator.", "Reload", "");
        }

        /// <summary>Windows signed the person in, but FRP Mapper refuses the account (locked, deactivated, expired or disabled).</summary>
        public static string WindowsSignInRefused(HttpContextBase context, string reason, IDictionary<string, string> versions)
        {
            return Message(context, versions, "You cannot use FRP Mapper right now", reason, "Try again", "");
        }

        /// <summary>A download the API refused or could not produce.</summary>
        public static string DownloadUnavailable(HttpContextBase context, string message, string projectId)
        {
            return "<!doctype html><meta charset=\"utf-8\"><title>Download not available</title>"
                + "<body style=\"font-family:Inter,Arial,sans-serif;max-width:640px;margin:10vh auto;padding:0 24px;line-height:1.6\">"
                + "<h1 style=\"font-size:24px\">Download not available</h1><p>" + Http.Encode(message) + "</p>"
                + "<p><a href=\"" + Http.Encode(Http.BasePath(context) + "projects/" + projectId) + "\">Back to the project</a></p></body>";
        }

        private static string Message(HttpContextBase context, IDictionary<string, string> versions, string title, string text, string link, string href)
        {
            var html = new StringBuilder();
            Head(html, context, title, versions, false, true);
            html.Append("<body class=\"bg-canvas font-body text-ink\">\n<main class=\"flex min-h-screen items-center justify-center px-4 py-12 sm:px-6\">\n")
                .Append("<div class=\"w-full max-w-md rounded-app border border-line bg-surface p-8 shadow-sm sm:p-10\">\n")
                .Append("<h1 class=\"font-display text-2xl font-bold tracking-tight text-ink\">").Append(Http.Encode(title)).Append("</h1>\n")
                .Append("<p class=\"mt-3 text-sm leading-6 text-muted\">").Append(Http.Encode(text)).Append("</p>\n")
                .Append("<a class=\"mt-6 inline-flex items-center rounded-app bg-accent px-4 py-2 text-sm font-semibold text-white hover:opacity-90\" href=\"").Append(Http.Encode(href)).Append("\">")
                .Append(Http.Encode(link)).Append("</a>\n</div>\n</main>\n</body>\n</html>\n");
            return html.ToString();
        }

        private static void Head(StringBuilder html, HttpContextBase context, string title, IDictionary<string, string> versions, bool icons, bool noIndex = false)
        {
            html.Append("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\" />\n")
                .Append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n");
            if (noIndex)
            {
                html.Append("<meta name=\"robots\" content=\"noindex\" />\n");
            }

            html.Append("<title>").Append(Http.Encode(title)).Append("</title>\n")
                .Append("<base href=\"").Append(Http.Encode(Http.BasePath(context))).Append("\" />\n")
                .Append("<link rel=\"icon\" type=\"image/svg+xml\" href=\"favicon.svg\" />\n")
                .Append("<link rel=\"stylesheet\" href=\"vendor/fonts/fonts.css\" />\n");
            if (icons)
            {
                html.Append("<link rel=\"stylesheet\" href=\"vendor/phosphor/style.css\" />\n");
            }

            foreach (var style in Styles)
            {
                html.Append("<link rel=\"stylesheet\" href=\"").Append(style).Append("?v=").Append(Version(versions, style)).Append("\" />\n");
            }

            html.Append("</head>\n");
        }

        private static void Hidden(StringBuilder html, string name, string value)
        {
            html.Append("<input type=\"hidden\" name=\"").Append(name).Append("\" value=\"").Append(Http.Encode(value)).Append("\" />\n");
        }

        private static string Version(IDictionary<string, string> versions, string file)
        {
            string version;
            return versions != null && versions.TryGetValue(file, out version) ? version : "0";
        }
    }
}
