// Validate: check a filled Excel template, the XML built from a project, or any XML file against a project's XSD and BSP
// specification. A filled template that passes can become the project's submission file. The same XML can then be sent
// to a BSP test environment (sandbox): BSP's findings are merged into the result, each message showing where it came from.
(function () {
    "use strict";

    var Frp = window.Frp;
    var html = Frp.html;
    var C = Frp.components;
    var P = Frp.Permissions;

    /** The validation runner for one project (the Blazor ValidationRunner component). */
    function Runner(page) {
        this.page = page;
        this.projectId = null;
        this.status = null;
        this.setup = null;
        this.reset();
    }

    // ---------- BSP sandbox: send the validated XML, wait for BSP's result, merge its findings ----------

    var pollSeconds = 15, pollAttempts = 12;

    function ruleKey(code) {
        return String(code || "").trim().toUpperCase().replace(/^ASSERTION-/, "");
    }

    /** The rule of an app message ("Specification: RIN-B1690: …" or message.rule). */
    function ruleOf(message) {
        if (message.rule) {
            return ruleKey(message.rule);
        }

        var parts = /^[A-Za-z][A-Za-z ]*: ([A-Za-z0-9][A-Za-z0-9_.\-]*): /.exec(message.message || "");
        return parts ? ruleKey(parts[1]) : "";
    }

    /** The form, table and row an app message names ("…, BRIS_DL MAIN_Y1 row 233, …"), or null. */
    function placeOf(message) {
        var where = /, ([A-Za-z0-9_]+) ([A-Za-z0-9_]+) row (\d+)(?:,|\))/.exec(message.message || "");
        return where ? { form: where[1], table: where[2], row: Number(where[3]) } : null;
    }

    var severityRank = { Error: 0, Warning: 1, Info: 2 };

    /**
     * One result from the app's and BSP's: every app message once, tagged "App", or "Both" when BSP reported the same rule
     * at the same place; BSP findings the app did not report are added, tagged "BSP sandbox". Errors first, then warnings,
     * then information, each in their own order. Not valid when either found an error.
     */
    Frp.mergeBspFindings = function (appResult, sent, findings) {
        var messages = (appResult.messages || []).map(function (m) {
            var copy = {};
            Object.keys(m).forEach(function (key) { copy[key] = m[key]; });
            copy.source = "App";
            return copy;
        });
        var bspOnly = [], both = 0;
        (findings.findings || []).forEach(function (f) {
            var rule = ruleKey(f.code), match = null;
            for (var i = 0; rule && i < messages.length && !match; i++) {
                var m = messages[i];
                if (m.source !== "App" || m.severity === "Info" || ruleOf(m) !== rule) {
                    continue;
                }

                var place = placeOf(m);
                if (f.row !== null && f.row !== undefined && place) {
                    if (place.table === f.table && place.row === f.row) {
                        match = m;
                    }
                } else {
                    match = m;
                }
            }

            if (match) {
                match.source = "Both";
                match.bspMessage = f.message;
                both++;
            } else {
                var text = f.message || "(BSP gave no message)";
                bspOnly.push({
                    severity: f.severity || "Error", source: "BSP sandbox", rule: f.code || null, schemaPath: f.location || null,
                    message: "BSP sandbox: " + (f.code ? f.code + ": " : "") + text + (f.location && text.indexOf(f.location) < 0 ? " (" + f.location + ")" : "")
                });
            }
        });

        var all = messages.concat(bspOnly).map(function (m, index) { return { m: m, index: index }; });
        all.sort(function (a, b) {
            var ra = severityRank[a.m.severity] !== undefined ? severityRank[a.m.severity] : 3, rb = severityRank[b.m.severity] !== undefined ? severityRank[b.m.severity] : 3;
            return ra - rb || a.index - b.index;
        });
        var merged = {};
        Object.keys(appResult).forEach(function (key) { merged[key] = appResult[key]; });
        merged.messages = all.map(function (x) { return x.m; });
        merged.isValid = !!appResult.isValid && !(findings.findings || []).some(function (f) { return (f.severity || "Error") === "Error"; });
        merged.bsp = {
            environmentName: sent.environmentName, submissionId: findings.submissionId || sent.submissionId, format: findings.format,
            total: (findings.findings || []).length, both: both, bspOnly: bspOnly.length,
            appOnly: messages.filter(function (m) { return m.source === "App" && m.severity !== "Info"; }).length
        };
        return merged;
    };

    Runner.prototype.reset = function () {
        this.result = null;
        this.error = null;
        this.notice = null;
        this.workbook = null;
        this.xmlFile = null;
        this.busy = false;
        this.attaching = false;
        this.running = null;
        this.progress = null;
        this.source = null;
        this.stopBsp();
        this.bsp = null;
    };

    Runner.prototype.stopBsp = function () {
        if (this.bsp && this.bsp.timer) {
            clearTimeout(this.bsp.timer);
            this.bsp.timer = null;
        }
    };

    Runner.prototype.canSandbox = function () {
        return Frp.can(P.SubmissionPrepare);
    };

    /**
     * The result shown: the app's, or the app's merged with BSP's findings once they arrived. While an uploaded XML is
     * still with BSP, the app's result carries a line saying so (bspStatus), so both checks read as one validation.
     */
    Runner.prototype.shown = function () {
        var bsp = this.bsp;
        if (bsp && bsp.merged) {
            return bsp.merged;
        }

        if (bsp && bsp.auto && this.result && (bsp.phase === "preparing" || bsp.phase === "sending" || bsp.phase === "waiting")) {
            var copy = {}, result = this.result;
            Object.keys(result).forEach(function (key) { copy[key] = result[key]; });
            copy.bspStatus = bsp.phase === "waiting"
                ? "BSP sandbox: submission " + bsp.sent.submissionId + " accepted; waiting for BSP's validation result (check " + bsp.attempts + " of " + pollAttempts + ")…"
                : "BSP sandbox: sending " + this.source.label + " with the report code, period and bank from its Header…";
            return copy;
        }

        return this.result;
    };

    /**
     * An uploaded XML is validated by the app and by BSP's sandbox in one go: once the app's check is done, the same XML
     * is sent to the first approved test environment. The report code, period and bank come from the XML on the server.
     * When that cannot work (no bank for the Header's Undertaking, no stored certificate…), the BSP panel shows why, with
     * the fields to correct and send again.
     */
    Runner.prototype.autoBsp = function () {
        var self = this, projectId = self.projectId, source = self.source;
        if (!self.canSandbox() || !self.result || !source) {
            return Promise.resolve();
        }

        var bsp = self.bsp = self.newBsp();
        bsp.auto = true;
        bsp.phase = "preparing";
        self.page.update();
        return self.loadSetup().then(function () {
            if (self.bsp !== bsp || projectId !== self.projectId || self.source !== source) return;
            var setup = self.setup;
            if (setup.error || !setup.environments.length) {
                bsp.phase = "failed";
                bsp.error = setup.error || "No BSP test environment is approved, so the XML was checked by the app only. A bank profile Maker adds one on BSP submission, Settings tab.";
                return;
            }

            bsp.environment = setup.environments[0].key;
            bsp.phase = "idle";
            return self.sendToBsp();
        });
    };

    /** The approved test environments and the bank profiles, loaded once when the BSP panel is first shown. */
    Runner.prototype.loadSetup = function () {
        var self = this;
        if (self.setupLoad) {
            return self.setupLoad;
        }

        self.setup = { loading: true };
        return self.setupLoad = Promise.all([Frp.api.get("sandbox/environments", null, { quiet: true }), Frp.api.get("sandbox/banks", null, { quiet: true })]).then(function (results) {
            var environments = (results[0] || []).filter(function (e) { return e.kind === "Test" && e.canUse; });
            self.setup = { environments: environments, banks: results[1] || [] };
        }, function (error) {
            self.setup = { error: Frp.messageOf(error) };
        }).then(function () {
            if (self.bsp && !self.bsp.environment && self.setup.environments && self.setup.environments.length) {
                self.bsp.environment = self.setup.environments[0].key;
            }

            self.page.update();
        });
    };

    Runner.prototype.newBsp = function () {
        var environments = this.setup && this.setup.environments;
        return { environment: environments && environments.length ? environments[0].key : "", bank: "", reportCode: "", period: "",
            certificate: null, password: "", phase: "idle", sent: null, findings: null, attempts: 0, answer: null, error: null, timer: null, merged: null,
            read: null, reading: false };
    };

    /** Fills the report code, period and bank from the validated XML (read on the server; nothing is sent to BSP). */
    Runner.prototype.readParameters = function () {
        var self = this, bsp = self.bsp, source = self.source;
        if (!bsp || !source || bsp.read || bsp.reading) {
            return Promise.resolve();
        }

        bsp.reading = true;
        var fields = { project: self.projectId, source: source.kind };
        if (source.kind === "file") fields.file = source.file;
        if (source.kind === "workbook") fields.workbookFile = source.file;
        return Frp.api.upload("sandbox/parameters", fields, { quiet: true }).then(function (read) {
            if (self.bsp !== bsp) return;
            bsp.read = read;
            if (!bsp.reportCode) bsp.reportCode = read.reportCode || "";
            if (!bsp.period) bsp.period = read.period || "";
            if (!bsp.bank && read.bankKey) bsp.bank = read.bankKey;
        }, function (error) {
            if (self.bsp !== bsp) return;
            bsp.read = { error: Frp.messageOf(error) };
        }).then(function () {
            bsp.reading = false;
            self.page.update();
        });
    };

    /** The fields that identify the certificate (stored for the bank, or the PFX chosen here). */
    Runner.prototype.certificateFields = function (bank) {
        var bsp = this.bsp;
        return bsp.certificate ? { certificateSource: "upload", certificate: bsp.certificate, password: bsp.password, bank: bank }
            : { certificateSource: "stored", bank: bank };
    };

    Runner.prototype.sendToBsp = function () {
        var self = this, bsp = self.bsp, source = self.source, projectId = self.projectId;
        if (!bsp || !source || bsp.phase === "sending" || bsp.phase === "waiting" || bsp.phase === "preparing") {
            return Promise.resolve();
        }

        var fields = self.certificateFields(bsp.bank);
        fields.environment = bsp.environment;
        fields.project = projectId;
        fields.source = source.kind;
        if (bsp.reportCode.trim()) fields.reportCode = bsp.reportCode.trim();
        if (bsp.period.trim()) fields.period = bsp.period.trim();
        if (source.kind === "file") fields.file = source.file;
        if (source.kind === "workbook") fields.workbookFile = source.file;
        bsp.phase = "sending"; bsp.error = null; bsp.answer = null; bsp.findings = null; bsp.merged = null; bsp.attempts = 0;
        self.page.update();
        return Frp.api.upload("sandbox/validate", fields, { busy: "Sending the XML to BSP's sandbox" }).then(function (sent) {
            if (self.bsp !== bsp || projectId !== self.projectId) return;
            bsp.sent = sent;
            if (!sent.submissionId) {
                bsp.phase = "failed";
                bsp.error = "BSP did not accept the submission (HTTP " + sent.statusCode + "), so it has no validation result. BSP's answer is below.";
                bsp.answer = sent.body;
                return;
            }

            bsp.phase = "waiting";
            return self.pollBsp();
        }, function (error) {
            if (self.bsp !== bsp) return;
            bsp.phase = "failed";
            bsp.error = Frp.messageOf(error);
        }).then(function () {
            self.page.update();
        });
    };

    /** Asks BSP for the validation result; until it is ready, again every 15 seconds, at most 12 times. */
    Runner.prototype.pollBsp = function () {
        var self = this, bsp = self.bsp;
        if (!bsp || !bsp.sent) {
            return Promise.resolve();
        }

        bsp.timer = null;
        bsp.phase = "waiting";
        bsp.attempts++;
        self.page.update();
        var fields = self.certificateFields(bsp.sent.bankKey);
        fields.environment = bsp.sent.environment;
        fields.submissionId = bsp.sent.submissionId;
        return Frp.api.upload("sandbox/findings", fields, { quiet: true }).then(function (findings) {
            if (self.bsp !== bsp) return;
            if (findings.ready) {
                bsp.findings = findings;
                bsp.merged = Frp.mergeBspFindings(self.result, bsp.sent, findings);
                bsp.phase = "done";
            } else if (bsp.attempts < pollAttempts) {
                bsp.answer = findings.body;
                bsp.timer = setTimeout(function () { self.pollBsp(); }, pollSeconds * 1000);
            } else {
                bsp.answer = findings.body;
                bsp.phase = "stopped";
            }
        }, function (error) {
            if (self.bsp !== bsp) return;
            bsp.phase = "failed";
            bsp.error = Frp.messageOf(error);
        }).then(function () {
            self.page.update();
        });
    };

    /** What was read from the XML, under the fields. */
    Runner.prototype.renderRead = function () {
        var bsp = this.bsp, read = bsp.read;
        if (bsp.reading) {
            return html`<p class="mt-3 text-xs text-muted" role="status">Reading the report code, period and bank from the XML…</p>`;
        }

        if (!read) {
            return "";
        }

        if (read.error) {
            return html`<p class="mt-3 text-xs text-amber-800">The XML could not be read for its parameters (${read.error}). Fill them in.</p>`;
        }

        var parts = [];
        if (read.reportCode) parts.push("report code " + read.reportCode + " (the XML's root element)");
        if (read.period) parts.push("period " + read.period + " (Header Year and Period)");
        if (read.bankKey) parts.push("bank " + read.bankKey + " (Header Undertaking " + read.undertaking + ")");
        return html`<p class="mt-3 flex items-start gap-1.5 text-xs text-muted"><i class="ph ph-file-code mt-0.5 text-accent" aria-hidden="true"></i>
            <span>${parts.length ? "From the XML: " + parts.join(", ") + ". You can change them." : "The XML gives none of these; fill them in."}
            ${!read.period ? html` <span class="font-semibold text-amber-800">The Header has no Year and month Period: enter the period.</span>` : ""}
            ${!read.bankKey ? html` <span class="font-semibold text-amber-800">${read.undertaking ? "No single bank profile has provider code " + read.undertaking + ": choose the bank." : "The Header has no Undertaking: choose the bank."}</span>` : ""}
            ${read.bankKey && !read.hasStoredCertificate ? html` <span class="font-semibold text-amber-800">${read.bankKey} has no stored certificate: upload its PFX below.</span>` : ""}</span></p>`;
    };

    Runner.prototype.renderBsp = function () {
        var self = this, page = self.page, bsp = self.bsp, setup = self.setup;
        if (!self.canSandbox() || !self.source || !self.result) {
            return "";
        }

        // An uploaded XML goes to BSP by itself; its progress is shown in the result. The panel appears only when
        // sending it needs a correction (or BSP has no result yet), so it can be sent again.
        if (bsp && bsp.auto && (bsp.phase === "preparing" || bsp.phase === "sending" || bsp.phase === "waiting" || bsp.phase === "done")) {
            return "";
        }

        self.loadSetup();
        if (!bsp) {
            bsp = self.bsp = self.newBsp();
        }

        self.readParameters();

        var input = "mt-1.5 block h-10 w-full rounded-app border border-line bg-surface px-3 text-sm outline-none transition hover:border-slate-300 focus:border-accent disabled:opacity-60";
        var busy = bsp.phase === "sending" || bsp.phase === "waiting";
        var body;
        if (!setup || setup.loading) {
            body = html`<p class="text-sm text-muted">Loading the BSP environments and bank profiles…</p>`;
        } else if (setup.error) {
            body = C.notice("Error", null, setup.error);
        } else if (!setup.environments.length) {
            body = html`<p class="text-sm text-muted">No BSP test environment is approved. A bank profile Maker adds one on BSP submission, Settings tab.</p>`;
        } else {
            var bank = setup.banks.filter(function (b) { return b.key === bsp.bank; })[0];
            var needsPfx = bank && !bank.storedCertificate;
            body = html`<div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <label class="block text-sm font-semibold text-ink">Environment
            <select autocomplete="off" class="${input}"${Frp.attr("disabled", busy)} data-change="${page.on(function (e) { bsp.environment = e.target.value; })}">
                ${setup.environments.map(function (e) { return html`<option value="${e.key}"${Frp.attr("selected", bsp.environment === e.key)}>${e.name}</option>`; })}
            </select>
        </label>
        <label class="block text-sm font-semibold text-ink">Bank
            <select autocomplete="off" class="${input}"${Frp.attr("disabled", busy)} data-change="${page.on(function (e) { bsp.bank = e.target.value; bsp.certificate = null; bsp.password = ""; page.update(); })}">
                <option value=""${Frp.attr("selected", !bsp.bank)}>Choose the bank</option>
                ${setup.banks.map(function (b) { return html`<option value="${b.key}"${Frp.attr("selected", bsp.bank === b.key)}>${b.key} · ${b.name}${b.storedCertificate ? "" : " (no stored certificate)"}</option>`; })}
            </select>
        </label>
        <label class="block text-sm font-semibold text-ink">Report code
            <input autocomplete="off" maxlength="40" class="${input} font-mono" value="${bsp.reportCode}"${Frp.attr("disabled", busy)}
                   data-input="${page.on(function (e) { bsp.reportCode = e.target.value; })}" />
        </label>
        <label class="block text-sm font-semibold text-ink">Reporting period
            <input autocomplete="off" maxlength="7" class="${input} font-mono" placeholder="YYYY-MM" value="${bsp.period}"${Frp.attr("disabled", busy)}
                   data-input="${page.on(function (e) { bsp.period = e.target.value; })}" />
        </label>
    </div>
    ${self.renderRead()}
    ${needsPfx ? html`<div class="mt-4 grid gap-4 sm:grid-cols-2">
        <label class="block text-sm font-semibold text-ink">${bank.key}'s certificate (.pfx)
            <input type="file" accept=".pfx,.p12" class="mt-1.5 block w-full text-sm"${Frp.attr("disabled", busy)}
                   data-change="${page.on(function (e) { bsp.certificate = e.target.files[0] || null; page.update(); })}" />
        </label>
        <label class="block text-sm font-semibold text-ink">Certificate password
            <input type="password" autocomplete="new-password" class="${input}" value="${bsp.password}"${Frp.attr("disabled", busy)}
                   data-input="${page.on(function (e) { bsp.password = e.target.value; })}" />
        </label>
    </div>` : ""}
    <div class="mt-4 flex flex-wrap items-center gap-3">
        <button type="button" class="inline-flex h-10 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50"
                ${Frp.attr("disabled", busy || (needsPfx && !bsp.certificate))} data-click="${page.on(function () { return self.sendToBsp(); })}">
            ${busy ? html`<span class="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" aria-hidden="true"></span>` : html`<i class="ph ph-paper-plane-tilt"></i>`}
            ${bsp.phase === "done" || bsp.phase === "failed" || bsp.phase === "stopped" ? "Validate in BSP sandbox again" : "Validate in BSP sandbox"}
        </button>
        ${bsp.phase === "sending" ? html`<span class="text-sm text-muted" role="status">Sending ${self.source.label} to BSP…</span>` : ""}
        ${bsp.phase === "waiting" ? html`<span class="text-sm text-muted" role="status">Submission ${bsp.sent.submissionId} accepted. Waiting for BSP's validation result (check ${bsp.attempts} of ${pollAttempts}, every ${pollSeconds} seconds)…</span>` : ""}
        ${bsp.phase === "stopped" ? html`<span class="text-sm text-muted">BSP has no result yet for ${bsp.sent.submissionId}.</span>
            <button type="button" class="inline-flex h-9 items-center gap-2 rounded-app border border-line bg-surface px-3 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent"
                    data-click="${page.on(function () { bsp.attempts = 0; return self.pollBsp(); })}"><i class="ph ph-arrow-clockwise"></i> Check again</button>` : ""}
        ${bsp.phase === "done" ? html`<span class="text-sm text-muted">BSP's findings for submission ${bsp.findings.submissionId} are merged into the result below.</span>` : ""}
    </div>
    ${bsp.error ? html`<div class="mt-4">${C.notice("Error", "BSP sandbox validation", bsp.error)}</div>` : ""}
    ${bsp.answer && bsp.phase !== "done" ? html`<details class="mt-3 text-sm"><summary class="cursor-pointer font-semibold text-ink hover:text-accent">BSP's last answer</summary>
        <pre class="mt-2 max-h-60 overflow-auto whitespace-pre-wrap break-words rounded-app border border-line bg-canvas p-3 font-mono text-xs text-ink">${bsp.answer}</pre></details>` : ""}
    ${bsp.phase === "done" && !bsp.findings.findings.length && bsp.findings.format !== "xml" && bsp.findings.format !== "json" ? html`<p class="mt-3 text-sm text-amber-800">
        BSP's result (${bsp.findings.format}) has no findings this page can read. Download it on BSP submission to check it.</p>` : ""}`;
        }

        return html`<section class="mt-6 rounded-app border ${bsp.auto ? "border-amber-200" : "border-line"} bg-surface p-5" aria-labelledby="bsp-validate-title">
    <h2 id="bsp-validate-title" class="font-semibold text-ink">${bsp.auto ? "BSP sandbox validation did not finish" : "Validate in BSP sandbox"}</h2>
    <p class="mt-1 max-w-prose text-sm text-muted">${bsp.auto
        ? "The app checked " + self.source.label + " (result below). Sending it to BSP's sandbox needs your attention: correct what is shown and send it again; BSP's findings are then added to the result."
        : "Sends " + self.source.label + " to a BSP test environment with the bank's certificate, waits for BSP's validation result and merges its findings into the result below. A sandbox submission is a test, never a real submission."}</p>
    <div class="mt-4">${body}</div>
</section>`;
    };

    /** Another project was chosen: results for the previous one no longer apply. */
    Runner.prototype.forProject = function (projectId, status) {
        if (this.projectId !== projectId) {
            if (this.progress) {
                this.progress.stop();
            }

            this.projectId = projectId;
            this.reset();
        }

        this.status = status;
    };

    /** The API merged an XML exported by Excel from sheet copies before checking it (see SheetCopyMap on the API). */
    Runner.prototype.mergedFromSheetCopies = function () {
        return !!this.result && this.result.messages.some(function (m) {
            return m.severity === "Info" && m.message.indexOf("This XML was exported by Excel from sheet copies") === 0;
        });
    };

    Runner.prototype.canAttach = function () {
        return Frp.can(P.SubmissionPrepare) && (this.status === "Draft" || this.status === "Returned");
    };

    Runner.prototype.begin = function (what, title) {
        this.busy = true;
        this.running = what;
        this.error = null;
        this.notice = null;
        this.workbook = null;
        this.result = null;
        this.source = null;
        this.stopBsp();
        this.bsp = null;
        if (this.progress) {
            this.progress.stop();
        }

        this.progress = new C.Progress(this.page, title);
    };

    Runner.prototype.end = function () {
        this.busy = false;
        this.running = null;
        if (this.progress) {
            this.progress.stop();
            this.progress = null;
        }
    };

    /** Runs a streamed validation; call(report) returns the result. */
    Runner.prototype.run = function (what, title, file, call) {
        var self = this;
        var projectId = self.projectId;
        if (self.running !== "reading") {
            self.begin(what, title);
        }

        self.running = what;
        self.progress.show({
            percent: 0,
            stage: file ? "Sending the file to the API" : "Asking the API to start",
            detail: file ? file.name + " · " + Frp.size(file.size) : null
        });
        return call(function (update) { self.progress.show(update); }).then(function (result) {
            if (projectId === self.projectId) {
                self.result = result;
            }
        }, function (error) {
            if (projectId === self.projectId) {
                Frp.toast("Error", "The file was not validated", Frp.messageOf(error));
            }
        }).then(function () {
            if (projectId === self.projectId) {
                self.end();
                self.page.update();
            }
        });
    };

    /** Checks the chosen file's type and size (shown as the first step). */
    Runner.prototype.chosen = function (file, kind) {
        var problem = Frp.files.problem(kind, file);
        if (problem) {
            Frp.toast("Error", "This file cannot be validated", problem);
            return false;
        }

        this.begin("reading", "Validating " + file.name);
        this.progress.show({ percent: 0, stage: "Reading the file from your computer", detail: file.name + " · " + Frp.size(file.size) });
        return true;
    };

    function streamed(method, path, form, onProgress) {
        return Frp.api.stream(method, path, form ? { form: form } : {}, onProgress, function (item) { return item.result; }, "The validation failed.");
    }

    function fileForm(name, file) {
        var form = new FormData();
        form.append(name, file, file.name);
        return form;
    }

    Runner.prototype.validateProject = function () {
        var self = this;
        var id = this.projectId;
        return this.run("project", "Validating the XML built from the project", null, function (report) {
            return streamed("GET", "projects/" + id + "/validate/generated-xml", null, report);
        }).then(function () {
            self.source = self.result ? { kind: "generated", label: "the XML built from the project" } : null;
            self.page.update();
        });
    };

    Runner.prototype.validateFile = function (file) {
        var self = this;
        var id = self.projectId;
        if (!self.chosen(file, Frp.UploadKinds.XmlToValidate)) {
            return Promise.resolve();
        }

        return self.run("file", "Validating " + file.name, file, function (report) {
            return streamed("POST", "projects/" + id + "/validate/xml", fileForm("xmlFile", file), report);
        }).then(function () {
            self.xmlFile = self.result && !self.error ? file : null;
            self.source = self.result ? { kind: "file", file: file, label: file.name } : null;
            self.page.update();
            return self.autoBsp();
        });
    };

    Runner.prototype.validateWorkbook = function (file) {
        var self = this;
        var id = self.projectId;
        if (!self.chosen(file, Frp.UploadKinds.WorkbookToCheck)) {
            return Promise.resolve();
        }

        return self.run("workbook", "Validating " + file.name, file, function (report) {
            return streamed("POST", "projects/" + id + "/validate/workbook", fileForm("workbookFile", file), report);
        }).then(function () {
            self.workbook = self.result && !self.error ? file : null;
            self.source = self.result ? { kind: "workbook", file: file, label: "the XML built from " + file.name } : null;
            self.page.update();
        });
    };

    Runner.prototype.downloadMerged = function () {
        var self = this;
        if (!self.xmlFile || self.busy) {
            return Promise.resolve();
        }

        self.busy = true;
        self.error = null;
        self.page.update();
        return Frp.api.file("projects/" + self.projectId + "/xml/merge-sheet-copies", { xmlFile: self.xmlFile }).then(function (file) {
            Frp.saveFile(file.name.replace(/^.*[\\/]/, ""), file.blob);
        }, function (error) {
            Frp.toast("Error", "The merged XML was not downloaded", error instanceof Frp.ApiError && !error.unreachable ? error.message : "The merged XML could not be downloaded. Try again.");
        }).then(function () {
            self.busy = false;
            self.page.update();
        });
    };

    /**
     * Saves the result shown on the page as an Excel workbook: "Summary" (the totals and the count per rule) and
     * "Messages" (every message, not only the first 200 shown, with the rule, form, row and branch split into columns
     * so the list can be filtered and compared with BSP's "List of errors").
     */
    Runner.prototype.downloadResults = function () {
        var result = this.shown();
        if (!result) {
            return;
        }

        var messages = (result.messages || []).map(function (m, index) {
            // "Specification: RIN-B1690: ... (left side 51 = right side 57, BRIS_DL MAIN_Y1 row 233, branch 1000072 ISABELA-SANTIAGO)"
            var parts = /^([A-Za-z][A-Za-z ]*): (?:([A-Za-z0-9][A-Za-z0-9_.\-]*): )?([\s\S]*)$/.exec(m.message || "");
            var where = /, ([A-Za-z0-9_]+) ([A-Za-z0-9_]+) row (\d+)(?:,|\))/.exec(m.message || "");
            return [index + 1, m.severity, parts ? parts[1] : "", m.rule || (parts && parts[2]) || "", where ? where[1] : "", where ? where[2] : "",
                where ? Number(where[3]) : "", m.branchCode || "", m.branchName || "", parts ? parts[3] : m.message,
                m.cell || "", m.schemaPath || "", m.lineNumber > 0 ? m.lineNumber : "", m.linePosition > 0 ? m.linePosition : "",
                m.source === "Both" ? "App and BSP sandbox" : m.source || "App", m.bspMessage || ""];
        });

        var counts = {};
        messages.forEach(function (row) {
            if (row[3] && row[1] !== "Info") {
                var key = row[3] + "\u0000" + row[1];
                counts[key] = (counts[key] || 0) + 1;
            }
        });

        var summary = [["Validation result"], [], ["Validated", result.target], ["Result", result.isValid ? "Valid" : "Not valid"],
            ["Exported", new Date().toLocaleString()]];
        if (result.bsp) {
            summary.push(["BSP sandbox", result.bsp.environmentName], ["BSP submission ID", result.bsp.submissionId], ["BSP findings", result.bsp.total],
                ["Found by both", result.bsp.both], ["Found only by BSP", result.bsp.bspOnly], ["Found only by the app", result.bsp.appOnly]);
        }

        if (result.specificationChecked) {
            summary.push(["BSP rules passed", result.specRulesPassed], ["BSP rules failed", result.specRulesFailed],
                ["BSP rules not applicable", result.specRulesNotApplicable], ["BSP rules not evaluated", result.specRulesNotEvaluated]);
        }

        ["Error", "Warning", "Info"].forEach(function (severity) {
            summary.push([severity + " messages", messages.filter(function (row) { return row[1] === severity; }).length]);
        });
        summary.push([], ["Rule", "Severity", "Messages"]);
        var headerRow = summary.length;
        Object.keys(counts).sort().forEach(function (key) {
            var pair = key.split("\u0000");
            summary.push([pair[0], pair[1], counts[key]]);
        });

        var sheets = [
            { name: "Summary", rows: summary, widths: [34, 14, 12], bold: [1, headerRow] },
            {
                name: "Messages", widths: [7, 10, 14, 42, 12, 12, 8, 13, 34, 110, 18, 40, 7, 9, 20, 80], bold: [1], freeze: true,
                rows: [["No.", "Severity", "Check", "Rule", "Form", "Table", "Row", "Branch code", "Branch name", "Message", "Cell", "XML element", "Line", "Position", "Source", "BSP's message"]].concat(messages)
            }
        ];
        if (result.specificationChecked && (result.specRuleForms || []).length) {
            // Every form whose rules were checked, also when they all passed (and so have no message).
            sheets.push({
                name: "Rules by form", widths: [22, 10, 10, 15, 15], bold: [1], freeze: true,
                rows: [["Form", "Passed", "Failed", "Not applicable", "Not evaluated"]].concat(result.specRuleForms.map(function (f) {
                    return [f.form, f.passed, f.failed, f.notApplicable, f.notEvaluated];
                }))
            });
        }
        var now = new Date();
        var stamp = now.getFullYear() + ("0" + (now.getMonth() + 1)).slice(-2) + ("0" + now.getDate()).slice(-2) + "-"
            + ("0" + now.getHours()).slice(-2) + ("0" + now.getMinutes()).slice(-2);
        var name = "validation-" + String(result.target || "result").replace(/^.*[\\/]/, "").replace(/\.[^.]*$/, "").replace(/[^A-Za-z0-9_\-]+/g, "_").slice(0, 60) + "-" + stamp + ".xlsx";
        Frp.saveFile(name, new Blob([xlsx(sheets)], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
    };

    // ---------- a small .xlsx writer (Office Open XML in an uncompressed zip; no library needed) ----------

    /** sheets: [{ name, rows: [[value]], widths: [characters], bold: [row numbers], freeze }] → Uint8Array of an .xlsx file. */
    function xlsx(sheets) {
        function esc(value) {
            return String(value).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F￾￿]/g, "")
                .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        }

        function column(index) {
            var name = "";
            for (var n = index + 1; n > 0; n = Math.floor((n - 1) / 26)) {
                name = String.fromCharCode(65 + (n - 1) % 26) + name;
            }

            return name;
        }

        function sheetXml(sheet) {
            var width = sheet.rows.reduce(function (max, row) { return Math.max(max, row.length); }, 1);
            var rows = sheet.rows.map(function (row, r) {
                var bold = sheet.bold && sheet.bold.indexOf(r + 1) >= 0;
                var cells = row.map(function (value, c) {
                    if (value === "" || value === null || value === undefined) {
                        return "";
                    }

                    var ref = column(c) + (r + 1);
                    var style = bold ? ' s="1"' : "";
                    // Text is written as inline strings, so Excel never reads a message as a formula.
                    return typeof value === "number" && isFinite(value)
                        ? '<c r="' + ref + '"' + style + "><v>" + value + "</v></c>"
                        : '<c r="' + ref + '"' + style + ' t="inlineStr"><is><t xml:space="preserve">' + esc(value) + "</t></is></c>";
                }).join("");
                return '<row r="' + (r + 1) + '">' + cells + "</row>";
            }).join("");
            var cols = (sheet.widths || []).map(function (w, i) { return '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + w + '" customWidth="1"/>'; }).join("");
            var pane = sheet.freeze ? '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>' : "";
            var filter = sheet.freeze && sheet.rows.length > 1 ? '<autoFilter ref="A1:' + column(width - 1) + sheet.rows.length + '"/>' : "";
            return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                + pane + (cols ? "<cols>" + cols + "</cols>" : "") + "<sheetData>" + rows + "</sheetData>" + filter + "</worksheet>";
        }

        var ns = "http://schemas.openxmlformats.org/";
        var files = [
            ["[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="' + ns + 'package/2006/content-types">'
                + '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
                + '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                + '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                + sheets.map(function (s, i) { return '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'; }).join("")
                + "</Types>"],
            ["_rels/.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="' + ns + 'package/2006/relationships">'
                + '<Relationship Id="rId1" Type="' + ns + 'officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
            ["xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="' + ns + 'spreadsheetml/2006/main" xmlns:r="' + ns + 'officeDocument/2006/relationships"><sheets>'
                + sheets.map(function (s, i) { return '<sheet name="' + esc(s.name) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>'; }).join("")
                + "</sheets></workbook>"],
            ["xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="' + ns + 'package/2006/relationships">'
                + sheets.map(function (s, i) { return '<Relationship Id="rId' + (i + 1) + '" Type="' + ns + 'officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>'; }).join("")
                + '<Relationship Id="rId' + (sheets.length + 1) + '" Type="' + ns + 'officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'],
            ["xl/styles.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="' + ns + 'spreadsheetml/2006/main">'
                + '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
                + '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
                + '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
                + '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                + '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>'
                + '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
                + "</styleSheet>"]
        ].concat(sheets.map(function (s, i) { return ["xl/worksheets/sheet" + (i + 1) + ".xml", sheetXml(s)]; }));
        return zip(files);
    }

    /** A zip archive with the files stored uncompressed (what Excel needs; no compression library). */
    function zip(files) {
        var encoder = new TextEncoder();
        var table = zip.crcTable || (zip.crcTable = (function () {
            var t = new Uint32Array(256);
            for (var n = 0; n < 256; n++) {
                var c = n;
                for (var k = 0; k < 8; k++) {
                    c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
                }

                t[n] = c >>> 0;
            }

            return t;
        })());
        function crc32(bytes) {
            var crc = 0xFFFFFFFF;
            for (var i = 0; i < bytes.length; i++) {
                crc = table[(crc ^ bytes[i]) & 0xFF] ^ (crc >>> 8);
            }

            return (crc ^ 0xFFFFFFFF) >>> 0;
        }

        var locals = [], centrals = [], offset = 0;
        files.forEach(function (file) {
            var name = encoder.encode(file[0]);
            var data = encoder.encode(file[1]);
            var crc = crc32(data);
            var local = new DataView(new ArrayBuffer(30));
            local.setUint32(0, 0x04034B50, true); local.setUint16(4, 20, true); local.setUint16(6, 0x0800, true); local.setUint16(8, 0, true);
            local.setUint16(10, 0, true); local.setUint16(12, 0x21, true); local.setUint32(14, crc, true);
            local.setUint32(18, data.length, true); local.setUint32(22, data.length, true); local.setUint16(26, name.length, true); local.setUint16(28, 0, true);
            var central = new DataView(new ArrayBuffer(46));
            central.setUint32(0, 0x02014B50, true); central.setUint16(4, 20, true); central.setUint16(6, 20, true); central.setUint16(8, 0x0800, true);
            central.setUint16(10, 0, true); central.setUint16(12, 0, true); central.setUint16(14, 0x21, true); central.setUint32(16, crc, true);
            central.setUint32(20, data.length, true); central.setUint32(24, data.length, true); central.setUint16(28, name.length, true);
            central.setUint32(42, offset, true);
            locals.push(new Uint8Array(local.buffer), name, data);
            centrals.push(new Uint8Array(central.buffer), name);
            offset += 30 + name.length + data.length;
        });
        var centralSize = centrals.reduce(function (sum, part) { return sum + part.length; }, 0);
        var end = new DataView(new ArrayBuffer(22));
        end.setUint32(0, 0x06054B50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true);
        end.setUint32(12, centralSize, true); end.setUint32(16, offset, true);
        var parts = locals.concat(centrals, [new Uint8Array(end.buffer)]);
        var out = new Uint8Array(parts.reduce(function (sum, part) { return sum + part.length; }, 0));
        var at = 0;
        parts.forEach(function (part) { out.set(part, at); at += part.length; });
        return out;
    }

    Runner.prototype.attachWorkbook = function (onChanged) {
        var self = this;
        if (!self.workbook || self.busy) {
            return Promise.resolve();
        }

        self.busy = true;
        self.attaching = true;
        self.error = null;
        self.page.update();
        var workbook = self.workbook;
        return Frp.api.upload("projects/" + self.projectId + "/submission/workbook", { workbookFile: workbook }).then(function (updated) {
            Frp.toast("Success", "Submission file replaced", "The XML built from " + workbook.name + " is now the submission file. Submit it for review from the project page.");
            self.workbook = null;
            onChanged(updated);
        }, function (error) {
            Frp.toast("Error", "The submission file was not replaced", Frp.messageOf(error));
        }).then(function () {
            self.busy = false;
            self.attaching = false;
            self.page.update();
        });
    };

    Runner.prototype.render = function (onChanged) {
        var self = this;
        var page = self.page;
        var busy = self.busy;
        var spinnerWhite = html`<span class="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" aria-hidden="true"></span>`;
        return html`<div>
    <div class="flex flex-wrap gap-2">
        <label class="inline-flex h-10 cursor-pointer items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover ${busy ? "pointer-events-none opacity-50" : ""}">
            ${busy && self.running === "workbook" ? spinnerWhite : html`<i class="ph ph-microsoft-excel-logo"></i>`}
            Validate a filled Excel template
            <input type="file" class="sr-only" accept="${Frp.files.acceptFor(Frp.UploadKinds.WorkbookToCheck)}"${Frp.attr("disabled", busy || !Frp.files.settings())}
                   data-change="${page.on(function (e) { var file = e.target.files[0]; e.target.value = ""; return file ? self.validateWorkbook(file) : undefined; })}" />
        </label>
        <button class="inline-flex h-10 items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:opacity-50"
                ${Frp.attr("disabled", busy)} data-click="${page.on(function () { return self.validateProject(); })}">
            ${busy && self.running === "project" ? html`<span class="h-4 w-4 animate-spin rounded-full border-2 border-accent-line border-t-accent" aria-hidden="true"></span>` : html`<i class="ph ph-shield-check"></i>`}
            Validate XML built from the project
        </button>
        <label class="inline-flex h-10 cursor-pointer items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent ${busy ? "pointer-events-none opacity-50" : ""}">
            <i class="ph ph-upload-simple"></i> Validate an XML file
            <input type="file" class="sr-only" accept="${Frp.files.acceptFor(Frp.UploadKinds.XmlToValidate)}"${Frp.attr("disabled", busy || !Frp.files.settings())}
                   data-change="${page.on(function (e) { var file = e.target.files[0]; e.target.value = ""; return file ? self.validateFile(file) : undefined; })}" />
        </label>
    </div>
    <p class="mt-2 max-w-prose text-xs leading-5 text-subtle">
        A filled Excel template is the input template downloaded from the project with your figures typed in: the app
        reads the values from its input cells, builds the XML and names the cell of every problem. No Excel XML export is needed.
        ${self.canSandbox() ? html`<span class="mt-1 block">An XML file is also checked in BSP's sandbox in the same step (a test submission, never a real one):
            the report code, period and bank are read from its Header, and BSP's errors are added to the result.</span>` : ""}
    </p>
    ${self.running && self.progress ? html`<div class="mt-6">${self.progress.render()}</div>` : ""}
    ${self.result && !self.running ? html`
        ${self.xmlFile && self.mergedFromSheetCopies() ? html`<div class="mt-6 flex flex-wrap items-center gap-3 rounded-app border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900" role="status">
            <i class="ph ph-warning text-lg text-amber-700" aria-hidden="true"></i>
            <span class="min-w-[12rem] flex-1">
                ${self.xmlFile.name} was exported by Excel from sheet copies (elements such as CAR_Part_IV_4c_USD that BSP's XSD does not have),
                so other tools and BSP reject it as it is. These results are for the merged XML; download it to check it elsewhere or submit it.
            </span>
            <button class="inline-flex h-9 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50"
                    ${Frp.attr("disabled", busy)} data-click="${page.on(function () { return self.downloadMerged(); })}">
                <i class="ph ph-download-simple"></i> Download the merged XML
            </button>
        </div>` : ""}
        <div class="mt-6 flex flex-wrap items-center justify-end gap-2">
            <button class="inline-flex h-9 items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent"
                    data-click="${page.on(function () { self.downloadResults(); })}">
                <i class="ph ph-microsoft-excel-logo"></i> Download results in Excel (${Frp.n0((self.shown().messages || []).length)} messages)
            </button>
        </div>
        ${self.renderBsp()}
        <div class="mt-3">${C.xmlValidationResult(self.shown())}</div>
        ${self.workbook && self.result.isValid && self.canAttach() ? html`<div class="mt-4 flex flex-wrap items-center gap-3 rounded-app border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm">
            <i class="ph ph-check-circle text-lg text-emerald-700" aria-hidden="true"></i>
            <span class="min-w-[12rem] flex-1 text-ink">${self.workbook.name} passed. Use the XML built from it as the submission file for review?</span>
            <button class="inline-flex h-9 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50"
                    ${Frp.attr("disabled", busy)} data-click="${page.on(function () { return self.attachWorkbook(onChanged); })}">
                ${self.attaching ? spinnerWhite : html`<i class="ph ph-paperclip"></i>`}
                Use as the submission XML
            </button>
        </div>` : ""}` : ""}
</div>`;
    };

    var Validate = Frp.page(function (app, query) {
        Frp.Page.call(this, app);
        this.projectQuery = query.get("project");
        this.projects = null;
        this.selected = null;
        this.error = null;
        this.canCreate = Frp.can(P.ProjectCreate);
        this.runner = new Runner(this);
    }, {
        title: function () { return "Validate · FRP Mapper"; },

        init: function () {
            var self = this;
            return Frp.api.get("projects").then(function (projects) {
                self.projects = projects;
                self.selected = projects.filter(function (p) { return p.id === self.projectQuery; })[0] || (projects.length === 1 ? projects[0] : null);
            }, function (error) {
                self.error = error.unreachable ? Frp.unreachable() : Frp.messageOf(error);
            });
        },

        select: function (id) {
            var self = this;
            self.selected = (self.projects || []).filter(function (p) { return p.id === id; })[0] || null;
            // Keep the choice in the address, so the page can be bookmarked or reloaded.
            var url = new URL(location.href);
            if (self.selected) {
                url.searchParams.set("project", self.selected.id);
            } else {
                url.searchParams.delete("project");
            }

            history.replaceState(null, "", url.href);
            self.update();
        },

        close: function () {
            Frp.Page.prototype.close.call(this);
            this.runner.end();
            this.runner.stopBsp();
        },

        render: function () {
            var self = this;
            var body;
            if (self.error) {
                body = html`<div class="mt-8">${C.notice("Error", null, self.error)}</div>`;
            } else if (!self.projects) {
                body = C.pageLoading("Loading the projects");
            } else if (!self.projects.length) {
                body = html`<div class="mt-8 max-w-prose rounded-app border border-line bg-surface p-6 text-sm leading-6 text-muted">
            <p class="font-semibold text-ink">No projects yet</p>
            <p class="mt-1">Files are validated against a project's XSD and specification, so a project is needed first.</p>
            ${self.canCreate ? html`<a class="mt-4 inline-flex h-10 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover" href="projects/new">
                <i class="ph ph-plus-circle"></i> New project
            </a>` : ""}
        </div>`;
            } else {
                var selected = self.selected;
                if (selected) {
                    self.runner.forProject(selected.id, selected.status);
                }

                body = html`<div class="mt-8 max-w-5xl space-y-8">
            <div>
                <label class="block text-sm font-semibold text-ink" for="validateProject">Project</label>
                <p class="mt-1 max-w-prose text-sm text-muted">The files are checked against this project's XSD and BSP specification.</p>
                <select autocomplete="off" id="validateProject" class="mt-2 h-11 w-full max-w-xl rounded-app border border-line bg-surface px-3 text-sm outline-none transition hover:border-slate-300 focus:border-accent"
                        data-change="${self.on(function (e) { self.select(e.target.value); })}">
                    <option value=""${Frp.attr("selected", !selected)}>Choose a project…</option>
                    ${self.projects.map(function (project) {
                        return html`<option value="${project.id}"${Frp.attr("selected", selected && selected.id === project.id)}>${project.name} · ${project.rootElement || "report"} · updated ${Frp.date(project.updatedAt, true)}</option>`;
                    })}
                </select>
            </div>
            ${selected ? html`<div class="flex flex-wrap items-center gap-x-4 gap-y-2 rounded-app border border-line bg-surface px-5 py-4 text-sm">
                <span class="font-semibold text-ink">${selected.name}</span>
                ${C.statusBadge(selected.status)}
                <span class="text-muted">${selected.rootElement || ""}${selected.hasSpecification ? " · with BSP specification" : " · no BSP specification (XSD only)"}</span>
                <a class="ml-auto inline-flex items-center gap-1.5 font-semibold text-accent transition hover:text-accent-hover" href="${"projects/" + selected.id}">
                    Open project <i class="ph ph-arrow-right"></i>
                </a>
            </div>
            ${self.runner.render(function (updated) {
                if (self.selected && self.selected.id === updated.id) {
                    self.selected.status = updated.workflow.status;
                    self.selected.updatedAt = updated.updatedAt;
                    self.runner.status = updated.workflow.status;
                }
            })}` : ""}
        </div>`;
            }

            return html`<div class="px-6 py-8 lg:px-10 lg:py-10">
    <header class="border-b border-line pb-8">
        <h1 class="font-display text-3xl font-bold tracking-tight text-ink">Validate</h1>
        <p class="mt-2 max-w-prose text-base leading-7 text-muted">
            Check a filled Excel template or an XML file against a project's XSD and BSP specification, at any time and
            whatever the project's status. Validating never changes the project.
        </p>
    </header>
    ${body}
</div>`;
        }
    });

    Frp.routes.push({ pattern: /^validate$/, permission: P.ProjectRead, create: function (app, match, query) { return new Validate(app, query); } });
})();
