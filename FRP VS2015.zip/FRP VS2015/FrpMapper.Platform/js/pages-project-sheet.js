// The Sheet view of a project's Mappings tab: a sheet of the Excel input template drawn as Excel shows it, with each
// mapped cell marked. The mappings FRP Mapper made when the project was created are the starting point; a Maker selects a
// cell and maps, moves or removes an XSD field there, or goes back to the app's mapping for a cell or a whole sheet.
// Changes are made to the same rows as the Table view and saved with its Save button (PUT projects/{id}/mappings).
(function () {
    "use strict";

    var Frp = window.Frp;
    var html = Frp.html;
    var C = Frp.components;
    var esc = Frp.esc;

    var maxRows = 2000;     // as TemplateGridReader.MaxRows
    var maxColumns = 200;   // as TemplateGridReader.MaxColumns
    var fieldListSize = 60; // unmapped fields listed beside the grid
    var moreItemRows = 5;   // empty rows shown under a list's row as where more items are typed
    var colour = /^#[0-9A-F]{6}$/;
    var cellAddress = /^([A-Z]{1,3})([1-9][0-9]{0,6})$/;

    function lower(text) {
        return (text || "").toLowerCase();
    }

    function columnName(index) {
        var name = "";
        while (index > 0) {
            var remainder = (index - 1) % 26;
            name = String.fromCharCode(65 + remainder) + name;
            index = Math.floor((index - 1) / 26);
        }

        return name;
    }

    function columnIndex(letters) {
        var index = 0;
        for (var i = 0; i < letters.length; i++) {
            index = index * 26 + letters.charCodeAt(i) - 64;
        }

        return index;
    }

    /** { row, column } of "E9" (null when it is not a cell address). */
    function parseCell(address) {
        var m = cellAddress.exec((address || "").trim().toUpperCase());
        return m ? { row: parseInt(m[2], 10), column: columnIndex(m[1]) } : null;
    }

    function cellKey(sheet, address) {
        return lower(sheet) + "!" + (address || "").toUpperCase();
    }

    /** The XSD sheet of a path: /FRP/FRP_1/R0010/... gives FRP_1. */
    function xsdSheet(path) {
        var parts = (path || "").split("/");
        return parts.length > 2 ? parts[2] : "";
    }

    function lastPart(path) {
        var parts = (path || "").split("/");
        return parts[parts.length - 1] || path || "";
    }

    /** The value a mapped cell holds: its own; "" when its sample value was removed; the sample value when it has none. */
    function valueOf(row, node) {
        return row.defaultValue === null || row.defaultValue === undefined ? (node ? node.testValue || "" : "") : row.defaultValue;
    }

    /** "sample" (still the sample value), "empty" (removed, nothing entered) or "entered". */
    function valueKind(row, node) {
        var value = valueOf(row, node);
        return value === "" ? "empty" : node && value === node.testValue ? "sample" : "entered";
    }

    function isManual(source) {
        return !source || source === "Manual";
    }

    /** Excel column width (characters) in pixels, as Excel draws Calibri 11. */
    function pixels(width) {
        return Math.max(24, Math.min(480, Math.round(width * 7 + 5)));
    }

    function plural(n, one, many) {
        return n === 1 ? one : many;
    }

    /**
     * The data validation of an XSD field in plain words: what Excel's data validation in the downloaded template and
     * the app's own check both apply. { summary, lines: [{ label, text }], values: allowed codes }.
     */
    function rules(node) {
        var v = node.validation || {};
        var values = v.enumerations || [];
        var lines = [];
        var summary = [];
        var type;
        var fd = v.fractionDigits;
        if (values.length) {
            type = "A code from the list (" + Frp.n0(values.length) + " allowed " + plural(values.length, "value", "values") + ")";
        } else {
            switch (node.dataType) {
                case "integer": type = "Whole number"; break;
                case "decimal": type = fd === 0 ? "Whole number" : fd ? "Number, up to " + fd + " " + plural(fd, "decimal", "decimals") : "Number"; break;
                case "date": type = "Date (YYYY-MM-DD)"; break;
                case "dateTime": type = "Date and time (YYYY-MM-DDThh:mm:ss)"; break;
                case "gYearMonth": type = "Year and month (YYYY-MM)"; break;
                case "gYear": type = "Year (YYYY)"; break;
                case "boolean": type = "true or false"; break;
                default: type = "Text";
            }
        }

        lines.push({ label: "Type", text: type });
        summary.push(type);
        lines.push({ label: "Required", text: node.isRequired ? "Yes: it must have a value" : "No: it can be left blank" });
        if (v.fixedValue) {
            lines.push({ label: "Must be", text: v.fixedValue });
            summary.push("must be " + v.fixedValue);
        }

        if (v.totalDigits) {
            var digits = "at most " + v.totalDigits + " " + plural(v.totalDigits, "digit", "digits") + " in all";
            lines.push({ label: "Digits", text: digits });
            summary.push(digits);
        }

        var low = v.minInclusive !== null && v.minInclusive !== undefined ? { value: v.minInclusive, word: "at least" }
            : v.minExclusive !== null && v.minExclusive !== undefined ? { value: v.minExclusive, word: "more than" } : null;
        var high = v.maxInclusive !== null && v.maxInclusive !== undefined ? { value: v.maxInclusive, word: "at most" }
            : v.maxExclusive !== null && v.maxExclusive !== undefined ? { value: v.maxExclusive, word: "less than" } : null;
        if (low || high) {
            var range = low && high && low.word === "at least" && high.word === "at most" ? "from " + low.value + " to " + high.value
                : [low ? low.word + " " + low.value : "", high ? high.word + " " + high.value : ""].filter(Boolean).join(" and ");
            lines.push({ label: "Range", text: range });
            summary.push(range);
        }

        var pattern = (v.pattern || "").trim();
        var exactDigits = /^(?:\\d|\[0-9\])\{(\d+)\}$/.exec(pattern);
        var length = null;
        if (exactDigits) {
            length = "exactly " + exactDigits[1] + " digits";
        } else if (v.length !== null && v.length !== undefined) {
            length = "exactly " + v.length + " " + plural(v.length, "character", "characters");
        } else if (v.minLength && v.maxLength) {
            length = v.minLength === v.maxLength ? "exactly " + v.maxLength + " characters" : v.minLength + " to " + v.maxLength + " characters";
        } else if (v.maxLength) {
            length = "up to " + v.maxLength + " " + plural(v.maxLength, "character", "characters");
        } else if (v.minLength) {
            length = "at least " + v.minLength + " " + plural(v.minLength, "character", "characters");
        }

        if (length) {
            lines.push({ label: "Length", text: length });
            summary.push(length);
        }

        // A number's pattern only restates its digits and decimals (BSP writes both), so it is shown for text only.
        if (pattern && !exactDigits && node.dataType !== "decimal" && node.dataType !== "integer") {
            var text = pattern === "[^\\s].*" || pattern === "\\S.*" ? "must not start with a space" : "must match " + pattern;
            lines.push({ label: "Format", text: text });
            summary.push(text);
        }

        return { summary: summary.join(", "), lines: lines, values: values };
    }

    // The Sheet view on screen (drag and drop and the Escape key are handled once, for the document).
    var active = null;

    // ---------- the view ----------

    var Sheet = Frp.projectTabs.MappingSheet = function (mappings) {
        this.mappings = mappings;  // the Mappings tab: its rows, dirty flag, value checks and Save
        this.page = mappings.page;
        this.projectId = null;
        this.sheet = "";
        this.grids = {};           // sheet name (lower case) -> grid, or { error }
        this.suggested = null;     // the app's mappings: { list, byCell, byPath }
        this.suggestedError = null;
        this.selected = null;      // cell address on this sheet
        this.show = "field";       // what mapped cells show: "field" or "value"
        this.goTo = "";
        this.picked = "";          // the XSD path typed or picked for the selected cell
        this.confirmReset = false;
        this.message = null;
        this.messageKind = "Info";
        this.markupFor = null;
        this.markup = "";
        this.maximized = false;     // full screen
        this.paletteFilter = "";
        this.paletteAll = false;    // false: only fields no cell holds
        this.showAllValues = false; // the full list of allowed codes of the selected field
        this.dragging = null;       // the XSD path being dragged
        this.help = readHelp();
        this.editing = null;        // the cell being typed in: { address, path, draft, error, checking }
        this.pending = {};          // typed values waiting to be saved, by XSD path (lower case)
        this.saving = false;
        this.saveState = null;      // "saving", "saved" or "error"
        this.saveError = null;
        this.savedAt = null;
        this.nodesVersion = null;   // the version the value checks use (the XSD fields do not change when values are saved)
    };

    function readHelp() {
        try {
            return window.localStorage.getItem("frp.sheetHelp") !== "hidden";
        } catch (e) {
            return true;
        }
    }

    function writeHelp(show) {
        try {
            window.localStorage.setItem("frp.sheetHelp", show ? "shown" : "hidden");
        } catch (e) {
            // the help shows again next time
        }
    }

    /** Called by each render: loads the app's mappings once per project and the shown sheet once. */
    Sheet.prototype.prepare = function () {
        var self = this;
        var project = self.page.project;
        if (self.projectId !== project.id) {
            self.projectId = project.id;
            self.nodesVersion = project.updatedAt;
            self.editing = null;
            self.pending = {};
            self.saveState = null;
            self.grids = {};
            self.suggested = null;
            self.suggestedError = null;
            self.selected = null;
            self.sheet = "";
            Frp.api.get("projects/" + project.id + "/mappings/suggested", null, { quiet: true }).then(function (answer) {
                var byCell = {};
                var byPath = {};
                answer.mappings.forEach(function (m) {
                    byCell[cellKey(m.sheetName, m.cellAddress)] = m;
                    byPath[lower(m.schemaPath)] = m;
                });
                self.suggested = { list: answer.mappings, byCell: byCell, byPath: byPath };
            }, function (error) {
                self.suggestedError = Frp.messageOf(error);
            }).then(function () { self.page.update(); });
        }

        if (project.updatedAt !== self.versionSeen) {
            // Value checks use the XSD fields of this version; a save of typed values does not change them.
            self.versionSeen = project.updatedAt;
            if (!self.ownVersions || !self.ownVersions[project.updatedAt]) {
                self.nodesVersion = project.updatedAt;
            }
        }

        var sheets = self.sheetNames();
        if (!self.sheet || !sheets.some(function (s) { return s === self.sheet; })) {
            // The first sheet that has mappings; else the first sheet.
            var counts = self.countsBySheet();
            self.sheet = sheets.filter(function (s) { return counts[lower(s)] > 0; })[0] || sheets[0] || "";
        }

        if (self.sheet && !self.grids[lower(self.sheet)]) {
            var name = self.sheet;
            self.grids[lower(name)] = { loading: true };
            Frp.api.get("projects/" + project.id + "/template/sheet", { name: name }).then(function (grid) {
                self.grids[lower(name)] = grid;
            }, function (error) {
                self.grids[lower(name)] = { error: Frp.messageOf(error) };
            }).then(function () { self.page.update(); });
        }
    };

    Sheet.prototype.sheetNames = function () {
        var workbook = this.page.project.workbook;
        return workbook ? workbook.sheets.map(function (s) { return s.name; }) : [];
    };

    Sheet.prototype.countsBySheet = function () {
        var counts = {};
        this.mappings.rows.forEach(function (r) {
            var key = lower(r.sheetName);
            counts[key] = (counts[key] || 0) + 1;
        });
        return counts;
    };

    /** The rows mapped on the shown sheet, by cell address. */
    Sheet.prototype.rowsByCell = function () {
        var sheet = lower(this.sheet);
        var byCell = {};
        this.mappings.rows.forEach(function (r) {
            if (lower(r.sheetName) === sheet && r.cellAddress) {
                var address = r.cellAddress.trim().toUpperCase();
                (byCell[address] = byCell[address] || []).push(r);
            }
        });
        return byCell;
    };

    /** Whether a field is mapped to any cell (from the set made at the start of each render). */
    Sheet.prototype.isMapped = function (path) {
        if (!this.pathSet) {
            this.indexPaths();
        }

        return !!this.pathSet[lower(path)];
    };

    Sheet.prototype.indexPaths = function () {
        var set = {};
        this.mappings.rows.forEach(function (r) { set[lower(r.schemaPath)] = true; });
        this.pathSet = set;
    };

    /**
     * The repeating XSD element (list item, e.g. .../MAIN_I/MAIN_I_Item) a field belongs to: its nearest repeating
     * ancestor (or itself), or null for a field that occurs once.
     */
    Sheet.prototype.itemOf = function (path) {
        var m = this.mappings;
        var key = lower(path);
        this.items = this.items && this.itemsFor === this.projectId ? this.items : {};
        this.itemsFor = this.projectId;
        if (key in this.items) {
            return this.items[key];
        }

        var node = m.node(path);
        var item = null;
        if (node && node.isInRepeatingGroup) {
            for (var n = node; n; n = n.parentPath ? m.node(n.parentPath) : null) {
                if (n.isRepeating) {
                    item = n.path;
                    break;
                }
            }
        }

        this.items[key] = item;
        return item;
    };

    /**
     * The lists on the shown sheet: { item path -> { name, rows: [row numbers], columns: {column: true} } }. A list whose
     * fields share one row is a table in the downloaded template: every row typed under it is another item.
     */
    Sheet.prototype.listsOnSheet = function (byCell) {
        var self = this;
        var lists = {};
        Object.keys(byCell).forEach(function (address) {
            var at = parseCell(address);
            byCell[address].forEach(function (r) {
                var item = at ? self.itemOf(r.schemaPath) : null;
                if (!item) {
                    return;
                }

                var list = lists[item] = lists[item] || { item: item, name: lastPart(item), rows: [], columns: {} };
                if (list.rows.indexOf(at.row) < 0) {
                    list.rows.push(at.row);
                }

                list.columns[at.column] = true;
            });
        });
        return lists;
    };

    /** The one row a list's fields share on the shown sheet (excluding a field being moved), or null. */
    Sheet.prototype.listRow = function (item, exceptPath) {
        var self = this;
        var sheet = lower(self.sheet);
        var rows = [];
        self.mappings.rows.forEach(function (r) {
            var at = parseCell(r.cellAddress);
            if (at && lower(r.sheetName) === sheet && lower(r.schemaPath) !== lower(exceptPath) && self.itemOf(r.schemaPath) === item && rows.indexOf(at.row) < 0) {
                rows.push(at.row);
            }
        });
        return rows.length === 1 ? rows[0] : null;
    };

    Sheet.prototype.suggestionAt = function (address) {
        return this.suggested ? this.suggested.byCell[cellKey(this.sheet, address)] || null : null;
    };

    /**
     * How a mapped cell compares with the app's mapping: "app" (as the app mapped it), "changed" (moved here, another
     * field, or added by hand) or "removed" (the app maps a field here and the cell is empty now).
     */
    Sheet.prototype.status = function (address, rows) {
        var suggestion = this.suggestionAt(address);
        if (rows && rows.length) {
            if (this.suggested) {
                return suggestion && rows.length === 1 && lower(suggestion.schemaPath) === lower(rows[0].schemaPath) ? "app" : "changed";
            }

            return rows.every(function (r) { return !isManual(r.source); }) ? "app" : "changed";
        }

        if (suggestion) {
            return "removed"; // the app maps a field here and the cell is empty now (the field was moved or unmapped)
        }

        return null;
    };

    /** The XSD fields that belong on the shown sheet: its XSD sheet's fields, and those the app maps to it. */
    Sheet.prototype.sheetFields = function () {
        var self = this;
        var sheet = lower(self.sheet);
        var seen = {};
        var fields = [];
        self.mappings.leafPaths.forEach(function (path) {
            var suggestion = self.suggested ? self.suggested.byPath[lower(path)] : null;
            if (lower(xsdSheet(path)) === sheet || (suggestion && lower(suggestion.sheetName) === sheet)) {
                if (!seen[lower(path)]) {
                    seen[lower(path)] = true;
                    fields.push(path);
                }
            }
        });
        return fields;
    };

    // ---------- changes (the same rows the Table view shows) ----------

    /** Messages go to a toast (the app's default for what happened). */
    Sheet.prototype.say = function (kind, text) {
        // Routine notes (a field moved, a value kept) close sooner, so they do not sit over the sheet.
        return Frp.toast(kind, null, text, kind === "Info" ? { timeout: 3000 } : undefined);
    };

    /** The toast about the cell being typed in: one at a time, closed once the value is fixed or the typing cancelled. */
    Sheet.prototype.editMessage = function (text) {
        this.closeEditMessage();
        this.editToast = text ? this.say("Error", text) : null;
    };

    Sheet.prototype.closeEditMessage = function () {
        if (this.editToast) {
            this.editToast.close();
            this.editToast = null;
        }
    };

    /**
     * Maps an XSD field to a cell of the shown sheet: a field mapped elsewhere moves here, and a field already on the cell
     * is unmapped (one field per cell). Returns what happened, for the message.
     */
    Sheet.prototype.assign = function (path, address, source) {
        var m = this.mappings;
        var node = m.node(path);
        if (!node || node.dataType === "complex") {
            this.say("Error", "\"" + path + "\" is not a field of the XSD. Pick one from the list.");
            return false;
        }

        var sheet = this.sheet;
        var problem = this.dropProblem(node.path, address);
        if (problem) {
            this.say("Error", problem);
            return false;
        }

        var notes = [];
        var existing = m.rows.filter(function (r) { return lower(r.schemaPath) === lower(node.path); })[0] || null;
        var occupants = m.rows.filter(function (r) {
            return r !== existing && lower(r.sheetName) === lower(sheet) && (r.cellAddress || "").trim().toUpperCase() === address;
        });
        occupants.forEach(function (r) {
            m.rows.splice(m.rows.indexOf(r), 1);
            notes.push(lastPart(r.schemaPath) + " is no longer mapped");
        });

        var row = existing;
        if (row) {
            if (lower(row.sheetName) !== lower(sheet) || (row.cellAddress || "").trim().toUpperCase() !== address) {
                notes.unshift("moved from " + row.sheetName + "!" + row.cellAddress);
            }

            row.sheetName = sheet;
            row.cellAddress = address;
            row.source = source;
        } else {
            row = { id: Frp.newId(), sheetName: sheet, cellAddress: address, schemaPath: node.path, defaultValue: node.testValue, source: source, key: "m" + (m.nextId++) };
            m.rows.unshift(row);
        }

        m.dirty = true;
        m.requestChecks([row]);
        this.say("Info", lastPart(node.path) + " is mapped to " + sheet + "!" + address + (notes.length ? " (" + notes.join("; ") + ")" : "") + ". Save to keep it.");
        return true;
    };

    Sheet.prototype.unmap = function (address) {
        var m = this.mappings;
        var sheet = lower(this.sheet);
        var removed = m.rows.filter(function (r) { return lower(r.sheetName) === sheet && (r.cellAddress || "").trim().toUpperCase() === address; });
        removed.forEach(function (r) { m.rows.splice(m.rows.indexOf(r), 1); });
        if (removed.length) {
            m.dirty = true;
            this.say("Info", removed.map(function (r) { return lastPart(r.schemaPath); }).join(", ") + " removed from " + this.sheet + "!" + address + ". Save to keep it.");
        }
    };

    /** Why a field cannot go to a cell of the shown sheet, or null when it can. */
    Sheet.prototype.dropProblem = function (path, address) {
        var target = parseCell(address);
        var item = this.itemOf(path);
        var itemRow = item ? this.listRow(item, path) : null;
        if (item && itemRow !== null && target && target.row !== itemRow) {
            // Excel exports a repeating element only through a list table, and the table needs the item's fields in one row.
            return lastPart(path) + " is a column of the list " + lastPart(item) + ", whose other fields are on row " + itemRow
                + " of " + this.sheet + ". Map it to a cell on row " + itemRow + ": the downloaded template makes that row an Excel table, and every row typed under it becomes another "
                + lastPart(item) + ". On row " + target.row + " the list could not be built.";
        }

        return null;
    };

    /** The app's mapping for the selected cell: its field goes back here (and leaves any other cell). */
    Sheet.prototype.restoreCell = function (address) {
        var suggestion = this.suggestionAt(address);
        if (suggestion) {
            this.assign(suggestion.schemaPath, address, suggestion.source);
        } else {
            this.unmap(address);
        }
    };

    /** The app's mappings for the whole sheet; values typed for those fields are kept. */
    Sheet.prototype.restoreSheet = function () {
        var self = this;
        var m = self.mappings;
        var sheet = lower(self.sheet);
        if (!self.suggested) {
            return;
        }

        var wanted = self.suggested.list.filter(function (s) { return lower(s.sheetName) === sheet; });
        var wantedPaths = {};
        wanted.forEach(function (s) { wantedPaths[lower(s.schemaPath)] = true; });
        var keep = {};
        m.rows.forEach(function (r) {
            if (wantedPaths[lower(r.schemaPath)] && !keep[lower(r.schemaPath)]) {
                keep[lower(r.schemaPath)] = r;
            }
        });
        var before = m.rows.length;
        m.rows = m.rows.filter(function (r) { return lower(r.sheetName) !== sheet && !wantedPaths[lower(r.schemaPath)]; });
        var added = wanted.map(function (s) {
            var old = keep[lower(s.schemaPath)];
            var node = m.node(s.schemaPath);
            return {
                id: old ? old.id : Frp.newId(),
                sheetName: s.sheetName,
                cellAddress: s.cellAddress,
                schemaPath: s.schemaPath,
                defaultValue: old ? old.defaultValue : node ? node.testValue : null,
                source: s.source,
                key: old ? old.key : "m" + (m.nextId++)
            };
        });
        m.rows = added.concat(m.rows);
        m.dirty = true;
        m.requestChecks(added);
        self.confirmReset = false;
        self.say("Info", self.sheet + " has the app's mapping again: " + Frp.n0(added.length) + " fields"
            + (before - m.rows.length + added.length !== added.length ? " (other mappings on this sheet removed)" : "") + ". Save to keep it.");
    };

    // ---------- typing values into cells: checked first, then saved automatically ----------

    /** Starts typing in a mapped cell (double-click, Enter, F2 or just typing); initial replaces the value. */
    Sheet.prototype.startEdit = function (address, initial) {
        if (!this.page.canEdit()) {
            return;
        }

        var rows = this.rowsByCell()[address];
        if (!rows || !rows.length) {
            this.select(address);
            this.say("Info", "No XSD field is mapped to " + this.sheet + "!" + address + ", so there is nothing to fill in. Drag a field onto the cell first.");
            this.page.update();
            return;
        }

        var row = rows[0];
        var node = this.mappings.node(row.schemaPath);
        this.select(address);
        this.show = "value"; // what is typed is seen on the sheet
        this.message = null;
        this.editing = {
            address: address,
            path: row.schemaPath,
            draft: initial !== undefined ? initial : valueOf(row, node),
            error: null,
            checking: false
        };
        this.page.update();
        focusEditor(initial !== undefined);
    };

    Sheet.prototype.cancelEdit = function () {
        this.closeEditMessage();
        this.editing = null;
        this.message = null;
        this.page.update();
        focusGrid();
    };

    /**
     * Checks the typed value against the field's XSD rules (the Platform's check, the same rules the API applies). A value
     * that breaks them is not taken: the cell stays open and red with the reason. A good value is put in the cell and
     * saved (PUT projects/{id}/values, which checks it again).
     */
    Sheet.prototype.commitEdit = function (dRow, dColumn) {
        var self = this;
        var editing = self.editing;
        var m = self.mappings;
        if (!editing || editing.checking) {
            return;
        }

        var row = m.rows.filter(function (r) { return lower(r.schemaPath) === lower(editing.path); })[0];
        if (!row) {
            self.editing = null;
            self.page.update();
            return;
        }

        var value = editing.draft;
        var node = m.node(row.schemaPath);
        var current = valueOf(row, node);
        var next = function () {
            self.closeEditMessage();
            self.editing = null;
            if (dRow || dColumn) {
                self.move(dRow, dColumn);
            }

            self.page.update();
            reveal(self.selected);
            focusGrid();
        };
        if (value === current && !editing.error) {
            next();
            return;
        }

        if (!value.trim()) {
            // An empty cell: nothing to check (a required field is reported by validation until it has a value).
            row.defaultValue = "";
            self.queueValue(row, "");
            next();
            return;
        }

        editing.checking = true;
        self.page.update();
        Frp.api.util("value-errors", { projectId: self.projectId, version: self.nodesVersion, items: [[row.schemaPath, value]] }).then(function (answer) {
            var errors = (answer && answer.errors && answer.errors["0"]) || [];
            editing.checking = false;
            if (self.editing !== editing) {
                return;
            }

            if (errors.length) {
                editing.error = errors[0];
                self.editMessage(lastPart(row.schemaPath) + " (" + self.sheet + "!" + editing.address + ") was not saved: " + errors[0] + " Correct the value, or press Esc to keep the old one.");
                self.page.update();
                focusEditor(false);
                return;
            }

            row.defaultValue = value;
            m.checks[row.schemaPath + "\u001f" + value] = [];
            self.message = null;
            self.queueValue(row, value);
            next();
        }, function (error) {
            editing.checking = false;
            editing.error = "The value could not be checked: " + Frp.messageOf(error);
            self.editMessage(editing.error);
            self.page.update();
            focusEditor(false);
        });
    };

    /** Empties a cell ("") or puts its sample value back (null); saved at once. */
    Sheet.prototype.setValue = function (address, value) {
        var rows = this.rowsByCell()[address];
        if (!rows || !rows.length || !this.page.canEdit()) {
            return;
        }

        var row = rows[0];
        var node = this.mappings.node(row.schemaPath);
        row.defaultValue = value === null ? (node ? node.testValue : null) : value;
        this.queueValue(row, value);
        this.page.update();
    };

    /** A checked value is saved at once (values typed while a save runs go with the next one). */
    Sheet.prototype.queueValue = function (row, value) {
        var saved = this.page.project.mappings.some(function (m) { return lower(m.schemaPath) === lower(row.schemaPath); });
        if (!saved) {
            // The field's mapping is new and not saved yet; the value goes with the mapping changes.
            this.mappings.dirty = true;
            this.say("Info", "The value is kept with your unsaved mapping changes; press Save to keep both.");
            return;
        }

        this.pending[lower(row.schemaPath)] = { schemaPath: row.schemaPath, value: value };
        this.flush();
    };

    Sheet.prototype.flush = function () {
        var self = this;
        var page = self.page;
        var m = self.mappings;
        var keys = Object.keys(self.pending);
        if (self.saving || !keys.length) {
            return;
        }

        var batch = keys.map(function (k) { return self.pending[k]; });
        self.pending = {};
        self.saving = true;
        self.saveState = "saving";
        self.saveError = null;
        page.update();
        Frp.api.put("projects/" + page.project.id + "/values", { values: batch }, { quiet: true }).then(function (saved) {
            self.saving = false;
            self.saveState = "saved";
            self.savedAt = new Date();
            self.ownVersions = self.ownVersions || {};
            self.ownVersions[saved.updatedAt] = true;
            // Keep the rows on screen (they may hold unsaved mapping changes); take the saved project's check results.
            m.loaded = saved;
            m.validation = saved.validation;
            m.issues = (saved.issues || []).slice();
            page.changed(saved);
            self.flush();
        }, function (error) {
            self.saving = false;
            self.saveState = "error";
            var refused = error && error.status === 400 && error.details && error.details.errors;
            if (refused) {
                refused.forEach(function (e) {
                    var typed = batch.filter(function (b) { return lower(b.schemaPath) === lower(e.schemaPath); })[0];
                    if (typed) {
                        m.checks[typed.schemaPath + "\u001f" + typed.value] = e.errors;
                    }
                });
                self.saveError = refused.map(function (e) { return lastPart(e.schemaPath) + ": " + e.errors[0]; }).join(" ");
            } else {
                // Not saved (e.g. the connection dropped): kept for Retry, newer typing wins.
                batch.forEach(function (b) {
                    if (!self.pending[lower(b.schemaPath)]) {
                        self.pending[lower(b.schemaPath)] = b;
                    }
                });
                self.saveError = Frp.messageOf(error);
            }

            page.update();
        });
    };

    /** Where the typed values stand: saving, saved, or not saved (with Retry). */
    Sheet.prototype.renderSaveState = function () {
        var self = this;
        var page = self.page;
        var waiting = Object.keys(self.pending).length;
        if (self.saveState === "saving") {
            return html`<span class="inline-flex h-8 items-center gap-1.5 rounded-full bg-canvas px-3 text-xs text-muted" role="status"><i class="ph ph-spinner animate-spin"></i> Saving entries…</span>`;
        }

        if (self.saveState === "error") {
            return html`<span class="inline-flex min-h-8 items-center gap-2 rounded-full bg-red-50 px-3 py-1 text-xs text-red-800" role="alert">
                <i class="ph ph-warning-circle"></i> Not saved: ${self.saveError}
                ${waiting ? html`<button class="font-semibold underline" data-click="${page.on(function () { self.flush(); })}">Retry</button>` : ""}
            </span>`;
        }

        if (self.saveState === "saved") {
            var at = self.savedAt;
            return html`<span class="inline-flex h-8 items-center gap-1.5 rounded-full bg-emerald-50 px-3 text-xs text-emerald-800" role="status"><i class="ph ph-check-circle"></i> Entries saved ${("0" + at.getHours()).slice(-2) + ":" + ("0" + at.getMinutes()).slice(-2)}</span>`;
        }

        return page.canEdit() ? html`<span class="inline-flex h-8 items-center gap-1.5 text-xs text-subtle"><i class="ph ph-pencil-simple"></i> Double-click a blue cell or start typing to enter a value</span>` : "";
    };

    Sheet.prototype.select = function (address) {
        this.selected = address;
        this.picked = "";
        var rows = address ? this.rowsByCell()[address] : null;
        if (rows && rows.length) {
            this.picked = rows[0].schemaPath;
        }
    };

    /** Moves the selection with the arrow keys, as in Excel. */
    Sheet.prototype.move = function (dRow, dColumn) {
        var current = parseCell(this.selected) || { row: 1, column: 1 };
        var grid = this.grids[lower(this.sheet)];
        var hiddenRows = {};
        var hiddenColumns = {};
        (grid && grid.hiddenRows || []).forEach(function (r) { hiddenRows[r] = true; });
        (grid && grid.columns || []).forEach(function (c) { if (c.hidden) { hiddenColumns[c.index] = true; } });
        var row = current.row;
        var column = current.column;
        do { row += dRow; } while (dRow && hiddenRows[row] && row > 1 && row < maxRows);
        do { column += dColumn; } while (dColumn && hiddenColumns[column] && column > 1 && column < maxColumns);
        row = Math.max(1, Math.min(maxRows, row));
        column = Math.max(1, Math.min(maxColumns, column));
        this.select(columnName(column) + row);
    };

    /** "Go to": a cell (E9), or an XSD field (R0010C0010 or part of a path), on this sheet first, then on the others. */
    Sheet.prototype.find = function (text) {
        var self = this;
        var wanted = (text || "").trim();
        if (!wanted) {
            return;
        }

        if (parseCell(wanted)) {
            self.select(wanted.toUpperCase());
            self.message = null;
            return;
        }

        var low = lower(wanted);
        var rows = self.mappings.rows;
        var match = function (r) { return lower(lastPart(r.schemaPath)) === low; };
        var loose = function (r) { return lower(r.schemaPath).indexOf(low) >= 0; };
        var here = function (r) { return lower(r.sheetName) === lower(self.sheet); };
        var found = rows.filter(function (r) { return here(r) && match(r); })[0]
            || rows.filter(match)[0]
            || rows.filter(function (r) { return here(r) && loose(r); })[0]
            || rows.filter(loose)[0];
        if (!found) {
            self.say("Warning", "No mapped cell or XSD field matches \"" + wanted + "\".");
            return;
        }

        if (!self.sheetNames().some(function (s) { return lower(s) === lower(found.sheetName); })) {
            self.say("Warning", lastPart(found.schemaPath) + " is mapped to " + found.sheetName + "!" + found.cellAddress + ", a sheet the template does not have. See the Table view.");
            return;
        }

        self.sheet = self.sheetNames().filter(function (s) { return lower(s) === lower(found.sheetName); })[0];
        self.select(found.cellAddress.trim().toUpperCase());
        self.message = null;
    };

    // ---------- the grid (built as one string; the page keeps it until the sheet, its mappings or the selection change) ----------

    Sheet.prototype.gridMarkup = function (grid, byCell) {
        var self = this;
        var m = self.mappings;
        var canDrag = self.page.canEdit();
        var cells = {};
        grid.cells.forEach(function (c) { cells[c.address] = c; });

        var lastRow = Math.max(grid.maxRow, 20);
        var lastColumn = Math.max(grid.maxColumn, 8);
        var mappedRows = {};
        var mappedColumns = {};
        Object.keys(byCell).concat(self.selected ? [self.selected] : []).forEach(function (address) {
            var at = parseCell(address);
            if (at) {
                lastRow = Math.max(lastRow, at.row);
                lastColumn = Math.max(lastColumn, at.column);
                mappedRows[at.row] = true;
                mappedColumns[at.column] = true;
            }
        });
        lastRow = Math.min(lastRow + 2, maxRows);
        lastColumn = Math.min(lastColumn + 1, maxColumns);

        var widths = {};
        var hiddenColumns = {};
        grid.columns.forEach(function (c) {
            widths[c.index] = c.width;
            if (c.hidden) {
                hiddenColumns[c.index] = true;
            }
        });
        var hiddenRows = {};
        grid.hiddenRows.forEach(function (r) { hiddenRows[r] = true; });

        // Hidden rows and columns stay hidden, unless a mapped cell is in them.
        var columns = [];
        for (var c = 1; c <= lastColumn; c++) {
            if (!hiddenColumns[c] || mappedColumns[c]) {
                columns.push(c);
            }
        }

        var rows = [];
        for (var r = 1; r <= lastRow; r++) {
            if (!hiddenRows[r] || mappedRows[r]) {
                rows.push(r);
            }
        }

        var shownRow = {};
        rows.forEach(function (row) { shownRow[row] = true; });
        var shownColumn = {};
        columns.forEach(function (column) { shownColumn[column] = true; });

        // Merged ranges: the first cell spans the shown rows and columns of the range; the others are not drawn.
        var spans = {};
        var covered = {};
        grid.merges.forEach(function (range) {
            var corners = range.split(":");
            var from = parseCell(corners[0]);
            var to = parseCell(corners[1]);
            if (!from || !to || !shownRow[from.row] || !shownColumn[from.column]) {
                return;
            }

            var rowSpan = 0;
            var columnSpan = 0;
            for (var rr = from.row; rr <= to.row; rr++) {
                if (shownRow[rr]) {
                    rowSpan++;
                }
            }

            for (var cc = from.column; cc <= to.column; cc++) {
                if (shownColumn[cc]) {
                    columnSpan++;
                }
            }

            for (rr = from.row; rr <= to.row; rr++) {
                for (cc = from.column; cc <= to.column; cc++) {
                    if (rr !== from.row || cc !== from.column) {
                        covered[rr + "," + cc] = true;
                    }
                }
            }

            spans[from.row + "," + from.column] = { rows: rowSpan, columns: columnSpan };
        });

        var tableWidth = 44;
        var pixelWidth = {};
        var out = [];
        out.push("<colgroup><col style=\"width:44px\">");
        columns.forEach(function (column) {
            var width = pixels(widths[column] !== undefined ? widths[column] : grid.defaultColumnWidth || 8.43);
            tableWidth += width;
            pixelWidth[column] = width;
            out.push("<col style=\"width:" + width + "px\">");
        });
        out.push("</colgroup><thead><tr><th class=\"sticky left-0 top-0 z-30 border border-slate-300 bg-slate-100\"></th>");
        columns.forEach(function (column) {
            out.push("<th scope=\"col\" class=\"sticky top-0 z-20 h-6 border border-slate-300 bg-slate-100 text-center font-normal "
                + (hiddenColumns[column] ? "text-amber-700" : "text-slate-600") + "\"" + (hiddenColumns[column] ? " title=\"Hidden in the template\"" : "") + ">" + columnName(column) + "</th>");
        });
        out.push("</tr></thead><tbody>");

        var hasContent = function (row, column) {
            var address = columnName(column) + row;
            return (cells[address] && cells[address].text) || byCell[address] || covered[row + "," + column];
        };

        // Lists whose fields share one row: that row repeats down. The empty rows under it (up to moreItemRows) are shown
        // as where more items are typed; a row that already holds something ends the band (in Excel, insert table rows).
        var listCells = {};
        var moreCells = {};
        var lists = self.listsOnSheet(byCell);
        Object.keys(lists).forEach(function (item) {
            var list = lists[item];
            if (list.rows.length !== 1) {
                return;
            }

            var listColumns = Object.keys(list.columns).map(Number);
            listColumns.forEach(function (column) { listCells[columnName(column) + list.rows[0]] = list.name; });
            for (var below = list.rows[0] + 1; below <= Math.min(list.rows[0] + moreItemRows, lastRow); below++) {
                if (listColumns.some(function (column) { return hasContent(below, column); })) {
                    break;
                }

                listColumns.forEach(function (column) { moreCells[columnName(column) + below] = list.name; });
            }
        });

        rows.forEach(function (row) {
            out.push("<tr><th scope=\"row\" class=\"sticky left-0 z-10 h-6 border border-slate-300 bg-slate-100 px-1 text-right font-normal "
                + (hiddenRows[row] ? "text-amber-700" : "text-slate-600") + "\"" + (hiddenRows[row] ? " title=\"Hidden in the template\"" : "") + ">" + row + "</th>");
            columns.forEach(function (column, index) {
                if (covered[row + "," + column]) {
                    return;
                }

                var address = columnName(column) + row;
                var cell = cells[address];
                var span = spans[row + "," + column];
                var mapped = byCell[address];
                var status = self.status(address, mapped);
                var next = columns[index + (span ? span.columns : 1)];
                var clip = next !== undefined && hasContent(row, next); // as Excel: text runs into empty cells only
                var classes = ["h-6 border border-slate-200 px-1 align-middle"];
                var style = "";
                var title = "";
                var content = "";
                var overflowWidth = 0;
                var editor = self.editing && self.editing.address === address ? self.editing : null;
                if (editor) {
                    classes.push("relative p-0 ring-2 ring-inset " + (editor.error ? "ring-red-500 bg-red-50" : "ring-accent bg-white"));
                    title = editor.error || "Enter to save and go down · Tab to go right · Esc to cancel";
                } else if (mapped) {
                    var first = mapped[0];
                    var node = m.node(first.schemaPath);
                    var errors = m.rowErrors(first);
                    var value = valueOf(first, node);
                    var kind = valueKind(first, node);
                    content = (listCells[address] ? "\u2193 " : "") + (self.show === "value" ? (kind === "empty" && node && node.isRequired ? "required" : value) : lastPart(first.schemaPath) + (mapped.length > 1 ? " +" + (mapped.length - 1) : ""));
                    if (self.show === "value" && kind !== "entered") {
                        classes.push("italic"); // sample values and empty cells look different from the bank's own figures
                        classes.push(kind === "empty" ? "!text-slate-400" : "!text-slate-500");
                    }
                    classes.push((canDrag ? "cursor-grab active:cursor-grabbing" : "cursor-pointer") + " whitespace-nowrap overflow-hidden text-ellipsis font-mono text-[11px] ring-1 ring-inset");
                    classes.push(errors && errors.length ? "bg-red-50 text-red-800 ring-red-400"
                        : status === "app" ? "bg-blue-50 text-blue-900 ring-blue-300" : "bg-amber-50 text-amber-900 ring-amber-400");
                    title = mapped.map(function (row2) { return row2.schemaPath; }).join("\n") + "\nValue: " + (kind === "empty" ? "(empty: the sample value was removed)" : value + (kind === "sample" ? " (sample value)" : ""))
                        + (node ? "\nData validation: " + rules(node).summary + (node.isRequired ? ", required" : "") : "")
                        + (canDrag ? "\nDrag to move it to another cell" : "")
                        + (status === "app" ? "\nMapped by FRP Mapper" : "\nChanged from the app's mapping")
                        + (errors && errors.length ? "\n" + errors[0] : "")
                        + (listCells[address] ? "\nList " + listCells[address] + ": this row repeats down; every row typed under it is another item, checked the same way." : "");
                } else {
                    classes.push("cursor-cell text-[12px] text-slate-800");
                    if (cell) {
                        content = cell.text;
                        title = cell.text.length > 20 ? cell.text : "";
                        if (cell.bold) {
                            classes.push("font-semibold");
                        }

                        if (cell.fill && colour.test(cell.fill)) {
                            style += "background-color:" + cell.fill + ";";
                        }

                        if (cell.color && colour.test(cell.color) && cell.color !== "#000000") {
                            style += "color:" + cell.color + ";";
                        }

                        if (cell.align) {
                            classes.push(cell.align === "center" ? "text-center" : cell.align === "right" ? "text-right" : "text-left");
                        }
                    }

                    if (moreCells[address] && !cell) {
                        classes.push("bg-sky-50 bg-[repeating-linear-gradient(135deg,transparent_0_6px,rgba(14,165,233,0.12)_6px_8px)]");
                        title = "More items of the list " + moreCells[address] + " are typed in this row (in the downloaded template)";
                    }

                    if (status === "removed") {
                        classes.push("outline-dashed outline-1 -outline-offset-2 outline-amber-500");
                        var gone = self.suggestionAt(address).schemaPath;
                        var now = self.mappings.rows.filter(function (r2) { return lower(r2.schemaPath) === lower(gone); })[0];
                        title = "The app maps " + gone + " here; " + (now ? "it is now on " + now.sheetName + "!" + now.cellAddress + "." : "it is not mapped now.");
                    }

                    classes.push(span && span.rows > 1 ? "whitespace-normal" : "whitespace-nowrap");
                    classes.push(clip ? "overflow-hidden text-ellipsis" : "overflow-visible");
                    if (!clip && content && !(span && span.rows > 1) && (!cell || !cell.align || cell.align === "left")) {
                        // As Excel: left-aligned text runs over the empty cells to its right and stops at the next filled one.
                        var room = 0;
                        for (var k = index; k < columns.length && room < 3000; k++) {
                            if (k > index && hasContent(row, columns[k])) {
                                break;
                            }

                            room += pixelWidth[columns[k]] || 0;
                        }

                        overflowWidth = Math.max(room - 8, 16);
                    }
                }

                if (address === self.selected && !editor) {
                    classes.push("outline outline-2 -outline-offset-2 outline-accent");
                }

                out.push("<td data-cell=\"" + address + "\" class=\"" + classes.join(" ") + "\""
                    + (mapped && canDrag ? " draggable=\"true\" data-drag-path=\"" + esc(mapped[0].schemaPath) + "\"" : "")
                    + (span && span.rows > 1 ? " rowspan=\"" + span.rows + "\"" : "")
                    + (span && span.columns > 1 ? " colspan=\"" + span.columns + "\"" : "")
                    + (style ? " style=\"" + style + "\"" : "")
                    + (title ? " title=\"" + esc(title) + "\"" : "") + ">"
                    + (editor ? "<input id=\"sheetCellEditor\" autocomplete=\"off\" spellcheck=\"false\" class=\"block h-6 w-full min-w-0 border-0 bg-transparent px-1 font-mono text-[12px] outline-none "
                        + (editor.error ? "text-red-800" : "text-ink") + "\" value=\"" + esc(editor.draft) + "\"" + (editor.checking ? " disabled" : "")
                        + " aria-label=\"" + esc("Value of " + lastPart(editor.path) + " in " + address) + "\"" + (editor.error ? " aria-invalid=\"true\"" : "") + ">"
                    : overflowWidth ? "<span class=\"block overflow-hidden text-ellipsis\" style=\"width:" + overflowWidth + "px\">" + esc(content) + "</span>" : esc(content)) + "</td>");
            });
            out.push("</tr>");
        });
        out.push("</tbody>");
        return "<table class=\"border-separate border-spacing-0 bg-white\" style=\"table-layout:fixed;width:" + tableWidth + "px\">" + out.join("") + "</table>";
    };

    // ---------- the side panel: the selected cell ----------

    var placeholder = /^-\s*(empty|none)\s*-$|-\s*autogenerated\s*-/i; // BSP's markers for blank and computed cells
    var code = /^([RC][0-9]{4}|[0-9]{10,})$/;

    /** The row's label (the text left of the cell) and the column's heading (the nearest text above it), as the template shows them. */
    Sheet.prototype.labels = function (grid, address) {
        var at = parseCell(address);
        if (!at || !grid || !grid.cells) {
            return { row: "", column: "" };
        }

        var left = [];
        var above = null;
        var aboveRow = 0;
        grid.cells.forEach(function (c) {
            var text = (c.text || "").trim();
            var p = parseCell(c.address);
            if (!p || !text || placeholder.test(text) || code.test(text)) {
                return;
            }

            if (p.row === at.row && p.column < at.column) {
                left.push({ column: p.column, text: text });
            }

            if (p.column === at.column && p.row < at.row && p.row > aboveRow) {
                above = text;
                aboveRow = p.row;
            }
        });
        left.sort(function (a, b) { return a.column - b.column; });
        return { row: left.slice(-2).map(function (c) { return c.text; }).join(" · "), column: above || "" };
    };

    /** The side panel: the selected cell (its field, value and data validation), then the XSD fields to drag onto the sheet. */
    Sheet.prototype.renderPanel = function (grid, byCell, fields) {
        var self = this;
        return html`<div class="space-y-5">
    ${self.selected ? self.renderCell(grid, byCell) : html`<div class="rounded-app border border-dashed border-line p-3 text-xs leading-5 text-muted">
        <p class="font-semibold text-ink">No cell selected</p>
        <p class="mt-1">Click a cell to see its XSD field, its value and its data validation. Arrow keys move, as in Excel.</p>
    </div>`}
    ${self.renderPalette(fields)}
</div>`;
    };

    /** The XSD fields of the shown sheet, to drag onto a cell (or pick for the selected cell). */
    Sheet.prototype.renderPalette = function (fields) {
        var self = this;
        var page = self.page;
        var m = self.mappings;
        var canEdit = page.canEdit();
        var mappedAt = {};
        m.rows.forEach(function (r) { mappedAt[lower(r.schemaPath)] = r.sheetName + "!" + r.cellAddress; });
        var unmappedCount = fields.filter(function (path) { return !mappedAt[lower(path)]; }).length;
        var filter = lower(self.paletteFilter.trim());
        var shown = fields.filter(function (path) {
            return (self.paletteAll || !mappedAt[lower(path)]) && (!filter || lower(path).indexOf(filter) >= 0);
        });
        return html`<section aria-labelledby="paletteTitle">
    <div class="flex items-baseline justify-between gap-2">
        <h4 id="paletteTitle" class="font-semibold text-ink">XSD fields of ${self.sheet}</h4>
        <span class="text-xs text-subtle">${Frp.n0(unmappedCount)} not mapped</span>
    </div>
    <p class="mt-1 text-xs leading-5 text-subtle">${canEdit ? "Drag a field onto a cell to map it there." : "The fields of this sheet and where they are."}</p>
    <div class="mt-2 flex items-center gap-2">
        <input autocomplete="off" aria-label="Find a field" class="h-8 min-w-0 flex-1 rounded-app border border-line bg-surface px-2 text-xs outline-none transition placeholder:text-subtle hover:border-slate-300 focus:border-accent"
            value="${self.paletteFilter}" placeholder="Find a field (R0010, C0020…)" data-input="${page.on(function (e) { self.paletteFilter = e.target.value; page.update(); })}" />
        <label class="inline-flex shrink-0 items-center gap-1 text-xs text-muted">
            <input type="checkbox" class="h-3.5 w-3.5 accent-[#1d4ed8]"${Frp.attr("checked", self.paletteAll)} data-change="${page.on(function (e) { self.paletteAll = e.target.checked; page.update(); })}" /> Mapped too
        </label>
    </div>
    ${shown.length ? html`<ul class="mt-2 max-h-[360px] space-y-1 overflow-y-auto pr-1" aria-label="XSD fields">
        ${shown.slice(0, fieldListSize).map(function (path) {
            var node = m.node(path);
            var at = mappedAt[lower(path)];
            var check = node ? rules(node) : null;
            var item = self.itemOf(path);
            return html`<li class="group flex items-center gap-2 rounded-app border border-line bg-surface px-2 py-1.5 transition ${canEdit ? "cursor-grab hover:border-accent hover:bg-accent-soft active:cursor-grabbing" : ""}"
                ${canEdit ? Frp.raw(" draggable=\"true\" data-drag-path=\"" + esc(path) + "\"") : ""}
                title="${path + (check ? "\nData validation: " + check.summary : "") + (item ? "\nPart of the list " + lastPart(item) : "")}"
                data-click="${page.on(function () { if (canEdit && self.selected) { self.picked = path; page.update(); } })}">
                ${canEdit ? html`<i class="ph ph-dots-six-vertical text-subtle group-hover:text-accent" aria-hidden="true"></i>` : ""}
                <span class="min-w-0 flex-1">
                    <span class="block truncate font-mono text-xs text-ink">${item ? "\u2193 " : ""}${lastPart(path)}${node && node.isRequired ? html`<span class="text-red-700" title="Required"> *</span>` : ""}</span>
                    <span class="block truncate text-[11px] text-subtle">${check ? check.summary : ""}</span>
                </span>
                ${at ? html`<span class="shrink-0 font-mono text-[11px] text-subtle">${at.split("!")[0] === self.sheet ? at.split("!")[1] : at}</span>` : ""}
            </li>`;
        })}
    </ul>
    ${shown.length > fieldListSize ? html`<p class="mt-2 text-xs text-subtle">${Frp.n0(shown.length - fieldListSize)} more: type part of a name to find one.</p>` : ""}`
        : html`<p class="mt-3 text-xs ${unmappedCount || filter ? "text-subtle" : "text-emerald-700"}">${filter ? "No field matches." : unmappedCount ? "" : html`<i class="ph ph-check-circle"></i> Every XSD field of this sheet is mapped.`}</p>`}
</section>`;
    };

    Sheet.prototype.renderCell = function (grid, byCell) {
        var self = this;
        var page = self.page;
        var m = self.mappings;
        var canEdit = page.canEdit();
        var input = "h-9 w-full rounded-app border border-line bg-surface px-2 text-sm outline-none transition hover:border-slate-300 focus:border-accent";
        var address = self.selected;
        var rows = byCell[address] || [];
        var row = rows[0] || null;
        var node = row ? m.node(row.schemaPath) : null;
        var status = self.status(address, rows);
        var suggestion = self.suggestionAt(address);
        var fieldSuggestion = row && self.suggested ? self.suggested.byPath[lower(row.schemaPath)] : null;
        var labels = self.labels(grid, address);
        var code = m.accountCode({ sheetName: self.sheet, cellAddress: address });
        var errors = row ? m.rowErrors(row) : null;
        var differs = (suggestion && (!row || lower(row.schemaPath) !== lower(suggestion.schemaPath))) || (!suggestion && row && self.suggested);
        var pickedNode = m.node(self.picked);
        var listItem = row ? self.itemOf(row.schemaPath) : null;
        var listInfo = null;
        if (listItem) {
            var listRows = self.listsOnSheet(byCell)[listItem];
            listInfo = { name: lastPart(listItem), oneRow: !!listRows && listRows.rows.length === 1, row: listRows ? listRows.rows[0] : null };
        }

        var pickedItem = pickedNode ? self.itemOf(pickedNode.path) : null;
        var pickedRow = pickedItem ? self.listRow(pickedItem, pickedNode.path) : null;
        var pickedAt = parseCell(address);
        var wrongRow = pickedRow !== null && pickedAt && pickedAt.row !== pickedRow;

        var mapField = function () {
            self.assign(self.picked, address, "Manual");
            page.update();
        };

        var check = node ? rules(node) : null;
        var values = check ? check.values : [];
        return html`<div class="space-y-4 text-sm">
    <div class="flex items-start justify-between gap-2">
        <div class="min-w-0">
        <p class="font-mono text-base font-semibold text-ink">${self.sheet}!${address}</p>
        ${labels.row ? html`<p class="mt-1 text-xs leading-5 text-muted" title="Text on the cell's row">${labels.row}</p>` : ""}
        ${labels.column ? html`<p class="text-xs leading-5 text-subtle" title="The heading above the cell">${labels.column}</p>` : ""}
        ${code !== null ? html`<p class="mt-1 text-xs text-subtle">Account code <span class="font-mono text-ink">${code}</span></p>` : ""}
        </div>
        <button class="grid h-8 w-8 shrink-0 place-items-center rounded-app text-subtle transition hover:bg-canvas hover:text-ink" title="Close (Esc)" aria-label="Close the selected cell"
            data-click="${page.on(function () { self.select(null); page.update(); })}"><i class="ph ph-x"></i></button>
    </div>

    ${row ? html`<div class="rounded-app border ${status === "app" ? "border-blue-200 bg-blue-50/60" : "border-amber-200 bg-amber-50/60"} p-3">
        <p class="text-xs font-semibold ${status === "app" ? "text-blue-800" : "text-amber-800"}">
            ${status === "app" ? "Mapped by FRP Mapper" : "Changed from the app's mapping"}${row.source && !isManual(row.source) ? html`<span class="font-normal"> · ${row.source}</span>` : ""}
        </p>
        <p class="mt-2 break-all font-mono text-xs text-ink">${row.schemaPath}</p>
        <p class="mt-1 text-xs text-subtle">${node ? node.dataType : ""}${node && node.isRequired ? " · required" : ""}${rows.length > 1 ? " · " + rows.length + " fields on this cell" : ""}</p>
        ${listInfo ? html`<div class="mt-2 rounded-app border border-sky-200 bg-sky-50 px-2 py-1.5 text-xs leading-5 text-sky-900">
            <p class="font-semibold"><i class="ph ph-arrow-down"></i> List ${listInfo.name}</p>
            <p>${listInfo.oneRow
                ? "This is the list's first row. In the downloaded template it is an Excel table: every row typed under it becomes another " + listInfo.name + ", checked with the same XSD and BSP rules. When the rows below are taken, insert table rows (right-click, Insert, Table Rows Below). The list's fields must stay on row " + listInfo.row + "."
                : "The list's fields are spread over several rows (one item per sheet or sheet copy), so the downloaded template adds a helper table below the form; the item is entered in these cells."}</p>
        </div>` : ""}
        ${fieldSuggestion && cellKey(fieldSuggestion.sheetName, fieldSuggestion.cellAddress) !== cellKey(self.sheet, address)
            ? html`<p class="mt-2 text-xs text-amber-800">The app maps this field to ${fieldSuggestion.sheetName}!${fieldSuggestion.cellAddress}.</p>` : ""}
        <label class="mt-3 block text-xs font-medium text-subtle" for="sheetValue">Value</label>
        <input id="sheetValue" autocomplete="off" class="${input} mt-1 font-mono ${errors && errors.length ? "border-red-300 bg-red-50" : ""}"
            value="${valueOf(row, node)}" placeholder="${node && node.isRequired ? "Empty (required)" : "Empty"}"${Frp.attr("disabled", !canEdit)}
            data-change="${page.on(function (e) {
                self.editing = { address: address, path: row.schemaPath, draft: e.target.value, error: null, checking: false, panel: true };
                self.commitEdit(0, 0);
            })}" />
        <p class="mt-1 text-xs ${errors && errors.length && valueKind(row, node) !== "empty" ? "text-red-700" : "text-subtle"}">${valueKind(row, node) === "empty"
            ? (node && node.isRequired ? "Empty. This field is required: enter a value before the report is submitted." : "Empty: the sample value was removed.")
            : errors === undefined ? "Checking…" : errors && errors.length ? errors[0]
            : valueKind(row, node) === "sample" ? "A sample value, for testing. Type the bank's figure, or clear it." : "Passes the data validation."}</p>
        ${canEdit ? html`<div class="mt-2 flex flex-wrap gap-2">
            ${valueKind(row, node) !== "empty" ? html`<button class="inline-flex h-8 items-center gap-1.5 rounded-app border border-line bg-surface px-2.5 text-xs font-semibold text-ink transition hover:border-accent hover:text-accent"
                title="Empty this cell (Delete key)" data-click="${page.on(function () { self.setValue(address, ""); })}"><i class="ph ph-eraser"></i> Clear</button>` : ""}
            ${valueKind(row, node) !== "sample" ? html`<button class="inline-flex h-8 items-center gap-1.5 rounded-app border border-line bg-surface px-2.5 text-xs font-semibold text-ink transition hover:border-accent hover:text-accent"
                title="${"Put the sample value back: " + (node ? node.testValue || "" : "")}" data-click="${page.on(function () { self.setValue(address, null); })}"><i class="ph ph-flask"></i> Use sample value</button>` : ""}
        </div>` : ""}
    </div>
    <section class="rounded-app border border-line p-3" aria-labelledby="cellRules">
        <h4 id="cellRules" class="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-subtle"><i class="ph ph-shield-check"></i> Data validation</h4>
        <dl class="mt-2 grid grid-cols-[84px_minmax(0,1fr)] gap-x-2 gap-y-1 text-xs">
            ${check.lines.map(function (line) {
                return html`<dt class="text-subtle">${line.label}</dt><dd class="break-words ${line.label === "Required" && node.isRequired ? "font-semibold text-red-700" : "text-ink"}">${line.text}</dd>`;
            })}
        </dl>
        ${values.length ? html`<div class="mt-2">
            <p class="text-xs text-subtle">Allowed values</p>
            <ul class="mt-1 flex max-h-40 flex-wrap gap-1 overflow-y-auto">
                ${(self.showAllValues ? values : values.slice(0, 12)).map(function (value) {
                    return html`<li class="rounded border border-line bg-canvas px-1.5 py-0.5 font-mono text-[11px] text-ink">${value}</li>`;
                })}
            </ul>
            ${values.length > 12 ? html`<button class="mt-1 text-xs font-medium text-accent hover:underline" data-click="${page.on(function () { self.showAllValues = !self.showAllValues; page.update(); })}">
                ${self.showAllValues ? "Show fewer" : "Show all " + Frp.n0(values.length)}</button>` : ""}
        </div>` : ""}
        <p class="mt-2 text-[11px] leading-4 text-subtle">The downloaded template checks this in Excel (Data, Data Validation, with a note when the cell is selected), and FRP Mapper checks it again when the file is validated.</p>
    </section>` : html`<div class="rounded-app border border-dashed border-line p-3 text-xs leading-5 text-muted">
        No XSD field is mapped to this cell.
        ${suggestion ? html`<span class="text-amber-800">The app maps <span class="font-mono">${lastPart(suggestion.schemaPath)}</span> here.</span>` : ""}
    </div>`}

    ${canEdit ? html`<div>
        <label class="block text-xs font-medium text-subtle" for="sheetField">${row ? "Map another XSD field here" : "Map an XSD field here"}</label>
        <input id="sheetField" autocomplete="off" list="sheetFieldPaths" class="${input} mt-1 font-mono text-xs" value="${self.picked}" placeholder="/ROOT/SHEET/…/R0010C0010"
            data-input="${page.on(function (e) { self.picked = e.target.value; page.update(); })}"
            data-keydown="${page.on(function (e) { if (e.key === "Enter") { e.preventDefault(); self.picked = e.target.value; mapField(); } })}" />
        ${self.picked && !pickedNode ? html`<p class="mt-1 text-xs text-subtle">Pick a field from the list (a full XSD path).</p>` : ""}
        ${wrongRow ? html`<p class="mt-1 text-xs text-red-700">${lastPart(pickedNode.path)} belongs to the list ${lastPart(pickedItem)}, whose fields are on row ${pickedRow}. Pick a cell on row ${pickedRow}.</p>` : ""}
        <div class="mt-2 flex flex-wrap gap-2">
            <button class="inline-flex h-9 items-center gap-1.5 rounded-app bg-accent px-3 text-xs font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50"
                ${Frp.attr("disabled", !pickedNode || wrongRow || (row && lower(row.schemaPath) === lower(self.picked)))} data-click="${page.on(mapField)}">
                <i class="ph ph-link"></i> Map to ${address}
            </button>
            ${row ? html`<button class="inline-flex h-9 items-center gap-1.5 rounded-app border border-line bg-surface px-3 text-xs font-semibold text-ink transition hover:border-red-300 hover:text-red-700"
                data-click="${page.on(function () { self.unmap(address); self.picked = ""; page.update(); })}"><i class="ph ph-link-break"></i> Remove</button>` : ""}
            ${differs && self.suggested ? html`<button class="inline-flex h-9 items-center gap-1.5 rounded-app border border-line bg-surface px-3 text-xs font-semibold text-ink transition hover:border-accent hover:text-accent"
                title="${suggestion ? "Map " + suggestion.schemaPath + " here, as the app does" : "The app maps nothing to this cell"}"
                data-click="${page.on(function () { self.restoreCell(address); self.select(address); page.update(); })}"><i class="ph ph-arrow-counter-clockwise"></i> Use the app's mapping</button>` : ""}
        </div>
        <p class="mt-2 text-xs leading-5 text-subtle">Or drag a field from the list below onto any cell. A field mapped to another cell moves here; a field already on this cell is unmapped.</p>
    </div>` : ""}
</div>`;
    };

    /** The paths offered in the field box: this sheet's fields first (unmapped ones marked), then every other field. */
    Sheet.prototype.fillFieldList = function (fields) {
        var key = this.projectId + "|" + this.sheet + "|" + this.mappings.rows.length;
        if (this.fieldListFor === key || !this.page.canEdit()) {
            return;
        }

        this.fieldListFor = key;
        var list = document.getElementById("sheetFieldPaths");
        if (!list) {
            list = document.createElement("datalist");
            list.id = "sheetFieldPaths";
            document.body.appendChild(list);
        }

        var m = this.mappings;
        var mapped = {};
        m.rows.forEach(function (r) { mapped[lower(r.schemaPath)] = r.sheetName + "!" + r.cellAddress; });
        var first = {};
        var fragment = document.createDocumentFragment();
        var add = function (path) {
            var option = document.createElement("option");
            option.value = path;
            option.label = mapped[lower(path)] ? "on " + mapped[lower(path)] : "not mapped";
            fragment.appendChild(option);
        };
        fields.forEach(function (path) { first[lower(path)] = true; add(path); });
        m.leafPaths.forEach(function (path) {
            if (!first[lower(path)]) {
                add(path);
            }
        });
        list.innerHTML = "";
        list.appendChild(fragment);
    };

    // ---------- render ----------

    Sheet.prototype.render = function () {
        var self = this;
        var page = self.page;
        var project = page.project;
        var canEdit = page.canEdit();
        self.prepare();
        self.indexPaths();
        active = self;
        lockScroll(self.maximized);
        var sheets = self.sheetNames();
        if (!sheets.length) {
            return html`<div class="mt-6">${C.notice("Info", "No template sheets", "This project has no Excel input template, so there is no sheet to show. Use the Table view.")}</div>`;
        }

        var counts = self.countsBySheet();
        var grid = self.grids[lower(self.sheet)];
        var byCell = self.rowsByCell();
        var fields = self.sheetFields();
        self.fillFieldList(fields);
        var offKeys = Object.keys(counts).filter(function (k) { return !sheets.some(function (s) { return lower(s) === k; }); });
        var offCount = offKeys.reduce(function (n, k) { return n + counts[k]; }, 0);
        var offSheets = offKeys.map(function (k) { return self.mappings.rows.filter(function (r) { return lower(r.sheetName) === k; })[0].sheetName; });
        var split = m2split(self.mappings, self.sheet);
        var tally = { app: 0, changed: 0, removed: 0 };
        Object.keys(byCell).forEach(function (address) {
            tally[self.status(address, byCell[address])]++;
        });
        if (self.suggested) {
            self.suggested.list.forEach(function (s) {
                if (lower(s.sheetName) === lower(self.sheet) && !byCell[s.cellAddress.toUpperCase()] && self.status(s.cellAddress.toUpperCase(), null) === "removed") {
                    tally.removed++;
                }
            });
        }

        var gridView;
        if (!grid || grid.loading) {
            gridView = C.pageLoading("Loading the sheet", { classes: "mt-0" });
        } else if (grid.error) {
            gridView = C.notice("Error", "The sheet could not be shown", grid.error);
        } else {
            // The grid is rebuilt only when what it shows changes; otherwise the page keeps the one on screen.
            var editing = self.editing;
            var signature = [self.projectId, self.sheet, self.selected, self.show, !!self.suggested, canEdit,
                editing ? editing.address + "|" + editing.error + "|" + editing.checking : ""].concat(Object.keys(byCell).map(function (address) {
                return address + "=" + byCell[address].map(function (r) {
                    var errors = self.mappings.rowErrors(r);
                    return r.schemaPath + "|" + r.source + "|" + (self.show === "value" ? r.defaultValue : "") + "|" + (errors ? errors.length : "?");
                }).join(",");
            })).join("\u001f");
            if (self.markupFor !== signature) {
                self.markupFor = signature;
                self.markup = self.gridMarkup(grid, byCell);
                self.markupKey = (self.markupKey || 0) + 1;
                if (editing && !editing.checking) {
                    focusEditor(true); // the cell was drawn again while typing: keep typing in it
                }
            }

            gridView = html`<div class="${self.maximized ? "h-[calc(100vh-230px)] min-h-[320px]" : "max-h-[640px]"} overflow-auto rounded-app border border-line bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-accent" tabindex="0" id="sheetGrid"
                role="grid" aria-label="${"Sheet " + self.sheet + "; arrow keys move the selected cell"}"
                data-click="${page.on(function (e) {
                    var td = e.target.closest ? e.target.closest("[data-cell]") : null;
                    if (td) {
                        self.select(td.getAttribute("data-cell"));
                        page.update();
                    }
                })}"
                data-keydown="${page.on(function (e) {
                    var moves = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] };
                    if (e.target && e.target.id === "sheetCellEditor") {
                        return; // the editor's own keys (see the document's keydown listener)
                    }

                    var typing = e.key && e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey;
                    var mappedHere = self.selected && self.rowsByCell()[self.selected];
                    if (canEdit && self.selected && mappedHere && (typing || e.key === "F2" || e.key === "Enter")) {
                        e.preventDefault();
                        self.startEdit(self.selected, typing ? e.key : undefined);
                    } else if (moves[e.key]) {
                        e.preventDefault();
                        self.move(moves[e.key][0], moves[e.key][1]);
                        page.update();
                        reveal(self.selected);
                    } else if ((e.key === "Delete" || e.key === "Backspace") && canEdit && self.selected && mappedHere) {
                        e.preventDefault();
                        self.setValue(self.selected, ""); // as in Excel: Delete empties the cell (Remove in the panel unmaps it)
                    } else if (e.key === "Enter" && self.selected) {
                        e.preventDefault();
                        var field = document.getElementById(canEdit ? "sheetField" : "sheetValue");
                        if (field) {
                            field.focus();
                        }
                    } else if (e.key === "Escape" && self.selected) {
                        e.preventDefault(); // the next Escape leaves full screen
                        self.select(null);
                        page.update();
                    }
                })}">
                <div data-key="${"grid-" + self.markupKey}" data-morph-skip>${Frp.raw(self.markup)}</div>
            </div>
            ${grid.truncated ? html`<p class="mt-2 text-xs text-amber-800">This sheet is larger than ${Frp.n0(maxRows)} rows or ${Frp.n0(maxColumns)} columns; cells beyond are not shown.</p>` : ""}`;
        }

        var chip = "inline-flex items-center gap-1.5 text-xs text-muted";
        var m = self.mappings;
        var toggleFull = function () {
            self.maximized = !self.maximized;
            page.update();
            reveal(self.selected);
        };
        return html`<div class="${self.maximized ? "fixed inset-0 z-50 overflow-y-auto bg-canvas p-4 sm:p-6" : "mt-4"}"${self.maximized ? Frp.raw(" role=\"dialog\" aria-modal=\"true\" aria-label=\"Sheet, full screen\"") : ""}>
    ${self.maximized ? html`<div class="mb-4 flex flex-wrap items-center justify-between gap-3 border-b border-line pb-3">
        <div class="min-w-0">
            <p class="truncate font-display text-lg font-bold text-ink">${project.name} · ${self.sheet}</p>
            <p class="text-xs text-subtle">${m.dirty ? "Unsaved changes" : "All changes saved"} · Esc to leave full screen</p>
        </div>
        <div class="flex gap-2">
            ${canEdit ? html`<button class="inline-flex h-10 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50"
                ${Frp.attr("disabled", m.busy || !m.dirty)} data-click="${page.on(function () { return m.save(); })}"><i class="ph ph-floppy-disk"></i> ${m.dirty ? "Save changes" : "Saved"}</button>` : ""}
            <button class="inline-flex h-10 items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent"
                data-click="${page.on(toggleFull)}"><i class="ph ph-arrows-in"></i> Exit full screen</button>
        </div>
    </div>
` : ""}
    ${self.help ? html`<div class="mb-4 rounded-app border border-accent-line bg-accent-soft p-4 text-sm text-ink" role="note">
        <div class="flex items-start justify-between gap-3">
            <p class="font-semibold">How to map on the sheet</p>
            <button class="text-xs font-medium text-accent hover:underline" data-click="${page.on(function () { self.help = false; writeHelp(false); page.update(); })}">Got it, hide this</button>
        </div>
        <ol class="mt-2 grid gap-3 text-xs leading-5 text-muted sm:grid-cols-2 xl:grid-cols-4">
            ${(canEdit ? [
                ["ph-hand-grabbing", "Drag and drop", "Drag a field from the list on the right onto a cell. Drag a blue cell to move its field."],
                ["ph-cursor-click", "Check a cell", "Click a cell to see its XSD field, its value and its data validation (type, digits, allowed values)."],
                ["ph-keyboard", "Type values", "Select a blue cell and type (or double-click it). Enter checks the value against its data validation and saves it at once; a wrong value turns red and is not saved. Delete empties a cell; Remove sample values empties the sheet, and Restore brings the samples back."],
                ["ph-floppy-disk", "Save the mapping", "Blue cells are the app's mapping, amber ones your changes. Moving fields needs Save; typed values save themselves."]
            ] : [
                ["ph-cursor-click", "Check a cell", "Click a cell to see its XSD field, its value and its data validation."],
                ["ph-palette", "Read the colours", "Blue cells are the app's mapping, amber ones were changed by the Maker."],
                ["ph-arrows-out", "Full screen", "Use Full screen to see more of the sheet."]
            ]).map(function (step, i) {
                return html`<li class="flex gap-2"><span class="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-white text-accent"><i class="ph ${step[0]}"></i></span>
                    <span><span class="font-semibold text-ink">${i + 1}. ${step[1]}.</span> ${step[2]}</span></li>`;
            })}
        </ol>
    </div>` : ""}
    <div class="flex flex-wrap items-end gap-3">
        <div>
            <label class="block text-xs font-medium text-subtle" for="gridSheet">Sheet</label>
            <select autocomplete="off" id="gridSheet" class="mt-1 h-10 max-w-[280px] rounded-app border border-line bg-surface px-3 text-sm transition hover:border-slate-300 focus:border-accent"
                    data-change="${page.on(function (e) { self.sheet = e.target.value; self.select(null); self.confirmReset = false; self.message = null; page.update(); })}">
                ${sheets.map(function (s) {
                    var n = counts[lower(s)] || 0;
                    return html`<option value="${s}"${Frp.attr("selected", s === self.sheet)}>${s}${n ? " (" + Frp.n0(n) + ")" : ""}</option>`;
                })}
            </select>
        </div>
        <div>
            <label class="block text-xs font-medium text-subtle" for="gridGoTo">Go to</label>
            <input autocomplete="off" id="gridGoTo" class="mt-1 h-10 w-56 rounded-app border border-line bg-surface px-3 text-sm outline-none transition placeholder:text-subtle hover:border-slate-300 focus:border-accent"
                   value="${self.goTo}" placeholder="Cell (E9) or field (R0010C0010)"
                   data-input="${page.on(function (e) { self.goTo = e.target.value; })}"
                   data-keydown="${page.on(function (e) { if (e.key === "Enter") { e.preventDefault(); self.find(e.target.value); page.update(); reveal(self.selected); } })}" />
        </div>
        <div>
            <span class="block text-xs font-medium text-subtle" id="gridShowLabel">Mapped cells show</span>
            <div class="mt-1 inline-flex h-10 rounded-app border border-line bg-surface p-0.5" role="group" aria-labelledby="gridShowLabel">
                ${[["field", "XSD field"], ["value", "Value"]].map(function (o) {
                    return html`<button class="rounded-[6px] px-3 text-sm font-medium transition ${self.show === o[0] ? "bg-accent-soft text-accent" : "text-muted hover:text-ink"}" aria-pressed="${self.show === o[0] ? "true" : "false"}"
                        data-click="${page.on(function () { self.show = o[0]; page.update(); })}">${o[1]}</button>`;
                })}
            </div>
        </div>
        <div class="ml-auto flex flex-wrap items-center gap-1">
        ${self.renderSaveState()}
        ${!self.help ? html`<button class="inline-flex h-10 items-center gap-2 rounded-app px-3 text-sm font-semibold text-muted transition hover:bg-surface hover:text-ink" title="How to map on the sheet"
                data-click="${page.on(function () { self.help = true; writeHelp(true); page.update(); })}"><i class="ph ph-question"></i> Help</button>` : ""}
        ${!self.maximized ? html`<button class="inline-flex h-10 items-center gap-2 rounded-app px-3 text-sm font-semibold text-muted transition hover:bg-surface hover:text-ink" title="Show the sheet over the whole window"
                data-click="${page.on(toggleFull)}"><i class="ph ph-arrows-out"></i> Full screen</button>` : ""}
        ${canEdit ? m.sampleButtons(self.sheet) : ""}
        ${canEdit && self.suggested ? html`<button class="inline-flex h-10 items-center gap-2 rounded-app px-3 text-sm font-semibold text-muted transition hover:bg-surface hover:text-ink disabled:opacity-50"
                ${Frp.attr("disabled", !tally.changed && !tally.removed)} title="Map every field of this sheet as FRP Mapper did when the project was created"
                data-click="${page.on(function () {
                    return Frp.confirm({
                        title: "Use the app's mapping for " + self.sheet + "?",
                        message: "Every cell of the sheet gets the app's mapping again; fields you mapped on this sheet by hand are unmapped. Values you typed for the app's fields are kept. Nothing is saved until you press Save.",
                        confirmLabel: "Use the app's mapping",
                        cancelLabel: "Keep my mapping"
                    }).then(function (yes) {
                        if (yes) {
                            self.restoreSheet();
                            page.update();
                        }
                    });
                })}">
            <i class="ph ph-arrow-counter-clockwise"></i> Use the app's mapping for this sheet
        </button>` : ""}
        </div>
    </div>


    ${self.suggestedError ? html`<div class="mt-4">${C.notice("Warning", null, "The app's mapping could not be loaded, so changed cells are told apart by how they were made: " + self.suggestedError)}</div>` : ""}
    ${split ? html`<p class="mt-3 max-w-prose text-xs leading-5 text-muted">${self.sheet} is entered on ${split} sheet copies (Sheet copies tab); the copies use these cells.</p>` : ""}
    ${offCount ? html`<p class="mt-3 max-w-prose text-xs leading-5 text-muted">${Frp.n0(offCount)} mapping${offCount === 1 ? " is" : "s are"} on sheets the template does not have (${offSheets.slice(0, 3).join(", ")}${offSheets.length > 3 ? ", …" : ""}); the Table view lists them.</p>` : ""}

    <div class="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2" aria-label="Legend">
        <span class="${chip}"><span class="h-3.5 w-5 rounded-sm bg-blue-50 ring-1 ring-inset ring-blue-300"></span> Mapped by FRP Mapper (${Frp.n0(tally.app)})</span>
        <span class="${chip}"><span class="h-3.5 w-5 rounded-sm bg-amber-50 ring-1 ring-inset ring-amber-400"></span> Changed from the app's mapping (${Frp.n0(tally.changed)})</span>
        <span class="${chip}"><span class="h-3.5 w-5 rounded-sm outline-dashed outline-1 -outline-offset-2 outline-amber-500"></span> App's cell now empty (${Frp.n0(tally.removed)})</span>
        <span class="${chip}"><span class="h-3.5 w-5 rounded-sm bg-red-50 ring-1 ring-inset ring-red-400"></span> Value fails the XSD</span>
        <span class="${chip}"><span class="font-mono text-[11px] italic text-slate-500">123</span> Sample value (Value view)</span>
        <span class="${chip}"><span class="font-mono text-[11px] text-blue-900">\u2193</span> List row: repeats down</span>
        <span class="${chip}"><span class="h-3.5 w-5 rounded-sm bg-sky-50 bg-[repeating-linear-gradient(135deg,transparent_0_6px,rgba(14,165,233,0.12)_6px_8px)] ring-1 ring-inset ring-sky-200"></span> More list items go here</span>
    </div>

    <div class="mt-3 grid gap-4 ${self.maximized ? "lg:grid-cols-[minmax(0,1fr)_340px]" : "xl:grid-cols-[minmax(0,1fr)_320px]"}">
        <div class="min-w-0">${gridView}</div>
        <aside class="rounded-app border border-line bg-surface p-4 ${self.maximized ? "lg:h-[calc(100vh-230px)] lg:overflow-y-auto" : ""}" aria-label="Selected cell">${grid && grid.cells ? self.renderPanel(grid, byCell, fields) : ""}</aside>
    </div>
</div>`;
    };

    // ---------- drag and drop, full screen ----------

    /** The page behind the full-screen sheet does not scroll. */
    function lockScroll(on) {
        document.documentElement.classList.toggle("overflow-hidden", !!on);
    }

    window.addEventListener("popstate", function () { lockScroll(false); });

    var dropTarget = null;

    function mark(td, ok) {
        if (dropTarget === td && td && td.getAttribute("data-drop") === (ok ? "ok" : "no")) {
            return;
        }

        unmark();
        if (td) {
            dropTarget = td;
            td.setAttribute("data-drop", ok ? "ok" : "no");
            td.classList.add("outline", "outline-2", "-outline-offset-2", ok ? "outline-emerald-500" : "outline-red-500", ok ? "!bg-emerald-50" : "!bg-red-50");
        }
    }

    function unmark() {
        if (dropTarget) {
            dropTarget.removeAttribute("data-drop");
            dropTarget.classList.remove("outline", "outline-2", "-outline-offset-2", "outline-emerald-500", "outline-red-500", "!bg-emerald-50", "!bg-red-50");
            dropTarget = null;
        }
    }

    function sheetCell(event) {
        var td = event.target && event.target.closest ? event.target.closest("#sheetGrid td[data-cell]") : null;
        return td && active && active.dragging ? td : null;
    }

    document.addEventListener("dragstart", function (event) {
        var source = event.target && event.target.closest ? event.target.closest("[data-drag-path]") : null;
        if (!source || !active || !active.page.canEdit()) {
            return;
        }

        active.dragging = source.getAttribute("data-drag-path");
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", active.dragging);
    });

    document.addEventListener("dragover", function (event) {
        var td = sheetCell(event);
        if (!td) {
            unmark();
            return;
        }

        var ok = !active.dropProblem(active.dragging, td.getAttribute("data-cell"));
        event.preventDefault();
        event.dataTransfer.dropEffect = "move"; // a refused drop still lands, so the reason is shown
        mark(td, ok);
    });

    document.addEventListener("drop", function (event) {
        var td = sheetCell(event);
        unmark();
        if (!td) {
            return;
        }

        event.preventDefault();
        var path = active.dragging;
        var address = td.getAttribute("data-cell");
        active.dragging = null;
        if (active.assign(path, address, "Manual")) {
            active.select(address);
        }

        active.page.update();
    });

    document.addEventListener("dragend", function () {
        unmark();
        if (active) {
            active.dragging = null;
        }
    });

    document.addEventListener("keydown", function (event) {
        if (event.target && event.target.id === "sheetCellEditor" && active && active.editing) {
            // As in Excel: Enter saves and goes down, Tab right (Shift+Tab left), Esc cancels.
            if (event.key === "Enter") {
                event.preventDefault();
                active.commitEdit(event.shiftKey ? -1 : 1, 0);
            } else if (event.key === "Tab") {
                event.preventDefault();
                active.commitEdit(0, event.shiftKey ? -1 : 1);
            } else if (event.key === "Escape") {
                event.preventDefault();
                active.cancelEdit();
            }

            return;
        }

        if (event.key === "Escape" && !event.defaultPrevented && active && active.maximized && document.getElementById("sheetGrid")) {
            active.maximized = false;
            active.page.update();
        }
    });

    document.addEventListener("input", function (event) {
        if (event.target && event.target.id === "sheetCellEditor" && active && active.editing) {
            active.editing.draft = event.target.value;
        }
    });

    // Leaving the cell (a click elsewhere) saves it too, unless the editor was only redrawn.
    document.addEventListener("focusout", function (event) {
        var editor = event.target;
        if (!editor || editor.id !== "sheetCellEditor" || !active || !active.editing) {
            return;
        }

        window.setTimeout(function () {
            if (document.body.contains(editor) && document.activeElement !== editor && active && active.editing && !active.editing.checking) {
                active.commitEdit(0, 0);
            }
        }, 0);
    });

    document.addEventListener("dblclick", function (event) {
        var td = event.target && event.target.closest ? event.target.closest("#sheetGrid td[data-cell]") : null;
        if (td && active && active.page.canEdit() && !(active.editing && active.editing.address === td.getAttribute("data-cell"))) {
            active.startEdit(td.getAttribute("data-cell"));
        }
    });

    /** Puts the cursor in the cell being typed in (after the grid is drawn); select: replace the whole value. */
    function focusEditor(caretAtEnd) {
        var focus = function () {
            var editor = document.getElementById("sheetCellEditor");
            if (editor && !editor.disabled && document.activeElement !== editor) {
                editor.focus();
                if (caretAtEnd) {
                    editor.setSelectionRange(editor.value.length, editor.value.length);
                } else {
                    editor.select();
                }
            }
        };
        // At once (the page is drawn synchronously), so the next keys typed land in the cell; again once drawing settles.
        focus();
        window.setTimeout(focus, 0);
    }

    function focusGrid() {
        window.setTimeout(function () {
            var grid = document.getElementById("sheetGrid");
            if (grid && (!document.activeElement || document.activeElement === document.body || document.activeElement.id === "sheetCellEditor" || !document.body.contains(document.activeElement))) {
                grid.focus({ preventScroll: true });
            }
        }, 0);
    }

    /** How many sheet copies the sheet is entered on (Sheet copies tab), or 0. */
    function m2split(mappings, sheet) {
        return mappings.splitSheets ? mappings.splitSheets[lower(sheet)] || 0 : 0;
    }

    /** Scrolls the selected cell into view after the grid is drawn again. */
    function reveal(address) {
        if (!address) {
            return;
        }

        window.setTimeout(function () {
            var grid = document.getElementById("sheetGrid");
            var td = grid ? grid.querySelector("[data-cell=\"" + address + "\"]") : null;
            if (td) {
                td.scrollIntoView({ block: "nearest", inline: "nearest" });
            }
        }, 0);
    }
})();
