// Shared pieces of the screens (the Blazor version's Shared and Components folders).
(function () {
    "use strict";

    var Frp = window.Frp;
    var html = Frp.html;
    var C = Frp.components = {};

    /** An inline message. kind: Info, Success, Warning, Error. */
    C.notice = function (kind, title, body) {
        var classes = {
            Success: "border-emerald-200 bg-emerald-50 text-emerald-900",
            Warning: "border-amber-200 bg-amber-50 text-amber-900",
            Error: "border-red-200 bg-red-50 text-red-900"
        }[kind] || "border-accent-line bg-accent-soft text-ink";
        var icon = {
            Success: "ph-check-circle text-emerald-700",
            Warning: "ph-warning text-amber-700",
            Error: "ph-x-circle text-red-700"
        }[kind] || "ph-info text-accent";
        return html`<div class="flex gap-3 rounded-app border px-4 py-3 text-sm leading-6 ${classes}" role="${kind === "Error" || kind === "Warning" ? "alert" : "status"}">
    <i class="ph ${icon} mt-0.5 text-lg" aria-hidden="true"></i>
    <div class="min-w-0 max-w-prose">
        ${title ? html`<p class="font-semibold">${title}</p>` : ""}
        ${body}
    </div>
</div>`;
    };

    C.metric = function (label, value) {
        return html`<div class="rounded-app border border-line bg-surface px-4 py-3">
    <span class="block text-xs font-medium text-subtle">${label}</span>
    <strong class="mt-1 block break-words font-display text-xl font-bold text-ink">${value}</strong>
</div>`;
    };

    C.statusLabel = function (status) {
        return { Draft: "Draft", InReview: "In review", Returned: "Returned", Approved: "Approved" }[status] || status;
    };

    /** Workflow status as a small labelled badge. Colour is never the only signal: the label is always shown. */
    C.statusBadge = function (status) {
        var icon = { Draft: "ph-pencil-simple", InReview: "ph-hourglass-medium", Returned: "ph-arrow-u-up-left", Approved: "ph-seal-check" }[status] || "ph-circle";
        var classes = {
            Draft: "border-line bg-canvas text-muted",
            InReview: "border-accent-line bg-accent-soft text-accent",
            Returned: "border-amber-200 bg-amber-50 text-amber-800",
            Approved: "border-emerald-200 bg-emerald-50 text-emerald-800"
        }[status] || "border-line bg-canvas text-muted";
        return html`<span class="inline-flex items-center gap-1.5 rounded-app border px-2 py-0.5 text-xs font-semibold ${classes}">
    <i class="ph ${icon}" aria-hidden="true"></i>${C.statusLabel(status)}
</span>`;
    };

    /** Empty state: what this place is for, what to do next, and a real screenshot of what it will look like. */
    C.emptyState = function (title, text, screenshot, screenshotAlt, caption, actions) {
        return html`<section class="grid items-center gap-10 rounded-app border border-line bg-surface p-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:p-12">
    <div class="max-w-prose">
        <h2 class="font-display text-2xl font-bold tracking-tight text-ink">${title}</h2>
        <p class="mt-3 text-base leading-7 text-muted">${text}</p>
        ${actions ? html`<div class="mt-6 flex flex-wrap gap-3">${actions}</div>` : ""}
    </div>
    ${screenshot ? html`<figure>
        <img class="w-full rounded-app border border-line" src="${screenshot}" alt="${screenshotAlt}" loading="lazy" />
        ${caption ? html`<figcaption class="mt-2 text-xs text-subtle">${caption}</figcaption>` : ""}
    </figure>` : ""}
</section>`;
    };

    /** The Active Directory groups that grant each role (database table frp.RoleDirectoryGroup). */
    C.roleGroupList = function (roles) {
        return html`<dl class="mt-6 grid max-w-3xl gap-3 sm:grid-cols-3">
    ${roles.map(function (role) {
        var groups = (role.directoryGroups || []).filter(function (g) { return g && g.trim(); });
        return html`<div class="rounded-app border border-line bg-surface p-4">
        <dt class="text-sm font-semibold text-ink">${role.displayName}</dt>
        <dd class="mt-1 text-sm text-muted">
            ${groups.length ? groups.map(function (group) { return html`<code class="block break-all text-xs text-ink">${group}</code>`; }) : html`<span class="text-xs">No group set up</span>`}
        </dd>
    </div>`;
    })}
</dl>`;
    };

    C.severityClass = function (severity) {
        return severity === "Error" ? "text-red-700" : severity === "Warning" ? "text-amber-700" : "text-muted";
    };

    /** Validation issues with a severity filter; selecting one with a schema path calls onSelect. */
    C.IssueList = function () {
        this.filter = "All";
    };

    C.IssueList.prototype.render = function (page, issues, onSelect) {
        var self = this;
        if (!issues.length) {
            return html`<p class="flex items-center gap-2 text-sm text-emerald-700"><i class="ph ph-check-circle"></i> No issues.</p>`;
        }

        var shown = self.filter === "All" ? issues : issues.filter(function (i) { return i.severity === self.filter; });
        return html`<div class="flex flex-wrap gap-1">
    ${["All", "Error", "Warning", "Info"].map(function (severity) {
        var count = severity === "All" ? issues.length : issues.filter(function (i) { return i.severity === severity; }).length;
        if (severity !== "All" && count === 0) {
            return "";
        }

        return html`<button class="inline-flex h-8 items-center gap-1.5 rounded-app px-2.5 text-xs font-semibold transition ${self.filter === severity ? "bg-ink text-white" : "text-muted hover:bg-canvas hover:text-ink"}" data-click="${page.on(function () { self.filter = severity; page.update(); })}">
        ${severity} <span class="opacity-70">${count}</span>
    </button>`;
    })}
</div>
<div class="mt-2 max-h-80 overflow-auto rounded-app border border-line bg-surface">
    ${shown.slice(0, 300).map(function (issue) {
        var clickable = !!(issue.schemaPath && issue.schemaPath.trim());
        return html`<button type="button" class="grid w-full gap-1 border-b border-line/70 px-4 py-2.5 text-left text-sm transition last:border-0 md:grid-cols-[80px_150px_minmax(0,1fr)] ${clickable ? "hover:bg-canvas" : "cursor-default"}"
            data-click="${page.on(function () { if (clickable && onSelect) { onSelect(issue); } })}"${Frp.attr("disabled", !clickable)}>
        <span class="font-semibold ${C.severityClass(issue.severity)}">${issue.severity}</span>
        <span class="font-mono text-xs text-subtle">${issue.sheetName && issue.sheetName.trim() ? issue.sheetName + "!" + issue.cellAddress : issue.category}</span>
        <span class="min-w-0 text-ink">
            ${issue.message}
            ${clickable ? html`<code class="mt-0.5 block break-all text-xs text-subtle">${issue.schemaPath}</code>` : ""}
        </span>
    </button>`;
    })}
</div>
${shown.length > 300 ? html`<p class="mt-2 text-xs text-subtle">Showing the first 300 of ${Frp.n0(shown.length)}.</p>` : ""}`;
    };

    /**
     * The BSP rules per form (e.g. INTRA: 22 passed, 0 failed, 6 not evaluated), so a form whose rules all passed, and
     * so has no message, still shows it was checked. Folded by default; a search box narrows it to a form.
     */
    C.ruleForms = function (result) {
        var forms = result.specRuleForms || [];
        if (!result.specificationChecked || !forms.length) {
            return "";
        }

        var cell = function (value, tone) {
            return html`<td class="px-3 py-1.5 text-right tabular-nums ${value ? tone || "text-ink" : "text-subtle"}">${Frp.n0(value)}</td>`;
        };
        var key = "rule-forms:" + result.target + ":" + forms.length + ":" + result.specRulesPassed + ":" + result.specRulesFailed;
        return html`<details class="border-b border-line px-5 py-3 text-sm" data-morph-skip data-key="${key}">
    <summary class="cursor-pointer font-semibold text-ink hover:text-accent">BSP rules by form <span class="font-normal text-subtle">(${Frp.n0(forms.length)} forms; every form checked is listed, also when all its rules passed)</span></summary>
    <div class="mt-3">
        <input type="search" autocomplete="off" placeholder="Find a form, e.g. INTRA" aria-label="Find a form"
               class="h-9 w-full max-w-xs rounded-app border border-line bg-surface px-3 text-sm outline-none transition placeholder:text-subtle hover:border-slate-300 focus:border-accent"
               data-rule-form-filter />
        <div class="mt-2 max-h-80 overflow-auto rounded-app border border-line">
            <table class="w-full text-sm">
                <thead class="sticky top-0 bg-canvas text-xs text-subtle">
                    <tr><th class="px-3 py-2 text-left font-semibold">Form</th><th class="px-3 py-2 text-right font-semibold">Passed</th><th class="px-3 py-2 text-right font-semibold">Failed</th><th class="px-3 py-2 text-right font-semibold">Not applicable</th><th class="px-3 py-2 text-right font-semibold">Not evaluated</th></tr>
                </thead>
                <tbody>
                    ${forms.map(function (f) {
                        return html`<tr class="border-t border-line/70" data-form="${f.form}">
                        <td class="px-3 py-1.5 font-medium text-ink">${f.form}</td>
                        ${cell(f.passed, "text-emerald-700")}${cell(f.failed, "font-semibold text-red-700")}${cell(f.notApplicable)}${cell(f.notEvaluated, "text-amber-700")}
                    </tr>`;
                    })}
                </tbody>
            </table>
        </div>
        <p class="mt-2 text-xs text-subtle">Not applicable: the form or table is not in the XML, or the rule's condition does not apply. Not evaluated: see the Info messages for the reason (e.g. bank profile or imported figures missing).</p>
    </div>
</details>`;
    };

    // The form search of C.ruleForms (a document listener: the table is not redrawn while typing, and the CSP allows no inline handlers).
    document.addEventListener("input", function (event) {
        var box = event.target;
        if (!box || !box.hasAttribute || !box.hasAttribute("data-rule-form-filter")) {
            return;
        }

        var query = box.value.trim().toLowerCase();
        Array.prototype.forEach.call(box.parentNode.querySelectorAll("tbody tr"), function (row) {
            row.hidden = !!query && row.getAttribute("data-form").toLowerCase().indexOf(query) < 0;
        });
    });

    /** Result of validating an XML file against the XSD and the BSP specification. */
    C.xmlValidationResult = function (result) {
        var messages = result.messages || [];
        return html`<div class="rounded-app border ${result.isValid ? "border-emerald-200" : "border-red-200"} bg-surface">
    <div class="flex flex-wrap items-start gap-3 border-b border-line px-5 py-4">
        <i class="ph ${result.isValid ? "ph-check-circle text-emerald-700" : "ph-x-circle text-red-700"} mt-0.5 text-xl"></i>
        <div class="min-w-0">
            <p class="font-semibold text-ink">${result.isValid ? "Valid" : "Not valid"}: <span class="font-normal text-muted">${result.target}</span></p>
            ${result.specificationChecked ? html`<p class="mt-1 text-sm text-muted">
                BSP rules: ${Frp.n0(result.specRulesPassed)} passed,
                <span class="${result.specRulesFailed > 0 ? "font-semibold text-red-700" : ""}">${Frp.n0(result.specRulesFailed)} failed</span>,
                ${Frp.n0(result.specRulesNotApplicable)} not applicable, ${Frp.n0(result.specRulesNotEvaluated)} not evaluated.
            </p>` : ""}
            ${result.bspStatus ? html`<p class="mt-1 flex items-center gap-2 text-sm text-muted" role="status">
                <span class="h-3.5 w-3.5 shrink-0 animate-spin rounded-full border-2 border-accent/30 border-t-accent" aria-hidden="true"></span>${result.bspStatus}</p>` : ""}
            ${result.bsp ? html`<p class="mt-1 text-sm text-muted">
                ${result.bsp.environmentName}: <span class="${result.bsp.total > 0 ? "font-semibold text-red-700" : ""}">${Frp.n0(result.bsp.total)} finding${result.bsp.total === 1 ? "" : "s"}</span>
                (${Frp.n0(result.bsp.both)} also found by the app, ${Frp.n0(result.bsp.bspOnly)} only by BSP; ${Frp.n0(result.bsp.appOnly)} app message${result.bsp.appOnly === 1 ? "" : "s"} not reported by BSP).
                <span>Submission <span class="break-all font-mono text-xs">${result.bsp.submissionId}</span></span>
            </p>` : ""}
        </div>
    </div>
    ${C.ruleForms(result)}
    ${messages.length ? html`
        ${messages.length > 200 ? html`<p class="border-b border-line px-5 py-2 text-xs text-subtle">Showing the first 200 of ${Frp.n0(messages.length)} messages.</p>` : ""}
        <div class="max-h-96 overflow-auto">
            ${messages.slice(0, 200).map(function (message) {
                return html`<div class="grid gap-1 border-b border-line/70 px-5 py-2.5 text-sm last:border-0 md:grid-cols-[80px_minmax(0,1fr)]">
                <span class="font-semibold ${C.severityClass(message.severity)}">${message.severity}</span>
                <span class="min-w-0 break-words text-ink">
                    ${result.bsp ? html`<span class="mr-1.5 inline-block rounded px-1.5 py-0.5 text-xs font-semibold ${message.source === "BSP sandbox" ? "bg-amber-100 text-amber-900" : message.source === "Both" ? "bg-accent-soft text-accent" : "bg-slate-100 text-muted"}"
                        title="${message.source === "Both" && message.bspMessage ? "BSP: " + message.bspMessage : ""}">${message.source === "BSP sandbox" ? "BSP" : message.source === "Both" ? "App + BSP" : "App"}</span>` : ""}
                    ${message.cell ? html`<span class="mr-1.5 inline-block rounded bg-slate-100 px-1.5 py-0.5 font-mono text-xs font-semibold text-ink">${message.cell}</span>` : ""}
                    ${message.message}
                    ${message.lineNumber > 0 && !message.cell ? html`<span class="block text-xs text-subtle">Line ${message.lineNumber}, position ${message.linePosition}</span>` : ""}
                </span>
            </div>`;
            })}
        </div>` : ""}
</div>`;
    };

    /** Result of checking a workbook's Excel XML map against the XSD. */
    C.coverageResult = function (coverage) {
        return html`<div class="rounded-app border ${coverage.isComplete ? "border-emerald-200" : "border-amber-200"} bg-surface">
    <div class="flex items-start gap-3 border-b border-line px-5 py-4">
        <i class="ph ${coverage.isComplete ? "ph-check-circle text-emerald-700" : "ph-warning text-amber-700"} mt-0.5 text-xl"></i>
        <div class="min-w-0">
            <p class="font-semibold text-ink">${coverage.isComplete ? "Every XSD field Excel can bind is mapped" : "The template is not fully mapped"}</p>
            <p class="mt-0.5 break-all text-xs text-subtle">${coverage.fileName}</p>
        </div>
    </div>
    <div class="grid gap-3 p-5 sm:grid-cols-2 xl:grid-cols-5">
        ${C.metric("XSD fields", Frp.n0(coverage.totalFields))}
        ${C.metric("Bound single cells", Frp.n0(coverage.boundSingleCells))}
        ${C.metric("Bound list columns", Frp.n0(coverage.boundListColumns))}
        ${C.metric("Not bound", Frp.n0(coverage.unbound))}
        ${C.metric("Excel cannot bind", Frp.n0(coverage.notBindableInExcel))}
    </div>
    <div class="space-y-3 px-5 pb-5 text-sm leading-6 text-muted">
        ${coverage.notBindableInExcel > 0 ? html`<p class="max-w-prose">Fields in lists inside other lists cannot be bound by Excel; the project’s XML includes them.</p>` : ""}
        ${coverage.leftOutBySpecification > 0 ? html`<p class="max-w-prose">${Frp.n0(coverage.leftOutBySpecification)} field(s) in ${(coverage.leftOutForms || []).join(", ")} are left unbound on purpose: the BSP specification says these forms are not submitted for the sample’s Header values.</p>` : ""}
        ${(coverage.problems || []).length ? html`<ul class="list-disc space-y-1 pl-5 text-red-800">
            ${coverage.problems.slice(0, 50).map(function (problem) { return html`<li>${problem}</li>`; })}
        </ul>` : ""}
        ${(coverage.unboundFields || []).length ? html`<details>
            <summary class="cursor-pointer font-semibold text-ink hover:text-accent">Unbound fields (${Frp.n0(coverage.unboundFields.length)})</summary>
            <div class="mt-2 max-h-72 overflow-auto rounded-app border border-line">
                ${coverage.unboundFields.map(function (field) {
                    return html`<div class="grid gap-1 border-b border-line/70 px-3 py-2 last:border-0 md:grid-cols-2">
                    <code class="break-all text-xs text-ink">${field.schemaPath}</code>
                    <span class="text-xs">${field.reason}</span>
                </div>`;
                })}
            </div>
        </details>` : ""}
    </div>
</div>`;
    };

    /**
     * Progress of a running validation or analysis: percent done, the step it is on, what it is checking right now, the
     * steps already finished, the time taken and an estimate of the time left.
     */
    C.Progress = function (page, title) {
        this.page = page;
        this.title = title;
        this.progress = null;
        this.finished = [];
        this.startedAt = Date.now();
        var self = this;
        // The elapsed time keeps counting even while a long step sends no update.
        this.timer = setInterval(function () { self.page.update(); }, 1000);
    };

    /** Shows an update; a new step marks the previous one as finished. */
    C.Progress.prototype.show = function (update) {
        if (this.progress && this.progress.stage !== update.stage && this.finished.indexOf(this.progress.stage) < 0) {
            this.finished.push(this.progress.stage);
        }

        this.progress = update;
        this.page.update();
    };

    C.Progress.prototype.stop = function () {
        clearInterval(this.timer);
    };

    C.Progress.prototype.render = function () {
        var percent = Math.max(0, Math.min(100, this.progress ? this.progress.percent || 0 : 0));
        var elapsed = Date.now() - this.startedAt;
        var remaining = percent >= 10 && percent < 100 && elapsed >= 2000 ? Math.ceil(elapsed / 1000 * (100 - percent) / percent) * 1000 : null;
        var progress = this.progress;
        return html`<div class="rounded-app border border-accent-line bg-surface p-5" role="status" aria-live="polite">
    <div class="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
        <p class="font-semibold text-ink">${this.title}</p>
        <p class="text-sm tabular-nums text-muted">${Frp.elapsed(elapsed)} elapsed${remaining !== null ? " · about " + Frp.elapsed(remaining) + " left" : ""}</p>
    </div>
    <div class="mt-4 flex items-center gap-4">
        <div class="h-3 flex-1 overflow-hidden rounded-full bg-line" role="progressbar" aria-label="Validation progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent}">
            <div class="h-full rounded-full bg-accent transition-all duration-300 ease-out" style="width: ${percent}%"></div>
        </div>
        <span class="w-12 text-right font-display text-lg font-bold tabular-nums text-ink">${percent}%</span>
    </div>
    <div class="mt-4 flex items-start gap-3 text-sm">
        <span class="mt-0.5 h-4 w-4 shrink-0 animate-spin rounded-full border-2 border-accent-line border-t-accent" aria-hidden="true"></span>
        <div class="min-w-0">
            <p class="font-medium text-ink">${progress ? progress.stage : "Starting"}</p>
            ${progress && progress.detail ? html`<p class="mt-0.5 truncate font-mono text-xs text-muted" title="${progress.detail}">${progress.detail}</p>` : ""}
        </div>
    </div>
    ${this.finished.length ? html`<ul class="mt-4 space-y-1.5 border-t border-line pt-4 text-sm text-muted">
        ${this.finished.map(function (stage) { return html`<li class="flex items-center gap-2"><i class="ph ph-check-circle text-emerald-700" aria-hidden="true"></i> ${stage}</li>`; })}
    </ul>` : ""}
</div>`;
    };

    /** The submission file: name, source, hash and its validation results. */
    C.submissionFacts = function (submission) {
        if (!submission) {
            return html`<p class="mt-4 rounded-app border border-dashed border-line px-4 py-3 text-sm text-subtle">No submission file attached yet.</p>`;
        }

        return html`<dl class="mt-4 grid max-w-xl grid-cols-[auto_minmax(0,1fr)] gap-x-6 gap-y-2 rounded-app border border-line px-4 py-3 text-sm">
    <dt class="text-subtle">File</dt>
    <dd class="min-w-0 truncate font-medium text-ink" title="${submission.fileName}">${submission.fileName}</dd>
    <dt class="text-subtle">Source</dt>
    <dd class="text-ink">${submission.source === "Uploaded" ? "Uploaded" : "Built from project values"} by ${Frp.shortName(submission.attachedBy)}, ${Frp.date(submission.attachedAt, true)}</dd>
    <dt class="text-subtle">XSD</dt>
    <dd>${submission.xsdValid
        ? html`<span class="inline-flex items-center gap-1.5 text-emerald-700"><i class="ph ph-check-circle"></i> Valid</span>`
        : html`<span class="inline-flex items-center gap-1.5 text-red-700"><i class="ph ph-x-circle"></i> ${submission.xsdErrors} error(s)</span>`}</dd>
    <dt class="text-subtle">BSP rules</dt>
    <dd class="text-ink">${submission.specificationChecked
        ? html`<span>${Frp.n0(submission.specRulesPassed)} passed, </span><span class="${submission.specRulesFailed > 0 ? "font-semibold text-red-700" : ""}">${Frp.n0(submission.specRulesFailed)} failed</span>`
        : html`<span class="text-subtle">No specification uploaded</span>`}</dd>
    <dt class="text-subtle">SHA-256</dt>
    <dd class="min-w-0"><code class="block truncate text-xs text-muted" title="${submission.sha256}">${submission.sha256}</code></dd>
</dl>`;
    };

    C.downloadCard = function (href, icon, title, text, primary) {
        return html`<a class="group flex flex-col rounded-app border p-5 transition ${primary ? "border-accent bg-accent-soft hover:bg-blue-100" : "border-line bg-surface hover:border-accent"}" href="${href}" data-native="true">
    <span class="flex items-center gap-2 font-semibold text-ink group-hover:text-accent">
        <i class="ph ${icon} text-lg ${primary ? "text-accent" : "text-subtle"} group-hover:text-accent"></i> ${title}
    </span>
    <span class="mt-2 text-sm leading-6 text-muted">${text}</span>
    <span class="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-accent">
        <i class="ph ph-download-simple"></i> Download
    </span>
</a>`;
    };

    /** One or two workflow buttons; the chosen action asks for a second click before it runs. */
    /** The workflow buttons; options.onRequest(action) asks for confirmation (a toast) and runs the step. */
    C.confirmActions = function (page, options) {
        return html`<div class="mt-4 flex flex-wrap items-center gap-2">
    ${options.primary ? html`<button class="inline-flex h-10 items-center gap-2 rounded-app bg-accent px-5 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-50"
            data-click="${page.on(function () { return options.onRequest(options.primary); })}"${Frp.attr("disabled", options.busy || options.primaryDisabled)}>
        ${options.busy ? html`<span class="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" aria-hidden="true"></span>` : html`<i class="ph ${options.primaryIcon}"></i>`} ${options.primaryLabel}
    </button>` : ""}
    ${options.secondary ? html`<button class="inline-flex h-10 items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:cursor-not-allowed disabled:opacity-50"
            data-click="${page.on(function () { return options.onRequest(options.secondary); })}"${Frp.attr("disabled", options.busy || options.secondaryDisabled)}>
        <i class="ph ${options.secondaryIcon}"></i> ${options.secondaryLabel}
    </button>` : ""}
</div>`;
    };

    /**
     * A labelled file input. The allowed extensions and the size limit come from the API's FileStorage settings; a file
     * already stored on the server (same content) is marked as reused.
     */
    C.FilePicker = function (page, options) {
        this.page = page;
        this.options = options; // label, help, kind, required, onSelected(file), onError(message)
        this.file = null;
        this.reading = false;
        this.alreadyStored = false;
        this.id = "file-" + Math.random().toString(36).substring(2, 9);
    };

    C.FilePicker.prototype.clear = function () {
        this.file = null;
        this.alreadyStored = false;
    };

    C.FilePicker.prototype.choose = function (file) {
        var self = this;
        var settings = Frp.files.settings();
        if (!settings) {
            return;
        }

        if (!Frp.files.allows(self.options.kind, file.name)) {
            self.options.onError(file.name + " is not a " + Frp.files.extensionsFor(self.options.kind).join(" or ") + " file.");
            return;
        }

        if (file.size > settings.maxUploadBytes) {
            self.options.onError(file.name + " is larger than the " + Frp.files.maxMegabytes() + " MB limit.");
            return;
        }

        self.reading = true;
        self.alreadyStored = false;
        self.page.update();
        // Only a hint for the Maker; the API decides again when the project is created.
        Frp.sha256(file).then(function (sha256) {
            file.sha256 = sha256;
            return Frp.api.get("files/stored", { sha256: sha256, fileName: file.name }, { quiet: true }).then(function (stored) {
                self.alreadyStored = !!(stored && stored.stored);
            }, function () {
                self.alreadyStored = false;
            });
        }).then(function () {
            self.file = file;
            self.reading = false;
            self.options.onSelected(file);
            self.page.update();
        }, function (error) {
            self.reading = false;
            self.options.onError(file.name + " could not be read: " + (error && error.message ? error.message : "unknown error"));
            self.page.update();
        });
    };

    C.FilePicker.prototype.render = function (disabled) {
        var self = this;
        var page = self.page;
        var settings = Frp.files.settings();
        var accept = Frp.files.acceptFor(self.options.kind);
        var file = self.file;
        var off = disabled || !settings;
        return html`<div>
    <span class="block text-sm font-semibold text-ink">
        ${self.options.label}
        ${!self.options.required ? html`<span class="ml-1 font-normal text-subtle">(optional)</span>` : ""}
    </span>
    <p class="mt-1 max-w-prose text-sm text-muted">${self.options.help}</p>
    <label class="mt-2 flex cursor-pointer items-center gap-3 rounded-app border border-dashed px-4 py-3 text-sm transition ${!file ? "border-line bg-surface hover:border-accent hover:bg-accent-soft" : "border-accent-line bg-accent-soft"} ${off ? "pointer-events-none opacity-60" : ""}">
        <i class="ph ${self.reading ? "ph-spinner animate-spin" : !file ? "ph-upload-simple" : "ph-check-circle"} text-lg ${!file ? "text-subtle" : "text-accent"}"></i>
        <span class="min-w-0 flex-1">
            ${self.reading ? html`<span class="text-muted">Reading file…</span>`
                : !file ? html`<span class="font-medium text-ink">Choose a file</span> <span class="text-subtle">${accept}${settings ? " · up to " + Frp.files.maxMegabytes() + " MB" : ""}</span>`
                : html`<span class="block truncate font-medium text-ink">${file.name}</span>
                <span class="text-xs text-subtle">${Frp.size(file.size)} · click to replace</span>
                ${self.alreadyStored ? html`<span class="mt-1 flex items-center gap-1.5 text-xs font-medium text-emerald-700">
                    <i class="ph ph-copy-simple" aria-hidden="true"></i> Already uploaded before: the stored file is reused, not saved again.
                </span>` : ""}`}
        </span>
        <input type="file" class="sr-only" accept="${accept}"${Frp.attr("disabled", off || self.reading)}
               data-change="${page.on(function (event) { var chosen = event.target.files[0]; event.target.value = ""; if (chosen) { self.choose(chosen); } })}" />
    </label>
</div>`;
    };

    /** A file an existing project already uploaded, which the new project reuses instead of a new upload. */
    C.reusedFileCard = function (page, options) {
        return html`<div>
    <span class="block text-sm font-semibold text-ink">
        ${options.label}
        ${!options.required ? html`<span class="ml-1 font-normal text-subtle">(optional)</span>` : ""}
    </span>
    <p class="mt-1 max-w-prose text-sm text-muted">${options.help}</p>
    <div class="mt-2 flex flex-wrap items-center gap-3 rounded-app border border-accent-line bg-accent-soft px-4 py-3 text-sm">
        <i class="ph ph-copy-simple text-lg text-accent" aria-hidden="true"></i>
        <span class="min-w-[12rem] flex-1">
            <span class="block truncate font-medium text-ink">${options.file.fileName}</span>
            <span class="text-xs text-subtle">${Frp.size(options.file.size)} · reused from ${options.projectName}, not uploaded again</span>
        </span>
        <span class="flex shrink-0 gap-1">
            <button type="button" class="inline-flex h-9 items-center gap-1.5 rounded-app px-3 text-xs font-semibold text-accent transition hover:bg-surface disabled:opacity-50"
                    data-click="${page.on(options.onReplace)}"${Frp.attr("disabled", options.disabled)}>
                <i class="ph ph-upload-simple" aria-hidden="true"></i> Upload a different file
            </button>
            ${!options.required ? html`<button type="button" class="inline-flex h-9 items-center gap-1.5 rounded-app px-3 text-xs font-semibold text-muted transition hover:bg-surface hover:text-ink disabled:opacity-50"
                    data-click="${page.on(options.onRemove)}"${Frp.attr("disabled", options.disabled)}>
                <i class="ph ph-x" aria-hidden="true"></i> Don't use
            </button>` : ""}
        </span>
    </div>
</div>`;
    };

    /**
     * The standard loading screen: what is loading, 0–100% and a bar, filled in by Frp.progress while the API calls
     * run (sending and receiving are measured, the server's work is estimated). label: "Loading the project";
     * options.compact: a smaller one for a panel; options.classes: extra classes (e.g. the top margin).
     */
    C.pageLoading = function (label, options) {
        options = options || {};
        var value = Frp.progress ? Frp.progress.percent() : 0;
        var stage = Frp.progress && Frp.progress.busy() ? Frp.progress.stage() : "Starting";
        var text = label || "Loading";
        // data-morph-skip: redrawing the page keeps the bar where Frp.progress put it; data-key: another label is a new screen.
        return html`<div class="${options.classes || "mt-8"} ${options.compact ? "p-4" : "px-6 py-8 sm:px-8"} rounded-app border border-line bg-surface shadow-sm"
        data-frp-progress data-morph-skip data-key="${"loading:" + text}" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${value}" aria-label="${text}" aria-busy="true">
    <div class="${options.compact ? "" : "mx-auto max-w-xl"}">
        <div class="flex items-center justify-between gap-4">
            <p class="flex min-w-0 items-center gap-2 text-sm font-semibold text-ink">
                <i class="ph ph-circle-notch animate-spin text-base text-accent" aria-hidden="true"></i>
                <span class="truncate">${text}…</span>
            </p>
            <span class="font-display text-2xl font-bold tabular-nums text-accent" data-frp-progress-text>${value}%</span>
        </div>
        <div class="mt-3 h-2 overflow-hidden rounded-full bg-line/70">
            <div class="h-full rounded-full bg-accent transition-[width] duration-150 ease-out" data-frp-progress-bar style="width: ${value}%"></div>
        </div>
        <p class="mt-2 text-xs text-subtle" data-frp-progress-note>${stage}</p>
    </div>
</div>`;
    };

    // ---------- paged lists (the audit trail and a project's history) ----------

    /**
     * A list the API returns one page at a time (GET path?page=&pageSize=&search=&action=, answering
     * { entries, total, page, pageSize, actions }). owner is the page (update() redraws it); storageKey remembers the
     * page size in this browser. Searching waits until typing stops; an answer that arrives after a newer request is
     * ignored.
     */
    C.PagedList = function (owner, path, storageKey) {
        this.owner = owner;
        this.path = path;
        this.storageKey = storageKey;
        this.page = 1;
        this.pageSize = C.PagedList.storedSize(storageKey);
        this.search = "";
        this.action = "";
        this.data = null;
        this.error = null;
        this.loading = false;
        this.sequence = 0;
        this.timer = null;
    };

    C.PagedList.sizes = [10, 25, 50, 100];

    C.PagedList.storedSize = function (key) {
        try {
            var stored = parseInt(window.localStorage.getItem(key) || "", 10);
            return C.PagedList.sizes.indexOf(stored) >= 0 ? stored : 25;
        } catch (e) {
            return 25;
        }
    };

    C.PagedList.prototype.load = function () {
        var self = this;
        var sequence = ++self.sequence;
        var filtered = self.filtered();
        self.loading = true;
        return Frp.api.get(self.path, { page: self.page, pageSize: self.pageSize, search: self.search.trim() || null, action: self.action || null }).then(function (data) {
            if (sequence !== self.sequence) {
                return;
            }

            self.loading = false;
            self.error = null;
            // A page past the end (entries were filtered away): show the last page instead.
            var pages = Math.max(1, Math.ceil(data.total / data.pageSize));
            if (!data.entries.length && data.total > 0 && self.page > pages) {
                self.page = pages;
                return self.load();
            }

            self.data = data;
            self.dataFiltered = filtered;
        }, function (error) {
            if (sequence !== self.sequence) {
                return;
            }

            self.loading = false;
            self.error = error instanceof Frp.ApiError && !error.unreachable ? error.message : "The entries could not be loaded. Check your connection and try again.";
        }).then(function () {
            if (sequence === self.sequence) {
                self.owner.update();
            }
        });
    };

    C.PagedList.prototype.go = function (page) {
        // A search still waiting for typing to stop is included in this request (the text is already kept).
        window.clearTimeout(this.timer);
        this.page = Math.max(1, page);
        var loading = this.load();
        // Drawn once the request is on its way, so the list shows as loading (dimmed) until the page arrives.
        this.owner.update();
        return loading;
    };

    C.PagedList.prototype.setSize = function (size) {
        size = parseInt(size, 10);
        if (C.PagedList.sizes.indexOf(size) < 0) {
            return undefined;
        }

        // Keep the first entry on screen in view.
        var first = (this.page - 1) * this.pageSize;
        this.pageSize = size;
        try {
            window.localStorage.setItem(this.storageKey, String(size));
        } catch (e) {
            // Not remembered (private window); the size still applies now.
        }

        return this.go(Math.floor(first / size) + 1);
    };

    C.PagedList.prototype.setAction = function (action) {
        this.action = action || "";
        return this.go(1);
    };

    C.PagedList.prototype.setSearch = function (text) {
        var self = this;
        self.search = text;
        window.clearTimeout(self.timer);
        self.timer = window.setTimeout(function () {
            self.go(1);
        }, 350);
    };

    C.PagedList.prototype.filtered = function () {
        return !!(this.search.trim() || this.action);
    };

    /** True when the trail (or the project's history) has no entries at all, as opposed to none matching a filter. */
    C.PagedList.prototype.empty = function () {
        return !!this.data && !this.data.total && !this.dataFiltered;
    };

    /** The search box and Action filter. on: the page's on(). */
    C.PagedList.prototype.filters = function (on, placeholder) {
        var self = this;
        var actions = (self.data && self.data.actions) || [];
        if (self.action && actions.indexOf(self.action) < 0) {
            actions = actions.concat([self.action]);
        }

        return html`<div class="flex flex-col gap-3 sm:flex-row sm:items-end">
    <label class="block sm:w-80">
        <span class="block text-xs font-medium text-subtle">Search</span>
        <input type="search" autocomplete="off" maxlength="200" class="mt-1 h-10 w-full rounded-app border border-line bg-surface px-3 text-sm outline-none transition placeholder:text-subtle hover:border-slate-300 focus:border-accent"
               placeholder="${placeholder || "Person, project or details"}" value="${self.search}" data-input="${on(function (e) { self.setSearch(e.target.value); })}" />
    </label>
    <label class="block">
        <span class="block text-xs font-medium text-subtle">Action</span>
        <select autocomplete="off" class="mt-1 h-10 rounded-app border border-line bg-surface px-3 text-sm transition hover:border-slate-300 focus:border-accent"
                data-change="${on(function (e) { self.setAction(e.target.value); })}">
            <option value=""${Frp.attr("selected", !self.action)}>All actions</option>
            ${actions.map(function (name) { return html`<option value="${name}"${Frp.attr("selected", self.action === name)}>${name}</option>`; })}
        </select>
    </label>
</div>`;
    };

    /** "26–50 of 1,234", the page size, and First / Previous / page numbers / Next / Last. on: the page's on(). */
    C.PagedList.prototype.pager = function (on) {
        var self = this;
        var data = self.data;
        if (!data) {
            return "";
        }

        var total = data.total;
        var pages = Math.max(1, Math.ceil(total / data.pageSize));
        // The page on screen (the one asked for shows once it has arrived).
        var page = Math.min(data.page || 1, pages);
        var from = total ? (page - 1) * data.pageSize + 1 : 0;
        var to = Math.min(total, page * data.pageSize);
        var numbers = [];
        var low = Math.max(1, page - 2);
        var high = Math.min(pages, page + 2);
        if (low > 1) {
            numbers.push(1);
            if (low > 2) {
                numbers.push(null);
            }
        }

        for (var n = low; n <= high; n++) {
            numbers.push(n);
        }

        if (high < pages) {
            if (high < pages - 1) {
                numbers.push(null);
            }

            numbers.push(pages);
        }

        var button = "inline-flex h-9 min-w-9 items-center justify-center rounded-app border px-2.5 text-sm font-medium tabular-nums transition disabled:cursor-not-allowed disabled:opacity-40";
        var plain = button + " border-line bg-surface text-ink hover:border-slate-300 hover:bg-canvas";
        var arrow = function (text, label, target, disabled) {
            return html`<button type="button" class="${plain}" aria-label="${label}" title="${label}"${Frp.attr("disabled", disabled || self.loading)}
        data-click="${on(function () { return self.go(target); })}"><span aria-hidden="true">${text}</span></button>`;
        };

        return html`<nav class="mt-4 flex flex-col gap-3 text-sm sm:flex-row sm:items-center sm:justify-between" aria-label="Pages">
    <div class="flex flex-wrap items-center gap-3 text-muted">
        <p aria-live="polite"><span class="font-semibold tabular-nums text-ink">${Frp.n0(from)}–${Frp.n0(to)}</span> of <span class="font-semibold tabular-nums text-ink">${Frp.n0(total)}</span> ${total === 1 ? "entry" : "entries"}</p>
        <label class="flex items-center gap-2">
            <span>Show</span>
            <select autocomplete="off" class="h-9 rounded-app border border-line bg-surface px-2 text-sm text-ink transition hover:border-slate-300 focus:border-accent"
                    aria-label="Entries per page" data-change="${on(function (e) { return self.setSize(e.target.value); })}">
                ${C.PagedList.sizes.map(function (size) { return html`<option value="${size}"${Frp.attr("selected", data.pageSize === size)}>${size}</option>`; })}
            </select>
            <span>per page</span>
        </label>
    </div>
    ${pages > 1 ? html`<div class="flex flex-wrap items-center gap-1">
        ${arrow("«", "First page", 1, page === 1)}
        ${arrow("‹", "Previous page", page - 1, page === 1)}
        ${numbers.map(function (n) {
            return n === null
                ? html`<span class="px-1 text-subtle" aria-hidden="true">…</span>`
                : html`<button type="button" class="${n === page ? button + " border-accent bg-accent text-white" : plain}" aria-label="${"Page " + n}"${Frp.raw(n === page ? " aria-current=\"page\"" : "")}${Frp.attr("disabled", self.loading && n !== page)}
        data-click="${on(function () { return n === page ? undefined : self.go(n); })}">${Frp.n0(n)}</button>`;
        })}
        ${arrow("›", "Next page", page + 1, page === pages)}
        ${arrow("»", "Last page", pages, page === pages)}
    </div>` : ""}
</nav>`;
    };

    /** A skeleton while something loads. */
    C.loading = function (classes, label) {
        return html`<div class="${classes} animate-pulse rounded-app bg-line/60" aria-busy="true"${label ? Frp.raw(" aria-label=\"" + Frp.esc(label) + "\"") : ""}></div>`;
    };

    C.historyDot = function (action) {
        switch (action) {
            case "Approved":
            case "Approved submission downloaded":
                return "bg-emerald-600";
            case "Returned for changes":
            case "Action refused":
            case "Reopened (approval voided)":
                return "bg-amber-500";
            case "Submitted for review":
                return "bg-accent";
            default:
                return "bg-slate-300";
        }
    };

    /** Shown instead of a page the person's roles do not allow (or when they have no role at all). */
    C.accessDenied = function () {
        var session = Frp.session;
        var user = session.user;
        var roles = user.roles;
        var body;
        if (user.accessUnavailable) {
            body = html`<h1 class="mt-2 font-display text-3xl font-bold tracking-tight text-ink">Your roles could not be checked</h1>
    <p class="mt-3 max-w-prose text-base leading-7 text-muted">
        You are signed in as <strong class="text-ink">${user.name}</strong>, but the FRP Mapper API cannot be reached,
        so your roles could not be read from the database. Try again in a moment; if it keeps happening, contact your administrator.
    </p>`;
        } else if (user.userDisabled) {
            body = html`<h1 class="mt-2 font-display text-3xl font-bold tracking-tight text-ink">Your access is disabled</h1>
    <p class="mt-3 max-w-prose text-base leading-7 text-muted">
        You are signed in as <strong class="text-ink">${user.name}</strong>, but the SRAU team has disabled your FRP Mapper access.
        Contact SRAU if you need it again.
    </p>`;
        } else if (user.roleConflict) {
            body = html`<h1 class="mt-2 font-display text-3xl font-bold tracking-tight text-ink">Your roles cannot be combined</h1>
    <p class="mt-3 max-w-prose text-base leading-7 text-muted">
        You are signed in as <strong class="text-ink">${user.name}</strong>, but the roles you hold together break the segregation
        of duties, so none of them is given: ${user.roleConflict} Ask SRAU to correct your roles.
    </p>`;
        } else if (!roles.length) {
            body = html`<h1 class="mt-2 font-display text-3xl font-bold tracking-tight text-ink">You don’t have access yet</h1>
    <p class="mt-3 max-w-prose text-base leading-7 text-muted">
        You are signed in as <strong class="text-ink">${user.name}</strong>, but you have no FRP Mapper role.
        Ask your administrator to add you to the group for the role you need.
    </p>
    ${session.catalog ? C.roleGroupList(session.catalog.roles) : ""}`;
        } else {
            var admin = !Frp.can(Frp.Permissions.ProjectRead) && Frp.Administration.some(Frp.can);
            body = html`<h1 class="mt-2 font-display text-3xl font-bold tracking-tight text-ink">This page is not available to your role</h1>
    <p class="mt-3 max-w-prose text-base leading-7 text-muted">
        You are signed in as <strong class="text-ink">${user.name}</strong> (${roles.join(", ")}).
        The action you tried needs a permission your roles do not have.
    </p>
    ${admin ? html`<a class="mt-6 inline-flex h-10 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover" href="admin/access">
        <i class="ph ph-users-three"></i> Go to access administration
    </a>` : html`<a class="mt-6 inline-flex h-10 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover" href="">
        <i class="ph ph-arrow-left"></i> Back to projects
    </a>`}`;
        }

        return html`<div class="px-6 py-10 lg:px-10">
    <p class="text-sm font-semibold text-accent">Access</p>
    ${body}
</div>`;
    };

    /** The menu on the left (top on small screens), with the person and the sign-out button. */
    C.navMenu = function (path) {
        var P = Frp.Permissions;
        var session = Frp.session;
        var user = session.user;
        var linkClass = "flex shrink-0 items-center gap-2.5 rounded-app px-3 py-2 text-sm font-medium text-muted transition hover:bg-canvas hover:text-ink";

        function link(href, icon, label, exact) {
            var active = exact ? path === href || (href === "" && path === "projects") : path === href || path.indexOf(href + "/") === 0;
            return html`<a class="${linkClass}${active ? " !bg-accent-soft !text-accent" : ""}" href="${href}"${active ? Frp.raw(" aria-current=\"page\"") : ""}>
            <i class="ph ${icon} text-lg"></i> ${label}
        </a>`;
        }

        var reports = [P.UsersManage, P.UsersApprove, P.RolesManage, P.RolesApprove, P.ReferenceManage, P.ReferenceApprove].some(Frp.can);
        var previous = user.previousSignInAt;
        var failed = user.failedSinceLast || 0;
        var signOut = session.mode === "Development" || session.mode === "ActiveDirectory";
        return html`<aside class="flex flex-col border-b border-line bg-surface lg:sticky lg:top-0 lg:h-screen lg:border-b-0 lg:border-r print:hidden">
    <a class="flex items-center gap-3 px-5 py-5" href="">
        <span class="grid h-9 w-9 place-items-center rounded-app bg-accent text-white" aria-hidden="true"><i class="ph ph-table text-lg"></i></span>
        <span>
            <strong class="block font-display text-base font-bold leading-5 text-ink">FRP Mapper</strong>
            <span class="block text-xs text-subtle">BSP submissions</span>
        </span>
    </a>
    <nav class="flex gap-1 overflow-x-auto px-3 pb-3 lg:flex-col lg:overflow-visible lg:pb-0" aria-label="Main">
        ${Frp.can(P.ProjectRead) ? link("", "ph-folders", "Projects", true) : ""}
        ${Frp.can(P.ProjectCreate) ? link("projects/new", "ph-plus-circle", "New project") : ""}
        ${Frp.can(P.ProjectRead) ? link("validate", "ph-seal-check", "Validate") : ""}
        ${Frp.can(P.AuditReadAll) ? link("audit", "ph-clock-counter-clockwise", "Audit trail") : ""}
        ${Frp.can(P.SubmissionPrepare) || Frp.can(P.ReferenceManage) || Frp.can(P.ReferenceApprove) ? link("sandbox", "ph-paper-plane-tilt", "BSP submission") : ""}
        ${Frp.can(P.ReferenceManage) || Frp.can(P.ReferenceApprove) ? link("Pages/BankProfiles.aspx", "ph-bank", "Bank profiles") : ""}
        ${Frp.Administration.some(Frp.can) ? link("admin/access", "ph-users-three", "Access administration") : ""}
        ${reports ? link("reports", "ph-table", "Reports") : ""}
        ${link("access", "ph-shield-check", "Roles & access")}
    </nav>
    <div class="flex items-center justify-between gap-4 border-t border-line px-5 py-3 lg:mt-auto lg:block lg:py-4">
        <div class="min-w-0">
            <p class="truncate text-sm font-semibold text-ink" title="${user.name}">${user.name}</p>
            <p class="mt-0.5 text-xs text-subtle">${user.roles.length ? user.roles.join(" · ") : "No role"}</p>
            ${user.failedSinceLast !== null && user.failedSinceLast !== undefined ? html`
                <p class="mt-1 text-xs text-subtle">${previous ? "Last sign-in: " + Frp.date(previous, true) : "First sign-in"}</p>
                ${failed > 0 ? html`<p class="mt-0.5 text-xs font-semibold text-amber-800" role="status">${failed} failed sign-in attempt${failed === 1 ? "" : "s"} since then</p>` : ""}` : ""}
        </div>
        ${signOut ? html`<form id="frp-signout" method="post" action="account/signout" class="shrink-0 lg:mt-3" data-native="true">
            <input type="hidden" name="reason" value="" />
            <input type="hidden" name="__RequestVerificationToken" value="${session.csrf}" />
            <button class="inline-flex items-center gap-1.5 text-xs font-semibold text-muted transition hover:text-accent">
                <i class="ph ph-sign-out"></i> ${session.mode === "Development" ? "Switch test user" : "Sign out"}
            </button>
        </form>` : html`<p class="shrink-0 text-xs text-subtle lg:mt-3">Signed in with Windows</p>`}
    </div>
</aside>`;
    };
})();
