using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace FrpMapper.Api.Hosting
{
    /// <summary>An uploaded file (stand-in for ASP.NET Core's IFormFile, so the business code is unchanged).</summary>
    public interface IFormFile
    {
        /// <summary>The form field's name (e.g. xsdFile).</summary>
        string Name { get; }

        /// <summary>The file's name as the browser sent it (without any folder).</summary>
        string FileName { get; }

        string ContentType { get; }

        long Length { get; }

        Stream OpenReadStream();

        Task CopyToAsync(Stream target, CancellationToken cancellationToken = default(CancellationToken));
    }

    /// <summary>A file posted in a multipart/form-data request (System.Web's HttpPostedFile).</summary>
    public sealed class PostedFormFile : IFormFile
    {
        private readonly HttpPostedFileBase file;

        public PostedFormFile(string name, HttpPostedFileBase file)
        {
            Name = name;
            this.file = file;
        }

        public string Name { get; private set; }

        public string FileName
        {
            // Older browsers send the full path; only the name is kept.
            get { return Path.GetFileName(file.FileName ?? ""); }
        }

        public string ContentType
        {
            get { return file.ContentType ?? "application/octet-stream"; }
        }

        public long Length
        {
            get { return file.ContentLength; }
        }

        public Stream OpenReadStream()
        {
            var stream = file.InputStream;
            stream.Position = 0;
            // The caller may dispose it; the request still owns the original.
            return new NonClosingStream(stream);
        }

        public Task CopyToAsync(Stream target, CancellationToken cancellationToken = default(CancellationToken))
        {
            var stream = file.InputStream;
            stream.Position = 0;
            return stream.CopyToAsync(target, 81920, cancellationToken);
        }

        /// <summary>A view of a stream that ignores Dispose (so the upload can be read again).</summary>
        private sealed class NonClosingStream : Stream
        {
            private readonly Stream inner;

            public NonClosingStream(Stream inner)
            {
                this.inner = inner;
            }

            public override bool CanRead { get { return inner.CanRead; } }

            public override bool CanSeek { get { return inner.CanSeek; } }

            public override bool CanWrite { get { return false; } }

            public override long Length { get { return inner.Length; } }

            public override long Position
            {
                get { return inner.Position; }
                set { inner.Position = value; }
            }

            public override void Flush()
            {
            }

            public override int Read(byte[] buffer, int offset, int count)
            {
                return inner.Read(buffer, offset, count);
            }

            public override Task<int> ReadAsync(byte[] buffer, int offset, int count, CancellationToken cancellationToken)
            {
                return inner.ReadAsync(buffer, offset, count, cancellationToken);
            }

            public override long Seek(long offset, SeekOrigin origin)
            {
                return inner.Seek(offset, origin);
            }

            public override void SetLength(long value)
            {
                throw new NotSupportedException();
            }

            public override void Write(byte[] buffer, int offset, int count)
            {
                throw new NotSupportedException();
            }
        }
    }

    /// <summary>A file held in memory (tests and internal calls).</summary>
    public sealed class MemoryFormFile : IFormFile
    {
        private readonly byte[] content;

        public MemoryFormFile(string name, string fileName, byte[] content, string contentType = "application/octet-stream")
        {
            Name = name;
            FileName = fileName;
            this.content = content;
            ContentType = contentType;
        }

        public string Name { get; private set; }

        public string FileName { get; private set; }

        public string ContentType { get; private set; }

        public long Length
        {
            get { return content.Length; }
        }

        public Stream OpenReadStream()
        {
            return new MemoryStream(content, false);
        }

        public Task CopyToAsync(Stream target, CancellationToken cancellationToken = default(CancellationToken))
        {
            return target.WriteAsync(content, 0, content.Length, cancellationToken);
        }
    }

    public static class StatusCodes
    {
        public const int Status200OK = 200;
        public const int Status204NoContent = 204;
        public const int Status400BadRequest = 400;
        public const int Status401Unauthorized = 401;
        public const int Status403Forbidden = 403;
        public const int Status404NotFound = 404;
        public const int Status405MethodNotAllowed = 405;
        public const int Status409Conflict = 409;
        public const int Status413PayloadTooLarge = 413;
        public const int Status500InternalServerError = 500;
    }

    /// <summary>A request that cannot be read (too large, malformed form or JSON).</summary>
    public sealed class BadHttpRequestException : Exception
    {
        public BadHttpRequestException(string message, int statusCode = StatusCodes.Status400BadRequest) : base(message)
        {
            StatusCode = statusCode;
        }

        public int StatusCode { get; private set; }
    }
}

namespace FrpMapper.Api.Hosting
{
    /// <summary>
    /// A file read from a stream (as ASP.NET Core's FormFile: a stored upload reused as if it were uploaded again).
    /// The stream belongs to the caller.
    /// </summary>
    public sealed class FormFile : IFormFile
    {
        private readonly System.IO.Stream stream;
        private readonly long offset;

        public FormFile(System.IO.Stream baseStream, long baseStreamOffset, long length, string name, string fileName)
        {
            stream = baseStream;
            offset = baseStreamOffset;
            Length = length;
            Name = name;
            FileName = fileName;
        }

        public string Name { get; private set; }

        public string FileName { get; private set; }

        public string ContentType
        {
            get { return "application/octet-stream"; }
        }

        public long Length { get; private set; }

        public System.IO.Stream OpenReadStream()
        {
            stream.Position = offset;
            var copy = new System.IO.MemoryStream();
            stream.CopyTo(copy);
            copy.Position = 0;
            return copy;
        }

        public System.Threading.Tasks.Task CopyToAsync(System.IO.Stream target, System.Threading.CancellationToken cancellationToken = default(System.Threading.CancellationToken))
        {
            stream.Position = offset;
            return stream.CopyToAsync(target, 81920, cancellationToken);
        }
    }
}
