using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using FrpMapper.Api.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Http;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Hosting
{
    /// <summary>
    /// Every API request (web.config maps all paths here): the .NET 9 version's middleware pipeline, in the same order.
    /// 1. Only GET, HEAD, POST, PUT and DELETE (others 405).
    /// 2. Security and no-cache headers.
    /// 3. Upload size limit (FileStorage:MaxUploadMegabytes).
    /// 4. The caller from the internal API key (<see cref="PlatformTrustAuthentication"/>).
    /// 5. The route and its authorization policies (401 without a caller, 403 without the permission).
    /// 6. The bank profiles for project requests (BankReferenceContext).
    /// 7. The endpoint. Workflow rules become 403 / 409 / 400 with their message; anything else is logged and gets a
    ///    generic message (no stack traces, file paths or XML/SQL details reach the client).
    /// </summary>
    public sealed class ApiHandler : HttpTaskAsyncHandler
    {
        public override bool IsReusable
        {
            get { return true; }
        }

        public override Task ProcessRequestAsync(HttpContext context)
        {
            return ApiPipeline.ProcessAsync(new HttpContextWrapper(context));
        }
    }

    /// <summary>The request pipeline (see <see cref="ApiHandler"/>), on System.Web's abstractions so it can also be hosted in tests.</summary>
    public static class ApiPipeline
    {
        private static readonly HashSet<string> AllowedMethods = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "GET", "HEAD", "POST", "PUT", "DELETE" };

        public static async Task ProcessAsync(HttpContextBase context)
        {
            var request = context.Request;
            var response = context.Response;
            if (!AllowedMethods.Contains(request.HttpMethod))
            {
                response.StatusCode = StatusCodes.Status405MethodNotAllowed;
                response.AddHeader("Allow", "GET, HEAD, POST, PUT, DELETE");
                return;
            }

            response.AddHeader("X-Content-Type-Options", "nosniff");
            response.AddHeader("X-Frame-Options", "DENY");
            response.AddHeader("Referrer-Policy", "no-referrer");
            // API responses carry project data and access details: never cached.
            response.Cache.SetCacheability(HttpCacheability.NoCache);
            response.Cache.SetNoStore();
            response.AppendHeader("Pragma", "no-cache");

            var services = ApiApplication.Services;
            var cancellation = response.ClientDisconnectedToken;
            using (var scope = services.CreateScope())
            {
                try
                {
                    await HandleAsync(context, scope, cancellation);
                }
                catch (Exception ex)
                {
                    if (ex is OperationCanceledException && cancellation.IsCancellationRequested)
                    {
                        return;
                    }

                    var error = ApiErrors.Map(ex);
                    if (error.Status == StatusCodes.Status500InternalServerError)
                    {
                        ApiApplication.Logger.LogError(ex, "Unhandled error for {Path}", request.Path);
                    }
                    else if (ex is System.Xml.XmlException)
                    {
                        ApiApplication.Logger.LogWarning(ex, "Refused XML in a request to {Path}", request.Path);
                    }

                    if (!response.HeadersWritten)
                    {
                        response.ClearContent();
                        await Results.Json(error.Status, new { message = error.Message }).WriteAsync(context);
                    }
                }
                finally
                {
                    RequestPrincipal.Current = null;
                }
            }
        }

        private static async Task HandleAsync(HttpContextBase context, ServiceProvider scope, CancellationToken cancellation)
        {
            var request = context.Request;

            // Upload size limits follow FileStorage:MaxUploadMegabytes. A request may carry up to three files (XSD,
            // template, specification) plus form fields.
            if (request.ContentType != null && request.ContentType.StartsWith("multipart/form-data", StringComparison.OrdinalIgnoreCase))
            {
                var maxUploadBytes = scope.GetRequiredService<IOptionsMonitor<FileStorageOptions>>().CurrentValue.MaxUploadBytes;
                if (request.ContentLength > maxUploadBytes * 3 + 1024 * 1024)
                {
                    throw new BadHttpRequestException("The request is too large.", StatusCodes.Status413PayloadTooLarge);
                }
            }

            // The caller: the Platform's internal API key, the user and roles it forwards (or nobody).
            var outcome = await scope.GetRequiredService<PlatformTrustAuthentication>().AuthenticateAsync(request.Headers, cancellation);
            var user = outcome.Principal ?? new ClaimsPrincipal(new ClaimsIdentity());
            RequestPrincipal.Current = user;
            context.User = user;

            IDictionary<string, string> routeValues;
            bool pathExists;
            var path = request.Path;
            var endpoint = ApiApplication.Routes.Match(request.HttpMethod, path, out routeValues, out pathExists);
            if (endpoint == null)
            {
                if (pathExists)
                {
                    context.Response.StatusCode = StatusCodes.Status405MethodNotAllowed;
                    context.Response.AddHeader("Allow", string.Join(", ", ApiApplication.Routes.MethodsFor(path)));
                }
                else
                {
                    context.Response.StatusCode = StatusCodes.Status404NotFound;
                }

                return;
            }

            if (!endpoint.Anonymous)
            {
                var policies = endpoint.Policies.Count == 0 ? new[] { Policies.Default } : endpoint.Policies.ToArray();
                if (!Authorization.IsAuthenticated(user))
                {
                    context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                    return;
                }

                if (!policies.All(p => Authorization.Satisfies(user, p)))
                {
                    context.Response.StatusCode = StatusCodes.Status403Forbidden;
                    return;
                }
            }

            // Project requests get the bank profiles (and the sample bank chosen with ?bank=).
            if (path.StartsWith("/api/projects", StringComparison.OrdinalIgnoreCase) && user.HasClaim(AppClaimTypes.Permission, Permissions.ProjectRead))
            {
                var reference = scope.GetRequiredService<BankReferenceContext>();
                reference.Data = await scope.GetRequiredService<IReferenceDataRepository>().ReadAsync(cancellation);
                var bank = request.Unvalidated.QueryString["bank"];
                reference.SampleBankKey = string.IsNullOrEmpty(bank) ? null : bank;
                if (reference.SampleBankKey != null && reference.SampleBank == null)
                {
                    throw new WorkflowException(WorkflowErrorKind.Invalid, "The selected bank profile does not exist.");
                }
            }

            var apiRequest = new ApiRequest(context, routeValues, scope, user, cancellation);
            var result = await endpoint.Handler(apiRequest);
            if (result != null)
            {
                await result.WriteAsync(context);
            }
        }
    }
}
