﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Api.Models
{
    /// <summary>
    /// "SignIn" in appsettings.json: the lockout and inactivity rules of the Application Security Checklist.
    /// </summary>
    public sealed class SignInOptions
    {
        public const string SectionName = "SignIn";

        /// <summary>Failed sign-ins in a row that lock an account (1 to 3; the checklist allows at most 3).</summary>
        public int MaxFailedAttempts { get; set; } = 3;

        /// <summary>How long an administrator account (SRAU or PARAM) cannot sign in after that many failures, instead of a lockout (at least 5).</summary>
        public int AdministratorDelayMinutes { get; set; } = 5;

        /// <summary>Days without a sign-in after which an account is deactivated (1 to 30). 0 turns the rule off, allowed only in Development.</summary>
        public int InactiveDays { get; set; } = 30;
    }

    public sealed class SignInOptionsValidator: FrpMapper.Shared.Hosting.IValidateOptions<SignInOptions>
    {
        private readonly IHostEnvironment environment;

        public SignInOptionsValidator(IHostEnvironment environment)
    {
        this.environment = environment;
    }
        public FrpMapper.Shared.Hosting.ValidateOptionsResult Validate(string name, SignInOptions options)
        {
            var errors = new List<string>();
            if (options.MaxFailedAttempts < 1 || options.MaxFailedAttempts > 3)
            {
                errors.Add("SignIn:MaxFailedAttempts must be between 1 and 3.");
            }

            if (options.AdministratorDelayMinutes < 5 || options.AdministratorDelayMinutes > 1440)
            {
                errors.Add("SignIn:AdministratorDelayMinutes must be between 5 and 1440.");
            }

            if (options.InactiveDays < 0 || options.InactiveDays > 30 || options.InactiveDays == 0 && !environment.IsDevelopment())
            {
                errors.Add("SignIn:InactiveDays must be between 1 and 30 (0, which turns the rule off, only in Development).");
            }

            return errors.Count == 0
                ? FrpMapper.Shared.Hosting.ValidateOptionsResult.Success
                : FrpMapper.Shared.Hosting.ValidateOptionsResult.Fail(errors);
        }
    }

}
