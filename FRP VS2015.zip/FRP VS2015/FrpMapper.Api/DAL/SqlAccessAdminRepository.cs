﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL.Sql;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.DAL
{
    public sealed class SqlAccessAdminRepository: IAccessAdminRepository
    {
        private readonly ISqlConnectionFactory connections;

        public SqlAccessAdminRepository(ISqlConnectionFactory connections)
    {
        this.connections = connections;
    }
        private static readonly JsonSerializerOptions Json = new JsonSerializerOptions(JsonSerializerDefaults.Web);

        public async Task<AccessAdministrationDto> GetAsync(int decidedTake, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            using (var reader = await connection.QueryMultipleAsync(new CommandDefinition(
                "frp.usp_AccessAdmin_Get",
                new { RequestTake = decidedTake },
                commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds,
                cancellationToken: cancellationToken)))
            {
            var roles = (await reader.ReadAsync<RoleRow>()).ToList();
            var permissions = (await reader.ReadAsync<PermissionRow>()).ToList();
            var grants = Lookup(await reader.ReadAsync<KeyPairRow>());
            var groups = Lookup(await reader.ReadAsync<KeyPairRow>());
            var users = (await reader.ReadAsync<UserRow>()).ToList();
            var userRoles = Lookup(await reader.ReadAsync<KeyPairRow>());
            var requests = (await reader.ReadAsync<RequestRow>()).ToList();
            var signIns = (await reader.ReadAsync<SignInRow>())
                .GroupBy(s => s.UserName, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.Max(s => s.LastSignInAt), StringComparer.OrdinalIgnoreCase);

            return new AccessAdministrationDto
            {
                Roles = roles.Where(r => !r.IsDeleted).Select(r => { IReadOnlyList<string> p; IReadOnlyList<string> g; return new AdminRoleDto
                {
                    Key = r.RoleKey,
                    DisplayName = r.DisplayName,
                    Description = r.Description,
                    IsActive = r.IsActive,
                    Permissions = grants.TryGetValue(r.RoleKey, out p) ? p : new List<string>(),
                    DirectoryGroups = groups.TryGetValue(r.RoleKey, out g) ? g : new List<string>()
                }; }).ToList(),
                DeletedRoleKeys = roles.Where(r => r.IsDeleted).Select(r => r.RoleKey).ToList(),
                Permissions = permissions.Select(p => new AppPermissionDto { Key = p.PermissionKey, DisplayName = p.DisplayName }).ToList(),
                Users = users.Select(u => { IReadOnlyList<string> keys; DateTimeOffset last; DateTime until; return new AdminUserDto
                {
                    UserName = u.UserName,
                    DisplayName = u.DisplayName,
                    IsActive = u.IsActive,
                    Roles = userRoles.TryGetValue(u.UserName, out keys) ? keys : new List<string>(),
                    UpdatedAtUtc = DateTime.SpecifyKind(u.UpdatedAtUtc, DateTimeKind.Utc),
                    UpdatedBy = u.UpdatedBy,
                    LastSignInAt = signIns.TryGetValue(u.UserName, out last) ? (DateTimeOffset?)last : (DateTimeOffset?)null,
                    DisabledReason = u.DisabledReasonKey,
                    Department = u.Department,
                    AccessUntil = CompatPattern.Is(u.AccessUntil, out until) ? (DateOnly?)DateOnly.FromDateTime(until) : (DateOnly?)null,
                    CreatedAtUtc = DateTime.SpecifyKind(u.CreatedAtUtc, DateTimeKind.Utc)
                }; }).ToList(),
                Requests = requests.Select(ToDto).ToList(),
                OtherSignIns = signIns
                    .Where(s => !users.Any(u => string.Equals(u.UserName, s.Key, StringComparison.OrdinalIgnoreCase)))
                    .Select(s => new SignInSeenDto { UserName = s.Key, LastSignInAt = s.Value })
                    .OrderBy(s => s.UserName, StringComparer.OrdinalIgnoreCase)
                    .ToList()
            };
            }
            }
        }

        public async Task<AccessChangeRequestDto> CreateRequestAsync(AccessChangeRequestDto request, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var parameters = new DynamicParameters();
            parameters.Add("@RequestId", request.Id, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@Team", request.Team, DbType.AnsiString, size: 10);
            parameters.Add("@Kind", request.Kind, DbType.AnsiString, size: 10);
            parameters.Add("@TargetKey", request.TargetKey, DbType.String, size: 256);
            parameters.Add("@Summary", request.Summary, DbType.String, size: 2000);
            parameters.Add("@Payload", Payload(request), DbType.String, size: -1);
            parameters.Add("@RequestedBy", request.RequestedBy, DbType.String, size: 256);
            parameters.Add("@RequestedAt", request.RequestedAt);
            try
            {
                var version = await connection.ExecuteScalarAsync<byte[]>(new CommandDefinition(
                    "frp.usp_AccessChange_Create", parameters, commandType: CommandType.StoredProcedure,
                    commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                return request.With(copy => { copy.Version = Convert.ToBase64String(version ?? new byte[0]); });
            }
            catch (SqlException ex) when (Has(ex, DatabaseErrors.AccessRequestOpen))
            {
                throw new AccessRequestOpenException(ex.Message);
            }
            }
        }

        public async Task<bool> DecideAsync(AccessChangeRequestDto request, byte[] expectedVersion, string decision, string decidedBy, DateTimeOffset decidedAt,
            string comment, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var user = request.User;
            var role = request.Role;
            var parameters = new DynamicParameters();
            parameters.Add("@RequestId", request.Id, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@ExpectedRowVersion", expectedVersion, DbType.Binary, size: 8);
            parameters.Add("@Decision", decision, DbType.AnsiString, size: 10);
            parameters.Add("@DecidedBy", decidedBy, DbType.String, size: 256);
            parameters.Add("@DecidedAt", decidedAt);
            parameters.Add("@Comment", comment, DbType.String, size: 1000);
            parameters.Add("@UserName", user?.UserName, DbType.String, size: 256);
            parameters.Add("@UserDisplayName", user?.DisplayName, DbType.String, size: 200);
            parameters.Add("@UserIsActive", user?.IsActive, DbType.Boolean);
            parameters.Add("@UserRoles", Keys(user?.Roles).AsTableValuedParameter("frp.KeyListTableType"));
            parameters.Add("@RoleKey", role?.Key ?? request.Groups?.RoleKey, DbType.AnsiString, size: 50);
            parameters.Add("@RoleDisplayName", role?.DisplayName, DbType.String, size: 100);
            parameters.Add("@RoleDescription", role?.Description, DbType.String, size: 500);
            parameters.Add("@RoleIsActive", role?.IsActive, DbType.Boolean);
            parameters.Add("@Delete", (user?.Delete ?? false) || (role?.Delete ?? false), DbType.Boolean);
            parameters.Add("@UserDepartment", user?.Department, DbType.String, size: 100);
            parameters.Add("@UserAccessUntil", user?.AccessUntil?.ToDateTime(TimeOnly.MinValue), DbType.Date);
            parameters.Add("@RolePermissions", Keys(role?.Permissions).AsTableValuedParameter("frp.KeyListTableType"));
            parameters.Add("@RoleGroups", Keys(request.Groups?.DirectoryGroups).AsTableValuedParameter("frp.KeyListTableType"));
            try
            {
                await connection.ExecuteAsync(new CommandDefinition(
                    "frp.usp_AccessChange_Decide", parameters, commandType: CommandType.StoredProcedure,
                    commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                return true;
            }
            catch (SqlException ex) when (Has(ex, DatabaseErrors.NotFound))
            {
                return false;
            }
            catch (SqlException ex) when (Has(ex, DatabaseErrors.ConcurrencyConflict))
            {
                throw new ConcurrencyConflictException(ex.Message);
            }
            catch (SqlException ex) when (Has(ex, DatabaseErrors.AccessDecisionRefused))
            {
                throw new AccessDecisionRefusedException(ex.Message);
            }
            }
        }

        private static bool Has(SqlException ex, int number) => ex.Errors.Cast<SqlError>().Any(e => e.Number == number);

        private static string Payload(AccessChangeRequestDto request) =>
            JsonSerializer.Serialize(new RequestPayload(request.User, request.Role, request.Groups, request.UserBefore, request.RoleBefore, request.GroupsBefore), Json);

        internal static AccessChangeRequestDto ToDto(RequestRow row)
        {
            var payload = JsonSerializer.Deserialize<RequestPayload>(row.Payload, Json);
            return new AccessChangeRequestDto
            {
                Id = row.RequestId,
                Team = row.Team,
                Kind = row.Kind,
                TargetKey = row.TargetKey,
                Summary = row.Summary,
                Status = row.StatusKey,
                User = payload?.User,
                Role = payload?.Role,
                Groups = payload?.Groups,
                UserBefore = payload?.UserBefore,
                RoleBefore = payload?.RoleBefore,
                GroupsBefore = payload?.GroupsBefore,
                RequestedBy = row.RequestedBy,
                RequestedAt = row.RequestedAt,
                DecidedBy = row.DecidedBy,
                DecidedAt = row.DecidedAt,
                DecisionComment = row.DecisionComment,
                Version = Convert.ToBase64String(row.RowVersion)
            };
        }

        private static DataTable Keys(IEnumerable<string> values)
        {
            var table = new DataTable();
            table.Columns.Add("Value", typeof(string));
            foreach (var value in (values ?? new List<string>()).Distinct(StringComparer.OrdinalIgnoreCase))
            {
                table.Rows.Add(value);
            }

            return table;
        }

        private static Dictionary<string, IReadOnlyList<string>> Lookup(IEnumerable<KeyPairRow> rows) => rows
            .GroupBy(r => r.Owner, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => (IReadOnlyList<string>)g.Select(r => r.Value).ToList(), StringComparer.OrdinalIgnoreCase);

        private sealed class RequestPayload : IRecord<RequestPayload>, IEquatable<RequestPayload>
    {
        public UserChangeDto User { get; set; }

        public RoleChangeDto Role { get; set; }

        public RoleGroupsChangeDto Groups { get; set; }

        public UserChangeDto UserBefore { get; set; }

        public RoleChangeDto RoleBefore { get; set; }

        public RoleGroupsChangeDto GroupsBefore { get; set; }

        public RequestPayload(UserChangeDto User, RoleChangeDto Role, RoleGroupsChangeDto Groups = null, UserChangeDto UserBefore = null, RoleChangeDto RoleBefore = null, RoleGroupsChangeDto GroupsBefore = null)
    {
    this.User = User;
    this.Role = Role;
    this.Groups = Groups;
    this.UserBefore = UserBefore;
    this.RoleBefore = RoleBefore;
    this.GroupsBefore = GroupsBefore;
    }

        public void Deconstruct(out UserChangeDto User, out RoleChangeDto Role, out RoleGroupsChangeDto Groups, out UserChangeDto UserBefore, out RoleChangeDto RoleBefore, out RoleGroupsChangeDto GroupsBefore)
    {
    User = this.User;
    Role = this.Role;
    Groups = this.Groups;
    UserBefore = this.UserBefore;
    RoleBefore = this.RoleBefore;
    GroupsBefore = this.GroupsBefore;
    }

        public bool Equals(RequestPayload other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<UserChangeDto>.Default.Equals(User, other.User)
    && EqualityComparer<RoleChangeDto>.Default.Equals(Role, other.Role)
    && EqualityComparer<RoleGroupsChangeDto>.Default.Equals(Groups, other.Groups)
    && EqualityComparer<UserChangeDto>.Default.Equals(UserBefore, other.UserBefore)
    && EqualityComparer<RoleChangeDto>.Default.Equals(RoleBefore, other.RoleBefore)
    && EqualityComparer<RoleGroupsChangeDto>.Default.Equals(GroupsBefore, other.GroupsBefore);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as RequestPayload);
    }

        public static bool operator ==(RequestPayload left, RequestPayload right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(RequestPayload left, RequestPayload right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 3344;
    hash = hash * -1521134295 + EqualityComparer<UserChangeDto>.Default.GetHashCode(User);
    hash = hash * -1521134295 + EqualityComparer<RoleChangeDto>.Default.GetHashCode(Role);
    hash = hash * -1521134295 + EqualityComparer<RoleGroupsChangeDto>.Default.GetHashCode(Groups);
    hash = hash * -1521134295 + EqualityComparer<UserChangeDto>.Default.GetHashCode(UserBefore);
    hash = hash * -1521134295 + EqualityComparer<RoleChangeDto>.Default.GetHashCode(RoleBefore);
    hash = hash * -1521134295 + EqualityComparer<RoleGroupsChangeDto>.Default.GetHashCode(GroupsBefore);
    return hash;
    }
    }

        public override string ToString()
    {
    return "RequestPayload { " + "User = " + User + ", " + "Role = " + Role + ", " + "Groups = " + Groups + ", " + "UserBefore = " + UserBefore + ", " + "RoleBefore = " + RoleBefore + ", " + "GroupsBefore = " + GroupsBefore + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public RequestPayload CloneRecord()
    {
    return (RequestPayload)MemberwiseClone();
    }

    }

        private sealed class SignInRow
        {
            public string UserName { get; set; } = "";
            public DateTimeOffset LastSignInAt { get; set; }
        }

        private sealed class RoleRow
        {
            public string RoleKey { get; set; } = "";
            public string DisplayName { get; set; } = "";
            public string Description { get; set; }
            public int SortOrder { get; set; }
            public bool IsActive { get; set; }
            public bool IsDeleted { get; set; }
        }

        private sealed class PermissionRow
        {
            public string PermissionKey { get; set; } = "";
            public string DisplayName { get; set; } = "";
            public int SortOrder { get; set; }
        }

        /// <summary>A role and a permission, a role and a group, or a person and a role: the first column, then the second.</summary>
        private sealed class KeyPairRow
        {
            public string Owner { get; set; } = "";
            public string Value { get; set; } = "";
        }

        private sealed class UserRow
        {
            public string UserName { get; set; } = "";
            public string DisplayName { get; set; }
            public bool IsActive { get; set; }
            public DateTime UpdatedAtUtc { get; set; }
            public string UpdatedBy { get; set; }
            public string DisabledReasonKey { get; set; }
            public string Department { get; set; }
            public DateTime? AccessUntil { get; set; }
            public DateTime CreatedAtUtc { get; set; }
        }

        internal sealed class RequestRow
        {
            public string RequestId { get; set; } = "";
            public string Team { get; set; } = "";
            public string Kind { get; set; } = "User";
            public string TargetKey { get; set; } = "";
            public string Summary { get; set; } = "";
            public string Payload { get; set; } = "{}";
            public string StatusKey { get; set; } = "";
            public string RequestedBy { get; set; } = "";
            public DateTimeOffset RequestedAt { get; set; }
            public string DecidedBy { get; set; }
            public DateTimeOffset? DecidedAt { get; set; }
            public string DecisionComment { get; set; }
            public byte[] RowVersion { get; set; } = new byte[0];
        }
    }

}
