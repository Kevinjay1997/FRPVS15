using System;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using FrpMapper.Api.BL;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Http;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api
{
    /// <summary>
    /// The API's endpoints (the routes of the .NET 9 version's Program.cs, with the same paths, bodies, answers and
    /// policies). Endpoint → BL service → DAL → stored procedure.
    /// </summary>
    public static class Endpoints
    {
        public static RouteTable Map(RouteTable app)
        {
            // BSP submission (sandbox). Credentials travel only in authenticated, CSRF-protected request bodies, never in URLs.
            app.MapGet("/api/sandbox/banks", async r => Results.Ok(await r.Service<ISandboxService>().BanksAsync(r.CancellationToken)))
                .RequireAuthorization(Permissions.SubmissionPrepare);
            // The approved BSP environments (Sandbox, Production, …) a request can be sent to.
            app.MapGet("/api/sandbox/environments", async r => Results.Ok(await r.Service<ISandboxService>().EnvironmentsAsync(r.CancellationToken)))
                .RequireAuthorization(Permissions.SubmissionPrepare);
            app.MapPost("/api/sandbox/{operation}", async r =>
            {
                // The environment, bank profile and certificate are selected separately; an edited reportInfo is forwarded as JSON.
                var request = new SandboxRequest {
                    Operation = r.Route("operation"), UseStoredCertificate = r.Form["certificateSource"] == "stored",
                    Certificate = r.File("certificate"), Password = r.Form["password"],
                    BankKey = r.Form["bank"], Xml = r.File("file"), ReportCode = r.Form["reportCode"],
                    Period = r.Form["period"], ReportInfo = r.Form["reportInfo"], Environment = r.Form["environment"],
                    ConfirmEnvironment = r.Form["confirmEnvironment"],
                    SubmissionId = r.Form["submissionId"], ProjectId = r.Form["project"], Source = r.Form["source"], Workbook = r.File("workbookFile")
                };
                var service = r.Service<ISandboxService>();
                // Validate page: send the XML it checked to a BSP test environment, then read BSP's validation result.
                if (request.Operation == "validate") return Results.Ok(await service.ValidateAsync(request, r.CancellationToken));
                if (request.Operation == "parameters") return Results.Ok(await service.ParametersAsync(request, r.CancellationToken));
                if (request.Operation == "findings") return Results.Ok(await service.FindingsAsync(request, r.CancellationToken));
                if (request.Operation == "certificate") return Results.Ok(await service.InspectAsync(request, r.CancellationToken));
                var result = await service.ExecuteAsync(request, r.CancellationToken);
                if (result.FileBytes != null) return Results.File(result.FileBytes, result.ContentType, result.FileName);
                if (request.Operation != "submit" && request.Operation != "status")
                    return Results.Json(502, new { message = "BSP did not return a download (HTTP " + result.StatusCode + ").", bspResponse = result.Body });
                return Results.Ok(result);
            }).RequireAuthorization(Permissions.SubmissionPrepare);

            // ---------- reference data (bank profiles) ----------

            // Each bank profile's BSP certificate: a Maker uploads it, a different Checker approves it. Only its details are
            // ever returned; the PFX and password stay encrypted on the server.
            app.MapGet("/api/reference/certificates", async r => Results.Ok(await r.Service<IBankCertificateService>().ListAsync(r.CancellationToken)))
                .RequireAuthorization(Policies.SignedInUser);
            app.MapPost("/api/reference/certificates", async r =>
                    Results.Ok(await r.Service<IBankCertificateService>().UploadAsync(r.Form["bank"], r.File("certificate"), r.Form["password"], r.CancellationToken)))
                .RequireAuthorization(Permissions.ReferenceManage);
            app.MapPost("/api/reference/certificates/{certificateId}/{decision}", async r =>
            {
                var decision = r.Route("decision");
                if (decision != "approve" && decision != "reject" && decision != "cancel" && decision != "remove")
                {
                    return Results.NotFound();
                }

                var body = await r.ReadJsonAsync<AccessDecisionRequest>();
                return await r.Service<IBankCertificateService>().DecideAsync(r.Route("certificateId"), decision, body, r.CancellationToken)
                    ? Results.NoContent()
                    : Results.NotFound();
            }).RequireAuthorization(Policies.SignedInUser);

            // BSP environments (BSP submission, Settings tab): a Maker proposes, a different Checker approves. Hosts come from
            // the API's Bsp:AllowedHosts only.
            app.MapGet("/api/reference/bsp-environments", async r => Results.Ok(await r.Service<ISubmissionEnvironmentService>().ListAsync(r.CancellationToken)))
                .RequireAuthorization(Policies.SignedInUser);
            app.MapPost("/api/reference/bsp-environments", async r =>
                    Results.Ok(await r.Service<ISubmissionEnvironmentService>().RequestAsync(await r.ReadJsonAsync<SubmissionEnvironmentRequest>(), r.CancellationToken)))
                .RequireAuthorization(Permissions.ReferenceManage);
            app.MapPost("/api/reference/bsp-environments/{environmentId}/{decision}", async r =>
            {
                var decision = r.Route("decision");
                if (decision != "approve" && decision != "reject" && decision != "cancel" && decision != "remove")
                {
                    return Results.NotFound();
                }

                var body = await r.ReadJsonAsync<AccessDecisionRequest>();
                return await r.Service<ISubmissionEnvironmentService>().DecideAsync(r.Route("environmentId"), decision, body, r.CancellationToken)
                    ? Results.NoContent()
                    : Results.NotFound();
            }).RequireAuthorization(Policies.SignedInUser);

            app.MapGet("/api/reference", async r => Results.Ok(await r.Service<IReferenceDataService>().ReadAsync(r.CancellationToken)))
                .RequireAuthorization(Permissions.ProjectRead);
            // Bank profiles follow Maker / Checker: the Maker requests a change, a Checker approves it (or the Maker cancels it).
            app.MapPost("/api/reference/banks/requests", async r =>
                    Results.Ok(await r.Service<IReferenceDataService>().RequestBankChangeAsync(await r.ReadJsonAsync<BankProfileDto>(), r.CancellationToken)))
                .RequireAuthorization(Permissions.ReferenceManage);
            app.MapPost("/api/reference/banks/requests/{requestId}/{decision}", async r =>
            {
                var status = DecisionStatus(r.Route("decision"));
                if (status == null)
                {
                    return Results.NotFound();
                }

                var body = await r.ReadJsonAsync<AccessDecisionRequest>();
                return await r.Service<IReferenceDataService>().DecideBankChangeAsync(r.Route("requestId"), status, body, r.CancellationToken)
                    ? Results.NoContent()
                    : Results.NotFound();
            }).RequireAuthorization(Policies.SignedInUser);
            app.MapPost("/api/reference/branches", async r =>
            {
                var file = r.File("file");
                if (file == null)
                {
                    throw new WorkflowException(WorkflowErrorKind.Invalid, "Choose a branch file.");
                }

                return Results.Ok(await r.Service<IReferenceDataService>().ReadBranchesAsync(file, r.CancellationToken));
            }).RequireAuthorization(Permissions.ReferenceManage);
            app.MapPost("/api/reference/sandbox", async r =>
            {
                var report = r.File("report");
                if (report == null)
                {
                    throw new WorkflowException(WorkflowErrorKind.Invalid, "Choose a BSP report.");
                }

                var xml = r.File("xml");
                if (xml == null)
                {
                    throw new WorkflowException(WorkflowErrorKind.Invalid, "Choose the corresponding submitted XML.");
                }

                return Results.Ok(await r.Service<IReferenceDataService>().ImportAsync(r.Form["bank"] ?? "", r.Form["project"] ?? "", report, xml,
                    r.Form["save"] == "true", r.CancellationToken));
            }).RequireAuthorization(Permissions.ReferenceManage);

            // ---------- start page and health ----------

            app.MapGet("/", r => Task.FromResult(Results.Content(StartPage, "text/html"))).AllowAnonymous();
            app.MapGet("/api/health", r => Task.FromResult(Results.Ok(new { status = "Healthy", service = "FRP Mapper API" }))).AllowAnonymous();

            app.MapGet("/api/me", r =>
            {
                var user = r.Service<ICurrentUser>();
                return Task.FromResult(Results.Ok(new CurrentUserDto { Name = user.Name, Roles = user.Roles, Permissions = user.Permissions }));
            }).RequireAuthorization(Policies.SignedInUser);

            // ---------- access ----------

            // Roles, permissions, grants and Active Directory groups (the Platform uses them to sign users in and to show them).
            app.MapGet("/api/access/catalog", async r => Results.Ok(await r.Service<IAccessService>().GetCatalogAsync(r.CancellationToken)))
                .RequireAuthorization(Policies.PlatformClient);

            // Access administration: SRAU requests and approves changes to people, PARAM to roles (the service checks which team).
            app.MapGet("/api/admin/access", async r => Results.Ok(await r.Service<IAccessAdminService>().GetAsync(r.CancellationToken)))
                .RequireAuthorization(Policies.SignedInUser);
            app.MapPost("/api/admin/access/users", async r =>
                    Results.Ok(await r.Service<IAccessAdminService>().RequestUserChangeAsync(await r.ReadJsonAsync<UserChangeDto>(), r.CancellationToken)))
                .RequireAuthorization(Policies.SignedInUser);
            app.MapPost("/api/admin/access/roles", async r =>
                    Results.Ok(await r.Service<IAccessAdminService>().RequestRoleChangeAsync(await r.ReadJsonAsync<RoleChangeDto>(), r.CancellationToken)))
                .RequireAuthorization(Policies.SignedInUser);
            app.MapPost("/api/admin/access/groups", async r =>
                    Results.Ok(await r.Service<IAccessAdminService>().RequestGroupsChangeAsync(await r.ReadJsonAsync<RoleGroupsChangeDto>(), r.CancellationToken)))
                .RequireAuthorization(Policies.SignedInUser);
            app.MapGet("/api/admin/access/activity", async r =>
                    Results.Ok(await r.Service<IAccessAdminService>().GetUserActivityAsync(r.Query("user") ?? "", r.CancellationToken)))
                .RequireAuthorization(Policies.SignedInUser);
            app.MapPost("/api/admin/access/requests/{requestId}/{decision}", async r =>
            {
                var status = DecisionStatus(r.Route("decision"));
                var requestId = r.Route("requestId");
                if (status == null || requestId.Length != 32 || !requestId.All(ch => (ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f')))
                {
                    return Results.NotFound();
                }

                var body = await r.ReadJsonAsync<AccessDecisionRequest>();
                return await r.Service<IAccessAdminService>().DecideAsync(requestId, status, body, r.CancellationToken) ? Results.NoContent() : Results.NotFound();
            }).RequireAuthorization(Policies.SignedInUser);

            // The Platform's sign-in page reports each sign-in (and each failed one) for the audit trail and SRAU's activity view.
            // Sign-in rules (lockout, administrator delay, inactivity, one session), for the Platform's sign-in page only.
            app.MapPost("/api/access/sign-ins/check", async r =>
                    Results.Ok(await r.Service<ISignInService>().CheckAsync(await r.ReadJsonAsync<SignInCheckDto>(), r.CancellationToken)))
                .RequireAuthorization(Policies.PlatformClient);
            app.MapPost("/api/access/sign-ins/failed", async r =>
                    Results.Ok(new { outcome = await r.Service<ISignInService>().RecordFailureAsync(await r.ReadJsonAsync<SignInFailedDto>(), r.CancellationToken) }))
                .RequireAuthorization(Policies.PlatformClient);
            app.MapPost("/api/access/sign-ins/blocked", async r =>
            {
                await r.Service<ISignInService>().RecordBlockedAsync(await r.ReadJsonAsync<SignInFailedDto>(), r.CancellationToken);
                return Results.NoContent();
            }).RequireAuthorization(Policies.PlatformClient);
            app.MapPost("/api/access/sign-ins/succeeded", async r =>
                    Results.Ok(await r.Service<ISignInService>().RecordSuccessAsync(await r.ReadJsonAsync<SignInSucceededDto>(), r.CancellationToken)))
                .RequireAuthorization(Policies.PlatformClient);
            app.MapPost("/api/access/sign-ins/session", async r =>
                    Results.Ok(await r.Service<ISignInService>().CheckSessionAsync(await r.ReadJsonAsync<SessionCheckDto>(), r.CancellationToken)))
                .RequireAuthorization(Policies.PlatformClient);
            app.MapPost("/api/access/sign-ins/ended", async r =>
            {
                await r.Service<ISignInService>().EndSessionAsync(await r.ReadJsonAsync<SessionEndDto>(), r.CancellationToken);
                return Results.NoContent();
            }).RequireAuthorization(Policies.PlatformClient);

            // Test users for the Platform's Development sign-in. Only a Development API serves them.
            app.MapGet("/api/access/development-users", async r =>
                    r.Service<IHostEnvironment>().IsDevelopment()
                        ? Results.Ok(await r.Service<IAccessService>().GetDevelopmentUsersAsync(r.CancellationToken))
                        : Results.NotFound())
                .RequireAuthorization(Policies.PlatformClient);

            // ---------- files ----------

            // Upload limits (FileStorage in web.config), so the UI checks files the same way before sending them.
            app.MapGet("/api/files/settings", r => Task.FromResult(Results.Ok(r.Service<UploadRules>().Settings)))
                .RequireAuthorization(Policies.PlatformClient);

            // Is a file with this content already stored? The New project page uses it to say an upload will be reused.
            app.MapGet("/api/files/stored", r =>
            {
                var sha256 = r.Query("sha256");
                var fileName = r.Query("fileName");
                return Task.FromResult(string.IsNullOrWhiteSpace(sha256) || string.IsNullOrWhiteSpace(fileName)
                    ? Results.BadRequest(new { message = "sha256 and fileName are required." })
                    : Results.Ok(new FileStoredDto { Stored = r.Service<UploadRules>().IsAlreadyStored(sha256, fileName) }));
            }).RequireAuthorization(Permissions.ProjectCreate);

            // ---------- projects ----------

            app.MapGet("/api/projects", async r => Results.Ok(await r.Service<IFrpMappingService>().ListAsync(r.CancellationToken)))
                .RequireAuthorization(Permissions.ProjectRead);

            app.MapPost("/api/projects/analyze", async r =>
            {
                if (!r.HasFormContentType)
                {
                    return Results.BadRequest(new { message = "Use multipart/form-data with xsdFile and optional templateFile." });
                }

                var xsdFile = r.File("xsdFile");
                var templateFile = r.File("templateFile");
                var specificationFile = r.File("specificationFile");
                var projectName = r.Form["projectName"] ?? "";

                // Optional: reuse the uploaded files of an existing project (sourceProjectId plus reuseXsd / reuseTemplate /
                // reuseSpecification = true) instead of uploading them again.
                var sourceProjectId = (r.Form["sourceProjectId"] ?? "").Trim();
                var reuse = new ProjectFileReuse
                {
                    SourceProjectId = sourceProjectId,
                    Xsd = IsTrue(r.Form["reuseXsd"]),
                    Template = IsTrue(r.Form["reuseTemplate"]),
                    Specification = IsTrue(r.Form["reuseSpecification"])
                };
                if (reuse.Any && !ProjectIds.IsValid(sourceProjectId))
                {
                    return Results.BadRequest(new { message = "sourceProjectId must be a project id when files are reused." });
                }

                if (xsdFile == null && !reuse.Xsd)
                {
                    return Results.BadRequest(new { message = "xsdFile is required." });
                }

                var service = r.Service<IFrpMappingService>();
                // With Accept: application/x-ndjson the progress is streamed (percent done and the current step), then the project.
                if (ValidationStream.IsRequested(r.Context.Request))
                {
                    await ValidationStream.WriteAsync(r.Context,
                        progress => service.AnalyzeAsync(projectName, xsdFile, templateFile, specificationFile, reuse, r.CancellationToken, progress),
                        project => new ValidationStreamEventDto { Project = project }, r.Logger("FrpMapper.Api"), r.CancellationToken);
                    return Results.Empty();
                }

                return Results.Ok(await service.AnalyzeAsync(projectName, xsdFile, templateFile, specificationFile, reuse, r.CancellationToken));
            }).RequireAuthorization(Permissions.ProjectCreate);

            // The uploaded files of an existing project, which the New project page offers to reuse (names and sizes only).
            app.MapGet("/api/projects/{projectId}/uploads", async r =>
            {
                var files = await r.Service<IFrpMappingService>().GetReusableFilesAsync(r.Route("projectId"), r.CancellationToken);
                return files == null ? Results.NotFound() : Results.Ok(files);
            }).RequireAuthorization(Permissions.ProjectCreate, Permissions.ProjectRead);

            app.MapGet("/api/projects/{projectId}", async r =>
            {
                var project = await r.Service<IFrpMappingService>().GetAsync(r.Route("projectId"), r.CancellationToken);
                // The same project object is answered again until it changes (ProjectReadCache), so its JSON is reused too.
                return project == null ? Results.NotFound() : Results.OkReused(project);
            }).RequireAuthorization(Permissions.ProjectRead);

            // Projects that already use these files (one project per set of XSD, template and specification): checked before creating.
            app.MapPost("/api/projects/matching-files", async r =>
                    Results.Ok(await r.Service<IFrpMappingService>().FindProjectsWithFilesAsync(await r.ReadJsonAsync<ProjectFilesCheckRequest>(), r.CancellationToken)))
                .RequireAuthorization(Permissions.ProjectCreate, Permissions.ProjectRead);

            // The account code on each row of the project's Excel input template, for showing beside the mapped cells.
            app.MapGet("/api/projects/{projectId}/account-codes", async r =>
            {
                var codes = await r.Service<IFrpMappingService>().GetAccountCodesAsync(r.Route("projectId"), r.CancellationToken);
                return codes == null ? Results.NotFound() : Results.Ok(codes);
            }).RequireAuthorization(Permissions.ProjectRead);

            // One sheet of the project's Excel input template, laid out as Excel shows it (the sheet view of the Mappings tab).
            app.MapGet("/api/projects/{projectId}/template/sheet", async r =>
            {
                var grid = await r.Service<ITemplateGridService>().GetSheetAsync(r.Route("projectId"), r.Query("name"), r.CancellationToken);
                return grid == null ? Results.NotFound() : Results.Ok(grid);
            }).RequireAuthorization(Permissions.ProjectRead);

            // The mappings the app makes for the project's XSD and template (what "Use the app's mapping" goes back to); nothing is saved.
            app.MapGet("/api/projects/{projectId}/mappings/suggested", async r =>
            {
                var suggested = await r.Service<ITemplateGridService>().GetSuggestedMappingsAsync(r.Route("projectId"), r.CancellationToken);
                return suggested == null ? Results.NotFound() : Results.Ok(suggested);
            }).RequireAuthorization(Permissions.ProjectRead);

            // Values typed on the Sheet view, saved as they are entered: each is checked against its XSD rules first.
            app.MapPut("/api/projects/{projectId}/values", async r =>
            {
                var request = await r.ReadJsonAsync<SaveValuesRequest>();
                var result = await r.Service<IFrpMappingService>().SaveValuesAsync(r.Route("projectId"), request?.Values, r.CancellationToken);
                if (result == null)
                {
                    return Results.NotFound();
                }

                return result.Errors.Count > 0
                    ? Results.BadRequest(new { message = result.Errors.Count == 1 ? "The value breaks the field's data validation; nothing was saved." : "Values break their fields' data validation; nothing was saved.", errors = result.Errors })
                    : Results.Ok(result.Project);
            }).RequireAuthorization(Permissions.ProjectEdit);

            // Removes or restores the sample values of one sheet or the whole project; values people entered are kept.
            app.MapPost("/api/projects/{projectId}/values/samples", async r =>
            {
                var request = await r.ReadJsonAsync<SampleValuesRequest>();
                var result = await r.Service<IFrpMappingService>().ChangeSampleValuesAsync(r.Route("projectId"), request?.Action, request?.SheetName, r.CancellationToken);
                return result == null ? Results.NotFound() : Results.Ok(result);
            }).RequireAuthorization(Permissions.ProjectEdit);

            // Rename a draft or returned project (Maker): { "name": "..." }.
            app.MapPut("/api/projects/{projectId}/name", async r =>
            {
                var body = await r.ReadJsonAsync<RenameProjectRequest>();
                var project = await r.Service<IFrpMappingService>().RenameAsync(r.Route("projectId"), body == null ? null : body.Name, r.CancellationToken);
                return project == null ? Results.NotFound() : Results.Ok(project);
            }).RequireAuthorization(Permissions.ProjectEdit);

            // Replace a draft or returned project's files (Maker), multipart/form-data: any of xsdFile, templateFile,
            // specificationFile; generateTemplate=true, removeSpecification=true, keepCells=true; optional projectName.
            // With Accept: application/x-ndjson the progress is streamed, then { type: "result", edit: { project, summary } }.
            app.MapPost("/api/projects/{projectId}/files", async r =>
            {
                if (!r.HasFormContentType)
                {
                    return Results.BadRequest(new { message = "Use multipart/form-data with the files to replace." });
                }

                var edit = new ProjectFilesEdit
                {
                    Name = r.Form["projectName"],
                    XsdFile = r.File("xsdFile"),
                    TemplateFile = r.File("templateFile"),
                    SpecificationFile = r.File("specificationFile"),
                    GenerateTemplate = IsTrue(r.Form["generateTemplate"]),
                    RemoveSpecification = IsTrue(r.Form["removeSpecification"]),
                    KeepCells = IsTrue(r.Form["keepCells"])
                };
                var service = r.Service<IFrpMappingService>();
                var projectId = r.Route("projectId");
                if (ValidationStream.IsRequested(r.Context.Request))
                {
                    await ValidationStream.WriteAsync(r.Context,
                        progress => service.ReplaceFilesAsync(projectId, edit, r.CancellationToken, progress),
                        result => new ValidationStreamEventDto { Edit = result, Project = result.Project }, r.Logger("FrpMapper.Api"), r.CancellationToken);
                    return Results.Empty();
                }

                var replaced = await service.ReplaceFilesAsync(projectId, edit, r.CancellationToken);
                return replaced == null ? Results.NotFound() : Results.Ok(replaced);
            }).RequireAuthorization(Permissions.ProjectEdit);

            app.MapPut("/api/projects/{projectId}/mappings", async r =>
            {
                var update = await r.ReadJsonAsync<UpdateMappingsRequest>();
                var project = await r.Service<IFrpMappingService>().UpdateMappingsAsync(r.Route("projectId"), update.Mappings, r.CancellationToken);
                return project == null ? Results.NotFound() : Results.Ok(project);
            }).RequireAuthorization(Permissions.ProjectEdit);

            app.MapGet("/api/projects/{projectId}/export/xml", async r =>
            {
                // values: "mapped" (default) or "sample"
                ExportValues exportValues;
                if (!TryParseExportValues(r.Query("values"), false, out exportValues))
                {
                    return Results.BadRequest(new { message = "values must be 'mapped' or 'sample'." });
                }

                var export = await r.Service<IFrpMappingService>().ExportXmlAsync(r.Route("projectId"), exportValues, r.CancellationToken);
                return export == null ? Results.NotFound() : Results.File(export.Value.Bytes, export.Value.ContentType, export.Value.FileName);
            }).RequireAuthorization(Permissions.ProjectRead);

            app.MapGet("/api/projects/{projectId}/export/template", async r =>
            {
                // values: "mapped" (default), "sample" or "blank"
                ExportValues exportValues;
                if (!TryParseExportValues(r.Query("values"), true, out exportValues))
                {
                    return Results.BadRequest(new { message = "values must be 'mapped', 'sample' or 'blank'." });
                }

                var export = await r.Service<IFrpMappingService>().ExportMappedTemplateAsync(r.Route("projectId"), exportValues, r.CancellationToken);
                return export == null ? Results.NotFound() : Results.File(export.Value.Bytes, export.Value.ContentType, export.Value.FileName);
            }).RequireAuthorization(Permissions.ProjectRead);

            // Forms entered on one copy of their sheet per key value (e.g. one CAR_Part_IV_4c sheet per Currency).
            app.MapGet("/api/projects/{projectId}/sheet-splits", async r =>
            {
                var settings = await r.Service<IFrpMappingService>().GetSheetSplitsAsync(r.Route("projectId"), r.CancellationToken);
                return settings == null ? Results.NotFound() : Results.Ok(settings);
            }).RequireAuthorization(Permissions.ProjectRead);

            app.MapPut("/api/projects/{projectId}/sheet-splits", async r =>
            {
                var request = await r.ReadJsonAsync<SaveSheetSplitsRequest>(optional: true);
                var project = await r.Service<IFrpMappingService>().SaveSheetSplitsAsync(r.Route("projectId"), request == null ? null : request.Splits, r.CancellationToken);
                return project == null ? Results.NotFound() : Results.Ok(project);
            }).RequireAuthorization(Permissions.ProjectEdit);

            // New, unique sample values for every mapped field (XSD-valid, solved for the BSP rules).
            app.MapPost("/api/projects/{projectId}/mappings/sample-values", async r =>
            {
                var refill = await r.Service<IFrpMappingService>().RefillSampleValuesAsync(r.Route("projectId"), r.CancellationToken);
                return refill == null ? Results.NotFound() : Results.Ok(refill);
            }).RequireAuthorization(Permissions.ProjectEdit);

            app.MapPost("/api/projects/{projectId}/validate", async r =>
            {
                var update = await r.ReadJsonAsync<UpdateMappingsRequest>(optional: true);
                var result = await r.Service<IFrpMappingService>().ValidateAsync(r.Route("projectId"), update == null ? null : update.Mappings, r.CancellationToken);
                return result == null ? Results.NotFound() : Results.Ok(result);
            }).RequireAuthorization(Permissions.ProjectRead);

            // Checks the mapped template the app exports: every XSD field bound in its Excel XML map?
            app.MapGet("/api/projects/{projectId}/export/template/check", async r =>
            {
                ExportValues exportValues;
                if (!TryParseExportValues(r.Query("values"), true, out exportValues))
                {
                    return Results.BadRequest(new { message = "values must be 'mapped', 'sample' or 'blank'." });
                }

                var result = await r.Service<IFrpMappingService>().CheckExportedTemplateAsync(r.Route("projectId"), exportValues, r.CancellationToken);
                return result == null ? Results.NotFound() : Results.Ok(result);
            }).RequireAuthorization(Permissions.ProjectRead);

            // Checks any uploaded Excel workbook (e.g. a template edited in Excel) against the project's XSD.
            app.MapPost("/api/projects/{projectId}/check-template", async r =>
            {
                if (!r.HasFormContentType)
                {
                    return Results.BadRequest(new { message = "Use multipart/form-data with templateFile." });
                }

                var file = r.File("templateFile");
                if (file == null || file.Length == 0)
                {
                    return Results.BadRequest(new { message = "templateFile is required." });
                }

                var result = await r.Service<IFrpMappingService>().CheckUploadedTemplateAsync(r.Route("projectId"), file, r.CancellationToken);
                return result == null ? Results.NotFound() : Results.Ok(result);
            }).RequireAuthorization(Permissions.ProjectRead);

            app.MapGet("/api/projects/{projectId}/validate/generated-xml", async r =>
            {
                var service = r.Service<IFrpMappingService>();
                var projectId = r.Route("projectId");
                if (ValidationStream.IsRequested(r.Context.Request))
                {
                    await ValidationStream.WriteAsync(r.Context, progress => service.ValidateGeneratedXmlAsync(projectId, r.CancellationToken, progress),
                        r.Logger("FrpMapper.Api"), r.CancellationToken);
                    return Results.Empty();
                }

                var result = await service.ValidateGeneratedXmlAsync(projectId, r.CancellationToken);
                return result == null ? Results.NotFound() : Results.Ok(result);
            }).RequireAuthorization(Permissions.ProjectRead);

            // An XML exported by Excel from a template with sheet copies (CAR_Part_IV_4c_USD…), in the XSD's structure.
            app.MapPost("/api/projects/{projectId}/xml/merge-sheet-copies", async r =>
            {
                if (!r.HasFormContentType)
                {
                    return Results.BadRequest(new { message = "Use multipart/form-data with xmlFile." });
                }

                var xmlFile = r.File("xmlFile");
                if (xmlFile == null)
                {
                    return Results.BadRequest(new { message = "xmlFile is required." });
                }

                var merged = await r.Service<IFrpMappingService>().MergeSheetCopiesXmlAsync(r.Route("projectId"), xmlFile, r.CancellationToken);
                return merged == null ? Results.NotFound() : Results.File(merged.Value.Bytes, "application/xml", merged.Value.FileName);
            }).RequireAuthorization(Permissions.ProjectRead);

            app.MapPost("/api/projects/{projectId}/validate/xml", async r =>
            {
                if (!r.HasFormContentType)
                {
                    return Results.BadRequest(new { message = "Use multipart/form-data with xmlFile." });
                }

                var xmlFile = r.File("xmlFile");
                if (xmlFile == null)
                {
                    return Results.BadRequest(new { message = "xmlFile is required." });
                }

                var service = r.Service<IFrpMappingService>();
                var projectId = r.Route("projectId");
                if (ValidationStream.IsRequested(r.Context.Request))
                {
                    await ValidationStream.WriteAsync(r.Context, progress => service.ValidateUploadedXmlAsync(projectId, xmlFile, r.CancellationToken, progress),
                        r.Logger("FrpMapper.Api"), r.CancellationToken);
                    return Results.Empty();
                }

                var result = await service.ValidateUploadedXmlAsync(projectId, xmlFile, r.CancellationToken);
                return result == null ? Results.NotFound() : Results.Ok(result);
            }).RequireAuthorization(Permissions.ProjectRead);

            // Builds the XML from the values typed into an Excel input template and validates it; problems name their cell.
            app.MapPost("/api/projects/{projectId}/validate/workbook", async r =>
            {
                if (!r.HasFormContentType)
                {
                    return Results.BadRequest(new { message = "Use multipart/form-data with workbookFile." });
                }

                var workbook = r.File("workbookFile");
                if (workbook == null || workbook.Length == 0)
                {
                    return Results.BadRequest(new { message = "workbookFile is required." });
                }

                var service = r.Service<IFrpMappingService>();
                var projectId = r.Route("projectId");
                if (ValidationStream.IsRequested(r.Context.Request))
                {
                    await ValidationStream.WriteAsync(r.Context, progress => service.ValidateFilledTemplateAsync(projectId, workbook, r.CancellationToken, progress),
                        r.Logger("FrpMapper.Api"), r.CancellationToken);
                    return Results.Empty();
                }

                var result = await service.ValidateFilledTemplateAsync(projectId, workbook, r.CancellationToken);
                return result == null ? Results.NotFound() : Results.Ok(result);
            }).RequireAuthorization(Permissions.ProjectRead);

            // ---------- Maker / Checker workflow ----------

            app.MapPost("/api/projects/{projectId}/submission", async r =>
            {
                if (!r.HasFormContentType)
                {
                    return Results.BadRequest(new { message = "Use multipart/form-data with xmlFile." });
                }

                var xmlFile = r.File("xmlFile");
                if (xmlFile == null || xmlFile.Length == 0)
                {
                    return Results.BadRequest(new { message = "xmlFile is required." });
                }

                var project = await r.Service<IProjectWorkflowService>().AttachSubmissionAsync(r.Route("projectId"), xmlFile, r.CancellationToken);
                return project == null ? Results.NotFound() : Results.Ok(project);
            }).RequireAuthorization(Permissions.SubmissionPrepare);

            // Maker: the XML built from a filled Excel input template becomes the file to review.
            app.MapPost("/api/projects/{projectId}/submission/workbook", async r =>
            {
                if (!r.HasFormContentType)
                {
                    return Results.BadRequest(new { message = "Use multipart/form-data with workbookFile." });
                }

                var workbook = r.File("workbookFile");
                if (workbook == null || workbook.Length == 0)
                {
                    return Results.BadRequest(new { message = "workbookFile is required." });
                }

                var project = await r.Service<IProjectWorkflowService>().AttachFilledTemplateAsync(r.Route("projectId"), workbook, r.CancellationToken);
                return project == null ? Results.NotFound() : Results.Ok(project);
            }).RequireAuthorization(Permissions.SubmissionPrepare);

            app.MapPost("/api/projects/{projectId}/submission/generate", async r =>
            {
                var project = await r.Service<IProjectWorkflowService>().UseGeneratedSubmissionAsync(r.Route("projectId"), r.CancellationToken);
                return project == null ? Results.NotFound() : Results.Ok(project);
            }).RequireAuthorization(Permissions.SubmissionPrepare);

            app.MapGet("/api/projects/{projectId}/submission", async r =>
            {
                var file = await r.Service<IProjectWorkflowService>().DownloadSubmissionAsync(r.Route("projectId"), r.CancellationToken);
                return file == null ? Results.NotFound() : Results.File(file.Value.Bytes, "application/xml", file.Value.FileName);
            }).RequireAuthorization(Permissions.ProjectRead);

            app.MapPost("/api/projects/{projectId}/submit", r => Workflow(r, (w, id, comment) => w.SubmitAsync(id, comment, r.CancellationToken)))
                .RequireAuthorization(Permissions.SubmissionPrepare);
            app.MapPost("/api/projects/{projectId}/withdraw", r => Workflow(r, (w, id, comment) => w.WithdrawAsync(id, comment, r.CancellationToken)))
                .RequireAuthorization(Permissions.SubmissionWithdraw);
            app.MapPost("/api/projects/{projectId}/reopen", r => Workflow(r, (w, id, comment) => w.ReopenAsync(id, comment, r.CancellationToken)))
                .RequireAuthorization(Permissions.SubmissionReopen);
            app.MapPost("/api/projects/{projectId}/approve", r => Workflow(r, (w, id, comment) => w.ApproveAsync(id, comment, r.CancellationToken)))
                .RequireAuthorization(Permissions.SubmissionReview);
            app.MapPost("/api/projects/{projectId}/return", r => Workflow(r, (w, id, comment) => w.ReturnAsync(id, comment, r.CancellationToken)))
                .RequireAuthorization(Permissions.SubmissionReview);

            // Deletes a draft or returned project (only its creator; it is marked deleted, its data and history are kept).
            app.MapDelete("/api/projects/{projectId}", async r =>
                    await r.Service<IProjectWorkflowService>().DeleteAsync(r.Route("projectId"), r.CancellationToken) ? Results.NoContent() : Results.NotFound())
                .RequireAuthorization(Permissions.ProjectDelete);

            app.MapGet("/api/projects/{projectId}/audit", async r =>
                    Results.Ok(await r.Service<IProjectWorkflowService>().AuditAsync(r.Route("projectId"), 500, r.CancellationToken)))
                .RequireAuthorization(Permissions.ProjectRead);

            // The project's history one page at a time: ?page=1&pageSize=25&search=&action= (newest first).
            app.MapGet("/api/projects/{projectId}/audit/page", r => AuditPage(r, r.Route("projectId")))
                .RequireAuthorization(Permissions.ProjectRead);

            // ---------- reports ----------

            // Reports (Application Security Checklist). Dates are yyyy-MM-dd in the server's local time zone; each report checks
            // the reader's permissions itself and is written to the audit trail.
            app.MapGet("/api/reports/user-maintenance", async r =>
            {
                DateOnly from, to;
                if (!Dates(r, out from, out to))
                {
                    return Results.BadRequest(new { message = "from and to must be dates (yyyy-MM-dd)." });
                }

                return Results.Ok(await r.Service<IReportService>().UserMaintenanceAsync(from, to, r.CancellationToken));
            }).RequireAuthorization(Policies.SignedInUser);
            app.MapGet("/api/reports/parameter-maintenance", async r =>
            {
                DateOnly from, to;
                if (!Dates(r, out from, out to))
                {
                    return Results.BadRequest(new { message = "from and to must be dates (yyyy-MM-dd)." });
                }

                return Results.Ok(await r.Service<IReportService>().ParameterMaintenanceAsync(from, to, r.CancellationToken));
            }).RequireAuthorization(Policies.SignedInUser);
            app.MapGet("/api/reports/users", async r => Results.Ok(await r.Service<IReportService>().UserExtractionAsync(r.CancellationToken)))
                .RequireAuthorization(Policies.SignedInUser);
            app.MapGet("/api/reports/sign-ins", async r =>
            {
                DateOnly from, to;
                if (!Dates(r, out from, out to))
                {
                    return Results.BadRequest(new { message = "from and to must be dates (yyyy-MM-dd)." });
                }

                return Results.Ok(await r.Service<IReportService>().SignInsAsync(from, to, r.Query("user"), r.CancellationToken));
            }).RequireAuthorization(Policies.SignedInUser);

            app.MapGet("/api/audit", async r =>
            {
                int take;
                var takeText = r.Query("take");
                if (string.IsNullOrEmpty(takeText))
                {
                    take = 500;
                }
                else if (!int.TryParse(takeText, out take))
                {
                    return Results.BadRequest(new { message = "take must be a whole number." });
                }

                return Results.Ok(await r.Service<IProjectWorkflowService>().AuditAsync(null, take, r.CancellationToken));
            }).RequireAuthorization(Permissions.AuditReadAll);

            // The whole audit trail one page at a time: ?page=1&pageSize=25&search=&action= (newest first).
            app.MapGet("/api/audit/page", r => AuditPage(r, null))
                .RequireAuthorization(Permissions.AuditReadAll);

            return app;
        }

        private static async Task<ApiResult> AuditPage(ApiRequest r, string projectId)
        {
            int page = 1, pageSize = 25;
            var pageText = r.Query("page");
            var sizeText = r.Query("pageSize");
            if ((!string.IsNullOrEmpty(pageText) && !int.TryParse(pageText, NumberStyles.None, CultureInfo.InvariantCulture, out page))
                || (!string.IsNullOrEmpty(sizeText) && !int.TryParse(sizeText, NumberStyles.None, CultureInfo.InvariantCulture, out pageSize)))
            {
                return Results.BadRequest(new { message = "page and pageSize must be whole numbers." });
            }

            var result = await r.Service<IProjectWorkflowService>().AuditPageAsync(projectId, page, pageSize, r.Query("search"), r.Query("action"), r.CancellationToken);
            return result == null ? Results.NotFound() : Results.Ok(result);
        }

        private static async Task<ApiResult> Workflow(ApiRequest r, Func<IProjectWorkflowService, string, string, Task<FrpProjectDto>> action)
        {
            var body = await r.ReadJsonAsync<WorkflowCommentRequest>(optional: true);
            var project = await action(r.Service<IProjectWorkflowService>(), r.Route("projectId"), body == null ? null : body.Comment);
            return project == null ? Results.NotFound() : Results.Ok(project);
        }

        private static string DecisionStatus(string decision)
        {
            switch (decision)
            {
                case "approve": return AccessRequestStatus.Approved;
                case "reject": return AccessRequestStatus.Rejected;
                case "cancel": return AccessRequestStatus.Cancelled;
                default: return null;
            }
        }

        private static bool IsTrue(string value)
        {
            bool result;
            return bool.TryParse(value, out result) && result;
        }

        private static bool Dates(ApiRequest r, out DateOnly from, out DateOnly to)
        {
            to = default(DateOnly);
            return DateOnly.TryParse(r.Query("from"), out from) & DateOnly.TryParse(r.Query("to"), out to);
        }

        private static bool TryParseExportValues(string value, bool allowBlank, out ExportValues result)
        {
            result = ExportValues.Mapped;
            if (string.IsNullOrWhiteSpace(value))
            {
                return true;
            }

            if (!Enum.TryParse(value, true, out result) || !Enum.IsDefined(typeof(ExportValues), result))
            {
                return false;
            }

            return allowBlank || result != ExportValues.Blank;
        }

        private const string StartPage = @"<!doctype html>
<html lang=""en"">
<head>
  <meta charset=""utf-8"">
  <meta name=""viewport"" content=""width=device-width, initial-scale=1"">
  <title>FRP Mapper API</title>
  <style>
    body{margin:0;font-family:Arial,Helvetica,sans-serif;background:#f5f7fb;color:#1d2433}
    main{max-width:760px;margin:12vh auto;padding:32px;background:#fff;border:1px solid #dce3ee;border-radius:8px}
    h1{margin:0 0 10px;font-size:28px} p{color:#526070;line-height:1.5}
    a{display:inline-flex;margin:8px 10px 0 0;padding:10px 14px;border-radius:6px;text-decoration:none;font-weight:700}
    .primary{background:#1d4ed8;color:#fff}.secondary{background:#eef2ff;color:#1e3a8a}
    code{background:#eff6ff;color:#1e40af;padding:2px 5px;border-radius:4px}
  </style>
</head>
<body>
  <main>
    <h1>FRP Mapper API is running</h1>
    <p>This is the backend service. People use FrpMapper through <strong>FrpMapper.Platform</strong>; start it too and open its address.</p>
    <a class=""primary"" href=""/api/health"">Check API health</a>
  </main>
</body>
</html>";
    }
}
