using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// The sheet view of the Mappings tab. Projects are read through <see cref="IFrpMappingService.GetAsync"/>, so the
    /// same visibility rules (<see cref="ProjectAccess"/>) and the same read cache apply: a project the person may not
    /// see reads as not found. Nothing here changes a project; mappings changed on the sheet are saved with the
    /// existing PUT projects/{id}/mappings (Maker, editable project).
    /// </summary>
    public sealed class TemplateGridService : ITemplateGridService
    {
        /// <summary>Excel's limit for a sheet name.</summary>
        public const int MaxSheetNameLength = 31;

        private static readonly TimeSpan CacheFor = TimeSpan.FromMinutes(30);

        private readonly IFrpMappingService projects;
        private readonly TemplateGridReader gridReader;
        private readonly OpenXmlWorkbookInspector workbookInspector;
        private readonly MappingSuggestionEngine suggestionEngine;
        private readonly XsdInputTemplateGenerator templateGenerator;
        private readonly BspSpecificationReader specificationReader;
        private readonly ICurrentUser currentUser;
        private readonly IMemoryCache cache;

        public TemplateGridService(IFrpMappingService projects, TemplateGridReader gridReader, OpenXmlWorkbookInspector workbookInspector,
            MappingSuggestionEngine suggestionEngine, XsdInputTemplateGenerator templateGenerator, BspSpecificationReader specificationReader,
            ICurrentUser currentUser, IMemoryCache cache)
        {
            this.projects = projects;
            this.gridReader = gridReader;
            this.workbookInspector = workbookInspector;
            this.suggestionEngine = suggestionEngine;
            this.templateGenerator = templateGenerator;
            this.specificationReader = specificationReader;
            this.currentUser = currentUser;
            this.cache = cache;
        }

        public async Task<TemplateGridDto> GetSheetAsync(string projectId, string sheetName, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectRead, "read projects");
            if (string.IsNullOrWhiteSpace(sheetName) || sheetName.Length > MaxSheetNameLength || sheetName.Any(char.IsControl))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"Give the name of a sheet of the template (at most {MaxSheetNameLength} characters).");
            }

            var project = await projects.GetAsync(projectId, cancellationToken);
            if (project?.TemplateFile == null || string.IsNullOrEmpty(project.TemplateFile.StoredPath))
            {
                return null;
            }

            return gridReader.Read(project.TemplateFile.StoredPath, sheetName);
        }

        public async Task<SuggestedMappingsDto> GetSuggestedMappingsAsync(string projectId, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectRead, "read projects");
            var project = await projects.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            // The app's mappings depend only on the XSD fields and the template, so they are worked out once per template file.
            var key = "suggested-mappings|" + project.Id + "|" + FileKey(project.TemplateFile) + "|" + FileKey(project.SpecificationFile)
                + "|" + project.TemplateGenerated + "|" + project.SchemaNodes.Count.ToString(CultureInfo.InvariantCulture);
            SuggestedMappingsDto suggested;
            if (cache.TryGetValue(key, out suggested))
            {
                return suggested;
            }

            suggested = new SuggestedMappingsDto { Mappings = Suggest(project) };
            cache.Set(key, suggested, new MemoryCacheEntryOptions { SlidingExpiration = CacheFor });
            return suggested;
        }

        /// <summary>What <see cref="FrpMappingService"/> maps when a project is created (AnalyzeAsync), from the stored files.</summary>
        private IReadOnlyList<MappingEntryDto> Suggest(FrpProjectDto project)
        {
            if (project.TemplateGenerated)
            {
                BspSpecification specification = null;
                if (project.SpecificationFile != null && File.Exists(project.SpecificationFile.StoredPath))
                {
                    try
                    {
                        specification = specificationReader.Read(project.SpecificationFile.StoredPath);
                    }
                    catch (Exception ex) when (ex is InvalidOperationException || ex is InvalidDataException || ex is System.Xml.XmlException || ex is IOException)
                    {
                        // As when the project was created: labels are optional, validation reports an unreadable specification.
                    }
                }

                var draft = new FrpProjectDto { RootElement = project.RootElement, TargetNamespace = project.TargetNamespace, SchemaNodes = project.SchemaNodes };
                return templateGenerator.Generate(draft, specification).Mappings;
            }

            var workbook = project.TemplateFile != null && File.Exists(project.TemplateFile.StoredPath)
                ? workbookInspector.Inspect(project.TemplateFile.StoredPath)
                : null;
            return suggestionEngine.CreateInitialMappings(project.SchemaNodes, workbook).Mappings;
        }

        private static string FileKey(UploadedFileDto file)
        {
            if (file == null || string.IsNullOrEmpty(file.StoredPath))
            {
                return "-";
            }

            var info = new FileInfo(file.StoredPath);
            return info.Exists
                ? info.FullName + ":" + info.Length.ToString(CultureInfo.InvariantCulture) + ":" + info.LastWriteTimeUtc.Ticks.ToString(CultureInfo.InvariantCulture)
                : file.StoredPath;
        }
    }
}
