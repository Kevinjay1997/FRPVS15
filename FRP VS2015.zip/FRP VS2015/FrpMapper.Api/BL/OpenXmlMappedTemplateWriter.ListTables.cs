﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Excel XML list tables for repeating XSD elements (e.g. .../MAIN_I/MAIN_I_Item/C0010).
    /// Excel can only export a repeating element through a list table (tableType="xml"), never through a single cell;
    /// without these tables Excel's XML export omits required lists and the XML fails XSD validation.
    ///
    /// Placement, following BSP's own templates:
    /// - in place: when the item's input cells sit in one row directly under their code header row (C0010, C0020, ...),
    ///   that header row plus the input row become the table, so the form looks the same;
    /// - helper table: otherwise (a vertical layout such as COUNTRY / R0010.. down one column, or a whole grid per
    ///   currency), a horizontal table is added below the form. Its cells are formulas linked to the form's input cells,
    ///   so data is still entered in the form.
    /// Lists nested inside another list cannot be mapped by Excel at all; those are left unmapped
    /// (the app's own XML export still contains them).
    /// </summary>
    public sealed partial class OpenXmlMappedTemplateWriter
    {
        private const string TableContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml";

        /// <summary>Repeating groups Excel cannot map (a list inside another list), keyed by the repeating element path.</summary>
        public static IReadOnlyList<string> UnmappableListGroups(FrpProjectDto project)
        {
            var plan = PlanListGroups(project);
            return plan.Unmappable;
        }

        private static ListGroupPlan PlanListGroups(FrpProjectDto project)
        {
            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var repeatingPaths = project.SchemaNodes.Where(n => n.IsRepeating).Select(n => n.Path).ToList();
            var groups = new Dictionary<string, List<SchemaNodeDto>>(StringComparer.OrdinalIgnoreCase);

            foreach (var leaf in project.SchemaNodes.Where(n => n.DataType != "complex" && n.IsInRepeatingGroup))
            {
                var group = NearestRepeating(leaf, nodesByPath);
                if (group == null)
                {
                    continue;
                }

                List<SchemaNodeDto> leaves;
                if (!groups.TryGetValue(group.Path, out leaves))
                {
                    leaves = new List<SchemaNodeDto>();
                    groups[group.Path] = leaves;
                }

                leaves.Add(leaf);
            }

            var mappable = new Dictionary<string, List<SchemaNodeDto>>(StringComparer.OrdinalIgnoreCase);
            var unmappable = new List<string>();
            foreach (var group2 in groups)
            {
                var path = group2.Key;
                var leaves = group2.Value;
                var nested = repeatingPaths.Any(other =>
                    !string.Equals(other, path, StringComparison.OrdinalIgnoreCase)
                    && (path.StartsWith(other + "/", StringComparison.OrdinalIgnoreCase) || other.StartsWith(path + "/", StringComparison.OrdinalIgnoreCase)));
                if (nested)
                {
                    unmappable.Add(path);
                }
                else
                {
                    mappable[path] = leaves;
                }
            }

            return new ListGroupPlan(mappable, unmappable);
        }

        private static SchemaNodeDto NearestRepeating(SchemaNodeDto node, IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath)
        {
            var current = node;
            while (current != null)
            {
                if (current.IsRepeating)
                {
                    return current;
                }

                current = (current.ParentPath == null) ? null : nodesByPath.GetValueOrDefault(current.ParentPath);
            }

            return null;
        }

        /// <param name="appReadGroups">Forms the app reads from their sheets itself (see <see cref="SheetSplitRules.AppReadForms"/>): no table.</param>
        private static void WriteListTables(ZipArchive archive, FrpProjectDto project, IReadOnlyList<MappingEntryDto> mappings, XmlMapInfo map, bool writeValues,
            ISet<string> appReadGroups)
        {
            NormalizeExistingListTables(archive, mappings, map);
            var plan = PlanListGroups(project);
            if (plan.Mappable.Count == 0)
            {
                return;
            }

            var mappingByPath = mappings
                .GroupBy(m => m.SchemaPath, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var sheets = ReadSheets(archive);
            var sharedStrings = ReadSharedStrings(archive);
            var usedTableNames = ExistingTableNames(archive);
            var nextTableId = ExistingTableIds(archive).DefaultIfEmpty(0).Max() + 1;
            var addedFormulas = false;

            // Groups per worksheet, only those whose every field is mapped on one existing template sheet
            // and not already bound by the template's own XML map.
            var bySheet = new Dictionary<string, List<VT_GroupPath_Fields<string, List<VT_Node_Mapping<SchemaNodeDto, MappingEntryDto>>>>>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in plan.Mappable)
            {
                var groupPath = entry.Key;
                var leaves = entry.Value;
                var fields = leaves
                    .Select(leaf => new VT_Node_Mapping<SchemaNodeDto, MappingEntryDto>(leaf, mappingByPath.GetValueOrDefault(leaf.Path)))
                    .Where(x => x.Mapping != null)
                    .Select(x => new VT_Node_Mapping<SchemaNodeDto, MappingEntryDto>(x.Node, x.Mapping))
                    .ToList();
                if (fields.Count == 0 || appReadGroups.Contains(groupPath)
                    || fields.Any(f => f.Mapping.Source == MappingSuggestionEngine.SourceExistingList || f.Mapping.Source == MappingSuggestionEngine.SourceExistingSingle))
                {
                    continue;
                }

                // All of an item's fields must be in one XML table (Excel cannot export sibling elements of one repeating
                // element from different tables). When they are spread over sheets (e.g. a field the template lacks is on
                // FRP_Unplaced), the table goes on the sheet with most of them and links to the others.
                var sheetName = fields
                    .GroupBy(f => f.Mapping.SheetName, StringComparer.OrdinalIgnoreCase)
                    .OrderByDescending(g => g.Count())
                    .First().Key;
                List<VT_GroupPath_Fields<string, List<VT_Node_Mapping<SchemaNodeDto, MappingEntryDto>>>> list;
                if (!bySheet.TryGetValue(sheetName, out list))
                {
                    list = new List<VT_GroupPath_Fields<string, List<VT_Node_Mapping<SchemaNodeDto, MappingEntryDto>>>>();
                    bySheet[sheetName] = list;
                }

                list.Add(new VT_GroupPath_Fields<string, List<VT_Node_Mapping<SchemaNodeDto, MappingEntryDto>>>(groupPath, fields));
            }

            foreach (var entry2 in bySheet)
            {
                var sheetName = entry2.Key;
                var groups = entry2.Value;
                var sheet = sheets.FirstOrDefault(s => string.Equals(s.Name, sheetName, StringComparison.OrdinalIgnoreCase));
                if (sheet.WorksheetPath == null)
                {
                    continue;
                }

                var document = ReadXml(archive, sheet.WorksheetPath);
                var root = document?.Root;
                if (root == null)
                {
                    continue;
                }

                var sheetData = root.Element(Main + "sheetData") ?? new XElement(Main + "sheetData");
                if (sheetData.Parent == null)
                {
                    root.Add(sheetData);
                }

                var blocked = BlockedAreas(archive, sheet.WorksheetPath, root);
                var nextHelperRow = MaxRow(sheetData) + 3;

                foreach (var group in groups.OrderBy(g => g.GroupPath, StringComparer.Ordinal))
                {
                    var groupPath = group.GroupPath;
                    var fields = group.Fields;
                    var expectedNames = ListColumnNames(groupPath, fields.Select(f => f.Node));
                    var onOneSheet = fields.All(f => string.Equals(f.Mapping.SheetName, sheetName, StringComparison.OrdinalIgnoreCase));
                    var inPlace = onOneSheet ? TryInPlaceTable(sheetData, fields, sharedStrings, blocked, expectedNames) : null;
                    ListTable table;
                    if (inPlace != null)
                    {
                        table = inPlace;
                        RemoveSingleCellMerges(root, table);
                        foreach (var column2 in table.Columns.Select(c => new VT_Column_Name<int, string>(c.Column, c.Name)))
                        {
                            var column = column2.Column;
                            var name = column2.Name;
                            // The form's own header cell already shows the code (C0010...): keep it as supplied.
                            if (!string.Equals(CellText(sheetData, ColumnName(column), table.HeaderRow, sharedStrings), name, StringComparison.Ordinal))
                            {
                                SetInlineString(GetOrCreateCell(sheetData, ColumnName(column), table.HeaderRow), name);
                            }
                        }
                    }
                    else
                    {
                        table = BuildHelperTable(sheetData, sheetName, groupPath, fields, nextHelperRow, project, writeValues);
                        nextHelperRow = table.DataRow + 3;
                        addedFormulas = true;
                    }

                    blocked.Add(new VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int>(table.HeaderRow, table.DataRow, table.Columns.Min(c => c.Column), table.Columns.Max(c => c.Column)));

                    var tableName = UniqueTableName(usedTableNames);
                    var tablePath = NextFreePart(archive, "xl/tables/frpTable", ".xml");
                    UpsertEntry(archive, tablePath, BuildTableXml(table, nextTableId++, tableName, map).ToString(SaveOptions.DisableFormatting));
                    EnsureContentType(archive, "/" + tablePath, TableContentType);
                    var relationshipId = AddSheetRelationship(archive, sheet.WorksheetPath, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/table", "../tables/" + Path.GetFileName(tablePath));
                    AddTablePart(root, relationshipId);
                }

                UpsertEntry(archive, sheet.WorksheetPath, document.ToString(SaveOptions.DisableFormatting));
            }

            if (addedFormulas)
            {
                RequestFullCalculationOnLoad(archive);
            }
        }

        /// <summary>
        /// The item's input cells are in one row and the row above holds their codes: that header row plus the
        /// input row become the table. Every column in the range needs a unique, non-empty header.
        /// </summary>
        private static ListTable TryInPlaceTable(
            XElement sheetData,
            List<VT_Node_Mapping<SchemaNodeDto, MappingEntryDto>> fields,
            IReadOnlyList<string> sharedStrings,
            List<VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int>> blocked,
            IReadOnlyDictionary<string, string> expectedNames)
        {
            var positions = fields
                .Select(f => { string column; int row; return new VT_Node_Mapping_Ok_Column_Row<SchemaNodeDto, MappingEntryDto, bool, int, int>(f.Node, f.Mapping, TryParseCellAddress(f.Mapping.CellAddress, out column, out row), CellColumnIndex(f.Mapping.CellAddress), row); })
                .ToList();
            if (positions.Any(p => !p.Ok) || positions.Select(p => p.Row).Distinct().Count() != 1)
            {
                return null;
            }

            var dataRow = positions[0].Row;
            var headerRow = dataRow - 1;
            if (headerRow < 1 || positions.Select(p => p.Column).Distinct().Count() != positions.Count)
            {
                return null;
            }

            var firstColumn = positions.Min(p => p.Column);
            var lastColumn = positions.Max(p => p.Column);
            if (blocked.Any(b => b.FirstRow <= dataRow && b.LastRow >= headerRow && b.FirstColumn <= lastColumn && b.LastColumn >= firstColumn))
            {
                return null;
            }

            var byColumn = positions.ToDictionary(p => p.Column);
            var columns = new List<ListColumn>();
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (var column = firstColumn; column <= lastColumn; column++)
            {
                var header = CellText(sheetData, ColumnName(column), headerRow, sharedStrings)?.Trim() ?? "";
                VT_Node_Mapping_Ok_Column_Row<SchemaNodeDto, MappingEntryDto, bool, int, int> field;
                if (byColumn.TryGetValue(column, out field))
                {
                    // The header shows the element's code (C0010...) or, for generated templates with repeated codes,
                    // its unique column name (ADD1_R0010C0010).
                    var expected = expectedNames.GetValueOrDefault(field.Node.Path) ?? field.Node.Name;
                    if (string.Equals(header, field.Node.Name, StringComparison.OrdinalIgnoreCase))
                    {
                        header = field.Node.Name;
                    }
                    else if (string.Equals(header, expected, StringComparison.OrdinalIgnoreCase))
                    {
                        header = expected;
                    }
                    else
                    {
                        return null;
                    }
                }

                if (header.Length == 0 || !names.Add(header))
                {
                    return null;
                }

                VT_Node_Mapping_Ok_Column_Row<SchemaNodeDto, MappingEntryDto, bool, int, int> mapped;
                columns.Add(new ListColumn(column, header, byColumn.TryGetValue(column, out mapped) ? mapped.Node : null));
            }

            return new ListTable(headerRow, dataRow, columns);
        }

        /// <summary>
        /// A horizontal table below the form: a caption, a header row of element names and one row of formulas
        /// linked to the form's input cells (the cached value is written so the file shows values before recalculation).
        /// </summary>
        private static ListTable BuildHelperTable(
            XElement sheetData,
            string sheetName,
            string groupPath,
            List<VT_Node_Mapping<SchemaNodeDto, MappingEntryDto>> fields,
            int captionRow,
            FrpProjectDto project,
            bool writeValues)
        {
            var headerRow = captionRow + 1;
            var dataRow = captionRow + 2;
            const int firstColumn = 2; // column B
            var groupName = groupPath.Split('/', StringSplitOptions.RemoveEmptyEntries).LastOrDefault() ?? "Item";
            SetInlineString(GetOrCreateCell(sheetData, "B", captionRow),
                $"XML list {groupName}: linked to the input cells above and used by Excel's XML export. Enter data in the form above.");

            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var columns = new List<ListColumn>();
            var column = firstColumn;
            foreach (var field in fields)
            {
                var node = field.Node;
                var mapping = field.Mapping;
                var name = UniqueColumnName(node, groupPath, names);
                SetInlineString(GetOrCreateCell(sheetData, ColumnName(column), headerRow), name);

                var source = string.Equals(mapping.SheetName, sheetName, StringComparison.OrdinalIgnoreCase)
                    ? mapping.CellAddress.ToUpperInvariant()
                    : $"'{mapping.SheetName.Replace("'", "''")}'!{mapping.CellAddress.ToUpperInvariant()}";
                var cell = GetOrCreateCell(sheetData, ColumnName(column), dataRow);
                var cachedValue = writeValues ? XmlSubmissionWriter.ResolveExportValue(project, mapping) : null;
                SetFormula(cell, $"IF(ISBLANK({source}),\"\",{source})", cachedValue, mapping.DataType);

                columns.Add(new ListColumn(column, name, node));
                column++;
            }

            return new ListTable(headerRow, dataRow, columns);
        }

        /// <summary>
        /// Column names for a list item's elements: the element name, or the path below the item joined with "_"
        /// when two elements share a name (MAIN/R0010C0010 vs ADD1/R0010C0010). Used for generated templates and
        /// helper tables, and to recognise those header rows when exporting.
        /// </summary>
        internal static IReadOnlyDictionary<string, string> ListColumnNames(string groupPath, IEnumerable<SchemaNodeDto> leaves)
        {
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var leaf in leaves)
            {
                result[leaf.Path] = UniqueColumnName(leaf, groupPath, used);
            }

            return result;
        }

        internal static SchemaNodeDto NearestRepeatingNode(SchemaNodeDto node, IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath) =>
            NearestRepeating(node, nodesByPath);

        private static string UniqueColumnName(SchemaNodeDto node, string groupPath, HashSet<string> used)
        {
            var name = node.Name;
            if (used.Add(name))
            {
                return name;
            }

            // Same code in two blocks of one item (e.g. MAIN/R0010C0010 and ADD1/R0010C0010): prefix the block.
            var relative = node.Path.Length > groupPath.Length ? node.Path.Substring(groupPath.Length + 1) : node.Name;
            name = relative.Replace('/', '_');
            var candidate = name;
            var suffix = 2;
            while (!used.Add(candidate))
            {
                candidate = $"{name}_{suffix++}";
            }

            return candidate;
        }

        private static XDocument BuildTableXml(ListTable table, int id, string name, XmlMapInfo map)
        {
            var first = table.Columns.Min(c => c.Column);
            var last = table.Columns.Max(c => c.Column);
            var reference = $"{ColumnName(first)}{table.HeaderRow}:{ColumnName(last)}{table.DataRow}";
            var tableColumns = new XElement(Main + "tableColumns", new XAttribute("count", table.Columns.Count));
            var columnId = 1;
            var uniqueNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var column in table.Columns.OrderBy(c => c.Column))
            {
                var element = new XElement(Main + "tableColumn",
                    new XAttribute("id", columnId),
                    new XAttribute("uniqueName", UniqueXmlColumnName(column, columnId, map.Prefix, uniqueNames)),
                    new XAttribute("name", column.Name));
                if (column.Node != null)
                {
                    element.Add(new XElement(Main + "xmlColumnPr",
                        new XAttribute("mapId", map.MapId),
                        new XAttribute("xpath", ToNsXPath(column.Node.Path, map.Prefix)),
                        new XAttribute("xmlDataType", NormalizeXmlDataType(column.Node.DataType))));
                }

                tableColumns.Add(element);
                columnId++;
            }

            return new XDocument(new XElement(Main + "table",
                new XAttribute("id", id),
                new XAttribute("name", name),
                new XAttribute("displayName", name),
                new XAttribute("ref", reference),
                new XAttribute("tableType", "xml"),
                new XAttribute("totalsRowShown", "0"),
                new XElement(Main + "autoFilter", new XAttribute("ref", reference)),
                tableColumns));
        }

        /// <summary>Same form as Excel: "ns1:C0010" for mapped columns, the column id for unmapped ones.</summary>
        private static string UniqueXmlColumnName(ListColumn column, int columnId, string prefix, HashSet<string> used)
        {
            var name = (column.Node == null) ? columnId.ToString(System.Globalization.CultureInfo.InvariantCulture) : $"{prefix}:{column.Node.Name}";
            var candidate = name;
            var suffix = 2;
            while (!used.Add(candidate))
            {
                candidate = $"{name}{suffix++}";
            }

            return candidate;
        }

        /// <summary>Areas a new table must not overlap: merged cells, existing tables and single-cell XML bindings.</summary>
        private static List<VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int>> BlockedAreas(ZipArchive archive, string worksheetPath, XElement worksheet)
        {
            var blocked = new List<VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int>>();
            foreach (var merge in worksheet.Descendants(Main + "mergeCell"))
            {
                // Some BSP templates record single cells as 1x1 "merges"; they merge nothing and are removed
                // where a table is placed (see RemoveSingleCellMerges), so they do not block a table.
                VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int> area;
                if (TryParseRange((string)merge.Attribute("ref"), out area) && !(area.FirstRow == area.LastRow && area.FirstColumn == area.LastColumn))
                {
                    blocked.Add(area);
                }
            }

            var directory = Path.GetDirectoryName(worksheetPath)?.Replace('\\', '/') ?? "xl/worksheets";
            var rels = ReadXml(archive, $"{directory}/_rels/{Path.GetFileName(worksheetPath)}.rels");
            foreach (var relationship in rels?.Root?.Elements(PackageRel + "Relationship") ?? new List<XElement>())
            {
                var type = (string)relationship.Attribute("Type") ?? "";
                var target = (string)relationship.Attribute("Target");
                var isTable = type.EndsWith("/table", StringComparison.OrdinalIgnoreCase);
                var isSingleCells = type.EndsWith("/tableSingleCells", StringComparison.OrdinalIgnoreCase);
                if (target == null || !isTable && !isSingleCells)
                {
                    continue; // only table parts are XML; drawings, printer settings (.bin) etc. are skipped
                }

                var part = ReadXml(archive, NormalizePartPath(directory, target));
                VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int> tableArea;
                if (isTable && TryParseRange((string)part?.Root?.Attribute("ref"), out tableArea))
                {
                    blocked.Add(tableArea);
                }
                else if (isSingleCells)
                {
                    foreach (var single in part?.Root?.Elements(Main + "singleXmlCell") ?? new List<XElement>())
                    {
                        VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int> cellArea;
                        if (TryParseRange((string)single.Attribute("r"), out cellArea))
                        {
                            blocked.Add(cellArea);
                        }
                    }
                }
            }

            return blocked;
        }

        /// <summary>
        /// The export writes one item row into each XML list table the template already has. Leftover rows below it
        /// (earlier data or partial samples) would be exported by Excel as extra, usually incomplete items, so the
        /// table is resized to its header plus one data row and the leftover cells in its columns are cleared.
        /// </summary>
        private static void NormalizeExistingListTables(ZipArchive archive, IReadOnlyList<MappingEntryDto> mappings, XmlMapInfo map)
        {
            var listPaths = mappings
                .Where(m => m.Source == MappingSuggestionEngine.SourceExistingList)
                .Select(m => ToNsXPath(m.SchemaPath, map.Prefix))
                .ToHashSet(StringComparer.Ordinal);
            if (listPaths.Count == 0)
            {
                return;
            }

            var mappingsBySheet = mappings
                .GroupBy(m => m.SheetName, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.OrdinalIgnoreCase);

            foreach (var sheet in ReadSheets(archive))
            {
                var directory = Path.GetDirectoryName(sheet.WorksheetPath)?.Replace('\\', '/') ?? "xl/worksheets";
                var rels = ReadXml(archive, $"{directory}/_rels/{Path.GetFileName(sheet.WorksheetPath)}.rels");
                var tables = (rels?.Root?.Elements(PackageRel + "Relationship") ?? new List<XElement>())
                    .Where(r => ((string)r.Attribute("Type"))?.EndsWith("/table", StringComparison.OrdinalIgnoreCase) == true)
                    .Select(r => NormalizePartPath(directory, (string)r.Attribute("Target")))
                    .ToList();
                if (tables.Count == 0)
                {
                    continue;
                }

                XDocument worksheet = null;
                foreach (var tablePath in tables)
                {
                    var table = ReadXml(archive, tablePath);
                    var root = table?.Root;
                    VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int> area;
                    if (root == null
                        || (string)root.Attribute("tableType") != "xml"
                        || ((int?)root.Attribute("totalsRowCount") ?? 0) > 0
                        || !root.Descendants(Main + "xmlColumnPr").Any(x => listPaths.Contains((string)x.Attribute("xpath") ?? ""))
                        || !TryParseRange((string)root.Attribute("ref"), out area))
                    {
                        continue;
                    }

                    var headerRows = (int?)root.Attribute("headerRowCount") ?? 1;
                    var firstDataRow = area.FirstRow + headerRows;
                    if (worksheet == null) worksheet = ReadXml(archive, sheet.WorksheetPath);
                    var sheetData = worksheet?.Root?.Element(Main + "sheetData");
                    if (sheetData == null)
                    {
                        continue;
                    }

                    var sheetMappings = mappingsBySheet.GetValueOrDefault(sheet.Name) ?? new List<MappingEntryDto>();
                    var completed = CompleteTableColumns(root, area.FirstColumn, firstDataRow, sheetMappings, map);
                    completed |= ExtendTableColumns(root, area, firstDataRow, sheetMappings, map, sheetData, BlockedAreas(archive, sheet.WorksheetPath, worksheet.Root));
                    if (completed)
                    {
                        TryParseRange((string)root.Attribute("ref"), out area);
                    }

                    if (area.LastRow <= firstDataRow)
                    {
                        if (completed)
                        {
                            UpsertEntry(archive, tablePath, table.ToString(SaveOptions.DisableFormatting));
                        }

                        continue;
                    }

                    foreach (var row in sheetData.Elements(Main + "row"))
                    {
                        var rowNumber = (int?)row.Attribute("r") ?? 0;
                        if (rowNumber <= firstDataRow || rowNumber > area.LastRow)
                        {
                            continue;
                        }

                        foreach (var cell in row.Elements(Main + "c"))
                        {
                            var column = CellColumnIndex((string)cell.Attribute("r") ?? "");
                            if (column >= area.FirstColumn && column <= area.LastColumn)
                            {
                                SetCellValue(cell, null, "string");
                            }
                        }
                    }

                    var reference = $"{ColumnName(area.FirstColumn)}{area.FirstRow}:{ColumnName(area.LastColumn)}{firstDataRow}";
                    root.SetAttributeValue("ref", reference);
                    root.Element(Main + "autoFilter")?.SetAttributeValue("ref", reference);
                    UpsertEntry(archive, tablePath, table.ToString(SaveOptions.DisableFormatting));
                }

                if (worksheet != null)
                {
                    UpsertEntry(archive, sheet.WorksheetPath, worksheet.ToString(SaveOptions.DisableFormatting));
                }
            }
        }

        /// <summary>
        /// Binds table columns the template left unmapped to the XSD element mapped at that column's input cell,
        /// when the element belongs to the same list item (e.g. BSP's BCCR_PRODUCT table has an unbound C0030 column,
        /// which makes Excel's XML export miss the required C0030).
        /// </summary>
        private static bool CompleteTableColumns(XElement table, int firstColumn, int dataRow, IReadOnlyList<MappingEntryDto> sheetMappings, XmlMapInfo map)
        {
            var columns = table.Descendants(Main + "tableColumn").ToList();
            var boundXPaths = columns
                .Select(c => (string)c.Element(Main + "xmlColumnPr")?.Attribute("xpath"))
                .Where(x => x != null)
                .ToList();
            if (boundXPaths.Count == 0)
            {
                return false;
            }

            // The list item element shared by the bound columns, e.g. /ns1:BCCR/ns1:BCCR_PRODUCT/ns1:MAIN/ns1:MAIN_Item
            var itemXPath = boundXPaths[0].Substring(0, boundXPaths[0].LastIndexOf('/'));
            var uniqueNames = columns.Select(c => (string)c.Attribute("uniqueName") ?? "").ToHashSet(StringComparer.OrdinalIgnoreCase);
            var changed = false;
            foreach (var mapping in sheetMappings)
            {
                string unusedColumn;
                int row;
                if (!TryParseCellAddress(mapping.CellAddress, out unusedColumn, out row) || row != dataRow)
                {
                    continue;
                }

                var index = CellColumnIndex(mapping.CellAddress) - firstColumn;
                if (index < 0 || index >= columns.Count || columns[index].Element(Main + "xmlColumnPr") != null)
                {
                    continue;
                }

                var xpath = ToNsXPath(mapping.SchemaPath, map.Prefix);
                if (!string.Equals(xpath.Substring(0, xpath.LastIndexOf('/')), itemXPath, StringComparison.Ordinal) || boundXPaths.Contains(xpath))
                {
                    continue;
                }

                var mapId = (string)table.Descendants(Main + "xmlColumnPr").First().Attribute("mapId") ?? map.MapId;
                var uniqueName = $"{map.Prefix}:{LastToken(mapping.SchemaPath)}";
                var candidate = uniqueName;
                var suffix = 2;
                while (!uniqueNames.Add(candidate))
                {
                    candidate = $"{uniqueName}{suffix++}";
                }

                columns[index].SetAttributeValue("uniqueName", candidate);
                columns[index].Add(new XElement(Main + "xmlColumnPr",
                    new XAttribute("mapId", mapId),
                    new XAttribute("xpath", xpath),
                    new XAttribute("xmlDataType", NormalizeXmlDataType(mapping.DataType))));
                boundXPaths.Add(xpath);
                changed = true;
            }

            return changed;
        }

        /// <summary>
        /// Adds columns at the right edge of an existing XML list for elements of the same item that the template
        /// has no column for (mapped by the engine to the next free column). Header text = element name.
        /// </summary>
        private static bool ExtendTableColumns(
            XElement table,
            VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int> area,
            int dataRow,
            IReadOnlyList<MappingEntryDto> sheetMappings,
            XmlMapInfo map,
            XElement sheetData,
            List<VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int>> blocked)
        {
            var boundXPaths = table.Descendants(Main + "xmlColumnPr").Select(x => (string)x.Attribute("xpath")).Where(x => x != null).ToList();
            if (boundXPaths.Count == 0 || area.FirstRow != dataRow - 1)
            {
                return false;
            }

            var itemXPath = boundXPaths[0].Substring(0, boundXPaths[0].LastIndexOf('/'));
            var tableColumns = table.Element(Main + "tableColumns");
            if (tableColumns == null)
            {
                return false;
            }

            var extensions = sheetMappings
                .Where(m => { string unusedColumn; int row; return m.Source == MappingSuggestionEngine.SourceListExtension
                    && TryParseCellAddress(m.CellAddress, out unusedColumn, out row) && row == dataRow; })
                .OrderBy(m => CellColumnIndex(m.CellAddress))
                .ToList();
            var lastColumn = area.LastColumn;
            var names = tableColumns.Elements(Main + "tableColumn").Select(c => (string)c.Attribute("name") ?? "").ToHashSet(StringComparer.OrdinalIgnoreCase);
            var uniqueNames = tableColumns.Elements(Main + "tableColumn").Select(c => (string)c.Attribute("uniqueName") ?? "").ToHashSet(StringComparer.OrdinalIgnoreCase);
            var nextId = tableColumns.Elements(Main + "tableColumn").Select(c => (int?)c.Attribute("id") ?? 0).DefaultIfEmpty(0).Max() + 1;
            var mapId = (string)table.Descendants(Main + "xmlColumnPr").First().Attribute("mapId") ?? map.MapId;
            var changed = false;
            foreach (var mapping in extensions)
            {
                var column = CellColumnIndex(mapping.CellAddress);
                var xpath = ToNsXPath(mapping.SchemaPath, map.Prefix);
                var name = LastToken(mapping.SchemaPath);
                if (column != lastColumn + 1
                    || !string.Equals(xpath.Substring(0, xpath.LastIndexOf('/')), itemXPath, StringComparison.Ordinal)
                    || boundXPaths.Contains(xpath)
                    || names.Contains(name)
                    || blocked.Any(b => b.FirstRow <= dataRow && b.LastRow >= area.FirstRow && b.FirstColumn <= column && b.LastColumn >= column))
                {
                    continue;
                }

                var uniqueName = $"{map.Prefix}:{name}";
                while (!uniqueNames.Add(uniqueName))
                {
                    uniqueName += "_";
                }

                tableColumns.Add(new XElement(Main + "tableColumn",
                    new XAttribute("id", nextId++),
                    new XAttribute("uniqueName", uniqueName),
                    new XAttribute("name", name),
                    new XElement(Main + "xmlColumnPr",
                        new XAttribute("mapId", mapId),
                        new XAttribute("xpath", xpath),
                        new XAttribute("xmlDataType", NormalizeXmlDataType(mapping.DataType)))));
                tableColumns.SetAttributeValue("count", tableColumns.Elements(Main + "tableColumn").Count());
                SetInlineString(GetOrCreateCell(sheetData, ColumnName(column), area.FirstRow), name);
                names.Add(name);
                boundXPaths.Add(xpath);
                lastColumn = column;
                changed = true;
            }

            if (changed)
            {
                var reference = $"{ColumnName(area.FirstColumn)}{area.FirstRow}:{ColumnName(lastColumn)}{area.LastRow}";
                table.SetAttributeValue("ref", reference);
                table.Element(Main + "autoFilter")?.SetAttributeValue("ref", reference);
            }

            return changed;
        }

        /// <summary>Removes 1x1 merge entries inside a table's range (Excel does not allow merged cells in a table).</summary>
        private static void RemoveSingleCellMerges(XElement worksheet, ListTable table)
        {
            var mergeCells = worksheet.Element(Main + "mergeCells");
            if (mergeCells == null)
            {
                return;
            }

            var firstColumn = table.Columns.Min(c => c.Column);
            var lastColumn = table.Columns.Max(c => c.Column);
            foreach (var merge in mergeCells.Elements(Main + "mergeCell").ToList())
            {
                VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int> area;
                if (TryParseRange((string)merge.Attribute("ref"), out area)
                    && area.FirstRow == area.LastRow && area.FirstColumn == area.LastColumn
                    && area.FirstRow >= table.HeaderRow && area.FirstRow <= table.DataRow
                    && area.FirstColumn >= firstColumn && area.FirstColumn <= lastColumn)
                {
                    merge.Remove();
                }
            }

            var remaining = mergeCells.Elements(Main + "mergeCell").Count();
            if (remaining == 0)
            {
                mergeCells.Remove();
            }
            else
            {
                mergeCells.SetAttributeValue("count", remaining);
            }
        }

        private static bool TryParseRange(string reference, out VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int> area)
        {
            area = default(VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int>);
            if (string.IsNullOrWhiteSpace(reference))
            {
                return false;
            }

            var parts = reference.Split(':');
            string unusedColumn;
            int firstRow;
            if (!TryParseCellAddress(parts[0], out unusedColumn, out firstRow))
            {
                return false;
            }

            var lastRef = parts.Length > 1 ? parts[1] : parts[0];
            string unusedColumn2;
            int lastRow;
            if (!TryParseCellAddress(lastRef, out unusedColumn2, out lastRow))
            {
                return false;
            }

            area = new VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int>(Math.Min(firstRow, lastRow), Math.Max(firstRow, lastRow), Math.Min(CellColumnIndex(parts[0]), CellColumnIndex(lastRef)), Math.Max(CellColumnIndex(parts[0]), CellColumnIndex(lastRef)));
            return true;
        }

        private static string AddSheetRelationship(ZipArchive archive, string worksheetPath, string type, string target)
        {
            var directory = Path.GetDirectoryName(worksheetPath)?.Replace('\\', '/') ?? "xl/worksheets";
            var relPath = $"{directory}/_rels/{Path.GetFileName(worksheetPath)}.rels";
            var document = ReadXml(archive, relPath) ?? new XDocument(new XElement(PackageRel + "Relationships"));
            var root = document.Root;
            var id = NextRelationshipId(root);
            root.Add(new XElement(PackageRel + "Relationship",
                new XAttribute("Id", id),
                new XAttribute("Type", type),
                new XAttribute("Target", target)));
            UpsertEntry(archive, relPath, document.ToString(SaveOptions.DisableFormatting));
            return id;
        }

        /// <summary>Adds &lt;tablePart&gt; in the schema position (after everything except extLst).</summary>
        private static void AddTablePart(XElement worksheet, string relationshipId)
        {
            if (worksheet.GetNamespaceOfPrefix("r") != Rel)
            {
                worksheet.SetAttributeValue(XNamespace.Xmlns + "r", Rel.NamespaceName);
            }

            var tableParts = worksheet.Element(Main + "tableParts");
            if (tableParts == null)
            {
                tableParts = new XElement(Main + "tableParts");
                var extensions = worksheet.Element(Main + "extLst");
                if (extensions != null)
                {
                    extensions.AddBeforeSelf(tableParts);
                }
                else
                {
                    worksheet.Add(tableParts);
                }
            }

            tableParts.Add(new XElement(Main + "tablePart", new XAttribute(Rel + "id", relationshipId)));
            tableParts.SetAttributeValue("count", tableParts.Elements(Main + "tablePart").Count());
        }

        /// <summary>Asks Excel to recalculate on open so helper-table formulas show current form values.</summary>
        private static void RequestFullCalculationOnLoad(ZipArchive archive)
        {
            var workbook = ReadXml(archive, "xl/workbook.xml");
            if ((workbook?.Root) == null)
            {
                return;
            }

            var calcPr = workbook.Root.Element(Main + "calcPr");
            if (calcPr == null)
            {
                calcPr = new XElement(Main + "calcPr");
                // calcPr follows sheets/functionGroups/externalReferences/definedNames in the schema.
                var anchor = workbook.Root.Element(Main + "definedNames")
                    ?? workbook.Root.Element(Main + "externalReferences")
                    ?? workbook.Root.Element(Main + "functionGroups")
                    ?? workbook.Root.Element(Main + "sheets");
                if (anchor == null)
                {
                    workbook.Root.Add(calcPr);
                }
                else
                {
                    anchor.AddAfterSelf(calcPr);
                }
            }

            calcPr.SetAttributeValue("fullCalcOnLoad", "1");
            UpsertEntry(archive, "xl/workbook.xml", workbook.ToString(SaveOptions.DisableFormatting));
        }

        private static XElement GetOrCreateCell(XElement sheetData, string columnName, int rowNumber)
        {
            var row = sheetData.Elements(Main + "row").FirstOrDefault(r => (int?)r.Attribute("r") == rowNumber);
            if (row == null)
            {
                row = new XElement(Main + "row", new XAttribute("r", rowNumber));
                InsertRowSorted(sheetData, row, rowNumber);
            }

            var address = $"{columnName}{rowNumber}";
            var cell = row.Elements(Main + "c").FirstOrDefault(c => string.Equals((string)c.Attribute("r"), address, StringComparison.OrdinalIgnoreCase));
            if (cell == null)
            {
                cell = new XElement(Main + "c", new XAttribute("r", address));
                row.Add(cell);
                SortCells(row);
            }

            return cell;
        }

        private static void SetInlineString(XElement cell, string text)
        {
            cell.Elements(Main + "f").Remove();
            cell.Elements(Main + "v").Remove();
            cell.Elements(Main + "is").Remove();
            cell.SetAttributeValue("t", "inlineStr");
            cell.Add(new XElement(Main + "is", new XElement(Main + "t", text)));
        }

        private static void SetFormula(XElement cell, string formula, string cachedValue, string dataType)
        {
            cell.Elements(Main + "f").Remove();
            cell.Elements(Main + "v").Remove();
            cell.Elements(Main + "is").Remove();
            cell.Attribute("t")?.Remove();
            cell.Add(new XElement(Main + "f", formula));
            if (string.IsNullOrEmpty(cachedValue))
            {
                cell.SetAttributeValue("t", "str");
                cell.Add(new XElement(Main + "v", ""));
                return;
            }

            decimal number;
            if ((dataType == "integer" || dataType == "decimal")
                && decimal.TryParse(cachedValue, System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture, out number))
            {
                cell.Add(new XElement(Main + "v", cachedValue));
                return;
            }

            cell.SetAttributeValue("t", "str");
            cell.Add(new XElement(Main + "v", cachedValue));
        }

        private static string CellText(XElement sheetData, string columnName, int rowNumber, IReadOnlyList<string> sharedStrings)
        {
            var address = $"{columnName}{rowNumber}";
            var cell = sheetData.Elements(Main + "row")
                .FirstOrDefault(r => (int?)r.Attribute("r") == rowNumber)?
                .Elements(Main + "c")
                .FirstOrDefault(c => string.Equals((string)c.Attribute("r"), address, StringComparison.OrdinalIgnoreCase));
            if (cell == null)
            {
                return null;
            }

            var type = (string)cell.Attribute("t");
            var value = cell.Element(Main + "v")?.Value;
            int index;
            return type == "s" && int.TryParse(value, out index) && index >= 0 && index < sharedStrings.Count ? sharedStrings[index] : type == "inlineStr" ? string.Concat(cell.Element(Main + "is")?.Descendants(Main + "t").Select(t => t.Value) ?? new List<string>()) : value;
        }

        private static IReadOnlyList<string> ReadSharedStrings(ZipArchive archive)
        {
            var document = ReadXml(archive, "xl/sharedStrings.xml");
            return document?.Root?.Elements(Main + "si")
                .Select(si => string.Concat(si.Descendants(Main + "t").Select(t => t.Value)))
                .ToList() ?? new List<string>();
        }

        private static int MaxRow(XElement sheetData)
        {
            return sheetData.Elements(Main + "row").Select(r => (int?)r.Attribute("r") ?? 0).DefaultIfEmpty(0).Max();
        }

        private static IEnumerable<int> ExistingTableIds(ZipArchive archive)
        {
            foreach (var entry in archive.Entries.Where(e => e.FullName.StartsWith("xl/tables/", StringComparison.OrdinalIgnoreCase)).ToList())
            {
                var root = ReadXml(archive, entry.FullName)?.Root;
                int id;
                if (root?.Name == Main + "table" && int.TryParse((string)root.Attribute("id"), out id))
                {
                    yield return id;
                }
            }
        }

        private static HashSet<string> ExistingTableNames(ZipArchive archive)
        {
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in archive.Entries.Where(e => e.FullName.StartsWith("xl/tables/", StringComparison.OrdinalIgnoreCase)).ToList())
            {
                var root = ReadXml(archive, entry.FullName)?.Root;
                if (root?.Name == Main + "table")
                {
                    names.Add((string)root.Attribute("name") ?? "");
                    names.Add((string)root.Attribute("displayName") ?? "");
                }
            }

            var workbook = ReadXml(archive, "xl/workbook.xml");
            foreach (var definedName in workbook?.Root?.Descendants(Main + "definedName") ?? new List<XElement>())
            {
                names.Add((string)definedName.Attribute("name") ?? "");
            }

            return names;
        }

        private static string UniqueTableName(HashSet<string> used)
        {
            var index = 1;
            string name;
            do
            {
                name = $"FrpXmlList{index++}";
            }
            while (!used.Add(name));

            return name;
        }

        private static string NextFreePart(ZipArchive archive, string prefix, string extension)
        {
            var index = 1;
            while (archive.GetEntry($"{prefix}{index}{extension}") != null)
            {
                index++;
            }

            return $"{prefix}{index}{extension}";
        }

        private static string ColumnName(int index)
        {
            var name = "";
            while (index > 0)
            {
                var remainder = (index - 1) % 26;
                name = (char)('A' + remainder) + name;
                index = (index - 1) / 26;
            }

            return name;
        }

        private sealed class ListGroupPlan : IRecord<ListGroupPlan>, IEquatable<ListGroupPlan>
    {
        public IReadOnlyDictionary<string, List<SchemaNodeDto>> Mappable { get; set; }

        public IReadOnlyList<string> Unmappable { get; set; }

        public ListGroupPlan(IReadOnlyDictionary<string, List<SchemaNodeDto>> Mappable, IReadOnlyList<string> Unmappable)
    {
    this.Mappable = Mappable;
    this.Unmappable = Unmappable;
    }

        public void Deconstruct(out IReadOnlyDictionary<string, List<SchemaNodeDto>> Mappable, out IReadOnlyList<string> Unmappable)
    {
    Mappable = this.Mappable;
    Unmappable = this.Unmappable;
    }

        public bool Equals(ListGroupPlan other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyDictionary<string, List<SchemaNodeDto>>>.Default.Equals(Mappable, other.Mappable)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Unmappable, other.Unmappable);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ListGroupPlan);
    }

        public static bool operator ==(ListGroupPlan left, ListGroupPlan right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ListGroupPlan left, ListGroupPlan right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 13383;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyDictionary<string, List<SchemaNodeDto>>>.Default.GetHashCode(Mappable);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Unmappable);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ListGroupPlan { " + "Mappable = " + Mappable + ", " + "Unmappable = " + Unmappable + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ListGroupPlan CloneRecord()
    {
    return (ListGroupPlan)MemberwiseClone();
    }

    }

        private sealed class ListColumn : IRecord<ListColumn>, IEquatable<ListColumn>
    {
        public int Column { get; set; }

        public string Name { get; set; }

        public SchemaNodeDto Node { get; set; }

        public ListColumn(int Column, string Name, SchemaNodeDto Node)
    {
    this.Column = Column;
    this.Name = Name;
    this.Node = Node;
    }

        public void Deconstruct(out int Column, out string Name, out SchemaNodeDto Node)
    {
    Column = this.Column;
    Name = this.Name;
    Node = this.Node;
    }

        public bool Equals(ListColumn other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<int>.Default.Equals(Column, other.Column)
    && EqualityComparer<string>.Default.Equals(Name, other.Name)
    && EqualityComparer<SchemaNodeDto>.Default.Equals(Node, other.Node);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ListColumn);
    }

        public static bool operator ==(ListColumn left, ListColumn right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ListColumn left, ListColumn right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 17989;
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Column);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    hash = hash * -1521134295 + EqualityComparer<SchemaNodeDto>.Default.GetHashCode(Node);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ListColumn { " + "Column = " + Column + ", " + "Name = " + Name + ", " + "Node = " + Node + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ListColumn CloneRecord()
    {
    return (ListColumn)MemberwiseClone();
    }

    }

        private sealed class ListTable : IRecord<ListTable>, IEquatable<ListTable>
    {
        public int HeaderRow { get; set; }

        public int DataRow { get; set; }

        public IReadOnlyList<ListColumn> Columns { get; set; }

        public ListTable(int HeaderRow, int DataRow, IReadOnlyList<ListColumn> Columns)
    {
    this.HeaderRow = HeaderRow;
    this.DataRow = DataRow;
    this.Columns = Columns;
    }

        public void Deconstruct(out int HeaderRow, out int DataRow, out IReadOnlyList<ListColumn> Columns)
    {
    HeaderRow = this.HeaderRow;
    DataRow = this.DataRow;
    Columns = this.Columns;
    }

        public bool Equals(ListTable other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<int>.Default.Equals(HeaderRow, other.HeaderRow)
    && EqualityComparer<int>.Default.Equals(DataRow, other.DataRow)
    && EqualityComparer<IReadOnlyList<ListColumn>>.Default.Equals(Columns, other.Columns);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ListTable);
    }

        public static bool operator ==(ListTable left, ListTable right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ListTable left, ListTable right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 96287;
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(HeaderRow);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(DataRow);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<ListColumn>>.Default.GetHashCode(Columns);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ListTable { " + "HeaderRow = " + HeaderRow + ", " + "DataRow = " + DataRow + ", " + "Columns = " + Columns + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ListTable CloneRecord()
    {
    return (ListTable)MemberwiseClone();
    }

    }
    }

}
