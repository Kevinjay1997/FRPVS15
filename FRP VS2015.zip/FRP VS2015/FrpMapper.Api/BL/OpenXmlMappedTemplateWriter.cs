﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    public sealed partial class OpenXmlMappedTemplateWriter
    {
        private static readonly XNamespace Main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private static readonly XNamespace Rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        private static readonly XNamespace PackageRel = "http://schemas.openxmlformats.org/package/2006/relationships";
        private static readonly XNamespace ContentTypes = "http://schemas.openxmlformats.org/package/2006/content-types";

        /// <param name="writeValues">False writes the XML map bindings with empty input cells (a blank template for data entry).</param>
        /// <param name="unboundForms">Forms left without XML map bindings (and values), so Excel's XML export leaves them out.</param>
        public byte[] Write(FrpProjectDto project, bool writeValues = true, IReadOnlyCollection<string> unboundForms = null)
        {
            var leftOut = (unboundForms ?? new List<string>()).Select(f => $"/{project.RootElement}/{f}/").ToList();
            var allMappings = XmlSubmissionWriter.GetEffectiveMappings(project)
                .Where(m => !string.IsNullOrWhiteSpace(m.SheetName) && !string.IsNullOrWhiteSpace(m.CellAddress) && !string.IsNullOrWhiteSpace(m.SchemaPath))
                .ToList();
            var mappings = allMappings
                .Where(m => !leftOut.Any(prefix => m.SchemaPath.StartsWith(prefix, StringComparison.Ordinal)))
                .ToList();
            // Cells of the forms left unbound (sample template) still get their XSD data validation, so every mapped cell
            // refuses an invalid entry whichever template is used.
            var unboundMappings = allMappings.Except(mappings).ToList();

            using (var output = new MemoryStream())
            {
            if (project.TemplateFile != null && File.Exists(project.TemplateFile.StoredPath))
            {
                using (var source = File.OpenRead(project.TemplateFile.StoredPath))
                {
                source.CopyTo(output);
                }
            }
            else
            {
                CreateBaseWorkbook(output);
            }

            // Forms the app reads from their sheets itself (split into sheet copies, or holding a list inside their item):
            // no XML map binding, and each list inside them is validated on all of its input rows.
            var splits = SheetSplitRules.Resolve(project);
            var appRead = SheetSplitRules.AppReadForms(project);
            var appReadGroups = appRead.Select(f => f.GroupPath).ToHashSet(StringComparer.Ordinal);
            var validationRanges = appRead
                .SelectMany(f => f.NestedLists)
                .Where(l => l.FirstRow > 0 && l.LastRow > l.FirstRow)
                .SelectMany(l => l.Fields.Select(m =>
                {
                    var column = SheetSplitRules.ColumnLetters(SheetSplitRules.Column(m.CellAddress));
                    return new VT_SchemaPath_Range<string, string>(m.SchemaPath, $"{column}{l.FirstRow}:{column}{l.LastRow}");
                }))
                .ToDictionary(x => x.SchemaPath, x => x.Range, StringComparer.OrdinalIgnoreCase);

            output.Position = 0;
            using (var archive = new ZipArchive(output, ZipArchiveMode.Update, leaveOpen: true))
            {
                var map = EnsureXmlMap(archive, project);
                var lists = new ValidationLists();
                AddMissingSheets(archive, project, mappings);
                WriteMappings(archive, project, mappings, map, writeValues, lists, validationRanges);
                WriteValidationsOnly(archive, project, unboundMappings, lists, validationRanges);
                WriteListTables(archive, project, mappings, map, writeValues, appReadGroups);
                if (writeValues)
                {
                    WriteSampleRows(archive, project, mappings);
                }

                UnbindForms(archive, project, unboundForms ?? new List<string>());
                UnbindPaths(archive, appReadGroups.Select(g => g + "/").ToList());
                SplitSheets(archive, project, splits, writeValues);
                BindFormsForExcel(archive, project, map, leftOut);
                lists.WriteTo(archive);

                RemoveCalculationChain(archive);
            }

            // ZipArchiveMode.Update can carry the source workbook's data-descriptor flag into
            // rewritten entries without writing a descriptor. The XML is valid, but Excel then
            // offers to repair the .xlsx. Re-create the package with consistent local headers.
            return RepackWorkbook(output.ToArray());
            }
        }

        private static byte[] RepackWorkbook(byte[] updated)
        {
            using (var source = new MemoryStream(updated))
            using (var result = new MemoryStream())
            {
                using (var input = new ZipArchive(source, ZipArchiveMode.Read, leaveOpen: true))
                using (var output = new ZipArchive(result, ZipArchiveMode.Create, leaveOpen: true))
                {
                    foreach (var entry in input.Entries)
                    {
                        var copy = output.CreateEntry(entry.FullName, CompressionLevel.Optimal);
                        copy.LastWriteTime = entry.LastWriteTime;
                        using (var read = entry.Open())
                        using (var write = copy.Open()) read.CopyTo(write);
                    }
                }

                return result.ToArray();
            }
        }

        /// <summary>
        /// Reuses the template's XML map when it has one (so its list tables and single cells keep working);
        /// otherwise embeds the project XSD as a new map.
        /// </summary>
        private static XmlMapInfo EnsureXmlMap(ZipArchive archive, FrpProjectDto project)
        {
            var existing = ReadXml(archive, "xl/xmlMaps.xml");
            var existingMap = existing?.Root?.Elements(Main + "Map").FirstOrDefault();
            if ((existing?.Root) != null && existingMap != null)
            {
                var prefix = FindPrefix((string)existing.Root.Attribute("SelectionNamespaces"), project.TargetNamespace) ?? "ns1";
                return new XmlMapInfo((string)existingMap.Attribute("ID") ?? "1", prefix);
            }

            UpsertEntry(archive, "xl/xmlMaps.xml", BuildXmlMaps(project).ToString(SaveOptions.DisableFormatting));
            EnsureWorkbookXmlMapRelationship(archive);
            EnsureXmlMapsContentType(archive);
            return new XmlMapInfo("1", "ns1");
        }

        private static string FindPrefix(string selectionNamespaces, string targetNamespace)
        {
            if (string.IsNullOrWhiteSpace(selectionNamespaces) || string.IsNullOrWhiteSpace(targetNamespace))
            {
                return null;
            }

            foreach (System.Text.RegularExpressions.Match match in System.Text.RegularExpressions.Regex.Matches(selectionNamespaces, "xmlns:([A-Za-z_][\\w.-]*)=['\"]([^'\"]*)['\"]"))
            {
                if (match.Groups[2].Value == targetNamespace)
                {
                    return match.Groups[1].Value;
                }
            }

            return null;
        }

        private static XDocument BuildXmlMaps(FrpProjectDto project)
        {
            var namespaceDeclaration = string.IsNullOrWhiteSpace(project.TargetNamespace)
                ? ""
                : $"xmlns:ns1='{project.TargetNamespace}'";
            var schemaText = project.XsdFile != null && File.Exists(project.XsdFile.StoredPath)
                ? File.ReadAllText(project.XsdFile.StoredPath)
                : "<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"/>";

            return new XDocument(
                new XElement(Main + "MapInfo",
                    new XAttribute("SelectionNamespaces", namespaceDeclaration),
                    new XElement(Main + "Schema",
                        new XAttribute("ID", "Schema1"),
                        new XAttribute("Namespace", project.TargetNamespace ?? ""),
                        SafeXml.Parse(schemaText)),
                    new XElement(Main + "Map",
                        new XAttribute("ID", "1"),
                        new XAttribute("Name", $"{project.RootElement ?? "FRP"}_Map"),
                        new XAttribute("RootElement", project.RootElement ?? "Root"),
                        new XAttribute("SchemaID", "Schema1"),
                        new XAttribute("ShowImportExportValidationErrors", "false"),
                        new XAttribute("AutoFit", "true"),
                        new XAttribute("Append", "false"),
                        new XAttribute("PreserveSortAFLayout", "true"),
                        new XAttribute("PreserveFormat", "true"))));
        }

        /// <summary>Adds a worksheet for every mapped sheet the workbook does not have (e.g. Header, FRP_Unplaced).</summary>
        private static void AddMissingSheets(ZipArchive archive, FrpProjectDto project, IReadOnlyList<MappingEntryDto> mappings)
        {
            var existing = ReadSheets(archive).Select(s => s.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var sheetOrder = SchemaSheetOrder(project);
            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            GeneratedSheetStyles styles = null;

            foreach (var group in mappings.GroupBy(m => m.SheetName, StringComparer.OrdinalIgnoreCase))
            {
                if (existing.Contains(group.Key))
                {
                    continue;
                }

                var workbook = ReadXml(archive, "xl/workbook.xml") ?? CompatThrow.As<XDocument>(new InvalidOperationException("Workbook is missing xl/workbook.xml."));
                var rels = ReadXml(archive, "xl/_rels/workbook.xml.rels") ?? new XDocument(new XElement(PackageRel + "Relationships"));
                var sheetsElement = workbook.Root.Element(Main + "sheets");
                if (sheetsElement == null)
                {
                    sheetsElement = new XElement(Main + "sheets");
                    workbook.Root.Add(sheetsElement);
                }

                var partIndex = 1;
                while (archive.GetEntry($"xl/worksheets/frpSheet{partIndex}.xml") != null)
                {
                    partIndex++;
                }

                var partPath = $"xl/worksheets/frpSheet{partIndex}.xml";
                var relationshipId = NextRelationshipId(rels.Root);
                rels.Root.Add(new XElement(PackageRel + "Relationship",
                    new XAttribute("Id", relationshipId),
                    new XAttribute("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"),
                    new XAttribute("Target", $"worksheets/frpSheet{partIndex}.xml")));

                var nextSheetId = sheetsElement.Elements(Main + "sheet")
                    .Select(e => (int?)e.Attribute("sheetId") ?? 0)
                    .DefaultIfEmpty(0)
                    .Max() + 1;
                var newSheet = new XElement(Main + "sheet",
                    new XAttribute("name", group.Key),
                    new XAttribute("sheetId", nextSheetId),
                    new XAttribute(Rel + "id", relationshipId));
                InsertSheetInSchemaOrder(workbook.Root, sheetsElement, newSheet, group.Key, sheetOrder);

                UpsertEntry(archive, "xl/_rels/workbook.xml.rels", rels.ToString(SaveOptions.DisableFormatting));
                UpsertEntry(archive, "xl/workbook.xml", workbook.ToString(SaveOptions.DisableFormatting));
                var isUnplacedSheet = string.Equals(group.Key, MappingSuggestionEngine.UnplacedSheetName, StringComparison.OrdinalIgnoreCase);
                if (!isUnplacedSheet)
                {
                    if (styles == null) styles = EnsureGeneratedSheetStyles(archive);
                }

                UpsertEntry(archive, partPath, isUnplacedSheet
                    ? BuildUnplacedWorksheet(group.ToList(), nodesByPath)
                    : BuildXsdSheetWorksheet(group.Key, project.RootElement, group.ToList(), nodesByPath, styles));
                EnsureContentType(archive, $"/{partPath}", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml");
                existing.Add(group.Key);
            }
        }

        private static void WriteMappings(ZipArchive archive, FrpProjectDto project, IReadOnlyList<MappingEntryDto> mappings, XmlMapInfo map, bool writeValues,
            ValidationLists lists, IReadOnlyDictionary<string, string> validationRanges)
        {
            var sheets = ReadSheets(archive);
            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var nextCellId = 100000;

            foreach (var group in mappings.GroupBy(m => m.SheetName, StringComparer.OrdinalIgnoreCase))
            {
                var sheet = sheets.FirstOrDefault(s => string.Equals(s.Name, group.Key, StringComparison.OrdinalIgnoreCase));
                if (sheet.WorksheetPath == null)
                {
                    continue;
                }

                var groupMappings = group.ToList();
                WriteWorksheetValues(archive, project, sheet.WorksheetPath, groupMappings, writeValues);
                WriteWorksheetValidations(archive, sheet.WorksheetPath, groupMappings, nodesByPath, lists, validationRanges);

                // Single-cell XML maps only for elements Excel can bind to one cell:
                // not already bound by the template, and not inside a repeating group (those need list tables).
                var bindable = groupMappings
                    .Where(m => !(m.Source == MappingSuggestionEngine.SourceExistingSingle || m.Source == MappingSuggestionEngine.SourceExistingList))
                    .Where(m => { SchemaNodeDto node; return nodesByPath.TryGetValue(m.SchemaPath, out node) && !node.IsInRepeatingGroup; })
                    .ToList();
                if (bindable.Count > 0)
                {
                    WriteSingleCells(archive, sheet.WorksheetPath, bindable, map, ref nextCellId);
                }
            }
        }

        private static void WriteValidationsOnly(ZipArchive archive, FrpProjectDto project, IReadOnlyList<MappingEntryDto> mappings, ValidationLists lists,
            IReadOnlyDictionary<string, string> validationRanges)
        {
            if (mappings.Count == 0)
            {
                return;
            }

            var sheets = ReadSheets(archive);
            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            foreach (var group in mappings.GroupBy(m => m.SheetName, StringComparer.OrdinalIgnoreCase))
            {
                var sheet = sheets.FirstOrDefault(s => string.Equals(s.Name, group.Key, StringComparison.OrdinalIgnoreCase));
                if (sheet.WorksheetPath != null)
                {
                    WriteWorksheetValidations(archive, sheet.WorksheetPath, group.ToList(), nodesByPath, lists, validationRanges);
                }
            }
        }

        private static void WriteWorksheetValidations(
            ZipArchive archive,
            string worksheetPath,
            IReadOnlyList<MappingEntryDto> mappings,
            IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath,
            ValidationLists lists,
            IReadOnlyDictionary<string, string> validationRanges)
        {
            var document = ReadXml(archive, worksheetPath);
            if ((document?.Root) == null)
            {
                return;
            }

            var validations = mappings
                .Where(m => nodesByPath.ContainsKey(m.SchemaPath))
                .Select(m => XsdExcelValidationBuilder.Build(nodesByPath[m.SchemaPath],
                    validationRanges.GetValueOrDefault(m.SchemaPath) ?? m.CellAddress.ToUpperInvariant(), lists.Reference))
                .Where(v => v != null)
                .Select(v => v)
                .ToList();

            XsdExcelValidationBuilder.UpsertDataValidations(document.Root, validations);
            UpsertEntry(archive, worksheetPath, document.ToString(SaveOptions.DisableFormatting));
        }

        private static void WriteSingleCells(ZipArchive archive, string worksheetPath, IReadOnlyList<MappingEntryDto> mappings, XmlMapInfo map, ref int nextCellId)
        {
            var directory = Path.GetDirectoryName(worksheetPath)?.Replace('\\', '/') ?? "xl/worksheets";
            var relPath = $"{directory}/_rels/{Path.GetFileName(worksheetPath)}.rels";
            var rels = ReadXml(archive, relPath);
            var existingTarget = rels?.Root?.Elements(PackageRel + "Relationship")
                .FirstOrDefault(e => ((string)e.Attribute("Type"))?.EndsWith("/tableSingleCells", StringComparison.OrdinalIgnoreCase) == true);

            // A worksheet can only have one singleXmlCells part: append to the template's part when it exists.
            string partPath;
            XDocument document;
            if (existingTarget != null)
            {
                partPath = NormalizePartPath(directory, (string)existingTarget.Attribute("Target"));
                document = ReadXml(archive, partPath) ?? new XDocument(new XElement(Main + "singleXmlCells"));
            }
            else
            {
                var index = 1;
                while (archive.GetEntry($"xl/tables/frpSingleCells{index}.xml") != null)
                {
                    index++;
                }

                partPath = $"xl/tables/frpSingleCells{index}.xml";
                document = new XDocument(new XElement(Main + "singleXmlCells"));
                EnsureContentType(archive, $"/{partPath}", "application/vnd.openxmlformats-officedocument.spreadsheetml.tableSingleCells+xml");
                EnsureSheetRelationship(archive, worksheetPath, $"../tables/frpSingleCells{index}.xml");
            }

            var root = document.Root;
            var boundCells = root.Elements(Main + "singleXmlCell")
                .Select(e => (string)e.Attribute("r"))
                .Where(r => r != null)
                .ToHashSet(StringComparer.OrdinalIgnoreCase);
            var boundPaths = root.Descendants(Main + "xmlPr")
                .Select(e => (string)e.Attribute("xpath"))
                .Where(x => x != null)
                .ToHashSet(StringComparer.Ordinal);
            // Excel requires every uniqueName in a singleXmlCells part to be different, and repairs the workbook (dropping
            // the XML mapping) when two are the same. Leaf names repeat across a form's tables (MAIN/R0020C0010 and
            // ADD1/R0020C0010 on one sheet), so a repeated name gets a number (only the xpath identifies the element).
            var uniqueNames = root.Descendants(Main + "xmlCellPr")
                .Select(e => (string)e.Attribute("uniqueName"))
                .Where(n => n != null)
                .ToHashSet(StringComparer.OrdinalIgnoreCase);

            foreach (var mapping in mappings)
            {
                var xpath = ToNsXPath(mapping.SchemaPath, map.Prefix);
                if (boundCells.Contains(mapping.CellAddress) || boundPaths.Contains(xpath))
                {
                    continue;
                }

                var uniqueName = $"{map.Prefix}:{LastToken(mapping.SchemaPath)}";
                var candidate = uniqueName;
                for (var suffix = 2; !uniqueNames.Add(candidate); suffix++)
                {
                    candidate = uniqueName + suffix.ToString(CultureInfo.InvariantCulture);
                }

                root.Add(
                    new XElement(Main + "singleXmlCell",
                        new XAttribute("id", nextCellId++),
                        new XAttribute("r", mapping.CellAddress),
                        new XAttribute("connectionId", "0"),
                        new XElement(Main + "xmlCellPr",
                            new XAttribute("id", "1"),
                            new XAttribute("uniqueName", candidate),
                            new XElement(Main + "xmlPr",
                                new XAttribute("mapId", map.MapId),
                                new XAttribute("xpath", xpath),
                                new XAttribute("xmlDataType", NormalizeXmlDataType(mapping.DataType))))));
                boundCells.Add(mapping.CellAddress);
                boundPaths.Add(xpath);
            }

            UpsertEntry(archive, partPath, document.ToString(SaveOptions.DisableFormatting));
        }

        private static void WriteWorksheetValues(ZipArchive archive, FrpProjectDto project, string worksheetPath, IReadOnlyList<MappingEntryDto> mappings, bool writeValues)
        {
            var document = ReadXml(archive, worksheetPath);
            if ((document?.Root) == null)
            {
                return;
            }

            var sheetData = document.Root.Element(Main + "sheetData");
            if (sheetData == null)
            {
                sheetData = new XElement(Main + "sheetData");
                document.Root.Add(sheetData);
            }

            var rows = sheetData.Elements(Main + "row")
                .Where(r => r.Attribute("r") != null)
                .GroupBy(r => (int)r.Attribute("r"))
                .ToDictionary(g => g.Key, g => g.First());

            foreach (var mapping in mappings)
            {
                string unusedColumn;
                int rowNumber;
                if (!TryParseCellAddress(mapping.CellAddress, out unusedColumn, out rowNumber))
                {
                    continue;
                }

                XElement row;
                if (!rows.TryGetValue(rowNumber, out row))
                {
                    row = new XElement(Main + "row", new XAttribute("r", rowNumber));
                    InsertRowSorted(sheetData, row, rowNumber);
                    rows[rowNumber] = row;
                }

                var address = mapping.CellAddress.ToUpperInvariant();
                var cell = row.Elements(Main + "c")
                    .FirstOrDefault(c => string.Equals((string)c.Attribute("r"), address, StringComparison.OrdinalIgnoreCase));
                if (cell == null)
                {
                    cell = new XElement(Main + "c", new XAttribute("r", address));
                    row.Add(cell);
                    SortCells(row);
                }

                SetCellValue(cell, writeValues ? XmlSubmissionWriter.ResolveExportValue(project, mapping) : null, mapping.DataType);
            }

            UpsertEntry(archive, worksheetPath, document.ToString(SaveOptions.DisableFormatting));
        }

        /// <summary>
        /// calcChain.xml lists formula cells; after input cells change it can point at cells without formulas,
        /// which makes Excel "repair" the file. Excel rebuilds it on open, so it is safe to drop.
        /// </summary>
        private static void RemoveCalculationChain(ZipArchive archive)
        {
            var entry = archive.GetEntry("xl/calcChain.xml");
            if (entry == null)
            {
                return;
            }

            entry.Delete();
            var rels = ReadXml(archive, "xl/_rels/workbook.xml.rels");
            var relationship = rels?.Root?.Elements(PackageRel + "Relationship")
                .FirstOrDefault(e => ((string)e.Attribute("Type"))?.EndsWith("/calcChain", StringComparison.OrdinalIgnoreCase) == true);
            if (relationship != null)
            {
                relationship.Remove();
                UpsertEntry(archive, "xl/_rels/workbook.xml.rels", rels.ToString(SaveOptions.DisableFormatting));
            }

            var contentTypes = ReadXml(archive, "[Content_Types].xml");
            var overrideElement = contentTypes?.Root?.Elements(ContentTypes + "Override")
                .FirstOrDefault(e => string.Equals((string)e.Attribute("PartName"), "/xl/calcChain.xml", StringComparison.OrdinalIgnoreCase));
            if (overrideElement != null)
            {
                overrideElement.Remove();
                UpsertEntry(archive, "[Content_Types].xml", contentTypes.ToString(SaveOptions.DisableFormatting));
            }
        }

        private static void InsertRowSorted(XElement sheetData, XElement row, int rowNumber)
        {
            var after = sheetData.Elements(Main + "row")
                .LastOrDefault(r => ((int?)r.Attribute("r") ?? 0) < rowNumber);
            if (after == null)
            {
                sheetData.AddFirst(row);
            }
            else
            {
                after.AddAfterSelf(row);
            }
        }

        private struct XmlMapInfo : IEquatable<XmlMapInfo>
    {
        public string MapId { get; set; }

        public string Prefix { get; set; }

        public XmlMapInfo(string MapId, string Prefix)
    {
    this.MapId = MapId;
    this.Prefix = Prefix;
    }

        public void Deconstruct(out string MapId, out string Prefix)
    {
    MapId = this.MapId;
    Prefix = this.Prefix;
    }

        public bool Equals(XmlMapInfo other)
    {
    return EqualityComparer<string>.Default.Equals(MapId, other.MapId) && EqualityComparer<string>.Default.Equals(Prefix, other.Prefix);
    }

        public override bool Equals(object obj)
    {
    return obj is XmlMapInfo && Equals((XmlMapInfo)obj);
    }

        public static bool operator ==(XmlMapInfo left, XmlMapInfo right)
    {
    return left.Equals(right);
    }

        public static bool operator !=(XmlMapInfo left, XmlMapInfo right)
    {
    return !left.Equals(right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 45444;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(MapId);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Prefix);
    return hash;
    }
    }

        public override string ToString()
    {
    return "XmlMapInfo { " + "MapId = " + MapId + ", " + "Prefix = " + Prefix + " }";
    }

    }

        /// <summary>Writes a value into a cell (keeping its style); a null value leaves the input cell empty.</summary>
        private static void SetCellValue(XElement cell, string value, string dataType)
        {
            // Mapped cells are inputs: drop plain formulas, but keep shared-formula masters other cells depend on.
            var formula = cell.Element(Main + "f");
            if (formula != null && !((string)formula.Attribute("t") == "shared" && formula.Attribute("ref") != null))
            {
                formula.Remove();
            }

            cell.Elements(Main + "v").Remove();
            cell.Elements(Main + "is").Remove();
            cell.Attribute("t")?.Remove();
            if (string.IsNullOrEmpty(value))
            {
                return; // an empty input cell (e.g. a field whose sample value was removed)
            }

            decimal number;
            if ((dataType == "integer" || dataType == "decimal") && decimal.TryParse(value, System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture, out number))
            {
                cell.Add(new XElement(Main + "v", value));
                return;
            }

            cell.SetAttributeValue("t", "inlineStr");
            cell.Add(new XElement(Main + "is", new XElement(Main + "t", value)));
        }

        private static void EnsureWorkbookXmlMapRelationship(ZipArchive archive)
        {
            const string relPath = "xl/_rels/workbook.xml.rels";
            var document = ReadXml(archive, relPath) ?? new XDocument(new XElement(PackageRel + "Relationships"));
            var root = document.Root;
            var exists = root.Elements(PackageRel + "Relationship")
                .Any(e => ((string)e.Attribute("Type"))?.EndsWith("/xmlMaps", StringComparison.OrdinalIgnoreCase) == true);
            if (!exists)
            {
                root.Add(new XElement(PackageRel + "Relationship",
                    new XAttribute("Id", NextRelationshipId(root)),
                    new XAttribute("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/xmlMaps"),
                    new XAttribute("Target", "xmlMaps.xml")));
                UpsertEntry(archive, relPath, document.ToString(SaveOptions.DisableFormatting));
            }
        }

        private static void EnsureSheetRelationship(ZipArchive archive, string worksheetPath, string target)
        {
            var directory = Path.GetDirectoryName(worksheetPath)?.Replace('\\', '/') ?? "xl/worksheets";
            var fileName = Path.GetFileName(worksheetPath);
            var relPath = $"{directory}/_rels/{fileName}.rels";
            var document = ReadXml(archive, relPath) ?? new XDocument(new XElement(PackageRel + "Relationships"));
            var root = document.Root;
            var exists = root.Elements(PackageRel + "Relationship").Any(e => (string)e.Attribute("Target") == target);
            if (!exists)
            {
                root.Add(new XElement(PackageRel + "Relationship",
                    new XAttribute("Id", NextRelationshipId(root)),
                    new XAttribute("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/tableSingleCells"),
                    new XAttribute("Target", target)));
            }

            UpsertEntry(archive, relPath, document.ToString(SaveOptions.DisableFormatting));
        }

        private static void EnsureXmlMapsContentType(ZipArchive archive)
        {
            EnsureContentType(archive, "/xl/xmlMaps.xml", "application/xml");
        }

        private static void EnsureContentType(ZipArchive archive, string partName, string contentType)
        {
            const string path = "[Content_Types].xml";
            var document = ReadXml(archive, path) ?? new XDocument(new XElement(ContentTypes + "Types"));
            var root = document.Root;
            var exists = root.Elements(ContentTypes + "Override")
                .Any(e => string.Equals((string)e.Attribute("PartName"), partName, StringComparison.OrdinalIgnoreCase));
            if (!exists)
            {
                root.Add(new XElement(ContentTypes + "Override",
                    new XAttribute("PartName", partName),
                    new XAttribute("ContentType", contentType)));
                UpsertEntry(archive, path, document.ToString(SaveOptions.DisableFormatting));
            }
        }

        private static IReadOnlyList<VT_Name_RelationshipId_WorksheetPath<string, string, string>> ReadSheets(ZipArchive archive)
        {
            var workbook = ReadXml(archive, "xl/workbook.xml") ?? CompatThrow.As<XDocument>(new InvalidOperationException("Workbook is missing xl/workbook.xml."));
            var rels = ReadXml(archive, "xl/_rels/workbook.xml.rels") ?? CompatThrow.As<XDocument>(new InvalidOperationException("Workbook is missing relationships."));
            var relTargets = rels.Root?.Elements(PackageRel + "Relationship")
                .ToDictionary(e => (string)e.Attribute("Id"), e => (string)e.Attribute("Target")) ?? new Dictionary<string, string>();
            return workbook.Descendants(Main + "sheet")
                .Select(sheet =>
                {
                    var relationshipId = (string)sheet.Attribute(Rel + "id") ?? "";
                    string target;
                    relTargets.TryGetValue(relationshipId, out target);
                    return new VT_Name_RelationshipId_WorksheetPath<string, string, string>((string)sheet.Attribute("name") ?? "Sheet", relationshipId, NormalizePartPath("xl", target ?? "worksheets/sheet1.xml"));
                })
                .ToList();
        }

        /// <summary>Minimal workbook without worksheets; every mapped sheet is added by <see cref="AddMissingSheets"/>.</summary>
        private static void CreateBaseWorkbook(Stream output)
        {
            using (var archive = new ZipArchive(output, ZipArchiveMode.Create, leaveOpen: true))
            {
            UpsertEntry(archive, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">\n  <Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>\n  <Default Extension=\"xml\" ContentType=\"application/xml\"/>\n  <Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>\n  <Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>\n</Types>");
            UpsertEntry(archive, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">\n  <Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>\n</Relationships>");
            UpsertEntry(archive, "xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">\n  <Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>\n</Relationships>");
            UpsertEntry(archive, "xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">\n  <sheets/>\n</workbook>");
            UpsertEntry(archive, "xl/styles.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts><fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills><borders count=\"1\"><border/></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs></styleSheet>");
            }
        }

        /// <summary>XSD sheet elements (second path level) in schema order, e.g. Header, CAR_Info, CAR_Part_II...</summary>
        private static List<string> SchemaSheetOrder(FrpProjectDto project)
        {
            return project.SchemaNodes
                .Select(n => n.Path.Split('/', StringSplitOptions.RemoveEmptyEntries))
                .Where(t => t.Length >= 2)
                .Select(t => MappingSuggestionEngine.SafeSheetName(t[1]))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        /// <summary>
        /// Places a generated sheet in XSD order (Header first). Sheets after the insertion point move one position,
        /// so sheet-scoped defined names (localSheetId) and the active/first visible tab are shifted to match.
        /// </summary>
        private static void InsertSheetInSchemaOrder(XElement workbookRoot, XElement sheetsElement, XElement newSheet, string sheetName, IReadOnlyList<string> sheetOrder)
        {
            var sheets = sheetsElement.Elements(Main + "sheet").ToList();
            var order = sheetOrder.ToList();
            var newIndex = order.FindIndex(n => string.Equals(n, sheetName, StringComparison.OrdinalIgnoreCase));
            var insertAt = sheets.Count;
            if (newIndex >= 0)
            {
                for (var i = 0; i < sheets.Count; i++)
                {
                    var existingName = (string)sheets[i].Attribute("name") ?? "";
                    var existingIndex = order.FindIndex(n => string.Equals(n, existingName, StringComparison.OrdinalIgnoreCase)
                        || string.Equals(Compact(n), Compact(existingName), StringComparison.OrdinalIgnoreCase));
                    if (existingIndex > newIndex)
                    {
                        insertAt = i;
                        break;
                    }
                }
            }

            if (insertAt >= sheets.Count)
            {
                sheetsElement.Add(newSheet);
                return;
            }

            sheets[insertAt].AddBeforeSelf(newSheet);
            foreach (var definedName in workbookRoot.Descendants(Main + "definedName"))
            {
                int localSheetId;
                if (int.TryParse((string)definedName.Attribute("localSheetId"), out localSheetId) && localSheetId >= insertAt)
                {
                    definedName.SetAttributeValue("localSheetId", localSheetId + 1);
                }
            }

            foreach (var view in workbookRoot.Descendants(Main + "workbookView"))
            {
                foreach (var attributeName in new[] { "activeTab", "firstSheet" })
                {
                    int tab;
                    if (int.TryParse((string)view.Attribute(attributeName), out tab) && tab >= insertAt)
                    {
                        view.SetAttributeValue(attributeName, tab + 1);
                    }
                }
            }
        }

        /// <summary>
        /// BSP-style sheet for an XSD sheet element missing from the template (e.g. Header), laid out and coloured like
        /// BSP's own HEADER sheets: A1 = root element and A3 = sheet element (bold dark red on the beige sheet), B = field
        /// names (blue-grey, bordered), and the mapped value cells (white, bordered, unlocked for input).
        /// </summary>
        private static string BuildXsdSheetWorksheet(string sheetName, string rootElement, IReadOnlyList<MappingEntryDto> mappings,
            IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath, GeneratedSheetStyles styles)
        {
            var rows = new SortedDictionary<int, StringBuilder>
            {
                [1] = new StringBuilder($"<c r=\"A1\" s=\"{styles.Title}\" t=\"inlineStr\"><is><t>{Escape(rootElement ?? "")}</t></is></c>"),
                [2] = new StringBuilder(),
                [3] = new StringBuilder($"<c r=\"A3\" s=\"{styles.Title}\" t=\"inlineStr\"><is><t>{Escape(sheetName)}</t></is></c>")
            };
            var lastColumn = 3;
            foreach (var mapping in mappings
                         .Select(m => { string column; int r; return new VT_Mapping_Parsed<MappingEntryDto, VT_Column_Row<string, int>>(m, TryParseCellAddress(m.CellAddress, out column, out r) ? new VT_Column_Row<string, int>(column, r) : new VT_Column_Row<string, int>("", 0)); })
                         .Where(x => x.Parsed.Row > 3)
                         .OrderBy(x => x.Parsed.Row))
            {
                var cell = mapping.Parsed;
                var column = cell.Column;
                var row = cell.Row;
                var tokens = mapping.Mapping.SchemaPath.Split('/', StringSplitOptions.RemoveEmptyEntries);
                var label = tokens.Length > 2 ? string.Join("/", CompatArray.Slice(tokens, 2)) : tokens.LastOrDefault() ?? "";
                SchemaNodeDto node;
                var dataType = nodesByPath.TryGetValue(mapping.Mapping.SchemaPath, out node) ? node.DataType : mapping.Mapping.DataType;
                var valueStyle = (dataType == "string" || dataType == "" || dataType == null) ? styles.TextValue : styles.NumberValue;
                var cells = new StringBuilder();
                if (!string.Equals(column, "B", StringComparison.OrdinalIgnoreCase))
                {
                    cells.Append($"<c r=\"B{row}\" s=\"{styles.Label}\" t=\"inlineStr\"><is><t>{Escape(label)}</t></is></c>");
                }

                cells.Append($"<c r=\"{column}{row}\" s=\"{valueStyle}\"/>");
                rows[row] = cells;
                lastColumn = Math.Max(lastColumn, CellColumnIndex(column));
            }

            var sheetRows = new StringBuilder();
            for (var row = 1; row <= rows.Keys.Max(); row++)
            {
                StringBuilder content;
                var cells = rows.TryGetValue(row, out content) ? content.ToString() : "";
                sheetRows.Append($"<row r=\"{row}\" ht=\"18\" customHeight=\"1\">{cells}</row>");
            }

            var lastRow = rows.Keys.Max();
            var lastColumnName = ColumnName(lastColumn);
            return $"<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><dimension ref=\"A1:{lastColumnName}{lastRow}\"/><sheetViews><sheetView zoomScale=\"90\" zoomScaleNormal=\"90\" workbookViewId=\"0\"/></sheetViews><sheetFormatPr defaultColWidth=\"25\" defaultRowHeight=\"18\" customHeight=\"1\"/><cols><col min=\"1\" max=\"1\" width=\"8.1796875\" style=\"{styles.Band}\" customWidth=\"1\"/><col min=\"2\" max=\"3\" width=\"26\" style=\"{styles.Band}\" customWidth=\"1\"/><col min=\"4\" max=\"16384\" width=\"25\" style=\"{styles.Band}\"/></cols><sheetData>{sheetRows}</sheetData></worksheet>";
        }

        /// <summary>Cell formats of a generated XSD sheet (indexes into the workbook's cellXfs).</summary>
        private sealed class GeneratedSheetStyles : IRecord<GeneratedSheetStyles>, IEquatable<GeneratedSheetStyles>
    {
        public int Band { get; set; }

        public int Title { get; set; }

        public int Label { get; set; }

        public int TextValue { get; set; }

        public int NumberValue { get; set; }

        public GeneratedSheetStyles(int Band, int Title, int Label, int TextValue, int NumberValue)
    {
    this.Band = Band;
    this.Title = Title;
    this.Label = Label;
    this.TextValue = TextValue;
    this.NumberValue = NumberValue;
    }

        public void Deconstruct(out int Band, out int Title, out int Label, out int TextValue, out int NumberValue)
    {
    Band = this.Band;
    Title = this.Title;
    Label = this.Label;
    TextValue = this.TextValue;
    NumberValue = this.NumberValue;
    }

        public bool Equals(GeneratedSheetStyles other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<int>.Default.Equals(Band, other.Band)
    && EqualityComparer<int>.Default.Equals(Title, other.Title)
    && EqualityComparer<int>.Default.Equals(Label, other.Label)
    && EqualityComparer<int>.Default.Equals(TextValue, other.TextValue)
    && EqualityComparer<int>.Default.Equals(NumberValue, other.NumberValue);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as GeneratedSheetStyles);
    }

        public static bool operator ==(GeneratedSheetStyles left, GeneratedSheetStyles right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(GeneratedSheetStyles left, GeneratedSheetStyles right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 87363;
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Band);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Title);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Label);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(TextValue);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(NumberValue);
    return hash;
    }
    }

        public override string ToString()
    {
    return "GeneratedSheetStyles { " + "Band = " + Band + ", " + "Title = " + Title + ", " + "Label = " + Label + ", " + "TextValue = " + TextValue + ", " + "NumberValue = " + NumberValue + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public GeneratedSheetStyles CloneRecord()
    {
    return (GeneratedSheetStyles)MemberwiseClone();
    }

    }

        /// <summary>Adds an item to a collection of styles.xml (creating the collection before <paramref name="before"/>); returns its index.</summary>
        private static int AppendStyle(XElement root, string collectionName, string itemName, XElement item, string[] before)
        {
            var collection = root.Element(Main + collectionName);
            if (collection == null)
            {
                collection = new XElement(Main + collectionName);
                var next = root.Elements().FirstOrDefault(e => before.Contains(e.Name.LocalName));
                if (next == null)
                {
                    root.Add(collection);
                }
                else
                {
                    next.AddBeforeSelf(collection);
                }
            }

            collection.Add(item);
            var count = collection.Elements(Main + itemName).Count();
            collection.SetAttributeValue("count", count);
            return count - 1;
        }

        /// <summary>
        /// Adds BSP's HEADER-sheet formats to the workbook's styles.xml (the template keeps all of its own): beige sheet
        /// background (#FFE4B5), bold dark red titles (#8B0000), blue-grey bordered field names (#8497B0), and white
        /// bordered, unlocked value cells (text format for text fields).
        /// </summary>
        private static GeneratedSheetStyles EnsureGeneratedSheetStyles(ZipArchive archive)
        {
            var document = ReadXml(archive, "xl/styles.xml") ?? CompatThrow.As<XDocument>(new InvalidOperationException("The workbook has no xl/styles.xml."));
            var root = document.Root;

            string[] afterFonts = new string[] { "fills", "borders", "cellStyleXfs", "cellXfs", "cellStyles", "dxfs", "tableStyles", "colors", "extLst" };
            string[] afterFills = new string[] { "borders", "cellStyleXfs", "cellXfs", "cellStyles", "dxfs", "tableStyles", "colors", "extLst" };
            string[] afterBorders = new string[] { "cellStyleXfs", "cellXfs", "cellStyles", "dxfs", "tableStyles", "colors", "extLst" };
            string[] afterCellXfs = new string[] { "cellStyles", "dxfs", "tableStyles", "colors", "extLst" };

            var plainFont = AppendStyle(root, "fonts", "font", new XElement(Main + "font",
                new XElement(Main + "sz", new XAttribute("val", "11")), new XElement(Main + "name", new XAttribute("val", "Calibri")),
                new XElement(Main + "family", new XAttribute("val", "2"))), afterFonts);
            var titleFont = AppendStyle(root, "fonts", "font", new XElement(Main + "font", new XElement(Main + "b"),
                new XElement(Main + "sz", new XAttribute("val", "11")), new XElement(Main + "color", new XAttribute("rgb", "FF8B0000")),
                new XElement(Main + "name", new XAttribute("val", "Calibri")), new XElement(Main + "family", new XAttribute("val", "2"))), afterFonts);
            var beige = AppendStyle(root, "fills", "fill", Solid("FFFFE4B5"), afterFills);
            var blueGrey = AppendStyle(root, "fills", "fill", Solid("FF8497B0"), afterFills);
            var white = AppendStyle(root, "fills", "fill", Solid("FFFFFFFF"), afterFills);
            var thin = AppendStyle(root, "borders", "border", new XElement(Main + "border", Thin("left"), Thin("right"), Thin("top"), Thin("bottom"),
                new XElement(Main + "diagonal")), afterBorders);

            var styles = new GeneratedSheetStyles(
                Band: AppendStyle(root, "cellXfs", "xf", Xf(0, plainFont, beige, 0, null, false), afterCellXfs),
                Title: AppendStyle(root, "cellXfs", "xf", Xf(0, titleFont, beige, 0, null, false), afterCellXfs),
                Label: AppendStyle(root, "cellXfs", "xf", Xf(0, plainFont, blueGrey, thin, Align("left", wrap: true), false), afterCellXfs),
                TextValue: AppendStyle(root, "cellXfs", "xf", Xf(49, plainFont, white, thin, Align("left"), true), afterCellXfs),
                NumberValue: AppendStyle(root, "cellXfs", "xf", Xf(0, plainFont, white, thin, Align("right"), true), afterCellXfs));
            UpsertEntry(archive, "xl/styles.xml", document.ToString(SaveOptions.DisableFormatting));
            return styles;
        }

        /// <summary>Sheet for fields that could not be located: A = XSD path, B = value (mapped cell), C = data type, D = required.</summary>
        private static string BuildUnplacedWorksheet(IReadOnlyList<MappingEntryDto> mappings, IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath)
        {
            var cells = new StringBuilder();
            cells.Append("<row r=\"1\"><c r=\"A1\" t=\"inlineStr\"><is><t>XSD path</t></is></c><c r=\"B1\" t=\"inlineStr\"><is><t>Value</t></is></c><c r=\"C1\" t=\"inlineStr\"><is><t>Data type</t></is></c><c r=\"D1\" t=\"inlineStr\"><is><t>Required</t></is></c></row>");
            var lastRow = 1;
            foreach (var mapping in mappings
                         .Select(m => { string unusedColumn; int r; return new VT_Mapping_Row<MappingEntryDto, int>(m, TryParseCellAddress(m.CellAddress, out unusedColumn, out r) ? r : 0); })
                         .Where(x => x.Row > 1)
                         .OrderBy(x => x.Row))
            {
                var node = nodesByPath.GetValueOrDefault(mapping.Mapping.SchemaPath);
                var row = mapping.Row;
                cells.Append($"<row r=\"{row}\"><c r=\"A{row}\" t=\"inlineStr\"><is><t>{Escape(mapping.Mapping.SchemaPath)}</t></is></c><c r=\"C{row}\" t=\"inlineStr\"><is><t>{Escape(mapping.Mapping.DataType)}</t></is></c><c r=\"D{row}\" t=\"inlineStr\"><is><t>{(node?.IsRequired == true ? "Yes" : "No")}</t></is></c></row>");
                lastRow = Math.Max(lastRow, row);
            }

            return $"<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><dimension ref=\"A1:D{lastRow}\"/><sheetViews><sheetView workbookViewId=\"0\"/></sheetViews><cols><col min=\"1\" max=\"1\" width=\"70\" customWidth=\"1\"/><col min=\"2\" max=\"2\" width=\"24\" customWidth=\"1\"/><col min=\"3\" max=\"4\" width=\"12\" customWidth=\"1\"/></cols><sheetData>{cells}</sheetData></worksheet>";
        }

        private static XDocument ReadXml(ZipArchive archive, string path)
        {
            var entry = archive.GetEntry(path);
            if (entry == null)
            {
                return null;
            }

            using (var stream = entry.Open())
            {
            return SafeXml.Load(stream);
            }
        }

        private static void UpsertEntry(ZipArchive archive, string path, string content)
        {
            try
            {
                archive.GetEntry(path)?.Delete();
            }
            catch (NotSupportedException)
            {
                // Create-mode archives do not support lookup. Base workbook generation writes each part once.
            }

            // Same form as Excel writes its parts: UTF-8 without a byte-order mark, with an XML declaration.
            var text = content.TrimStart('\uFEFF', ' ', '\r', '\n', '\t');
            if (!text.StartsWith("<?xml", StringComparison.Ordinal))
            {
                text = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\r\n" + text;
            }

            var entry = archive.CreateEntry(path, CompressionLevel.Optimal);
            using (var writer = new StreamWriter(entry.Open(), new UTF8Encoding(encoderShouldEmitUTF8Identifier: false)))
            {
            writer.Write(text);
            }
        }

        private static string NextRelationshipId(XElement relationships)
        {
            var max = relationships.Elements(PackageRel + "Relationship")
                .Select(e => ((string)e.Attribute("Id"))?.TrimStart('r', 'I', 'd'))
                .Select(value => { int id; return int.TryParse(value, out id) ? id : 0; })
                .DefaultIfEmpty(0)
                .Max();
            return $"rId{max + 1}";
        }

        private static string ToNsXPath(string schemaPath, string prefix)
        {
            return "/" + string.Join("/", schemaPath.Split('/', StringSplitOptions.RemoveEmptyEntries).Select(part => $"{prefix}:{part}"));
        }

        private static string LastToken(string path)
        {
            return path.Split('/', StringSplitOptions.RemoveEmptyEntries).LastOrDefault() ?? "Value";
        }

        private static string NormalizeXmlDataType(string dataType)
        {
            return dataType == "integer" ? "integer" : dataType == "decimal" ? "decimal" : dataType == "date" ? "date" : dataType == "dateTime" ? "dateTime" : dataType == "boolean" ? "boolean" : "string";
        }

        private static string NormalizePartPath(string basePath, string target)
        {
            var combined = target.StartsWith("/", StringComparison.Ordinal) ? target.TrimStart('/') : $"{basePath.TrimEnd('/')}/{target}";
            var parts = new Stack<string>();
            foreach (var part in combined.Split('/', StringSplitOptions.RemoveEmptyEntries))
            {
                if (part == ".")
                {
                    continue;
                }

                if (part == "..")
                {
                    if (parts.Count > 0)
                    {
                        parts.Pop();
                    }
                    continue;
                }

                parts.Push(part);
            }

            return string.Join("/", parts.Reverse());
        }

        private static string Escape(string value)
        {
            return System.Security.SecurityElement.Escape(value) ?? "";
        }


        private static bool TryParseCellAddress(string address, out string columnName, out int rowNumber)
        {
            rowNumber = 0;
            columnName = string.Concat(address.TakeWhile(char.IsLetter)).ToUpperInvariant();
            var rowText = string.Concat(address.SkipWhile(char.IsLetter));
            return columnName.Length > 0 && int.TryParse(rowText, out rowNumber) && rowNumber > 0;
        }

        private static void SortCells(XElement row)
        {
            var cells = row.Elements(Main + "c")
                .OrderBy(c => CellColumnIndex((string)c.Attribute("r") ?? ""))
                .ToList();
            row.Elements(Main + "c").Remove();
            row.Add(cells);
        }

        private static int CellColumnIndex(string address)
        {
            var column = string.Concat(address.TakeWhile(char.IsLetter)).ToUpperInvariant();
            var index = 0;
            foreach (var ch in column)
            {
                index = (index * 26) + ch - 'A' + 1;
            }

            return index;
        }

            private static string Compact(string value)
    {
        return string.Concat(value.Where(char.IsLetterOrDigit));
    }

            private static XElement Solid(string rgb)
    {
        return new XElement(Main + "fill", new XElement(Main + "patternFill", new XAttribute("patternType", "solid"), new XElement(Main + "fgColor", new XAttribute("rgb", rgb)), new XElement(Main + "bgColor", new XAttribute("indexed", "64"))));
    }

            private static XElement Thin(string side)
    {
        return new XElement(Main + side, new XAttribute("style", "thin"), new XElement(Main + "color", new XAttribute("auto", "1")));
    }

            private static XElement Xf(int numFmt, int font, int fill, int border, XElement alignment, bool unlocked)
    {
        var xf = new XElement(Main + "xf", new XAttribute("numFmtId", numFmt), new XAttribute("fontId", font), new XAttribute("fillId", fill), new XAttribute("borderId", border), new XAttribute("xfId", 0), new XAttribute("applyFont", 1), new XAttribute("applyFill", 1), new XAttribute("applyBorder", border == 0 ? 0 : 1));
        if (numFmt != 0)
        {
            xf.SetAttributeValue("applyNumberFormat", 1);
        }

        if (alignment != null)
        {
            xf.SetAttributeValue("applyAlignment", 1);
            xf.Add(alignment);
        }

        if (unlocked)
        {
            xf.SetAttributeValue("applyProtection", 1);
            xf.Add(new XElement(Main + "protection", new XAttribute("locked", 0)));
        }

        return xf;
    }

            private static XElement Align(string horizontal, bool wrap = false)
    {
        return new XElement(Main + "alignment", new XAttribute("horizontal", horizontal), new XAttribute("vertical", "center"), wrap ? new XAttribute("wrapText", 1) : null);
    }
    }

}
