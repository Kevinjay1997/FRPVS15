﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    public sealed partial class OpenXmlMappedTemplateWriter
    {
        /// <summary>
        /// Splits each form of <paramref name="splits"/> into one copy of its sheet per key value, in the split's order
        /// ("CAR_Part_IV_4c (PHP)", "CAR_Part_IV_4c (USD)", ...): the form's sheet becomes the first copy, the others follow
        /// it. Every copy has the form's layout, styles and XSD data validations, and its key cell (e.g. Currency) holds its
        /// value. The project's (or sample) values stay on the copy whose value is the key's value (the first otherwise);
        /// the other copies start empty, or with the sample row the specification gives for their value.
        /// </summary>
        private static void SplitSheets(ZipArchive archive, FrpProjectDto project, IReadOnlyList<SheetSplitRules.ResolvedSplit> splits, bool writeValues)
        {
            if (splits.Count == 0)
            {
                return;
            }

            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var renames = new List<VT_OldName_NewName<string, string>>();

            foreach (var split in splits)
            {
                var sheets = ReadSheets(archive);
                var baseSheet = sheets.FirstOrDefault(s => string.Equals(s.Name, split.Form.SheetName, StringComparison.OrdinalIgnoreCase));
                var baseDocument = (baseSheet.WorksheetPath == null) ? null : ReadXml(archive, baseSheet.WorksheetPath);
                if ((baseDocument?.Root) == null)
                {
                    continue;
                }

                var workbook = ReadXml(archive, "xl/workbook.xml");
                var workbookRels = ReadXml(archive, "xl/_rels/workbook.xml.rels");
                var sheetsElement = workbook.Root.Element(Main + "sheets");
                var sheetElements = sheetsElement.Elements(Main + "sheet").ToList();
                var baseIndex = sheetElements.FindIndex(e => string.Equals((string)e.Attribute("name"), baseSheet.Name, StringComparison.OrdinalIgnoreCase));
                if (baseIndex < 0)
                {
                    continue;
                }

                var baseElement = sheetElements[baseIndex];
                var valuesSheet = writeValues ? SheetSplitRules.ValuesSheet(project, split) : -1;
                var groupFields = split.Form.Fields.Concat(split.Form.NestedLists.SelectMany(l => l.Fields)).ToList();
                var sampleRows = writeValues && FirstRowIsSample(project, project.Mappings, nodesByPath, split.Form.GroupPath)
                    ? project.SampleRows.Where(r => string.Equals(r.ItemPath, split.Form.GroupPath, StringComparison.Ordinal)).ToList()
                    : new List<SampleRowDto>();
                var copyRels = CopyableSheetRelationships(archive, baseSheet.WorksheetPath);
                var copies = split.Sheets.Count - 1;

                for (var i = 0; i < split.Sheets.Count; i++)
                {
                    var sheet2 = split.Sheets[i];
                    var value = sheet2.Value;
                    var sheetName = sheet2.SheetName;
                    var document = new XDocument(baseDocument);
                    var worksheet = document.Root;
                    var sheetData = worksheet.Element(Main + "sheetData") ?? new XElement(Main + "sheetData");
                    if (sheetData.Parent == null)
                    {
                        worksheet.Add(sheetData);
                    }

                    if (i != valuesSheet)
                    {
                        foreach (var field in groupFields)
                        {
                            SetCellValue(GetOrCreateCell(sheetData, ColumnName(SheetSplitRules.Column(field.CellAddress)), SheetSplitRules.Row(field.CellAddress)), null, field.DataType);
                        }

                        var sample = sampleRows.FirstOrDefault(r => { string key; return r.Values.TryGetValue(split.Key.SchemaPath, out key) && string.Equals(key, value, StringComparison.OrdinalIgnoreCase); });
                        foreach (var field in (sample == null) ? new List<MappingEntryDto>() : split.Form.Fields)
                        {
                            string sampleValue;
                            if (sample.Values.TryGetValue(field.SchemaPath, out sampleValue) && !string.IsNullOrEmpty(sampleValue))
                            {
                                SetCellValue(GetOrCreateCell(sheetData, ColumnName(SheetSplitRules.Column(field.CellAddress)), SheetSplitRules.Row(field.CellAddress)), sampleValue, field.DataType);
                            }
                        }
                    }

                    var keyCell = GetOrCreateCell(sheetData, ColumnName(SheetSplitRules.Column(split.Key.CellAddress)), SheetSplitRules.Row(split.Key.CellAddress));
                    SetCellValue(keyCell, value, split.Key.DataType);

                    // A reference to the form's own sheet by name now means this copy.
                    RenameSheetReferences(worksheet, baseSheet.Name, sheetName);

                    if (i == 0)
                    {
                        UpsertEntry(archive, baseSheet.WorksheetPath, document.ToString(SaveOptions.DisableFormatting));
                        continue;
                    }

                    foreach (var view in worksheet.Descendants(Main + "sheetView"))
                    {
                        view.Attribute("tabSelected")?.Remove();
                    }

                    var partPath = NextFreePart(archive, "xl/worksheets/frpCopy", ".xml");
                    WriteCopyRelationships(archive, worksheet, partPath, copyRels);
                    UpsertEntry(archive, partPath, document.ToString(SaveOptions.DisableFormatting));
                    EnsureContentType(archive, "/" + partPath, "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml");

                    var relationshipId = NextRelationshipId(workbookRels.Root);
                    workbookRels.Root.Add(new XElement(PackageRel + "Relationship",
                        new XAttribute("Id", relationshipId),
                        new XAttribute("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"),
                        new XAttribute("Target", "worksheets/" + Path.GetFileName(partPath))));
                    var nextSheetId = sheetsElement.Elements(Main + "sheet").Select(e => (int?)e.Attribute("sheetId") ?? 0).DefaultIfEmpty(0).Max() + 1;
                    var element = new XElement(Main + "sheet",
                        new XAttribute("name", sheetName),
                        new XAttribute("sheetId", nextSheetId));
                    XAttribute state;
                    if (CompatPattern.Is(baseElement.Attribute("state"), out state))
                    {
                        element.SetAttributeValue("state", state.Value);
                    }

                    element.Add(new XAttribute(Rel + "id", relationshipId));
                    sheetsElement.Elements(Main + "sheet").ElementAt(baseIndex + i - 1).AddAfterSelf(element);
                }

                // The copies sit right after the form's sheet: sheet-scoped names and tab positions after it move along,
                // and the form's own sheet-scoped names (print area, titles) are given to every copy.
                var definedNames = workbook.Root.Element(Main + "definedNames");
                foreach (var definedName in definedNames?.Elements(Main + "definedName").ToList() ?? new List<XElement>())
                {
                    int localSheetId;
                    if (!int.TryParse((string)definedName.Attribute("localSheetId"), out localSheetId))
                    {
                        continue;
                    }

                    if (localSheetId > baseIndex)
                    {
                        definedName.SetAttributeValue("localSheetId", localSheetId + copies);
                    }
                    else if (localSheetId == baseIndex)
                    {
                        for (var i = split.Sheets.Count - 1; i >= 1; i--)
                        {
                            var copy = new XElement(definedName);
                            copy.SetAttributeValue("localSheetId", baseIndex + i);
                            copy.Value = RenameInFormula(copy.Value, baseSheet.Name, split.Sheets[i].SheetName);
                            definedName.AddAfterSelf(copy);
                        }
                    }
                }

                foreach (var view in workbook.Root.Descendants(Main + "workbookView"))
                {
                    foreach (var attributeName in new[] { "activeTab", "firstSheet" })
                    {
                        int tab;
                        if (int.TryParse((string)view.Attribute(attributeName), out tab) && tab > baseIndex)
                        {
                            view.SetAttributeValue(attributeName, tab + copies);
                        }
                    }
                }

                baseElement.SetAttributeValue("name", split.Sheets[0].SheetName);
                UpsertEntry(archive, "xl/_rels/workbook.xml.rels", workbookRels.ToString(SaveOptions.DisableFormatting));
                UpsertEntry(archive, "xl/workbook.xml", workbook.ToString(SaveOptions.DisableFormatting));
                renames.Add(new VT_OldName_NewName<string, string>(baseSheet.Name, split.Sheets[0].SheetName));
            }

            // Other sheets, names and charts that refer to a split form's sheet by name now refer to its first copy.
            if (renames.Count > 0)
            {
                RenameReferencesEverywhere(archive, renames);
                RequestFullCalculationOnLoad(archive);
            }
        }

        // ---------- Excel XML map bindings of the forms the app reads ----------

        /// <summary>
        /// Binds the forms the app reads itself (split into sheet copies, or holding lists inside their item) in Excel's XML
        /// map: the map's schema lets the item occur once, its own fields are bound to single cells and each list inside it
        /// to an XML list table. The form's sheet (for a split form, its first copy) is bound under the XSD's own names, so
        /// a workbook that uses only that sheet exports an XML that passes the XSD as it is. Every other sheet copy is bound
        /// too, to its own clone element "{Form}_{value}" (Excel binds an element once per workbook): Excel's XML then holds
        /// CAR_Part_IV_4c plus CAR_Part_IV_4c_USD…, which the app merges into the XSD's structure
        /// (<see cref="SheetCopyMap.Normalize"/>). Forms the sample template leaves unbound (<paramref name="leftOut"/>)
        /// stay unbound.
        /// </summary>
        private static void BindFormsForExcel(ZipArchive archive, FrpProjectDto project, XmlMapInfo map, IReadOnlyList<string> leftOut)
        {
            var splits = SheetSplitRules.Resolve(project).ToDictionary(s => s.Form.GroupPath, StringComparer.Ordinal);
            var forms = SheetSplitRules.ExcelItemForms(project)
                .Where(f => !leftOut.Any(prefix => (f.GroupPath + "/").StartsWith(prefix, StringComparison.Ordinal)))
                .ToList();
            var maps = forms.Count == 0 ? null : ReadXml(archive, "xl/xmlMaps.xml");
            var mapElement = maps?.Root?.Elements(Main + "Map").FirstOrDefault(m => (string)m.Attribute("ID") == map.MapId);
            var schemaId = (string)mapElement?.Attribute("SchemaID");
            var schema = maps?.Root?.Elements(Main + "Schema")
                .FirstOrDefault(s => (string)s.Attribute("ID") == schemaId)?
                .Elements().FirstOrDefault(e => e.Name.LocalName == "schema");
            if (schema == null || string.IsNullOrEmpty(project.RootElement))
            {
                return;
            }

            var bound = forms.Where(f =>
            {
                var tokens = f.GroupPath.Split('/', StringSplitOptions.RemoveEmptyEntries);
                return SheetCopyMap.SetSingleItem(schema, project.RootElement, tokens[1], tokens[2]);
            }).ToList();
            if (bound.Count == 0)
            {
                return;
            }

            // The other sheet copies of the bound split forms: one clone form element each, after the form.
            var boundGroups = bound.Select(f => f.GroupPath).ToHashSet(StringComparer.Ordinal);
            var otherCopies = SheetCopyMap.Copies(project)
                .Where(c => boundGroups.Contains(c.Split.Form.GroupPath)
                    && !string.Equals(c.SheetName, c.Split.Sheets[0].SheetName, StringComparison.OrdinalIgnoreCase))
                .ToList();
            var clones = otherCopies.Count == 0 ? new List<SheetCopyMap.Copy>() : SheetCopyMap.AddClones(schema, project.RootElement, otherCopies);

            UpsertEntry(archive, "xl/xmlMaps.xml", maps.ToString(SaveOptions.DisableFormatting));
            var nextCellId = NextSingleCellId(archive);
            var sheets = ReadSheets(archive);
            foreach (var form in bound)
            {
                SheetSplitRules.ResolvedSplit split;
                var sheetName = splits.TryGetValue(form.GroupPath, out split) ? split.Sheets[0].SheetName : form.SheetName;
                var sheet = sheets.FirstOrDefault(s => string.Equals(s.Name, sheetName, StringComparison.OrdinalIgnoreCase));
                if (sheet.WorksheetPath == null)
                {
                    continue;
                }

                var view = SheetCopyMap.ForExcelItem(project, form, sheet.Name);
                var lists = form.NestedLists.Select(l => l.ItemPath + "/").ToList();
                var singles = view.Mappings.Where(m => !lists.Any(prefix => m.SchemaPath.StartsWith(prefix, StringComparison.Ordinal))).ToList();
                if (singles.Count > 0)
                {
                    WriteSingleCells(archive, sheet.WorksheetPath, singles, map, ref nextCellId);
                }

                // Each list: an XML table with its first input row; Excel grows it when a row is typed below it. (A table over
                // all input rows would make Excel export every blank row as an empty item.)
                var listFields = view.Mappings.Except(singles).ToList();
                if (listFields.Count > 0)
                {
                    WriteListTables(archive, view, listFields, map, writeValues: false, appReadGroups: new HashSet<string>());
                }

                foreach (var copy in clones.Where(c => c.Split.Form.GroupPath == form.GroupPath))
                {
                    var copySheet = sheets.FirstOrDefault(s => string.Equals(s.Name, copy.SheetName, StringComparison.OrdinalIgnoreCase));
                    if (copySheet.WorksheetPath == null)
                    {
                        continue;
                    }

                    var copyView = SheetCopyMap.ForCopy(project, copy);
                    copyView = copyView.With(inner => { inner.Mappings = copyView.Mappings.Select(m => m.With(innermost => { innermost.SheetName = copySheet.Name; })).ToList(); });
                    var copyLists = form.NestedLists.Select(l => copy.ToClone(l.ItemPath) + "/").ToList();
                    var copySingles = copyView.Mappings.Where(m => !copyLists.Any(prefix => m.SchemaPath.StartsWith(prefix, StringComparison.Ordinal))).ToList();
                    if (copySingles.Count > 0)
                    {
                        WriteSingleCells(archive, copySheet.WorksheetPath, copySingles, map, ref nextCellId);
                    }

                    var copyListFields = copyView.Mappings.Except(copySingles).ToList();
                    if (copyListFields.Count > 0)
                    {
                        WriteListTables(archive, copyView, copyListFields, map, writeValues: false, appReadGroups: new HashSet<string>());
                    }
                }
            }
        }

        /// <summary>The next free id for single-cell XML bindings (ids are unique in the workbook).</summary>
        private static int NextSingleCellId(ZipArchive archive)
        {
            var max = 100000;
            foreach (var entry in archive.Entries.Where(e => e.FullName.StartsWith("xl/tables/", StringComparison.OrdinalIgnoreCase)).ToList())
            {
                var root = ReadXml(archive, entry.FullName)?.Root;
                if (root?.Name != Main + "singleXmlCells")
                {
                    continue;
                }

                foreach (var cell in root.Elements(Main + "singleXmlCell"))
                {
                    int id;
                    if (int.TryParse((string)cell.Attribute("id"), out id))
                    {
                        max = Math.Max(max, id);
                    }
                }
            }

            return max + 1;
        }

        // ---------- the copies' own parts ----------

        private sealed class CopyableRelationship : IRecord<CopyableRelationship>, IEquatable<CopyableRelationship>
    {
        public string Id { get; set; }

        public string Type { get; set; }

        public string Target { get; set; }

        public bool External { get; set; }

        public string PartPath { get; set; }

        public CopyableRelationship(string Id, string Type, string Target, bool External, string PartPath)
    {
    this.Id = Id;
    this.Type = Type;
    this.Target = Target;
    this.External = External;
    this.PartPath = PartPath;
    }

        public void Deconstruct(out string Id, out string Type, out string Target, out bool External, out string PartPath)
    {
    Id = this.Id;
    Type = this.Type;
    Target = this.Target;
    External = this.External;
    PartPath = this.PartPath;
    }

        public bool Equals(CopyableRelationship other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Id, other.Id)
    && EqualityComparer<string>.Default.Equals(Type, other.Type)
    && EqualityComparer<string>.Default.Equals(Target, other.Target)
    && EqualityComparer<bool>.Default.Equals(External, other.External)
    && EqualityComparer<string>.Default.Equals(PartPath, other.PartPath);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as CopyableRelationship);
    }

        public static bool operator ==(CopyableRelationship left, CopyableRelationship right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(CopyableRelationship left, CopyableRelationship right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 62280;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Id);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Type);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Target);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(External);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(PartPath);
    return hash;
    }
    }

        public override string ToString()
    {
    return "CopyableRelationship { " + "Id = " + Id + ", " + "Type = " + Type + ", " + "Target = " + Target + ", " + "External = " + External + ", " + "PartPath = " + PartPath + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public CopyableRelationship CloneRecord()
    {
    return (CopyableRelationship)MemberwiseClone();
    }

    }

        /// <summary>
        /// The form sheet's relationships a copy can keep: external hyperlinks (shared) and printer settings (copied).
        /// Drawings, comments, tables and XML-map cells belong to one sheet only; the copies go without them.
        /// </summary>
        private static List<CopyableRelationship> CopyableSheetRelationships(ZipArchive archive, string worksheetPath)
        {
            var directory = Path.GetDirectoryName(worksheetPath)?.Replace('\\', '/') ?? "xl/worksheets";
            var rels = ReadXml(archive, $"{directory}/_rels/{Path.GetFileName(worksheetPath)}.rels");
            var result = new List<CopyableRelationship>();
            foreach (var relationship in rels?.Root?.Elements(PackageRel + "Relationship") ?? new List<XElement>())
            {
                var id = (string)relationship.Attribute("Id");
                var type = (string)relationship.Attribute("Type") ?? "";
                var target = (string)relationship.Attribute("Target");
                if (id == null || target == null)
                {
                    continue;
                }

                var external = string.Equals((string)relationship.Attribute("TargetMode"), "External", StringComparison.OrdinalIgnoreCase);
                if (external && type.EndsWith("/hyperlink", StringComparison.OrdinalIgnoreCase))
                {
                    result.Add(new CopyableRelationship(id, type, target, true, null));
                }
                else if (!external && type.EndsWith("/printerSettings", StringComparison.OrdinalIgnoreCase))
                {
                    result.Add(new CopyableRelationship(id, type, target, false, NormalizePartPath(directory, target)));
                }
            }

            return result;
        }

        private static void WriteCopyRelationships(ZipArchive archive, XElement worksheet, string partPath, IReadOnlyList<CopyableRelationship> copyable)
        {
            var kept = new HashSet<string>(StringComparer.Ordinal);
            var relationships = new XElement(PackageRel + "Relationships");
            foreach (var relationship in copyable)
            {
                var target = relationship.Target;
                if (!relationship.External)
                {
                    var source = archive.GetEntry(relationship.PartPath);
                    if (source == null)
                    {
                        continue;
                    }

                    var extension = Path.GetExtension(relationship.PartPath);
                    var copyPath = NextFreePart(archive, "xl/printerSettings/frpCopy", extension);
                    using (var input = source.Open())
                    using (var output = archive.CreateEntry(copyPath, CompressionLevel.Optimal).Open())
                    {
                        input.CopyTo(output);
                    }

                    target = "../printerSettings/" + Path.GetFileName(copyPath);
                }

                var element = new XElement(PackageRel + "Relationship",
                    new XAttribute("Id", relationship.Id),
                    new XAttribute("Type", relationship.Type),
                    new XAttribute("Target", target));
                if (relationship.External)
                {
                    element.SetAttributeValue("TargetMode", "External");
                }

                relationships.Add(element);
                kept.Add(relationship.Id);
            }

            // Anything else that points at one of the form sheet's parts is left out of the copy.
            foreach (var attribute in worksheet.Descendants().Attributes(Rel + "id").Where(a => !kept.Contains(a.Value)).ToList())
            {
                var owner = attribute.Parent;
                if (owner.Name == Main + "pageSetup")
                {
                    attribute.Remove();
                }
                else
                {
                    owner.Remove();
                }
            }

            // Containers that must not be empty lose their last child with it.
            var containers = new[] { Main + "tableParts", Main + "hyperlinks", Main + "oleObjects", Main + "controls" };
            foreach (var list in worksheet.Elements().Where(e => containers.Contains(e.Name)).ToList())
            {
                if (!list.HasElements)
                {
                    list.Remove();
                }
                else if (list.Attribute("count") != null)
                {
                    list.SetAttributeValue("count", list.Elements().Count());
                }
            }

            if (relationships.HasElements)
            {
                var directory = Path.GetDirectoryName(partPath).Replace('\\', '/');
                UpsertEntry(archive, $"{directory}/_rels/{Path.GetFileName(partPath)}.rels", new XDocument(relationships).ToString(SaveOptions.DisableFormatting));
            }
        }

        // ---------- sheet references in formulas ----------

        private static readonly HashSet<string> FormulaElements = new HashSet<string> { "f", "formula", "formula1", "formula2" };

        private static void RenameSheetReferences(XElement root, string oldName, string newName)
        {
            foreach (var element in root.Descendants().Where(e => FormulaElements.Contains(e.Name.LocalName) && !e.HasElements))
            {
                var renamed = RenameInFormula(element.Value, oldName, newName);
                if (renamed != element.Value)
                {
                    element.Value = renamed;
                }
            }
        }

        /// <summary>Worksheets, defined names and charts: references to each renamed sheet follow the new name.</summary>
        private static void RenameReferencesEverywhere(ZipArchive archive, IReadOnlyList<VT_OldName_NewName<string, string>> renames)
        {
            var parts = archive.Entries
                .Select(e => e.FullName)
                .Where(name => name == "xl/workbook.xml"
                    || name.StartsWith("xl/worksheets/", StringComparison.OrdinalIgnoreCase) && name.EndsWith(".xml", StringComparison.OrdinalIgnoreCase) && !name.Contains("/_rels/")
                    || name.StartsWith("xl/charts/", StringComparison.OrdinalIgnoreCase) && name.EndsWith(".xml", StringComparison.OrdinalIgnoreCase) && !name.Contains("/_rels/"))
                .ToList();
            foreach (var part in parts)
            {
                var document = ReadXml(archive, part);
                if ((document?.Root) == null)
                {
                    continue;
                }

                var changed = false;
                var elements = part == "xl/workbook.xml"
                    ? document.Root.Descendants(Main + "definedName")
                    : document.Root.Descendants().Where(e => FormulaElements.Contains(e.Name.LocalName) && !e.HasElements);
                foreach (var element in elements)
                {
                    var value = element.Value;
                    foreach (var rename in renames)
                    {
                        var oldName = rename.OldName;
                        var newName = rename.NewName;
                        value = RenameInFormula(value, oldName, newName);
                    }

                    if (value != element.Value)
                    {
                        element.Value = value;
                        changed = true;
                    }
                }

                if (changed)
                {
                    UpsertEntry(archive, part, document.ToString(SaveOptions.DisableFormatting));
                }
            }
        }

        /// <summary>
        /// 'Old'!A1 and Old!A1 become 'New'!A1 (a name with spaces or brackets is always quoted). Text in string
        /// literals ("...") is left alone.
        /// </summary>
        internal static string RenameInFormula(string formula, string oldName, string newName)
        {
            if (string.IsNullOrEmpty(formula) || formula.IndexOf(oldName, StringComparison.OrdinalIgnoreCase) < 0)
            {
                return formula;
            }

            var quotedNew = $"'{newName.Replace("'", "''")}'!";
            var quotedOld = Regex.Escape($"'{oldName.Replace("'", "''")}'!");
            var bareOld = Regex.Escape(oldName + "!");
            var pattern = new Regex($@"(""[^""]*"")|(?<![A-Za-z0-9_.'\]]){quotedOld}|(?<![A-Za-z0-9_.'\]]){bareOld}", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
            return pattern.Replace(formula, m => m.Groups[1].Success ? m.Value : quotedNew);
        }
    }

}
