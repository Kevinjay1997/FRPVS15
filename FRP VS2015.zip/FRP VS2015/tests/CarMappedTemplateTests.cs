// Regression for BSP CAR_M v1.0: preserve the supplied workbook (lists use the form's own rows) while mapping all three CAR Part IV 5 forms.
// Arguments: <CAR_M XSD> <CAR_M input XLSX> <CAR_M specification XLSX>.
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;
using FrpMapper.Api.BL;
using FrpMapper.Shared.Models;

static class CarMappedTemplateTests
{
    static readonly XNamespace Sml = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    static int checks;
    static void Check(bool condition, string name) { if (!condition) throw new Exception("FAILED: " + name); checks++; }
    static XDocument Read(ZipArchive archive, string path)
    {
        using (var stream = archive.GetEntry(path).Open()) return XDocument.Load(stream);
    }
    static IReadOnlyList<string> Merges(ZipArchive archive, string path)
    {
        return Read(archive, path).Descendants(Sml + "mergeCell").Select(e => (string)e.Attribute("ref")).ToList();
    }
    static List<string> TableRefs(ZipArchive archive, string sheetPath)
    {
        var rels = archive.GetEntry("xl/worksheets/_rels/" + Path.GetFileName(sheetPath) + ".rels");
        if (rels == null) return new List<string>();
        XDocument relsDoc;
        using (var stream = rels.Open()) relsDoc = XDocument.Load(stream);
        return relsDoc.Root.Elements().Where(r => ((string)r.Attribute("Type")).EndsWith("/table"))
            .Select(r => (string)Read(archive, "xl/tables/" + Path.GetFileName((string)r.Attribute("Target"))).Root.Attribute("ref")).ToList();
    }
    static int[] Area(string range)
    {
        Func<string, int[]> cell = a => {
            var letters = new string(a.TakeWhile(char.IsLetter).ToArray());
            return new[] { int.Parse(a.Substring(letters.Length)), letters.Aggregate(0, (n, ch) => n * 26 + char.ToUpperInvariant(ch) - 'A' + 1) };
        };
        var parts = range.Split(':');
        var first = cell(parts[0]); var last = cell(parts[parts.Length - 1]);
        return new[] { first[0], last[0], first[1], last[1] };
    }
    static bool Inside(int[] inner, int[] outer)
    {
        return inner[0] >= outer[0] && inner[1] <= outer[1] && inner[2] >= outer[2] && inner[3] <= outer[3];
    }
    static int Main(string[] args)
    {
        var parsed = new XsdSchemaParser().Parse(args[0]);
        var inspector = new OpenXmlWorkbookInspector();
        var workbook = inspector.Inspect(args[1]);
        var plan = new MappingSuggestionEngine().CreateInitialMappings(parsed.Nodes, workbook);
        var specification = new BspSpecificationReader(inspector).Read(args[2]);
        var solved = new BspSampleValueSolver(new BspAssertionEvaluator(), new XmlSubmissionWriter(), new BspDerivedValues())
            .Apply(parsed.Nodes, parsed.RootElement, parsed.TargetNamespace, specification);
        var forms = new[] { "CAR_Part_IV_5a", "CAR_Part_IV_5b", "CAR_Part_IV_5c" };
        Check(forms.All(solved.OmittedForms.Contains), "sample excludes these forms by BSP rule");
        var project = new FrpProjectDto {
            RootElement = parsed.RootElement, TargetNamespace = parsed.TargetNamespace, SchemaNodes = parsed.Nodes,
            Workbook = workbook, Mappings = plan.Mappings,
            XsdFile = new UploadedFileDto { StoredPath = args[0] }, TemplateFile = new UploadedFileDto { StoredPath = args[1] }
        };
        var output = new OpenXmlMappedTemplateWriter().Write(project, writeValues: false);
        var coverage = new TemplateCoverageChecker().Check(project, output, "CAR_M.xlsx");
        Check(coverage.IsComplete && coverage.Unbound == 0, "all fields bound in full export");
        var sampleOutput = new OpenXmlMappedTemplateWriter().Write(project, writeValues: true, unboundForms: solved.OmittedForms);
        if (args.Length > 3) File.WriteAllBytes(args[3], output);
        if (args.Length > 4) File.WriteAllBytes(args[4], sampleOutput);
        using (var sample = new ZipArchive(new MemoryStream(sampleOutput), ZipArchiveMode.Read))
        {
            var samplePaths = sample.Entries.Where(e => e.FullName.StartsWith("xl/tables/") && e.FullName.EndsWith(".xml"))
                .Select(e => Read(sample, e.FullName))
                .SelectMany(document => document.Descendants(Sml + "xmlPr")
                    .Concat(document.Descendants(Sml + "xmlColumnPr")))
                .Select(e => (string)e.Attribute("xpath")).ToList();
            Check(forms.All(form => samplePaths.All(path => !path.Contains("/ns1:" + form + "/"))),
                "sample export alone omits the three specification-excluded forms");
        }
        using (var source = ZipFile.OpenRead(args[1]))
        using (var result = new ZipArchive(new MemoryStream(output), ZipArchiveMode.Read))
        {
            foreach (var path in new[] { "xl/worksheets/sheet35.xml", "xl/worksheets/sheet36.xml", "xl/worksheets/sheet37.xml" })
                Check(Merges(source, path).Where(m => m.Contains(":")).SequenceEqual(Merges(result, path).Where(m => m.Contains(":"))),
                    path + " multi-cell merge layout preserved");
            foreach (var entry in source.Entries.Where(e => e.FullName.StartsWith("xl/worksheets/sheet") && e.FullName.EndsWith(".xml")))
            {
                var original = Read(source, entry.FullName);
                var exported = Read(result, entry.FullName);
                var exportedCells = exported.Descendants(Sml + "c")
                    .Where(c => c.Attribute("r") != null)
                    .ToDictionary(c => (string)c.Attribute("r"), StringComparer.OrdinalIgnoreCase);
                Check(original.Descendants(Sml + "c").All(cell => {
                    XElement actual;
                    return exportedCells.TryGetValue((string)cell.Attribute("r"), out actual)
                        && XNode.DeepEquals(cell, actual);
                }), entry.FullName + " original cells preserved");
                // Only 1x1 merge entries (which merge nothing) may be dropped, and only inside an in-place XML table.
                var tableAreas = TableRefs(result, entry.FullName).Select(Area).ToList();
                var kept = Merges(result, entry.FullName);
                var dropped = Merges(source, entry.FullName).Where(m => !kept.Contains(m)).ToList();
                Check(Merges(source, entry.FullName).Where(m => !dropped.Contains(m)).SequenceEqual(kept), entry.FullName + " merges kept in order");
                Check(dropped.All(m => !m.Contains(":") && tableAreas.Any(a => Inside(Area(m), a))),
                    entry.FullName + " only 1x1 merges inside a list table removed");
            }
            // A list whose rows already exist on the form becomes a table on those rows, not a new table below the form.
            var partTwo = TableRefs(result, "xl/worksheets/sheet3.xml");
            Check(partTwo.Contains("F116:I117") && partTwo.Contains("F152:I153") && partTwo.Count == 2,
                "CAR_Part_II lists use the form's own rows (" + string.Join(", ", partTwo) + ")");
            var formRows = Read(source, "xl/worksheets/sheet3.xml").Descendants(Sml + "row").Max(r => (int)r.Attribute("r"));
            Check(Read(result, "xl/worksheets/sheet3.xml").Descendants(Sml + "row").Max(r => (int)r.Attribute("r")) == formRows,
                "CAR_Part_II has no helper table below the form");
            var bindings = result.Entries.Where(e => e.FullName.StartsWith("xl/tables/") && e.FullName.EndsWith(".xml"))
                .Select(e => Read(result, e.FullName)).ToList();
            var paths = bindings.SelectMany(d => d.Descendants(Sml + "xmlPr").Concat(d.Descendants(Sml + "xmlColumnPr")))
                .Select(e => (string)e.Attribute("xpath")).ToList();
            foreach (var form in forms)
            {
                var expected = plan.Mappings.Count(m => m.SchemaPath.StartsWith("/CAR_M/" + form + "/", StringComparison.Ordinal));
                Check(expected > 0 && paths.Count(p => p.Contains("/ns1:" + form + "/")) == expected, form + " bindings retained");
            }
            var sheet = Read(result, "xl/worksheets/sheet36.xml");
            Check(TableRefs(result, "xl/worksheets/sheet36.xml").SequenceEqual(new[] { "E6:G7" }) && !sheet.Descendants(Sml + "f").Any(),
                "5b list is a table on the form's own input row (E7, G7), with no helper formulas");
            // Lists entered one item per sheet (spread over rows) still get a linked helper table below the form.
            var partFour1d = TableRefs(result, "xl/worksheets/sheet25.xml");
            Check(partFour1d.Count == 1 && Read(result, "xl/worksheets/sheet25.xml").Descendants(Sml + "f").Any(),
                "CAR_Part_IV_1d (multi-row item) keeps its linked helper table");
        }
        Console.WriteLine("CarMappedTemplateTests: " + checks + " checks passed");
        return 0;
    }
}
