﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Shared.Models
{
    public sealed class FrpProjectDto : IRecord<FrpProjectDto>, IEquatable<FrpProjectDto>
    {
        // Transient: exclusions apply only to an explicitly requested sample export.
        [FrpMapper.Shared.Json.JsonIgnore]
        public IReadOnlyList<string> SampleExcludedSelectors { get; set; } = new List<string>();

        public string Id { get; set; } = "";

        public string Name { get; set; } = "";

        public DateTimeOffset CreatedAt { get; set; }

        public DateTimeOffset UpdatedAt { get; set; }

        public UploadedFileDto XsdFile { get; set; }

        public UploadedFileDto TemplateFile { get; set; }

        public UploadedFileDto SpecificationFile { get; set; }

        /// <summary>True when no BSP template was uploaded and the app generated the input template from the XSD.</summary>
        public bool TemplateGenerated { get; set; }

        public string TargetNamespace { get; set; }

        public string RootElement { get; set; }

        public IReadOnlyList<SchemaNodeDto> SchemaNodes { get; set; } = new List<SchemaNodeDto>();

        public WorkbookSummaryDto Workbook { get; set; }

        public WorkbookSummaryDto SpecificationWorkbook { get; set; }

        public IReadOnlyList<MappingEntryDto> Mappings { get; set; } = new List<MappingEntryDto>();

        /// <summary>
        /// Extra sample rows for repeating items the BSP specification requires more than once
        /// (e.g. one FRP_11A234 row with Bookcode 1 and one with Bookcode 2). The first row uses the schema nodes' test values.
        /// </summary>
        public IReadOnlyList<SampleRowDto> SampleRows { get; set; } = new List<SampleRowDto>();

        /// <summary>Forms without sample values because the specification says they are not submitted with the sample's Header values.</summary>
        public IReadOnlyList<string> SampleOmittedForms { get; set; } = new List<string>();

        /// <summary>
        /// Forms whose repeating item is entered on one copy of the form's sheet per key value (e.g. one
        /// CAR_Part_IV_4c sheet per Currency). Set by a Maker on the project's "Sheet copies" tab.
        /// </summary>
        public IReadOnlyList<SheetSplitDto> SheetSplits { get; set; } = new List<SheetSplitDto>();

        public IReadOnlyList<ValidationIssueDto> Issues { get; set; } = new List<ValidationIssueDto>();

        /// <summary>Summary of the last XSD validation run (issue details are in <see cref="Issues"/>).</summary>
        public ProjectValidationResultDto Validation { get; set; }

        /// <summary>Maker / Checker workflow: status, who prepared, submitted and reviewed, and the file under review.</summary>
        public ProjectWorkflowDto Workflow { get; set; } = new ProjectWorkflowDto();

        /// <summary>
        /// The database row version this copy was read at. A save fails if someone else saved the project in between,
        /// so a change is never based on stale data. Server-side only; not sent to clients.
        /// </summary>
        [FrpMapper.Shared.Json.JsonIgnore]
        public byte[] Version { get; set; }

        public bool Equals(FrpProjectDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<string>>.Default.Equals(SampleExcludedSelectors, other.SampleExcludedSelectors)
    && EqualityComparer<string>.Default.Equals(Id, other.Id)
    && EqualityComparer<string>.Default.Equals(Name, other.Name)
    && EqualityComparer<DateTimeOffset>.Default.Equals(CreatedAt, other.CreatedAt)
    && EqualityComparer<DateTimeOffset>.Default.Equals(UpdatedAt, other.UpdatedAt)
    && EqualityComparer<UploadedFileDto>.Default.Equals(XsdFile, other.XsdFile)
    && EqualityComparer<UploadedFileDto>.Default.Equals(TemplateFile, other.TemplateFile)
    && EqualityComparer<UploadedFileDto>.Default.Equals(SpecificationFile, other.SpecificationFile)
    && EqualityComparer<bool>.Default.Equals(TemplateGenerated, other.TemplateGenerated)
    && EqualityComparer<string>.Default.Equals(TargetNamespace, other.TargetNamespace)
    && EqualityComparer<string>.Default.Equals(RootElement, other.RootElement)
    && EqualityComparer<IReadOnlyList<SchemaNodeDto>>.Default.Equals(SchemaNodes, other.SchemaNodes)
    && EqualityComparer<WorkbookSummaryDto>.Default.Equals(Workbook, other.Workbook)
    && EqualityComparer<WorkbookSummaryDto>.Default.Equals(SpecificationWorkbook, other.SpecificationWorkbook)
    && EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.Equals(Mappings, other.Mappings)
    && EqualityComparer<IReadOnlyList<SampleRowDto>>.Default.Equals(SampleRows, other.SampleRows)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(SampleOmittedForms, other.SampleOmittedForms)
    && EqualityComparer<IReadOnlyList<SheetSplitDto>>.Default.Equals(SheetSplits, other.SheetSplits)
    && EqualityComparer<IReadOnlyList<ValidationIssueDto>>.Default.Equals(Issues, other.Issues)
    && EqualityComparer<ProjectValidationResultDto>.Default.Equals(Validation, other.Validation)
    && EqualityComparer<ProjectWorkflowDto>.Default.Equals(Workflow, other.Workflow)
    && EqualityComparer<byte[]>.Default.Equals(Version, other.Version);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as FrpProjectDto);
    }

        public static bool operator ==(FrpProjectDto left, FrpProjectDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(FrpProjectDto left, FrpProjectDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 95463;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(SampleExcludedSelectors);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Id);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(CreatedAt);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(UpdatedAt);
    hash = hash * -1521134295 + EqualityComparer<UploadedFileDto>.Default.GetHashCode(XsdFile);
    hash = hash * -1521134295 + EqualityComparer<UploadedFileDto>.Default.GetHashCode(TemplateFile);
    hash = hash * -1521134295 + EqualityComparer<UploadedFileDto>.Default.GetHashCode(SpecificationFile);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(TemplateGenerated);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(TargetNamespace);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(RootElement);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SchemaNodeDto>>.Default.GetHashCode(SchemaNodes);
    hash = hash * -1521134295 + EqualityComparer<WorkbookSummaryDto>.Default.GetHashCode(Workbook);
    hash = hash * -1521134295 + EqualityComparer<WorkbookSummaryDto>.Default.GetHashCode(SpecificationWorkbook);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.GetHashCode(Mappings);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SampleRowDto>>.Default.GetHashCode(SampleRows);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(SampleOmittedForms);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SheetSplitDto>>.Default.GetHashCode(SheetSplits);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<ValidationIssueDto>>.Default.GetHashCode(Issues);
    hash = hash * -1521134295 + EqualityComparer<ProjectValidationResultDto>.Default.GetHashCode(Validation);
    hash = hash * -1521134295 + EqualityComparer<ProjectWorkflowDto>.Default.GetHashCode(Workflow);
    hash = hash * -1521134295 + EqualityComparer<byte[]>.Default.GetHashCode(Version);
    return hash;
    }
    }

        public override string ToString()
    {
    return "FrpProjectDto { " + "SampleExcludedSelectors = " + SampleExcludedSelectors + ", " + "Id = " + Id + ", " + "Name = " + Name + ", " + "CreatedAt = " + CreatedAt + ", " + "UpdatedAt = " + UpdatedAt + ", " + "XsdFile = " + XsdFile + ", " + "TemplateFile = " + TemplateFile + ", " + "SpecificationFile = " + SpecificationFile + ", " + "TemplateGenerated = " + TemplateGenerated + ", " + "TargetNamespace = " + TargetNamespace + ", " + "RootElement = " + RootElement + ", " + "SchemaNodes = " + SchemaNodes + ", " + "Workbook = " + Workbook + ", " + "SpecificationWorkbook = " + SpecificationWorkbook + ", " + "Mappings = " + Mappings + ", " + "SampleRows = " + SampleRows + ", " + "SampleOmittedForms = " + SampleOmittedForms + ", " + "SheetSplits = " + SheetSplits + ", " + "Issues = " + Issues + ", " + "Validation = " + Validation + ", " + "Workflow = " + Workflow + ", " + "Version = " + Version + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public FrpProjectDto CloneRecord()
    {
    return (FrpProjectDto)MemberwiseClone();
    }

    }

    public sealed class SampleRowDto : IRecord<SampleRowDto>, IEquatable<SampleRowDto>
    {
        /// <summary>Schema path of the repeating item, e.g. /FRP/FRP_11A234/FRP_11A234_Item.</summary>
        public string ItemPath { get; set; } = "";

        /// <summary>Values of the row's fields by schema path.</summary>
        public IReadOnlyDictionary<string, string> Values { get; set; } = new Dictionary<string, string>();

        public bool Equals(SampleRowDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(ItemPath, other.ItemPath)
    && EqualityComparer<IReadOnlyDictionary<string, string>>.Default.Equals(Values, other.Values);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SampleRowDto);
    }

        public static bool operator ==(SampleRowDto left, SampleRowDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SampleRowDto left, SampleRowDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 86112;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ItemPath);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyDictionary<string, string>>.Default.GetHashCode(Values);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SampleRowDto { " + "ItemPath = " + ItemPath + ", " + "Values = " + Values + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SampleRowDto CloneRecord()
    {
    return (SampleRowDto)MemberwiseClone();
    }

    }

    /// <summary>
    /// One copy of a form's sheet per key value: the repeating item <see cref="GroupPath"/> is entered once per value
    /// of its field <see cref="KeyPath"/>, each on its own sheet named "Form (value)".
    /// </summary>
    public sealed class SheetSplitDto : IRecord<SheetSplitDto>, IEquatable<SheetSplitDto>
    {
        /// <summary>Schema path of the repeating item, e.g. /CAR_M/CAR_Part_IV_4c/CAR_Part_IV_4c_Item.</summary>
        public string GroupPath { get; set; } = "";

        /// <summary>Schema path of the item's field that tells the copies apart, e.g. .../CAR_Part_IV_4c_Item/Currency.</summary>
        public string KeyPath { get; set; } = "";

        /// <summary>One sheet per value, in this order (e.g. PHP, USD, JPY).</summary>
        public IReadOnlyList<string> Values { get; set; } = new List<string>();

        public bool Equals(SheetSplitDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(GroupPath, other.GroupPath)
    && EqualityComparer<string>.Default.Equals(KeyPath, other.KeyPath)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Values, other.Values);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SheetSplitDto);
    }

        public static bool operator ==(SheetSplitDto left, SheetSplitDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SheetSplitDto left, SheetSplitDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 94227;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(GroupPath);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(KeyPath);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Values);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SheetSplitDto { " + "GroupPath = " + GroupPath + ", " + "KeyPath = " + KeyPath + ", " + "Values = " + Values + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SheetSplitDto CloneRecord()
    {
    return (SheetSplitDto)MemberwiseClone();
    }

    }

    /// <summary>A form that can be split into one sheet per key value, and its possible key fields.</summary>
    public sealed class SheetSplitOptionDto : IRecord<SheetSplitOptionDto>, IEquatable<SheetSplitOptionDto>
    {
        public string GroupPath { get; set; } = "";

        /// <summary>The XSD form (e.g. CAR_Part_IV_4c).</summary>
        public string Form { get; set; } = "";

        /// <summary>The template sheet the form is mapped to; the copies are named after it.</summary>
        public string SheetName { get; set; } = "";

        public int FieldCount { get; set; }

        /// <summary>True when the item holds lists of its own (Excel cannot bind those; the app reads them).</summary>
        public bool HasNestedLists { get; set; }

        public IReadOnlyList<SheetSplitKeyDto> KeyFields { get; set; } = new List<SheetSplitKeyDto>();

        public bool Equals(SheetSplitOptionDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(GroupPath, other.GroupPath)
    && EqualityComparer<string>.Default.Equals(Form, other.Form)
    && EqualityComparer<string>.Default.Equals(SheetName, other.SheetName)
    && EqualityComparer<int>.Default.Equals(FieldCount, other.FieldCount)
    && EqualityComparer<bool>.Default.Equals(HasNestedLists, other.HasNestedLists)
    && EqualityComparer<IReadOnlyList<SheetSplitKeyDto>>.Default.Equals(KeyFields, other.KeyFields);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SheetSplitOptionDto);
    }

        public static bool operator ==(SheetSplitOptionDto left, SheetSplitOptionDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SheetSplitOptionDto left, SheetSplitOptionDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 54690;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(GroupPath);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Form);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SheetName);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(FieldCount);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(HasNestedLists);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SheetSplitKeyDto>>.Default.GetHashCode(KeyFields);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SheetSplitOptionDto { " + "GroupPath = " + GroupPath + ", " + "Form = " + Form + ", " + "SheetName = " + SheetName + ", " + "FieldCount = " + FieldCount + ", " + "HasNestedLists = " + HasNestedLists + ", " + "KeyFields = " + KeyFields + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SheetSplitOptionDto CloneRecord()
    {
    return (SheetSplitOptionDto)MemberwiseClone();
    }

    }

    public sealed class SheetSplitKeyDto : IRecord<SheetSplitKeyDto>, IEquatable<SheetSplitKeyDto>
    {
        public string Path { get; set; } = "";

        public string Name { get; set; } = "";

        public string DataType { get; set; } = "string";

        public bool IsRequired { get; set; }

        /// <summary>The XSD's allowed values (e.g. the currency codes); empty when any valid value is allowed.</summary>
        public IReadOnlyList<string> AllowedValues { get; set; } = new List<string>();

        /// <summary>The key field's mapped cell on the form's sheet (e.g. A6).</summary>
        public string CellAddress { get; set; } = "";

        public bool Equals(SheetSplitKeyDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Path, other.Path)
    && EqualityComparer<string>.Default.Equals(Name, other.Name)
    && EqualityComparer<string>.Default.Equals(DataType, other.DataType)
    && EqualityComparer<bool>.Default.Equals(IsRequired, other.IsRequired)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(AllowedValues, other.AllowedValues)
    && EqualityComparer<string>.Default.Equals(CellAddress, other.CellAddress);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SheetSplitKeyDto);
    }

        public static bool operator ==(SheetSplitKeyDto left, SheetSplitKeyDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SheetSplitKeyDto left, SheetSplitKeyDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 11980;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Path);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DataType);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsRequired);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(AllowedValues);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(CellAddress);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SheetSplitKeyDto { " + "Path = " + Path + ", " + "Name = " + Name + ", " + "DataType = " + DataType + ", " + "IsRequired = " + IsRequired + ", " + "AllowedValues = " + AllowedValues + ", " + "CellAddress = " + CellAddress + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SheetSplitKeyDto CloneRecord()
    {
    return (SheetSplitKeyDto)MemberwiseClone();
    }

    }

    /// <summary>The forms that can be split by sheet and the project's current splits.</summary>
    public sealed class SheetSplitSettingsDto : IRecord<SheetSplitSettingsDto>, IEquatable<SheetSplitSettingsDto>
    {
        public IReadOnlyList<SheetSplitOptionDto> Options { get; set; } = new List<SheetSplitOptionDto>();

        public IReadOnlyList<SheetSplitDto> Splits { get; set; } = new List<SheetSplitDto>();

        public int MaxValues { get; set; }

        public bool Equals(SheetSplitSettingsDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<SheetSplitOptionDto>>.Default.Equals(Options, other.Options)
    && EqualityComparer<IReadOnlyList<SheetSplitDto>>.Default.Equals(Splits, other.Splits)
    && EqualityComparer<int>.Default.Equals(MaxValues, other.MaxValues);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SheetSplitSettingsDto);
    }

        public static bool operator ==(SheetSplitSettingsDto left, SheetSplitSettingsDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SheetSplitSettingsDto left, SheetSplitSettingsDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 63376;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SheetSplitOptionDto>>.Default.GetHashCode(Options);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SheetSplitDto>>.Default.GetHashCode(Splits);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(MaxValues);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SheetSplitSettingsDto { " + "Options = " + Options + ", " + "Splits = " + Splits + ", " + "MaxValues = " + MaxValues + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SheetSplitSettingsDto CloneRecord()
    {
    return (SheetSplitSettingsDto)MemberwiseClone();
    }

    }

    public sealed class SaveSheetSplitsRequest : IRecord<SaveSheetSplitsRequest>, IEquatable<SaveSheetSplitsRequest>
    {
        public IReadOnlyList<SheetSplitDto> Splits { get; set; } = new List<SheetSplitDto>();

        public bool Equals(SaveSheetSplitsRequest other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<SheetSplitDto>>.Default.Equals(Splits, other.Splits);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SaveSheetSplitsRequest);
    }

        public static bool operator ==(SaveSheetSplitsRequest left, SaveSheetSplitsRequest right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SaveSheetSplitsRequest left, SaveSheetSplitsRequest right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 80123;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SheetSplitDto>>.Default.GetHashCode(Splits);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SaveSheetSplitsRequest { " + "Splits = " + Splits + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SaveSheetSplitsRequest CloneRecord()
    {
    return (SaveSheetSplitsRequest)MemberwiseClone();
    }

    }

    /// <summary>Sheet names of split forms: "CAR_Part_IV_4c (USD)", shortened to Excel's 31 characters.</summary>
    public static class SheetSplitNames
    {
        public const int MaxSheetNameLength = 31;

        /// <summary>
        /// The sheet of one value: "Base (value)", e.g. "CAR_Part_IV_4c (PHP)". A sheet whose name ends with a number and
        /// its parts' letters, e.g. "CAR_Part_V_2abc" (parts 2a, 2b, 2c), takes the part's letter for the values 1, 2, 3…:
        /// "CAR_Part_V_2a", "CAR_Part_V_2b", "CAR_Part_V_2c" (other values keep "Base (value)").
        /// </summary>
        public static string For(string baseSheet, string value) => PartName(baseSheet, value) ?? WithSuffix(baseSheet, value);

        /// <summary>"Base (value)", the name every copy had before part names (a template downloaded earlier).</summary>
        public static string WithSuffix(string baseSheet, string value)
        {
            var suffix = $" ({value})";
            var room = MaxSheetNameLength - suffix.Length;
            var prefix = baseSheet.Length <= room ? baseSheet : baseSheet.Substring(0, Math.Max(room, 1)).TrimEnd();
            return prefix + suffix;
        }

        /// <summary>"CAR_Part_V_2abc" with value 2 gives "CAR_Part_V_2b"; null when the sheet or value does not fit.</summary>
        private static string PartName(string baseSheet, string value)
        {
            var letters = PartLetters(baseSheet);
            int number;
            if (letters == null || !int.TryParse(value, System.Globalization.NumberStyles.None, System.Globalization.CultureInfo.InvariantCulture, out number)
                || number < 1 || number > letters.Length || value != number.ToString(System.Globalization.CultureInfo.InvariantCulture))
            {
                return null;
            }

            return baseSheet.Substring(0, baseSheet.Length - letters.Length) + letters[number - 1];
        }

        /// <summary>The part letters at the end of a sheet name ("abc" in "CAR_Part_V_2abc"): two or more distinct a–z after a digit.</summary>
        private static string PartLetters(string sheetName)
        {
            var end = sheetName.Length;
            var start = end;
            while (start > 0 && sheetName[start - 1] >= 'a' && sheetName[start - 1] <= 'z')
            {
                start--;
            }

            var letters = sheetName.Substring(start, end - start);
            return letters.Length >= 2 && start > 0 && CompatChar.IsAsciiDigit(sheetName[start - 1]) && letters.Distinct().Count() == letters.Length
                ? letters
                : null;
        }

        /// <summary>True when <paramref name="sheetName"/> looks like a copy of <paramref name="baseSheet"/> ("Base (value)", or a part name such as "CAR_Part_V_2a").</summary>
        public static bool IsCopyOf(string sheetName, string baseSheet)
        {
            var letters = PartLetters(baseSheet);
            if (letters != null)
            {
                for (var number = 1; number <= letters.Length; number++)
                {
                    if (string.Equals(PartName(baseSheet, number.ToString(System.Globalization.CultureInfo.InvariantCulture)), sheetName, StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
            }

            var open = sheetName.LastIndexOf(" (", StringComparison.Ordinal);
            if (open <= 0 || !sheetName.EndsWith(')'))
            {
                return false;
            }

            var value = sheetName.Substring(open + 2, (sheetName.Length - 1) - (open + 2));
            return value.Length > 0 && string.Equals(WithSuffix(baseSheet, value), sheetName, StringComparison.OrdinalIgnoreCase);
        }
    }

    public sealed class UploadedFileDto : IRecord<UploadedFileDto>, IEquatable<UploadedFileDto>
    {
        public string OriginalName { get; set; } = "";

        public string StoredPath { get; set; } = "";

        public long Size { get; set; }

        /// <summary>SHA-256 of the content. Identical uploads are stored once and shared by the projects that use them.</summary>
        public string Sha256 { get; set; }

        public bool Equals(UploadedFileDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(OriginalName, other.OriginalName)
    && EqualityComparer<string>.Default.Equals(StoredPath, other.StoredPath)
    && EqualityComparer<long>.Default.Equals(Size, other.Size)
    && EqualityComparer<string>.Default.Equals(Sha256, other.Sha256);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as UploadedFileDto);
    }

        public static bool operator ==(UploadedFileDto left, UploadedFileDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(UploadedFileDto left, UploadedFileDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 35822;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(OriginalName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(StoredPath);
    hash = hash * -1521134295 + EqualityComparer<long>.Default.GetHashCode(Size);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Sha256);
    return hash;
    }
    }

        public override string ToString()
    {
    return "UploadedFileDto { " + "OriginalName = " + OriginalName + ", " + "StoredPath = " + StoredPath + ", " + "Size = " + Size + ", " + "Sha256 = " + Sha256 + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public UploadedFileDto CloneRecord()
    {
    return (UploadedFileDto)MemberwiseClone();
    }

    }

    public sealed class SchemaNodeDto : IRecord<SchemaNodeDto>, IEquatable<SchemaNodeDto>
    {
        public string Path { get; set; } = "";

        public string Name { get; set; } = "";

        public string DataType { get; set; } = "string";

        public string TestValue { get; set; }

        public SchemaValidationDto Validation { get; set; } = new SchemaValidationDto();

        public bool IsRequired { get; set; }

        public bool IsRepeating { get; set; }

        /// <summary>True when this node or one of its ancestors can occur more than once (list/table data).</summary>
        public bool IsInRepeatingGroup { get; set; }

        public string ParentPath { get; set; }

        public int Depth { get; set; }

        public bool Equals(SchemaNodeDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Path, other.Path)
    && EqualityComparer<string>.Default.Equals(Name, other.Name)
    && EqualityComparer<string>.Default.Equals(DataType, other.DataType)
    && EqualityComparer<string>.Default.Equals(TestValue, other.TestValue)
    && EqualityComparer<SchemaValidationDto>.Default.Equals(Validation, other.Validation)
    && EqualityComparer<bool>.Default.Equals(IsRequired, other.IsRequired)
    && EqualityComparer<bool>.Default.Equals(IsRepeating, other.IsRepeating)
    && EqualityComparer<bool>.Default.Equals(IsInRepeatingGroup, other.IsInRepeatingGroup)
    && EqualityComparer<string>.Default.Equals(ParentPath, other.ParentPath)
    && EqualityComparer<int>.Default.Equals(Depth, other.Depth);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SchemaNodeDto);
    }

        public static bool operator ==(SchemaNodeDto left, SchemaNodeDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SchemaNodeDto left, SchemaNodeDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 16981;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Path);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DataType);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(TestValue);
    hash = hash * -1521134295 + EqualityComparer<SchemaValidationDto>.Default.GetHashCode(Validation);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsRequired);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsRepeating);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsInRepeatingGroup);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ParentPath);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Depth);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SchemaNodeDto { " + "Path = " + Path + ", " + "Name = " + Name + ", " + "DataType = " + DataType + ", " + "TestValue = " + TestValue + ", " + "Validation = " + Validation + ", " + "IsRequired = " + IsRequired + ", " + "IsRepeating = " + IsRepeating + ", " + "IsInRepeatingGroup = " + IsInRepeatingGroup + ", " + "ParentPath = " + ParentPath + ", " + "Depth = " + Depth + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SchemaNodeDto CloneRecord()
    {
    return (SchemaNodeDto)MemberwiseClone();
    }

    }

    public sealed class SchemaValidationDto : IRecord<SchemaValidationDto>, IEquatable<SchemaValidationDto>
    {
        public IReadOnlyList<string> Enumerations { get; set; } = new List<string>();

        public string Pattern { get; set; }

        public IReadOnlyList<IReadOnlyList<string>> PatternGroups { get; set; } = new List<IReadOnlyList<string>>();

        public string WhiteSpace { get; set; }

        public string FixedValue { get; set; }

        public int? Length { get; set; }

        public string MinInclusive { get; set; }

        public string MaxInclusive { get; set; }

        public string MinExclusive { get; set; }

        public string MaxExclusive { get; set; }

        public int? TotalDigits { get; set; }

        public int? FractionDigits { get; set; }

        public int? MinLength { get; set; }

        public int? MaxLength { get; set; }

        public bool Equals(SchemaValidationDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<string>>.Default.Equals(Enumerations, other.Enumerations)
    && EqualityComparer<string>.Default.Equals(Pattern, other.Pattern)
    && EqualityComparer<IReadOnlyList<IReadOnlyList<string>>>.Default.Equals(PatternGroups, other.PatternGroups)
    && EqualityComparer<string>.Default.Equals(WhiteSpace, other.WhiteSpace)
    && EqualityComparer<string>.Default.Equals(FixedValue, other.FixedValue)
    && EqualityComparer<int?>.Default.Equals(Length, other.Length)
    && EqualityComparer<string>.Default.Equals(MinInclusive, other.MinInclusive)
    && EqualityComparer<string>.Default.Equals(MaxInclusive, other.MaxInclusive)
    && EqualityComparer<string>.Default.Equals(MinExclusive, other.MinExclusive)
    && EqualityComparer<string>.Default.Equals(MaxExclusive, other.MaxExclusive)
    && EqualityComparer<int?>.Default.Equals(TotalDigits, other.TotalDigits)
    && EqualityComparer<int?>.Default.Equals(FractionDigits, other.FractionDigits)
    && EqualityComparer<int?>.Default.Equals(MinLength, other.MinLength)
    && EqualityComparer<int?>.Default.Equals(MaxLength, other.MaxLength);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SchemaValidationDto);
    }

        public static bool operator ==(SchemaValidationDto left, SchemaValidationDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SchemaValidationDto left, SchemaValidationDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 6508;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Enumerations);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Pattern);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<IReadOnlyList<string>>>.Default.GetHashCode(PatternGroups);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(WhiteSpace);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(FixedValue);
    hash = hash * -1521134295 + EqualityComparer<int?>.Default.GetHashCode(Length);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(MinInclusive);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(MaxInclusive);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(MinExclusive);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(MaxExclusive);
    hash = hash * -1521134295 + EqualityComparer<int?>.Default.GetHashCode(TotalDigits);
    hash = hash * -1521134295 + EqualityComparer<int?>.Default.GetHashCode(FractionDigits);
    hash = hash * -1521134295 + EqualityComparer<int?>.Default.GetHashCode(MinLength);
    hash = hash * -1521134295 + EqualityComparer<int?>.Default.GetHashCode(MaxLength);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SchemaValidationDto { " + "Enumerations = " + Enumerations + ", " + "Pattern = " + Pattern + ", " + "PatternGroups = " + PatternGroups + ", " + "WhiteSpace = " + WhiteSpace + ", " + "FixedValue = " + FixedValue + ", " + "Length = " + Length + ", " + "MinInclusive = " + MinInclusive + ", " + "MaxInclusive = " + MaxInclusive + ", " + "MinExclusive = " + MinExclusive + ", " + "MaxExclusive = " + MaxExclusive + ", " + "TotalDigits = " + TotalDigits + ", " + "FractionDigits = " + FractionDigits + ", " + "MinLength = " + MinLength + ", " + "MaxLength = " + MaxLength + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SchemaValidationDto CloneRecord()
    {
    return (SchemaValidationDto)MemberwiseClone();
    }

    }

    public sealed class WorkbookSummaryDto : IRecord<WorkbookSummaryDto>, IEquatable<WorkbookSummaryDto>
    {
        public string FileName { get; set; } = "";

        public IReadOnlyList<WorkbookSheetDto> Sheets { get; set; } = new List<WorkbookSheetDto>();

        public IReadOnlyList<ExistingXmlMappingDto> ExistingMappings { get; set; } = new List<ExistingXmlMappingDto>();

        /// <summary>Total existing XML map bindings found (the stored list may be trimmed for size).</summary>
        public int ExistingMappingCount { get; set; }

        public bool Equals(WorkbookSummaryDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(FileName, other.FileName)
    && EqualityComparer<IReadOnlyList<WorkbookSheetDto>>.Default.Equals(Sheets, other.Sheets)
    && EqualityComparer<IReadOnlyList<ExistingXmlMappingDto>>.Default.Equals(ExistingMappings, other.ExistingMappings)
    && EqualityComparer<int>.Default.Equals(ExistingMappingCount, other.ExistingMappingCount);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as WorkbookSummaryDto);
    }

        public static bool operator ==(WorkbookSummaryDto left, WorkbookSummaryDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(WorkbookSummaryDto left, WorkbookSummaryDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 72324;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(FileName);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<WorkbookSheetDto>>.Default.GetHashCode(Sheets);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<ExistingXmlMappingDto>>.Default.GetHashCode(ExistingMappings);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(ExistingMappingCount);
    return hash;
    }
    }

        public override string ToString()
    {
    return "WorkbookSummaryDto { " + "FileName = " + FileName + ", " + "Sheets = " + Sheets + ", " + "ExistingMappings = " + ExistingMappings + ", " + "ExistingMappingCount = " + ExistingMappingCount + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public WorkbookSummaryDto CloneRecord()
    {
    return (WorkbookSummaryDto)MemberwiseClone();
    }

    }

    public sealed class WorkbookSheetDto : IRecord<WorkbookSheetDto>, IEquatable<WorkbookSheetDto>
    {
        public string Name { get; set; } = "";

        public string RelationshipId { get; set; } = "";

        public string WorksheetPath { get; set; } = "";

        public int TotalStoredCellCount { get; set; }

        public IReadOnlyList<WorkbookCellDto> Cells { get; set; } = new List<WorkbookCellDto>();

        public bool Equals(WorkbookSheetDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Name, other.Name)
    && EqualityComparer<string>.Default.Equals(RelationshipId, other.RelationshipId)
    && EqualityComparer<string>.Default.Equals(WorksheetPath, other.WorksheetPath)
    && EqualityComparer<int>.Default.Equals(TotalStoredCellCount, other.TotalStoredCellCount)
    && EqualityComparer<IReadOnlyList<WorkbookCellDto>>.Default.Equals(Cells, other.Cells);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as WorkbookSheetDto);
    }

        public static bool operator ==(WorkbookSheetDto left, WorkbookSheetDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(WorkbookSheetDto left, WorkbookSheetDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 83317;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(RelationshipId);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(WorksheetPath);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(TotalStoredCellCount);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<WorkbookCellDto>>.Default.GetHashCode(Cells);
    return hash;
    }
    }

        public override string ToString()
    {
    return "WorkbookSheetDto { " + "Name = " + Name + ", " + "RelationshipId = " + RelationshipId + ", " + "WorksheetPath = " + WorksheetPath + ", " + "TotalStoredCellCount = " + TotalStoredCellCount + ", " + "Cells = " + Cells + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public WorkbookSheetDto CloneRecord()
    {
    return (WorkbookSheetDto)MemberwiseClone();
    }

    }

    public sealed class WorkbookCellDto : IRecord<WorkbookCellDto>, IEquatable<WorkbookCellDto>
    {
        public string Address { get; set; } = "";

        public string DisplayValue { get; set; } = "";

        public string Style { get; set; }

        public bool Equals(WorkbookCellDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Address, other.Address)
    && EqualityComparer<string>.Default.Equals(DisplayValue, other.DisplayValue)
    && EqualityComparer<string>.Default.Equals(Style, other.Style);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as WorkbookCellDto);
    }

        public static bool operator ==(WorkbookCellDto left, WorkbookCellDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(WorkbookCellDto left, WorkbookCellDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 88082;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Address);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DisplayValue);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Style);
    return hash;
    }
    }

        public override string ToString()
    {
    return "WorkbookCellDto { " + "Address = " + Address + ", " + "DisplayValue = " + DisplayValue + ", " + "Style = " + Style + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public WorkbookCellDto CloneRecord()
    {
    return (WorkbookCellDto)MemberwiseClone();
    }

    }

    public sealed class ExistingXmlMappingDto : IRecord<ExistingXmlMappingDto>, IEquatable<ExistingXmlMappingDto>
    {
        public string SheetName { get; set; } = "";

        public string CellAddress { get; set; } = "";

        public string XPath { get; set; } = "";

        public string DataType { get; set; } = "";

        public string ElementName { get; set; }

        /// <summary>True when the binding comes from an Excel XML list table (repeating rows) instead of a single cell.</summary>
        public bool IsListColumn { get; set; }

        public bool Equals(ExistingXmlMappingDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(SheetName, other.SheetName)
    && EqualityComparer<string>.Default.Equals(CellAddress, other.CellAddress)
    && EqualityComparer<string>.Default.Equals(XPath, other.XPath)
    && EqualityComparer<string>.Default.Equals(DataType, other.DataType)
    && EqualityComparer<string>.Default.Equals(ElementName, other.ElementName)
    && EqualityComparer<bool>.Default.Equals(IsListColumn, other.IsListColumn);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ExistingXmlMappingDto);
    }

        public static bool operator ==(ExistingXmlMappingDto left, ExistingXmlMappingDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ExistingXmlMappingDto left, ExistingXmlMappingDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 39244;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SheetName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(CellAddress);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(XPath);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DataType);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ElementName);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsListColumn);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ExistingXmlMappingDto { " + "SheetName = " + SheetName + ", " + "CellAddress = " + CellAddress + ", " + "XPath = " + XPath + ", " + "DataType = " + DataType + ", " + "ElementName = " + ElementName + ", " + "IsListColumn = " + IsListColumn + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ExistingXmlMappingDto CloneRecord()
    {
    return (ExistingXmlMappingDto)MemberwiseClone();
    }

    }

    public sealed class MappingEntryDto : IRecord<MappingEntryDto>, IEquatable<MappingEntryDto>
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");

        public string SheetName { get; set; } = "";

        public string CellAddress { get; set; } = "";

        public string SchemaPath { get; set; } = "";

        public string DataType { get; set; } = "string";

        public bool Required { get; set; }

        public string DefaultValue { get; set; }

        public string Source { get; set; } = "Manual";

        public bool Equals(MappingEntryDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Id, other.Id)
    && EqualityComparer<string>.Default.Equals(SheetName, other.SheetName)
    && EqualityComparer<string>.Default.Equals(CellAddress, other.CellAddress)
    && EqualityComparer<string>.Default.Equals(SchemaPath, other.SchemaPath)
    && EqualityComparer<string>.Default.Equals(DataType, other.DataType)
    && EqualityComparer<bool>.Default.Equals(Required, other.Required)
    && EqualityComparer<string>.Default.Equals(DefaultValue, other.DefaultValue)
    && EqualityComparer<string>.Default.Equals(Source, other.Source);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as MappingEntryDto);
    }

        public static bool operator ==(MappingEntryDto left, MappingEntryDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(MappingEntryDto left, MappingEntryDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 97654;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Id);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SheetName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(CellAddress);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SchemaPath);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DataType);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Required);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DefaultValue);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Source);
    return hash;
    }
    }

        public override string ToString()
    {
    return "MappingEntryDto { " + "Id = " + Id + ", " + "SheetName = " + SheetName + ", " + "CellAddress = " + CellAddress + ", " + "SchemaPath = " + SchemaPath + ", " + "DataType = " + DataType + ", " + "Required = " + Required + ", " + "DefaultValue = " + DefaultValue + ", " + "Source = " + Source + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public MappingEntryDto CloneRecord()
    {
    return (MappingEntryDto)MemberwiseClone();
    }

    }

    public sealed class ValidationIssueDto : IRecord<ValidationIssueDto>, IEquatable<ValidationIssueDto>
    {
        public string Severity { get; set; } = "Info";

        public string Message { get; set; } = "";

        public string SchemaPath { get; set; }

        public string SheetName { get; set; }

        public string CellAddress { get; set; }

        /// <summary>Where the issue came from: Mapping, Value, or Schema.</summary>
        public string Category { get; set; } = "Mapping";

        /// <summary>The BSP rule code (e.g. RIN-B1690), for a specification rule.</summary>
        public string Rule { get; set; }

        /// <summary>The branch the rule failed for (its code and name in the bank's branch register), for a per-branch rule.</summary>
        public string BranchCode { get; set; }

        public string BranchName { get; set; }

        public bool Equals(ValidationIssueDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Severity, other.Severity)
    && EqualityComparer<string>.Default.Equals(Message, other.Message)
    && EqualityComparer<string>.Default.Equals(SchemaPath, other.SchemaPath)
    && EqualityComparer<string>.Default.Equals(SheetName, other.SheetName)
    && EqualityComparer<string>.Default.Equals(CellAddress, other.CellAddress)
    && EqualityComparer<string>.Default.Equals(Category, other.Category);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ValidationIssueDto);
    }

        public static bool operator ==(ValidationIssueDto left, ValidationIssueDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ValidationIssueDto left, ValidationIssueDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 46256;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Severity);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Message);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SchemaPath);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SheetName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(CellAddress);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Category);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ValidationIssueDto { " + "Severity = " + Severity + ", " + "Message = " + Message + ", " + "SchemaPath = " + SchemaPath + ", " + "SheetName = " + SheetName + ", " + "CellAddress = " + CellAddress + ", " + "Category = " + Category + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ValidationIssueDto CloneRecord()
    {
    return (ValidationIssueDto)MemberwiseClone();
    }

    }

    public sealed class ProjectValidationResultDto : IRecord<ProjectValidationResultDto>, IEquatable<ProjectValidationResultDto>
    {
        public bool IsValid { get; set; }

        public int ErrorCount { get; set; }

        public int WarningCount { get; set; }

        public int CheckedValues { get; set; }

        public int MappedSheets { get; set; }

        public int TotalSheets { get; set; }

        /// <summary>True when a BSP specification workbook was available and checked.</summary>
        public bool SpecificationChecked { get; set; }

        public int SpecInputFieldsConfirmed { get; set; }

        public int SpecRulesPassed { get; set; }

        public int SpecRulesFailed { get; set; }

        public int SpecRulesNotApplicable { get; set; }

        /// <summary>Rules that cannot be decided from the files (e.g. LOOKUP of BSP's bank master list).</summary>
        public int SpecRulesNotEvaluated { get; set; }

        public IReadOnlyList<ValidationIssueDto> Issues { get; set; } = new List<ValidationIssueDto>();

        public bool Equals(ProjectValidationResultDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<bool>.Default.Equals(IsValid, other.IsValid)
    && EqualityComparer<int>.Default.Equals(ErrorCount, other.ErrorCount)
    && EqualityComparer<int>.Default.Equals(WarningCount, other.WarningCount)
    && EqualityComparer<int>.Default.Equals(CheckedValues, other.CheckedValues)
    && EqualityComparer<int>.Default.Equals(MappedSheets, other.MappedSheets)
    && EqualityComparer<int>.Default.Equals(TotalSheets, other.TotalSheets)
    && EqualityComparer<bool>.Default.Equals(SpecificationChecked, other.SpecificationChecked)
    && EqualityComparer<int>.Default.Equals(SpecInputFieldsConfirmed, other.SpecInputFieldsConfirmed)
    && EqualityComparer<int>.Default.Equals(SpecRulesPassed, other.SpecRulesPassed)
    && EqualityComparer<int>.Default.Equals(SpecRulesFailed, other.SpecRulesFailed)
    && EqualityComparer<int>.Default.Equals(SpecRulesNotApplicable, other.SpecRulesNotApplicable)
    && EqualityComparer<int>.Default.Equals(SpecRulesNotEvaluated, other.SpecRulesNotEvaluated)
    && EqualityComparer<IReadOnlyList<ValidationIssueDto>>.Default.Equals(Issues, other.Issues);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ProjectValidationResultDto);
    }

        public static bool operator ==(ProjectValidationResultDto left, ProjectValidationResultDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ProjectValidationResultDto left, ProjectValidationResultDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 37599;
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsValid);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(ErrorCount);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(WarningCount);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(CheckedValues);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(MappedSheets);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(TotalSheets);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(SpecificationChecked);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SpecInputFieldsConfirmed);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SpecRulesPassed);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SpecRulesFailed);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SpecRulesNotApplicable);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SpecRulesNotEvaluated);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<ValidationIssueDto>>.Default.GetHashCode(Issues);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ProjectValidationResultDto { " + "IsValid = " + IsValid + ", " + "ErrorCount = " + ErrorCount + ", " + "WarningCount = " + WarningCount + ", " + "CheckedValues = " + CheckedValues + ", " + "MappedSheets = " + MappedSheets + ", " + "TotalSheets = " + TotalSheets + ", " + "SpecificationChecked = " + SpecificationChecked + ", " + "SpecInputFieldsConfirmed = " + SpecInputFieldsConfirmed + ", " + "SpecRulesPassed = " + SpecRulesPassed + ", " + "SpecRulesFailed = " + SpecRulesFailed + ", " + "SpecRulesNotApplicable = " + SpecRulesNotApplicable + ", " + "SpecRulesNotEvaluated = " + SpecRulesNotEvaluated + ", " + "Issues = " + Issues + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ProjectValidationResultDto CloneRecord()
    {
    return (ProjectValidationResultDto)MemberwiseClone();
    }

    }

    public sealed class AnalyzeProjectRequest : IRecord<AnalyzeProjectRequest>, IEquatable<AnalyzeProjectRequest>
    {
        public string ProjectName { get; set; } = "";

        public bool Equals(AnalyzeProjectRequest other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(ProjectName, other.ProjectName);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AnalyzeProjectRequest);
    }

        public static bool operator ==(AnalyzeProjectRequest left, AnalyzeProjectRequest right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AnalyzeProjectRequest left, AnalyzeProjectRequest right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 31407;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ProjectName);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AnalyzeProjectRequest { " + "ProjectName = " + ProjectName + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AnalyzeProjectRequest CloneRecord()
    {
    return (AnalyzeProjectRequest)MemberwiseClone();
    }

    }

    public sealed class UpdateMappingsRequest : IRecord<UpdateMappingsRequest>, IEquatable<UpdateMappingsRequest>
    {
        public IReadOnlyList<MappingEntryDto> Mappings { get; set; } = new List<MappingEntryDto>();

        public bool Equals(UpdateMappingsRequest other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.Equals(Mappings, other.Mappings);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as UpdateMappingsRequest);
    }

        public static bool operator ==(UpdateMappingsRequest left, UpdateMappingsRequest right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(UpdateMappingsRequest left, UpdateMappingsRequest right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 43888;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.GetHashCode(Mappings);
    return hash;
    }
    }

        public override string ToString()
    {
    return "UpdateMappingsRequest { " + "Mappings = " + Mappings + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public UpdateMappingsRequest CloneRecord()
    {
    return (UpdateMappingsRequest)MemberwiseClone();
    }

    }

    public sealed class XsdValidationResultDto : IRecord<XsdValidationResultDto>, IEquatable<XsdValidationResultDto>
    {
        public bool IsValid { get; set; }

        public string Target { get; set; } = "";

        public bool SpecificationChecked { get; set; }

        public int SpecRulesPassed { get; set; }

        public int SpecRulesFailed { get; set; }

        public int SpecRulesNotApplicable { get; set; }

        public int SpecRulesNotEvaluated { get; set; }

        public IReadOnlyList<XsdValidationMessageDto> Messages { get; set; } = new List<XsdValidationMessageDto>();

        /// <summary>The specification rules per form (passed, failed, not applicable, not evaluated), so a form whose rules all passed is visible too.</summary>
        public IReadOnlyList<SpecRuleFormDto> SpecRuleForms { get; set; } = new List<SpecRuleFormDto>();

        public bool Equals(XsdValidationResultDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<bool>.Default.Equals(IsValid, other.IsValid)
    && EqualityComparer<string>.Default.Equals(Target, other.Target)
    && EqualityComparer<bool>.Default.Equals(SpecificationChecked, other.SpecificationChecked)
    && EqualityComparer<int>.Default.Equals(SpecRulesPassed, other.SpecRulesPassed)
    && EqualityComparer<int>.Default.Equals(SpecRulesFailed, other.SpecRulesFailed)
    && EqualityComparer<int>.Default.Equals(SpecRulesNotApplicable, other.SpecRulesNotApplicable)
    && EqualityComparer<int>.Default.Equals(SpecRulesNotEvaluated, other.SpecRulesNotEvaluated)
    && EqualityComparer<IReadOnlyList<XsdValidationMessageDto>>.Default.Equals(Messages, other.Messages)
    && EqualityComparer<IReadOnlyList<SpecRuleFormDto>>.Default.Equals(SpecRuleForms, other.SpecRuleForms);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as XsdValidationResultDto);
    }

        public static bool operator ==(XsdValidationResultDto left, XsdValidationResultDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(XsdValidationResultDto left, XsdValidationResultDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 5967;
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsValid);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Target);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(SpecificationChecked);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SpecRulesPassed);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SpecRulesFailed);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SpecRulesNotApplicable);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SpecRulesNotEvaluated);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<XsdValidationMessageDto>>.Default.GetHashCode(Messages);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SpecRuleFormDto>>.Default.GetHashCode(SpecRuleForms);
    return hash;
    }
    }

        public override string ToString()
    {
    return "XsdValidationResultDto { " + "IsValid = " + IsValid + ", " + "Target = " + Target + ", " + "SpecificationChecked = " + SpecificationChecked + ", " + "SpecRulesPassed = " + SpecRulesPassed + ", " + "SpecRulesFailed = " + SpecRulesFailed + ", " + "SpecRulesNotApplicable = " + SpecRulesNotApplicable + ", " + "SpecRulesNotEvaluated = " + SpecRulesNotEvaluated + ", " + "Messages = " + Messages + ", " + "SpecRuleForms = " + SpecRuleForms + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public XsdValidationResultDto CloneRecord()
    {
    return (XsdValidationResultDto)MemberwiseClone();
    }

    }

    public sealed class XsdValidationMessageDto : IRecord<XsdValidationMessageDto>, IEquatable<XsdValidationMessageDto>
    {
        public string Severity { get; set; } = "";

        public string Message { get; set; } = "";

        public int LineNumber { get; set; }

        public int LinePosition { get; set; }

        /// <summary>The Excel cell the message is about ("Sheet!A1"), when a filled template was validated.</summary>
        public string Cell { get; set; }

        /// <summary>The XSD element the message is about, when known.</summary>
        public string SchemaPath { get; set; }

        /// <summary>The BSP rule code (e.g. RIN-B1690), for a specification rule.</summary>
        public string Rule { get; set; }

        /// <summary>The branch a per-branch rule failed for: its code and its name in the bank's branch register.</summary>
        public string BranchCode { get; set; }

        public string BranchName { get; set; }

        public bool Equals(XsdValidationMessageDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Severity, other.Severity)
    && EqualityComparer<string>.Default.Equals(Message, other.Message)
    && EqualityComparer<int>.Default.Equals(LineNumber, other.LineNumber)
    && EqualityComparer<int>.Default.Equals(LinePosition, other.LinePosition)
    && EqualityComparer<string>.Default.Equals(Cell, other.Cell)
    && EqualityComparer<string>.Default.Equals(SchemaPath, other.SchemaPath);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as XsdValidationMessageDto);
    }

        public static bool operator ==(XsdValidationMessageDto left, XsdValidationMessageDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(XsdValidationMessageDto left, XsdValidationMessageDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 87881;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Severity);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Message);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(LineNumber);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(LinePosition);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Cell);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SchemaPath);
    return hash;
    }
    }

        public override string ToString()
    {
    return "XsdValidationMessageDto { " + "Severity = " + Severity + ", " + "Message = " + Message + ", " + "LineNumber = " + LineNumber + ", " + "LinePosition = " + LinePosition + ", " + "Cell = " + Cell + ", " + "SchemaPath = " + SchemaPath + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public XsdValidationMessageDto CloneRecord()
    {
    return (XsdValidationMessageDto)MemberwiseClone();
    }

    }

    /// <summary>How far a validation has got: percent done (0-100), the current step, and what it is checking now.</summary>
    public sealed class ValidationProgressDto : IRecord<ValidationProgressDto>, IEquatable<ValidationProgressDto>
    {
        public int Percent { get; set; }

        public string Stage { get; set; } = "";

        public string Detail { get; set; }

        public bool Equals(ValidationProgressDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<int>.Default.Equals(Percent, other.Percent)
    && EqualityComparer<string>.Default.Equals(Stage, other.Stage)
    && EqualityComparer<string>.Default.Equals(Detail, other.Detail);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ValidationProgressDto);
    }

        public static bool operator ==(ValidationProgressDto left, ValidationProgressDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ValidationProgressDto left, ValidationProgressDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 9416;
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Percent);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Stage);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Detail);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ValidationProgressDto { " + "Percent = " + Percent + ", " + "Stage = " + Stage + ", " + "Detail = " + Detail + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ValidationProgressDto CloneRecord()
    {
    return (ValidationProgressDto)MemberwiseClone();
    }

    }

    /// <summary>
    /// One line of a streamed validation (application/x-ndjson): progress while it runs, then the result or an error.
    /// </summary>
    public sealed class ValidationStreamEventDto : IRecord<ValidationStreamEventDto>, IEquatable<ValidationStreamEventDto>
    {
        public const string ProgressType = "progress";

        public const string ResultType = "result";

        public const string ErrorType = "error";


        public string Type { get; set; } = ProgressType;

        public ValidationProgressDto Progress { get; set; }

        public XsdValidationResultDto Result { get; set; }

        /// <summary>The result of a streamed project creation (POST /api/projects/analyze).</summary>
        public FrpProjectDto Project { get; set; }

        /// <summary>The result of a streamed file replacement (POST /api/projects/{id}/files).</summary>
        public ProjectEditResultDto Edit { get; set; }

        public string Message { get; set; }

        /// <summary>For errors: the HTTP status the request would have had (400, 403, 404, 409, 500).</summary>
        public int Status { get; set; }

        public bool Equals(ValidationStreamEventDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Type, other.Type)
    && EqualityComparer<ValidationProgressDto>.Default.Equals(Progress, other.Progress)
    && EqualityComparer<XsdValidationResultDto>.Default.Equals(Result, other.Result)
    && EqualityComparer<FrpProjectDto>.Default.Equals(Project, other.Project)
    && EqualityComparer<ProjectEditResultDto>.Default.Equals(Edit, other.Edit)
    && EqualityComparer<string>.Default.Equals(Message, other.Message)
    && EqualityComparer<int>.Default.Equals(Status, other.Status);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ValidationStreamEventDto);
    }

        public static bool operator ==(ValidationStreamEventDto left, ValidationStreamEventDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ValidationStreamEventDto left, ValidationStreamEventDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 47185;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Type);
    hash = hash * -1521134295 + EqualityComparer<ValidationProgressDto>.Default.GetHashCode(Progress);
    hash = hash * -1521134295 + EqualityComparer<XsdValidationResultDto>.Default.GetHashCode(Result);
    hash = hash * -1521134295 + EqualityComparer<FrpProjectDto>.Default.GetHashCode(Project);
    hash = hash * -1521134295 + EqualityComparer<ProjectEditResultDto>.Default.GetHashCode(Edit);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Message);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Status);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ValidationStreamEventDto { " + "Type = " + Type + ", " + "Progress = " + Progress + ", " + "Result = " + Result + ", " + "Project = " + Project + ", " + "Edit = " + Edit + ", " + "Message = " + Message + ", " + "Status = " + Status + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ValidationStreamEventDto CloneRecord()
    {
    return (ValidationStreamEventDto)MemberwiseClone();
    }

    }

    /// <summary>The account code on each row of a project's Excel input template: sheet name, then row number.</summary>
    public sealed class TemplateAccountCodesDto : IRecord<TemplateAccountCodesDto>, IEquatable<TemplateAccountCodesDto>
    {
        public IReadOnlyDictionary<string, IReadOnlyDictionary<int, string>> Sheets { get; set; } = new Dictionary<string, IReadOnlyDictionary<int, string>>();


        /// <summary>The account code on the row of <paramref name="cellAddress"/> (e.g. E9), or null.</summary>
        public string For(string sheetName, string cellAddress)
        {
            IReadOnlyDictionary<int, string> rows;
            if (string.IsNullOrEmpty(sheetName) || string.IsNullOrEmpty(cellAddress) || !Sheets.TryGetValue(sheetName, out rows))
            {
                return null;
            }

            int row;
            string code;
            return int.TryParse(string.Concat(cellAddress.SkipWhile(char.IsLetter)), out row) && rows.TryGetValue(row, out code) ? code : null;
        }

        public bool Equals(TemplateAccountCodesDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyDictionary<string, IReadOnlyDictionary<int, string>>>.Default.Equals(Sheets, other.Sheets);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as TemplateAccountCodesDto);
    }

        public static bool operator ==(TemplateAccountCodesDto left, TemplateAccountCodesDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(TemplateAccountCodesDto left, TemplateAccountCodesDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 26267;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyDictionary<string, IReadOnlyDictionary<int, string>>>.Default.GetHashCode(Sheets);
    return hash;
    }
    }

        public override string ToString()
    {
    return "TemplateAccountCodesDto { " + "Sheets = " + Sheets + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public TemplateAccountCodesDto CloneRecord()
    {
    return (TemplateAccountCodesDto)MemberwiseClone();
    }

    }

    /// <summary>Which values an export contains.</summary>
    public enum ExportValues
    {
        /// <summary>The project's mapped values (edited values, otherwise XSD sample values).</summary>
        Mapped,
        /// <summary>Generated XSD sample values for every field.</summary>
        Sample,
        /// <summary>Template only: XML map bindings with empty input cells.</summary>
        Blank
    }

    /// <summary>Result of checking which XSD elements an Excel workbook's XML map binds.</summary>
    public sealed class TemplateCoverageDto : IRecord<TemplateCoverageDto>, IEquatable<TemplateCoverageDto>
    {
        public string FileName { get; set; } = "";

        public bool XmlMapFound { get; set; }

        public string MapRootElement { get; set; }

        public bool MatchesXsd { get; set; }

        /// <summary>True when every XSD field Excel can bind is bound and no binding is invalid.</summary>
        public bool IsComplete { get; set; }

        public int TotalFields { get; set; }

        public int BoundSingleCells { get; set; }

        public int BoundListColumns { get; set; }

        public int Unbound { get; set; }

        /// <summary>Fields inside a list that is itself inside a list; Excel XML maps cannot bind these.</summary>
        public int NotBindableInExcel { get; set; }

        /// <summary>
        /// Fields of forms the BSP specification says are not submitted with the sample's Header values; the
        /// "XSD sample values" template leaves them unbound so Excel's XML export leaves those forms out.
        /// </summary>
        public int LeftOutBySpecification { get; set; }

        public IReadOnlyList<string> LeftOutForms { get; set; } = new List<string>();

        public IReadOnlyList<TemplateSheetCoverageDto> Sheets { get; set; } = new List<TemplateSheetCoverageDto>();

        public IReadOnlyList<TemplateUnboundFieldDto> UnboundFields { get; set; } = new List<TemplateUnboundFieldDto>();

        public IReadOnlyList<string> Problems { get; set; } = new List<string>();

        public bool Equals(TemplateCoverageDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(FileName, other.FileName)
    && EqualityComparer<bool>.Default.Equals(XmlMapFound, other.XmlMapFound)
    && EqualityComparer<string>.Default.Equals(MapRootElement, other.MapRootElement)
    && EqualityComparer<bool>.Default.Equals(MatchesXsd, other.MatchesXsd)
    && EqualityComparer<bool>.Default.Equals(IsComplete, other.IsComplete)
    && EqualityComparer<int>.Default.Equals(TotalFields, other.TotalFields)
    && EqualityComparer<int>.Default.Equals(BoundSingleCells, other.BoundSingleCells)
    && EqualityComparer<int>.Default.Equals(BoundListColumns, other.BoundListColumns)
    && EqualityComparer<int>.Default.Equals(Unbound, other.Unbound)
    && EqualityComparer<int>.Default.Equals(NotBindableInExcel, other.NotBindableInExcel)
    && EqualityComparer<int>.Default.Equals(LeftOutBySpecification, other.LeftOutBySpecification)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(LeftOutForms, other.LeftOutForms)
    && EqualityComparer<IReadOnlyList<TemplateSheetCoverageDto>>.Default.Equals(Sheets, other.Sheets)
    && EqualityComparer<IReadOnlyList<TemplateUnboundFieldDto>>.Default.Equals(UnboundFields, other.UnboundFields)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Problems, other.Problems);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as TemplateCoverageDto);
    }

        public static bool operator ==(TemplateCoverageDto left, TemplateCoverageDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(TemplateCoverageDto left, TemplateCoverageDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 56076;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(FileName);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(XmlMapFound);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(MapRootElement);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(MatchesXsd);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsComplete);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(TotalFields);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(BoundSingleCells);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(BoundListColumns);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Unbound);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(NotBindableInExcel);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(LeftOutBySpecification);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(LeftOutForms);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<TemplateSheetCoverageDto>>.Default.GetHashCode(Sheets);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<TemplateUnboundFieldDto>>.Default.GetHashCode(UnboundFields);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Problems);
    return hash;
    }
    }

        public override string ToString()
    {
    return "TemplateCoverageDto { " + "FileName = " + FileName + ", " + "XmlMapFound = " + XmlMapFound + ", " + "MapRootElement = " + MapRootElement + ", " + "MatchesXsd = " + MatchesXsd + ", " + "IsComplete = " + IsComplete + ", " + "TotalFields = " + TotalFields + ", " + "BoundSingleCells = " + BoundSingleCells + ", " + "BoundListColumns = " + BoundListColumns + ", " + "Unbound = " + Unbound + ", " + "NotBindableInExcel = " + NotBindableInExcel + ", " + "LeftOutBySpecification = " + LeftOutBySpecification + ", " + "LeftOutForms = " + LeftOutForms + ", " + "Sheets = " + Sheets + ", " + "UnboundFields = " + UnboundFields + ", " + "Problems = " + Problems + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public TemplateCoverageDto CloneRecord()
    {
    return (TemplateCoverageDto)MemberwiseClone();
    }

    }

    public sealed class TemplateSheetCoverageDto : IRecord<TemplateSheetCoverageDto>, IEquatable<TemplateSheetCoverageDto>
    {
        public string XsdSheet { get; set; } = "";

        public int Total { get; set; }

        public int Bound { get; set; }

        public int Unbound { get; set; }

        public int NotBindableInExcel { get; set; }

        public bool Equals(TemplateSheetCoverageDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(XsdSheet, other.XsdSheet)
    && EqualityComparer<int>.Default.Equals(Total, other.Total)
    && EqualityComparer<int>.Default.Equals(Bound, other.Bound)
    && EqualityComparer<int>.Default.Equals(Unbound, other.Unbound)
    && EqualityComparer<int>.Default.Equals(NotBindableInExcel, other.NotBindableInExcel);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as TemplateSheetCoverageDto);
    }

        public static bool operator ==(TemplateSheetCoverageDto left, TemplateSheetCoverageDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(TemplateSheetCoverageDto left, TemplateSheetCoverageDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 65213;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(XsdSheet);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Total);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Bound);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Unbound);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(NotBindableInExcel);
    return hash;
    }
    }

        public override string ToString()
    {
    return "TemplateSheetCoverageDto { " + "XsdSheet = " + XsdSheet + ", " + "Total = " + Total + ", " + "Bound = " + Bound + ", " + "Unbound = " + Unbound + ", " + "NotBindableInExcel = " + NotBindableInExcel + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public TemplateSheetCoverageDto CloneRecord()
    {
    return (TemplateSheetCoverageDto)MemberwiseClone();
    }

    }

    public sealed class TemplateUnboundFieldDto : IRecord<TemplateUnboundFieldDto>, IEquatable<TemplateUnboundFieldDto>
    {
        public string SchemaPath { get; set; } = "";

        public string Reason { get; set; } = "";

        public bool Equals(TemplateUnboundFieldDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(SchemaPath, other.SchemaPath)
    && EqualityComparer<string>.Default.Equals(Reason, other.Reason);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as TemplateUnboundFieldDto);
    }

        public static bool operator ==(TemplateUnboundFieldDto left, TemplateUnboundFieldDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(TemplateUnboundFieldDto left, TemplateUnboundFieldDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SchemaPath);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Reason);
    return hash;
    }
    }

        public override string ToString()
    {
    return "TemplateUnboundFieldDto { " + "SchemaPath = " + SchemaPath + ", " + "Reason = " + Reason + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public TemplateUnboundFieldDto CloneRecord()
    {
    return (TemplateUnboundFieldDto)MemberwiseClone();
    }

    }

}
