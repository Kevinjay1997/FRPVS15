﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Shared.Models
{
    /// <summary>What a maintenance report row is about.</summary>
    public static class ReportCategories
    {
        public const string Users = "Users";
        public const string Roles = "Roles";
        public const string DirectoryGroups = "AD groups";
        public const string BankProfiles = "Bank profiles";
    }

    /// <summary>
    /// One changed field of one maintenance change (Application Security Checklist, Reports): the ID and name, when it
    /// was created and last modified, the field with its original and new value, who processed it (Maker) and who
    /// approved it (Checker).
    /// </summary>
    public sealed class MaintenanceRowDto : IRecord<MaintenanceRowDto>, IEquatable<MaintenanceRowDto>
    {
        public string Category { get; set; } = "";

        /// <summary>User ID, group (role) ID or bank key.</summary>
        public string TargetId { get; set; } = "";

        public string TargetName { get; set; }

        public DateTimeOffset? CreatedAt { get; set; }

        public DateTimeOffset? LastModifiedAt { get; set; }

        public string Field { get; set; } = "";

        public string Before { get; set; } = "";

        public string After { get; set; } = "";

        /// <summary>Approved, Rejected or Cancelled.</summary>
        public string Status { get; set; } = "";

        public string Maker { get; set; } = "";

        public DateTimeOffset RequestedAt { get; set; }

        public string Approver { get; set; }

        public DateTimeOffset? DecidedAt { get; set; }

        public string Comment { get; set; }

        public bool Equals(MaintenanceRowDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Category, other.Category)
    && EqualityComparer<string>.Default.Equals(TargetId, other.TargetId)
    && EqualityComparer<string>.Default.Equals(TargetName, other.TargetName)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(CreatedAt, other.CreatedAt)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(LastModifiedAt, other.LastModifiedAt)
    && EqualityComparer<string>.Default.Equals(Field, other.Field)
    && EqualityComparer<string>.Default.Equals(Before, other.Before)
    && EqualityComparer<string>.Default.Equals(After, other.After)
    && EqualityComparer<string>.Default.Equals(Status, other.Status)
    && EqualityComparer<string>.Default.Equals(Maker, other.Maker)
    && EqualityComparer<DateTimeOffset>.Default.Equals(RequestedAt, other.RequestedAt)
    && EqualityComparer<string>.Default.Equals(Approver, other.Approver)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(DecidedAt, other.DecidedAt)
    && EqualityComparer<string>.Default.Equals(Comment, other.Comment);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as MaintenanceRowDto);
    }

        public static bool operator ==(MaintenanceRowDto left, MaintenanceRowDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(MaintenanceRowDto left, MaintenanceRowDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 70489;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Category);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(TargetId);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(TargetName);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(CreatedAt);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(LastModifiedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Field);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Before);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(After);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Status);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Maker);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(RequestedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Approver);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(DecidedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Comment);
    return hash;
    }
    }

        public override string ToString()
    {
    return "MaintenanceRowDto { " + "Category = " + Category + ", " + "TargetId = " + TargetId + ", " + "TargetName = " + TargetName + ", " + "CreatedAt = " + CreatedAt + ", " + "LastModifiedAt = " + LastModifiedAt + ", " + "Field = " + Field + ", " + "Before = " + Before + ", " + "After = " + After + ", " + "Status = " + Status + ", " + "Maker = " + Maker + ", " + "RequestedAt = " + RequestedAt + ", " + "Approver = " + Approver + ", " + "DecidedAt = " + DecidedAt + ", " + "Comment = " + Comment + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public MaintenanceRowDto CloneRecord()
    {
    return (MaintenanceRowDto)MemberwiseClone();
    }

    }

    public sealed class MaintenanceReportDto : IRecord<MaintenanceReportDto>, IEquatable<MaintenanceReportDto>
    {
        public DateOnly From { get; set; }

        public DateOnly To { get; set; }

        public DateTimeOffset GeneratedAt { get; set; }

        public string GeneratedBy { get; set; } = "";

        /// <summary>The categories this person may see (the rows are limited to them).</summary>
        public IReadOnlyList<string> Categories { get; set; } = new List<string>();

        public IReadOnlyList<MaintenanceRowDto> Rows { get; set; } = new List<MaintenanceRowDto>();

        public bool Equals(MaintenanceReportDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<DateOnly>.Default.Equals(From, other.From)
    && EqualityComparer<DateOnly>.Default.Equals(To, other.To)
    && EqualityComparer<DateTimeOffset>.Default.Equals(GeneratedAt, other.GeneratedAt)
    && EqualityComparer<string>.Default.Equals(GeneratedBy, other.GeneratedBy)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Categories, other.Categories)
    && EqualityComparer<IReadOnlyList<MaintenanceRowDto>>.Default.Equals(Rows, other.Rows);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as MaintenanceReportDto);
    }

        public static bool operator ==(MaintenanceReportDto left, MaintenanceReportDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(MaintenanceReportDto left, MaintenanceReportDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 58409;
    hash = hash * -1521134295 + EqualityComparer<DateOnly>.Default.GetHashCode(From);
    hash = hash * -1521134295 + EqualityComparer<DateOnly>.Default.GetHashCode(To);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(GeneratedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(GeneratedBy);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Categories);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<MaintenanceRowDto>>.Default.GetHashCode(Rows);
    return hash;
    }
    }

        public override string ToString()
    {
    return "MaintenanceReportDto { " + "From = " + From + ", " + "To = " + To + ", " + "GeneratedAt = " + GeneratedAt + ", " + "GeneratedBy = " + GeneratedBy + ", " + "Categories = " + Categories + ", " + "Rows = " + Rows + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public MaintenanceReportDto CloneRecord()
    {
    return (MaintenanceReportDto)MemberwiseClone();
    }

    }

    /// <summary>One account in the user extraction report.</summary>
    public sealed class UserExtractionRowDto : IRecord<UserExtractionRowDto>, IEquatable<UserExtractionRowDto>
    {
        public string UserId { get; set; } = "";

        public string UserName { get; set; }

        /// <summary>Profile / group access: the roles given in the app, or (for people only in AD groups) those of their last sign-in.</summary>
        public string Roles { get; set; } = "";

        public string Department { get; set; }

        public DateTimeOffset? CreatedAt { get; set; }

        /// <summary>Active, Disabled, Locked, Deactivated (inactivity), Access ended or Deleted.</summary>
        public string Status { get; set; } = "";

        public DateTimeOffset? LastModifiedAt { get; set; }

        public DateOnly? AccessUntil { get; set; }

        public DateTimeOffset? LastSignInAt { get; set; }

        /// <summary>"App list" (maintained by SRAU) or "AD groups only".</summary>
        public string Source { get; set; } = "";

        public bool Equals(UserExtractionRowDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserId, other.UserId)
    && EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<string>.Default.Equals(Roles, other.Roles)
    && EqualityComparer<string>.Default.Equals(Department, other.Department)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(CreatedAt, other.CreatedAt)
    && EqualityComparer<string>.Default.Equals(Status, other.Status)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(LastModifiedAt, other.LastModifiedAt)
    && EqualityComparer<DateOnly?>.Default.Equals(AccessUntil, other.AccessUntil)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(LastSignInAt, other.LastSignInAt)
    && EqualityComparer<string>.Default.Equals(Source, other.Source);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as UserExtractionRowDto);
    }

        public static bool operator ==(UserExtractionRowDto left, UserExtractionRowDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(UserExtractionRowDto left, UserExtractionRowDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 58504;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserId);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Roles);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Department);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(CreatedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Status);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(LastModifiedAt);
    hash = hash * -1521134295 + EqualityComparer<DateOnly?>.Default.GetHashCode(AccessUntil);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(LastSignInAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Source);
    return hash;
    }
    }

        public override string ToString()
    {
    return "UserExtractionRowDto { " + "UserId = " + UserId + ", " + "UserName = " + UserName + ", " + "Roles = " + Roles + ", " + "Department = " + Department + ", " + "CreatedAt = " + CreatedAt + ", " + "Status = " + Status + ", " + "LastModifiedAt = " + LastModifiedAt + ", " + "AccessUntil = " + AccessUntil + ", " + "LastSignInAt = " + LastSignInAt + ", " + "Source = " + Source + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public UserExtractionRowDto CloneRecord()
    {
    return (UserExtractionRowDto)MemberwiseClone();
    }

    }

    public sealed class UserExtractionReportDto : IRecord<UserExtractionReportDto>, IEquatable<UserExtractionReportDto>
    {
        public DateTimeOffset GeneratedAt { get; set; }

        public string GeneratedBy { get; set; } = "";

        public IReadOnlyList<UserExtractionRowDto> Rows { get; set; } = new List<UserExtractionRowDto>();

        public bool Equals(UserExtractionReportDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<DateTimeOffset>.Default.Equals(GeneratedAt, other.GeneratedAt)
    && EqualityComparer<string>.Default.Equals(GeneratedBy, other.GeneratedBy)
    && EqualityComparer<IReadOnlyList<UserExtractionRowDto>>.Default.Equals(Rows, other.Rows);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as UserExtractionReportDto);
    }

        public static bool operator ==(UserExtractionReportDto left, UserExtractionReportDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(UserExtractionReportDto left, UserExtractionReportDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 67784;
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(GeneratedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(GeneratedBy);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<UserExtractionRowDto>>.Default.GetHashCode(Rows);
    return hash;
    }
    }

        public override string ToString()
    {
    return "UserExtractionReportDto { " + "GeneratedAt = " + GeneratedAt + ", " + "GeneratedBy = " + GeneratedBy + ", " + "Rows = " + Rows + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public UserExtractionReportDto CloneRecord()
    {
    return (UserExtractionReportDto)MemberwiseClone();
    }

    }

    /// <summary>Sign-in attempts for review of patterns and trends of unsuccessful sign-ins.</summary>
    public sealed class SignInReportDto : IRecord<SignInReportDto>, IEquatable<SignInReportDto>
    {
        public DateOnly From { get; set; }

        public DateOnly To { get; set; }

        public DateTimeOffset GeneratedAt { get; set; }

        public string GeneratedBy { get; set; } = "";

        public IReadOnlyList<SignInSummaryDto> Summary { get; set; } = new List<SignInSummaryDto>();

        public IReadOnlyList<AuditEntryDto> Entries { get; set; } = new List<AuditEntryDto>();

        /// <summary>True when there were more attempts than shown (narrow the range or choose a person).</summary>
        public bool Truncated { get; set; }

        public bool Equals(SignInReportDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<DateOnly>.Default.Equals(From, other.From)
    && EqualityComparer<DateOnly>.Default.Equals(To, other.To)
    && EqualityComparer<DateTimeOffset>.Default.Equals(GeneratedAt, other.GeneratedAt)
    && EqualityComparer<string>.Default.Equals(GeneratedBy, other.GeneratedBy)
    && EqualityComparer<IReadOnlyList<SignInSummaryDto>>.Default.Equals(Summary, other.Summary)
    && EqualityComparer<IReadOnlyList<AuditEntryDto>>.Default.Equals(Entries, other.Entries)
    && EqualityComparer<bool>.Default.Equals(Truncated, other.Truncated);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SignInReportDto);
    }

        public static bool operator ==(SignInReportDto left, SignInReportDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SignInReportDto left, SignInReportDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 53544;
    hash = hash * -1521134295 + EqualityComparer<DateOnly>.Default.GetHashCode(From);
    hash = hash * -1521134295 + EqualityComparer<DateOnly>.Default.GetHashCode(To);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(GeneratedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(GeneratedBy);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SignInSummaryDto>>.Default.GetHashCode(Summary);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<AuditEntryDto>>.Default.GetHashCode(Entries);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Truncated);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SignInReportDto { " + "From = " + From + ", " + "To = " + To + ", " + "GeneratedAt = " + GeneratedAt + ", " + "GeneratedBy = " + GeneratedBy + ", " + "Summary = " + Summary + ", " + "Entries = " + Entries + ", " + "Truncated = " + Truncated + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SignInReportDto CloneRecord()
    {
    return (SignInReportDto)MemberwiseClone();
    }

    }

    public sealed class SignInSummaryDto : IRecord<SignInSummaryDto>, IEquatable<SignInSummaryDto>
    {
        public string UserName { get; set; } = "";

        public int SignedIn { get; set; }

        public int Failed { get; set; }

        public int Blocked { get; set; }

        public int Refused { get; set; }

        public int Locked { get; set; }

        public DateTimeOffset? LastFailedAt { get; set; }

        /// <summary>The addresses failed attempts came from.</summary>
        public IReadOnlyList<string> FailedFrom { get; set; } = new List<string>();

        public bool Equals(SignInSummaryDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<int>.Default.Equals(SignedIn, other.SignedIn)
    && EqualityComparer<int>.Default.Equals(Failed, other.Failed)
    && EqualityComparer<int>.Default.Equals(Blocked, other.Blocked)
    && EqualityComparer<int>.Default.Equals(Refused, other.Refused)
    && EqualityComparer<int>.Default.Equals(Locked, other.Locked)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(LastFailedAt, other.LastFailedAt)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(FailedFrom, other.FailedFrom);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SignInSummaryDto);
    }

        public static bool operator ==(SignInSummaryDto left, SignInSummaryDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SignInSummaryDto left, SignInSummaryDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 49452;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SignedIn);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Failed);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Blocked);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Refused);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Locked);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(LastFailedAt);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(FailedFrom);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SignInSummaryDto { " + "UserName = " + UserName + ", " + "SignedIn = " + SignedIn + ", " + "Failed = " + Failed + ", " + "Blocked = " + Blocked + ", " + "Refused = " + Refused + ", " + "Locked = " + Locked + ", " + "LastFailedAt = " + LastFailedAt + ", " + "FailedFrom = " + FailedFrom + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SignInSummaryDto CloneRecord()
    {
    return (SignInSummaryDto)MemberwiseClone();
    }

    }

}
