﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Json;

namespace FrpMapper.Shared.Models
{
    [JsonConverter(typeof(JsonStringEnumConverter<ProjectStatus>))]
    public enum ProjectStatus
    {
        /// <summary>Being prepared by a Maker; mappings and the submission file can change.</summary>
        Draft,
        /// <summary>Submitted by a Maker; frozen until a Checker approves or returns it, or the Maker withdraws it.</summary>
        InReview,
        /// <summary>Returned by a Checker with a comment; the Maker corrects it and submits again.</summary>
        Returned,
        /// <summary>Approved by a Checker; the approved submission file can be downloaded. Reopening voids the approval.</summary>
        Approved
    }

    public sealed class ProjectWorkflowDto : IRecord<ProjectWorkflowDto>, IEquatable<ProjectWorkflowDto>
    {
        public ProjectStatus Status { get; set; } = ProjectStatus.Draft;

        public string CreatedBy { get; set; } = "";

        public DateTimeOffset? CreatedAt { get; set; }

        public string LastModifiedBy { get; set; }

        public DateTimeOffset? LastModifiedAt { get; set; }

        /// <summary>Everyone who created, edited, attached a file to or submitted the project; none of them may review it.</summary>
        public IReadOnlyList<string> Contributors { get; set; } = new List<string>();


        /// <summary>The file under review / approved: an uploaded XML (e.g. exported from Excel) or XML generated from the project's values.</summary>
        public SubmissionFileDto Submission { get; set; }


        public string SubmittedBy { get; set; }

        public DateTimeOffset? SubmittedAt { get; set; }

        public string SubmissionComment { get; set; }


        public string ReviewedBy { get; set; }

        public DateTimeOffset? ReviewedAt { get; set; }

        public string ReviewComment { get; set; }

        public bool Equals(ProjectWorkflowDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<ProjectStatus>.Default.Equals(Status, other.Status)
    && EqualityComparer<string>.Default.Equals(CreatedBy, other.CreatedBy)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(CreatedAt, other.CreatedAt)
    && EqualityComparer<string>.Default.Equals(LastModifiedBy, other.LastModifiedBy)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(LastModifiedAt, other.LastModifiedAt)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Contributors, other.Contributors)
    && EqualityComparer<SubmissionFileDto>.Default.Equals(Submission, other.Submission)
    && EqualityComparer<string>.Default.Equals(SubmittedBy, other.SubmittedBy)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(SubmittedAt, other.SubmittedAt)
    && EqualityComparer<string>.Default.Equals(SubmissionComment, other.SubmissionComment)
    && EqualityComparer<string>.Default.Equals(ReviewedBy, other.ReviewedBy)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(ReviewedAt, other.ReviewedAt)
    && EqualityComparer<string>.Default.Equals(ReviewComment, other.ReviewComment);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ProjectWorkflowDto);
    }

        public static bool operator ==(ProjectWorkflowDto left, ProjectWorkflowDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ProjectWorkflowDto left, ProjectWorkflowDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 84040;
    hash = hash * -1521134295 + EqualityComparer<ProjectStatus>.Default.GetHashCode(Status);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(CreatedBy);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(CreatedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(LastModifiedBy);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(LastModifiedAt);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Contributors);
    hash = hash * -1521134295 + EqualityComparer<SubmissionFileDto>.Default.GetHashCode(Submission);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SubmittedBy);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(SubmittedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SubmissionComment);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ReviewedBy);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(ReviewedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ReviewComment);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ProjectWorkflowDto { " + "Status = " + Status + ", " + "CreatedBy = " + CreatedBy + ", " + "CreatedAt = " + CreatedAt + ", " + "LastModifiedBy = " + LastModifiedBy + ", " + "LastModifiedAt = " + LastModifiedAt + ", " + "Contributors = " + Contributors + ", " + "Submission = " + Submission + ", " + "SubmittedBy = " + SubmittedBy + ", " + "SubmittedAt = " + SubmittedAt + ", " + "SubmissionComment = " + SubmissionComment + ", " + "ReviewedBy = " + ReviewedBy + ", " + "ReviewedAt = " + ReviewedAt + ", " + "ReviewComment = " + ReviewComment + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ProjectWorkflowDto CloneRecord()
    {
    return (ProjectWorkflowDto)MemberwiseClone();
    }

    }

    public sealed class SubmissionFileDto : IRecord<SubmissionFileDto>, IEquatable<SubmissionFileDto>
    {
        public string FileName { get; set; } = "";

        public string StoredPath { get; set; } = "";

        public long Size { get; set; }

        /// <summary>SHA-256 of the file; the approval applies to exactly these bytes.</summary>
        public string Sha256 { get; set; } = "";

        /// <summary>"Uploaded" or "Generated".</summary>
        public string Source { get; set; } = "";

        public string AttachedBy { get; set; } = "";

        public DateTimeOffset AttachedAt { get; set; }

        public bool XsdValid { get; set; }

        public int XsdErrors { get; set; }

        public bool SpecificationChecked { get; set; }

        public int SpecRulesPassed { get; set; }

        public int SpecRulesFailed { get; set; }

        public bool Equals(SubmissionFileDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(FileName, other.FileName)
    && EqualityComparer<string>.Default.Equals(StoredPath, other.StoredPath)
    && EqualityComparer<long>.Default.Equals(Size, other.Size)
    && EqualityComparer<string>.Default.Equals(Sha256, other.Sha256)
    && EqualityComparer<string>.Default.Equals(Source, other.Source)
    && EqualityComparer<string>.Default.Equals(AttachedBy, other.AttachedBy)
    && EqualityComparer<DateTimeOffset>.Default.Equals(AttachedAt, other.AttachedAt)
    && EqualityComparer<bool>.Default.Equals(XsdValid, other.XsdValid)
    && EqualityComparer<int>.Default.Equals(XsdErrors, other.XsdErrors)
    && EqualityComparer<bool>.Default.Equals(SpecificationChecked, other.SpecificationChecked)
    && EqualityComparer<int>.Default.Equals(SpecRulesPassed, other.SpecRulesPassed)
    && EqualityComparer<int>.Default.Equals(SpecRulesFailed, other.SpecRulesFailed);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SubmissionFileDto);
    }

        public static bool operator ==(SubmissionFileDto left, SubmissionFileDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SubmissionFileDto left, SubmissionFileDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 6278;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(FileName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(StoredPath);
    hash = hash * -1521134295 + EqualityComparer<long>.Default.GetHashCode(Size);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Sha256);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Source);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(AttachedBy);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(AttachedAt);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(XsdValid);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(XsdErrors);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(SpecificationChecked);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SpecRulesPassed);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SpecRulesFailed);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SubmissionFileDto { " + "FileName = " + FileName + ", " + "StoredPath = " + StoredPath + ", " + "Size = " + Size + ", " + "Sha256 = " + Sha256 + ", " + "Source = " + Source + ", " + "AttachedBy = " + AttachedBy + ", " + "AttachedAt = " + AttachedAt + ", " + "XsdValid = " + XsdValid + ", " + "XsdErrors = " + XsdErrors + ", " + "SpecificationChecked = " + SpecificationChecked + ", " + "SpecRulesPassed = " + SpecRulesPassed + ", " + "SpecRulesFailed = " + SpecRulesFailed + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SubmissionFileDto CloneRecord()
    {
    return (SubmissionFileDto)MemberwiseClone();
    }

    }

    public sealed class AuditEntryDto : IRecord<AuditEntryDto>, IEquatable<AuditEntryDto>
    {
        public string Id { get; set; } = "";

        public DateTimeOffset At { get; set; }

        public string User { get; set; } = "";

        public string Action { get; set; } = "";

        public string ProjectId { get; set; }

        public string ProjectName { get; set; }

        public string Details { get; set; }

        /// <summary>The network address the person worked from (null for entries recorded before it was kept).</summary>
        public string Address { get; set; }

        public bool Equals(AuditEntryDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Id, other.Id)
    && EqualityComparer<DateTimeOffset>.Default.Equals(At, other.At)
    && EqualityComparer<string>.Default.Equals(User, other.User)
    && EqualityComparer<string>.Default.Equals(Action, other.Action)
    && EqualityComparer<string>.Default.Equals(ProjectId, other.ProjectId)
    && EqualityComparer<string>.Default.Equals(ProjectName, other.ProjectName)
    && EqualityComparer<string>.Default.Equals(Details, other.Details)
    && EqualityComparer<string>.Default.Equals(Address, other.Address);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AuditEntryDto);
    }

        public static bool operator ==(AuditEntryDto left, AuditEntryDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AuditEntryDto left, AuditEntryDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 32023;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Id);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(At);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(User);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Action);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ProjectId);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ProjectName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Details);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Address);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AuditEntryDto { " + "Id = " + Id + ", " + "At = " + At + ", " + "User = " + User + ", " + "Action = " + Action + ", " + "ProjectId = " + ProjectId + ", " + "ProjectName = " + ProjectName + ", " + "Details = " + Details + ", " + "Address = " + Address + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AuditEntryDto CloneRecord()
    {
    return (AuditEntryDto)MemberwiseClone();
    }

    }

    /// <summary>
    /// The files a new project would be created from, to find projects that already use them: the SHA-256 of each new
    /// file, or the reuse flags for files taken from <see cref="SourceProjectId"/>.
    /// </summary>
    public sealed class ProjectFilesCheckRequest : IRecord<ProjectFilesCheckRequest>, IEquatable<ProjectFilesCheckRequest>
    {
        public string XsdSha256 { get; set; }

        public string TemplateSha256 { get; set; }

        public string SpecificationSha256 { get; set; }

        public string SourceProjectId { get; set; }

        public bool ReuseXsd { get; set; }

        public bool ReuseTemplate { get; set; }

        public bool ReuseSpecification { get; set; }

        public bool Equals(ProjectFilesCheckRequest other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(XsdSha256, other.XsdSha256)
    && EqualityComparer<string>.Default.Equals(TemplateSha256, other.TemplateSha256)
    && EqualityComparer<string>.Default.Equals(SpecificationSha256, other.SpecificationSha256)
    && EqualityComparer<string>.Default.Equals(SourceProjectId, other.SourceProjectId)
    && EqualityComparer<bool>.Default.Equals(ReuseXsd, other.ReuseXsd)
    && EqualityComparer<bool>.Default.Equals(ReuseTemplate, other.ReuseTemplate)
    && EqualityComparer<bool>.Default.Equals(ReuseSpecification, other.ReuseSpecification);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ProjectFilesCheckRequest);
    }

        public static bool operator ==(ProjectFilesCheckRequest left, ProjectFilesCheckRequest right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ProjectFilesCheckRequest left, ProjectFilesCheckRequest right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 21686;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(XsdSha256);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(TemplateSha256);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SpecificationSha256);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SourceProjectId);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(ReuseXsd);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(ReuseTemplate);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(ReuseSpecification);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ProjectFilesCheckRequest { " + "XsdSha256 = " + XsdSha256 + ", " + "TemplateSha256 = " + TemplateSha256 + ", " + "SpecificationSha256 = " + SpecificationSha256 + ", " + "SourceProjectId = " + SourceProjectId + ", " + "ReuseXsd = " + ReuseXsd + ", " + "ReuseTemplate = " + ReuseTemplate + ", " + "ReuseSpecification = " + ReuseSpecification + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ProjectFilesCheckRequest CloneRecord()
    {
    return (ProjectFilesCheckRequest)MemberwiseClone();
    }

    }

    public sealed class ProjectSummaryDto : IRecord<ProjectSummaryDto>, IEquatable<ProjectSummaryDto>
    {
        public string Id { get; set; } = "";

        public string Name { get; set; } = "";

        public string RootElement { get; set; }

        public ProjectStatus Status { get; set; }

        public string CreatedBy { get; set; } = "";

        public DateTimeOffset CreatedAt { get; set; }

        public DateTimeOffset UpdatedAt { get; set; }

        public string LastModifiedBy { get; set; }

        public string SubmittedBy { get; set; }

        public string ReviewedBy { get; set; }

        /// <summary>People who prepared or changed the project; they cannot review it.</summary>
        public IReadOnlyList<string> Contributors { get; set; } = new List<string>();

        public bool TemplateGenerated { get; set; }

        public bool HasSpecification { get; set; }

        public int MappingCount { get; set; }

        public bool? LastValidationValid { get; set; }

        public int LastValidationErrors { get; set; }

        public bool Equals(ProjectSummaryDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Id, other.Id)
    && EqualityComparer<string>.Default.Equals(Name, other.Name)
    && EqualityComparer<string>.Default.Equals(RootElement, other.RootElement)
    && EqualityComparer<ProjectStatus>.Default.Equals(Status, other.Status)
    && EqualityComparer<string>.Default.Equals(CreatedBy, other.CreatedBy)
    && EqualityComparer<DateTimeOffset>.Default.Equals(CreatedAt, other.CreatedAt)
    && EqualityComparer<DateTimeOffset>.Default.Equals(UpdatedAt, other.UpdatedAt)
    && EqualityComparer<string>.Default.Equals(LastModifiedBy, other.LastModifiedBy)
    && EqualityComparer<string>.Default.Equals(SubmittedBy, other.SubmittedBy)
    && EqualityComparer<string>.Default.Equals(ReviewedBy, other.ReviewedBy)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Contributors, other.Contributors)
    && EqualityComparer<bool>.Default.Equals(TemplateGenerated, other.TemplateGenerated)
    && EqualityComparer<bool>.Default.Equals(HasSpecification, other.HasSpecification)
    && EqualityComparer<int>.Default.Equals(MappingCount, other.MappingCount)
    && EqualityComparer<bool?>.Default.Equals(LastValidationValid, other.LastValidationValid)
    && EqualityComparer<int>.Default.Equals(LastValidationErrors, other.LastValidationErrors);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ProjectSummaryDto);
    }

        public static bool operator ==(ProjectSummaryDto left, ProjectSummaryDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ProjectSummaryDto left, ProjectSummaryDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 609;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Id);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(RootElement);
    hash = hash * -1521134295 + EqualityComparer<ProjectStatus>.Default.GetHashCode(Status);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(CreatedBy);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(CreatedAt);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(UpdatedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(LastModifiedBy);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SubmittedBy);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ReviewedBy);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Contributors);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(TemplateGenerated);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(HasSpecification);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(MappingCount);
    hash = hash * -1521134295 + EqualityComparer<bool?>.Default.GetHashCode(LastValidationValid);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(LastValidationErrors);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ProjectSummaryDto { " + "Id = " + Id + ", " + "Name = " + Name + ", " + "RootElement = " + RootElement + ", " + "Status = " + Status + ", " + "CreatedBy = " + CreatedBy + ", " + "CreatedAt = " + CreatedAt + ", " + "UpdatedAt = " + UpdatedAt + ", " + "LastModifiedBy = " + LastModifiedBy + ", " + "SubmittedBy = " + SubmittedBy + ", " + "ReviewedBy = " + ReviewedBy + ", " + "Contributors = " + Contributors + ", " + "TemplateGenerated = " + TemplateGenerated + ", " + "HasSpecification = " + HasSpecification + ", " + "MappingCount = " + MappingCount + ", " + "LastValidationValid = " + LastValidationValid + ", " + "LastValidationErrors = " + LastValidationErrors + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ProjectSummaryDto CloneRecord()
    {
    return (ProjectSummaryDto)MemberwiseClone();
    }

    }

    public sealed class WorkflowCommentRequest : IRecord<WorkflowCommentRequest>, IEquatable<WorkflowCommentRequest>
    {
        public string Comment { get; set; }

        public bool Equals(WorkflowCommentRequest other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Comment, other.Comment);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as WorkflowCommentRequest);
    }

        public static bool operator ==(WorkflowCommentRequest left, WorkflowCommentRequest right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(WorkflowCommentRequest left, WorkflowCommentRequest right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 4320;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Comment);
    return hash;
    }
    }

        public override string ToString()
    {
    return "WorkflowCommentRequest { " + "Comment = " + Comment + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public WorkflowCommentRequest CloneRecord()
    {
    return (WorkflowCommentRequest)MemberwiseClone();
    }

    }

    public sealed class CurrentUserDto : IRecord<CurrentUserDto>, IEquatable<CurrentUserDto>
    {
        public string Name { get; set; } = "";

        public IReadOnlyList<string> Roles { get; set; } = new List<string>();

        public IReadOnlyList<string> Permissions { get; set; } = new List<string>();

        public bool Equals(CurrentUserDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Name, other.Name)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Roles, other.Roles)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Permissions, other.Permissions);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as CurrentUserDto);
    }

        public static bool operator ==(CurrentUserDto left, CurrentUserDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(CurrentUserDto left, CurrentUserDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 17964;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Roles);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Permissions);
    return hash;
    }
    }

        public override string ToString()
    {
    return "CurrentUserDto { " + "Name = " + Name + ", " + "Roles = " + Roles + ", " + "Permissions = " + Permissions + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public CurrentUserDto CloneRecord()
    {
    return (CurrentUserDto)MemberwiseClone();
    }

    }

}
