using System;
using System.Collections.Generic;

namespace FrpMapper.Shared.Models
{
    // The configuration files the Regulatory Reports Workbench kept in its Config folder, kept by FRP Mapper as versions
    // that a Maker uploads and a different Checker approves (the same steps as a BSP environment): the COCREE
    // configuration and the XML tools' merge / cleanup / report period lists.

    /// <summary>Which configuration a version belongs to.</summary>
    public static class WorkbenchConfigKind
    {
        /// <summary>cocree_config.xlsx, cocree_dropdown_options.xlsx, cocree_validations.xlsx and BSP's COCREE XSD.</summary>
        public const string Cocree = "COCREE";

        /// <summary>merge.csv, cleanup.csv, reportperiod.csv and the rows the normalizer keeps.</summary>
        public const string XmlTools = "XML-TOOLS";
    }

    /// <summary>Where a configuration version is in its Maker / Checker life.</summary>
    public static class WorkbenchConfigStatus
    {
        public const string Pending = "Pending";
        public const string Active = "Active";
        public const string Replaced = "Replaced";
        public const string Rejected = "Rejected";
        public const string Cancelled = "Cancelled";
    }

    /// <summary>
    /// One sheet of a configuration file, kept exactly as it was uploaded: the column names of row 1 and every row after
    /// it, each cell as text (numbers as the Workbench read them, e.g. "1" or "102801000").
    /// </summary>
    public sealed class WorkbenchTableDto
    {
        public string Name { get; set; } = "";

        public List<string> Columns { get; set; } = new List<string>();

        public List<List<string>> Rows { get; set; } = new List<List<string>>();
    }

    /// <summary>A count shown with a version, e.g. 690 "XML attributes".</summary>
    public sealed class WorkbenchConfigFactDto
    {
        public string Label { get; set; } = "";

        public int Count { get; set; }
    }

    /// <summary>What a configuration holds, in numbers, and how it differs from the one in use (shown to the Checker).</summary>
    public sealed class WorkbenchConfigSummaryDto
    {
        public List<WorkbenchConfigFactDto> Facts { get; set; } = new List<WorkbenchConfigFactDto>();

        /// <summary>What the configuration has that is not used (rows without a sheet, mappings to nothing, …).</summary>
        public List<string> Notes { get; set; } = new List<string>();

        /// <summary>For a Pending version: what differs from the Active one, one line per sheet ("xml_mapping: 3 rows added").</summary>
        public List<string> Changes { get; set; } = new List<string>();
    }

    /// <summary>One version of a configuration (without its content).</summary>
    public sealed class WorkbenchConfigVersionDto
    {
        public string Id { get; set; } = "";

        /// <summary><see cref="WorkbenchConfigKind"/>.</summary>
        public string Kind { get; set; } = "";

        /// <summary><see cref="WorkbenchConfigStatus"/>.</summary>
        public string Status { get; set; } = "";

        /// <summary>The uploaded file names, e.g. "cocree_config.xlsx, cocree_dropdown_options.xlsx".</summary>
        public string SourceFiles { get; set; } = "";

        /// <summary>The Maker's note about the change.</summary>
        public string Note { get; set; }

        public WorkbenchConfigSummaryDto Summary { get; set; } = new WorkbenchConfigSummaryDto();

        /// <summary>SHA-256 of the stored content.</summary>
        public string ContentHash { get; set; } = "";

        public string RequestedBy { get; set; } = "";

        public DateTimeOffset RequestedAt { get; set; }

        public string DecidedBy { get; set; }

        public DateTimeOffset? DecidedAt { get; set; }

        public string DecisionComment { get; set; }

        /// <summary>Row version (base64) for the next decision.</summary>
        public string Version { get; set; } = "";
    }

    /// <summary>A Settings tab: every Pending and Active version and the latest decided ones.</summary>
    public sealed class WorkbenchSettingsDto
    {
        public List<WorkbenchConfigVersionDto> Versions { get; set; } = new List<WorkbenchConfigVersionDto>();
    }
}
