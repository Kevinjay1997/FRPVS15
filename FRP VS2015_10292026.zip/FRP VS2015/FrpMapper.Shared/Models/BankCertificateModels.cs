using System;

namespace FrpMapper.Shared.Models
{
    /// <summary>Where a BSP certificate is in its Maker / Checker life.</summary>
    public static class BankCertificateStatus
    {
        public const string Pending = "Pending";
        public const string Active = "Active";
        public const string Replaced = "Replaced";
        public const string Rejected = "Rejected";
        public const string Cancelled = "Cancelled";
        public const string Removed = "Removed";
    }

    /// <summary>
    /// A bank profile's BSP certificate as people see it. The PFX and its password are never part of it: they stay
    /// encrypted in the database and are opened on the API only to send a request to BSP.
    /// </summary>
    public sealed class BankCertificateDto
    {
        public string Id { get; set; } = "";

        public string BankKey { get; set; } = "";

        public string Status { get; set; } = "";

        public string FileName { get; set; } = "";

        public string Subject { get; set; } = "";

        public string Issuer { get; set; } = "";

        public string Thumbprint { get; set; } = "";

        /// <summary>UTC.</summary>
        public DateTime ValidFrom { get; set; }

        /// <summary>UTC.</summary>
        public DateTime ValidUntil { get; set; }

        public string RequestedBy { get; set; } = "";

        public DateTimeOffset RequestedAt { get; set; }

        public string DecidedBy { get; set; }

        public DateTimeOffset? DecidedAt { get; set; }

        public string DecisionComment { get; set; }

        /// <summary>The row version (base64), sent back with a decision so a stale page cannot decide.</summary>
        public string Version { get; set; } = "";
    }

    /// <summary>The stored certificate a bank's BSP requests use, as the submission page shows it.</summary>
    public sealed class SandboxStoredCertificateDto
    {
        public string Subject { get; set; } = "";

        public string Thumbprint { get; set; } = "";

        /// <summary>UTC, ISO 8601.</summary>
        public string ValidUntil { get; set; } = "";
    }
}
