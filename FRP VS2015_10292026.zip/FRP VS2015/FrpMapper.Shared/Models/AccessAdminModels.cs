﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Shared.Models
{
    /// <summary>
    /// Teams of access administration: SRAU (Users) and PARAM (Roles). A request's team is the requester's. In each team
    /// the Maker requests changes and the Checker approves or rejects them.
    /// </summary>
    public static class AccessTeams
    {
        public const string Users = "Users";
        public const string Roles = "Roles";

        public static string Name(string team) => team == Users ? "SRAU" : "PARAM";

        /// <summary>"an SRAU" or "a PARAM", for messages.</summary>
        public static string WithArticle(string team) => team == Users ? "an SRAU" : "a PARAM";

        /// <summary>The team's Maker permission: request changes.</summary>
        public static string RequestPermission(string team) => team == Users ? Permissions.UsersManage : Permissions.RolesManage;

        /// <summary>The team's Checker permission: approve or reject the Maker's requests.</summary>
        public static string ApprovePermission(string team) => team == Users ? Permissions.UsersApprove : Permissions.RolesApprove;
    }

    /// <summary>What a request changes: a person (SRAU), a role's definition and permissions (PARAM), or the Active
    /// Directory groups that grant a role (SRAU or PARAM).</summary>
    public static class AccessKinds
    {
        public const string User = "User";
        public const string Role = "Role";
        public const string Groups = "Groups";
    }

    public static class AccessRequestStatus
    {
        public const string Pending = "Pending";
        public const string Approved = "Approved";
        public const string Rejected = "Rejected";
        public const string Cancelled = "Cancelled";
    }

    /// <summary>Everything the access administration page shows: people, roles (including disabled ones) and requests.</summary>
    public sealed class AccessAdministrationDto : IRecord<AccessAdministrationDto>, IEquatable<AccessAdministrationDto>
    {
        public IReadOnlyList<AdminUserDto> Users { get; set; } = new List<AdminUserDto>();

        public IReadOnlyList<AdminRoleDto> Roles { get; set; } = new List<AdminRoleDto>();

        public IReadOnlyList<AppPermissionDto> Permissions { get; set; } = new List<AppPermissionDto>();

        public IReadOnlyList<AccessChangeRequestDto> Requests { get; set; } = new List<AccessChangeRequestDto>();

        /// <summary>People who signed in but are not in the list (their roles come only from their AD groups).</summary>
        public IReadOnlyList<SignInSeenDto> OtherSignIns { get; set; } = new List<SignInSeenDto>();

        /// <summary>Keys of deleted roles: a new role cannot use them.</summary>
        public IReadOnlyList<string> DeletedRoleKeys { get; set; } = new List<string>();

        public bool Equals(AccessAdministrationDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<AdminUserDto>>.Default.Equals(Users, other.Users)
    && EqualityComparer<IReadOnlyList<AdminRoleDto>>.Default.Equals(Roles, other.Roles)
    && EqualityComparer<IReadOnlyList<AppPermissionDto>>.Default.Equals(Permissions, other.Permissions)
    && EqualityComparer<IReadOnlyList<AccessChangeRequestDto>>.Default.Equals(Requests, other.Requests)
    && EqualityComparer<IReadOnlyList<SignInSeenDto>>.Default.Equals(OtherSignIns, other.OtherSignIns)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(DeletedRoleKeys, other.DeletedRoleKeys);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AccessAdministrationDto);
    }

        public static bool operator ==(AccessAdministrationDto left, AccessAdministrationDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AccessAdministrationDto left, AccessAdministrationDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 92876;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<AdminUserDto>>.Default.GetHashCode(Users);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<AdminRoleDto>>.Default.GetHashCode(Roles);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<AppPermissionDto>>.Default.GetHashCode(Permissions);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<AccessChangeRequestDto>>.Default.GetHashCode(Requests);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SignInSeenDto>>.Default.GetHashCode(OtherSignIns);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(DeletedRoleKeys);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AccessAdministrationDto { " + "Users = " + Users + ", " + "Roles = " + Roles + ", " + "Permissions = " + Permissions + ", " + "Requests = " + Requests + ", " + "OtherSignIns = " + OtherSignIns + ", " + "DeletedRoleKeys = " + DeletedRoleKeys + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AccessAdministrationDto CloneRecord()
    {
    return (AccessAdministrationDto)MemberwiseClone();
    }

    }

    public sealed class SignInSeenDto : IRecord<SignInSeenDto>, IEquatable<SignInSeenDto>
    {
        public string UserName { get; set; } = "";

        public DateTimeOffset LastSignInAt { get; set; }

        public bool Equals(SignInSeenDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<DateTimeOffset>.Default.Equals(LastSignInAt, other.LastSignInAt);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SignInSeenDto);
    }

        public static bool operator ==(SignInSeenDto left, SignInSeenDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SignInSeenDto left, SignInSeenDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 9489;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(LastSignInAt);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SignInSeenDto { " + "UserName = " + UserName + ", " + "LastSignInAt = " + LastSignInAt + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SignInSeenDto CloneRecord()
    {
    return (SignInSeenDto)MemberwiseClone();
    }

    }

    /// <summary>SRAU: what a person did (their sign-ins included) and the access changes made to them.</summary>
    public sealed class UserActivityDto : IRecord<UserActivityDto>, IEquatable<UserActivityDto>
    {
        public string UserName { get; set; } = "";

        public DateTimeOffset? LastSignInAt { get; set; }

        public IReadOnlyList<AuditEntryDto> Entries { get; set; } = new List<AuditEntryDto>();

        public IReadOnlyList<AccessChangeRequestDto> AccessChanges { get; set; } = new List<AccessChangeRequestDto>();

        public bool Equals(UserActivityDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(LastSignInAt, other.LastSignInAt)
    && EqualityComparer<IReadOnlyList<AuditEntryDto>>.Default.Equals(Entries, other.Entries)
    && EqualityComparer<IReadOnlyList<AccessChangeRequestDto>>.Default.Equals(AccessChanges, other.AccessChanges);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as UserActivityDto);
    }

        public static bool operator ==(UserActivityDto left, UserActivityDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(UserActivityDto left, UserActivityDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 68716;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(LastSignInAt);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<AuditEntryDto>>.Default.GetHashCode(Entries);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<AccessChangeRequestDto>>.Default.GetHashCode(AccessChanges);
    return hash;
    }
    }

        public override string ToString()
    {
    return "UserActivityDto { " + "UserName = " + UserName + ", " + "LastSignInAt = " + LastSignInAt + ", " + "Entries = " + Entries + ", " + "AccessChanges = " + AccessChanges + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public UserActivityDto CloneRecord()
    {
    return (UserActivityDto)MemberwiseClone();
    }

    }

    public sealed class AdminUserDto : IRecord<AdminUserDto>, IEquatable<AdminUserDto>
    {
        public string UserName { get; set; } = "";

        public string DisplayName { get; set; }

        public bool IsActive { get; set; } = true;

        public IReadOnlyList<string> Roles { get; set; } = new List<string>();

        public DateTime? UpdatedAtUtc { get; set; }

        public string UpdatedBy { get; set; }

        public DateTimeOffset? LastSignInAt { get; set; }

        /// <summary>Why the application disabled the person: <see cref="SignInOutcomes.Locked"/> or <see cref="SignInOutcomes.Dormant"/>; null otherwise.</summary>
        public string DisabledReason { get; set; }

        public string Department { get; set; }

        public DateOnly? AccessUntil { get; set; }

        public DateTime? CreatedAtUtc { get; set; }

        public bool Equals(AdminUserDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<string>.Default.Equals(DisplayName, other.DisplayName)
    && EqualityComparer<bool>.Default.Equals(IsActive, other.IsActive)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Roles, other.Roles)
    && EqualityComparer<DateTime?>.Default.Equals(UpdatedAtUtc, other.UpdatedAtUtc)
    && EqualityComparer<string>.Default.Equals(UpdatedBy, other.UpdatedBy)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(LastSignInAt, other.LastSignInAt)
    && EqualityComparer<string>.Default.Equals(DisabledReason, other.DisabledReason)
    && EqualityComparer<string>.Default.Equals(Department, other.Department)
    && EqualityComparer<DateOnly?>.Default.Equals(AccessUntil, other.AccessUntil)
    && EqualityComparer<DateTime?>.Default.Equals(CreatedAtUtc, other.CreatedAtUtc);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AdminUserDto);
    }

        public static bool operator ==(AdminUserDto left, AdminUserDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AdminUserDto left, AdminUserDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 41002;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DisplayName);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsActive);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Roles);
    hash = hash * -1521134295 + EqualityComparer<DateTime?>.Default.GetHashCode(UpdatedAtUtc);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UpdatedBy);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(LastSignInAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DisabledReason);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Department);
    hash = hash * -1521134295 + EqualityComparer<DateOnly?>.Default.GetHashCode(AccessUntil);
    hash = hash * -1521134295 + EqualityComparer<DateTime?>.Default.GetHashCode(CreatedAtUtc);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AdminUserDto { " + "UserName = " + UserName + ", " + "DisplayName = " + DisplayName + ", " + "IsActive = " + IsActive + ", " + "Roles = " + Roles + ", " + "UpdatedAtUtc = " + UpdatedAtUtc + ", " + "UpdatedBy = " + UpdatedBy + ", " + "LastSignInAt = " + LastSignInAt + ", " + "DisabledReason = " + DisabledReason + ", " + "Department = " + Department + ", " + "AccessUntil = " + AccessUntil + ", " + "CreatedAtUtc = " + CreatedAtUtc + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AdminUserDto CloneRecord()
    {
    return (AdminUserDto)MemberwiseClone();
    }

    }

    public sealed class AdminRoleDto : IRecord<AdminRoleDto>, IEquatable<AdminRoleDto>
    {
        public string Key { get; set; } = "";

        public string DisplayName { get; set; } = "";

        public string Description { get; set; }

        public bool IsActive { get; set; } = true;

        public IReadOnlyList<string> Permissions { get; set; } = new List<string>();

        public IReadOnlyList<string> DirectoryGroups { get; set; } = new List<string>();

        public bool Equals(AdminRoleDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Key, other.Key)
    && EqualityComparer<string>.Default.Equals(DisplayName, other.DisplayName)
    && EqualityComparer<string>.Default.Equals(Description, other.Description)
    && EqualityComparer<bool>.Default.Equals(IsActive, other.IsActive)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Permissions, other.Permissions)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(DirectoryGroups, other.DirectoryGroups);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AdminRoleDto);
    }

        public static bool operator ==(AdminRoleDto left, AdminRoleDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AdminRoleDto left, AdminRoleDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 76011;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Key);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DisplayName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Description);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsActive);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Permissions);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(DirectoryGroups);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AdminRoleDto { " + "Key = " + Key + ", " + "DisplayName = " + DisplayName + ", " + "Description = " + Description + ", " + "IsActive = " + IsActive + ", " + "Permissions = " + Permissions + ", " + "DirectoryGroups = " + DirectoryGroups + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AdminRoleDto CloneRecord()
    {
    return (AdminRoleDto)MemberwiseClone();
    }

    }

    /// <summary>SRAU: the whole new state of one person (roles replace the current ones).</summary>
    public sealed class UserChangeDto : IRecord<UserChangeDto>, IEquatable<UserChangeDto>
    {
        public string UserName { get; set; } = "";

        public string DisplayName { get; set; }

        public bool IsActive { get; set; } = true;

        public IReadOnlyList<string> Roles { get; set; } = new List<string>();

        /// <summary>The person's branch or department (for the user extraction report).</summary>
        public string Department { get; set; }

        /// <summary>The last day of the person's access (null = no end); after it they get no role at all.</summary>
        public DateOnly? AccessUntil { get; set; }

        /// <summary>Delete the person from the list: their roles given in the app are removed (AD groups still apply).</summary>
        public bool Delete { get; set; }

        public bool Equals(UserChangeDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<string>.Default.Equals(DisplayName, other.DisplayName)
    && EqualityComparer<bool>.Default.Equals(IsActive, other.IsActive)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Roles, other.Roles)
    && EqualityComparer<string>.Default.Equals(Department, other.Department)
    && EqualityComparer<DateOnly?>.Default.Equals(AccessUntil, other.AccessUntil)
    && EqualityComparer<bool>.Default.Equals(Delete, other.Delete);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as UserChangeDto);
    }

        public static bool operator ==(UserChangeDto left, UserChangeDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(UserChangeDto left, UserChangeDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 32237;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DisplayName);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsActive);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Roles);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Department);
    hash = hash * -1521134295 + EqualityComparer<DateOnly?>.Default.GetHashCode(AccessUntil);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Delete);
    return hash;
    }
    }

        public override string ToString()
    {
    return "UserChangeDto { " + "UserName = " + UserName + ", " + "DisplayName = " + DisplayName + ", " + "IsActive = " + IsActive + ", " + "Roles = " + Roles + ", " + "Department = " + Department + ", " + "AccessUntil = " + AccessUntil + ", " + "Delete = " + Delete + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public UserChangeDto CloneRecord()
    {
    return (UserChangeDto)MemberwiseClone();
    }

    }

    /// <summary>PARAM: the whole new definition of one role (the permissions replace the current ones).</summary>
    public sealed class RoleChangeDto : IRecord<RoleChangeDto>, IEquatable<RoleChangeDto>
    {
        public string Key { get; set; } = "";

        public string DisplayName { get; set; } = "";

        public string Description { get; set; }

        public bool IsActive { get; set; } = true;

        public IReadOnlyList<string> Permissions { get; set; } = new List<string>();

        /// <summary>Delete the role: nobody gets it any more and its AD groups give nothing. Its key cannot be used again.</summary>
        public bool Delete { get; set; }

        public bool Equals(RoleChangeDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Key, other.Key)
    && EqualityComparer<string>.Default.Equals(DisplayName, other.DisplayName)
    && EqualityComparer<string>.Default.Equals(Description, other.Description)
    && EqualityComparer<bool>.Default.Equals(IsActive, other.IsActive)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Permissions, other.Permissions)
    && EqualityComparer<bool>.Default.Equals(Delete, other.Delete);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as RoleChangeDto);
    }

        public static bool operator ==(RoleChangeDto left, RoleChangeDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(RoleChangeDto left, RoleChangeDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 3448;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Key);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DisplayName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Description);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsActive);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Permissions);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Delete);
    return hash;
    }
    }

        public override string ToString()
    {
    return "RoleChangeDto { " + "Key = " + Key + ", " + "DisplayName = " + DisplayName + ", " + "Description = " + Description + ", " + "IsActive = " + IsActive + ", " + "Permissions = " + Permissions + ", " + "Delete = " + Delete + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public RoleChangeDto CloneRecord()
    {
    return (RoleChangeDto)MemberwiseClone();
    }

    }

    /// <summary>SRAU or PARAM: the full new list of Active Directory groups that grant one role.</summary>
    public sealed class RoleGroupsChangeDto : IRecord<RoleGroupsChangeDto>, IEquatable<RoleGroupsChangeDto>
    {
        public string RoleKey { get; set; } = "";

        public IReadOnlyList<string> DirectoryGroups { get; set; } = new List<string>();

        public bool Equals(RoleGroupsChangeDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(RoleKey, other.RoleKey)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(DirectoryGroups, other.DirectoryGroups);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as RoleGroupsChangeDto);
    }

        public static bool operator ==(RoleGroupsChangeDto left, RoleGroupsChangeDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(RoleGroupsChangeDto left, RoleGroupsChangeDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 30508;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(RoleKey);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(DirectoryGroups);
    return hash;
    }
    }

        public override string ToString()
    {
    return "RoleGroupsChangeDto { " + "RoleKey = " + RoleKey + ", " + "DirectoryGroups = " + DirectoryGroups + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public RoleGroupsChangeDto CloneRecord()
    {
    return (RoleGroupsChangeDto)MemberwiseClone();
    }

    }

    /// <summary>Outcomes of a sign-in attempt, decided by the API from frp.SignInState and the app's user list.</summary>
    public static class SignInOutcomes
    {
        public const string SignedIn = "SignedIn";
        public const string Failed = "Failed";
        /// <summary>Too many failed sign-ins in a row: disabled until SRAU re-enables the account.</summary>
        public const string Locked = "Locked";
        /// <summary>An administrator account after too many failed sign-ins: no sign-in for a few minutes.</summary>
        public const string Delayed = "Delayed";
        /// <summary>Disabled by SRAU.</summary>
        public const string Disabled = "Disabled";
        /// <summary>Deactivated after too many days without a sign-in.</summary>
        public const string Dormant = "Dormant";
        /// <summary>The last day of access set by SRAU has passed.</summary>
        public const string Expired = "Expired";
    }

    /// <summary>The Platform asks before checking a password whether the account is delayed.</summary>
    public sealed class SignInCheckDto : IRecord<SignInCheckDto>, IEquatable<SignInCheckDto>
    {
        public string UserName { get; set; } = "";

        public bool Equals(SignInCheckDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SignInCheckDto);
    }

        public static bool operator ==(SignInCheckDto left, SignInCheckDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SignInCheckDto left, SignInCheckDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 68310;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SignInCheckDto { " + "UserName = " + UserName + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SignInCheckDto CloneRecord()
    {
    return (SignInCheckDto)MemberwiseClone();
    }

    }

    public sealed class SignInCheckResultDto : IRecord<SignInCheckResultDto>, IEquatable<SignInCheckResultDto>
    {
        /// <summary>Until when the account cannot sign in, or null.</summary>
        public DateTimeOffset? DelayedUntil { get; set; }

        public bool Equals(SignInCheckResultDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<DateTimeOffset?>.Default.Equals(DelayedUntil, other.DelayedUntil);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SignInCheckResultDto);
    }

        public static bool operator ==(SignInCheckResultDto left, SignInCheckResultDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SignInCheckResultDto left, SignInCheckResultDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 69715;
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(DelayedUntil);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SignInCheckResultDto { " + "DelayedUntil = " + DelayedUntil + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SignInCheckResultDto CloneRecord()
    {
    return (SignInCheckResultDto)MemberwiseClone();
    }

    }

    /// <summary>A failed or blocked sign-in on the sign-in page (never the password).</summary>
    public sealed class SignInFailedDto : IRecord<SignInFailedDto>, IEquatable<SignInFailedDto>
    {
        public string UserName { get; set; } = "";

        /// <summary>Where it came from and why it failed, e.g. "From 10.1.2.3; Windows error 1326."</summary>
        public string Detail { get; set; }

        /// <summary>False for failures that are not a wrong password (e.g. an expired password): audited, not counted.</summary>
        public bool CountsTowardLockout { get; set; } = true;

        public bool Equals(SignInFailedDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<string>.Default.Equals(Detail, other.Detail)
    && EqualityComparer<bool>.Default.Equals(CountsTowardLockout, other.CountsTowardLockout);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SignInFailedDto);
    }

        public static bool operator ==(SignInFailedDto left, SignInFailedDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SignInFailedDto left, SignInFailedDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 71569;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Detail);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(CountsTowardLockout);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SignInFailedDto { " + "UserName = " + UserName + ", " + "Detail = " + Detail + ", " + "CountsTowardLockout = " + CountsTowardLockout + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SignInFailedDto CloneRecord()
    {
    return (SignInFailedDto)MemberwiseClone();
    }

    }

    /// <summary>A correct password (or a Development test user): the API decides whether the person may sign in.</summary>
    public sealed class SignInSucceededDto : IRecord<SignInSucceededDto>, IEquatable<SignInSucceededDto>
    {
        public string UserName { get; set; } = "";

        public string Detail { get; set; }

        /// <summary>Active Directory groups of the account that grant an FRP Mapper role.</summary>
        public IReadOnlyList<string> DirectoryGroups { get; set; } = new List<string>();

        /// <summary>Development sign-in: the test user's roles.</summary>
        public IReadOnlyList<string> Roles { get; set; } = new List<string>();

        /// <summary>The new session's id: from now on the only session this account may use.</summary>
        public string SessionId { get; set; } = "";

        public bool Equals(SignInSucceededDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<string>.Default.Equals(Detail, other.Detail)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(DirectoryGroups, other.DirectoryGroups)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Roles, other.Roles)
    && EqualityComparer<string>.Default.Equals(SessionId, other.SessionId);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SignInSucceededDto);
    }

        public static bool operator ==(SignInSucceededDto left, SignInSucceededDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SignInSucceededDto left, SignInSucceededDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 52559;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Detail);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(DirectoryGroups);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Roles);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SessionId);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SignInSucceededDto { " + "UserName = " + UserName + ", " + "Detail = " + Detail + ", " + "DirectoryGroups = " + DirectoryGroups + ", " + "Roles = " + Roles + ", " + "SessionId = " + SessionId + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SignInSucceededDto CloneRecord()
    {
    return (SignInSucceededDto)MemberwiseClone();
    }

    }

    public sealed class SignInResultDto : IRecord<SignInResultDto>, IEquatable<SignInResultDto>
    {
        public string Outcome { get; set; } = SignInOutcomes.Failed;

        /// <summary>The previous successful sign-in (shown to the person), or null for a first sign-in.</summary>
        public DateTimeOffset? PreviousSignInAt { get; set; }

        /// <summary>Failed sign-ins since the previous successful one.</summary>
        public int FailedSinceLast { get; set; }

        /// <summary>Days without sign-in after which an account is deactivated (for the message), 0 when the rule is off.</summary>
        public int InactiveDays { get; set; }

        public bool Equals(SignInResultDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Outcome, other.Outcome)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(PreviousSignInAt, other.PreviousSignInAt)
    && EqualityComparer<int>.Default.Equals(FailedSinceLast, other.FailedSinceLast)
    && EqualityComparer<int>.Default.Equals(InactiveDays, other.InactiveDays);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SignInResultDto);
    }

        public static bool operator ==(SignInResultDto left, SignInResultDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SignInResultDto left, SignInResultDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 91279;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Outcome);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(PreviousSignInAt);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(FailedSinceLast);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(InactiveDays);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SignInResultDto { " + "Outcome = " + Outcome + ", " + "PreviousSignInAt = " + PreviousSignInAt + ", " + "FailedSinceLast = " + FailedSinceLast + ", " + "InactiveDays = " + InactiveDays + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SignInResultDto CloneRecord()
    {
    return (SignInResultDto)MemberwiseClone();
    }

    }

    public sealed class SessionCheckDto : IRecord<SessionCheckDto>, IEquatable<SessionCheckDto>
    {
        public string UserName { get; set; } = "";

        public string SessionId { get; set; } = "";

        public bool Equals(SessionCheckDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<string>.Default.Equals(SessionId, other.SessionId);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SessionCheckDto);
    }

        public static bool operator ==(SessionCheckDto left, SessionCheckDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SessionCheckDto left, SessionCheckDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 57636;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SessionId);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SessionCheckDto { " + "UserName = " + UserName + ", " + "SessionId = " + SessionId + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SessionCheckDto CloneRecord()
    {
    return (SessionCheckDto)MemberwiseClone();
    }

    }

    /// <summary>A sign-out: ends the session on the server as well (see frp.usp_SignIn_End).</summary>
    public sealed class SessionEndDto : IRecord<SessionEndDto>, IEquatable<SessionEndDto>
    {
        public string UserName { get; set; } = "";

        public string SessionId { get; set; } = "";

        /// <summary>True when the page signed the person out after the idle timeout.</summary>
        public bool Idle { get; set; }

        public bool Equals(SessionEndDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<string>.Default.Equals(SessionId, other.SessionId)
    && EqualityComparer<bool>.Default.Equals(Idle, other.Idle);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SessionEndDto);
    }

        public static bool operator ==(SessionEndDto left, SessionEndDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SessionEndDto left, SessionEndDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 17481;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SessionId);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Idle);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SessionEndDto { " + "UserName = " + UserName + ", " + "SessionId = " + SessionId + ", " + "Idle = " + Idle + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SessionEndDto CloneRecord()
    {
    return (SessionEndDto)MemberwiseClone();
    }

    }

    public sealed class SessionCheckResultDto : IRecord<SessionCheckResultDto>, IEquatable<SessionCheckResultDto>
    {
        /// <summary>False when the account signed in again elsewhere since (only the newest session may be used).</summary>
        public bool Current { get; set; }

        public bool Equals(SessionCheckResultDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<bool>.Default.Equals(Current, other.Current);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SessionCheckResultDto);
    }

        public static bool operator ==(SessionCheckResultDto left, SessionCheckResultDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SessionCheckResultDto left, SessionCheckResultDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 74751;
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Current);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SessionCheckResultDto { " + "Current = " + Current + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SessionCheckResultDto CloneRecord()
    {
    return (SessionCheckResultDto)MemberwiseClone();
    }

    }

    public sealed class AccessChangeRequestDto : IRecord<AccessChangeRequestDto>, IEquatable<AccessChangeRequestDto>
    {
        public string Id { get; set; } = "";

        /// <summary>The requester's team (<see cref="AccessTeams"/>): a different member of it must approve.</summary>
        public string Team { get; set; } = "";

        public string Kind { get; set; } = AccessKinds.User;

        public string TargetKey { get; set; } = "";

        /// <summary>What changes, e.g. "Roles: Maker → Maker, Checker".</summary>
        public string Summary { get; set; } = "";

        public string Status { get; set; } = AccessRequestStatus.Pending;

        public UserChangeDto User { get; set; }

        public RoleChangeDto Role { get; set; }

        public RoleGroupsChangeDto Groups { get; set; }

        /// <summary>The person, role or AD groups as they were when the change was requested (null for a new one, or for
        /// requests made before this was recorded): the old values in the maintenance reports.</summary>
        public UserChangeDto UserBefore { get; set; }

        public RoleChangeDto RoleBefore { get; set; }

        public RoleGroupsChangeDto GroupsBefore { get; set; }

        public string RequestedBy { get; set; } = "";

        public DateTimeOffset RequestedAt { get; set; }

        public string DecidedBy { get; set; }

        public DateTimeOffset? DecidedAt { get; set; }

        public string DecisionComment { get; set; }

        /// <summary>The version the request was read at; a decision is refused when it changed since.</summary>
        public string Version { get; set; } = "";

        public bool Equals(AccessChangeRequestDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Id, other.Id)
    && EqualityComparer<string>.Default.Equals(Team, other.Team)
    && EqualityComparer<string>.Default.Equals(Kind, other.Kind)
    && EqualityComparer<string>.Default.Equals(TargetKey, other.TargetKey)
    && EqualityComparer<string>.Default.Equals(Summary, other.Summary)
    && EqualityComparer<string>.Default.Equals(Status, other.Status)
    && EqualityComparer<UserChangeDto>.Default.Equals(User, other.User)
    && EqualityComparer<RoleChangeDto>.Default.Equals(Role, other.Role)
    && EqualityComparer<RoleGroupsChangeDto>.Default.Equals(Groups, other.Groups)
    && EqualityComparer<UserChangeDto>.Default.Equals(UserBefore, other.UserBefore)
    && EqualityComparer<RoleChangeDto>.Default.Equals(RoleBefore, other.RoleBefore)
    && EqualityComparer<RoleGroupsChangeDto>.Default.Equals(GroupsBefore, other.GroupsBefore)
    && EqualityComparer<string>.Default.Equals(RequestedBy, other.RequestedBy)
    && EqualityComparer<DateTimeOffset>.Default.Equals(RequestedAt, other.RequestedAt)
    && EqualityComparer<string>.Default.Equals(DecidedBy, other.DecidedBy)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(DecidedAt, other.DecidedAt)
    && EqualityComparer<string>.Default.Equals(DecisionComment, other.DecisionComment)
    && EqualityComparer<string>.Default.Equals(Version, other.Version);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AccessChangeRequestDto);
    }

        public static bool operator ==(AccessChangeRequestDto left, AccessChangeRequestDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AccessChangeRequestDto left, AccessChangeRequestDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 88725;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Id);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Team);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Kind);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(TargetKey);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Summary);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Status);
    hash = hash * -1521134295 + EqualityComparer<UserChangeDto>.Default.GetHashCode(User);
    hash = hash * -1521134295 + EqualityComparer<RoleChangeDto>.Default.GetHashCode(Role);
    hash = hash * -1521134295 + EqualityComparer<RoleGroupsChangeDto>.Default.GetHashCode(Groups);
    hash = hash * -1521134295 + EqualityComparer<UserChangeDto>.Default.GetHashCode(UserBefore);
    hash = hash * -1521134295 + EqualityComparer<RoleChangeDto>.Default.GetHashCode(RoleBefore);
    hash = hash * -1521134295 + EqualityComparer<RoleGroupsChangeDto>.Default.GetHashCode(GroupsBefore);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(RequestedBy);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(RequestedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DecidedBy);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(DecidedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DecisionComment);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Version);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AccessChangeRequestDto { " + "Id = " + Id + ", " + "Team = " + Team + ", " + "Kind = " + Kind + ", " + "TargetKey = " + TargetKey + ", " + "Summary = " + Summary + ", " + "Status = " + Status + ", " + "User = " + User + ", " + "Role = " + Role + ", " + "Groups = " + Groups + ", " + "UserBefore = " + UserBefore + ", " + "RoleBefore = " + RoleBefore + ", " + "GroupsBefore = " + GroupsBefore + ", " + "RequestedBy = " + RequestedBy + ", " + "RequestedAt = " + RequestedAt + ", " + "DecidedBy = " + DecidedBy + ", " + "DecidedAt = " + DecidedAt + ", " + "DecisionComment = " + DecisionComment + ", " + "Version = " + Version + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AccessChangeRequestDto CloneRecord()
    {
    return (AccessChangeRequestDto)MemberwiseClone();
    }

    }

    public sealed class AccessDecisionRequest : IRecord<AccessDecisionRequest>, IEquatable<AccessDecisionRequest>
    {
        public string Version { get; set; } = "";

        public string Comment { get; set; }

        public bool Equals(AccessDecisionRequest other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Version, other.Version)
    && EqualityComparer<string>.Default.Equals(Comment, other.Comment);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AccessDecisionRequest);
    }

        public static bool operator ==(AccessDecisionRequest left, AccessDecisionRequest right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AccessDecisionRequest left, AccessDecisionRequest right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 70110;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Version);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Comment);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AccessDecisionRequest { " + "Version = " + Version + ", " + "Comment = " + Comment + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AccessDecisionRequest CloneRecord()
    {
    return (AccessDecisionRequest)MemberwiseClone();
    }

    }

}
