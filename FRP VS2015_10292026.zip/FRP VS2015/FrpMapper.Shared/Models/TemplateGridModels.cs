﻿using System;
using System.Collections.Generic;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Shared.Models
{
    /// <summary>One worksheet of a project's Excel input template, laid out as Excel shows it (for mapping XSD fields to cells on the sheet).</summary>
    public sealed class TemplateGridDto : IRecord<TemplateGridDto>, IEquatable<TemplateGridDto>
    {
        public string SheetName { get; set; } = "";

        /// <summary>The last row shown (1-based).</summary>
        public int MaxRow { get; set; }

        /// <summary>The last column shown (1-based; 1 = A).</summary>
        public int MaxColumn { get; set; }

        /// <summary>True when the sheet is larger than the grid shows (rows or columns were cut off).</summary>
        public bool Truncated { get; set; }

        /// <summary>Excel's default column width for the sheet, in characters.</summary>
        public double DefaultColumnWidth { get; set; }

        /// <summary>Columns with their own width, or hidden.</summary>
        public IReadOnlyList<TemplateGridColumnDto> Columns { get; set; } = new List<TemplateGridColumnDto>();

        public IReadOnlyList<int> HiddenRows { get; set; } = new List<int>();

        /// <summary>Merged ranges, e.g. B2:D2.</summary>
        public IReadOnlyList<string> Merges { get; set; } = new List<string>();

        /// <summary>Cells with text or a fill colour.</summary>
        public IReadOnlyList<TemplateGridCellDto> Cells { get; set; } = new List<TemplateGridCellDto>();

        /// <summary>
        /// The sheet is shown as the downloaded input template lays it out. A list entered as a table with one row per item
        /// (see the template's item rows) has its fields in the table's first data row; each link gives that cell and the
        /// form's cell the field is mapped to (where the project stores it). Empty when the sheet is the template itself.
        /// </summary>
        public IReadOnlyList<TemplateGridLinkDto> Links { get; set; } = new List<TemplateGridLinkDto>();

        /// <summary>The areas the item-rows tables replace on the form (note, headings and table), e.g. A3:BR15.</summary>
        public IReadOnlyList<TemplateGridItemTableDto> ItemTables { get; set; } = new List<TemplateGridItemTableDto>();

        public bool Equals(TemplateGridDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(SheetName, other.SheetName)
    && EqualityComparer<int>.Default.Equals(MaxRow, other.MaxRow)
    && EqualityComparer<int>.Default.Equals(MaxColumn, other.MaxColumn)
    && EqualityComparer<bool>.Default.Equals(Truncated, other.Truncated)
    && EqualityComparer<double>.Default.Equals(DefaultColumnWidth, other.DefaultColumnWidth)
    && EqualityComparer<IReadOnlyList<TemplateGridColumnDto>>.Default.Equals(Columns, other.Columns)
    && EqualityComparer<IReadOnlyList<int>>.Default.Equals(HiddenRows, other.HiddenRows)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Merges, other.Merges)
    && EqualityComparer<IReadOnlyList<TemplateGridCellDto>>.Default.Equals(Cells, other.Cells)
    && EqualityComparer<IReadOnlyList<TemplateGridLinkDto>>.Default.Equals(Links, other.Links)
    && EqualityComparer<IReadOnlyList<TemplateGridItemTableDto>>.Default.Equals(ItemTables, other.ItemTables);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as TemplateGridDto);
    }

        public static bool operator ==(TemplateGridDto left, TemplateGridDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(TemplateGridDto left, TemplateGridDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SheetName);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(MaxRow);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(MaxColumn);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Truncated);
    hash = hash * -1521134295 + EqualityComparer<double>.Default.GetHashCode(DefaultColumnWidth);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<TemplateGridColumnDto>>.Default.GetHashCode(Columns);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<int>>.Default.GetHashCode(HiddenRows);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Merges);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<TemplateGridCellDto>>.Default.GetHashCode(Cells);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<TemplateGridLinkDto>>.Default.GetHashCode(Links);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<TemplateGridItemTableDto>>.Default.GetHashCode(ItemTables);
    return hash;
    }
    }

        public override string ToString()
    {
    return "TemplateGridDto { " + "SheetName = " + SheetName + ", " + "MaxRow = " + MaxRow + ", " + "MaxColumn = " + MaxColumn + ", " + "Truncated = " + Truncated + ", " + "DefaultColumnWidth = " + DefaultColumnWidth + ", " + "Columns = " + Columns + ", " + "HiddenRows = " + HiddenRows + ", " + "Merges = " + Merges + ", " + "Cells = " + Cells + ", " + "Links = " + Links + ", " + "ItemTables = " + ItemTables + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public TemplateGridDto CloneRecord()
    {
    return (TemplateGridDto)MemberwiseClone();
    }

    }

    /// <summary>A field's cell in the downloaded template and the form's cell it is mapped to (see <see cref="TemplateGridDto.Links"/>).</summary>
    public sealed class TemplateGridLinkDto : IRecord<TemplateGridLinkDto>, IEquatable<TemplateGridLinkDto>
    {
        /// <summary>The cell in the downloaded template, e.g. D15.</summary>
        public string TemplateCell { get; set; } = "";

        /// <summary>The form's cell the project maps the field to, e.g. G13.</summary>
        public string FormCell { get; set; } = "";

        public string SchemaPath { get; set; } = "";

        public bool Equals(TemplateGridLinkDto other) =>
            !ReferenceEquals(other, null) && TemplateCell == other.TemplateCell && FormCell == other.FormCell && SchemaPath == other.SchemaPath;

        public override bool Equals(object obj) => Equals(obj as TemplateGridLinkDto);

        public override int GetHashCode() => (TemplateCell + "|" + FormCell + "|" + SchemaPath).GetHashCode();

        public override string ToString() => "TemplateGridLinkDto { TemplateCell = " + TemplateCell + ", FormCell = " + FormCell + ", SchemaPath = " + SchemaPath + " }";

        /// <summary>A shallow copy (what "with" starts from).</summary>
        public TemplateGridLinkDto CloneRecord() => (TemplateGridLinkDto)MemberwiseClone();
    }

    /// <summary>An item-rows table on the shown sheet: the list item and the area it takes (note, headings, table).</summary>
    public sealed class TemplateGridItemTableDto : IRecord<TemplateGridItemTableDto>, IEquatable<TemplateGridItemTableDto>
    {
        /// <summary>The repeating XSD element, e.g. /CAR_M/CAR_Part_IV_1d/CAR_Part_IV_1d_Item.</summary>
        public string ItemPath { get; set; } = "";

        /// <summary>From the note to the table's first data row, e.g. A3:BR15.</summary>
        public string Range { get; set; } = "";

        /// <summary>The table's first data row: each item is a row from here down.</summary>
        public int DataRow { get; set; }

        public bool Equals(TemplateGridItemTableDto other) =>
            !ReferenceEquals(other, null) && ItemPath == other.ItemPath && Range == other.Range && DataRow == other.DataRow;

        public override bool Equals(object obj) => Equals(obj as TemplateGridItemTableDto);

        public override int GetHashCode() => (ItemPath + "|" + Range + "|" + DataRow).GetHashCode();

        public override string ToString() => "TemplateGridItemTableDto { ItemPath = " + ItemPath + ", Range = " + Range + ", DataRow = " + DataRow + " }";

        /// <summary>A shallow copy (what "with" starts from).</summary>
        public TemplateGridItemTableDto CloneRecord() => (TemplateGridItemTableDto)MemberwiseClone();
    }

    /// <summary>A column of a template sheet with its own width (in characters) or hidden.</summary>
    public sealed class TemplateGridColumnDto : IRecord<TemplateGridColumnDto>, IEquatable<TemplateGridColumnDto>
    {
        public int Index { get; set; }

        public double Width { get; set; }

        public bool Hidden { get; set; }

        public bool Equals(TemplateGridColumnDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<int>.Default.Equals(Index, other.Index)
    && EqualityComparer<double>.Default.Equals(Width, other.Width)
    && EqualityComparer<bool>.Default.Equals(Hidden, other.Hidden);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as TemplateGridColumnDto);
    }

        public static bool operator ==(TemplateGridColumnDto left, TemplateGridColumnDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(TemplateGridColumnDto left, TemplateGridColumnDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Index);
    hash = hash * -1521134295 + EqualityComparer<double>.Default.GetHashCode(Width);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Hidden);
    return hash;
    }
    }

        public override string ToString()
    {
    return "TemplateGridColumnDto { " + "Index = " + Index + ", " + "Width = " + Width + ", " + "Hidden = " + Hidden + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public TemplateGridColumnDto CloneRecord()
    {
    return (TemplateGridColumnDto)MemberwiseClone();
    }

    }

    /// <summary>A cell of a template sheet as Excel shows it: its text (the cached value of a formula) and basic formatting.</summary>
    public sealed class TemplateGridCellDto : IRecord<TemplateGridCellDto>, IEquatable<TemplateGridCellDto>
    {
        public string Address { get; set; } = "";

        public string Text { get; set; } = "";

        public bool Bold { get; set; }

        /// <summary>Background colour, #RRGGBB, or null.</summary>
        public string Fill { get; set; }

        /// <summary>Text colour, #RRGGBB, or null.</summary>
        public string Color { get; set; }

        /// <summary>left, center or right; null for Excel's default.</summary>
        public string Align { get; set; }

        public bool Equals(TemplateGridCellDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Address, other.Address)
    && EqualityComparer<string>.Default.Equals(Text, other.Text)
    && EqualityComparer<bool>.Default.Equals(Bold, other.Bold)
    && EqualityComparer<string>.Default.Equals(Fill, other.Fill)
    && EqualityComparer<string>.Default.Equals(Color, other.Color)
    && EqualityComparer<string>.Default.Equals(Align, other.Align);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as TemplateGridCellDto);
    }

        public static bool operator ==(TemplateGridCellDto left, TemplateGridCellDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(TemplateGridCellDto left, TemplateGridCellDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Address);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Text);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Bold);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Fill);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Color);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Align);
    return hash;
    }
    }

        public override string ToString()
    {
    return "TemplateGridCellDto { " + "Address = " + Address + ", " + "Text = " + Text + ", " + "Bold = " + Bold + ", " + "Fill = " + Fill + ", " + "Color = " + Color + ", " + "Align = " + Align + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public TemplateGridCellDto CloneRecord()
    {
    return (TemplateGridCellDto)MemberwiseClone();
    }

    }

    /// <summary>The mappings FRP Mapper makes for a project's XSD and template (the starting point a Maker can go back to).</summary>
    public sealed class SuggestedMappingsDto : IRecord<SuggestedMappingsDto>, IEquatable<SuggestedMappingsDto>
    {
        public IReadOnlyList<MappingEntryDto> Mappings { get; set; } = new List<MappingEntryDto>();

        public bool Equals(SuggestedMappingsDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.Equals(Mappings, other.Mappings);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SuggestedMappingsDto);
    }

        public static bool operator ==(SuggestedMappingsDto left, SuggestedMappingsDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SuggestedMappingsDto left, SuggestedMappingsDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.GetHashCode(Mappings);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SuggestedMappingsDto { " + "Mappings = " + Mappings + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SuggestedMappingsDto CloneRecord()
    {
    return (SuggestedMappingsDto)MemberwiseClone();
    }

    }

}
