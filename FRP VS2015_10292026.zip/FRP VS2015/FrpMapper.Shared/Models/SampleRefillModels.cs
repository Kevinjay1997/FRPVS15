﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Shared.Models
{
    /// <summary>
    /// New sample values, saved in the database: every XSD field's own value (frp.SchemaNode.TestValue) and every mapped
    /// cell's value. With how many are unique and how the XML built from them checks against the XSD and BSP rules.
    /// </summary>
    public sealed class SampleRefillDto : IRecord<SampleRefillDto>, IEquatable<SampleRefillDto>
    {
        /// <summary>The project as saved, with its new sample values and mappings.</summary>
        public FrpProjectDto Project { get; set; } = new FrpProjectDto();

        /// <summary>Mapped cells that received the new value of their field.</summary>
        public int Refilled { get; set; }

        /// <summary>Of the amounts, whole numbers and texts refilled: how many have a value no other field has.</summary>
        public int Unique { get; set; }

        /// <summary>Refilled fields that share a value, because the BSP rules require it (e.g. 0, or equal totals).</summary>
        public int Shared { get; set; }

        public bool XsdValid { get; set; }

        public int XsdErrors { get; set; }

        public int RulesPassed { get; set; }

        public int RulesFailed { get; set; }

        /// <summary>The first problems found (XSD errors and failed rules), when there are any.</summary>
        public IReadOnlyList<string> Problems { get; set; } = new List<string>();

        public bool Equals(SampleRefillDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<FrpProjectDto>.Default.Equals(Project, other.Project)
    && EqualityComparer<int>.Default.Equals(Refilled, other.Refilled)
    && EqualityComparer<int>.Default.Equals(Unique, other.Unique)
    && EqualityComparer<int>.Default.Equals(Shared, other.Shared)
    && EqualityComparer<bool>.Default.Equals(XsdValid, other.XsdValid)
    && EqualityComparer<int>.Default.Equals(XsdErrors, other.XsdErrors)
    && EqualityComparer<int>.Default.Equals(RulesPassed, other.RulesPassed)
    && EqualityComparer<int>.Default.Equals(RulesFailed, other.RulesFailed)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Problems, other.Problems);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SampleRefillDto);
    }

        public static bool operator ==(SampleRefillDto left, SampleRefillDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SampleRefillDto left, SampleRefillDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 72398;
    hash = hash * -1521134295 + EqualityComparer<FrpProjectDto>.Default.GetHashCode(Project);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Refilled);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Unique);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Shared);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(XsdValid);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(XsdErrors);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(RulesPassed);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(RulesFailed);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Problems);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SampleRefillDto { " + "Project = " + Project + ", " + "Refilled = " + Refilled + ", " + "Unique = " + Unique + ", " + "Shared = " + Shared + ", " + "XsdValid = " + XsdValid + ", " + "XsdErrors = " + XsdErrors + ", " + "RulesPassed = " + RulesPassed + ", " + "RulesFailed = " + RulesFailed + ", " + "Problems = " + Problems + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SampleRefillDto CloneRecord()
    {
    return (SampleRefillDto)MemberwiseClone();
    }

    }

}
