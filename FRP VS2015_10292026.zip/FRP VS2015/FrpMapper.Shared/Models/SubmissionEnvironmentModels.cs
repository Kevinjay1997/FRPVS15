using System;
using System.Collections.Generic;

namespace FrpMapper.Shared.Models
{
    /// <summary>Where a BSP environment version is in its Maker / Checker life (the same steps as a bank certificate).</summary>
    public static class SubmissionEnvironmentStatus
    {
        public const string Pending = "Pending";
        public const string Active = "Active";
        public const string Replaced = "Replaced";
        public const string Rejected = "Rejected";
        public const string Cancelled = "Cancelled";
        public const string Removed = "Removed";
    }

    /// <summary>What a BSP environment is for. Production sends real regulatory submissions and needs submission.production.</summary>
    public static class SubmissionEnvironmentKind
    {
        public const string Test = "Test";
        public const string Production = "Production";
    }

    /// <summary>
    /// One version of a BSP Report API environment (Sandbox, Production, …): its base URL and the path of each operation.
    /// A path is relative to the base URL; every path except the submit one contains <c>{submissionId}</c>.
    /// </summary>
    public sealed class SubmissionEnvironmentDto
    {
        public string Id { get; set; } = "";

        /// <summary>Upper-case key, e.g. SANDBOX or PRODUCTION. One Active and at most one Pending version per key.</summary>
        public string Key { get; set; } = "";

        public string Name { get; set; } = "";

        /// <summary><see cref="SubmissionEnvironmentKind"/>.</summary>
        public string Kind { get; set; } = "";

        /// <summary>https://host/path/ (always ending with "/"); the host is one of the API's Bsp:AllowedHosts.</summary>
        public string BaseUrl { get; set; } = "";

        public string SubmitPath { get; set; } = "";

        public string StatusPath { get; set; } = "";

        public string ResultPdfPath { get; set; } = "";

        public string ResultXmlPath { get; set; } = "";

        public string ResultExcelPath { get; set; } = "";

        public string ReceiptPath { get; set; } = "";

        public int SortOrder { get; set; }

        /// <summary><see cref="SubmissionEnvironmentStatus"/>.</summary>
        public string Status { get; set; } = "";

        public string RequestedBy { get; set; } = "";

        public DateTimeOffset RequestedAt { get; set; }

        public string DecidedBy { get; set; }

        public DateTimeOffset? DecidedAt { get; set; }

        public string DecisionComment { get; set; }

        /// <summary>Row version (base64) for the decision.</summary>
        public string Version { get; set; } = "";
    }

    /// <summary>A Maker's proposal: a new environment, or a new version of an existing one (same key).</summary>
    public sealed class SubmissionEnvironmentRequest
    {
        public string Key { get; set; }
        public string Name { get; set; }
        public string Kind { get; set; }
        public string BaseUrl { get; set; }
        public string SubmitPath { get; set; }
        public string StatusPath { get; set; }
        public string ResultPdfPath { get; set; }
        public string ResultXmlPath { get; set; }
        public string ResultExcelPath { get; set; }
        public string ReceiptPath { get; set; }
        public int SortOrder { get; set; }
    }

    /// <summary>The settings tab: every Active and Pending environment, recent decisions, and the hosts the server allows.</summary>
    public sealed class SubmissionSettingsDto
    {
        public List<SubmissionEnvironmentDto> Environments { get; set; } = new List<SubmissionEnvironmentDto>();

        /// <summary>The API's Bsp:AllowedHosts: the only hosts an environment may use (changed by IT in the API's configuration).</summary>
        public List<string> AllowedHosts { get; set; } = new List<string>();
    }

    /// <summary>An approved environment as the submission form shows it.</summary>
    public sealed class SandboxEnvironmentDto
    {
        public string Key { get; set; } = "";
        public string Name { get; set; } = "";
        public string Kind { get; set; } = "";
        /// <summary>The full URL a report is POSTed to.</summary>
        public string SubmitUrl { get; set; } = "";
        /// <summary>The status URL with {submissionId} in it, shown on the page.</summary>
        public string StatusUrl { get; set; } = "";
        /// <summary>False for a Production environment when the person lacks submission.production.</summary>
        public bool CanUse { get; set; }
    }
}
