using System;
using System.Collections.Generic;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Shared.Models
{
    /// <summary>
    /// One page of the audit trail (the Audit trail page, or a project's History tab), newest first: the entries, how many
    /// match the search and action filter, and the actions used (for the filter).
    /// </summary>
    public sealed class AuditPageDto : IRecord<AuditPageDto>, IEquatable<AuditPageDto>
    {
        public IReadOnlyList<AuditEntryDto> Entries { get; set; } = new List<AuditEntryDto>();

        /// <summary>Entries matching the search and action (all pages).</summary>
        public int Total { get; set; }

        /// <summary>1 for the newest entries.</summary>
        public int Page { get; set; }

        public int PageSize { get; set; }

        /// <summary>The actions in the trail (or the project's), for the Action filter.</summary>
        public IReadOnlyList<string> Actions { get; set; } = new List<string>();

        public bool Equals(AuditPageDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<AuditEntryDto>>.Default.Equals(Entries, other.Entries)
    && EqualityComparer<int>.Default.Equals(Total, other.Total)
    && EqualityComparer<int>.Default.Equals(Page, other.Page)
    && EqualityComparer<int>.Default.Equals(PageSize, other.PageSize)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Actions, other.Actions);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AuditPageDto);
    }

        public static bool operator ==(AuditPageDto left, AuditPageDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AuditPageDto left, AuditPageDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<AuditEntryDto>>.Default.GetHashCode(Entries);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Total);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Page);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(PageSize);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Actions);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AuditPageDto { " + "Entries = " + Entries + ", " + "Total = " + Total + ", " + "Page = " + Page + ", " + "PageSize = " + PageSize + ", " + "Actions = " + Actions + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AuditPageDto CloneRecord()
    {
    return (AuditPageDto)MemberwiseClone();
    }

    }

}
