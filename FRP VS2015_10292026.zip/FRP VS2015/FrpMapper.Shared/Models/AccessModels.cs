﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Shared.Models
{
    /// <summary>
    /// Permission keys the application checks. Which roles hold which permission, which Active Directory groups grant
    /// each role, and the roles themselves are data in the database (frp.AppRole, frp.RolePermission,
    /// frp.RoleDirectoryGroup); only these keys are part of the code.
    /// </summary>
    public static class Permissions
    {
        /// <summary>Maker: request bank profile and branch changes, and import BSP sandbox results.</summary>
        public const string ReferenceManage = "reference.manage";
        /// <summary>Checker: approve or reject bank profile and branch changes.</summary>
        public const string ReferenceApprove = "reference.approve";
        public const string ProjectRead = "project.read";
        /// <summary>See every project; without it a person sees only the projects they created or worked on.</summary>
        public const string ProjectReadAll = "project.read-all";
        /// <summary>Delete a draft or returned project the person created.</summary>
        public const string ProjectDelete = "project.delete";
        /// <summary>SRAU Maker: request changes to people, the roles they hold and the AD groups that grant roles.</summary>
        public const string UsersManage = "users.manage";
        /// <summary>SRAU Checker: approve or reject the SRAU Maker's requests.</summary>
        public const string UsersApprove = "users.approve";
        /// <summary>PARAM Maker: request changes to roles, their permissions and the AD groups that grant them.</summary>
        public const string RolesManage = "roles.manage";
        /// <summary>PARAM Checker: approve or reject the PARAM Maker's requests.</summary>
        public const string RolesApprove = "roles.approve";
        public const string ProjectCreate = "project.create";
        public const string ProjectEdit = "project.edit";
        public const string SubmissionPrepare = "submission.prepare";
        /// <summary>Send to (and follow up in) a Production BSP environment: a real regulatory submission. Granted to no role by default.</summary>
        public const string SubmissionProduction = "submission.production";
        public const string SubmissionWithdraw = "submission.withdraw";
        public const string SubmissionReopen = "submission.reopen";
        public const string SubmissionDownloadInReview = "submission.download-in-review";
        public const string SubmissionReview = "submission.review";
        public const string SubmissionDownloadApproved = "submission.download-approved";
        public const string AuditReadAll = "audit.read-all";
        public const string AccessView = "access.view";

        public static IReadOnlyList<string> All { get; } =
        new List<string> { ProjectRead, ProjectCreate, ProjectEdit, SubmissionPrepare, SubmissionWithdraw, SubmissionReopen, SubmissionDownloadInReview, SubmissionReview, SubmissionDownloadApproved, AuditReadAll, AccessView, ReferenceManage, ProjectReadAll, ProjectDelete, UsersManage, UsersApprove, RolesManage, RolesApprove, ReferenceApprove, SubmissionProduction };

        /// <summary>Any of the four Administrator permissions (SRAU or PARAM, Maker or Checker).</summary>
        public static IReadOnlyList<string> Administration { get; } = new List<string> { UsersManage, UsersApprove, RolesManage, RolesApprove };
    }

    /// <summary>Claim types the Platform and the API add for the signed-in user.</summary>
    public static class AppClaimTypes
    {
        /// <summary>One claim per permission the user's roles grant.</summary>
        public const string Permission = "frp:permission";
    }

    /// <summary>Roles, permissions, grants and Active Directory groups, as stored in the database.</summary>
    public sealed class AccessCatalogDto : IRecord<AccessCatalogDto>, IEquatable<AccessCatalogDto>
    {
        public IReadOnlyList<AppRoleDto> Roles { get; set; } = new List<AppRoleDto>();

        public IReadOnlyList<AppPermissionDto> Permissions { get; set; } = new List<AppPermissionDto>();

        public IReadOnlyList<RolePermissionDto> Grants { get; set; } = new List<RolePermissionDto>();

        /// <summary>People given roles in the app by SRAU (in addition to the roles their Active Directory groups grant).</summary>
        public IReadOnlyList<AppUserDto> Users { get; set; } = new List<AppUserDto>();


        /// <summary>The person's entry in the app's user list, or null.</summary>
        public AppUserDto UserNamed(string userName) => string.IsNullOrWhiteSpace(userName)
            ? null
            : Users.FirstOrDefault(u => string.Equals(u.UserName, userName.Trim(), StringComparison.OrdinalIgnoreCase));


        public IReadOnlyList<string> PermissionsOf(IEnumerable<string> roleKeys)
        {
            var roles = roleKeys.ToHashSet(StringComparer.OrdinalIgnoreCase);
            var active = Permissions.Select(p => p.Key).ToHashSet(StringComparer.Ordinal);
            return Grants
                .Where(g => roles.Contains(g.RoleKey) && active.Contains(g.PermissionKey))
                .Select(g => g.PermissionKey)
                .Distinct(StringComparer.Ordinal)
                .ToList();
        }


        /// <summary>The catalog's spelling of each known role key; unknown or inactive roles are dropped.</summary>
        public IReadOnlyList<string> KnownRoles(IEnumerable<string> roleKeys)
        {
            var requested = roleKeys.Select(r => r.Trim()).Where(r => r.Length > 0).ToHashSet(StringComparer.OrdinalIgnoreCase);
            return Roles.Where(r => requested.Contains(r.Key)).Select(r => r.Key).ToList();
        }

        public bool Equals(AccessCatalogDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<AppRoleDto>>.Default.Equals(Roles, other.Roles)
    && EqualityComparer<IReadOnlyList<AppPermissionDto>>.Default.Equals(Permissions, other.Permissions)
    && EqualityComparer<IReadOnlyList<RolePermissionDto>>.Default.Equals(Grants, other.Grants)
    && EqualityComparer<IReadOnlyList<AppUserDto>>.Default.Equals(Users, other.Users);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AccessCatalogDto);
    }

        public static bool operator ==(AccessCatalogDto left, AccessCatalogDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AccessCatalogDto left, AccessCatalogDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 7163;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<AppRoleDto>>.Default.GetHashCode(Roles);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<AppPermissionDto>>.Default.GetHashCode(Permissions);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<RolePermissionDto>>.Default.GetHashCode(Grants);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<AppUserDto>>.Default.GetHashCode(Users);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AccessCatalogDto { " + "Roles = " + Roles + ", " + "Permissions = " + Permissions + ", " + "Grants = " + Grants + ", " + "Users = " + Users + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AccessCatalogDto CloneRecord()
    {
    return (AccessCatalogDto)MemberwiseClone();
    }

    }

    public sealed class AppRoleDto : IRecord<AppRoleDto>, IEquatable<AppRoleDto>
    {
        public string Key { get; set; } = "";

        public string DisplayName { get; set; } = "";

        public string Description { get; set; }

        /// <summary>Active Directory groups whose members get this role.</summary>
        public IReadOnlyList<string> DirectoryGroups { get; set; } = new List<string>();

        public bool Equals(AppRoleDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Key, other.Key)
    && EqualityComparer<string>.Default.Equals(DisplayName, other.DisplayName)
    && EqualityComparer<string>.Default.Equals(Description, other.Description)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(DirectoryGroups, other.DirectoryGroups);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AppRoleDto);
    }

        public static bool operator ==(AppRoleDto left, AppRoleDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AppRoleDto left, AppRoleDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 41223;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Key);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DisplayName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Description);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(DirectoryGroups);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AppRoleDto { " + "Key = " + Key + ", " + "DisplayName = " + DisplayName + ", " + "Description = " + Description + ", " + "DirectoryGroups = " + DirectoryGroups + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AppRoleDto CloneRecord()
    {
    return (AppRoleDto)MemberwiseClone();
    }

    }

    public sealed class AppPermissionDto : IRecord<AppPermissionDto>, IEquatable<AppPermissionDto>
    {
        public string Key { get; set; } = "";

        public string DisplayName { get; set; } = "";

        public bool Equals(AppPermissionDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Key, other.Key)
    && EqualityComparer<string>.Default.Equals(DisplayName, other.DisplayName);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AppPermissionDto);
    }

        public static bool operator ==(AppPermissionDto left, AppPermissionDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AppPermissionDto left, AppPermissionDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 52800;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Key);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DisplayName);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AppPermissionDto { " + "Key = " + Key + ", " + "DisplayName = " + DisplayName + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AppPermissionDto CloneRecord()
    {
    return (AppPermissionDto)MemberwiseClone();
    }

    }

    public sealed class RolePermissionDto : IRecord<RolePermissionDto>, IEquatable<RolePermissionDto>
    {
        public string RoleKey { get; set; } = "";

        public string PermissionKey { get; set; } = "";

        public bool Equals(RolePermissionDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(RoleKey, other.RoleKey)
    && EqualityComparer<string>.Default.Equals(PermissionKey, other.PermissionKey);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as RolePermissionDto);
    }

        public static bool operator ==(RolePermissionDto left, RolePermissionDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(RolePermissionDto left, RolePermissionDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27255;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(RoleKey);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(PermissionKey);
    return hash;
    }
    }

        public override string ToString()
    {
    return "RolePermissionDto { " + "RoleKey = " + RoleKey + ", " + "PermissionKey = " + PermissionKey + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public RolePermissionDto CloneRecord()
    {
    return (RolePermissionDto)MemberwiseClone();
    }

    }

    /// <summary>A test user for Development sign-in (frp.DevelopmentUser).</summary>
    public sealed class DevelopmentUserDto : IRecord<DevelopmentUserDto>, IEquatable<DevelopmentUserDto>
    {
        public string Name { get; set; } = "";

        public IReadOnlyList<string> Roles { get; set; } = new List<string>();

        public bool Equals(DevelopmentUserDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Name, other.Name)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Roles, other.Roles);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as DevelopmentUserDto);
    }

        public static bool operator ==(DevelopmentUserDto left, DevelopmentUserDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(DevelopmentUserDto left, DevelopmentUserDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 30698;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Roles);
    return hash;
    }
    }

        public override string ToString()
    {
    return "DevelopmentUserDto { " + "Name = " + Name + ", " + "Roles = " + Roles + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public DevelopmentUserDto CloneRecord()
    {
    return (DevelopmentUserDto)MemberwiseClone();
    }

    }

    /// <summary>Kinds of file a user can upload; each has its own allowed extensions (FileStorage:AllowedExtensions).</summary>
    public static class UploadKinds
    {
        public const string Xsd = "Xsd";
        public const string Template = "Template";
        public const string Specification = "Specification";
        public const string SubmissionXml = "SubmissionXml";
        public const string XmlToValidate = "XmlToValidate";
        public const string WorkbookToCheck = "WorkbookToCheck";

        public static IReadOnlyList<string> All { get; } = new List<string> { Xsd, Template, Specification, SubmissionXml, XmlToValidate, WorkbookToCheck };
    }

    /// <summary>Whether an upload's content is already stored (it will then be reused, not stored again).</summary>
    public sealed class FileStoredDto : IRecord<FileStoredDto>, IEquatable<FileStoredDto>
    {
        public bool Stored { get; set; }

        public bool Equals(FileStoredDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<bool>.Default.Equals(Stored, other.Stored);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as FileStoredDto);
    }

        public static bool operator ==(FileStoredDto left, FileStoredDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(FileStoredDto left, FileStoredDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 12943;
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Stored);
    return hash;
    }
    }

        public override string ToString()
    {
    return "FileStoredDto { " + "Stored = " + Stored + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public FileStoredDto CloneRecord()
    {
    return (FileStoredDto)MemberwiseClone();
    }

    }

    /// <summary>The uploaded files of an existing project that a new project can reuse (no paths on disk).</summary>
    public sealed class ReusableProjectFilesDto : IRecord<ReusableProjectFilesDto>, IEquatable<ReusableProjectFilesDto>
    {
        public string ProjectId { get; set; } = "";

        public string ProjectName { get; set; } = "";

        public ReusableFileDto Xsd { get; set; }

        /// <summary>Null when the project has no uploaded BSP template (its template was generated from the XSD).</summary>
        public ReusableFileDto Template { get; set; }

        public ReusableFileDto Specification { get; set; }

        public bool Equals(ReusableProjectFilesDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(ProjectId, other.ProjectId)
    && EqualityComparer<string>.Default.Equals(ProjectName, other.ProjectName)
    && EqualityComparer<ReusableFileDto>.Default.Equals(Xsd, other.Xsd)
    && EqualityComparer<ReusableFileDto>.Default.Equals(Template, other.Template)
    && EqualityComparer<ReusableFileDto>.Default.Equals(Specification, other.Specification);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ReusableProjectFilesDto);
    }

        public static bool operator ==(ReusableProjectFilesDto left, ReusableProjectFilesDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ReusableProjectFilesDto left, ReusableProjectFilesDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27429;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ProjectId);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ProjectName);
    hash = hash * -1521134295 + EqualityComparer<ReusableFileDto>.Default.GetHashCode(Xsd);
    hash = hash * -1521134295 + EqualityComparer<ReusableFileDto>.Default.GetHashCode(Template);
    hash = hash * -1521134295 + EqualityComparer<ReusableFileDto>.Default.GetHashCode(Specification);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ReusableProjectFilesDto { " + "ProjectId = " + ProjectId + ", " + "ProjectName = " + ProjectName + ", " + "Xsd = " + Xsd + ", " + "Template = " + Template + ", " + "Specification = " + Specification + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ReusableProjectFilesDto CloneRecord()
    {
    return (ReusableProjectFilesDto)MemberwiseClone();
    }

    }

    public sealed class ReusableFileDto : IRecord<ReusableFileDto>, IEquatable<ReusableFileDto>
    {
        public string FileName { get; set; } = "";

        public long Size { get; set; }

        public bool Equals(ReusableFileDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(FileName, other.FileName)
    && EqualityComparer<long>.Default.Equals(Size, other.Size);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ReusableFileDto);
    }

        public static bool operator ==(ReusableFileDto left, ReusableFileDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ReusableFileDto left, ReusableFileDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 84569;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(FileName);
    hash = hash * -1521134295 + EqualityComparer<long>.Default.GetHashCode(Size);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ReusableFileDto { " + "FileName = " + FileName + ", " + "Size = " + Size + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ReusableFileDto CloneRecord()
    {
    return (ReusableFileDto)MemberwiseClone();
    }

    }

    /// <summary>Upload limits from the API's FileStorage settings, so the UI checks files the same way.</summary>
    public sealed class FileSettingsDto : IRecord<FileSettingsDto>, IEquatable<FileSettingsDto>
    {
        public long MaxUploadBytes { get; set; }

        /// <summary>Largest bank reference file (branch register, sandbox report, source XML) the API accepts.</summary>
        public long MaxReferenceFileBytes { get; set; }

        public IReadOnlyDictionary<string, IReadOnlyList<string>> AllowedExtensions { get; set; } = new Dictionary<string, IReadOnlyList<string>>();


        public IReadOnlyList<string> ExtensionsFor(string kind)  {
        IReadOnlyList<string> extensions;
        return AllowedExtensions.TryGetValue(kind, out extensions) ? extensions : new List<string>();
    }


        /// <summary>For an input's accept attribute, e.g. ".xlsx,.xlsm".</summary>
        public string AcceptFor(string kind) => string.Join(",", ExtensionsFor(kind));


        public bool Allows(string kind, string fileName) =>
            ExtensionsFor(kind).Contains(Path.GetExtension(fileName), StringComparer.OrdinalIgnoreCase);

        public bool Equals(FileSettingsDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<long>.Default.Equals(MaxUploadBytes, other.MaxUploadBytes)
    && EqualityComparer<long>.Default.Equals(MaxReferenceFileBytes, other.MaxReferenceFileBytes)
    && EqualityComparer<IReadOnlyDictionary<string, IReadOnlyList<string>>>.Default.Equals(AllowedExtensions, other.AllowedExtensions);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as FileSettingsDto);
    }

        public static bool operator ==(FileSettingsDto left, FileSettingsDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(FileSettingsDto left, FileSettingsDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 59855;
    hash = hash * -1521134295 + EqualityComparer<long>.Default.GetHashCode(MaxUploadBytes);
    hash = hash * -1521134295 + EqualityComparer<long>.Default.GetHashCode(MaxReferenceFileBytes);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyDictionary<string, IReadOnlyList<string>>>.Default.GetHashCode(AllowedExtensions);
    return hash;
    }
    }

        public override string ToString()
    {
    return "FileSettingsDto { " + "MaxUploadBytes = " + MaxUploadBytes + ", " + "MaxReferenceFileBytes = " + MaxReferenceFileBytes + ", " + "AllowedExtensions = " + AllowedExtensions + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public FileSettingsDto CloneRecord()
    {
    return (FileSettingsDto)MemberwiseClone();
    }

    }

    /// <summary>A person given roles in the app (frp.AppUser). A disabled person gets no role at all.</summary>
    public sealed class AppUserDto : IRecord<AppUserDto>, IEquatable<AppUserDto>
    {
        public string UserName { get; set; } = "";

        public string DisplayName { get; set; }

        public bool IsActive { get; set; } = true;

        public IReadOnlyList<string> Roles { get; set; } = new List<string>();

        /// <summary>The last day of access (null = no end), in the server's local date.</summary>
        public DateOnly? AccessUntil { get; set; }


        /// <summary>True when the person's access ended (the day after <see cref="AccessUntil"/> has begun).</summary>
        public bool HasExpired(DateOnly today)  {
        DateOnly until;
        return CompatPattern.Is(AccessUntil, out until) && until < today;
    }

        public bool Equals(AppUserDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<string>.Default.Equals(DisplayName, other.DisplayName)
    && EqualityComparer<bool>.Default.Equals(IsActive, other.IsActive)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Roles, other.Roles)
    && EqualityComparer<DateOnly?>.Default.Equals(AccessUntil, other.AccessUntil);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AppUserDto);
    }

        public static bool operator ==(AppUserDto left, AppUserDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AppUserDto left, AppUserDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 58236;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DisplayName);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsActive);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Roles);
    hash = hash * -1521134295 + EqualityComparer<DateOnly?>.Default.GetHashCode(AccessUntil);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AppUserDto { " + "UserName = " + UserName + ", " + "DisplayName = " + DisplayName + ", " + "IsActive = " + IsActive + ", " + "Roles = " + Roles + ", " + "AccessUntil = " + AccessUntil + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AppUserDto CloneRecord()
    {
    return (AppUserDto)MemberwiseClone();
    }

    }

    /// <summary>
    /// Segregation of duties. Business users are Makers and Checkers of submissions; the Administrators are two teams,
    /// SRAU (people) and PARAM (roles), each with a Maker who requests changes and a Checker who approves them.
    /// A set of permissions (one role's, or everything one person holds) may not combine: requesting and approving in the
    /// same Administrator team; SRAU with PARAM; or any Administrator permission with preparing or reviewing submissions.
    /// </summary>
    public static class AccessRules
    {
        /// <summary>Permissions of the people who prepare and review submissions (Makers and Checkers).</summary>
        public static ISet<string> BusinessPermissions { get; } = new HashSet<string>(StringComparer.Ordinal)
        {
            Permissions.ProjectCreate, Permissions.ProjectEdit, Permissions.ProjectDelete, Permissions.SubmissionPrepare,
            Permissions.SubmissionWithdraw, Permissions.SubmissionReopen, Permissions.SubmissionReview, Permissions.SubmissionDownloadInReview
        };

        /// <summary>Why these permissions cannot be held together, or null when they can.</summary>
        public static string Conflict(IEnumerable<string> permissions)
        {
            var held = permissions.ToHashSet(StringComparer.Ordinal);
            if (held.Contains(Permissions.UsersManage) && held.Contains(Permissions.UsersApprove))
            {
                return "SRAU Maker (requests) and SRAU Checker (approves) cannot be held together.";
            }

            if (held.Contains(Permissions.RolesManage) && held.Contains(Permissions.RolesApprove))
            {
                return "PARAM Maker (requests) and PARAM Checker (approves) cannot be held together.";
            }

            var users = held.Contains(Permissions.UsersManage) || held.Contains(Permissions.UsersApprove);
            var roles = held.Contains(Permissions.RolesManage) || held.Contains(Permissions.RolesApprove);
            if (users && roles)
            {
                return "Managing people (SRAU) and managing roles (PARAM) cannot be held together.";
            }

            if ((users || roles) && held.Overlaps(BusinessPermissions))
            {
                return $"{(users ? "Managing people (SRAU)" : "Managing roles (PARAM)")} cannot be held together with preparing or reviewing submissions ("
                    + string.Join(", ", held.Intersect(BusinessPermissions).Order(StringComparer.Ordinal)) + ").";
            }

            return null;
        }

        /// <summary>
        /// A person's roles: those their groups (or Development test account) give, plus those SRAU gave them in the app.
        /// None when SRAU disabled them or their access ended (AccessUntil, in the server's local date). <paramref name="conflict"/> is set (and no role is given) when the roles together
        /// break the segregation of duties.
        /// </summary>
        public static IReadOnlyList<string> Resolve(AccessCatalogDto catalog, string userName, IEnumerable<string> otherRoles, out string conflict, out bool disabled)
        {
            conflict = null;
            var user = catalog.UserNamed(userName);
            disabled = user != null && object.Equals(user.IsActive, false) || (user?.HasExpired(DateOnly.FromDateTime(DateTime.Now)) ?? false);
            if (disabled)
            {
                return new List<string>();
            }

            var roles = catalog.KnownRoles(otherRoles.Concat(user?.Roles ?? new List<string>()));
            conflict = Conflict(catalog.PermissionsOf(roles));
            return (conflict == null) ? roles.Distinct(StringComparer.OrdinalIgnoreCase).ToList() : new List<string>();
        }
    }

}
