﻿using System;
using System.Collections.Generic;

namespace FrpMapper.Shared.Models
{
    // COCREE v2.0: BSP's credit data submission (CSDF XML, root CRIMS_Submission_Input). FRP Mapper builds it from the BU's
    // COCREE input workbooks the way the Regulatory Reports Workbench did, using a configuration (input file catalogue,
    // column → XML attribute mapping and code lists) that a Maker uploads and a different Checker approves.

    /// <summary>
    /// The COCREE configuration: the sheets of the Workbench's cocree_config.xlsx (input_files, input_file_sheets,
    /// input_file_sheet_columns, xml_entities, xml_mapping, source_record_type, …), of cocree_dropdown_options.xlsx (one
    /// code list per sheet: input_template → xml_code) and of cocree_validations.xlsx (BSP's validation rules), and
    /// BSP's COCREE XSD when one was uploaded.
    /// </summary>
    public sealed class CocreeConfigDto
    {
        public List<WorkbenchTableDto> Tables { get; set; } = new List<WorkbenchTableDto>();

        public List<WorkbenchTableDto> CodeLists { get; set; } = new List<WorkbenchTableDto>();

        /// <summary>The validation rules workbook (its Validations sheet is the one used).</summary>
        public List<WorkbenchTableDto> Validations { get; set; } = new List<WorkbenchTableDto>();

        /// <summary>BSP's COCREE XSD as text; empty when none was uploaded (the XSD check is then skipped).</summary>
        public string Xsd { get; set; } = "";

        /// <summary>The XSD's file name, e.g. "CSDF.xsd".</summary>
        public string XsdFileName { get; set; } = "";
    }

    /// <summary>An input file the configuration knows, with the sheets it must have (shown on the Generate tab).</summary>
    public sealed class CocreeInputFileDto
    {
        public string Name { get; set; } = "";

        public List<string> Sheets { get; set; } = new List<string>();

        /// <summary>Lower is preferred when the same subject comes from several files.</summary>
        public int SubjectHierarchy { get; set; }
    }

    /// <summary>A provider code the XML may be generated for (from the approved bank profiles).</summary>
    public sealed class CocreeProviderDto
    {
        public string Code { get; set; } = "";

        public string BankKey { get; set; } = "";

        public string BankName { get; set; } = "";
    }

    /// <summary>What the Generate tab needs: the active configuration, the provider codes and BSP's limits.</summary>
    public sealed class CocreeSetupDto
    {
        /// <summary>False when no configuration has been approved yet.</summary>
        public bool Configured { get; set; }

        public WorkbenchConfigVersionDto Configuration { get; set; }

        public List<CocreeInputFileDto> InputFiles { get; set; } = new List<CocreeInputFileDto>();

        public List<CocreeProviderDto> Providers { get; set; } = new List<CocreeProviderDto>();

        public List<string> SubmissionTypes { get; set; } = new List<string>();

        /// <summary>BSP's limit of records in one file (300,000); a larger value up to <see cref="MaxRecordsPerFile"/> may be chosen.</summary>
        public int BspRecordsPerFile { get; set; }

        public int MaxRecordsPerFile { get; set; }

        public long MaxUploadBytes { get; set; }

        /// <summary>How many BSP validation rules the approved configuration has (Validate tab).</summary>
        public int ValidationRules { get; set; }

        /// <summary>The approved configuration's XSD file name; empty when it has none (the XSD check is then skipped).</summary>
        public string XsdFileName { get; set; } = "";
    }

    /// <summary>One message about a COCREE run. Errors stop the XML from being written; warnings and information do not.</summary>
    public sealed class CocreeIssueDto
    {
        /// <summary>Error, Warning or Info.</summary>
        public string Severity { get; set; } = "Error";

        /// <summary>BSP's error code where there is one (e.g. 30-017, 40-004), else empty.</summary>
        public string Code { get; set; } = "";

        public string Message { get; set; } = "";

        /// <summary>The input or output file it is about.</summary>
        public string File { get; set; }

        public string Sheet { get; set; }

        /// <summary>The Excel row (input files), 0 when not about one row.</summary>
        public int Row { get; set; }

        public string Column { get; set; }

        public string Element { get; set; }

        public string ProviderSubjectNo { get; set; }

        public string ProviderContractNo { get; set; }
    }

    /// <summary>How many records of one element (Individuals, Installments, …) a file holds.</summary>
    public sealed class CocreeElementCountDto
    {
        public string Element { get; set; } = "";

        public int Count { get; set; }
    }

    /// <summary>One generated (or updated) CSDF XML file.</summary>
    public sealed class CocreeOutputFileDto
    {
        public string Name { get; set; } = "";

        public long Size { get; set; }

        /// <summary>Footer NumberOfRecords: subjects + contracts + negative events.</summary>
        public int Records { get; set; }

        public int Subjects { get; set; }

        public int Contracts { get; set; }

        public int NegativeEvents { get; set; }

        public List<CocreeElementCountDto> Elements { get; set; } = new List<CocreeElementCountDto>();
    }

    /// <summary>The result of generating CSDF XML from input workbooks.</summary>
    public sealed class CocreeExportResultDto
    {
        /// <summary>True when the XML files were written (no errors).</summary>
        public bool Succeeded { get; set; }

        /// <summary>Where the files can be downloaded (GET /api/cocree/outputs/{id}/{name}); empty when nothing was written.</summary>
        public string OutputId { get; set; } = "";

        public List<CocreeOutputFileDto> Files { get; set; } = new List<CocreeOutputFileDto>();

        public List<CocreeIssueDto> Issues { get; set; } = new List<CocreeIssueDto>();

        /// <summary>The Workbench's error report (Export_to_XML_Result_*.xml) when the subject / exposure checks failed.</summary>
        public string ErrorReport { get; set; }

        public int Subjects { get; set; }

        public int Contracts { get; set; }

        public int NegativeEvents { get; set; }

        /// <summary>What happened, step by step (as the Workbench's log).</summary>
        public List<string> Log { get; set; } = new List<string>();

        /// <summary>The configuration version used.</summary>
        public string ConfigurationId { get; set; } = "";
    }

    /// <summary>The result of adding up the records of several CSDF files of one submission (Workbench: Update Header).</summary>
    public sealed class CocreeHeaderTotalsResultDto
    {
        /// <summary>True when every file was read and checked without errors.</summary>
        public bool Succeeded { get; set; }

        /// <summary>Set when the totals were written into the files: download them from here.</summary>
        public string OutputId { get; set; } = "";

        public List<CocreeOutputFileDto> Files { get; set; } = new List<CocreeOutputFileDto>();

        public List<CocreeIssueDto> Issues { get; set; } = new List<CocreeIssueDto>();

        public int Subjects { get; set; }

        public int Contracts { get; set; }

        public int NegativeEvents { get; set; }
    }
    /// <summary>
    /// One BSP validation rule as a file met it: how many records it found wrong (the rule is FALSE) and how many it could
    /// not decide (no result, usually because an attribute the rule reads is missing).
    /// </summary>
    public sealed class CocreeRuleResultDto
    {
        public string Element { get; set; } = "";

        public string Code { get; set; } = "";

        public string Message { get; set; } = "";

        public int Errors { get; set; }

        public int Undecided { get; set; }

        /// <summary>The identifiers of the first records found wrong (the configuration's include_in_error_report attributes).</summary>
        public List<string> Examples { get; set; } = new List<string>();
    }

    /// <summary>One message of the XSD check (as the Workbench's Validate with XSD listed them).</summary>
    public sealed class XmlSchemaIssueDto
    {
        public int Line { get; set; }

        public int Position { get; set; }

        /// <summary>Error or Warning.</summary>
        public string Severity { get; set; } = "Error";

        public string Message { get; set; } = "";

        /// <summary>The open elements where it happened, e.g. "&lt;CRIMS_Submission_Input&gt;&lt;Body&gt;".</summary>
        public string Path { get; set; } = "";
    }

    /// <summary>The validation of one CSDF file: Stage 1, the preliminary checks, BSP's rules and the XSD.</summary>
    public sealed class CocreeFileValidationDto
    {
        public string Name { get; set; } = "";

        public long Size { get; set; }

        /// <summary>Passed, Failed (errors found) or Stopped (the file could not be checked further, e.g. a Stage 1 error).</summary>
        public string Outcome { get; set; } = "";

        /// <summary>
        /// "Rules" when BSP's rules were applied, "Preliminary" when the preliminary checks (duplicates, data types, links)
        /// found problems and the rules were not applied, as in the Workbench; empty when the file stopped earlier.
        /// </summary>
        public string Stage { get; set; } = "";

        /// <summary>The Workbench's report file (…_Validation_Result_….xml) to download from the run.</summary>
        public string Report { get; set; }

        /// <summary>The XSD check's report file, when the XSD was checked.</summary>
        public string XsdReport { get; set; }

        public int Records { get; set; }

        public int RulesApplied { get; set; }

        public int RecordErrors { get; set; }

        public int Undecided { get; set; }

        /// <summary>Messages of Stage 1 and the preliminary checks.</summary>
        public List<CocreeIssueDto> Issues { get; set; } = new List<CocreeIssueDto>();

        /// <summary>The rules that found something, worst first.</summary>
        public List<CocreeRuleResultDto> Rules { get; set; } = new List<CocreeRuleResultDto>();

        /// <summary>Null when no XSD was checked.</summary>
        public bool? XsdValid { get; set; }

        /// <summary>The first XSD messages (the report has all of them).</summary>
        public List<XmlSchemaIssueDto> XsdIssues { get; set; } = new List<XmlSchemaIssueDto>();

        public int XsdIssueCount { get; set; }
    }

    /// <summary>The result of validating CSDF files (the Workbench's steps 2 and 3).</summary>
    public sealed class CocreeValidationResultDto
    {
        /// <summary>True when every file passed.</summary>
        public bool Succeeded { get; set; }

        /// <summary>Where the reports can be downloaded (GET /api/cocree/outputs/{id}/{name}).</summary>
        public string OutputId { get; set; } = "";

        public string ConfigurationId { get; set; } = "";

        public bool XsdChecked { get; set; }

        public List<CocreeFileValidationDto> Files { get; set; } = new List<CocreeFileValidationDto>();
    }
}
