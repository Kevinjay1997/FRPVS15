using System;
using System.Collections.Generic;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Shared.Models
{
    /// <summary>A new name for a project (PUT projects/{id}/name).</summary>
    public sealed class RenameProjectRequest : IRecord<RenameProjectRequest>, IEquatable<RenameProjectRequest>
    {
        public string Name { get; set; } = "";

        public bool Equals(RenameProjectRequest other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Name, other.Name);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as RenameProjectRequest);
    }

        public static bool operator ==(RenameProjectRequest left, RenameProjectRequest right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(RenameProjectRequest left, RenameProjectRequest right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    return hash;
    }
    }

        public override string ToString()
    {
    return "RenameProjectRequest { " + "Name = " + Name + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public RenameProjectRequest CloneRecord()
    {
    return (RenameProjectRequest)MemberwiseClone();
    }

    }

    /// <summary>What replacing a project's files changed: the files, the mappings and the values carried over.</summary>
    public sealed class ProjectEditSummaryDto : IRecord<ProjectEditSummaryDto>, IEquatable<ProjectEditSummaryDto>
    {
        /// <summary>"XSD", "Excel template", "BSP specification": the files that changed ("BSP specification removed", "Excel template generated from the XSD").</summary>
        public IReadOnlyList<string> FilesReplaced { get; set; } = new List<string>();

        /// <summary>Mappings carried over from before (same field, same sheet and cell).</summary>
        public int MappingsKept { get; set; }

        /// <summary>Mappings the app made from the new files (new fields, or every field when the template's cells were used).</summary>
        public int MappingsFromTemplate { get; set; }

        /// <summary>Mappings whose field is no longer in the XSD, or whose sheet is not in the template.</summary>
        public int MappingsDropped { get; set; }

        /// <summary>XSD fields that were mapped before and are not in the new XSD (at most 50).</summary>
        public IReadOnlyList<string> FieldsRemoved { get; set; } = new List<string>();

        /// <summary>All of them.</summary>
        public int FieldsRemovedCount { get; set; }

        /// <summary>XSD fields that are new.</summary>
        public int FieldsAdded { get; set; }

        /// <summary>Values people entered (or emptied) that were carried over.</summary>
        public int ValuesKept { get; set; }

        /// <summary>Entered values whose field is no longer in the XSD or no longer mapped.</summary>
        public int ValuesDropped { get; set; }

        /// <summary>Sheet copies whose form or key field is no longer in the XSD.</summary>
        public int SheetCopiesDropped { get; set; }

        /// <summary>The XML attached for review was removed (it was made for the old files).</summary>
        public bool SubmissionRemoved { get; set; }

        public bool Equals(ProjectEditSummaryDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<string>>.Default.Equals(FilesReplaced, other.FilesReplaced)
    && EqualityComparer<int>.Default.Equals(MappingsKept, other.MappingsKept)
    && EqualityComparer<int>.Default.Equals(MappingsFromTemplate, other.MappingsFromTemplate)
    && EqualityComparer<int>.Default.Equals(MappingsDropped, other.MappingsDropped)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(FieldsRemoved, other.FieldsRemoved)
    && EqualityComparer<int>.Default.Equals(FieldsRemovedCount, other.FieldsRemovedCount)
    && EqualityComparer<int>.Default.Equals(FieldsAdded, other.FieldsAdded)
    && EqualityComparer<int>.Default.Equals(ValuesKept, other.ValuesKept)
    && EqualityComparer<int>.Default.Equals(ValuesDropped, other.ValuesDropped)
    && EqualityComparer<int>.Default.Equals(SheetCopiesDropped, other.SheetCopiesDropped)
    && EqualityComparer<bool>.Default.Equals(SubmissionRemoved, other.SubmissionRemoved);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ProjectEditSummaryDto);
    }

        public static bool operator ==(ProjectEditSummaryDto left, ProjectEditSummaryDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ProjectEditSummaryDto left, ProjectEditSummaryDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(FilesReplaced);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(MappingsKept);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(MappingsFromTemplate);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(MappingsDropped);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(FieldsRemoved);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(FieldsRemovedCount);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(FieldsAdded);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(ValuesKept);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(ValuesDropped);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(SheetCopiesDropped);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(SubmissionRemoved);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ProjectEditSummaryDto { " + "FilesReplaced = " + FilesReplaced + ", " + "MappingsKept = " + MappingsKept + ", " + "MappingsFromTemplate = " + MappingsFromTemplate + ", " + "MappingsDropped = " + MappingsDropped + ", " + "FieldsRemoved = " + FieldsRemoved + ", " + "FieldsRemovedCount = " + FieldsRemovedCount + ", " + "FieldsAdded = " + FieldsAdded + ", " + "ValuesKept = " + ValuesKept + ", " + "ValuesDropped = " + ValuesDropped + ", " + "SheetCopiesDropped = " + SheetCopiesDropped + ", " + "SubmissionRemoved = " + SubmissionRemoved + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ProjectEditSummaryDto CloneRecord()
    {
    return (ProjectEditSummaryDto)MemberwiseClone();
    }

    }

    /// <summary>The project after its files were replaced, and what changed.</summary>
    public sealed class ProjectEditResultDto : IRecord<ProjectEditResultDto>, IEquatable<ProjectEditResultDto>
    {
        public FrpProjectDto Project { get; set; }

        public ProjectEditSummaryDto Summary { get; set; } = new ProjectEditSummaryDto();

        public bool Equals(ProjectEditResultDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<FrpProjectDto>.Default.Equals(Project, other.Project)
    && EqualityComparer<ProjectEditSummaryDto>.Default.Equals(Summary, other.Summary);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ProjectEditResultDto);
    }

        public static bool operator ==(ProjectEditResultDto left, ProjectEditResultDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ProjectEditResultDto left, ProjectEditResultDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<FrpProjectDto>.Default.GetHashCode(Project);
    hash = hash * -1521134295 + EqualityComparer<ProjectEditSummaryDto>.Default.GetHashCode(Summary);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ProjectEditResultDto { " + "Project = " + Project + ", " + "Summary = " + Summary + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ProjectEditResultDto CloneRecord()
    {
    return (ProjectEditResultDto)MemberwiseClone();
    }

    }

}
