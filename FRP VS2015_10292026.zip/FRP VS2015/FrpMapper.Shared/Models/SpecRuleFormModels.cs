using System;
using System.Collections.Generic;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Shared.Models
{
    /// <summary>How the BSP specification rules of one form (e.g. INTRA) came out: passed, failed, not applicable (nothing to check) and not evaluated (the reason is in the messages).</summary>
    public sealed class SpecRuleFormDto : IRecord<SpecRuleFormDto>, IEquatable<SpecRuleFormDto>
    {
        /// <summary>The form (XML sheet element), e.g. INTRA; "(report)" for rules on the whole report.</summary>
        public string Form { get; set; } = "";

        public int Passed { get; set; }

        public int Failed { get; set; }

        public int NotApplicable { get; set; }

        public int NotEvaluated { get; set; }

        public bool Equals(SpecRuleFormDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Form, other.Form)
    && EqualityComparer<int>.Default.Equals(Passed, other.Passed)
    && EqualityComparer<int>.Default.Equals(Failed, other.Failed)
    && EqualityComparer<int>.Default.Equals(NotApplicable, other.NotApplicable)
    && EqualityComparer<int>.Default.Equals(NotEvaluated, other.NotEvaluated);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SpecRuleFormDto);
    }

        public static bool operator ==(SpecRuleFormDto left, SpecRuleFormDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SpecRuleFormDto left, SpecRuleFormDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Form);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Passed);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Failed);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(NotApplicable);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(NotEvaluated);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SpecRuleFormDto { " + "Form = " + Form + ", " + "Passed = " + Passed + ", " + "Failed = " + Failed + ", " + "NotApplicable = " + NotApplicable + ", " + "NotEvaluated = " + NotEvaluated + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SpecRuleFormDto CloneRecord()
    {
    return (SpecRuleFormDto)MemberwiseClone();
    }

    }

}
