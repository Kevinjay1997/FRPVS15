﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Shared.Models
{
    public sealed class BankProfileDto : IRecord<BankProfileDto>, IEquatable<BankProfileDto>
    {
        public string Key { get; set; } = "";

        public string Name { get; set; } = "";

        public string ProviderCode { get; set; } = "";

        /// <summary>
        /// The undertaking code BSP assigned to this bank for its Report API (reportInfo.undertakingCode of a submission).
        /// Digits only; null until a Checker approves one. Kept apart from <see cref="ProviderCode"/> (the XML
        /// Header/Undertaking value) because BSP may issue a different code for the API.
        /// </summary>
        public string BspUndertakingCode { get; set; }

        public string BankGroup { get; set; }

        public string ParentBankGroup { get; set; }

        public bool? IsDomestic { get; set; }

        public bool? IsSubsidiaryForeign { get; set; }

        public bool? IsBranchForeign { get; set; }

        public bool? HasTrustLicense { get; set; }

        public bool? HasEmoneyLicense { get; set; }

        public int? SubsidiaryCount { get; set; }

        public bool BranchRegisterComplete { get; set; }

        public List<BankBranchDto> Branches { get; set; } = new List<BankBranchDto>();

        public long Version { get; set; }

        public bool Equals(BankProfileDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Key, other.Key)
    && EqualityComparer<string>.Default.Equals(Name, other.Name)
    && EqualityComparer<string>.Default.Equals(ProviderCode, other.ProviderCode)
    && EqualityComparer<string>.Default.Equals(BspUndertakingCode, other.BspUndertakingCode)
    && EqualityComparer<string>.Default.Equals(BankGroup, other.BankGroup)
    && EqualityComparer<string>.Default.Equals(ParentBankGroup, other.ParentBankGroup)
    && EqualityComparer<bool?>.Default.Equals(IsDomestic, other.IsDomestic)
    && EqualityComparer<bool?>.Default.Equals(IsSubsidiaryForeign, other.IsSubsidiaryForeign)
    && EqualityComparer<bool?>.Default.Equals(IsBranchForeign, other.IsBranchForeign)
    && EqualityComparer<bool?>.Default.Equals(HasTrustLicense, other.HasTrustLicense)
    && EqualityComparer<bool?>.Default.Equals(HasEmoneyLicense, other.HasEmoneyLicense)
    && EqualityComparer<int?>.Default.Equals(SubsidiaryCount, other.SubsidiaryCount)
    && EqualityComparer<bool>.Default.Equals(BranchRegisterComplete, other.BranchRegisterComplete)
    && EqualityComparer<List<BankBranchDto>>.Default.Equals(Branches, other.Branches)
    && EqualityComparer<long>.Default.Equals(Version, other.Version);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as BankProfileDto);
    }

        public static bool operator ==(BankProfileDto left, BankProfileDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(BankProfileDto left, BankProfileDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 91395;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Key);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ProviderCode);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(BspUndertakingCode);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(BankGroup);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ParentBankGroup);
    hash = hash * -1521134295 + EqualityComparer<bool?>.Default.GetHashCode(IsDomestic);
    hash = hash * -1521134295 + EqualityComparer<bool?>.Default.GetHashCode(IsSubsidiaryForeign);
    hash = hash * -1521134295 + EqualityComparer<bool?>.Default.GetHashCode(IsBranchForeign);
    hash = hash * -1521134295 + EqualityComparer<bool?>.Default.GetHashCode(HasTrustLicense);
    hash = hash * -1521134295 + EqualityComparer<bool?>.Default.GetHashCode(HasEmoneyLicense);
    hash = hash * -1521134295 + EqualityComparer<int?>.Default.GetHashCode(SubsidiaryCount);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(BranchRegisterComplete);
    hash = hash * -1521134295 + EqualityComparer<List<BankBranchDto>>.Default.GetHashCode(Branches);
    hash = hash * -1521134295 + EqualityComparer<long>.Default.GetHashCode(Version);
    return hash;
    }
    }

        public override string ToString()
    {
    return "BankProfileDto { " + "Key = " + Key + ", " + "Name = " + Name + ", " + "ProviderCode = " + ProviderCode + ", " + "BspUndertakingCode = " + BspUndertakingCode + ", " + "BankGroup = " + BankGroup + ", " + "ParentBankGroup = " + ParentBankGroup + ", " + "IsDomestic = " + IsDomestic + ", " + "IsSubsidiaryForeign = " + IsSubsidiaryForeign + ", " + "IsBranchForeign = " + IsBranchForeign + ", " + "HasTrustLicense = " + HasTrustLicense + ", " + "HasEmoneyLicense = " + HasEmoneyLicense + ", " + "SubsidiaryCount = " + SubsidiaryCount + ", " + "BranchRegisterComplete = " + BranchRegisterComplete + ", " + "Branches = " + Branches + ", " + "Version = " + Version + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public BankProfileDto CloneRecord()
    {
    return (BankProfileDto)MemberwiseClone();
    }

    }
    /// <summary>Branch names as the register keeps them.</summary>
    public static class BankBranchNames
    {
        /// <summary>
        /// The branch's own name: "EAST WEST BANKING CORP  -168 MALL" becomes "168 MALL" for the bank named
        /// "EAST WEST BANKING CORP". Spaces are collapsed; a name that is only the bank's name (the head office) is kept.
        /// </summary>
        public static string Short(string name, string bankName)
        {
            var text = System.Text.RegularExpressions.Regex.Replace(name ?? "", @"\s+", " ").Trim();
            var bank = System.Text.RegularExpressions.Regex.Replace(bankName ?? "", @"\s+", " ").Trim();
            if (bank.Length == 0 || !text.StartsWith(bank, StringComparison.OrdinalIgnoreCase))
            {
                return text;
            }

            var rest = text.Substring(bank.Length).TrimStart();
            if (!rest.StartsWith("-", StringComparison.Ordinal))
            {
                return text;
            }

            rest = rest.Substring(1).Trim();
            return rest.Length == 0 ? text : rest;
        }
    }

    public sealed class BankBranchDto : IRecord<BankBranchDto>, IEquatable<BankBranchDto>
    {
        public string Code { get; set; } = "";

        public string Region { get; set; } = "";

        public bool IsDomestic { get; set; } = true;

        /// <summary>The branch's name, without the bank's own name (e.g. "168 MALL"); empty when not known.</summary>
        public string Name { get; set; } = "";

        public bool Equals(BankBranchDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Code, other.Code)
    && EqualityComparer<string>.Default.Equals(Region, other.Region)
    && EqualityComparer<bool>.Default.Equals(IsDomestic, other.IsDomestic)
    && EqualityComparer<string>.Default.Equals(Name, other.Name);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as BankBranchDto);
    }

        public static bool operator ==(BankBranchDto left, BankBranchDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(BankBranchDto left, BankBranchDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 13232;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Code);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Region);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsDomestic);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    return hash;
    }
    }

        public override string ToString()
    {
    return "BankBranchDto { " + "Code = " + Code + ", " + "Region = " + Region + ", " + "IsDomestic = " + IsDomestic + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public BankBranchDto CloneRecord()
    {
    return (BankBranchDto)MemberwiseClone();
    }

    }
    public sealed class SandboxImportDto : IRecord<SandboxImportDto>, IEquatable<SandboxImportDto>
    {
        public string Id { get; set; } = Guid.NewGuid().ToString("N");

        public string BankKey { get; set; } = "";

        public string ProviderCode { get; set; } = "";

        public string ProjectId { get; set; } = "";

        public string Report { get; set; } = "";

        public string Namespace { get; set; } = "";

        public string Period { get; set; } = "";

        public string SpecificationHash { get; set; } = "";

        public string FileName { get; set; } = "";

        public string Sha256 { get; set; } = "";

        public DateTimeOffset ImportedAt { get; set; } = DateTimeOffset.UtcNow;

        public int FindingCount { get; set; }

        public List<FieldExclusionDto> Exclusions { get; set; } = new List<FieldExclusionDto>();

        public List<HistoricalValueDto> HistoricalValues { get; set; } = new List<HistoricalValueDto>();

        public List<string> Warnings { get; set; } = new List<string>();

        public bool Equals(SandboxImportDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Id, other.Id)
    && EqualityComparer<string>.Default.Equals(BankKey, other.BankKey)
    && EqualityComparer<string>.Default.Equals(ProviderCode, other.ProviderCode)
    && EqualityComparer<string>.Default.Equals(ProjectId, other.ProjectId)
    && EqualityComparer<string>.Default.Equals(Report, other.Report)
    && EqualityComparer<string>.Default.Equals(Namespace, other.Namespace)
    && EqualityComparer<string>.Default.Equals(Period, other.Period)
    && EqualityComparer<string>.Default.Equals(SpecificationHash, other.SpecificationHash)
    && EqualityComparer<string>.Default.Equals(FileName, other.FileName)
    && EqualityComparer<string>.Default.Equals(Sha256, other.Sha256)
    && EqualityComparer<DateTimeOffset>.Default.Equals(ImportedAt, other.ImportedAt)
    && EqualityComparer<int>.Default.Equals(FindingCount, other.FindingCount)
    && EqualityComparer<List<FieldExclusionDto>>.Default.Equals(Exclusions, other.Exclusions)
    && EqualityComparer<List<HistoricalValueDto>>.Default.Equals(HistoricalValues, other.HistoricalValues)
    && EqualityComparer<List<string>>.Default.Equals(Warnings, other.Warnings);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SandboxImportDto);
    }

        public static bool operator ==(SandboxImportDto left, SandboxImportDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SandboxImportDto left, SandboxImportDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 28740;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Id);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(BankKey);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ProviderCode);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ProjectId);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Report);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Namespace);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Period);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SpecificationHash);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(FileName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Sha256);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(ImportedAt);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(FindingCount);
    hash = hash * -1521134295 + EqualityComparer<List<FieldExclusionDto>>.Default.GetHashCode(Exclusions);
    hash = hash * -1521134295 + EqualityComparer<List<HistoricalValueDto>>.Default.GetHashCode(HistoricalValues);
    hash = hash * -1521134295 + EqualityComparer<List<string>>.Default.GetHashCode(Warnings);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SandboxImportDto { " + "Id = " + Id + ", " + "BankKey = " + BankKey + ", " + "ProviderCode = " + ProviderCode + ", " + "ProjectId = " + ProjectId + ", " + "Report = " + Report + ", " + "Namespace = " + Namespace + ", " + "Period = " + Period + ", " + "SpecificationHash = " + SpecificationHash + ", " + "FileName = " + FileName + ", " + "Sha256 = " + Sha256 + ", " + "ImportedAt = " + ImportedAt + ", " + "FindingCount = " + FindingCount + ", " + "Exclusions = " + Exclusions + ", " + "HistoricalValues = " + HistoricalValues + ", " + "Warnings = " + Warnings + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SandboxImportDto CloneRecord()
    {
    return (SandboxImportDto)MemberwiseClone();
    }

    }
    public sealed class FieldExclusionDto : IRecord<FieldExclusionDto>, IEquatable<FieldExclusionDto>
    {
        public string Reference { get; set; }

        public string Selector { get; set; }

        public string Evidence { get; set; }

        public FieldExclusionDto(string Reference, string Selector, string Evidence)
    {
    this.Reference = Reference;
    this.Selector = Selector;
    this.Evidence = Evidence;
    }

        public void Deconstruct(out string Reference, out string Selector, out string Evidence)
    {
    Reference = this.Reference;
    Selector = this.Selector;
    Evidence = this.Evidence;
    }

        public bool Equals(FieldExclusionDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Reference, other.Reference)
    && EqualityComparer<string>.Default.Equals(Selector, other.Selector)
    && EqualityComparer<string>.Default.Equals(Evidence, other.Evidence);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as FieldExclusionDto);
    }

        public static bool operator ==(FieldExclusionDto left, FieldExclusionDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(FieldExclusionDto left, FieldExclusionDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 72986;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Reference);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Selector);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Evidence);
    return hash;
    }
    }

        public override string ToString()
    {
    return "FieldExclusionDto { " + "Reference = " + Reference + ", " + "Selector = " + Selector + ", " + "Evidence = " + Evidence + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public FieldExclusionDto CloneRecord()
    {
    return (FieldExclusionDto)MemberwiseClone();
    }

    }
    public sealed class HistoricalValueDto : IRecord<HistoricalValueDto>, IEquatable<HistoricalValueDto>
    {
        public string RuleCode { get; set; }

        public string Formula { get; set; }

        public decimal Value { get; set; }

        public string Evidence { get; set; }

        public HistoricalValueDto(string RuleCode, string Formula, decimal Value, string Evidence)
    {
    this.RuleCode = RuleCode;
    this.Formula = Formula;
    this.Value = Value;
    this.Evidence = Evidence;
    }

        public void Deconstruct(out string RuleCode, out string Formula, out decimal Value, out string Evidence)
    {
    RuleCode = this.RuleCode;
    Formula = this.Formula;
    Value = this.Value;
    Evidence = this.Evidence;
    }

        public bool Equals(HistoricalValueDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(RuleCode, other.RuleCode)
    && EqualityComparer<string>.Default.Equals(Formula, other.Formula)
    && EqualityComparer<decimal>.Default.Equals(Value, other.Value)
    && EqualityComparer<string>.Default.Equals(Evidence, other.Evidence);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as HistoricalValueDto);
    }

        public static bool operator ==(HistoricalValueDto left, HistoricalValueDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(HistoricalValueDto left, HistoricalValueDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 75831;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(RuleCode);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Formula);
    hash = hash * -1521134295 + EqualityComparer<decimal>.Default.GetHashCode(Value);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Evidence);
    return hash;
    }
    }

        public override string ToString()
    {
    return "HistoricalValueDto { " + "RuleCode = " + RuleCode + ", " + "Formula = " + Formula + ", " + "Value = " + Value + ", " + "Evidence = " + Evidence + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public HistoricalValueDto CloneRecord()
    {
    return (HistoricalValueDto)MemberwiseClone();
    }

    }
    public sealed class ReferenceDataDto : IRecord<ReferenceDataDto>, IEquatable<ReferenceDataDto>
    {
        public List<BankProfileDto> Banks { get; set; } = new List<BankProfileDto>();

        public List<SandboxImportDto> Imports { get; set; } = new List<SandboxImportDto>();

        /// <summary>Bank profile changes waiting for a Checker, then the latest decided ones.</summary>
        public List<BankProfileRequestDto> Requests { get; set; } = new List<BankProfileRequestDto>();

        public bool Equals(ReferenceDataDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<List<BankProfileDto>>.Default.Equals(Banks, other.Banks)
    && EqualityComparer<List<SandboxImportDto>>.Default.Equals(Imports, other.Imports)
    && EqualityComparer<List<BankProfileRequestDto>>.Default.Equals(Requests, other.Requests);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ReferenceDataDto);
    }

        public static bool operator ==(ReferenceDataDto left, ReferenceDataDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ReferenceDataDto left, ReferenceDataDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 97243;
    hash = hash * -1521134295 + EqualityComparer<List<BankProfileDto>>.Default.GetHashCode(Banks);
    hash = hash * -1521134295 + EqualityComparer<List<SandboxImportDto>>.Default.GetHashCode(Imports);
    hash = hash * -1521134295 + EqualityComparer<List<BankProfileRequestDto>>.Default.GetHashCode(Requests);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ReferenceDataDto { " + "Banks = " + Banks + ", " + "Imports = " + Imports + ", " + "Requests = " + Requests + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ReferenceDataDto CloneRecord()
    {
    return (ReferenceDataDto)MemberwiseClone();
    }

    }

    /// <summary>A Maker's change to one bank profile (branches included), applied only when a Checker approves it.</summary>
    public sealed class BankProfileRequestDto : IRecord<BankProfileRequestDto>, IEquatable<BankProfileRequestDto>
    {
        public string Id { get; set; } = "";

        public string BankKey { get; set; } = "";

        /// <summary>The profile version the change was made from (0 = a new bank).</summary>
        public long BaseVersion { get; set; }

        public BankProfileDto Proposed { get; set; } = new BankProfileDto();

        /// <summary>The profile when the change was requested (null for a new bank).</summary>
        public BankProfileDto Before { get; set; }

        public string Summary { get; set; } = "";

        public string Status { get; set; } = AccessRequestStatus.Pending;

        public string RequestedBy { get; set; } = "";

        public DateTimeOffset RequestedAt { get; set; }

        public string DecidedBy { get; set; }

        public DateTimeOffset? DecidedAt { get; set; }

        public string DecisionComment { get; set; }

        /// <summary>The request's version when read; a decision is refused when it changed since.</summary>
        public string Version { get; set; } = "";


        /// <summary>The fields this request changes. Sent to the page (the Checker's Before / After table); ignored when read.</summary>
        public IReadOnlyList<FieldChangeDto> Changes => BankProfileChanges.Compare(Before, Proposed);

        public bool Equals(BankProfileRequestDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Id, other.Id)
    && EqualityComparer<string>.Default.Equals(BankKey, other.BankKey)
    && EqualityComparer<long>.Default.Equals(BaseVersion, other.BaseVersion)
    && EqualityComparer<BankProfileDto>.Default.Equals(Proposed, other.Proposed)
    && EqualityComparer<BankProfileDto>.Default.Equals(Before, other.Before)
    && EqualityComparer<string>.Default.Equals(Summary, other.Summary)
    && EqualityComparer<string>.Default.Equals(Status, other.Status)
    && EqualityComparer<string>.Default.Equals(RequestedBy, other.RequestedBy)
    && EqualityComparer<DateTimeOffset>.Default.Equals(RequestedAt, other.RequestedAt)
    && EqualityComparer<string>.Default.Equals(DecidedBy, other.DecidedBy)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(DecidedAt, other.DecidedAt)
    && EqualityComparer<string>.Default.Equals(DecisionComment, other.DecisionComment)
    && EqualityComparer<string>.Default.Equals(Version, other.Version);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as BankProfileRequestDto);
    }

        public static bool operator ==(BankProfileRequestDto left, BankProfileRequestDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(BankProfileRequestDto left, BankProfileRequestDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 12588;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Id);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(BankKey);
    hash = hash * -1521134295 + EqualityComparer<long>.Default.GetHashCode(BaseVersion);
    hash = hash * -1521134295 + EqualityComparer<BankProfileDto>.Default.GetHashCode(Proposed);
    hash = hash * -1521134295 + EqualityComparer<BankProfileDto>.Default.GetHashCode(Before);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Summary);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Status);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(RequestedBy);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset>.Default.GetHashCode(RequestedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DecidedBy);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(DecidedAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DecisionComment);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Version);
    return hash;
    }
    }

        public override string ToString()
    {
    return "BankProfileRequestDto { " + "Id = " + Id + ", " + "BankKey = " + BankKey + ", " + "BaseVersion = " + BaseVersion + ", " + "Proposed = " + Proposed + ", " + "Before = " + Before + ", " + "Summary = " + Summary + ", " + "Status = " + Status + ", " + "RequestedBy = " + RequestedBy + ", " + "RequestedAt = " + RequestedAt + ", " + "DecidedBy = " + DecidedBy + ", " + "DecidedAt = " + DecidedAt + ", " + "DecisionComment = " + DecisionComment + ", " + "Version = " + Version + ", " + "Changes = " + Changes + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public BankProfileRequestDto CloneRecord()
    {
    return (BankProfileRequestDto)MemberwiseClone();
    }

    }

    /// <summary>One changed field: its old and new value, as shown to the Checker and in maintenance reports.</summary>
    public sealed class FieldChangeDto : IRecord<FieldChangeDto>, IEquatable<FieldChangeDto>
    {
        public string Field { get; set; }

        public string Before { get; set; }

        public string After { get; set; }

        public FieldChangeDto(string Field, string Before, string After)
    {
    this.Field = Field;
    this.Before = Before;
    this.After = After;
    }

        public void Deconstruct(out string Field, out string Before, out string After)
    {
    Field = this.Field;
    Before = this.Before;
    After = this.After;
    }

        public bool Equals(FieldChangeDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Field, other.Field)
    && EqualityComparer<string>.Default.Equals(Before, other.Before)
    && EqualityComparer<string>.Default.Equals(After, other.After);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as FieldChangeDto);
    }

        public static bool operator ==(FieldChangeDto left, FieldChangeDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(FieldChangeDto left, FieldChangeDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 78074;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Field);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Before);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(After);
    return hash;
    }
    }

        public override string ToString()
    {
    return "FieldChangeDto { " + "Field = " + Field + ", " + "Before = " + Before + ", " + "After = " + After + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public FieldChangeDto CloneRecord()
    {
    return (FieldChangeDto)MemberwiseClone();
    }

    }

    /// <summary>The fields that differ between two bank profiles (branches summarised: added, removed, changed).</summary>
    public static class BankProfileChanges
    {
        public static IReadOnlyList<FieldChangeDto> Compare(BankProfileDto before, BankProfileDto after)
        {
            var changes = new List<FieldChangeDto>();
            Action<string, object, object> Field = null;
            Field = (string name, object oldArg, object nowArg) =>
            {
                var o = Text(oldArg);
                var n = Text(nowArg);
                if ((before == null) ? n != "—" : o != n)
                {
                    changes.Add(new FieldChangeDto(name, (before == null) ? "—" : o, n));
                }
            };

            Field("Bank key", before?.Key, after.Key);
            Field("BSP undertaking name", before?.Name, after.Name);
            Field("Provider code", before?.ProviderCode, after.ProviderCode);
            Field("BSP API undertaking code", before?.BspUndertakingCode, after.BspUndertakingCode);
            Field("Bank group", before?.BankGroup, after.BankGroup);
            Field("Parent bank group", before?.ParentBankGroup, after.ParentBankGroup);
            Field("Domestic", before?.IsDomestic, after.IsDomestic);
            Field("Subsidiary of a foreign bank", before?.IsSubsidiaryForeign, after.IsSubsidiaryForeign);
            Field("Branch of a foreign bank", before?.IsBranchForeign, after.IsBranchForeign);
            Field("Trust licence", before?.HasTrustLicense, after.HasTrustLicense);
            Field("E-money licence", before?.HasEmoneyLicense, after.HasEmoneyLicense);
            Field("Subsidiary count", before?.SubsidiaryCount, after.SubsidiaryCount);
            Field("Complete branch register", before?.BranchRegisterComplete, after.BranchRegisterComplete);

            var old = (before?.Branches ?? new List<BankBranchDto>()).GroupBy(b => b.Code.Trim(), StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var now = after.Branches.GroupBy(b => b.Code.Trim(), StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var added = now.Keys.Where(k => !old.ContainsKey(k)).Order(StringComparer.OrdinalIgnoreCase).ToList();
            var removed = old.Keys.Where(k => !now.ContainsKey(k)).Order(StringComparer.OrdinalIgnoreCase).ToList();
            var changed = now.Keys.Where(k => { BankBranchDto o; return old.TryGetValue(k, out o) && (!string.Equals(o.Region, now[k].Region, StringComparison.Ordinal) || o.IsDomestic != now[k].IsDomestic || !string.Equals(o.Name ?? "", now[k].Name ?? "", StringComparison.Ordinal)); })
                .Order(StringComparer.OrdinalIgnoreCase).ToList();
            if (added.Count + removed.Count + changed.Count > 0)
            {
                var parts = new List<string>();
                if (added.Count > 0) parts.Add($"added {added.Count}: {List(added)}");
                if (removed.Count > 0) parts.Add($"removed {removed.Count}: {List(removed)}");
                if (changed.Count > 0) parts.Add($"name, region or domestic changed {changed.Count}: {List(changed)}");
                changes.Add(new FieldChangeDto("Branches", $"{old.Count} branches", $"{now.Count} branches; " + string.Join("; ", parts)));
            }

            return changes;
        }

        private static string Text(object value)  {
        string s__2;
        bool b__1;
        return value == null ? "—" : CompatPattern.Is(value, out b__1) ? (b__1 ? "Yes" : "No") : CompatPattern.Is(value, out s__2) && string.IsNullOrWhiteSpace(s__2) ? "—" : Convert.ToString(value, System.Globalization.CultureInfo.InvariantCulture).Trim();
    }

            private static string List(List<string> codes)
    {
        return string.Join(", ", codes.Take(20)) + (codes.Count > 20 ? $" and {codes.Count - 20} more" : "");
    }
    }

}
