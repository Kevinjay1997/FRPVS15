using System.Collections.Generic;

namespace FrpMapper.Shared.Models
{
    /// <summary>One finding in a BSP environment's validation result.</summary>
    public sealed class BspFindingDto
    {
        /// <summary>BSP's rule code, e.g. ASSERTION-RIN-B1690, COND-0001 or DYN-0002.</summary>
        public string Code { get; set; } = "";

        /// <summary>Error, Warning or Info (Error when BSP gives none).</summary>
        public string Severity { get; set; } = "Error";

        public string Message { get; set; } = "";

        /// <summary>BSP's field reference, e.g. [BRIS_DL][MAIN_Y1:233][C0010], when it gives one.</summary>
        public string Location { get; set; }

        /// <summary>From the reference: the form (first part), the table and row (the part with ":row").</summary>
        public string Form { get; set; }
        public string Table { get; set; }
        public int? Row { get; set; }
    }

    /// <summary>What was read from a validation result: its format (xml, json, text, pdf, empty) and the findings.</summary>
    public sealed class BspFindingsReadDto
    {
        public string Format { get; set; } = "";
        public List<BspFindingDto> Findings { get; set; } = new List<BspFindingDto>();
    }

    /// <summary>A file validated on the Validate page, sent to a BSP test environment.</summary>
    public sealed class SandboxValidationDto
    {
        public string Environment { get; set; } = "";
        public string EnvironmentName { get; set; } = "";
        public string BankKey { get; set; } = "";
        public string FileName { get; set; } = "";
        public string ReportCode { get; set; } = "";
        public string Period { get; set; } = "";
        public int StatusCode { get; set; }
        /// <summary>BSP's answer to the submission.</summary>
        public string Body { get; set; } = "";
        /// <summary>The submission ID in BSP's answer, or null when it has none (then BSP refused the submission).</summary>
        public string SubmissionId { get; set; }
    }

    /// <summary>BSP's validation result for a submission, read into findings.</summary>
    public sealed class SandboxFindingsDto
    {
        /// <summary>False while BSP has no result yet (or refused the request): see StatusCode and Body.</summary>
        public bool Ready { get; set; }
        public int StatusCode { get; set; }
        /// <summary>BSP's answer when it is not a result (at most 4,000 characters).</summary>
        public string Body { get; set; }
        public string Format { get; set; } = "";
        public string SubmissionId { get; set; } = "";
        public List<BspFindingDto> Findings { get; set; } = new List<BspFindingDto>();
    }

    /// <summary>
    /// The BSP submission parameters read from a report XML: the report code (its root element: BSP's XSDs have no code
    /// in the Header), the period (Header Year and Period) and the bank (the profile whose provider code is the Header's
    /// Undertaking). Empty when the XML does not give it; the person can still change each one.
    /// </summary>
    public sealed class SandboxParametersDto
    {
        public string ReportCode { get; set; } = "";
        /// <summary>YYYY-MM, or empty when the Header has no valid Year and month Period.</summary>
        public string Period { get; set; } = "";
        /// <summary>The Header's Undertaking as written.</summary>
        public string Undertaking { get; set; } = "";
        /// <summary>The bank profile with that provider code, or null when none (or several) match.</summary>
        public string BankKey { get; set; }
        public string BankName { get; set; }
        public bool HasStoredCertificate { get; set; }
        public string FileName { get; set; } = "";
    }
}
