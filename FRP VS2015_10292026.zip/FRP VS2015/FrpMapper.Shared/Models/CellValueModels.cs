﻿using System;
using System.Collections.Generic;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Shared.Models
{
    /// <summary>Values typed into mapped cells (the Sheet view saves them as they are entered).</summary>
    public sealed class SaveValuesRequest : IRecord<SaveValuesRequest>, IEquatable<SaveValuesRequest>
    {
        public IReadOnlyList<CellValueDto> Values { get; set; } = new List<CellValueDto>();

        public bool Equals(SaveValuesRequest other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<CellValueDto>>.Default.Equals(Values, other.Values);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SaveValuesRequest);
    }

        public static bool operator ==(SaveValuesRequest left, SaveValuesRequest right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SaveValuesRequest left, SaveValuesRequest right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<CellValueDto>>.Default.GetHashCode(Values);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SaveValuesRequest { " + "Values = " + Values + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SaveValuesRequest CloneRecord()
    {
    return (SaveValuesRequest)MemberwiseClone();
    }

    }

    /// <summary>The value of one mapped XSD field: blank empties the cell (no sample value); null puts the sample value back.</summary>
    public sealed class CellValueDto : IRecord<CellValueDto>, IEquatable<CellValueDto>
    {
        public string SchemaPath { get; set; } = "";

        public string Value { get; set; }

        public bool Equals(CellValueDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(SchemaPath, other.SchemaPath)
    && EqualityComparer<string>.Default.Equals(Value, other.Value);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as CellValueDto);
    }

        public static bool operator ==(CellValueDto left, CellValueDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(CellValueDto left, CellValueDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SchemaPath);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Value);
    return hash;
    }
    }

        public override string ToString()
    {
    return "CellValueDto { " + "SchemaPath = " + SchemaPath + ", " + "Value = " + Value + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public CellValueDto CloneRecord()
    {
    return (CellValueDto)MemberwiseClone();
    }

    }

    /// <summary>Why a typed value was refused: the XSD rules it breaks.</summary>
    public sealed class ValueErrorDto : IRecord<ValueErrorDto>, IEquatable<ValueErrorDto>
    {
        public string SchemaPath { get; set; } = "";

        public IReadOnlyList<string> Errors { get; set; } = new List<string>();

        public bool Equals(ValueErrorDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(SchemaPath, other.SchemaPath)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Errors, other.Errors);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ValueErrorDto);
    }

        public static bool operator ==(ValueErrorDto left, ValueErrorDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ValueErrorDto left, ValueErrorDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SchemaPath);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Errors);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ValueErrorDto { " + "SchemaPath = " + SchemaPath + ", " + "Errors = " + Errors + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ValueErrorDto CloneRecord()
    {
    return (ValueErrorDto)MemberwiseClone();
    }

    }

    /// <summary>The saved project, or (nothing saved) the values that break the XSD rules.</summary>
    public sealed class SaveValuesResultDto : IRecord<SaveValuesResultDto>, IEquatable<SaveValuesResultDto>
    {
        /// <summary>The project as saved; null when a value was refused.</summary>
        public FrpProjectDto Project { get; set; }

        /// <summary>The refused values; empty when everything was saved.</summary>
        public IReadOnlyList<ValueErrorDto> Errors { get; set; } = new List<ValueErrorDto>();

        public bool Equals(SaveValuesResultDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<FrpProjectDto>.Default.Equals(Project, other.Project)
    && EqualityComparer<IReadOnlyList<ValueErrorDto>>.Default.Equals(Errors, other.Errors);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SaveValuesResultDto);
    }

        public static bool operator ==(SaveValuesResultDto left, SaveValuesResultDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SaveValuesResultDto left, SaveValuesResultDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<FrpProjectDto>.Default.GetHashCode(Project);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<ValueErrorDto>>.Default.GetHashCode(Errors);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SaveValuesResultDto { " + "Project = " + Project + ", " + "Errors = " + Errors + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SaveValuesResultDto CloneRecord()
    {
    return (SaveValuesResultDto)MemberwiseClone();
    }

    }

    /// <summary>Removes or restores the sample values of one sheet (SheetName) or the whole project (no SheetName).</summary>
    public sealed class SampleValuesRequest : IRecord<SampleValuesRequest>, IEquatable<SampleValuesRequest>
    {
        /// <summary>"remove" (empty every field still holding its sample value) or "restore" (give emptied fields their sample value).</summary>
        public string Action { get; set; } = "";

        /// <summary>The sheet to change; null or empty for every sheet.</summary>
        public string SheetName { get; set; }

        public bool Equals(SampleValuesRequest other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Action, other.Action)
    && EqualityComparer<string>.Default.Equals(SheetName, other.SheetName);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SampleValuesRequest);
    }

        public static bool operator ==(SampleValuesRequest left, SampleValuesRequest right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SampleValuesRequest left, SampleValuesRequest right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Action);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SheetName);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SampleValuesRequest { " + "Action = " + Action + ", " + "SheetName = " + SheetName + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SampleValuesRequest CloneRecord()
    {
    return (SampleValuesRequest)MemberwiseClone();
    }

    }

    /// <summary>The project after removing or restoring sample values, and how many fields changed.</summary>
    public sealed class SampleValuesResultDto : IRecord<SampleValuesResultDto>, IEquatable<SampleValuesResultDto>
    {
        public FrpProjectDto Project { get; set; }

        public int Changed { get; set; }

        public bool Equals(SampleValuesResultDto other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<FrpProjectDto>.Default.Equals(Project, other.Project)
    && EqualityComparer<int>.Default.Equals(Changed, other.Changed);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SampleValuesResultDto);
    }

        public static bool operator ==(SampleValuesResultDto left, SampleValuesResultDto right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SampleValuesResultDto left, SampleValuesResultDto right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 27009;
    hash = hash * -1521134295 + EqualityComparer<FrpProjectDto>.Default.GetHashCode(Project);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Changed);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SampleValuesResultDto { " + "Project = " + Project + ", " + "Changed = " + Changed + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SampleValuesResultDto CloneRecord()
    {
    return (SampleValuesResultDto)MemberwiseClone();
    }

    }

}
