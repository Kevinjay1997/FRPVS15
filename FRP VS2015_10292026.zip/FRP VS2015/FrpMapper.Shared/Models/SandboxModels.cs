namespace FrpMapper.Shared.Models
{
    public sealed class SandboxResponse
    {
        public int StatusCode { get; set; }
        public string Body { get; set; }
        public byte[] FileBytes { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }
    }
    public sealed class SandboxCertificateInfo
    {
        /// <summary>The certificate's common name (or its simplest name when it has none).</summary>
        public string Name { get; set; }
        public string Subject { get; set; }
        public string Issuer { get; set; }
        public string Thumbprint { get; set; }
        public string ValidFrom { get; set; }
        public string ValidUntil { get; set; }
        /// <summary>Other certificates in the PFX (usually the issuer chain); only the one with the private key is used.</summary>
        public int OtherCertificates { get; set; }
    }
    /// <summary>A bank profile (UNI, RB, ...) a BSP submission can be sent for: what the submission page needs, nothing more.</summary>
    public sealed class SandboxBankDto
    {
        public string Key { get; set; }
        public string Name { get; set; }
        /// <summary>The XML Header/Undertaking value of this bank's reports.</summary>
        public string ProviderCode { get; set; }
        /// <summary>The BSP API undertaking code sent in reportInfo; null when the profile has none yet.</summary>
        public string UndertakingCode { get; set; }
        /// <summary>The bank's approved stored certificate, or null when it has none (a PFX is then uploaded per request).</summary>
        public SandboxStoredCertificateDto StoredCertificate { get; set; }
    }
}
