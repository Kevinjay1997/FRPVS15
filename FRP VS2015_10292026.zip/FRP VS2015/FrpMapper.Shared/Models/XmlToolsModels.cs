using System;
using System.Collections.Generic;

namespace FrpMapper.Shared.Models
{
    // The Regulatory Reports Workbench's general XML tools: merging split report elements into the one BSP expects,
    // removing empty ones, keeping the reports of one reporting period, normalizing against the XSD, and checking any XML
    // file against any XSD.

    /// <summary>
    /// The XML tools' configuration, as the Workbench's Config folder had it: merge.csv (From → To), cleanup.csv (the
    /// elements whose empty rows are removed), reportperiod.csv (which reports each period has) and the _Item rows the
    /// normalizer keeps when they have a value (the Workbench's FRP.NonRemovableItems setting).
    /// </summary>
    public sealed class XmlToolsConfigDto
    {
        public WorkbenchTableDto Merge { get; set; } = new WorkbenchTableDto();

        public WorkbenchTableDto Cleanup { get; set; } = new WorkbenchTableDto();

        public WorkbenchTableDto ReportPeriods { get; set; } = new WorkbenchTableDto();

        public List<string> NonRemovableItems { get; set; } = new List<string>();
    }

    /// <summary>What the Merge tab needs.</summary>
    public sealed class XmlToolsSetupDto
    {
        /// <summary>False when no configuration has been approved yet (merging needs it; the XSD check does not).</summary>
        public bool Configured { get; set; }

        public WorkbenchConfigVersionDto Configuration { get; set; }

        /// <summary>The periods of reportperiod.csv (Daily, Weekly, Monthly, Quarterly, Midyear, Yearly).</summary>
        public List<string> ReportPeriods { get; set; } = new List<string>();

        public int MergeRules { get; set; }

        public List<string> CleanupElements { get; set; } = new List<string>();

        public long MaxUploadBytes { get; set; }
    }

    /// <summary>The result of checking an XML file against an XSD.</summary>
    public sealed class XmlSchemaCheckDto
    {
        public bool Valid { get; set; }

        public string XsdFileName { get; set; } = "";

        /// <summary>The first messages (the report file has all of them).</summary>
        public List<XmlSchemaIssueDto> Issues { get; set; } = new List<XmlSchemaIssueDto>();

        public int IssueCount { get; set; }

        /// <summary>The report file to download, when there are messages.</summary>
        public string Report { get; set; }
    }

    /// <summary>The result of Merge (and, when asked, the normalization and the XSD check of the merged file).</summary>
    public sealed class XmlMergeResultDto
    {
        /// <summary>Where the files can be downloaded (GET /api/xml-tools/outputs/{id}/{name}).</summary>
        public string OutputId { get; set; } = "";

        /// <summary>The merged file (…_EXPORTED_ON_yyyyMMdd.xml, as the Workbench named it).</summary>
        public string OutputFile { get; set; } = "";

        /// <summary>The normalized file (…_NORMALIZED.xml), when an XSD was given.</summary>
        public string NormalizedFile { get; set; }

        /// <summary>The normalizer's log (…_NORMALIZED.log).</summary>
        public string NormalizerLog { get; set; }

        /// <summary>The elements written, in order.</summary>
        public List<string> Elements { get; set; } = new List<string>();

        /// <summary>Elements merged into another, as "FRP_9A2 → FRP_9A234".</summary>
        public List<string> Merged { get; set; } = new List<string>();

        /// <summary>Elements left out because they were empty (cleanup.csv).</summary>
        public List<string> RemovedEmpty { get; set; } = new List<string>();

        /// <summary>Elements left out because the chosen period does not have them (reportperiod.csv).</summary>
        public List<string> OutsidePeriod { get; set; } = new List<string>();

        public int NormalizerItemsRemoved { get; set; }

        public int NormalizerSectionsRemoved { get; set; }

        /// <summary>Null when no XSD was given.</summary>
        public XmlSchemaCheckDto Schema { get; set; }

        public List<string> Log { get; set; } = new List<string>();
    }

    /// <summary>The result of checking an XML file against an XSD on its own (the Workbench's Validate with XSD).</summary>
    public sealed class XmlValidateResultDto
    {
        public string OutputId { get; set; } = "";

        public string XmlFileName { get; set; } = "";

        public long XmlSize { get; set; }

        public XmlSchemaCheckDto Schema { get; set; } = new XmlSchemaCheckDto();
    }

    /// <summary>A log file of the API (Logs page).</summary>
    public sealed class LogFileDto
    {
        public string Name { get; set; } = "";

        public long Size { get; set; }

        public DateTimeOffset LastWritten { get; set; }
    }

    /// <summary>The end of one log file, with sensitive values masked.</summary>
    public sealed class LogContentDto
    {
        public string Name { get; set; } = "";

        public List<string> Lines { get; set; } = new List<string>();

        /// <summary>True when the file has more lines before the ones returned.</summary>
        public bool Truncated { get; set; }

        public int Errors { get; set; }

        public int Warnings { get; set; }
    }

    public sealed class LogListDto
    {
        public List<LogFileDto> Files { get; set; } = new List<LogFileDto>();
    }
}
