using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;

namespace FrpMapper.Shared.Hosting
{
    public enum LogLevel
    {
        Trace = 0,
        Debug = 1,
        Information = 2,
        Warning = 3,
        Error = 4,
        Critical = 5,
        None = 6
    }

    /// <summary>A log (stand-in for Microsoft.Extensions.Logging.ILogger, which .NET Framework 4.5.2 does not have).</summary>
    public interface ILogger
    {
        bool IsEnabled(LogLevel level);

        void Log(LogLevel level, Exception exception, string message);
    }

    public interface ILogger<T> : ILogger
    {
    }

    public interface ILoggerFactory
    {
        ILogger CreateLogger(string category);
    }

    /// <summary>LogInformation("{User} signed in.", name): message templates with named placeholders, filled in order.</summary>
    public static class LoggerExtensions
    {
        public static void LogTrace(this ILogger logger, string template, params object[] args) { Write(logger, LogLevel.Trace, null, template, args); }

        public static void LogDebug(this ILogger logger, string template, params object[] args) { Write(logger, LogLevel.Debug, null, template, args); }

        public static void LogDebug(this ILogger logger, Exception exception, string template, params object[] args) { Write(logger, LogLevel.Debug, exception, template, args); }

        public static void LogInformation(this ILogger logger, string template, params object[] args) { Write(logger, LogLevel.Information, null, template, args); }

        public static void LogInformation(this ILogger logger, Exception exception, string template, params object[] args) { Write(logger, LogLevel.Information, exception, template, args); }

        public static void LogWarning(this ILogger logger, string template, params object[] args) { Write(logger, LogLevel.Warning, null, template, args); }

        public static void LogWarning(this ILogger logger, Exception exception, string template, params object[] args) { Write(logger, LogLevel.Warning, exception, template, args); }

        public static void LogError(this ILogger logger, string template, params object[] args) { Write(logger, LogLevel.Error, null, template, args); }

        public static void LogError(this ILogger logger, Exception exception, string template, params object[] args) { Write(logger, LogLevel.Error, exception, template, args); }

        public static void LogCritical(this ILogger logger, Exception exception, string template, params object[] args) { Write(logger, LogLevel.Critical, exception, template, args); }

        private static void Write(ILogger logger, LogLevel level, Exception exception, string template, object[] args)
        {
            if (logger == null || !logger.IsEnabled(level))
            {
                return;
            }

            logger.Log(level, exception, Format(template, args));
        }

        /// <summary>Fills "{Name}" / "{Count:N0}" placeholders with the arguments in order ("{{" and "}}" are literal braces).</summary>
        public static string Format(string template, object[] args)
        {
            if (string.IsNullOrEmpty(template) || args == null || args.Length == 0)
            {
                return template ?? "";
            }

            var b = new StringBuilder();
            var next = 0;
            for (var i = 0; i < template.Length; i++)
            {
                var ch = template[i];
                if (ch == '{' && i + 1 < template.Length && template[i + 1] == '{')
                {
                    b.Append('{');
                    i++;
                    continue;
                }

                if (ch == '}' && i + 1 < template.Length && template[i + 1] == '}')
                {
                    b.Append('}');
                    i++;
                    continue;
                }

                if (ch == '{')
                {
                    var end = template.IndexOf('}', i);
                    if (end < 0)
                    {
                        b.Append(template, i, template.Length - i);
                        break;
                    }

                    var hole = template.Substring(i + 1, end - i - 1);
                    var colon = hole.IndexOf(':');
                    var format = colon >= 0 ? hole.Substring(colon + 1) : null;
                    var value = next < args.Length ? args[next++] : null;
                    var formattable = value as IFormattable;
                    b.Append(formattable != null && format != null
                        ? formattable.ToString(format, CultureInfo.InvariantCulture)
                        : Convert.ToString(value, CultureInfo.InvariantCulture));
                    i = end;
                    continue;
                }

                b.Append(ch);
            }

            return b.ToString();
        }
    }

    /// <summary>
    /// Writes log lines to System.Diagnostics.Trace (Visual Studio's Output window; IIS trace listeners) and, when a
    /// file is set, to that file (one per day: name-yyyyMMdd.log). Messages never contain passwords: the callers do not
    /// log them.
    /// </summary>
    public sealed class LoggerFactory : ILoggerFactory
    {
        private readonly LogLevel minimum;
        private readonly string filePath;
        private readonly object gate = new object();

        public LoggerFactory(LogLevel minimum, string filePath)
        {
            this.minimum = minimum;
            this.filePath = string.IsNullOrWhiteSpace(filePath) ? null : filePath;
        }

        public ILogger CreateLogger(string category)
        {
            return new Logger(this, category);
        }

        public ILogger<T> CreateLogger<T>()
        {
            return new Logger<T>(this);
        }

        internal bool IsEnabled(LogLevel level)
        {
            return level >= minimum && level != LogLevel.None;
        }

        internal void Write(LogLevel level, string category, Exception exception, string message)
        {
            var line = string.Format(CultureInfo.InvariantCulture, "{0:yyyy-MM-dd HH:mm:ss.fff} {1,-11} {2}: {3}", DateTime.Now, level, category, message);
            if (exception != null)
            {
                line += Environment.NewLine + exception;
            }

            if (level >= LogLevel.Error)
            {
                Trace.TraceError(line);
            }
            else if (level == LogLevel.Warning)
            {
                Trace.TraceWarning(line);
            }
            else
            {
                Trace.TraceInformation(line);
            }

            if (filePath == null)
            {
                return;
            }

            try
            {
                lock (gate)
                {
                    var directory = Path.GetDirectoryName(filePath);
                    if (!string.IsNullOrEmpty(directory))
                    {
                        Directory.CreateDirectory(directory);
                    }

                    var dated = Path.Combine(directory ?? "", Path.GetFileNameWithoutExtension(filePath) + "-" + DateTime.Now.ToString("yyyyMMdd", CultureInfo.InvariantCulture) + Path.GetExtension(filePath));
                    File.AppendAllText(dated, line + Environment.NewLine, Encoding.UTF8);
                }
            }
            catch (IOException)
            {
                // logging must never break a request
            }
            catch (UnauthorizedAccessException)
            {
            }
        }

        private class Logger : ILogger
        {
            private readonly LoggerFactory factory;
            private readonly string category;

            public Logger(LoggerFactory factory, string category)
            {
                this.factory = factory;
                this.category = category;
            }

            public bool IsEnabled(LogLevel level)
            {
                return factory.IsEnabled(level);
            }

            public void Log(LogLevel level, Exception exception, string message)
            {
                if (factory.IsEnabled(level))
                {
                    factory.Write(level, category, exception, message);
                }
            }
        }

        private sealed class Logger<T> : Logger, ILogger<T>
        {
            public Logger(LoggerFactory factory) : base(factory, typeof(T).Name)
            {
            }
        }
    }
}
