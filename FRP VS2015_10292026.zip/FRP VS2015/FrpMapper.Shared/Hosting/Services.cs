using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace FrpMapper.Shared.Hosting
{
    public enum ServiceLifetime
    {
        Singleton,
        Scoped,
        Transient
    }

    /// <summary>
    /// A small dependency-injection container (ASP.NET on .NET Framework has none built in): registrations with a
    /// lifetime, constructor injection (the public constructor with the most parameters it can fill), one scope per
    /// request. Registrations read like the .NET 9 Program.cs.
    /// </summary>
    public sealed class ServiceCollection
    {
        private readonly Dictionary<Type, Registration> registrations = new Dictionary<Type, Registration>();

        public ServiceCollection AddSingleton<TService, TImplementation>() where TImplementation : TService
        {
            return Add(typeof(TService), typeof(TImplementation), null, null, ServiceLifetime.Singleton);
        }

        public ServiceCollection AddSingleton<TService>() where TService : class
        {
            return Add(typeof(TService), typeof(TService), null, null, ServiceLifetime.Singleton);
        }

        public ServiceCollection AddSingleton<TService>(TService instance) where TService : class
        {
            return Add(typeof(TService), null, instance, null, ServiceLifetime.Singleton);
        }

        public ServiceCollection AddSingleton<TService>(Func<IServiceProvider, TService> factory) where TService : class
        {
            return Add(typeof(TService), null, null, p => factory(p), ServiceLifetime.Singleton);
        }

        public ServiceCollection AddScoped<TService, TImplementation>() where TImplementation : TService
        {
            return Add(typeof(TService), typeof(TImplementation), null, null, ServiceLifetime.Scoped);
        }

        public ServiceCollection AddScoped<TService>() where TService : class
        {
            return Add(typeof(TService), typeof(TService), null, null, ServiceLifetime.Scoped);
        }

        public ServiceCollection AddScoped<TService>(Func<IServiceProvider, TService> factory) where TService : class
        {
            return Add(typeof(TService), null, null, p => factory(p), ServiceLifetime.Scoped);
        }

        public ServiceCollection AddTransient<TService, TImplementation>() where TImplementation : TService
        {
            return Add(typeof(TService), typeof(TImplementation), null, null, ServiceLifetime.Transient);
        }

        public ServiceCollection AddTransient<TService>() where TService : class
        {
            return Add(typeof(TService), typeof(TService), null, null, ServiceLifetime.Transient);
        }

        public bool Contains(Type service)
        {
            return registrations.ContainsKey(service);
        }

        private ServiceCollection Add(Type service, Type implementation, object instance, Func<IServiceProvider, object> factory, ServiceLifetime lifetime)
        {
            registrations[service] = new Registration
            {
                Service = service,
                Implementation = implementation,
                Instance = instance,
                Factory = factory,
                Lifetime = lifetime
            };
            return this;
        }

        public ServiceProvider Build()
        {
            return new ServiceProvider(new Dictionary<Type, Registration>(registrations), null);
        }

        internal sealed class Registration
        {
            public Type Service;
            public Type Implementation;
            public object Instance;
            public Func<IServiceProvider, object> Factory;
            public ServiceLifetime Lifetime;
        }
    }

    public sealed class ServiceProvider : IServiceProvider, IDisposable
    {
        private readonly Dictionary<Type, ServiceCollection.Registration> registrations;
        private readonly ServiceProvider root;
        private readonly Dictionary<Type, object> instances = new Dictionary<Type, object>();
        private readonly List<IDisposable> disposables = new List<IDisposable>();
        private readonly object gate = new object();
        private readonly HashSet<Type> resolving = new HashSet<Type>();

        internal ServiceProvider(Dictionary<Type, ServiceCollection.Registration> registrations, ServiceProvider root)
        {
            this.registrations = registrations;
            this.root = root;
        }

        /// <summary>A scope for one request: scoped services live (and are disposed) with it.</summary>
        public ServiceProvider CreateScope()
        {
            return new ServiceProvider(registrations, root ?? this);
        }

        /// <summary>Registers an object for this scope only (e.g. the current request).</summary>
        public void AddScopedInstance(Type service, object instance)
        {
            lock (gate)
            {
                instances[service] = instance;
            }
        }

        public object GetService(Type serviceType)
        {
            if (serviceType == typeof(IServiceProvider) || serviceType == typeof(ServiceProvider))
            {
                return this;
            }

            lock (gate)
            {
                object existing;
                if (instances.TryGetValue(serviceType, out existing))
                {
                    return existing;
                }
            }

            ServiceCollection.Registration registration;
            if (!registrations.TryGetValue(serviceType, out registration))
            {
                if (serviceType.IsGenericType)
                {
                    // ILogger<T>: from the registered factory
                    var definition = serviceType.GetGenericTypeDefinition();
                    if (definition == typeof(ILogger<>))
                    {
                        var factory = (LoggerFactory)GetService(typeof(ILoggerFactory));
                        if (factory != null)
                        {
                            var create = typeof(LoggerFactory).GetMethod("CreateLogger", Type.EmptyTypes).MakeGenericMethod(serviceType.GetGenericArguments()[0]);
                            return create.Invoke(factory, null);
                        }
                    }
                }

                return null;
            }

            switch (registration.Lifetime)
            {
                case ServiceLifetime.Singleton:
                    return (root ?? this).Resolve(registration, true);
                case ServiceLifetime.Scoped:
                    if (root == null)
                    {
                        throw new InvalidOperationException("The scoped service " + serviceType.Name + " was requested outside a scope.");
                    }

                    return Resolve(registration, true);
                default:
                    return Create(registration);
            }
        }

        private object Resolve(ServiceCollection.Registration registration, bool keep)
        {
            lock (gate)
            {
                object existing;
                if (instances.TryGetValue(registration.Service, out existing))
                {
                    return existing;
                }

                if (!resolving.Add(registration.Service))
                {
                    throw new InvalidOperationException("The service " + registration.Service.Name + " depends on itself.");
                }

                try
                {
                    var created = registration.Instance ?? Create(registration);
                    if (keep)
                    {
                        instances[registration.Service] = created;
                    }

                    return created;
                }
                finally
                {
                    resolving.Remove(registration.Service);
                }
            }
        }

        private object Create(ServiceCollection.Registration registration)
        {
            object created;
            if (registration.Factory != null)
            {
                created = registration.Factory(this);
            }
            else
            {
                var type = registration.Implementation;
                var constructors = type.GetConstructors(BindingFlags.Public | BindingFlags.Instance).OrderByDescending(c => c.GetParameters().Length);
                ConstructorInfo chosen = null;
                object[] arguments = null;
                foreach (var constructor in constructors)
                {
                    var parameters = constructor.GetParameters();
                    var values = new object[parameters.Length];
                    var ok = true;
                    for (var i = 0; i < parameters.Length; i++)
                    {
                        var value = GetService(parameters[i].ParameterType);
                        if (value == null && !parameters[i].HasDefaultValue)
                        {
                            ok = false;
                            break;
                        }

                        values[i] = value ?? parameters[i].DefaultValue;
                    }

                    if (ok)
                    {
                        chosen = constructor;
                        arguments = values;
                        break;
                    }
                }

                if (chosen == null)
                {
                    throw new InvalidOperationException("No constructor of " + type.Name + " can be filled from the registered services.");
                }

                created = chosen.Invoke(arguments);
            }

            var disposable = created as IDisposable;
            if (disposable != null && registration.Instance == null)
            {
                lock (gate)
                {
                    disposables.Add(disposable);
                }
            }

            return created;
        }

        public void Dispose()
        {
            List<IDisposable> toDispose;
            lock (gate)
            {
                toDispose = disposables.ToList();
                disposables.Clear();
            }

            foreach (var d in Enumerable.Reverse(toDispose))
            {
                d.Dispose();
            }
        }
    }

    public static class ServiceProviderExtensions
    {
        public static T GetService<T>(this IServiceProvider provider)
        {
            return (T)provider.GetService(typeof(T));
        }

        public static T GetRequiredService<T>(this IServiceProvider provider)
        {
            var service = provider.GetService(typeof(T));
            if (service == null)
            {
                throw new InvalidOperationException("The service " + typeof(T).Name + " is not registered.");
            }

            return (T)service;
        }
    }
}
