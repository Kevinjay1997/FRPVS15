using System;
using System.Collections.Generic;
using System.Linq;

namespace FrpMapper.Shared.Hosting
{
    /// <summary>Settings of type T (stand-in for Microsoft.Extensions.Options).</summary>
    public interface IOptions<out T> where T : class
    {
        T Value { get; }
    }

    /// <summary>
    /// Settings that may change. In ASP.NET on .NET Framework a change to web.config restarts the application, so the
    /// current value is simply the value read at start.
    /// </summary>
    public interface IOptionsMonitor<out T> where T : class
    {
        T CurrentValue { get; }

        T Get(string name);
    }

    public interface IValidateOptions<in T> where T : class
    {
        ValidateOptionsResult Validate(string name, T options);
    }

    public sealed class ValidateOptionsResult
    {
        public static readonly ValidateOptionsResult Success = new ValidateOptionsResult { Succeeded = true };

        public bool Succeeded { get; private set; }

        public bool Failed { get { return !Succeeded; } }

        public string FailureMessage { get; private set; }

        public IEnumerable<string> Failures { get; private set; }

        public static ValidateOptionsResult Fail(IEnumerable<string> failures)
        {
            var list = failures.ToList();
            return new ValidateOptionsResult { Succeeded = false, Failures = list, FailureMessage = string.Join("; ", list) };
        }

        public static ValidateOptionsResult Fail(string failure)
        {
            return Fail(new[] { failure });
        }
    }

    public sealed class OptionsValidationException : Exception
    {
        public OptionsValidationException(string message) : base(message)
        {
        }
    }

    public static class Options
    {
        public const string DefaultName = "";

        public static IOptions<T> Create<T>(T value) where T : class
        {
            return new FixedOptions<T>(value);
        }
    }

    /// <summary>Options read once (and validated) when the application starts.</summary>
    public sealed class FixedOptions<T> : IOptions<T>, IOptionsMonitor<T> where T : class
    {
        private readonly T value;

        public FixedOptions(T value)
        {
            this.value = value;
        }

        public FixedOptions(T value, IValidateOptions<T> validator) : this(value)
        {
            if (validator != null)
            {
                var result = validator.Validate(Options.DefaultName, value);
                if (result.Failed)
                {
                    throw new OptionsValidationException(result.FailureMessage);
                }
            }
        }

        public T Value { get { return value; } }

        public T CurrentValue { get { return value; } }

        public T Get(string name)
        {
            return value;
        }
    }
}
