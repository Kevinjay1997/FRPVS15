using System;
using System.Collections.Concurrent;
using System.Linq;

namespace FrpMapper.Shared.Hosting
{
    /// <summary>An in-process cache (stand-in for Microsoft.Extensions.Caching.Memory.IMemoryCache); keys are any objects.</summary>
    public interface IMemoryCache
    {
        bool TryGetValue(object key, out object value);

        ICacheEntry CreateEntry(object key);

        void Remove(object key);
    }

    public interface ICacheEntry : IDisposable
    {
        object Key { get; }

        object Value { get; set; }

        DateTimeOffset? AbsoluteExpiration { get; set; }

        TimeSpan? AbsoluteExpirationRelativeToNow { get; set; }

        TimeSpan? SlidingExpiration { get; set; }
    }

    public sealed class MemoryCacheEntryOptions
    {
        public DateTimeOffset? AbsoluteExpiration { get; set; }

        public TimeSpan? AbsoluteExpirationRelativeToNow { get; set; }

        public TimeSpan? SlidingExpiration { get; set; }
    }

    public static class MemoryCacheExtensions
    {
        public static bool TryGetValue<T>(this IMemoryCache cache, object key, out T value)
        {
            object found;
            if (cache.TryGetValue(key, out found) && found is T)
            {
                value = (T)found;
                return true;
            }

            value = default(T);
            return false;
        }

        public static T Get<T>(this IMemoryCache cache, object key)
        {
            T value;
            cache.TryGetValue(key, out value);
            return value;
        }

        public static T Set<T>(this IMemoryCache cache, object key, T value)
        {
            using (var entry = cache.CreateEntry(key))
            {
                entry.Value = value;
            }

            return value;
        }

        public static T Set<T>(this IMemoryCache cache, object key, T value, TimeSpan absoluteExpirationRelativeToNow)
        {
            using (var entry = cache.CreateEntry(key))
            {
                entry.Value = value;
                entry.AbsoluteExpirationRelativeToNow = absoluteExpirationRelativeToNow;
            }

            return value;
        }

        public static T Set<T>(this IMemoryCache cache, object key, T value, DateTimeOffset absoluteExpiration)
        {
            using (var entry = cache.CreateEntry(key))
            {
                entry.Value = value;
                entry.AbsoluteExpiration = absoluteExpiration;
            }

            return value;
        }

        public static T Set<T>(this IMemoryCache cache, object key, T value, MemoryCacheEntryOptions options)
        {
            using (var entry = cache.CreateEntry(key))
            {
                entry.Value = value;
                if (options != null)
                {
                    entry.AbsoluteExpiration = options.AbsoluteExpiration;
                    entry.AbsoluteExpirationRelativeToNow = options.AbsoluteExpirationRelativeToNow;
                    entry.SlidingExpiration = options.SlidingExpiration;
                }
            }

            return value;
        }

        public static T GetOrCreate<T>(this IMemoryCache cache, object key, Func<ICacheEntry, T> factory)
        {
            object found;
            if (cache.TryGetValue(key, out found) && found is T)
            {
                return (T)found;
            }

            using (var entry = cache.CreateEntry(key))
            {
                var value = factory(entry);
                entry.Value = value;
                return value;
            }
        }
    }

    public sealed class MemoryCache : IMemoryCache
    {
        private readonly ConcurrentDictionary<object, Entry> entries = new ConcurrentDictionary<object, Entry>();
        private int writes;

        public bool TryGetValue(object key, out object value)
        {
            Entry entry;
            if (entries.TryGetValue(key, out entry))
            {
                var now = DateTimeOffset.UtcNow;
                if (!entry.IsExpired(now))
                {
                    entry.Touch(now);
                    value = entry.Value;
                    return true;
                }

                entries.TryRemove(key, out entry);
            }

            value = null;
            return false;
        }

        public ICacheEntry CreateEntry(object key)
        {
            return new Entry(this, key);
        }

        public void Remove(object key)
        {
            Entry removed;
            entries.TryRemove(key, out removed);
        }

        private void Commit(Entry entry)
        {
            var now = DateTimeOffset.UtcNow;
            entry.Start(now);
            entries[entry.Key] = entry;
            if (System.Threading.Interlocked.Increment(ref writes) % 256 == 0)
            {
                foreach (var pair in entries.ToList())
                {
                    if (pair.Value.IsExpired(now))
                    {
                        Entry removed;
                        entries.TryRemove(pair.Key, out removed);
                    }
                }
            }
        }

        private sealed class Entry : ICacheEntry
        {
            private readonly MemoryCache owner;
            private DateTimeOffset? expiresAt;
            private DateTimeOffset lastAccess;
            private bool committed;

            public Entry(MemoryCache owner, object key)
            {
                this.owner = owner;
                Key = key;
            }

            public object Key { get; private set; }

            public object Value { get; set; }

            public DateTimeOffset? AbsoluteExpiration { get; set; }

            public TimeSpan? AbsoluteExpirationRelativeToNow { get; set; }

            public TimeSpan? SlidingExpiration { get; set; }

            public void Start(DateTimeOffset now)
            {
                lastAccess = now;
                if (AbsoluteExpirationRelativeToNow.HasValue)
                {
                    expiresAt = now + AbsoluteExpirationRelativeToNow.Value;
                }
                else if (AbsoluteExpiration.HasValue)
                {
                    expiresAt = AbsoluteExpiration.Value;
                }
            }

            public bool IsExpired(DateTimeOffset now)
            {
                if (expiresAt.HasValue && now >= expiresAt.Value)
                {
                    return true;
                }

                return SlidingExpiration.HasValue && now - lastAccess >= SlidingExpiration.Value;
            }

            public void Touch(DateTimeOffset now)
            {
                lastAccess = now;
            }

            public void Dispose()
            {
                if (!committed)
                {
                    committed = true;
                    owner.Commit(this);
                }
            }
        }
    }
}
