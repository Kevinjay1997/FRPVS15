using System;
using System.Collections.Specialized;
using System.Configuration;
using System.Globalization;

namespace FrpMapper.Shared.Hosting
{
    /// <summary>Settings by key ("Section:Name"), stand-in for Microsoft.Extensions.Configuration.IConfiguration.</summary>
    public interface IConfiguration
    {
        /// <summary>The value, or null when it is not set.</summary>
        string this[string key] { get; }
    }

    public static class ConfigurationExtensions
    {
        public static string GetConnectionString(this IConfiguration configuration, string name)
        {
            return configuration["ConnectionStrings:" + name];
        }

        public static T GetValue<T>(this IConfiguration configuration, string key, T defaultValue = default(T))
        {
            var text = configuration[key];
            if (string.IsNullOrWhiteSpace(text))
            {
                return defaultValue;
            }

            var type = Nullable.GetUnderlyingType(typeof(T)) ?? typeof(T);
            try
            {
                if (type.IsEnum)
                {
                    return (T)Enum.Parse(type, text, true);
                }

                if (type == typeof(TimeSpan))
                {
                    return (T)(object)TimeSpan.Parse(text, CultureInfo.InvariantCulture);
                }

                return (T)Convert.ChangeType(text, type, CultureInfo.InvariantCulture);
            }
            catch (FormatException)
            {
                throw new InvalidOperationException("The setting " + key + " has a value of the wrong type.");
            }
        }
    }

    /// <summary>
    /// The application's settings, first found wins:
    /// 1. an environment variable named like the key with ":" written as "__" (InternalApi__Key, ConnectionStrings__FrpDb), as in .NET Core;
    /// 2. web.config appSettings (which also merges the optional secrets file named in its "file" attribute);
    /// 3. for "ConnectionStrings:Name", web.config connectionStrings.
    /// Secrets (the connection string, the internal API key) belong in an environment variable or the secrets file,
    /// never in web.config in source control.
    /// </summary>
    public sealed class AppConfiguration : IConfiguration
    {
        private readonly NameValueCollection settings;
        private readonly ConnectionStringSettingsCollection connectionStrings;

        public AppConfiguration()
            : this(ConfigurationManager.AppSettings, ConfigurationManager.ConnectionStrings)
        {
        }

        public AppConfiguration(NameValueCollection settings, ConnectionStringSettingsCollection connectionStrings)
        {
            this.settings = settings ?? new NameValueCollection();
            this.connectionStrings = connectionStrings;
        }

        public string this[string key]
        {
            get
            {
                var environment = Environment.GetEnvironmentVariable(key.Replace(":", "__"));
                if (!string.IsNullOrEmpty(environment))
                {
                    return environment;
                }

                var value = settings[key];
                if (!string.IsNullOrEmpty(value))
                {
                    return value;
                }

                const string prefix = "ConnectionStrings:";
                if (connectionStrings != null && key.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                {
                    var connection = connectionStrings[key.Substring(prefix.Length)];
                    if (connection != null && !string.IsNullOrEmpty(connection.ConnectionString))
                    {
                        return connection.ConnectionString;
                    }
                }

                return null;
            }
        }
    }

    /// <summary>Stand-in for IHostEnvironment: the environment name (setting "Environment") and the application folder.</summary>
    public interface IHostEnvironment
    {
        string EnvironmentName { get; }

        string ContentRootPath { get; }
    }

    public interface IWebHostEnvironment : IHostEnvironment
    {
    }

    public static class HostEnvironmentExtensions
    {
        public static bool IsDevelopment(this IHostEnvironment environment)
        {
            return string.Equals(environment.EnvironmentName, "Development", StringComparison.OrdinalIgnoreCase);
        }

        public static bool IsProduction(this IHostEnvironment environment)
        {
            return string.Equals(environment.EnvironmentName, "Production", StringComparison.OrdinalIgnoreCase);
        }
    }

    public sealed class HostEnvironment : IWebHostEnvironment
    {
        public HostEnvironment(string environmentName, string contentRootPath)
        {
            EnvironmentName = string.IsNullOrWhiteSpace(environmentName) ? "Production" : environmentName.Trim();
            ContentRootPath = contentRootPath;
        }

        public string EnvironmentName { get; private set; }

        public string ContentRootPath { get; private set; }
    }
}
