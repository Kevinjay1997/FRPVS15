using System;
using System.Collections.Generic;

namespace FrpMapper.Shared.Compat
{
    /// <summary>
    /// A record-like class (value equality, copy with changes). The .NET 9 version used C# records; C# 6 has none, so
    /// these classes implement this interface and are copied with <see cref="RecordExtensions.With{T}"/>.
    /// </summary>
    public interface IRecord<T> where T : class
    {
        /// <summary>A shallow copy (what a record's "with" starts from).</summary>
        T CloneRecord();
    }

    public static class RecordExtensions
    {
        /// <summary>C# 9 "source with { A = 1 }": a copy of <paramref name="source"/> with <paramref name="change"/> applied.</summary>
        public static T With<T>(this T source, Action<T> change) where T : class, IRecord<T>
        {
            if (source == null)
            {
                throw new ArgumentNullException("source");
            }

            var copy = source.CloneRecord();
            change(copy);
            return copy;
        }
    }

    /// <summary>Pattern matching for C# 6 ("x is T t", "x is var v").</summary>
    public static class CompatPattern
    {
        /// <summary>"value is T result": true and the value when it is a non-null T.</summary>
        public static bool Is<T>(object value, out T result)
        {
            if (value is T)
            {
                result = (T)value;
                return true;
            }

            result = default(T);
            return false;
        }

        /// <summary>"value is var result": always true.</summary>
        public static bool Var<T>(T value, out T result)
        {
            result = value;
            return true;
        }
    }

    public static class CompatFn
    {
        /// <summary>Evaluates <paramref name="value"/> once and passes it to <paramref name="body"/> (switch expressions on a computed value).</summary>
        public static TResult Let<T, TResult>(T value, Func<T, TResult> body)
        {
            return body(value);
        }
    }

    public static class CompatThrow
    {
        /// <summary>A throw expression ("x ?? throw …") in C# 6: throws, typed as the expression it replaces.</summary>
        public static T As<T>(Exception exception)
        {
            throw exception;
        }
    }

    public static class CompatArray
    {
        /// <summary>array[start..end]</summary>
        public static T[] Slice<T>(T[] array, int start, int end)
        {
            var result = new T[end - start];
            Array.Copy(array, start, result, 0, result.Length);
            return result;
        }

        /// <summary>array[start..]</summary>
        public static T[] Slice<T>(T[] array, int start)
        {
            return Slice(array, start, array.Length);
        }
    }
}
