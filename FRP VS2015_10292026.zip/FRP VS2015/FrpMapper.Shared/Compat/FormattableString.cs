using System.Globalization;

// .NET Framework 4.5.2 has no FormattableString (added in 4.6). C# 6 turns an interpolated string ($"...") passed as a
// FormattableString into FormattableStringFactory.Create(format, args), so these two types are all the compiler needs.
// They match the .NET 4.6 API, so the code reads the same as on later frameworks.
namespace System
{
    /// <summary>A composite format string and its arguments ($"..." used as a FormattableString).</summary>
    public abstract class FormattableString : IFormattable
    {
        public abstract string Format { get; }

        public abstract int ArgumentCount { get; }

        public abstract object[] GetArguments();

        public abstract object GetArgument(int index);

        public abstract string ToString(IFormatProvider formatProvider);

        string IFormattable.ToString(string ignored, IFormatProvider formatProvider)
        {
            return ToString(formatProvider);
        }

        /// <summary>The text formatted with the invariant culture: FormattableString.Invariant($"...").</summary>
        public static string Invariant(FormattableString formattable)
        {
            if (formattable == null)
            {
                throw new ArgumentNullException("formattable");
            }

            return formattable.ToString(CultureInfo.InvariantCulture);
        }

        public override string ToString()
        {
            return ToString(CultureInfo.CurrentCulture);
        }
    }
}

namespace System.Runtime.CompilerServices
{
    /// <summary>What the C# compiler calls to build a FormattableString from $"...".</summary>
    public static class FormattableStringFactory
    {
        public static FormattableString Create(string format, params object[] arguments)
        {
            if (format == null)
            {
                throw new ArgumentNullException("format");
            }

            if (arguments == null)
            {
                throw new ArgumentNullException("arguments");
            }

            return new ConcreteFormattableString(format, arguments);
        }

        private sealed class ConcreteFormattableString : FormattableString
        {
            private readonly string format;
            private readonly object[] arguments;

            internal ConcreteFormattableString(string format, object[] arguments)
            {
                this.format = format;
                this.arguments = arguments;
            }

            public override string Format { get { return format; } }

            public override int ArgumentCount { get { return arguments.Length; } }

            public override object[] GetArguments() { return arguments; }

            public override object GetArgument(int index) { return arguments[index]; }

            public override string ToString(IFormatProvider formatProvider)
            {
                return string.Format(formatProvider, format, arguments);
            }
        }
    }
}
