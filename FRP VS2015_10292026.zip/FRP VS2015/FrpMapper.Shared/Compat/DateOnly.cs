using System;
using System.Globalization;

namespace FrpMapper.Shared.Compat
{
    /// <summary>A calendar date without a time (System.DateOnly arrived in .NET 6). Written as yyyy-MM-dd.</summary>
    [Serializable]
    public struct DateOnly : IEquatable<DateOnly>, IComparable<DateOnly>, IComparable, IFormattable
    {
        private readonly DateTime date;

        public DateOnly(int year, int month, int day)
        {
            date = new DateTime(year, month, day, 0, 0, 0, DateTimeKind.Unspecified);
        }

        private DateOnly(DateTime value)
        {
            date = DateTime.SpecifyKind(value.Date, DateTimeKind.Unspecified);
        }

        public static DateOnly MinValue { get { return new DateOnly(DateTime.MinValue); } }

        public static DateOnly MaxValue { get { return new DateOnly(DateTime.MaxValue); } }

        public int Year { get { return date.Year; } }

        public int Month { get { return date.Month; } }

        public int Day { get { return date.Day; } }

        public DayOfWeek DayOfWeek { get { return date.DayOfWeek; } }

        public int DayNumber { get { return (int)(date.Ticks / TimeSpan.TicksPerDay); } }

        public static DateOnly FromDateTime(DateTime value)
        {
            return new DateOnly(value);
        }

        public DateTime ToDateTime(TimeOnly time)
        {
            return date.Add(time.ToTimeSpan());
        }

        public DateTime ToDateTime(TimeOnly time, DateTimeKind kind)
        {
            return DateTime.SpecifyKind(date.Add(time.ToTimeSpan()), kind);
        }

        public DateOnly AddDays(int days)
        {
            return new DateOnly(date.AddDays(days));
        }

        public DateOnly AddMonths(int months)
        {
            return new DateOnly(date.AddMonths(months));
        }

        public DateOnly AddYears(int years)
        {
            return new DateOnly(date.AddYears(years));
        }

        public static bool TryParseExact(string text, string format, IFormatProvider provider, DateTimeStyles style, out DateOnly result)
        {
            DateTime parsed;
            if (DateTime.TryParseExact(text, format, provider, style, out parsed) && parsed.TimeOfDay == TimeSpan.Zero)
            {
                result = new DateOnly(parsed);
                return true;
            }

            result = default(DateOnly);
            return false;
        }

        public static bool TryParse(string text, out DateOnly result)
        {
            return TryParseExact(text, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out result);
        }

        public static DateOnly Parse(string text, IFormatProvider provider)
        {
            return new DateOnly(DateTime.Parse(text, provider));
        }

        public string ToString(string format, IFormatProvider provider)
        {
            return date.ToString(format, provider);
        }

        public string ToString(string format)
        {
            return date.ToString(format, CultureInfo.CurrentCulture);
        }

        public override string ToString()
        {
            return date.ToString("d", CultureInfo.CurrentCulture);
        }

        public bool Equals(DateOnly other)
        {
            return date == other.date;
        }

        public override bool Equals(object obj)
        {
            return obj is DateOnly && Equals((DateOnly)obj);
        }

        public override int GetHashCode()
        {
            return date.GetHashCode();
        }

        public int CompareTo(DateOnly other)
        {
            return date.CompareTo(other.date);
        }

        public int CompareTo(object obj)
        {
            return obj is DateOnly ? CompareTo((DateOnly)obj) : 1;
        }

        public static bool operator ==(DateOnly left, DateOnly right) { return left.date == right.date; }

        public static bool operator !=(DateOnly left, DateOnly right) { return left.date != right.date; }

        public static bool operator <(DateOnly left, DateOnly right) { return left.date < right.date; }

        public static bool operator >(DateOnly left, DateOnly right) { return left.date > right.date; }

        public static bool operator <=(DateOnly left, DateOnly right) { return left.date <= right.date; }

        public static bool operator >=(DateOnly left, DateOnly right) { return left.date >= right.date; }
    }

    /// <summary>A time of day (System.TimeOnly arrived in .NET 6); only what the app uses.</summary>
    [Serializable]
    public struct TimeOnly
    {
        private readonly TimeSpan time;

        public TimeOnly(int hour, int minute, int second = 0)
        {
            time = new TimeSpan(hour, minute, second);
        }

        public static TimeOnly MinValue { get { return new TimeOnly(0, 0); } }

        public TimeSpan ToTimeSpan()
        {
            return time;
        }
    }
}
