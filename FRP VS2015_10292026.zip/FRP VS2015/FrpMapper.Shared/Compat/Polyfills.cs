using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FrpMapper.Shared.Compat
{
    /// <summary>
    /// Methods the .NET 9 version used that .NET Framework 4.5.2 does not have, with the same names and behaviour, as
    /// extension methods (so the calling code reads the same).
    /// </summary>
    public static class StringPolyfills
    {
        public static bool Contains(this string text, char value)
        {
            return text.IndexOf(value) >= 0;
        }

        public static bool Contains(this string text, string value, StringComparison comparison)
        {
            return text.IndexOf(value, comparison) >= 0;
        }

        public static bool Contains(this string text, char value, StringComparison comparison)
        {
            return text.IndexOf(value.ToString(), comparison) >= 0;
        }

        public static bool StartsWith(this string text, char value)
        {
            return text.Length > 0 && text[0] == value;
        }

        public static bool EndsWith(this string text, char value)
        {
            return text.Length > 0 && text[text.Length - 1] == value;
        }

        public static int IndexOf(this string text, char value, StringComparison comparison)
        {
            return text.IndexOf(value.ToString(), comparison);
        }

        public static string[] Split(this string text, char separator, StringSplitOptions options)
        {
            return text.Split(new[] { separator }, options);
        }

        public static string[] Split(this string text, char separator, int count, StringSplitOptions options = StringSplitOptions.None)
        {
            return text.Split(new[] { separator }, count, options);
        }

        public static string[] Split(this string text, string separator, StringSplitOptions options = StringSplitOptions.None)
        {
            return text.Split(new[] { separator }, options);
        }

        public static string[] Split(this string text, string separator, int count, StringSplitOptions options = StringSplitOptions.None)
        {
            return text.Split(new[] { separator }, count, options);
        }

        public static string Replace(this string text, string oldValue, string newValue, StringComparison comparison)
        {
            if (string.IsNullOrEmpty(oldValue))
            {
                throw new ArgumentException("The value to replace is empty.", "oldValue");
            }

            var b = new StringBuilder();
            var start = 0;
            int index;
            while ((index = text.IndexOf(oldValue, start, comparison)) >= 0)
            {
                b.Append(text, start, index - start).Append(newValue);
                start = index + oldValue.Length;
            }

            b.Append(text, start, text.Length - start);
            return b.ToString();
        }

        public static string ReplaceLineEndings(this string text, string replacement)
        {
            return text.Replace("\r\n", "\n").Replace("\r", "\n").Replace("\n", replacement);
        }

        public static int GetHashCode(this string text, StringComparison comparison)
        {
            return GetComparer(comparison).GetHashCode(text);
        }

        private static StringComparer GetComparer(StringComparison comparison)
        {
            switch (comparison)
            {
                case StringComparison.CurrentCulture: return StringComparer.CurrentCulture;
                case StringComparison.CurrentCultureIgnoreCase: return StringComparer.CurrentCultureIgnoreCase;
                case StringComparison.InvariantCulture: return StringComparer.InvariantCulture;
                case StringComparison.InvariantCultureIgnoreCase: return StringComparer.InvariantCultureIgnoreCase;
                case StringComparison.OrdinalIgnoreCase: return StringComparer.OrdinalIgnoreCase;
                default: return StringComparer.Ordinal;
            }
        }

        /// <summary>StringBuilder.Append(provider, $"...") (.NET 6): the interpolated text formatted with the provider.</summary>
        public static StringBuilder Append(this StringBuilder builder, IFormatProvider provider, FormattableString text)
        {
            return builder.Append(text.ToString(provider));
        }

        public static StringBuilder AppendJoin<T>(this StringBuilder builder, string separator, IEnumerable<T> values)
        {
            return builder.Append(string.Join(separator, values));
        }

        public static StringBuilder AppendJoin<T>(this StringBuilder builder, char separator, IEnumerable<T> values)
        {
            return builder.Append(string.Join(separator.ToString(), values));
        }
    }

    public static class CompatString
    {
        /// <summary>string.Create(provider, $"...") (.NET 6).</summary>
        public static string Create(IFormatProvider provider, FormattableString text)
        {
            return text.ToString(provider);
        }
    }

    public static class CompatChar
    {
        public static bool IsAsciiDigit(char c)
        {
            return c >= '0' && c <= '9';
        }

        public static bool IsAsciiLetter(char c)
        {
            return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
        }

        public static bool IsAsciiLetterOrDigit(char c)
        {
            return IsAsciiLetter(c) || IsAsciiDigit(c);
        }

        public static bool IsAsciiLetterUpper(char c)
        {
            return c >= 'A' && c <= 'Z';
        }

        public static bool IsAsciiLetterLower(char c)
        {
            return c >= 'a' && c <= 'z';
        }

        public static bool IsAsciiHexDigit(char c)
        {
            return IsAsciiDigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
        }

        public static bool IsAsciiHexDigitLower(char c)
        {
            return IsAsciiDigit(c) || (c >= 'a' && c <= 'f');
        }
    }

    public static class EnumerablePolyfills
    {
        public static HashSet<T> ToHashSet<T>(this IEnumerable<T> source, IEqualityComparer<T> comparer = null)
        {
            return new HashSet<T>(source, comparer);
        }

        public static IOrderedEnumerable<T> Order<T>(this IEnumerable<T> source, IComparer<T> comparer = null)
        {
            return source.OrderBy(x => x, comparer ?? Comparer<T>.Default);
        }

        public static IOrderedEnumerable<T> OrderDescending<T>(this IEnumerable<T> source, IComparer<T> comparer = null)
        {
            return source.OrderByDescending(x => x, comparer ?? Comparer<T>.Default);
        }

        public static IEnumerable<T> Append<T>(this IEnumerable<T> source, T element)
        {
            foreach (var item in source)
            {
                yield return item;
            }

            yield return element;
        }

        public static IEnumerable<T> Prepend<T>(this IEnumerable<T> source, T element)
        {
            yield return element;
            foreach (var item in source)
            {
                yield return item;
            }
        }

        public static IEnumerable<T> DistinctBy<T, TKey>(this IEnumerable<T> source, Func<T, TKey> key, IEqualityComparer<TKey> comparer = null)
        {
            var seen = new HashSet<TKey>(comparer);
            foreach (var item in source)
            {
                if (seen.Add(key(item)))
                {
                    yield return item;
                }
            }
        }

        public static IEnumerable<T> ExceptBy<T, TKey>(this IEnumerable<T> source, IEnumerable<TKey> keys, Func<T, TKey> key, IEqualityComparer<TKey> comparer = null)
        {
            var excluded = new HashSet<TKey>(keys, comparer);
            foreach (var item in source)
            {
                if (excluded.Add(key(item)))
                {
                    yield return item;
                }
            }
        }

        public static IEnumerable<T> UnionBy<T, TKey>(this IEnumerable<T> first, IEnumerable<T> second, Func<T, TKey> key, IEqualityComparer<TKey> comparer = null)
        {
            return first.Concat(second).DistinctBy(key, comparer);
        }

        public static T MaxBy<T, TKey>(this IEnumerable<T> source, Func<T, TKey> key, IComparer<TKey> comparer = null)
        {
            comparer = comparer ?? Comparer<TKey>.Default;
            var found = false;
            var best = default(T);
            var bestKey = default(TKey);
            foreach (var item in source)
            {
                var k = key(item);
                if (!found || comparer.Compare(k, bestKey) > 0)
                {
                    best = item;
                    bestKey = k;
                    found = true;
                }
            }

            return best;
        }

        public static T MinBy<T, TKey>(this IEnumerable<T> source, Func<T, TKey> key, IComparer<TKey> comparer = null)
        {
            comparer = comparer ?? Comparer<TKey>.Default;
            var found = false;
            var best = default(T);
            var bestKey = default(TKey);
            foreach (var item in source)
            {
                var k = key(item);
                if (!found || comparer.Compare(k, bestKey) < 0)
                {
                    best = item;
                    bestKey = k;
                    found = true;
                }
            }

            return best;
        }

        public static IEnumerable<T[]> Chunk<T>(this IEnumerable<T> source, int size)
        {
            var chunk = new List<T>(size);
            foreach (var item in source)
            {
                chunk.Add(item);
                if (chunk.Count == size)
                {
                    yield return chunk.ToArray();
                    chunk.Clear();
                }
            }

            if (chunk.Count > 0)
            {
                yield return chunk.ToArray();
            }
        }

        public static IEnumerable<T> SkipLast<T>(this IEnumerable<T> source, int count)
        {
            var list = source.ToList();
            return list.Take(Math.Max(0, list.Count - count));
        }

        public static IEnumerable<T> TakeLast<T>(this IEnumerable<T> source, int count)
        {
            var list = source.ToList();
            return list.Skip(Math.Max(0, list.Count - count));
        }

        public static T FirstOrDefault<T>(this IEnumerable<T> source, T defaultValue)
        {
            foreach (var item in source)
            {
                return item;
            }

            return defaultValue;
        }

        public static T FirstOrDefault<T>(this IEnumerable<T> source, Func<T, bool> predicate, T defaultValue)
        {
            foreach (var item in source)
            {
                if (predicate(item))
                {
                    return item;
                }
            }

            return defaultValue;
        }

        public static T SingleOrDefault<T>(this IEnumerable<T> source, Func<T, bool> predicate, T defaultValue)
        {
            var found = false;
            var result = defaultValue;
            foreach (var item in source)
            {
                if (predicate(item))
                {
                    if (found)
                    {
                        throw new InvalidOperationException("Sequence contains more than one matching element.");
                    }

                    found = true;
                    result = item;
                }
            }

            return result;
        }

        public static IEnumerable<VT_First_Second<TFirst, TSecond>> Zip<TFirst, TSecond>(this IEnumerable<TFirst> first, IEnumerable<TSecond> second)
        {
            return first.Zip(second, (a, b) => new VT_First_Second<TFirst, TSecond>(a, b));
        }

        public static IEnumerable<VT_Index_Item<T>> Index<T>(this IEnumerable<T> source)
        {
            var i = 0;
            foreach (var item in source)
            {
                yield return new VT_Index_Item<T>(i++, item);
            }
        }

        public static Dictionary<TKey, int> CountBy<T, TKey>(this IEnumerable<T> source, Func<T, TKey> key, IEqualityComparer<TKey> comparer = null)
        {
            var result = new Dictionary<TKey, int>(comparer);
            foreach (var item in source)
            {
                var k = key(item);
                int count;
                result.TryGetValue(k, out count);
                result[k] = count + 1;
            }

            return result;
        }

        public static bool TryGetNonEnumeratedCount<T>(this IEnumerable<T> source, out int count)
        {
            var collection = source as ICollection<T>;
            if (collection != null)
            {
                count = collection.Count;
                return true;
            }

            var readOnly = source as IReadOnlyCollection<T>;
            if (readOnly != null)
            {
                count = readOnly.Count;
                return true;
            }

            count = 0;
            return false;
        }
    }

    /// <summary>(First, Second) pairs of Zip without a selector.</summary>
    public struct VT_First_Second<T1, T2>
    {
        public T1 First;
        public T2 Second;

        public VT_First_Second(T1 first, T2 second)
        {
            First = first;
            Second = second;
        }
    }

    /// <summary>(Index, Item) pairs of Index().</summary>
    public struct VT_Index_Item<T>
    {
        public int Index;
        public T Item;

        public VT_Index_Item(int index, T item)
        {
            Index = index;
            Item = item;
        }
    }

    public static class DictionaryPolyfills
    {
        public static TValue GetValueOrDefault<TKey, TValue>(this Dictionary<TKey, TValue> dictionary, TKey key, TValue defaultValue = default(TValue))
        {
            TValue value;
            return dictionary.TryGetValue(key, out value) ? value : defaultValue;
        }

        public static TValue GetValueOrDefault<TKey, TValue>(this SortedDictionary<TKey, TValue> dictionary, TKey key, TValue defaultValue = default(TValue))
        {
            TValue value;
            return dictionary.TryGetValue(key, out value) ? value : defaultValue;
        }

        public static TValue GetValueOrDefault<TKey, TValue>(this ConcurrentDictionary<TKey, TValue> dictionary, TKey key, TValue defaultValue = default(TValue))
        {
            TValue value;
            return dictionary.TryGetValue(key, out value) ? value : defaultValue;
        }

        public static TValue GetValueOrDefault<TKey, TValue>(this IReadOnlyDictionary<TKey, TValue> dictionary, TKey key, TValue defaultValue = default(TValue))
        {
            TValue value;
            return dictionary.TryGetValue(key, out value) ? value : defaultValue;
        }

        public static TValue GetValueOrDefault<TKey, TValue>(this IDictionary<TKey, TValue> dictionary, TKey key, TValue defaultValue = default(TValue))
        {
            TValue value;
            return dictionary.TryGetValue(key, out value) ? value : defaultValue;
        }

        public static bool TryAdd<TKey, TValue>(this Dictionary<TKey, TValue> dictionary, TKey key, TValue value)
        {
            if (dictionary.ContainsKey(key))
            {
                return false;
            }

            dictionary.Add(key, value);
            return true;
        }

        public static bool TryAdd<TKey, TValue>(this SortedDictionary<TKey, TValue> dictionary, TKey key, TValue value)
        {
            if (dictionary.ContainsKey(key))
            {
                return false;
            }

            dictionary.Add(key, value);
            return true;
        }

        public static bool Remove<TKey, TValue>(this Dictionary<TKey, TValue> dictionary, TKey key, out TValue value)
        {
            if (dictionary.TryGetValue(key, out value))
            {
                dictionary.Remove(key);
                return true;
            }

            return false;
        }

        public static void Deconstruct<TKey, TValue>(this KeyValuePair<TKey, TValue> pair, out TKey key, out TValue value)
        {
            key = pair.Key;
            value = pair.Value;
        }

        public static bool TryDequeue<T>(this Queue<T> queue, out T result)
        {
            if (queue.Count > 0)
            {
                result = queue.Dequeue();
                return true;
            }

            result = default(T);
            return false;
        }

        public static bool TryPop<T>(this Stack<T> stack, out T result)
        {
            if (stack.Count > 0)
            {
                result = stack.Pop();
                return true;
            }

            result = default(T);
            return false;
        }

        public static bool TryPeek<T>(this Stack<T> stack, out T result)
        {
            if (stack.Count > 0)
            {
                result = stack.Peek();
                return true;
            }

            result = default(T);
            return false;
        }

        public static IReadOnlyDictionary<TKey, TValue> AsReadOnly<TKey, TValue>(this IDictionary<TKey, TValue> dictionary)
        {
            return new System.Collections.ObjectModel.ReadOnlyDictionary<TKey, TValue>(dictionary);
        }
    }

    public static class StreamPolyfills
    {
        public static Task CopyToAsync(this Stream source, Stream destination, CancellationToken cancellationToken)
        {
            return source.CopyToAsync(destination, 81920, cancellationToken);
        }

        public static Task<int> ReadAsync(this Stream stream, byte[] buffer, CancellationToken cancellationToken)
        {
            return stream.ReadAsync(buffer, 0, buffer.Length, cancellationToken);
        }

        public static Task WriteAsync(this Stream stream, byte[] buffer, CancellationToken cancellationToken)
        {
            return stream.WriteAsync(buffer, 0, buffer.Length, cancellationToken);
        }
    }

    public static class TaskPolyfills
    {
        /// <summary>Task.WaitAsync(CancellationToken): stops waiting (the task itself goes on) when the token is cancelled.</summary>
        public static async Task<T> WaitAsync<T>(this Task<T> task, CancellationToken cancellationToken)
        {
            var cancelled = new TaskCompletionSource<bool>();
            using (cancellationToken.Register(() => cancelled.TrySetResult(true)))
            {
                if (await Task.WhenAny(task, cancelled.Task).ConfigureAwait(false) != task)
                {
                    throw new OperationCanceledException(cancellationToken);
                }
            }

            return await task.ConfigureAwait(false);
        }
    }

    public static class CompatBinary
    {
        /// <summary>BinaryPrimitives.ReadInt32LittleEndian: the first four bytes as a little-endian integer.</summary>
        public static int ReadInt32LittleEndian(byte[] bytes)
        {
            return bytes[0] | (bytes[1] << 8) | (bytes[2] << 16) | (bytes[3] << 24);
        }
    }

    public static class CompatMath
    {
        public static int Clamp(int value, int min, int max)
        {
            return value < min ? min : value > max ? max : value;
        }

        public static long Clamp(long value, long min, long max)
        {
            return value < min ? min : value > max ? max : value;
        }

        public static double Clamp(double value, double min, double max)
        {
            return value < min ? min : value > max ? max : value;
        }

        public static decimal Clamp(decimal value, decimal min, decimal max)
        {
            return value < min ? min : value > max ? max : value;
        }
    }

    public static class CompatGuard
    {
        public static void ThrowIfNull(object argument, string paramName = null)
        {
            if (argument == null)
            {
                throw new ArgumentNullException(paramName);
            }
        }

        public static void ThrowIfNullOrEmpty(string argument, string paramName = null)
        {
            if (argument == null)
            {
                throw new ArgumentNullException(paramName);
            }

            if (argument.Length == 0)
            {
                throw new ArgumentException("The value cannot be an empty string.", paramName);
            }
        }

        public static void ThrowIfNullOrWhiteSpace(string argument, string paramName = null)
        {
            if (argument == null)
            {
                throw new ArgumentNullException(paramName);
            }

            if (argument.Trim().Length == 0)
            {
                throw new ArgumentException("The value cannot be an empty string or composed entirely of whitespace.", paramName);
            }
        }

        public static void ThrowIfNegative(int value, string paramName = null)
        {
            if (value < 0)
            {
                throw new ArgumentOutOfRangeException(paramName);
            }
        }
    }

    public static class CompatHex
    {
        public static string ToHexString(byte[] bytes)
        {
            var b = new StringBuilder(bytes.Length * 2);
            foreach (var x in bytes)
            {
                b.Append(x.ToString("X2", CultureInfo.InvariantCulture));
            }

            return b.ToString();
        }

        public static string ToHexStringLower(byte[] bytes)
        {
            return ToHexString(bytes).ToLowerInvariant();
        }

        public static byte[] FromHexString(string hex)
        {
            if (hex.Length % 2 != 0)
            {
                throw new FormatException("The hex string has an odd length.");
            }

            var result = new byte[hex.Length / 2];
            for (var i = 0; i < result.Length; i++)
            {
                result[i] = byte.Parse(hex.Substring(i * 2, 2), NumberStyles.HexNumber, CultureInfo.InvariantCulture);
            }

            return result;
        }
    }

    public static class CompatHash
    {
        public static byte[] Sha256(byte[] data)
        {
            using (var sha = SHA256.Create())
            {
                return sha.ComputeHash(data);
            }
        }

        public static byte[] Sha256(Stream data)
        {
            using (var sha = SHA256.Create())
            {
                return sha.ComputeHash(data);
            }
        }

        public static Task<byte[]> Sha256Async(Stream data, CancellationToken cancellationToken = default(CancellationToken))
        {
            return Task.Run(() => Sha256(data), cancellationToken);
        }
    }

    public static class CompatRandom
    {
        private static readonly ThreadLocal<Random> Local = new ThreadLocal<Random>(() => new Random(Guid.NewGuid().GetHashCode()));

        /// <summary>Random.Shared: a non-cryptographic generator safe to use from any thread.</summary>
        public static Random Shared
        {
            get { return Local.Value; }
        }

        public static byte[] GetBytes(int count)
        {
            var bytes = new byte[count];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(bytes);
            }

            return bytes;
        }

        /// <summary>A cryptographically random integer in [minInclusive, maxExclusive).</summary>
        public static int GetInt32(int minInclusive, int maxExclusive)
        {
            if (minInclusive >= maxExclusive)
            {
                throw new ArgumentOutOfRangeException("maxExclusive");
            }

            var range = (uint)(maxExclusive - minInclusive);
            var limit = uint.MaxValue - (uint.MaxValue % range);
            uint value;
            do
            {
                value = BitConverter.ToUInt32(GetBytes(4), 0);
            }
            while (value >= limit);
            return (int)(minInclusive + (value % range));
        }

        public static int GetInt32(int maxExclusive)
        {
            return GetInt32(0, maxExclusive);
        }
    }

    public static class CompatCrypto
    {
        /// <summary>Compares two byte arrays in time that does not depend on where they differ.</summary>
        public static bool FixedTimeEquals(byte[] left, byte[] right)
        {
            if (left == null || right == null || left.Length != right.Length)
            {
                return false;
            }

            var difference = 0;
            for (var i = 0; i < left.Length; i++)
            {
                difference |= left[i] ^ right[i];
            }

            return difference == 0;
        }
    }

    public static class CompatEnum
    {
        public static T Parse<T>(string value, bool ignoreCase = false) where T : struct
        {
            return (T)Enum.Parse(typeof(T), value, ignoreCase);
        }

        public static T[] GetValues<T>() where T : struct
        {
            return (T[])Enum.GetValues(typeof(T));
        }

        public static bool IsDefined<T>(T value) where T : struct
        {
            return Enum.IsDefined(typeof(T), value);
        }
    }

    public static class CompatFile
    {
        public static Task<byte[]> ReadAllBytesAsync(string path, CancellationToken cancellationToken = default(CancellationToken))
        {
            return Task.Run(() => File.ReadAllBytes(path), cancellationToken);
        }

        public static Task<string> ReadAllTextAsync(string path, CancellationToken cancellationToken = default(CancellationToken))
        {
            return Task.Run(() => File.ReadAllText(path), cancellationToken);
        }

        public static Task WriteAllBytesAsync(string path, byte[] bytes, CancellationToken cancellationToken = default(CancellationToken))
        {
            return Task.Run(() => File.WriteAllBytes(path, bytes), cancellationToken);
        }

        public static Task WriteAllTextAsync(string path, string text, CancellationToken cancellationToken = default(CancellationToken))
        {
            return Task.Run(() => File.WriteAllText(path, text), cancellationToken);
        }
    }

    public static class CompatPath
    {
        public static string Join(params string[] parts)
        {
            var b = new StringBuilder();
            foreach (var part in parts)
            {
                if (string.IsNullOrEmpty(part))
                {
                    continue;
                }

                if (b.Length > 0 && b[b.Length - 1] != Path.DirectorySeparatorChar && b[b.Length - 1] != Path.AltDirectorySeparatorChar
                    && part[0] != Path.DirectorySeparatorChar && part[0] != Path.AltDirectorySeparatorChar)
                {
                    b.Append(Path.DirectorySeparatorChar);
                }

                b.Append(part);
            }

            return b.ToString();
        }

        public static string GetRelativePath(string relativeTo, string path)
        {
            var from = Path.GetFullPath(relativeTo).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar;
            var to = Path.GetFullPath(path);
            var fromUri = new Uri(from);
            var toUri = new Uri(to);
            if (fromUri.Scheme != toUri.Scheme)
            {
                return to;
            }

            var relative = Uri.UnescapeDataString(fromUri.MakeRelativeUri(toUri).ToString());
            return relative.Replace('/', Path.DirectorySeparatorChar);
        }
    }

    public static class CompatOs
    {
        public static bool IsWindows()
        {
            return Environment.OSVersion.Platform == PlatformID.Win32NT;
        }
    }

    public static class CompatEnvironment
    {
        public static int ProcessId
        {
            get { return System.Diagnostics.Process.GetCurrentProcess().Id; }
        }
    }

    /// <summary>System.HashCode (.NET Core 2.1): combines hash codes.</summary>
    public struct HashCode
    {
        private int hash;
        private bool started;

        public void Add<T>(T value)
        {
            Add(value, EqualityComparer<T>.Default);
        }

        public void Add<T>(T value, IEqualityComparer<T> comparer)
        {
            unchecked
            {
                if (!started)
                {
                    hash = 17;
                    started = true;
                }

                hash = hash * 31 + (value == null ? 0 : comparer.GetHashCode(value));
            }
        }

        public int ToHashCode()
        {
            return hash;
        }

        public static int Combine<T1, T2>(T1 a, T2 b)
        {
            var h = new HashCode();
            h.Add(a);
            h.Add(b);
            return h.ToHashCode();
        }

        public static int Combine<T1, T2, T3>(T1 a, T2 b, T3 c)
        {
            var h = new HashCode();
            h.Add(a);
            h.Add(b);
            h.Add(c);
            return h.ToHashCode();
        }

        public static int Combine<T1, T2, T3, T4>(T1 a, T2 b, T3 c, T4 d)
        {
            var h = new HashCode();
            h.Add(a);
            h.Add(b);
            h.Add(c);
            h.Add(d);
            return h.ToHashCode();
        }
    }

    /// <summary>System.TimeProvider (.NET 8): the clock, replaceable in tests.</summary>
    public abstract class TimeProvider
    {
        public static TimeProvider System { get; } = new SystemTimeProvider();

        public virtual TimeZoneInfo LocalTimeZone
        {
            get { return TimeZoneInfo.Local; }
        }

        public virtual DateTimeOffset GetUtcNow()
        {
            return DateTimeOffset.UtcNow;
        }

        public DateTimeOffset GetLocalNow()
        {
            var utc = GetUtcNow();
            return TimeZoneInfo.ConvertTime(utc, LocalTimeZone);
        }

        public virtual long GetTimestamp()
        {
            return global::System.Diagnostics.Stopwatch.GetTimestamp();
        }

        public TimeSpan GetElapsedTime(long startingTimestamp)
        {
            return TimeSpan.FromTicks((long)((GetTimestamp() - startingTimestamp) * ((double)TimeSpan.TicksPerSecond / global::System.Diagnostics.Stopwatch.Frequency)));
        }

        private sealed class SystemTimeProvider : TimeProvider
        {
        }
    }
}
