﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Models;

namespace FrpMapper.Shared.Validation
{
    /// <summary>
    /// Checks a single value against the XSD facets captured for a schema node
    /// (data type, enumeration, pattern, range, digits and length).
    /// Shared by the API (authoritative checks) and the UI (inline feedback while editing).
    /// </summary>
    public static class XsdValueValidator
    {
        private static readonly ConcurrentDictionary<string, Regex> PatternCache = new ConcurrentDictionary<string, Regex>(StringComparer.Ordinal);

        public static IReadOnlyList<string> Validate(string value, SchemaNodeDto node)
        {
            var errors = new List<string>();
            if (node.DataType == "complex")
            {
                return errors;
            }

            var validation = node.Validation ?? new SchemaValidationDto();
            var raw = value ?? "";
            var text = NormalizeWhitespace(node.DataType == "string" ? raw : raw.Trim(), validation.WhiteSpace);

            if (text.Length == 0)
            {
                if (node.IsRequired)
                {
                    errors.Add("A value is required by the XSD.");
                }

                return errors;
            }

            if (node.DataType == "integer" && !IsInteger(text))
            {
                errors.Add($"'{text}' is not a valid integer.");
                return errors;
            }
            else if (node.DataType == "decimal" && !IsDecimal(text))
            {
                errors.Add($"'{text}' is not a valid decimal number.");
                return errors;
            }
            else if (node.DataType == "date" && !IsDate(text))
            {
                errors.Add($"'{text}' is not a valid date (expected yyyy-MM-dd).");
                return errors;
            }
            else if (node.DataType == "dateTime" && !IsDateTime(text))
            {
                errors.Add($"'{text}' is not a valid date and time (expected yyyy-MM-ddTHH:mm:ss).");
                return errors;
            }
            else if (node.DataType == "boolean" && !(text == "true" || text == "false" || text == "1" || text == "0"))
            {
                errors.Add($"'{text}' is not a valid boolean (true, false, 1 or 0).");
                return errors;
            }

            if (validation.Enumerations.Count > 0 && !validation.Enumerations.Contains(text, StringComparer.Ordinal))
            {
                var allowed = validation.Enumerations.Count <= 12
                    ? string.Join(", ", validation.Enumerations)
                    : string.Join(", ", validation.Enumerations.Take(12)) + $", ... ({validation.Enumerations.Count} values)";
                errors.Add($"'{text}' is not an allowed value. Allowed: {allowed}.");
            }

            string fixedValue;
            if (CompatPattern.Is(validation.FixedValue, out fixedValue) && text != NormalizeWhitespace(fixedValue, validation.WhiteSpace))
            {
                errors.Add($"The XSD requires the fixed value '{fixedValue}'.");
            }
            string pattern;
            var patternGroups = validation.PatternGroups.Count > 0 ? validation.PatternGroups
                : CompatPattern.Is(validation.Pattern, out pattern) ? new IReadOnlyList<string>[] { new[] { pattern } } : new IReadOnlyList<string>[0];
            foreach (var group in patternGroups)
            {
                if (!group.Any(pattern2 => { Regex regex; return !CompatPattern.Is(GetPatternRegex(pattern2), out regex) || regex.IsMatch(text); }))
                {
                    errors.Add($"'{text}' does not match the XSD pattern {string.Join(" or ", group)}.");
                }
            }

            decimal number;
            if ((node.DataType == "integer" || node.DataType == "decimal")
                && decimal.TryParse(text, NumberStyles.Number, CultureInfo.InvariantCulture, out number))
            {
                decimal min;
                if (TryParseDecimal(validation.MinInclusive, out min) && number < min)
                {
                    errors.Add($"{text} is below the minimum of {validation.MinInclusive}.");
                }

                decimal max;
                if (TryParseDecimal(validation.MaxInclusive, out max) && number > max)
                {
                    errors.Add($"{text} is above the maximum of {validation.MaxInclusive}.");
                }
                decimal exclusiveMin;
                if (TryParseDecimal(validation.MinExclusive, out exclusiveMin) && number <= exclusiveMin)
                    errors.Add($"{text} must be greater than {validation.MinExclusive}.");
                decimal exclusiveMax;
                if (TryParseDecimal(validation.MaxExclusive, out exclusiveMax) && number >= exclusiveMax)
                    errors.Add($"{text} must be less than {validation.MaxExclusive}.");

                var digits2 = CountDigits(text);
                var totalDigits = digits2.TotalDigits;
                var fractionDigits = digits2.FractionDigits;
                int allowedTotal;
                if (CompatPattern.Is(validation.TotalDigits, out allowedTotal) && totalDigits > allowedTotal)
                {
                    errors.Add($"'{text}' has {totalDigits} digits; the XSD allows at most {allowedTotal}.");
                }

                int allowedFraction;
                if (CompatPattern.Is(validation.FractionDigits, out allowedFraction) && fractionDigits > allowedFraction)
                {
                    errors.Add($"'{text}' has {fractionDigits} decimal places; the XSD allows at most {allowedFraction}.");
                }
            }
            else if (node.DataType == "date" || node.DataType == "dateTime")
            {
                if (!string.IsNullOrEmpty(validation.MinInclusive) && string.CompareOrdinal(text, validation.MinInclusive) < 0)
                {
                    errors.Add($"'{text}' is before the minimum of {validation.MinInclusive}.");
                }

                if (!string.IsNullOrEmpty(validation.MaxInclusive) && string.CompareOrdinal(text, validation.MaxInclusive) > 0)
                {
                    errors.Add($"'{text}' is after the maximum of {validation.MaxInclusive}.");
                }
            }

            int minLength;
            if (CompatPattern.Is(validation.MinLength, out minLength) && text.Length < minLength)
            {
                errors.Add($"'{text}' is shorter than the minimum length of {minLength}.");
            }
            int length;
            if (CompatPattern.Is(validation.Length, out length) && text.Length != length)
                errors.Add($"'{text}' must have exactly {length} characters.");

            int maxLength;
            if (CompatPattern.Is(validation.MaxLength, out maxLength) && text.Length > maxLength)
            {
                errors.Add($"'{text}' is longer than the maximum length of {maxLength}.");
            }

            return errors;
        }

        public static bool IsValid(string value, SchemaNodeDto node) => Validate(value, node).Count == 0;

        public static string NormalizeWhitespace(string text, string mode)
        {
            if (!(mode == "replace" || mode == "collapse")) return text;
            text = text.Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ');
            return mode == "collapse" ? string.Join(" ", text.Split(' ', StringSplitOptions.RemoveEmptyEntries)) : text;
        }

        private static Regex GetPatternRegex(string pattern)
        {
            return PatternCache.GetOrAdd(pattern, p =>
            {
                try
                {
                    // XSD patterns are implicitly anchored to the whole value.
                    return new Regex($"^(?:{p})$", RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(200));
                }
                catch (ArgumentException)
                {
                    // Pattern uses XSD-only syntax .NET cannot parse; full-document schema validation still checks it.
                    return null;
                }
            });
        }

        private static bool IsInteger(string text) => Regex.IsMatch(text, @"^[+-]?\d+$");

        private static bool IsDecimal(string text) => Regex.IsMatch(text, @"^[+-]?(\d+(\.\d*)?|\.\d+)$");

        private static bool IsDate(string text)
        {
            var datePart = text.Length >= 10 ? text.Substring(0, 10) : text;
            DateOnly date;
            return DateOnly.TryParseExact(datePart, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date)
                && (text.Length == 10 || Regex.IsMatch(text.Substring(10), @"^(Z|[+-]\d{2}:\d{2})$"));
        }

        private static bool IsDateTime(string text)
        {
            try
            {
                XmlConvert.ToDateTimeOffset(text);
                return text.Contains('T');
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private static bool TryParseDecimal(string value, out decimal result)
        {
            return decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out result);
        }

        private static VT_TotalDigits_FractionDigits<int, int> CountDigits(string text)
        {
            var unsigned = text.TrimStart('+', '-');
            var parts = unsigned.Split('.', 2);
            var integerPart = parts[0].TrimStart('0');
            var fractionPart = parts.Length > 1 ? parts[1].TrimEnd('0') : "";
            return new VT_TotalDigits_FractionDigits<int, int>(integerPart.Length + fractionPart.Length, fractionPart.Length);
        }
    }

}
