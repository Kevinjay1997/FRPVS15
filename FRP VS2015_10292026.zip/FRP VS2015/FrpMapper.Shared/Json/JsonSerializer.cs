using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Shared.Json
{
    /// <summary>
    /// JSON for .NET Framework, written to behave like System.Text.Json (which the .NET 9 version used): property names
    /// camelCase with <see cref="JsonSerializerDefaults.Web"/> (as PascalCase otherwise), case-insensitive reading for Web,
    /// numbers readable from strings for Web, nulls written, enums as numbers unless the enum is marked with
    /// [JsonConverter(typeof(JsonStringEnumConverter&lt;T&gt;))], public properties only (no fields), [JsonIgnore] honoured,
    /// and classes without a parameterless constructor created through their constructor (positional records).
    /// </summary>
    public static class JsonSerializer
    {
        public static string Serialize<T>(T value, JsonSerializerOptions options = null)
        {
            return Serialize(value, typeof(T), options);
        }

        public static string Serialize(object value, Type type, JsonSerializerOptions options = null)
        {
            var builder = new StringBuilder();
            new JsonWriter(builder, options ?? JsonSerializerOptions.Default).WriteValue(value, type);
            return builder.ToString();
        }

        public static T Deserialize<T>(string json, JsonSerializerOptions options = null)
        {
            return (T)Deserialize(json, typeof(T), options);
        }

        public static object Deserialize(string json, Type type, JsonSerializerOptions options = null)
        {
            if (json == null)
            {
                throw new ArgumentNullException("json");
            }

            var value = new JsonParser(json).ParseDocument();
            return JsonConverterCore.Convert(value, type, options ?? JsonSerializerOptions.Default);
        }

        /// <summary>
        /// The JSON as plain objects: Dictionary&lt;string, object&gt; for objects, List&lt;object&gt; for arrays, string, bool,
        /// decimal or double for numbers, null.
        /// </summary>
        public static object Parse(string json)
        {
            return JsonConverterCore.Plain(new JsonParser(json).ParseDocument());
        }

        /// <summary>
        /// As <see cref="Parse"/>, but a property name repeated within one object is an error instead of the last value
        /// winning. Use it for JSON that is checked here and then sent on as written, so the receiver cannot read a value
        /// that was not checked.
        /// </summary>
        public static object ParseStrict(string json)
        {
            if (json == null)
            {
                throw new ArgumentNullException("json");
            }

            return JsonConverterCore.Plain(new JsonParser(json, true).ParseDocument());
        }
    }

    public enum JsonSerializerDefaults
    {
        General,
        Web
    }

    public sealed class JsonSerializerOptions
    {
        internal static readonly JsonSerializerOptions Default = new JsonSerializerOptions();

        public JsonSerializerOptions()
        {
        }

        public JsonSerializerOptions(JsonSerializerDefaults defaults)
        {
            if (defaults == JsonSerializerDefaults.Web)
            {
                CamelCase = true;
                PropertyNameCaseInsensitive = true;
                NumbersFromStrings = true;
            }
        }

        /// <summary>Property names written camelCase (System.Text.Json's JsonNamingPolicy.CamelCase).</summary>
        public bool CamelCase { get; set; }

        public bool PropertyNameCaseInsensitive { get; set; }

        /// <summary>Numbers may be read from JSON strings ("12").</summary>
        public bool NumbersFromStrings { get; set; }
    }

    /// <summary>The property is not written or read.</summary>
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public sealed class JsonIgnoreAttribute : Attribute
    {
    }

    /// <summary>Marks an enum to be written as its name (use with <see cref="JsonStringEnumConverter{TEnum}"/>).</summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Enum | AttributeTargets.Property)]
    public sealed class JsonConverterAttribute : Attribute
    {
        public JsonConverterAttribute(Type converterType)
        {
            ConverterType = converterType;
        }

        public Type ConverterType { get; private set; }
    }

    /// <summary>Marker: the enum is written as its name, and read from its name (any case) or number.</summary>
    public sealed class JsonStringEnumConverter<TEnum> where TEnum : struct
    {
    }

    /// <summary>Marker without a type parameter, for the same purpose.</summary>
    public sealed class JsonStringEnumConverter
    {
    }

    [Serializable]
    public sealed class JsonException : Exception
    {
        public JsonException(string message) : base(message)
        {
        }

        public JsonException(string message, Exception inner) : base(message, inner)
        {
        }
    }

    // ------------------------------------------------------------------ reflection metadata

    internal sealed class JsonProperty
    {
        public PropertyInfo Property;
        public string Name;
        public string CamelName;
        public bool CanRead;
        public bool CanWrite;
        public Func<object, object> Getter;
    }

    internal sealed class JsonTypeInfo
    {
        public Type Type;
        public List<JsonProperty> Properties;
        public ConstructorInfo DefaultConstructor;
        public ConstructorInfo ParameterizedConstructor;
        public ParameterInfo[] ConstructorParameters;
    }

    internal static class JsonMetadata
    {
        private static readonly ConcurrentDictionary<Type, JsonTypeInfo> Types = new ConcurrentDictionary<Type, JsonTypeInfo>();
        private static readonly ConcurrentDictionary<Type, bool> StringEnums = new ConcurrentDictionary<Type, bool>();

        public static JsonTypeInfo For(Type type)
        {
            return Types.GetOrAdd(type, Build);
        }

        public static bool IsStringEnum(Type enumType)
        {
            return StringEnums.GetOrAdd(enumType, t => t.GetCustomAttributes(typeof(JsonConverterAttribute), false)
                .OfType<JsonConverterAttribute>()
                .Any(a => a.ConverterType != null && a.ConverterType.Name.StartsWith("JsonStringEnumConverter", StringComparison.Ordinal)));
        }

        private static JsonTypeInfo Build(Type type)
        {
            var properties = new List<JsonProperty>();
            var seen = new HashSet<string>(StringComparer.Ordinal);
            // Declared order, most derived type first (as System.Text.Json reflects them).
            for (var t = type; t != null && t != typeof(object); t = t.BaseType)
            {
                foreach (var p in t.GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly).OrderBy(p => p.MetadataToken))
                {
                    if (p.GetIndexParameters().Length > 0 || p.IsDefined(typeof(JsonIgnoreAttribute), true) || !seen.Add(p.Name))
                    {
                        continue;
                    }

                    var getter = p.GetGetMethod(false);
                    var setter = p.GetSetMethod(false);
                    var property = new JsonProperty
                    {
                        Property = p,
                        Name = p.Name,
                        CamelName = CamelCase(p.Name),
                        CanRead = getter != null,
                        CanWrite = setter != null
                    };
                    var captured = p;
                    property.Getter = o => captured.GetValue(o, null);
                    properties.Add(property);
                }
            }

            var info = new JsonTypeInfo { Type = type, Properties = properties };
            info.DefaultConstructor = type.GetConstructor(Type.EmptyTypes);
            if (info.DefaultConstructor == null && !type.IsValueType)
            {
                var constructors = type.GetConstructors(BindingFlags.Public | BindingFlags.Instance);
                info.ParameterizedConstructor = constructors.OrderByDescending(c => c.GetParameters().Length).FirstOrDefault();
                info.ConstructorParameters = info.ParameterizedConstructor == null ? new ParameterInfo[0] : info.ParameterizedConstructor.GetParameters();
            }

            return info;
        }

        /// <summary>System.Text.Json's JsonNamingPolicy.CamelCase.</summary>
        public static string CamelCase(string name)
        {
            if (string.IsNullOrEmpty(name) || !char.IsUpper(name[0]))
            {
                return name;
            }

            var chars = name.ToCharArray();
            for (var i = 0; i < chars.Length; i++)
            {
                if (i == 1 && !char.IsUpper(chars[i]))
                {
                    break;
                }

                var hasNext = i + 1 < chars.Length;
                if (i > 0 && hasNext && !char.IsUpper(chars[i + 1]))
                {
                    if (chars[i + 1] == ' ')
                    {
                        chars[i] = char.ToLowerInvariant(chars[i]);
                    }

                    break;
                }

                chars[i] = char.ToLowerInvariant(chars[i]);
            }

            return new string(chars);
        }

        /// <summary>The element type of a sequence type (T of IEnumerable&lt;T&gt;), or object.</summary>
        public static Type ElementType(Type type)
        {
            if (type.IsArray)
            {
                return type.GetElementType();
            }

            var enumerable = type.IsGenericType && type.GetGenericTypeDefinition() == typeof(IEnumerable<>)
                ? type
                : type.GetInterfaces().FirstOrDefault(i => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IEnumerable<>));
            return enumerable == null ? typeof(object) : enumerable.GetGenericArguments()[0];
        }

        /// <summary>Key and value types when the type is a dictionary (IDictionary&lt;,&gt; or IReadOnlyDictionary&lt;,&gt;).</summary>
        public static Type[] DictionaryTypes(Type type)
        {
            var candidates = new[] { type }.Concat(type.GetInterfaces());
            foreach (var t in candidates)
            {
                if (t.IsGenericType)
                {
                    var definition = t.GetGenericTypeDefinition();
                    if (definition == typeof(IDictionary<,>) || definition == typeof(IReadOnlyDictionary<,>) || definition == typeof(Dictionary<,>)
                        || definition == typeof(SortedDictionary<,>))
                    {
                        return t.GetGenericArguments();
                    }
                }
            }

            return null;
        }
    }

    // ------------------------------------------------------------------ writing

    internal sealed class JsonWriter
    {
        private readonly StringBuilder b;
        private readonly JsonSerializerOptions options;
        private int depth;

        public JsonWriter(StringBuilder builder, JsonSerializerOptions options)
        {
            b = builder;
            this.options = options;
        }

        public void WriteValue(object value, Type declared)
        {
            if (value == null)
            {
                b.Append("null");
                return;
            }

            var type = declared == null || declared == typeof(object) || declared.IsInterface && !IsSequenceInterface(declared) ? value.GetType() : declared;
            type = Nullable.GetUnderlyingType(type) ?? type;
            if (++depth > 64)
            {
                throw new JsonException("The object is nested too deeply to be written as JSON.");
            }

            try
            {
                WriteTyped(value, type);
            }
            finally
            {
                depth--;
            }
        }

        private static bool IsSequenceInterface(Type type)
        {
            return type.IsGenericType && (typeof(IEnumerable).IsAssignableFrom(type));
        }

        private void WriteTyped(object value, Type type)
        {
            if (type == typeof(string))
            {
                WriteString((string)value);
            }
            else if (type == typeof(bool))
            {
                b.Append((bool)value ? "true" : "false");
            }
            else if (type == typeof(char))
            {
                WriteString(value.ToString());
            }
            else if (type.IsEnum)
            {
                if (JsonMetadata.IsStringEnum(type))
                {
                    WriteString(value.ToString());
                }
                else
                {
                    b.Append(Convert.ToInt64(value, CultureInfo.InvariantCulture).ToString(CultureInfo.InvariantCulture));
                }
            }
            else if (type == typeof(int) || type == typeof(long) || type == typeof(short) || type == typeof(byte) || type == typeof(sbyte)
                || type == typeof(uint) || type == typeof(ulong) || type == typeof(ushort))
            {
                b.Append(Convert.ToString(value, CultureInfo.InvariantCulture));
            }
            else if (type == typeof(double) || type == typeof(float))
            {
                var d = Convert.ToDouble(value, CultureInfo.InvariantCulture);
                if (double.IsNaN(d) || double.IsInfinity(d))
                {
                    throw new JsonException("NaN and infinity cannot be written as JSON numbers.");
                }

                b.Append(type == typeof(float) ? ((float)value).ToString("R", CultureInfo.InvariantCulture) : d.ToString("R", CultureInfo.InvariantCulture));
            }
            else if (type == typeof(decimal))
            {
                b.Append(((decimal)value).ToString(CultureInfo.InvariantCulture));
            }
            else if (type == typeof(DateTimeOffset))
            {
                WriteString(((DateTimeOffset)value).ToString("yyyy-MM-dd'T'HH:mm:ss.FFFFFFFzzz", CultureInfo.InvariantCulture));
            }
            else if (type == typeof(DateTime))
            {
                var dt = (DateTime)value;
                var text = dt.ToString("yyyy-MM-dd'T'HH:mm:ss.FFFFFFF", CultureInfo.InvariantCulture);
                if (dt.Kind == DateTimeKind.Utc)
                {
                    text += "Z";
                }
                else if (dt.Kind == DateTimeKind.Local)
                {
                    text += dt.ToString("zzz", CultureInfo.InvariantCulture);
                }

                WriteString(text);
            }
            else if (type == typeof(DateOnly))
            {
                WriteString(((DateOnly)value).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
            }
            else if (type == typeof(TimeSpan))
            {
                WriteString(((TimeSpan)value).ToString("c", CultureInfo.InvariantCulture));
            }
            else if (type == typeof(Guid))
            {
                WriteString(((Guid)value).ToString("D"));
            }
            else if (type == typeof(byte[]))
            {
                WriteString(Convert.ToBase64String((byte[])value));
            }
            else if (value is IDictionary)
            {
                var types = JsonMetadata.DictionaryTypes(type) ?? JsonMetadata.DictionaryTypes(value.GetType());
                var valueType = types == null ? typeof(object) : types[1];
                b.Append('{');
                var first = true;
                foreach (DictionaryEntry entry in (IDictionary)value)
                {
                    if (!first)
                    {
                        b.Append(',');
                    }

                    first = false;
                    WriteString(Convert.ToString(entry.Key, CultureInfo.InvariantCulture));
                    b.Append(':');
                    WriteValue(entry.Value, valueType);
                }

                b.Append('}');
            }
            else if (JsonMetadata.DictionaryTypes(type) != null && value is IEnumerable)
            {
                // IReadOnlyDictionary implemented by a type that is not an IDictionary
                var valueType = JsonMetadata.DictionaryTypes(type)[1];
                b.Append('{');
                var first = true;
                foreach (var pair in (IEnumerable)value)
                {
                    var pairType = pair.GetType();
                    var key = pairType.GetProperty("Key").GetValue(pair, null);
                    var item = pairType.GetProperty("Value").GetValue(pair, null);
                    if (!first)
                    {
                        b.Append(',');
                    }

                    first = false;
                    WriteString(Convert.ToString(key, CultureInfo.InvariantCulture));
                    b.Append(':');
                    WriteValue(item, valueType);
                }

                b.Append('}');
            }
            else if (value is IEnumerable)
            {
                var elementType = JsonMetadata.ElementType(type);
                b.Append('[');
                var first = true;
                foreach (var item in (IEnumerable)value)
                {
                    if (!first)
                    {
                        b.Append(',');
                    }

                    first = false;
                    WriteValue(item, elementType);
                }

                b.Append(']');
            }
            else
            {
                var info = JsonMetadata.For(type);
                b.Append('{');
                var first = true;
                foreach (var property in info.Properties)
                {
                    if (!property.CanRead)
                    {
                        continue;
                    }

                    if (!first)
                    {
                        b.Append(',');
                    }

                    first = false;
                    WriteString(options.CamelCase ? property.CamelName : property.Name);
                    b.Append(':');
                    WriteValue(property.Getter(value), property.Property.PropertyType);
                }

                b.Append('}');
            }
        }

        private void WriteString(string text)
        {
            b.Append('"');
            foreach (var ch in text)
            {
                switch (ch)
                {
                    case '"': b.Append("\\\""); break;
                    case '\\': b.Append("\\\\"); break;
                    case '\n': b.Append("\\n"); break;
                    case '\r': b.Append("\\r"); break;
                    case '\t': b.Append("\\t"); break;
                    case '\b': b.Append("\\b"); break;
                    case '\f': b.Append("\\f"); break;
                    // as System.Text.Json's default encoder: HTML-sensitive characters escaped
                    case '<':
                    case '>':
                    case '&':
                    case '\'':
                    case '+':
                    case '`':
                        b.Append("\\u").Append(((int)ch).ToString("X4", CultureInfo.InvariantCulture));
                        break;
                    default:
                        if (ch < 0x20 || ch == (char)0x2028 || ch == (char)0x2029)
                        {
                            b.Append("\\u").Append(((int)ch).ToString("X4", CultureInfo.InvariantCulture));
                        }
                        else
                        {
                            b.Append(ch);
                        }

                        break;
                }
            }

            b.Append('"');
        }
    }

    // ------------------------------------------------------------------ reading

    internal sealed class JsonNumber
    {
        public string Text;
    }

    internal sealed class JsonParser
    {
        private readonly string s;
        private int i;
        private int depth;
        private readonly bool rejectDuplicateNames;

        public JsonParser(string text) : this(text, false)
        {
        }

        public JsonParser(string text, bool rejectDuplicateNames)
        {
            s = text;
            this.rejectDuplicateNames = rejectDuplicateNames;
        }

        public object ParseDocument()
        {
            SkipWhitespace();
            var value = ParseValue();
            SkipWhitespace();
            if (i != s.Length)
            {
                throw Error("Unexpected text after the JSON value.");
            }

            return value;
        }

        private JsonException Error(string message)
        {
            return new JsonException(message + " (at position " + i.ToString(CultureInfo.InvariantCulture) + ")");
        }

        private void SkipWhitespace()
        {
            while (i < s.Length && (s[i] == ' ' || s[i] == '\t' || s[i] == '\n' || s[i] == '\r' || s[i] == '﻿'))
            {
                i++;
            }
        }

        private object ParseValue()
        {
            if (i >= s.Length)
            {
                throw Error("Unexpected end of JSON.");
            }

            var ch = s[i];
            switch (ch)
            {
                case '{':
                    return ParseObject();
                case '[':
                    return ParseArray();
                case '"':
                    return ParseString();
                case 't':
                    Expect("true");
                    return true;
                case 'f':
                    Expect("false");
                    return false;
                case 'n':
                    Expect("null");
                    return null;
                default:
                    if (ch == '-' || (ch >= '0' && ch <= '9'))
                    {
                        return ParseNumber();
                    }

                    throw Error("Unexpected character in JSON.");
            }
        }

        private void Expect(string word)
        {
            if (string.CompareOrdinal(s, i, word, 0, word.Length) != 0)
            {
                throw Error("Invalid JSON literal.");
            }

            i += word.Length;
        }

        private Dictionary<string, object> ParseObject()
        {
            if (++depth > 64)
            {
                throw Error("The JSON is nested too deeply.");
            }

            var result = new Dictionary<string, object>(StringComparer.Ordinal);
            i++;
            SkipWhitespace();
            if (i < s.Length && s[i] == '}')
            {
                i++;
                depth--;
                return result;
            }

            while (true)
            {
                SkipWhitespace();
                if (i >= s.Length || s[i] != '"')
                {
                    throw Error("Expected a property name.");
                }

                var name = ParseString();
                SkipWhitespace();
                if (i >= s.Length || s[i] != ':')
                {
                    throw Error("Expected ':'.");
                }

                i++;
                SkipWhitespace();
                if (rejectDuplicateNames && result.ContainsKey(name))
                {
                    throw Error("The property \"" + name + "\" appears more than once in the same object.");
                }

                result[name] = ParseValue();
                SkipWhitespace();
                if (i < s.Length && s[i] == ',')
                {
                    i++;
                    continue;
                }

                if (i < s.Length && s[i] == '}')
                {
                    i++;
                    depth--;
                    return result;
                }

                throw Error("Expected ',' or '}'.");
            }
        }

        private List<object> ParseArray()
        {
            if (++depth > 64)
            {
                throw Error("The JSON is nested too deeply.");
            }

            var result = new List<object>();
            i++;
            SkipWhitespace();
            if (i < s.Length && s[i] == ']')
            {
                i++;
                depth--;
                return result;
            }

            while (true)
            {
                SkipWhitespace();
                result.Add(ParseValue());
                SkipWhitespace();
                if (i < s.Length && s[i] == ',')
                {
                    i++;
                    continue;
                }

                if (i < s.Length && s[i] == ']')
                {
                    i++;
                    depth--;
                    return result;
                }

                throw Error("Expected ',' or ']'.");
            }
        }

        private string ParseString()
        {
            i++;
            var b = new StringBuilder();
            while (true)
            {
                if (i >= s.Length)
                {
                    throw Error("Unterminated JSON string.");
                }

                var ch = s[i++];
                if (ch == '"')
                {
                    return b.ToString();
                }

                if (ch == '\\')
                {
                    if (i >= s.Length)
                    {
                        throw Error("Unterminated JSON string.");
                    }

                    var e = s[i++];
                    switch (e)
                    {
                        case '"': b.Append('"'); break;
                        case '\\': b.Append('\\'); break;
                        case '/': b.Append('/'); break;
                        case 'b': b.Append('\b'); break;
                        case 'f': b.Append('\f'); break;
                        case 'n': b.Append('\n'); break;
                        case 'r': b.Append('\r'); break;
                        case 't': b.Append('\t'); break;
                        case 'u':
                            if (i + 4 > s.Length)
                            {
                                throw Error("Invalid \\u escape.");
                            }

                            int code;
                            if (!int.TryParse(s.Substring(i, 4), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out code))
                            {
                                throw Error("Invalid \\u escape.");
                            }

                            b.Append((char)code);
                            i += 4;
                            break;
                        default:
                            throw Error("Invalid escape in a JSON string.");
                    }
                }
                else
                {
                    if (ch < 0x20)
                    {
                        throw Error("Control character in a JSON string.");
                    }

                    b.Append(ch);
                }
            }
        }

        private JsonNumber ParseNumber()
        {
            var start = i;
            if (s[i] == '-')
            {
                i++;
            }

            while (i < s.Length && (char.IsDigit(s[i]) || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+' || s[i] == '-'))
            {
                i++;
            }

            var text = s.Substring(start, i - start);
            double check;
            if (!double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out check))
            {
                throw Error("Invalid JSON number.");
            }

            return new JsonNumber { Text = text };
        }
    }

    internal static class JsonConverterCore
    {
        public static object Plain(object value)
        {
            var number = value as JsonNumber;
            if (number != null)
            {
                decimal d;
                if (decimal.TryParse(number.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out d))
                {
                    return d;
                }

                return double.Parse(number.Text, NumberStyles.Float, CultureInfo.InvariantCulture);
            }

            var obj = value as Dictionary<string, object>;
            if (obj != null)
            {
                return obj.ToDictionary(p => p.Key, p => Plain(p.Value), StringComparer.Ordinal);
            }

            var list = value as List<object>;
            if (list != null)
            {
                return list.Select(Plain).ToList();
            }

            return value;
        }

        public static object Convert(object value, Type type, JsonSerializerOptions options)
        {
            var underlying = Nullable.GetUnderlyingType(type);
            if (value == null)
            {
                return type.IsValueType && underlying == null ? Activator.CreateInstance(type) : null;
            }

            if (underlying != null)
            {
                type = underlying;
            }

            if (type == typeof(object))
            {
                return Plain(value);
            }

            var text = value as string;
            var number = value as JsonNumber;
            try
            {
                if (type == typeof(string))
                {
                    if (text != null)
                    {
                        return text;
                    }

                    throw new JsonException("Expected a string.");
                }

                if (type == typeof(bool))
                {
                    if (value is bool)
                    {
                        return value;
                    }

                    throw new JsonException("Expected true or false.");
                }

                if (type.IsEnum)
                {
                    if (number != null)
                    {
                        return Enum.ToObject(type, long.Parse(number.Text, NumberStyles.Integer, CultureInfo.InvariantCulture));
                    }

                    if (text != null)
                    {
                        return Enum.Parse(type, text, true);
                    }

                    throw new JsonException("Expected an enum value.");
                }

                if (IsNumber(type))
                {
                    var numberText = number != null ? number.Text : options.NumbersFromStrings && text != null ? text : null;
                    if (numberText == null)
                    {
                        throw new JsonException("Expected a number.");
                    }

                    if (type == typeof(decimal))
                    {
                        return decimal.Parse(numberText, NumberStyles.Float, CultureInfo.InvariantCulture);
                    }

                    if (type == typeof(double))
                    {
                        return double.Parse(numberText, NumberStyles.Float, CultureInfo.InvariantCulture);
                    }

                    if (type == typeof(float))
                    {
                        return float.Parse(numberText, NumberStyles.Float, CultureInfo.InvariantCulture);
                    }

                    return System.Convert.ChangeType(decimal.Parse(numberText, NumberStyles.Float, CultureInfo.InvariantCulture), type, CultureInfo.InvariantCulture);
                }

                if (type == typeof(DateTimeOffset))
                {
                    return DateTimeOffset.Parse(Text(text), CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);
                }

                if (type == typeof(DateTime))
                {
                    return DateTime.Parse(Text(text), CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);
                }

                if (type == typeof(DateOnly))
                {
                    DateOnly date;
                    if (DateOnly.TryParseExact(Text(text), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                    {
                        return date;
                    }

                    throw new JsonException("Expected a date (yyyy-MM-dd).");
                }

                if (type == typeof(TimeSpan))
                {
                    return TimeSpan.Parse(Text(text), CultureInfo.InvariantCulture);
                }

                if (type == typeof(Guid))
                {
                    return Guid.Parse(Text(text));
                }

                if (type == typeof(char))
                {
                    var t = Text(text);
                    if (t.Length != 1)
                    {
                        throw new JsonException("Expected one character.");
                    }

                    return t[0];
                }

                if (type == typeof(byte[]))
                {
                    return System.Convert.FromBase64String(Text(text));
                }
            }
            catch (FormatException ex)
            {
                throw new JsonException("A JSON value has the wrong format.", ex);
            }
            catch (OverflowException ex)
            {
                throw new JsonException("A JSON number is out of range.", ex);
            }
            catch (ArgumentException ex)
            {
                throw new JsonException("A JSON value is not valid here.", ex);
            }

            var dictionaryTypes = JsonMetadata.DictionaryTypes(type);
            if (dictionaryTypes != null)
            {
                var obj = value as Dictionary<string, object>;
                if (obj == null)
                {
                    throw new JsonException("Expected a JSON object.");
                }

                var concrete = type.IsInterface || type.IsAbstract
                    ? typeof(Dictionary<,>).MakeGenericType(dictionaryTypes)
                    : type;
                var dictionary = (IDictionary)Activator.CreateInstance(concrete);
                foreach (var pair in obj)
                {
                    dictionary[ConvertKey(pair.Key, dictionaryTypes[0])] = Convert(pair.Value, dictionaryTypes[1], options);
                }

                return dictionary;
            }

            if (type.IsArray || (typeof(IEnumerable).IsAssignableFrom(type) && type != typeof(string)))
            {
                var list = value as List<object>;
                if (list == null)
                {
                    throw new JsonException("Expected a JSON array.");
                }

                var elementType = JsonMetadata.ElementType(type);
                var items = (IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(elementType));
                foreach (var item in list)
                {
                    items.Add(Convert(item, elementType, options));
                }

                if (type.IsArray)
                {
                    var array = Array.CreateInstance(elementType, items.Count);
                    items.CopyTo(array, 0);
                    return array;
                }

                if (type.IsInterface || type.IsAssignableFrom(items.GetType()))
                {
                    return items;
                }

                // HashSet<T>, SortedSet<T>…: a constructor taking the items
                var ctor = type.GetConstructor(new[] { typeof(IEnumerable<>).MakeGenericType(elementType) });
                if (ctor != null)
                {
                    return ctor.Invoke(new object[] { items });
                }

                throw new JsonException("The collection type " + type.Name + " cannot be read from JSON.");
            }

            var properties = value as Dictionary<string, object>;
            if (properties == null)
            {
                throw new JsonException("Expected a JSON object for " + type.Name + ".");
            }

            return ConvertObject(properties, type, options);
        }

        private static string Text(string text)
        {
            if (text == null)
            {
                throw new JsonException("Expected a string.");
            }

            return text;
        }

        private static bool IsNumber(Type type)
        {
            return type == typeof(int) || type == typeof(long) || type == typeof(short) || type == typeof(byte) || type == typeof(sbyte)
                || type == typeof(uint) || type == typeof(ulong) || type == typeof(ushort) || type == typeof(decimal) || type == typeof(double) || type == typeof(float);
        }

        private static object ConvertKey(string key, Type type)
        {
            if (type == typeof(string))
            {
                return key;
            }

            if (type.IsEnum)
            {
                return Enum.Parse(type, key, true);
            }

            if (type == typeof(Guid))
            {
                return Guid.Parse(key);
            }

            return System.Convert.ChangeType(key, type, CultureInfo.InvariantCulture);
        }

        private static object ConvertObject(Dictionary<string, object> json, Type type, JsonSerializerOptions options)
        {
            var info = JsonMetadata.For(type);
            var comparison = options.PropertyNameCaseInsensitive ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal;
            var lookup = new Dictionary<string, object>(comparison);
            foreach (var pair in json)
            {
                if (!lookup.ContainsKey(pair.Key))
                {
                    lookup[pair.Key] = pair.Value;
                }
            }

            object instance;
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (info.DefaultConstructor != null || type.IsValueType)
            {
                instance = info.DefaultConstructor != null ? info.DefaultConstructor.Invoke(null) : Activator.CreateInstance(type);
            }
            else if (info.ParameterizedConstructor != null)
            {
                // Constructor parameters match JSON properties by name, ignoring case (as System.Text.Json).
                var ignoreCase = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
                foreach (var pair in json)
                {
                    if (!ignoreCase.ContainsKey(pair.Key))
                    {
                        ignoreCase[pair.Key] = pair.Value;
                    }
                }

                var args = new object[info.ConstructorParameters.Length];
                for (var index = 0; index < args.Length; index++)
                {
                    var parameter = info.ConstructorParameters[index];
                    var property = info.Properties.FirstOrDefault(p => string.Equals(p.Name, parameter.Name, StringComparison.OrdinalIgnoreCase));
                    var jsonName = property == null ? parameter.Name : options.CamelCase ? property.CamelName : property.Name;
                    object raw;
                    if (ignoreCase.TryGetValue(jsonName, out raw) || ignoreCase.TryGetValue(parameter.Name, out raw))
                    {
                        args[index] = Convert(raw, parameter.ParameterType, options);
                        used.Add(parameter.Name);
                    }
                    else if (parameter.HasDefaultValue)
                    {
                        args[index] = parameter.DefaultValue;
                    }
                    else
                    {
                        args[index] = parameter.ParameterType.IsValueType ? Activator.CreateInstance(parameter.ParameterType) : null;
                    }
                }

                instance = info.ParameterizedConstructor.Invoke(args);
            }
            else
            {
                throw new JsonException("The type " + type.Name + " cannot be created from JSON.");
            }

            foreach (var property in info.Properties)
            {
                if (!property.CanWrite || used.Contains(property.Name))
                {
                    continue;
                }

                object raw;
                var name = options.CamelCase ? property.CamelName : property.Name;
                if (lookup.TryGetValue(name, out raw) || (options.PropertyNameCaseInsensitive && lookup.TryGetValue(property.Name, out raw)))
                {
                    property.Property.SetValue(instance, Convert(raw, property.Property.PropertyType, options), null);
                }
            }

            return instance;
        }
    }
}
