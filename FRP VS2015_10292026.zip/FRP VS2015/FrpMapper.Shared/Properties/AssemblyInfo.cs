﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("FrpMapper.Shared")]
[assembly: AssemblyDescription("Models, validation and hosting helpers shared by the FRP Mapper API, Platform and database tool.")]
[assembly: AssemblyProduct("FRP Mapper")]
[assembly: AssemblyCopyright("")]
[assembly: ComVisible(false)]
[assembly: Guid("fcf8d137-079e-4a7e-87e4-ea7e847badc1")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
