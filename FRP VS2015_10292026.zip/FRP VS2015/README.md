﻿# FRP Mapper for Visual Studio 2015

FRP Mapper on .NET Framework 4.5.2 and C# 6. It opens, builds and runs in Visual Studio 2015 and has no NuGet
packages. It does what the .NET 9 version (`FRP 2`) does: the same API, the same screens and the same generated files.

| Project | What it is | Runs at (IIS Express) |
|---|---|---|
| `FrpMapper.Shared` | Models, JSON, validation rules and hosting helpers used by both sites | (library) |
| `FrpMapper.Api` | The FRP Mapper API (projects, mapping, templates, validation, access, audit) and its data layer over SQL Server stored procedures | http://localhost:5088/ |
| `FrpMapper.Platform` | The web application people use (sign-in, screens, downloads); it calls the API | http://localhost:5089/ |

The database scripts and the database tool are kept apart from the application, in `FRP Database`:
`FRP Database/Scripts` holds the SQL and `FRP Database/FrpDatabaseTool.VS2015` holds the tool. The application's
solution holds no SQL and no data.

## Requirements

- Visual Studio 2015 (Update 3) with *Web Developer Tools*, which come with the ASP.NET and IIS Express workload.
- The .NET Framework 4.5.2 targeting pack (no admin install needed where Visual Studio 2015 already has it). The code
  uses nothing newer: the few .NET 4.6 types it needs are provided in `FrpMapper.Shared/Compat`.
- SQL Server 2016 SP1 or later. LocalDB, Express or a full instance all work. The scripts use `CREATE OR ALTER`.
- No Node.js, npm or NuGet. The compiled stylesheet (`FrpMapper.Platform/css/tailwind.css`) is committed. See
  *Changing the styles* below.

## First run

1. **Secrets.** They are in each project's `Web.config`:
   - `InternalApi:Key` in `<appSettings>` of both `FrpMapper.Api\Web.config` and `FrpMapper.Platform\Web.config`: the
     same random value in both, at least 32 characters.
   - In `FrpMapper.Api\Web.config` `<connectionStrings>`:
     - `FrpDb`: the API's own SQL login, which needs role `frp_app` only. For example, with LocalDB and Windows
       sign-in: `Server=(localdb)\MSSQLLocalDB;Database=FrpMapper;Integrated Security=True`
     - `FrpDbAdmin` (optional): a login that may change the schema. Only the database tool uses it.

   **These `Web.config` files now hold passwords and keys: don't commit them to source control or share them.**
   Environment variables with the same names, written with `__` instead of `:` (`InternalApi__Key`,
   `ConnectionStrings__FrpDb`), take precedence over `Web.config`.
   - `Certificates:ProtectionKey` in `<appSettings>` of `FrpMapper.Api\Web.config`: at least 32 random characters. It
     encrypts the banks' BSP certificates stored on Bank profiles. Keep it: if it changes, the stored certificates must
     be uploaded again.
2. **Database.** Open `FRP Database/FrpDatabaseTool.VS2015/FrpDatabaseTool.sln`, build it, and run it (see
   *Database tool* below). It deploys the scripts and then tests the data layer.
3. **Application.** Open `FrpMapper.sln`. Right-click the solution, choose **Set StartUp Projects…**, then
   **Multiple startup projects**, and set both `FrpMapper.Api` and `FrpMapper.Platform` to **Start**, with the API
   first. Press F5. The Platform opens at http://localhost:5089/. Never set `FrpMapper.Shared` as a startup project: it
   is a class library, and Visual Studio refuses to start it ("A project with an Output Type of Class Library cannot
   be started directly").
4. In the Debug configuration the Platform's sign-in page offers the **test users** that the database scripts create (`004_reference_data.sql`).
   They exist only in the Development environment. A Release build has no test-user sign-in.

## Settings

All settings are in each project's `Web.config` under `<appSettings>`, with comments. Any setting can be overridden by
an environment variable named like the key with `__` in place of `:` (for example `Session__IdleMinutes=5`).

| Setting | Project | Meaning |
|---|---|---|
| `Environment` | both | `Development` (test users, plain http allowed) or `Production` |
| `ApiBaseUrl` | Platform | The API's address. It must be https unless the API runs on the same machine. |
| `Authentication:Mode` | Platform | `Development` (test users), `ActiveDirectory` (sign-in page, checked by Windows) or `Windows` (IIS Windows Authentication) |
| `Authentication:DefaultDomain` | Platform | NetBIOS domain for user names typed without one |
| `Session:IdleMinutes` | Platform | A session ends after this many idle minutes (1–15) |
| `FileStorage:*` | API | Where project files are kept, the upload size limit, allowed extensions, and the bank reference file limit (`MaxReferenceFileBytes`) |
| `Database:*` | API | Connection string name, command timeout, access cache |
| `SignIn:*` | API | Account lockout after failed sign-ins, the administrator delay, and inactive-account days |
| `Bsp:AllowedHosts` | API | The only hosts a BSP environment may use (`;` between hosts, HTTPS on port 443). Not set: `rapi.bsp.gov.ph` |
| `Logging:*` | both | Log level and log file (`App_Data/logs`) |

## BSP environments

BSP submission sends to the environments on its **Settings** tab (Sandbox, Production, …): a base URL and the path of
each Report API operation (submit, status, validation result PDF / XML / Excel, receipt). `010_submission_environments.sql`
starts with the BSP sandbox. A bank profile Maker (`reference.manage`) proposes a new environment or a change; a
different Checker (`reference.approve`) approves it before it is used. Hosts are not chosen in the app: only those in
the API's `Bsp:AllowedHosts` can be used, so the bank's certificate is never presented to another server. Sending to a
**Production** environment needs the permission `submission.production`, which no role has until PARAM grants it on
Access administration, and every Production submission is confirmed by typing the environment's key.

## COCREE v2.0 (credit data)

The **COCREE** page does the Workbench's four COCREE steps: it builds BSP's credit data submission (CSDF XML,
`CRIMS_Submission_Input`) from the BU's COCREE input workbooks, validates CSDF files with BSP's rules and XSD, and adds up
the header totals of a submission's files. Code: `FrpMapper.Api/BL/Cocree/` (workbook reader, configuration, exporter,
validator, CSDF rules), `CocreeService`, `CocreeConfigService`; page `js/pages-cocree.js`.

- **Settings**: a reference data Maker (`reference.manage`) uploads the Workbench's `cocree_config.xlsx`,
  `cocree_dropdown_options.xlsx` and `cocree_validations.xlsx`, and optionally BSP's COCREE XSD; a different Checker
  (`reference.approve`) approves them (`011_workbench_tools.sql`). Every rule must be a formula that can be evaluated on its
  element's attributes, and the XSD must compile. The files in use can be downloaded, changed and uploaded again.
- **Generate** (`submission.prepare`): provider code (from the bank profiles), reference date, submission type, version and
  records per file (BSP's limit is 300,000); the input workbooks must be .xlsx. Generated files and reports are kept for a
  day under `FileStorage:RootPath\cocree-outputs`, for the person who made them only. Every run is in the audit trail.
- **Validate** (`submission.prepare`), the Workbench's steps 2 and 3, on uploaded files or the files just generated:
  Stage 1 (file name, UTF-8 without BOM, layout, record types), the preliminary checks (duplicate subjects and contracts,
  links and negative events without their subject, dates / whole numbers / amounts), then BSP's rules, each a .NET
  DataColumn expression as in the Workbench, and the XSD. Each file gets the Workbench's report
  (`…_Preliminary_Validation_Result_….xml` or `…_COCREE_v2_Validation_Result_….xml`) and the XSD messages as .csv.
- **Same output as the Workbench**, checked byte for byte: the generated files (one file, 150 files with the provision
  rollover, the error report) and the validation reports (170 and 2,040 records with BSP's 1,147 rules, and a preliminary
  report). Where the Workbench was wrong this differs: `subject_hierarchy` is compared as a number (the Workbench compared
  it as text, so 10 came before 4); Excel date cells are written as yyyyMMdd; rows of an unknown record type, money cells
  that are not amounts and mapped columns missing from a sheet are reported instead of being dropped silently; no empty
  file is written when one subject has more records than a file may hold. In validation: the Header and Footer rules are
  reported (the Workbench evaluated but never reported them) and the Footer rules get the Header's values they compare
  with; negative events are checked against the file's subjects (the Workbench compared them with themselves); the data
  types of OffBalanceSheets and the dates of negative events are checked; an amount written 0.00 is valid; a formula error
  names its record; a missing attribute is named.
- Note on BSP's rule file: rule 20-052 of Companies reads `LEN([IdentificationNumber2]<=11)` (a bracket in the wrong place),
  so a company with a GSIS number (type 12) gets "the rule could not be evaluated", in the Workbench too.

## XML tools

The **XML tools** page has the Workbench's general tools (`submission.prepare`; settings `reference.manage` /
`reference.approve`). Code: `FrpMapper.Api/BL/XmlTools/`, `XmlToolsService`, `XmlToolsConfigService`, `XmlSchemaChecker`;
page `js/pages-xml-tools.js`.

- **Merge**: an existing report XML file → the split report parts merged into the element BSP expects (`merge.csv`),
  empty elements left out and `_EWB_RECURSIVE_ELEMENT_` removed (`cleanup.csv`), optionally only the reports of one
  reporting period (`reportperiod.csv`), and with the report's XSD normalized (zero or incomplete `_Item` rows and the
  tables and sections left empty removed) and checked. The files are the Workbench's, byte for byte, except that every row
  of a merged element is kept: the Workbench added the element's last row once per row, so rows were lost and repeated.
- **Validate with XSD**: any XML file against any XSD, every message with its line and the elements open there.
- **Settings**: merge.csv, cleanup.csv, reportperiod.csv and the normalizer's kept `_Item` rows (the Workbench's
  `FRP.NonRemovableItems`, default `MAIN_Y1_Item`), Maker / Checker like COCREE.
- The Workbench's "Export Excel Data to XML" read the workbook through Excel's XML map; in FRP Mapper a project's mapped
  template does that.

## Logs and version history

- **Logs** (`audit.read-all`): the API's daily log files (`Logging:FilePath`), the last lines or the whole file, with values
  that look like passwords, keys, tokens or user IDs masked. Only the dated log files can be read.
- **Version history** (everyone): what changed, newest first (`js/pages-versions.js`; add an entry with each change).
- When a stored procedure or table a page needs is missing (the database scripts of a new version were not run), the API
  answers 503 with that explanation instead of "The request failed", and logs the error.

## Sign-in modes

- **Development**: buttons for the test users. Allowed only when `Environment` is `Development`.
- **ActiveDirectory**: a sign-in page whose user name and password are checked by Windows (`LogonUser`). The server
  must be on the domain. Roles come from the account's AD groups, as mapped on the *Access administration* screen,
  and from roles granted to the person directly.
- **Windows** (like MPVR): no sign-in page. IIS signs people in as the Windows account they use on their
  PC. The sign-in rules still apply: locked, deactivated (no use for 30 days), expired and disabled accounts are
  refused, and each sign-in is recorded in the audit trail. In the Platform site, turn **Windows Authentication on**
  and **Anonymous Authentication off**: in IIS Manager on a server, or in the project's properties (F4) for IIS
  Express.

The project is set up for **ActiveDirectory** (the sign-in page). In both ActiveDirectory and Windows mode the first
administrators are given their roles with `FRP Database\Setup\first_administrators_windows.sql`.

Whatever the mode, the API decides what each person may do. The Platform passes the signed-in user to the API, and the
API checks every permission against the access catalog in the database.

## Publishing (Release)

The step-by-step server guide, covering IIS sites, the database, secrets and the first administrators, is in
[DEPLOYMENT.md](DEPLOYMENT.md).


Publishing with the Release configuration applies `Web.Release.config`:
- API: `Environment=Production`, compilation without debug, custom errors on.
- Platform: the same, plus `Authentication:Mode=ActiveDirectory`. Change it to `Windows` for IIS Windows sign-in.
  Set `ApiBaseUrl` to the API's https address when the API runs on another server.

On the server:
- Bind both sites to https.
- Give each application pool identity write access to its `App_Data` folder. Alternatively, point
  `FileStorage:RootPath` and `Logging:FilePath` at a folder outside the site.
- Put the secrets in environment variables for the application pools, or in the site's `Web.config` readable only by
  the application pool identity and administrators. Publishing replaces `Web.config`, so see DEPLOYMENT.md, step 5.
- Keep the API reachable only from the Platform server, for example with the firewall or an internal binding.

## Database tool

`FRP Database/FrpDatabaseTool.VS2015` is a console program (`FrpDatabaseTool.exe`). It reads the same connection
strings as the API: the environment variables first, then the API project's `Web.config` (`<connectionStrings>`). The API folder comes
from `ApiProjectDirectory` in its `App.config`, which is relative to the `FRP Database` folder, or from
`--api-directory "<folder>"`.

| Command | What it does |
|---|---|
| `FrpDatabaseTool.exe` | Deploys the scripts in `FRP Database/Scripts`, then tests the data layer |
| `FrpDatabaseTool.exe test` | Tests only, with no deployment |
| `FrpDatabaseTool.exe --create-database` | Creates the database first if it does not exist |
| `FrpDatabaseTool.exe grant-app-user "<database user>"` | Adds the API's database user to role `frp_app` (least privilege) |

To run it from Visual Studio, set the arguments under *Project properties → Debug → Command line arguments*.

- The tests run inside transactions that are always rolled back, so they leave no data behind.
- The results are written to `FRP Database/report.txt`.
- Connection strings are never printed.

## Changing the styles

The Platform uses Tailwind CSS classes, compiled into `css/tailwind.css`, which is committed. After adding classes to
`js/*.js` or `Hosting/*.cs`, rebuild that file on any machine with Node.js:

```
cd FrpMapper.Platform
npx tailwindcss@3.4.17 -c tailwind.config.js -i Styles/tailwind.css -o css/tailwind.css --minify
```

Visual Studio itself needs nothing extra.

## Troubleshooting

- **"InternalApi:Key is not configured"** when a site starts: `InternalApi:Key` in that project's `Web.config` is
  empty or shorter than 32 characters. It must also be the same in both projects.
- **"A project with an Output Type of Class Library cannot be started"**: `FrpMapper.Shared` is set as a startup
  project. Set the startup projects as in *First run*, step 3.
- **"The connection string ConnectionStrings:FrpDb is not configured"**: fill in `FrpDb` in `<connectionStrings>` of
  `FrpMapper.Api\Web.config`.
- **"The FRP Mapper API cannot be reached"** on the Platform: the API is not running, or `ApiBaseUrl` is wrong.
- **HTTP 500.19** in IIS: the site needs the IIS features *ASP.NET 4.5* (or later) and, for Windows mode, *Windows Authentication*.
- Both sites write their logs to `App_Data/logs`.
