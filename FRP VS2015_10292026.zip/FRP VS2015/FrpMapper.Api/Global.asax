<%@ Application Codebehind="Global.asax.cs" Inherits="FrpMapper.Api.Global" Language="C#" %>
