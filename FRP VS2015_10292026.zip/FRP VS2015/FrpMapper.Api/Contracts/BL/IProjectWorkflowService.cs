﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.BL
{
    /// <summary>Maker / Checker workflow with segregation of duties (see WorkflowRules).</summary>
    public interface IProjectWorkflowService
    {
        /// <summary>Maker: attaches the XML to review (e.g. exported from the Excel template); it is validated and hashed.</summary>
        Task<FrpProjectDto> AttachSubmissionAsync(string projectId, IFormFile xmlFile, CancellationToken cancellationToken);
        /// <summary>Maker: builds the XML from a filled Excel input template and attaches it as the file to review.</summary>
        Task<FrpProjectDto> AttachFilledTemplateAsync(string projectId, IFormFile workbook, CancellationToken cancellationToken);
        /// <summary>Maker: uses XML generated from the project's values as the file to review.</summary>
        Task<FrpProjectDto> UseGeneratedSubmissionAsync(string projectId, CancellationToken cancellationToken);
        Task<FrpProjectDto> SubmitAsync(string projectId, string comment, CancellationToken cancellationToken);
        Task<FrpProjectDto> WithdrawAsync(string projectId, string comment, CancellationToken cancellationToken);
        Task<FrpProjectDto> ApproveAsync(string projectId, string comment, CancellationToken cancellationToken);
        Task<FrpProjectDto> ReturnAsync(string projectId, string comment, CancellationToken cancellationToken);
        Task<FrpProjectDto> ReopenAsync(string projectId, string comment, CancellationToken cancellationToken);
        /// <summary>The file under review (Checker, while in review) or the approved file (anyone, once approved).</summary>
        Task<VT_FileName_Bytes<string, byte[]>?> DownloadSubmissionAsync(string projectId, CancellationToken cancellationToken);
        Task<IReadOnlyList<AuditEntryDto>> AuditAsync(string projectId, int take, CancellationToken cancellationToken);
        /// <summary>
        /// One page of the audit trail, newest first (projectId null: the whole trail, for audit.read.all). A project
        /// the person may not see gives null. Throws Invalid for a page, page size, search or action out of range.
        /// </summary>
        Task<AuditPageDto> AuditPageAsync(string projectId, int page, int pageSize, string search, string action, CancellationToken cancellationToken);
        Task<bool> DeleteAsync(string projectId, CancellationToken cancellationToken);
    }

}
