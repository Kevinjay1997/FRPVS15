﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.BL
{
    /// <summary>Access administration: SRAU changes people, PARAM changes roles; a second team member approves each change.</summary>
    public interface IAccessAdminService
    {
        Task<AccessAdministrationDto> GetAsync(CancellationToken cancellationToken);
        Task<AccessChangeRequestDto> RequestUserChangeAsync(UserChangeDto change, CancellationToken cancellationToken);
        Task<AccessChangeRequestDto> RequestRoleChangeAsync(RoleChangeDto change, CancellationToken cancellationToken);
        Task<AccessChangeRequestDto> RequestGroupsChangeAsync(RoleGroupsChangeDto change, CancellationToken cancellationToken);
        Task<UserActivityDto> GetUserActivityAsync(string userName, CancellationToken cancellationToken);
        /// <summary>Approves, rejects or cancels a pending request. False when there is no such pending request.</summary>
        Task<bool> DecideAsync(string requestId, string decision, AccessDecisionRequest body, CancellationToken cancellationToken);
    }

}
