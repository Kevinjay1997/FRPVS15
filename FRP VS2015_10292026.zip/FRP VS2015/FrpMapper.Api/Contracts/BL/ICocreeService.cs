﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.BL
{
    /// <summary>What the person chose on the Generate tab (as posted).</summary>
    public sealed class CocreeExportRequest
    {
        public List<IFormFile> Files { get; set; } = new List<IFormFile>();

        public string ProviderCode { get; set; }

        /// <summary>yyyy-MM-dd.</summary>
        public string ReferenceDate { get; set; }

        public string SubmissionType { get; set; }

        public string Version { get; set; }

        public string ProviderComments { get; set; }

        public string MaxRecordsPerFile { get; set; }
    }

    /// <summary>The configuration files a Maker uploads (Settings tab); the XSD is optional.</summary>
    public sealed class CocreeConfigUpload
    {
        public IFormFile ConfigWorkbook { get; set; }

        public IFormFile CodeListWorkbook { get; set; }

        public IFormFile ValidationWorkbook { get; set; }

        public IFormFile Xsd { get; set; }

        public string Note { get; set; }
    }

    /// <summary>What to validate (Validate tab): uploaded CSDF files, or the files of one of the person's Generate runs.</summary>
    public sealed class CocreeValidateRequest
    {
        public List<IFormFile> Files { get; set; } = new List<IFormFile>();

        /// <summary>A Generate run's id: its XML files are validated instead of uploaded ones.</summary>
        public string RunId { get; set; }
    }

    /// <summary>A file to download, opened for reading.</summary>
    public sealed class ToolDownload
    {
        public ToolDownload(Stream content, string fileName, string contentType)
        {
            Content = content;
            FileName = fileName;
            ContentType = contentType;
        }

        public Stream Content { get; }

        public string FileName { get; }

        public string ContentType { get; }
    }

    /// <summary>
    /// COCREE v2.0 (submission.prepare): generate the CSDF XML from the BU's input workbooks with the approved configuration,
    /// validate CSDF files with BSP's rules and XSD, and add up the header totals of a submission's files. Generated files
    /// and reports are kept a day for the person who ran it.
    /// </summary>
    public interface ICocreeService
    {
        Task<CocreeSetupDto> SetupAsync(CancellationToken cancellation);

        Task<CocreeExportResultDto> ExportAsync(CocreeExportRequest request, CancellationToken cancellation, IProgress<ValidationProgressDto> progress = null);

        /// <summary>The Workbench's steps 2 and 3: Stage 1, the preliminary checks, BSP's rules and the XSD, with a report per file.</summary>
        Task<CocreeValidationResultDto> ValidateAsync(CocreeValidateRequest request, CancellationToken cancellation, IProgress<ValidationProgressDto> progress = null);

        /// <summary>Reads the files and their totals; with <paramref name="apply"/>, writes the submission's totals into every file's Header.</summary>
        Task<CocreeHeaderTotalsResultDto> HeaderTotalsAsync(List<IFormFile> files, string referenceDate, bool apply, CancellationToken cancellation);

        /// <summary>A file of one of the person's runs (or "all.zip" for every XML file of it), or null.</summary>
        ToolDownload Download(string runId, string fileName);
    }

    /// <summary>
    /// The COCREE configuration (Settings tab): a reference data Maker (reference.manage) uploads the Workbench's three
    /// configuration workbooks and BSP's XSD, a different Checker (reference.approve) approves them.
    /// </summary>
    public interface ICocreeConfigService
    {
        Task<WorkbenchSettingsDto> ListAsync(CancellationToken cancellation);

        Task<WorkbenchConfigVersionDto> UploadAsync(CocreeConfigUpload upload, CancellationToken cancellation);

        /// <summary>approve / reject / cancel a Pending version. False when it does not exist.</summary>
        Task<bool> DecideAsync(string configId, string decision, AccessDecisionRequest body, CancellationToken cancellation);

        /// <summary>
        /// A version's file to check or edit: "config", "code-lists" or "validations" as .xlsx, or "xsd"; null when it does
        /// not exist.
        /// </summary>
        Task<ToolDownload> DownloadAsync(string configId, string file, CancellationToken cancellation);
    }
}
