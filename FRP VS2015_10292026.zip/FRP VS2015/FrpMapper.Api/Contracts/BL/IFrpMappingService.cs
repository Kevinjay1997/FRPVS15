﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.BL
{
    public interface IFrpMappingService
    {
        /// <summary>
        /// Creates a project from new uploads and/or (per <paramref name="reuse"/>) the uploaded files of an existing
        /// project, which needs project.read as well as project.create.
        /// </summary>
        /// <param name="progress">Reports what is being done, 0-100 % (optional).</param>
        Task<FrpProjectDto> AnalyzeAsync(string projectName, IFormFile xsdFile, IFormFile templateFile, IFormFile specificationFile, FrpMapper.Api.Models.ProjectFileReuse reuse, CancellationToken cancellationToken,
            IProgress<ValidationProgressDto> progress = null);
        /// <summary>The uploaded files of a project, for reuse in a new project; null when it does not exist.</summary>
        Task<ReusableProjectFilesDto> GetReusableFilesAsync(string projectId, CancellationToken cancellationToken);
        Task<FrpProjectDto> GetAsync(string projectId, CancellationToken cancellationToken);
        Task<TemplateAccountCodesDto> GetAccountCodesAsync(string projectId, CancellationToken cancellationToken);
        Task<IReadOnlyList<ProjectSummaryDto>> FindProjectsWithFilesAsync(ProjectFilesCheckRequest request, CancellationToken cancellationToken);
        Task<FrpProjectDto> UpdateMappingsAsync(string projectId, IReadOnlyList<MappingEntryDto> mappings, CancellationToken cancellationToken);
        /// <summary>Saves values typed into mapped cells after checking each against its XSD rules (nothing is saved when one breaks them); null when the project is not found.</summary>
        Task<SaveValuesResultDto> SaveValuesAsync(string projectId, IReadOnlyList<CellValueDto> values, CancellationToken cancellationToken);
        /// <summary>Removes ("remove") or restores ("restore") the sample values of a sheet or the whole project; entered values are kept. Null when the project is not found.</summary>
        Task<SampleValuesResultDto> ChangeSampleValuesAsync(string projectId, string action, string sheetName, CancellationToken cancellationToken);

        /// <summary>A Maker renames a draft or returned project (null: no such project).</summary>
        Task<FrpProjectDto> RenameAsync(string projectId, string name, CancellationToken cancellationToken);

        /// <summary>
        /// A Maker replaces a draft or returned project's XSD, template and/or specification; mappings and entered
        /// values are carried over (null: no such project).
        /// </summary>
        Task<ProjectEditResultDto> ReplaceFilesAsync(string projectId, FrpMapper.Api.Models.ProjectFilesEdit edit, CancellationToken cancellationToken,
            IProgress<ValidationProgressDto> progress = null);
        /// <summary>New, unique sample values for every mapped field that pass the XSD and the BSP rules (not saved).</summary>
        Task<SampleRefillDto> RefillSampleValuesAsync(string projectId, CancellationToken cancellationToken);

        /// <summary>An XML exported by Excel from sheet copies (CAR_Part_IV_4c_PHP…) in the XSD's structure; null when the project is not found.</summary>
        Task<VT_FileName_Bytes<string, byte[]>?> MergeSheetCopiesXmlAsync(string projectId, IFormFile xmlFile, CancellationToken cancellationToken);

        /// <summary>The forms that can be entered on one sheet per key value, and the project's current splits.</summary>
        Task<SheetSplitSettingsDto> GetSheetSplitsAsync(string projectId, CancellationToken cancellationToken);

        /// <summary>Saves which forms are entered on one sheet per key value (Maker, editable project); returns the saved project.</summary>
        Task<FrpProjectDto> SaveSheetSplitsAsync(string projectId, IReadOnlyList<SheetSplitDto> splits, CancellationToken cancellationToken);
        Task<ProjectValidationResultDto> ValidateAsync(string projectId, IReadOnlyList<MappingEntryDto> mappings, CancellationToken cancellationToken);
        Task<VT_FileName_ContentType_Bytes<string, string, byte[]>?> ExportXmlAsync(string projectId, ExportValues values, CancellationToken cancellationToken);
        Task<VT_FileName_ContentType_Bytes<string, string, byte[]>?> ExportMappedTemplateAsync(string projectId, ExportValues values, CancellationToken cancellationToken);
        Task<TemplateCoverageDto> CheckExportedTemplateAsync(string projectId, ExportValues values, CancellationToken cancellationToken);
        Task<TemplateCoverageDto> CheckUploadedTemplateAsync(string projectId, IFormFile workbook, CancellationToken cancellationToken);
        Task<XsdValidationResultDto> ValidateGeneratedXmlAsync(string projectId, CancellationToken cancellationToken, IProgress<ValidationProgressDto> progress = null);
        Task<XsdValidationResultDto> ValidateUploadedXmlAsync(string projectId, IFormFile xmlFile, CancellationToken cancellationToken, IProgress<ValidationProgressDto> progress = null);
        /// <summary>Builds the XML from the values typed into an Excel input template and validates it (XSD + specification), with the cell of each problem.</summary>
        Task<XsdValidationResultDto> ValidateFilledTemplateAsync(string projectId, IFormFile workbook, CancellationToken cancellationToken, IProgress<ValidationProgressDto> progress = null);
        /// <summary>The XML built from a filled Excel input template, and its validation.</summary>
        FrpMapper.Api.BL.FilledTemplateXml BuildFromFilledTemplate(FrpProjectDto project, byte[] workbookBytes, string fileName, IProgress<ValidationProgressDto> progress = null);
        /// <summary>Validates XML bytes against the project's XSD and BSP specification.</summary>
        XsdValidationResultDto ValidateXml(FrpProjectDto project, byte[] xmlBytes, string label);
        /// <summary>The submission XML built from the project's current values.</summary>
        byte[] GenerateSubmissionXml(FrpProjectDto project);
        Task<IReadOnlyList<ProjectSummaryDto>> ListAsync(CancellationToken cancellationToken);
    }

}
