﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.BL
{
    public interface IReferenceDataService
    {
        Task<ReferenceDataDto> ReadAsync(CancellationToken ct);
        Task<BankProfileRequestDto> RequestBankChangeAsync(BankProfileDto bank, CancellationToken ct);
        Task<bool> DecideBankChangeAsync(string requestId, string decision, AccessDecisionRequest body, CancellationToken ct);
        Task<IReadOnlyList<BankBranchDto>> ReadBranchesAsync(IFormFile file, CancellationToken ct);
        Task<SandboxImportDto> ImportAsync(string bankKey, string projectId, IFormFile report, IFormFile xml, bool save, CancellationToken ct);
    }

}
