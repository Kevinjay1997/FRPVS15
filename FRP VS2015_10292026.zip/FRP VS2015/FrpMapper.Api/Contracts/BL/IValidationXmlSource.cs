using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Api.Contracts.BL
{
    /// <summary>
    /// The XML the Validate page checked, for sending to a BSP test environment: built from the project (source
    /// "generated"), from a filled Excel template ("workbook"), or an uploaded XML ("file", merged from sheet copies when
    /// Excel exported it that way). The XML stays on the server: the mapped submission XML is not handed out before a
    /// Checker approves the project.
    /// </summary>
    public interface IValidationXmlSource
    {
        /// <summary>The file name and XML, or null when the project does not exist or the person cannot see it.</summary>
        Task<VT_FileName_Bytes<string, byte[]>?> XmlForSandboxAsync(string projectId, string source, IFormFile file, CancellationToken cancellationToken);
    }
}
