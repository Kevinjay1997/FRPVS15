using System;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.BL
{
    /// <summary>What the person chose on the Merge tab.</summary>
    public sealed class XmlMergeRequest
    {
        public IFormFile Xml { get; set; }

        /// <summary>Empty for none, else Daily, Weekly, Monthly, Quarterly, Midyear or Yearly.</summary>
        public string ReportPeriod { get; set; }

        /// <summary>Optional: the XSD the merged file is normalized with and checked against.</summary>
        public IFormFile Xsd { get; set; }

        /// <summary>Normalize the merged file with the XSD (as the Workbench's Merge did); the XSD check runs either way.</summary>
        public bool Normalize { get; set; }
    }

    /// <summary>The XML tools' configuration files a Maker uploads.</summary>
    public sealed class XmlToolsConfigUpload
    {
        public IFormFile MergeCsv { get; set; }

        public IFormFile CleanupCsv { get; set; }

        public IFormFile ReportPeriodCsv { get; set; }

        /// <summary>The _Item rows the normalizer keeps when they have a value, comma-separated (e.g. MAIN_Y1_Item).</summary>
        public string NonRemovableItems { get; set; }

        public string Note { get; set; }
    }

    /// <summary>
    /// The Workbench's general XML tools (submission.prepare): merge, clean and filter an existing report XML file and
    /// normalize it with its XSD, and check any XML file against any XSD. Results are kept a day for the person who ran them.
    /// </summary>
    public interface IXmlToolsService
    {
        Task<XmlToolsSetupDto> SetupAsync(CancellationToken cancellation);

        Task<XmlMergeResultDto> MergeAsync(XmlMergeRequest request, CancellationToken cancellation, IProgress<ValidationProgressDto> progress = null);

        Task<XmlValidateResultDto> ValidateAsync(IFormFile xml, IFormFile xsd, CancellationToken cancellation);

        /// <summary>A file of one of the person's runs, or null.</summary>
        ToolDownload Download(string runId, string fileName);
    }

    /// <summary>
    /// The XML tools' configuration (merge.csv, cleanup.csv, reportperiod.csv and the normalizer's kept rows): a reference
    /// data Maker uploads it, a different Checker approves it.
    /// </summary>
    public interface IXmlToolsConfigService
    {
        Task<WorkbenchSettingsDto> ListAsync(CancellationToken cancellation);

        Task<WorkbenchConfigVersionDto> UploadAsync(XmlToolsConfigUpload upload, CancellationToken cancellation);

        Task<bool> DecideAsync(string configId, string decision, AccessDecisionRequest body, CancellationToken cancellation);

        /// <summary>A version's file as CSV: "merge", "cleanup" or "reportperiod"; null when it does not exist.</summary>
        Task<ToolDownload> DownloadAsync(string configId, string file, CancellationToken cancellation);
    }

    /// <summary>The API's log files, for the people who may read the whole audit trail (audit.read-all).</summary>
    public interface ILogService
    {
        LogListDto List();

        /// <summary>The last lines of a log file, with secrets masked; null when there is no such file.</summary>
        LogContentDto Read(string name, int lines);

        /// <summary>A whole log file, with secrets masked; null when there is no such file.</summary>
        ToolDownload Download(string name);
    }
}
