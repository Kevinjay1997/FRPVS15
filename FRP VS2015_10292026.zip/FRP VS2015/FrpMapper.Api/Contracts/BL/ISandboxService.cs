using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Models;
using FrpMapper.Shared.Models;
namespace FrpMapper.Api.Contracts.BL
{
    public interface ISandboxService
    {
        /// <summary>The bank profiles (UNI, RB, ...) a report can be submitted for, with their BSP API undertaking codes.</summary>
        Task<IReadOnlyList<SandboxBankDto>> BanksAsync(CancellationToken cancellation);
        /// <summary>The approved BSP environments (Sandbox, Production, …), with whether the person may use each.</summary>
        Task<IReadOnlyList<SandboxEnvironmentDto>> EnvironmentsAsync(CancellationToken cancellation);
        Task<SandboxCertificateInfo> InspectAsync(SandboxRequest request, CancellationToken cancellation);
        Task<SandboxResponse> ExecuteAsync(SandboxRequest request, CancellationToken cancellation);

        /// <summary>Validate page: sends the XML it checked to a BSP test environment (never Production).</summary>
        Task<SandboxValidationDto> ValidateAsync(SandboxRequest request, CancellationToken cancellation);

        /// <summary>Validate page: the report code, period and bank read from the XML it checked (nothing is sent).</summary>
        Task<SandboxParametersDto> ParametersAsync(SandboxRequest request, CancellationToken cancellation);

        /// <summary>BSP's validation result for a submission, read into findings; not ready yet: Ready is false.</summary>
        Task<SandboxFindingsDto> FindingsAsync(SandboxRequest request, CancellationToken cancellation);
    }
}
