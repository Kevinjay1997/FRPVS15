﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.BL
{
    /// <summary>Roles, permissions and their grants from the database, cached for Database:AccessCacheSeconds.</summary>
    public interface IAccessService
    {
        Task<AccessCatalogDto> GetCatalogAsync(CancellationToken cancellationToken);
        Task<IReadOnlyList<DevelopmentUserDto>> GetDevelopmentUsersAsync(CancellationToken cancellationToken);

        /// <summary>Drops the cached catalog, so an approved access change applies to the next request.</summary>
        void Invalidate();
    }

}
