﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.BL
{
    /// <summary>The sign-in rules the Platform's sign-in page applies (called only by the Platform).</summary>
    public interface ISignInService
    {
        Task<SignInCheckResultDto> CheckAsync(SignInCheckDto check, CancellationToken cancellationToken);

        Task<string> RecordFailureAsync(SignInFailedDto failure, CancellationToken cancellationToken);

        /// <summary>A sign-in refused before the password was checked (too many attempts): audited only.</summary>
        Task RecordBlockedAsync(SignInFailedDto blocked, CancellationToken cancellationToken);

        Task<SignInResultDto> RecordSuccessAsync(SignInSucceededDto success, CancellationToken cancellationToken);

        Task<SessionCheckResultDto> CheckSessionAsync(SessionCheckDto session, CancellationToken cancellationToken);

        /// <summary>Sign-out: ends the session so its cookie is refused from now on, and audits it.</summary>
        Task EndSessionAsync(SessionEndDto session, CancellationToken cancellationToken);
    }

}
