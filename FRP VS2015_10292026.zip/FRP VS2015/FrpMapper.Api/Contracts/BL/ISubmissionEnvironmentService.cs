using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.BL
{
    /// <summary>
    /// The BSP environments used by BSP submission (Settings tab): a Maker (reference.manage) proposes a new environment or
    /// a change, a different Checker (reference.approve) approves it.
    /// </summary>
    public interface ISubmissionEnvironmentService
    {
        Task<SubmissionSettingsDto> ListAsync(CancellationToken cancellation);

        Task<SubmissionEnvironmentDto> RequestAsync(SubmissionEnvironmentRequest request, CancellationToken cancellation);

        /// <summary>approve / reject / cancel a Pending version, or remove the Active one. False when it does not exist.</summary>
        Task<bool> DecideAsync(string environmentId, string decision, AccessDecisionRequest body, CancellationToken cancellation);
    }
}
