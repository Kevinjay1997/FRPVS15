using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.BL
{
    /// <summary>The Excel-style sheet view of the Mappings tab: a template sheet as a grid, and the mappings the app makes.</summary>
    public interface ITemplateGridService
    {
        /// <summary>One sheet of the project's Excel input template; null when the project, its template or the sheet does not exist (or is hidden from the person).</summary>
        Task<TemplateGridDto> GetSheetAsync(string projectId, string sheetName, CancellationToken cancellationToken);

        /// <summary>
        /// The mappings FRP Mapper makes for the project's XSD and template, worked out again from the stored files (as
        /// when the project was created); nothing is saved. Null when the project does not exist (or is hidden).
        /// </summary>
        Task<SuggestedMappingsDto> GetSuggestedMappingsAsync(string projectId, CancellationToken cancellationToken);
    }
}
