﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.BL
{
    /// <summary>The reports of the Application Security Checklist (Reports; Password and Login: review of unsuccessful sign-ins).</summary>
    public interface IReportService
    {
        /// <summary>SRAU: changes to people processed between the two dates (inclusive, server's local dates).</summary>
        Task<MaintenanceReportDto> UserMaintenanceAsync(DateOnly from, DateOnly to, CancellationToken cancellationToken);

        /// <summary>PARAM (roles, AD groups), SRAU (AD groups) and bank profile Makers / Checkers (bank profiles): parameter changes.</summary>
        Task<MaintenanceReportDto> ParameterMaintenanceAsync(DateOnly from, DateOnly to, CancellationToken cancellationToken);

        /// <summary>SRAU: every account with its roles, branch / department, status, dates and last sign-in.</summary>
        Task<UserExtractionReportDto> UserExtractionAsync(CancellationToken cancellationToken);

        /// <summary>SRAU: sign-in attempts between the two dates, with a summary per account.</summary>
        Task<SignInReportDto> SignInsAsync(DateOnly from, DateOnly to, string userName, CancellationToken cancellationToken);
    }

}
