using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.BL
{
    /// <summary>Each bank profile's BSP certificate, stored once and approved Maker / Checker.</summary>
    public interface IBankCertificateService
    {
        /// <summary>Makers and Checkers of bank profiles: every bank's Pending and Active certificate and recent decisions.</summary>
        Task<IReadOnlyList<BankCertificateDto>> ListAsync(CancellationToken cancellation);

        /// <summary>Maker: checks the PFX opens with the password, then stores it encrypted as Pending.</summary>
        Task<BankCertificateDto> UploadAsync(string bankKey, IFormFile certificate, string password, CancellationToken cancellation);

        /// <summary>approve / reject / cancel a Pending certificate, or remove the Active one. False when it does not exist.</summary>
        Task<bool> DecideAsync(string certificateId, string decision, AccessDecisionRequest body, CancellationToken cancellation);
    }
}
