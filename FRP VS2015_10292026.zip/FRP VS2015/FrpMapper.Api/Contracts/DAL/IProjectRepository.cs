﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>
    /// Projects in the database (stored procedures frp.usp_Project_*). Saves use optimistic concurrency: each save
    /// passes the <see cref="FrpProjectDto.Version"/> the project was read at and fails with
    /// <see cref="ConcurrencyConflictException"/> when someone else saved it in between.
    /// </summary>
    public interface IProjectRepository
    {
        /// <summary>Inserts a new project with everything it contains. Returns it with its version.</summary>
        Task<FrpProjectDto> CreateAsync(FrpProjectDto project, CancellationToken cancellationToken);

        /// <summary>
        /// Saves the workflow (status, people, dates, comments, contributors, submission file) and UpdatedAt.
        /// The schema, workbooks, sample rows, uploaded files and mappings are not changed.
        /// </summary>
        Task<FrpProjectDto> SaveWorkflowAsync(FrpProjectDto project, CancellationToken cancellationToken);

        /// <summary>Saves what <see cref="SaveWorkflowAsync"/> saves plus the mappings, issues and validation summary.</summary>
        Task<FrpProjectDto> SaveMappingsAsync(FrpProjectDto project, CancellationToken cancellationToken);

        /// <summary>
        /// Saves what <see cref="SaveMappingsAsync"/> saves plus every XSD field's sample value (frp.SchemaNode.TestValue),
        /// in one transaction.
        /// </summary>
        Task<FrpProjectDto> SaveSampleValuesAsync(FrpProjectDto project, CancellationToken cancellationToken);

        /// <summary>Saves the workflow, mappings with their validation, and the project's sheet copies (<see cref="FrpProjectDto.SheetSplits"/>).</summary>
        Task<FrpProjectDto> SaveSheetSplitsAsync(FrpProjectDto project, CancellationToken cancellationToken);

        /// <summary>
        /// Saves a new name (frp.usp_Project_Rename) with UpdatedAt and the workflow's last change, when the draft or
        /// returned project is still at its <see cref="FrpProjectDto.Version"/>. Throws <see cref="ConcurrencyConflictException"/>
        /// or <see cref="ProjectNotEditableException"/>.
        /// </summary>
        Task<FrpProjectDto> RenameAsync(FrpProjectDto project, CancellationToken cancellationToken);

        /// <summary>
        /// Replaces the project's files and everything read from them (XSD fields, workbooks, sample values, mappings,
        /// validation, sheet copies, submission file, contributors) with <paramref name="project"/>'s, in one transaction
        /// (frp.usp_Project_ReplaceSources). Its id, creator, status and history stay. Throws
        /// <see cref="ConcurrencyConflictException"/>, <see cref="ProjectNotEditableException"/> or
        /// <see cref="DuplicateProjectFilesException"/>.
        /// </summary>
        Task<FrpProjectDto> ReplaceSourcesAsync(FrpProjectDto project, CancellationToken cancellationToken);

        Task<FrpProjectDto> GetAsync(string projectId, CancellationToken cancellationToken);

        Task<IReadOnlyList<ProjectSummaryDto>> ListAsync(CancellationToken cancellationToken);

        /// <summary>The project's uploaded files (frp.usp_ProjectFile_List); null when the project does not exist.</summary>
        Task<FrpMapper.Api.Models.ProjectUploads> GetUploadsAsync(string projectId, CancellationToken cancellationToken);

        /// <summary>
        /// The projects <paramref name="createdBy"/> created that use exactly this set of files (frp.usp_Project_FindByFiles): the XSD's SHA-256, the uploaded
        /// template's SHA-256 or <see cref="ProjectFileKeys.None"/> (template generated from the XSD), and the
        /// specification's SHA-256 or <see cref="ProjectFileKeys.None"/>. Newest first.
        /// </summary>
        Task<IReadOnlyList<ProjectSummaryDto>> FindByFilesAsync(string createdBy, string xsdSha256, string templateKey, string specificationKey, CancellationToken cancellationToken);

        /// <summary>
        /// Marks a draft or returned project deleted (frp.usp_Project_Delete) when it is still at <paramref name="expectedVersion"/>;
        /// its rows, files and audit trail are kept. False when the project does not exist (or was already deleted).
        /// Throws <see cref="ConcurrencyConflictException"/> or <see cref="ProjectNotDeletableException"/>.
        /// </summary>
        Task<bool> DeleteAsync(string projectId, byte[] expectedVersion, string deletedBy, DateTimeOffset deletedAt, CancellationToken cancellationToken);

        /// <summary>Serializes read-check-write changes to one project within this process (the database version check covers other processes).</summary>
        Task<IDisposable> LockAsync(string projectId, CancellationToken cancellationToken);
    }

    public static partial class ProjectIds
    {
        /// <summary>Project ids are 32 lowercase hex characters (a GUID without dashes); anything else (e.g. "../") is rejected.</summary>
        public static bool IsValid(string projectId) => projectId != null && IdRegex().IsMatch(projectId);

        private static System.Text.RegularExpressions.Regex IdRegex() { return IdRegexInstance; }

        private static readonly System.Text.RegularExpressions.Regex IdRegexInstance = new System.Text.RegularExpressions.Regex("^[0-9a-f]{32}$", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

    /// <summary>How a missing template or specification is written in a file-set lookup.</summary>
    public static class ProjectFileKeys
    {
        public const string None = "NONE";
    }

    /// <summary>The person already has a project with the same XSD, template and specification (SQL error 51007); one project per person per set of files.</summary>
    public sealed class DuplicateProjectFilesException: Exception
    {

        public DuplicateProjectFilesException(string message) : base(message)
    {
    }
    }

    /// <summary>Only a draft or returned project can be deleted (SQL error 51008).</summary>
    public sealed class ProjectNotDeletableException: Exception
    {

        public ProjectNotDeletableException(string message) : base(message)
    {
    }
    }

    /// <summary>Only a draft or returned project can be changed (SQL error 51006).</summary>
    public sealed class ProjectNotEditableException: Exception
    {

        public ProjectNotEditableException(string message) : base(message)
    {
    }
    }

    /// <summary>The project was saved by someone else after it was read; reload and try again (HTTP 409).</summary>
    public sealed class ConcurrencyConflictException: Exception
    {

        public ConcurrencyConflictException(string message) : base(message)
    {
    }
    }

}
