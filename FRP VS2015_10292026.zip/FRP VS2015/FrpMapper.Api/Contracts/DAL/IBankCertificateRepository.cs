using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>The bank profiles' BSP certificates (frp.BankCertificate). The ciphertext is read only by <see cref="GetActiveAsync"/>.</summary>
    public interface IBankCertificateRepository
    {
        /// <summary>Every Pending and Active certificate and the latest decided ones, without their ciphertext.</summary>
        Task<IReadOnlyList<BankCertificateDto>> ListAsync(CancellationToken cancellationToken);

        /// <summary>
        /// Maker: stores an uploaded certificate as Pending. Throws <see cref="AccessRequestOpenException"/> when the bank
        /// already has one waiting. Returns it with its row version.
        /// </summary>
        Task<BankCertificateDto> RequestAsync(BankCertificateDto certificate, byte[] protectedPfx, CancellationToken cancellationToken);

        /// <summary>
        /// Approved / Rejected / Cancelled (a Pending one) or Removed (the Active one). False when it does not exist;
        /// <see cref="ConcurrencyConflictException"/> when it changed; <see cref="AccessDecisionRefusedException"/> for self-approval.
        /// </summary>
        Task<bool> DecideAsync(string certificateId, byte[] expectedVersion, string decision, string decidedBy, DateTimeOffset decidedAt, string comment,
            CancellationToken cancellationToken);

        /// <summary>The bank's Active certificate with its ciphertext, or null.</summary>
        Task<StoredBankCertificate> GetActiveAsync(string bankKey, CancellationToken cancellationToken);
    }

    /// <summary>An Active certificate as stored: still encrypted.</summary>
    public sealed class StoredBankCertificate
    {
        public string CertificateId { get; set; } = "";

        public string BankKey { get; set; } = "";

        public byte[] Protected { get; set; } = new byte[0];

        public string Thumbprint { get; set; } = "";

        public DateTime ValidFrom { get; set; }

        public DateTime ValidUntil { get; set; }
    }
}
