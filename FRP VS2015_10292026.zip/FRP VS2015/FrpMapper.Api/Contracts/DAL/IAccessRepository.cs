﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>Roles, permissions, grants, Active Directory groups and Development test users (frp.usp_AccessCatalog_Get, frp.usp_DevelopmentUser_List).</summary>
    public interface IAccessRepository
    {
        Task<AccessCatalogDto> GetCatalogAsync(CancellationToken cancellationToken);
        Task<IReadOnlyList<DevelopmentUserDto>> GetDevelopmentUsersAsync(CancellationToken cancellationToken);
    }

}
