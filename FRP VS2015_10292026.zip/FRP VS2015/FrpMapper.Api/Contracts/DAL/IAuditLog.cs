﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>Append-only audit trail of who did what, when (never updated or deleted by the application).</summary>
    public interface IAuditLog
    {
        Task AppendAsync(AuditEntryDto entry, CancellationToken cancellationToken);
        Task<IReadOnlyList<AuditEntryDto>> QueryAsync(string projectId, int take, CancellationToken cancellationToken);

        /// <summary>What one person did (their sign-ins included), newest first.</summary>
        Task<IReadOnlyList<AuditEntryDto>> QueryByUserAsync(string userName, int take, CancellationToken cancellationToken);

        /// <summary>
        /// One page of the trail (projectId null: the whole trail), newest first: entries skip..skip+take matching the
        /// search text (person, address, action, project, details) and the action; with the total and the actions used.
        /// </summary>
        Task<AuditPageDto> QueryPageAsync(string projectId, string search, string action, int skip, int take, CancellationToken cancellationToken);
    }

}
