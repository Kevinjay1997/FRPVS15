﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>
    /// Access administration in the database (frp.usp_AccessAdmin_Get, frp.usp_AccessChange_*): people, roles and the
    /// change requests SRAU and PARAM make and approve.
    /// </summary>
    public interface IAccessAdminRepository
    {
        /// <summary>People, all roles (disabled ones too), permissions, open requests and the latest <paramref name="decidedTake"/> decided ones.</summary>
        Task<AccessAdministrationDto> GetAsync(int decidedTake, CancellationToken cancellationToken);

        /// <summary>Records a request. Throws <see cref="AccessRequestOpenException"/> when the person or role already has one.</summary>
        Task<AccessChangeRequestDto> CreateRequestAsync(AccessChangeRequestDto request, CancellationToken cancellationToken);

        /// <summary>
        /// Approves (applying the change in the same transaction), rejects or cancels a request read at
        /// <paramref name="expectedVersion"/>. False when it does not exist. Throws <see cref="ConcurrencyConflictException"/>
        /// when it was decided or changed since, and <see cref="AccessDecisionRefusedException"/> for a decision by the
        /// wrong person (the database checks this too).
        /// </summary>
        Task<bool> DecideAsync(AccessChangeRequestDto request, byte[] expectedVersion, string decision, string decidedBy, DateTimeOffset decidedAt,
            string comment, CancellationToken cancellationToken);
    }

    /// <summary>The person or role already has a change waiting for approval (SQL error 51009).</summary>
    public sealed class AccessRequestOpenException: Exception
    {

        public AccessRequestOpenException(string message) : base(message)
    {
    }
    }

    /// <summary>A change approved or rejected by the person who requested it, or cancelled by someone else (SQL error 51010).</summary>
    public sealed class AccessDecisionRefusedException: Exception
    {

        public AccessDecisionRefusedException(string message) : base(message)
    {
    }
    }

}
