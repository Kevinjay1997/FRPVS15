﻿using System.Collections.Generic;
using System.IO;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>
    /// The files a run of the Workbench's tools produced (COCREE: CSDF XML, error and validation reports; XML tools: merged
    /// and normalized XML, logs, XSD reports), kept on disk for a day so the person who ran it can download them. Each run
    /// has its own folder; only its owner can read it.
    /// </summary>
    public interface ICocreeOutputStore
    {
        /// <summary>A new, empty run for <paramref name="owner"/>. Runs older than a day are removed first.</summary>
        CocreeOutputRun CreateRun(string owner);

        /// <summary>The names of a run's files (empty when the run does not exist or is someone else's).</summary>
        IReadOnlyList<string> Files(string runId, string owner);

        /// <summary>One file of a run opened for reading, or null (no such run or file, or someone else's).</summary>
        Stream Open(string runId, string fileName, string owner);
    }

    /// <summary>Where a COCREE run's files go.</summary>
    public interface ICocreeOutput
    {
        /// <summary>A new file of the run, opened for writing.</summary>
        Stream Create(string fileName);
    }

    /// <summary>One run's folder: files are created in it through <see cref="ICocreeOutput"/>.</summary>
    public sealed class CocreeOutputRun : ICocreeOutput
    {
        private readonly string folder;

        public CocreeOutputRun(string id, string folder)
        {
            Id = id;
            this.folder = folder;
        }

        public string Id { get; }

        public Stream Create(string fileName)
        {
            if (!CocreeOutputNames.IsValid(fileName))
            {
                throw new System.ArgumentException("Not a valid output file name.", nameof(fileName));
            }

            return new FileStream(Path.Combine(folder, fileName), FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920);
        }
    }

    /// <summary>The file names a run may hold: letters, digits, "_", "-" and "." only (no folders), ending in .xml, .csv or .log.</summary>
    public static class CocreeOutputNames
    {
        public static bool IsValid(string name)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(name ?? "", @"\A[A-Za-z0-9_\-][A-Za-z0-9_.\-]{0,150}\.(xml|csv|log)\z") && !name.Contains("..");
        }

        /// <summary>Text made fit to start an output file name: other characters become "_", at most 100 characters.</summary>
        public static string Safe(string text)
        {
            var safe = System.Text.RegularExpressions.Regex.Replace(text ?? "", @"[^A-Za-z0-9_\-]", "_");
            safe = safe.Length > 100 ? safe.Substring(0, 100) : safe;
            return safe.Length == 0 ? "file" : safe;
        }
    }
}
