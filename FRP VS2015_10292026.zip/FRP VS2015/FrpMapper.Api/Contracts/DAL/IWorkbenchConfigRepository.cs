﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>A configuration version with its content (the uploaded files as JSON).</summary>
    public sealed class StoredWorkbenchConfig
    {
        public WorkbenchConfigVersionDto Version { get; set; } = new WorkbenchConfigVersionDto();

        /// <summary>JSON of a <see cref="CocreeConfigDto"/> or an <see cref="XmlToolsConfigDto"/>, by kind.</summary>
        public string Content { get; set; } = "";
    }

    /// <summary>The configuration versions of the Workbench's tools, one series per kind (frp.WorkbenchConfig, 011_workbench_tools.sql).</summary>
    public interface IWorkbenchConfigRepository
    {
        /// <summary>The Pending and Active versions of a <see cref="WorkbenchConfigKind"/> and its latest decided ones, without content.</summary>
        Task<IReadOnlyList<WorkbenchConfigVersionDto>> ListAsync(string kind, CancellationToken cancellationToken);

        /// <summary>One version with its content, or null.</summary>
        Task<StoredWorkbenchConfig> GetAsync(string configId, CancellationToken cancellationToken);

        /// <summary>The Active version of a kind with its content, or null before the first approval.</summary>
        Task<StoredWorkbenchConfig> GetActiveAsync(string kind, CancellationToken cancellationToken);

        /// <summary>
        /// Maker: stores a new version (of the kind its Version says) as Pending. Throws <see cref="AccessRequestOpenException"/> when one is already
        /// waiting. Returns it with its row version.
        /// </summary>
        Task<WorkbenchConfigVersionDto> RequestAsync(StoredWorkbenchConfig config, CancellationToken cancellationToken);

        /// <summary>
        /// Approved / Rejected / Cancelled. False when the version does not exist; <see cref="ConcurrencyConflictException"/>
        /// when it changed; <see cref="AccessDecisionRefusedException"/> for self-approval or someone else's cancel.
        /// </summary>
        Task<bool> DecideAsync(string configId, byte[] expectedVersion, string decision, string decidedBy, DateTimeOffset decidedAt, string comment,
            CancellationToken cancellationToken);
    }
}
