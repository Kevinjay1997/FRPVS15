﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>Sign-in state (frp.SignInState): lockout, administrator delay, inactivity and the one active session.</summary>
    public interface ISignInRepository
    {
        /// <summary>Until when the account cannot sign in, or null.</summary>
        Task<DateTimeOffset?> GetDelayedUntilAsync(string userName, DateTimeOffset at, CancellationToken cancellationToken);

        /// <summary>Records a failed sign-in; returns <see cref="SignInOutcomes.Failed"/>, <see cref="SignInOutcomes.Locked"/> or <see cref="SignInOutcomes.Delayed"/>.</summary>
        Task<string> RecordFailureAsync(string userName, DateTimeOffset at, string detail, bool countsTowardLockout, int maxFailures, int delayMinutes,
            CancellationToken cancellationToken);

        /// <summary>Records a correct password; returns whether the person may sign in, and their previous sign-in.</summary>
        Task<SignInResultDto> RecordSuccessAsync(string userName, DateTimeOffset at, string detail, bool isAdministrator, string roles, string sessionId,
            int inactiveDays, CancellationToken cancellationToken);

        /// <summary>The one session the account may use, or null.</summary>
        Task<string> GetSessionAsync(string userName, CancellationToken cancellationToken);

        /// <summary>Ends the account's session when it is still the current one (and audits the sign-out); true when it was.</summary>
        Task<bool> EndSessionAsync(string userName, string sessionId, DateTimeOffset at, string detail, CancellationToken cancellationToken);
    }

}
