﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>
    /// The project files (uploaded XSD, template, specification; generated template; submission XML) on disk under
    /// FileStorage:RootPath (appsettings.json). The database stores each file's path relative to that root, so the
    /// folder can be moved by moving it and changing the setting.
    /// </summary>
    public interface IProjectFileStore
    {
        /// <summary>
        /// Stores an uploaded XSD, template or specification once by content: the file is kept as
        /// {SharedUploadsFolder}/{first two hex digits}/{SHA-256}{extension}. When a file with the same content and extension
        /// is already stored (and still has that content), it is reused and nothing is written.
        /// </summary>
        Task<StoredUpload> StoreUploadAsync(IFormFile file, CancellationToken cancellationToken);

        /// <summary>True when a file with this SHA-256 and extension is already stored.</summary>
        bool IsUploadStored(string sha256, string extension);

        /// <summary>Stores a file the app produced (e.g. the generated template) in the project's folder; returns its full path.</summary>
        Task<string> SaveFileAsync(string projectId, string fileName, byte[] content, CancellationToken cancellationToken);

        /// <summary>The path to store in the database: relative to the storage root, with '/' separators.</summary>
        string ToStoredPath(string fullPath);

        /// <summary>The full path of a stored (relative) path under the current storage root.</summary>
        string ToFullPath(string storedPath);

        /// <summary>The project's folder under the storage root.</summary>
        string GetProjectDirectory(string projectId);
    }

    /// <summary>An upload in the shared store: its full path, SHA-256, and whether an identical stored file was reused.</summary>
    public sealed class StoredUpload : IRecord<StoredUpload>, IEquatable<StoredUpload>
    {
        public string FullPath { get; set; }

        public string Sha256 { get; set; }

        public bool Reused { get; set; }

        public StoredUpload(string FullPath, string Sha256, bool Reused)
    {
    this.FullPath = FullPath;
    this.Sha256 = Sha256;
    this.Reused = Reused;
    }

        public void Deconstruct(out string FullPath, out string Sha256, out bool Reused)
    {
    FullPath = this.FullPath;
    Sha256 = this.Sha256;
    Reused = this.Reused;
    }

        public bool Equals(StoredUpload other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(FullPath, other.FullPath)
    && EqualityComparer<string>.Default.Equals(Sha256, other.Sha256)
    && EqualityComparer<bool>.Default.Equals(Reused, other.Reused);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as StoredUpload);
    }

        public static bool operator ==(StoredUpload left, StoredUpload right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(StoredUpload left, StoredUpload right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 42347;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(FullPath);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Sha256);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Reused);
    return hash;
    }
    }

        public override string ToString()
    {
    return "StoredUpload { " + "FullPath = " + FullPath + ", " + "Sha256 = " + Sha256 + ", " + "Reused = " + Reused + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public StoredUpload CloneRecord()
    {
    return (StoredUpload)MemberwiseClone();
    }

    }

}
