﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>
    /// What is recorded with every audit entry besides the entry itself: the network address the person works from
    /// (Application Security Checklist: the client IP address in the audit trail).
    /// </summary>
    public interface IAuditContext
    {
        /// <summary>The current request's client address as the Platform forwarded it, or null (not known).</summary>
        string ClientAddress { get; }
    }

}
