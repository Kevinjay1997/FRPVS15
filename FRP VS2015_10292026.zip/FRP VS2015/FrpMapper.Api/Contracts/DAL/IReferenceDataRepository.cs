﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.DAL
{
    public interface IReferenceDataRepository
    {
        Task<ReferenceDataDto> ReadAsync(CancellationToken cancellationToken);

        /// <summary>Maker: stores a bank profile change for a Checker (throws <see cref="AccessRequestOpenException"/> when one is already open,
        /// <see cref="ConcurrencyConflictException"/> when the profile changed since it was read).</summary>
        Task<BankProfileRequestDto> CreateBankRequestAsync(BankProfileRequestDto request, CancellationToken cancellationToken);

        /// <summary>Checker: approves (applies) or rejects the change; the requester may cancel it. False when the request does not exist.</summary>
        Task<bool> DecideBankRequestAsync(string requestId, byte[] expectedVersion, string decision, string decidedBy, DateTimeOffset decidedAt, string comment,
            CancellationToken cancellationToken);

        Task SaveImportAsync(SandboxImportDto import, string user, CancellationToken cancellationToken);
    }

}
