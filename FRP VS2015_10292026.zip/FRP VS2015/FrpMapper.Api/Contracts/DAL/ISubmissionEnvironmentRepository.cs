using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>The BSP environments (frp.SubmissionEnvironment, 010_submission_environments.sql).</summary>
    public interface ISubmissionEnvironmentRepository
    {
        /// <summary>Every Pending and Active environment version and the latest decided ones.</summary>
        Task<IReadOnlyList<SubmissionEnvironmentDto>> ListAsync(CancellationToken cancellationToken);

        /// <summary>
        /// Maker: stores a proposed version as Pending. Throws <see cref="AccessRequestOpenException"/> when the key already
        /// has one waiting. Returns it with its row version.
        /// </summary>
        Task<SubmissionEnvironmentDto> RequestAsync(SubmissionEnvironmentDto environment, CancellationToken cancellationToken);

        /// <summary>
        /// Approved / Rejected / Cancelled (a Pending version) or Removed (the Active one). False when it does not exist;
        /// <see cref="ConcurrencyConflictException"/> when it changed; <see cref="AccessDecisionRefusedException"/> for self-approval.
        /// </summary>
        Task<bool> DecideAsync(string environmentId, byte[] expectedVersion, string decision, string decidedBy, DateTimeOffset decidedAt, string comment,
            CancellationToken cancellationToken);

        /// <summary>The Active version of an environment, or null.</summary>
        Task<SubmissionEnvironmentDto> GetActiveAsync(string key, CancellationToken cancellationToken);
    }
}
