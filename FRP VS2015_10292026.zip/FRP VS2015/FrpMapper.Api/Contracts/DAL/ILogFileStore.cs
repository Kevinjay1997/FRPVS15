using System;
using System.Collections.Generic;
using System.IO;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>A log file of the API: its name (e.g. api-20261028.log), size and last change.</summary>
    public sealed class LogFileInfo
    {
        public string Name { get; set; } = "";

        public long Size { get; set; }

        public DateTimeOffset LastWritten { get; set; }
    }

    /// <summary>The API's log files (the folder of Logging:FilePath), read-only.</summary>
    public interface ILogFileStore
    {
        /// <summary>The log files, newest first; empty when logging to a file is off.</summary>
        IReadOnlyList<LogFileInfo> List();

        /// <summary>One log file opened for reading (it may still be written to), or null when there is no such file.</summary>
        Stream Open(string name);
    }
}
