﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Contracts.DAL
{
    /// <summary>Read-only data for the maintenance, user extraction and sign-in reports.</summary>
    public interface IReportRepository
    {
        Task<AccessChangeHistory> GetAccessChangesAsync(DateTimeOffset to, CancellationToken cancellationToken);

        Task<BankChangeHistory> GetBankChangesAsync(DateTimeOffset to, CancellationToken cancellationToken);

        Task<UserReportData> GetUsersAsync(CancellationToken cancellationToken);

        /// <summary>Sign-in attempts from <paramref name="from"/> (inclusive) to <paramref name="to"/> (exclusive), newest first.</summary>
        Task<IReadOnlyList<AuditEntryDto>> GetSignInsAsync(DateTimeOffset from, DateTimeOffset to, string userName, int take, CancellationToken cancellationToken);
    }

    /// <summary>When a person, role or bank profile was created and last changed (UTC).</summary>
    public sealed class ReportTarget : IRecord<ReportTarget>, IEquatable<ReportTarget>
    {
        public string Key { get; set; }

        public string Name { get; set; }

        public DateTime CreatedAtUtc { get; set; }

        public DateTime? UpdatedAtUtc { get; set; }

        public ReportTarget(string Key, string Name, DateTime CreatedAtUtc, DateTime? UpdatedAtUtc)
    {
    this.Key = Key;
    this.Name = Name;
    this.CreatedAtUtc = CreatedAtUtc;
    this.UpdatedAtUtc = UpdatedAtUtc;
    }

        public void Deconstruct(out string Key, out string Name, out DateTime CreatedAtUtc, out DateTime? UpdatedAtUtc)
    {
    Key = this.Key;
    Name = this.Name;
    CreatedAtUtc = this.CreatedAtUtc;
    UpdatedAtUtc = this.UpdatedAtUtc;
    }

        public bool Equals(ReportTarget other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Key, other.Key)
    && EqualityComparer<string>.Default.Equals(Name, other.Name)
    && EqualityComparer<DateTime>.Default.Equals(CreatedAtUtc, other.CreatedAtUtc)
    && EqualityComparer<DateTime?>.Default.Equals(UpdatedAtUtc, other.UpdatedAtUtc);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ReportTarget);
    }

        public static bool operator ==(ReportTarget left, ReportTarget right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ReportTarget left, ReportTarget right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 950;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Key);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    hash = hash * -1521134295 + EqualityComparer<DateTime>.Default.GetHashCode(CreatedAtUtc);
    hash = hash * -1521134295 + EqualityComparer<DateTime?>.Default.GetHashCode(UpdatedAtUtc);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ReportTarget { " + "Key = " + Key + ", " + "Name = " + Name + ", " + "CreatedAtUtc = " + CreatedAtUtc + ", " + "UpdatedAtUtc = " + UpdatedAtUtc + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ReportTarget CloneRecord()
    {
    return (ReportTarget)MemberwiseClone();
    }

    }

    public sealed class AccessChangeHistory : IRecord<AccessChangeHistory>, IEquatable<AccessChangeHistory>
    {
        public IReadOnlyList<AccessChangeRequestDto> Requests { get; set; }

        public IReadOnlyList<ReportTarget> Users { get; set; }

        public IReadOnlyList<ReportTarget> Roles { get; set; }

        public AccessChangeHistory(IReadOnlyList<AccessChangeRequestDto> Requests, IReadOnlyList<ReportTarget> Users, IReadOnlyList<ReportTarget> Roles)
    {
    this.Requests = Requests;
    this.Users = Users;
    this.Roles = Roles;
    }

        public void Deconstruct(out IReadOnlyList<AccessChangeRequestDto> Requests, out IReadOnlyList<ReportTarget> Users, out IReadOnlyList<ReportTarget> Roles)
    {
    Requests = this.Requests;
    Users = this.Users;
    Roles = this.Roles;
    }

        public bool Equals(AccessChangeHistory other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<AccessChangeRequestDto>>.Default.Equals(Requests, other.Requests)
    && EqualityComparer<IReadOnlyList<ReportTarget>>.Default.Equals(Users, other.Users)
    && EqualityComparer<IReadOnlyList<ReportTarget>>.Default.Equals(Roles, other.Roles);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as AccessChangeHistory);
    }

        public static bool operator ==(AccessChangeHistory left, AccessChangeHistory right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(AccessChangeHistory left, AccessChangeHistory right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 74737;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<AccessChangeRequestDto>>.Default.GetHashCode(Requests);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<ReportTarget>>.Default.GetHashCode(Users);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<ReportTarget>>.Default.GetHashCode(Roles);
    return hash;
    }
    }

        public override string ToString()
    {
    return "AccessChangeHistory { " + "Requests = " + Requests + ", " + "Users = " + Users + ", " + "Roles = " + Roles + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public AccessChangeHistory CloneRecord()
    {
    return (AccessChangeHistory)MemberwiseClone();
    }

    }

    public sealed class BankChangeHistory : IRecord<BankChangeHistory>, IEquatable<BankChangeHistory>
    {
        public IReadOnlyList<BankProfileRequestDto> Requests { get; set; }

        public IReadOnlyList<ReportTarget> Banks { get; set; }

        public BankChangeHistory(IReadOnlyList<BankProfileRequestDto> Requests, IReadOnlyList<ReportTarget> Banks)
    {
    this.Requests = Requests;
    this.Banks = Banks;
    }

        public void Deconstruct(out IReadOnlyList<BankProfileRequestDto> Requests, out IReadOnlyList<ReportTarget> Banks)
    {
    Requests = this.Requests;
    Banks = this.Banks;
    }

        public bool Equals(BankChangeHistory other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<BankProfileRequestDto>>.Default.Equals(Requests, other.Requests)
    && EqualityComparer<IReadOnlyList<ReportTarget>>.Default.Equals(Banks, other.Banks);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as BankChangeHistory);
    }

        public static bool operator ==(BankChangeHistory left, BankChangeHistory right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(BankChangeHistory left, BankChangeHistory right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 79497;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<BankProfileRequestDto>>.Default.GetHashCode(Requests);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<ReportTarget>>.Default.GetHashCode(Banks);
    return hash;
    }
    }

        public override string ToString()
    {
    return "BankChangeHistory { " + "Requests = " + Requests + ", " + "Banks = " + Banks + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public BankChangeHistory CloneRecord()
    {
    return (BankChangeHistory)MemberwiseClone();
    }

    }

    public sealed class ReportUser : IRecord<ReportUser>, IEquatable<ReportUser>
    {
        public string UserName { get; set; }

        public string DisplayName { get; set; }

        public string Department { get; set; }

        public DateOnly? AccessUntil { get; set; }

        public bool IsActive { get; set; }

        public string DisabledReason { get; set; }

        public bool IsDeleted { get; set; }

        public DateTime? DeletedAtUtc { get; set; }

        public DateTime CreatedAtUtc { get; set; }

        public DateTime UpdatedAtUtc { get; set; }

        public IReadOnlyList<string> Roles { get; set; }

        public ReportUser(string UserName, string DisplayName, string Department, DateOnly? AccessUntil, bool IsActive, string DisabledReason, bool IsDeleted, DateTime? DeletedAtUtc, DateTime CreatedAtUtc, DateTime UpdatedAtUtc, IReadOnlyList<string> Roles)
    {
    this.UserName = UserName;
    this.DisplayName = DisplayName;
    this.Department = Department;
    this.AccessUntil = AccessUntil;
    this.IsActive = IsActive;
    this.DisabledReason = DisabledReason;
    this.IsDeleted = IsDeleted;
    this.DeletedAtUtc = DeletedAtUtc;
    this.CreatedAtUtc = CreatedAtUtc;
    this.UpdatedAtUtc = UpdatedAtUtc;
    this.Roles = Roles;
    }

        public void Deconstruct(out string UserName, out string DisplayName, out string Department, out DateOnly? AccessUntil, out bool IsActive, out string DisabledReason, out bool IsDeleted, out DateTime? DeletedAtUtc, out DateTime CreatedAtUtc, out DateTime UpdatedAtUtc, out IReadOnlyList<string> Roles)
    {
    UserName = this.UserName;
    DisplayName = this.DisplayName;
    Department = this.Department;
    AccessUntil = this.AccessUntil;
    IsActive = this.IsActive;
    DisabledReason = this.DisabledReason;
    IsDeleted = this.IsDeleted;
    DeletedAtUtc = this.DeletedAtUtc;
    CreatedAtUtc = this.CreatedAtUtc;
    UpdatedAtUtc = this.UpdatedAtUtc;
    Roles = this.Roles;
    }

        public bool Equals(ReportUser other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<string>.Default.Equals(DisplayName, other.DisplayName)
    && EqualityComparer<string>.Default.Equals(Department, other.Department)
    && EqualityComparer<DateOnly?>.Default.Equals(AccessUntil, other.AccessUntil)
    && EqualityComparer<bool>.Default.Equals(IsActive, other.IsActive)
    && EqualityComparer<string>.Default.Equals(DisabledReason, other.DisabledReason)
    && EqualityComparer<bool>.Default.Equals(IsDeleted, other.IsDeleted)
    && EqualityComparer<DateTime?>.Default.Equals(DeletedAtUtc, other.DeletedAtUtc)
    && EqualityComparer<DateTime>.Default.Equals(CreatedAtUtc, other.CreatedAtUtc)
    && EqualityComparer<DateTime>.Default.Equals(UpdatedAtUtc, other.UpdatedAtUtc)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(Roles, other.Roles);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ReportUser);
    }

        public static bool operator ==(ReportUser left, ReportUser right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ReportUser left, ReportUser right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 94256;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DisplayName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Department);
    hash = hash * -1521134295 + EqualityComparer<DateOnly?>.Default.GetHashCode(AccessUntil);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsActive);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DisabledReason);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(IsDeleted);
    hash = hash * -1521134295 + EqualityComparer<DateTime?>.Default.GetHashCode(DeletedAtUtc);
    hash = hash * -1521134295 + EqualityComparer<DateTime>.Default.GetHashCode(CreatedAtUtc);
    hash = hash * -1521134295 + EqualityComparer<DateTime>.Default.GetHashCode(UpdatedAtUtc);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(Roles);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ReportUser { " + "UserName = " + UserName + ", " + "DisplayName = " + DisplayName + ", " + "Department = " + Department + ", " + "AccessUntil = " + AccessUntil + ", " + "IsActive = " + IsActive + ", " + "DisabledReason = " + DisabledReason + ", " + "IsDeleted = " + IsDeleted + ", " + "DeletedAtUtc = " + DeletedAtUtc + ", " + "CreatedAtUtc = " + CreatedAtUtc + ", " + "UpdatedAtUtc = " + UpdatedAtUtc + ", " + "Roles = " + Roles + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ReportUser CloneRecord()
    {
    return (ReportUser)MemberwiseClone();
    }

    }

    public sealed class ReportSignIn : IRecord<ReportSignIn>, IEquatable<ReportSignIn>
    {
        public string UserName { get; set; }

        public DateTimeOffset? LastSignInAt { get; set; }

        public string LastRoles { get; set; }

        public ReportSignIn(string UserName, DateTimeOffset? LastSignInAt, string LastRoles)
    {
    this.UserName = UserName;
    this.LastSignInAt = LastSignInAt;
    this.LastRoles = LastRoles;
    }

        public void Deconstruct(out string UserName, out DateTimeOffset? LastSignInAt, out string LastRoles)
    {
    UserName = this.UserName;
    LastSignInAt = this.LastSignInAt;
    LastRoles = this.LastRoles;
    }

        public bool Equals(ReportSignIn other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(UserName, other.UserName)
    && EqualityComparer<DateTimeOffset?>.Default.Equals(LastSignInAt, other.LastSignInAt)
    && EqualityComparer<string>.Default.Equals(LastRoles, other.LastRoles);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ReportSignIn);
    }

        public static bool operator ==(ReportSignIn left, ReportSignIn right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ReportSignIn left, ReportSignIn right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 38119;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(UserName);
    hash = hash * -1521134295 + EqualityComparer<DateTimeOffset?>.Default.GetHashCode(LastSignInAt);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(LastRoles);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ReportSignIn { " + "UserName = " + UserName + ", " + "LastSignInAt = " + LastSignInAt + ", " + "LastRoles = " + LastRoles + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ReportSignIn CloneRecord()
    {
    return (ReportSignIn)MemberwiseClone();
    }

    }

    public sealed class UserReportData : IRecord<UserReportData>, IEquatable<UserReportData>
    {
        public IReadOnlyList<ReportUser> Users { get; set; }

        public IReadOnlyList<ReportSignIn> SignIns { get; set; }

        public UserReportData(IReadOnlyList<ReportUser> Users, IReadOnlyList<ReportSignIn> SignIns)
    {
    this.Users = Users;
    this.SignIns = SignIns;
    }

        public void Deconstruct(out IReadOnlyList<ReportUser> Users, out IReadOnlyList<ReportSignIn> SignIns)
    {
    Users = this.Users;
    SignIns = this.SignIns;
    }

        public bool Equals(UserReportData other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<ReportUser>>.Default.Equals(Users, other.Users)
    && EqualityComparer<IReadOnlyList<ReportSignIn>>.Default.Equals(SignIns, other.SignIns);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as UserReportData);
    }

        public static bool operator ==(UserReportData left, UserReportData right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(UserReportData left, UserReportData right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 71866;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<ReportUser>>.Default.GetHashCode(Users);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<ReportSignIn>>.Default.GetHashCode(SignIns);
    return hash;
    }
    }

        public override string ToString()
    {
    return "UserReportData { " + "Users = " + Users + ", " + "SignIns = " + SignIns + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public UserReportData CloneRecord()
    {
    return (UserReportData)MemberwiseClone();
    }

    }

}
