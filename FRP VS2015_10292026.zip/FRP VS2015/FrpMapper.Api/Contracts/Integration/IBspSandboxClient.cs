using System;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Shared.Models;
namespace FrpMapper.Api.Contracts.Integration
{
    public interface IBspSandboxClient
    {
        /// <summary>
        /// Sends one request with the bank's client certificate: a POST of <paramref name="content"/>, or a GET when it is
        /// null. <paramref name="download"/>: a successful answer is a file (FileBytes), not text.
        /// </summary>
        Task<SandboxResponse> SendAsync(X509Certificate2 certificate, Uri url, HttpContent content, bool download, CancellationToken cancellation);
    }
}
