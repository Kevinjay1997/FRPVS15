using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.BL.Cocree;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// The COCREE configuration is reference data, approved like bank profiles and BSP environments (see
    /// <see cref="WorkbenchConfigWorkflow"/>): a Maker uploads the Workbench's cocree_config.xlsx,
    /// cocree_dropdown_options.xlsx and cocree_validations.xlsx, and optionally BSP's COCREE XSD; they are checked and
    /// stored as a Pending version, and a different Checker approves it.
    /// </summary>
    public sealed class CocreeConfigService : ICocreeConfigService
    {
        private const int MaxProblemsShown = 25;
        private readonly WorkbenchConfigWorkflow workflow;
        private readonly IOptionsMonitor<FileStorageOptions> storage;

        public CocreeConfigService(IWorkbenchConfigRepository versions, ICurrentUser user, IOptionsMonitor<FileStorageOptions> storage)
        {
            workflow = new WorkbenchConfigWorkflow(versions, user, WorkbenchConfigKind.Cocree, "COCREE configuration");
            this.storage = storage;
        }

        public Task<WorkbenchSettingsDto> ListAsync(CancellationToken cancellation)
        {
            return workflow.ListAsync(cancellation);
        }

        public async Task<WorkbenchConfigVersionDto> UploadAsync(CocreeConfigUpload upload, CancellationToken cancellation)
        {
            var note = workflow.BeginUpload(upload.Note);
            if (upload.ConfigWorkbook == null || upload.CodeListWorkbook == null || upload.ValidationWorkbook == null)
                throw WorkbenchConfigWorkflow.Invalid("Choose the three workbooks: the configuration (cocree_config.xlsx), the code lists (cocree_dropdown_options.xlsx) and the validation rules (cocree_validations.xlsx).");
            RequireFile(upload.ConfigWorkbook, ".xlsx", "configuration workbook");
            RequireFile(upload.CodeListWorkbook, ".xlsx", "code list workbook");
            RequireFile(upload.ValidationWorkbook, ".xlsx", "validation rules workbook");
            string xsd = null;
            if (upload.Xsd != null)
            {
                RequireFile(upload.Xsd, ".xsd", "XSD");
                xsd = XmlSchemaChecker.ReadText(Read(upload.Xsd));
            }

            // Read the files and check that the export and the validation can use them.
            CocreeConfigDto content;
            try
            {
                using (var config = upload.ConfigWorkbook.OpenReadStream())
                using (var codes = upload.CodeListWorkbook.OpenReadStream())
                using (var validations = upload.ValidationWorkbook.OpenReadStream())
                {
                    content = CocreeConfiguration.FromFiles(config, codes, validations, upload.Xsd == null ? null : Path.GetFileName(upload.Xsd.FileName), xsd);
                }
            }
            catch (CocreeFileException ex)
            {
                throw WorkbenchConfigWorkflow.Invalid(ex.Message);
            }
            catch (Exception ex) when (ex is InvalidDataException || ex is System.Xml.XmlException)
            {
                throw WorkbenchConfigWorkflow.Invalid("A workbook could not be read: " + ex.Message);
            }

            var problems = new List<string>();
            var notes = new List<string>();
            var configuration = CocreeConfiguration.Load(content, problems, notes);
            if (configuration == null)
            {
                throw WorkbenchConfigWorkflow.Invalid("The configuration cannot be used: " + string.Join(" ", problems.Take(MaxProblemsShown))
                    + (problems.Count > MaxProblemsShown ? " … and " + (problems.Count - MaxProblemsShown) + " more." : ""));
            }

            var summary = configuration.Summary();
            summary.Notes = notes;
            var files = new[] { upload.ConfigWorkbook, upload.CodeListWorkbook, upload.ValidationWorkbook, upload.Xsd }.Where(f => f != null).Select(f => Path.GetFileName(f.FileName));
            return await workflow.RequestAsync(string.Join(", ", files), note, summary, JsonSerializer.Serialize(content),
                active => CocreeConfiguration.Differences(JsonSerializer.Deserialize<CocreeConfigDto>(active), content), cancellation);
        }

        public Task<bool> DecideAsync(string configId, string decision, AccessDecisionRequest body, CancellationToken cancellation)
        {
            return workflow.DecideAsync(configId, decision, body, cancellation);
        }

        /// <summary>One of a version's files: "config", "code-lists" or "validations" as .xlsx, or "xsd".</summary>
        public async Task<ToolDownload> DownloadAsync(string configId, string file, CancellationToken cancellation)
        {
            if (file != "config" && file != "code-lists" && file != "validations" && file != "xsd") return null;
            var stored = await workflow.GetForDownloadAsync(configId, cancellation);
            if (stored == null) return null;
            var content = JsonSerializer.Deserialize<CocreeConfigDto>(stored.Content);
            var suffix = "_" + stored.Version.Status.ToLowerInvariant() + "_" + stored.Version.RequestedAt.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
            if (file == "xsd")
            {
                if (string.IsNullOrEmpty(content.Xsd)) return null;
                var name = Path.GetFileNameWithoutExtension(content.XsdFileName.Length > 0 ? content.XsdFileName : "cocree.xsd") + suffix + ".xsd";
                return new ToolDownload(new MemoryStream(new UTF8Encoding(false).GetBytes(content.Xsd), false), name, "application/xml");
            }

            List<WorkbenchTableDto> sheets;
            string baseName;
            switch (file)
            {
                case "config": sheets = content.Tables; baseName = "cocree_config"; break;
                case "code-lists": sheets = content.CodeLists; baseName = "cocree_dropdown_options"; break;
                default: sheets = content.Validations ?? new List<WorkbenchTableDto>(); baseName = "cocree_validations"; break;
            }

            if (sheets.Count == 0) return null;
            var bytes = CocreeWorkbookWriter.Write(sheets);
            return new ToolDownload(new MemoryStream(bytes, false), baseName + suffix + ".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        }

        private void RequireFile(IFormFile file, string extension, string description)
        {
            if (!string.Equals(Path.GetExtension(file.FileName), extension, StringComparison.OrdinalIgnoreCase))
                throw WorkbenchConfigWorkflow.Invalid("The " + description + " must be a " + extension + " file.");
            if (file.Length > storage.CurrentValue.MaxUploadBytes)
                throw WorkbenchConfigWorkflow.Invalid("The " + description + " is larger than " + storage.CurrentValue.MaxUploadMegabytes + " MB.");
        }

        private static byte[] Read(IFormFile file)
        {
            using (var stream = file.OpenReadStream())
            using (var copy = new MemoryStream())
            {
                stream.CopyTo(copy);
                return copy.ToArray();
            }
        }
    }
}
