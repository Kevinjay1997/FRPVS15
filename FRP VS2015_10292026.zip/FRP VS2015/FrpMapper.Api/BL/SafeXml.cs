﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Reads XML from uploaded files (XSD, the parts of Excel workbooks) without DTD processing or external resolution
    /// (Application Security Checklist: XML external entities / entity expansion). A document with a DOCTYPE is refused
    /// with an <see cref="XmlException"/>; no file or URL is ever fetched while reading.
    /// </summary>
    public static class SafeXml
    {
        public static XmlReaderSettings Settings() => new XmlReaderSettings() {
            DtdProcessing = DtdProcessing.Prohibit,
            XmlResolver = null,
            // Whitespace is kept as in the file (LoadOptions.PreserveWhitespace decides what XDocument keeps).
            IgnoreWhitespace = false
        };

        public static XDocument Load(Stream stream, LoadOptions options = LoadOptions.None)
        {
            using (var reader = XmlReader.Create(stream, Settings()))
            {
            return XDocument.Load(reader, options);
            }
        }

        public static XDocument Load(string path, LoadOptions options = LoadOptions.None)
        {
            using (var reader = XmlReader.Create(path, Settings()))
            {
            return XDocument.Load(reader, options);
            }
        }

        public static XElement Parse(string text)
        {
            using (var reader = XmlReader.Create(new StringReader(text), Settings()))
            {
            return XElement.Load(reader);
            }
        }
    }

}
