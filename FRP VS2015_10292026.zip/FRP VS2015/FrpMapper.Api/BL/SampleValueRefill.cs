﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;
using FrpMapper.Shared.Validation;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Every XSD field's own sample value (stored in frp.SchemaNode.TestValue when a project is created, and again by
    /// "Fill sample values" on the Mappings tab): each amount, whole number and text is a different value, every value
    /// satisfies its XSD facets, and the BSP rule solver then makes the amounts agree with the specification's assertions
    /// (totals, cross-checks), exactly as for the sample export. The seed decides the values (a new seed, new values).
    /// Enumerated values, dates, true/false, fixed values, the Header (undertaking, year, period) and codes the rules
    /// compare keep their usual sample values: they cannot, or must not, differ per field.
    /// </summary>
    public sealed partial class SampleValueRefill
    {
        private readonly BspSpecificationReader specificationReader;
        private readonly BspSampleValueSolver solver;

        public SampleValueRefill(BspSpecificationReader specificationReader, BspSampleValueSolver solver)
    {
        this.specificationReader = specificationReader;
        this.solver = solver;
    }
        /// <summary>At most this many variants are tried to make one text value unique.</summary>
        private const int MaxTextAttempts = 5000;

        /// <param name="keepAllRuleFields">
        /// False: only codes a rule compares or looks up keep their values (a rule that only checks that a text is filled
        /// in does not). True: every code or text a rule mentions keeps its value (the safe fallback).
        /// </param>
        public SampleRefill Refill(FrpProjectDto project, string seed, bool keepAllRuleFields = false, ValidationStep progress = null)
        {
            var specification = project.SpecificationFile != null && File.Exists(project.SpecificationFile.StoredPath)
                ? specificationReader.Read(project.SpecificationFile.StoredPath)
                : null;
            var ruleFields = ((specification == null) ? new List<RuleField>() : RuleFields(specification, keepAllRuleFields))
                .Distinct()
                .GroupBy(field => field.Name, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.OrdinalIgnoreCase);
            Func<SchemaNodeDto, bool> Changes = null;
            Changes = (SchemaNodeDto nodeArg) =>
            {
                List<RuleField> sameName;
                return Refillable(nodeArg) // Codes and counts a BSP rule refers to (e.g. branch, month and product that join rows across sheets)
                // keep their values: making them unique would break those rules. Amounts are balanced by the solver.
                && (nodeArg.DataType == "decimal" || !(ruleFields.TryGetValue(nodeArg.Name, out sameName) && sameName.Any(field => field.Matches(nodeArg))));
            };

            // Every XSD field, mapped or not, has its own value.
            var targets = project.SchemaNodes.Where(n => n.DataType != "complex" && Changes(n))
                .Select(n => n.Path).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var usedAmounts = new HashSet<decimal>();
            var usedWholeNumbers = new HashSet<string>(StringComparer.Ordinal);
            var nodes = project.SchemaNodes
                .Select(node => !targets.Contains(node.Path) ? node : node.With(copy => { copy.TestValue = node.DataType == "integer"
                        ? UniqueWholeNumber(node, seed, usedWholeNumbers)
                        : XsdTestValueGenerator.Generate(node.Name, node.DataType, node.Validation, sampleKey: $"{node.Path}|{seed}", usedAmounts: usedAmounts); }))
                .ToList();
            // Text before the solver, so the rows it adds (e.g. one per branch and month) use the final values.
            nodes = MakeTextUnique(nodes, targets);

            IReadOnlyList<SampleRowDto> sampleRows = project.SampleRows;
            IReadOnlyList<string> omittedForms = project.SampleOmittedForms;
            if (specification != null)
            {
                var refined = BspSampleValueRefiner.Apply(nodes, specification);
                var solved = solver.Apply(refined, project.RootElement, project.TargetNamespace, specification, progress: progress);
                nodes = solved.Nodes.ToList();
                sampleRows = solved.SampleRows;
                omittedForms = solved.OmittedForms;
            }

            var nodesByPath = nodes
                .Where(n => n.DataType != "complex")
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var mappings = project.Mappings
                .Select(m => { SchemaNodeDto node; return nodesByPath.TryGetValue(m.SchemaPath, out node) ? m.With(copy => { copy.DefaultValue = node.TestValue; }) : m; })
                .ToList();
            return new SampleRefill(nodes, mappings, sampleRows, omittedForms);
        }

        /// <summary>
        /// The fields whose value the specification's rules depend on ("$1[C0010]=$[C0010]", LOOKUP(...;
        /// [Header][Undertaking])), each with the sheet and table it belongs to: "$[C0040]" in a rule looping over
        /// [CAR_Part_IV_4a][MAIN_Y1] is that table's C0040, not every C0040. A field only tested with ISNULL(...) is not
        /// one of them, unless <paramref name="all"/> asks for every field a rule mentions.
        /// </summary>
        private static List<RuleField> RuleFields(BspSpecification specification, bool all)
        {
            var fields = new List<RuleField>();
            foreach (var assertion in specification.Assertions)
            {
                var formulas = new[] { assertion.Left, assertion.Right, assertion.Precondition }
                    .Select(text => all ? text ?? "" : NullCheck().Replace(text ?? "", "ISNULL()"))
                    .ToList();
                // The tables a "$" reference can mean: the rule's loop, and the tables a SUMIF/COUNTIF iterates ([S][T]:$1).
                var scopes = TableReference().Matches(assertion.Loop ?? "").Cast<System.Text.RegularExpressions.Match>()
                    .Concat(formulas.SelectMany(f => TableReference().Matches(f).Cast<System.Text.RegularExpressions.Match>()))
                    .Select(m => new VT_Sheet_Table<string, string>(m.Groups[1].Value, m.Groups[2].Value))
                    .Distinct()
                    .ToList();
                foreach (var formula in formulas)
                {
                    foreach (System.Text.RegularExpressions.Match match in FieldReference().Matches(formula))
                    {
                        var names = match.Groups["names"].Captures.Cast<System.Text.RegularExpressions.Capture>().Select(c => c.Value).ToList();
                        if (match.Groups["relative"].Success)
                        {
                            var field = names[names.Count - 1];
                            fields.AddRange(scopes.Count == 0
                                ? new List<RuleField> { new RuleField(null, null, field) }
                                : scopes.Select(scope => new RuleField(scope.Sheet, scope.Table, field)));
                        }
                        else if (names.Count >= 2)
                        {
                            // [Sheet][Field] or [Sheet][Table][Field]
                            fields.Add(new RuleField(names[0], names.Count >= 3 ? names[names.Count - 2] : null, names[names.Count - 1]));
                        }
                    }
                }
            }

            return fields;
        }

        private sealed class RuleField : IRecord<RuleField>, IEquatable<RuleField>
    {
        public string Sheet { get; set; }

        public string Table { get; set; }

        public string Name { get; set; }

        public RuleField(string Sheet, string Table, string Name)
    {
    this.Sheet = Sheet;
    this.Table = Table;
    this.Name = Name;
    }

        public void Deconstruct(out string Sheet, out string Table, out string Name)
    {
    Sheet = this.Sheet;
    Table = this.Table;
    Name = this.Name;
    }

            /// <summary>/Root/Sheet/Table/Table_Item/Field or /Root/Sheet/Field.</summary>
            public bool Matches(SchemaNodeDto node)
            {
                if (!string.Equals(node.Name, Name, StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }

                var parts = node.Path.Split('/', StringSplitOptions.RemoveEmptyEntries);
                return (Sheet == null || parts.Length > 1 && string.Equals(parts[1], Sheet, StringComparison.OrdinalIgnoreCase))
                    && (Table == null || parts.Skip(2).Any(p => string.Equals(p, Table, StringComparison.OrdinalIgnoreCase)));
            }

        public bool Equals(RuleField other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Sheet, other.Sheet)
    && EqualityComparer<string>.Default.Equals(Table, other.Table)
    && EqualityComparer<string>.Default.Equals(Name, other.Name);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as RuleField);
    }

        public static bool operator ==(RuleField left, RuleField right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(RuleField left, RuleField right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 75117;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Sheet);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Table);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    return hash;
    }
    }

        public override string ToString()
    {
    return "RuleField { " + "Sheet = " + Sheet + ", " + "Table = " + Table + ", " + "Name = " + Name + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public RuleField CloneRecord()
    {
    return (RuleField)MemberwiseClone();
    }

    }

            private static System.Text.RegularExpressions.Regex FieldReference() { return FieldReferenceInstance; }

            private static System.Text.RegularExpressions.Regex TableReference() { return TableReferenceInstance; }


            private static System.Text.RegularExpressions.Regex NullCheck() { return NullCheckInstance; }

        /// <summary>Fields whose value can differ per field: not enumerated, fixed, date, true/false or a Header field.</summary>
        private static bool Refillable(SchemaNodeDto node) =>
            (node.DataType == "decimal" || node.DataType == "integer" || node.DataType == "string")
            && node.Validation.Enumerations.Count == 0
            && node.Validation.FixedValue == null
            && !IsHeaderField(node.Path);

        private static bool IsHeaderField(string path)
        {
            var parts = path.Split('/', StringSplitOptions.RemoveEmptyEntries);
            return parts.Length >= 2 && string.Equals(parts[1], "Header", StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>A whole number within the XSD bounds that no other field has (small, count-like values first).</summary>
        private static string UniqueWholeNumber(SchemaNodeDto node, string seed, ISet<string> used)
        {
            var probe = node.With(copy => { copy.IsRequired = true; });
            var validation = node.Validation;
            decimal min;
            var lower = decimal.TryParse(validation.MinInclusive, NumberStyles.Number, CultureInfo.InvariantCulture, out min) ? min : 0m;
            decimal max;
            var upper = decimal.TryParse(validation.MaxInclusive, NumberStyles.Number, CultureInfo.InvariantCulture, out max) ? max : 999999999m;
            int digits;
            if (CompatPattern.Is(validation.TotalDigits, out digits) && validation.TotalDigits > 0 && validation.TotalDigits < 19)
            {
                upper = Math.Min(upper, (decimal)Math.Pow(10, digits) - 1);
            }

            lower = Math.Max(lower, Math.Min(1m, upper));
            var span = Math.Min(upper, lower + 99999m) - lower;
            if (span >= 0)
            {
                var random = new Random(BitConverter.ToInt32(CompatHash.Sha256(Encoding.UTF8.GetBytes($"{node.Path}|{seed}")), 0));
                for (var attempt = 0; attempt < 200; attempt++)
                {
                    var candidate = decimal.Truncate(lower + (decimal)random.NextDouble() * (span + 1)).ToString("0", CultureInfo.InvariantCulture);
                    if (XsdValueValidator.IsValid(candidate, probe) && used.Add(candidate))
                    {
                        return candidate;
                    }
                }
            }

            return XsdTestValueGenerator.Generate(node.Name, node.DataType, validation, sampleKey: $"{node.Path}|{seed}");
        }

        /// <summary>
        /// Gives every mapped free-text field its own value: a repeated value gets a number ("Regular banking data 2"),
        /// cut to the XSD length when needed, and only a variant that still matches the XSD facets is used.
        /// </summary>
        private static List<SchemaNodeDto> MakeTextUnique(List<SchemaNodeDto> nodes, ISet<string> targets)
        {
            var used = new HashSet<string>(nodes
                .Where(n => n.DataType != "complex" && n.TestValue != null)
                .Where(n => !(targets.Contains(n.Path) && n.DataType == "string" && Refillable(n)))
                .Select(n => n.TestValue), StringComparer.Ordinal);
            var result = new List<SchemaNodeDto>(nodes.Count);
            foreach (var node in nodes)
            {
                if (node.DataType != "string" || !Refillable(node) || !targets.Contains(node.Path) || string.IsNullOrEmpty(node.TestValue))
                {
                    result.Add(node);
                    continue;
                }

                if (used.Add(node.TestValue))
                {
                    result.Add(node);
                    continue;
                }

                var probe = node.With(copy => { copy.IsRequired = true; });
                var maxLength = node.Validation.Length ?? node.Validation.MaxLength ?? int.MaxValue;
                string unique = null;
                // "Text 2", "Text 3"… and, for values that may not contain a space (codes), "TEXT2", "TEXT3"…
                foreach (var separator in new[] { " ", "" })
                {
                    for (var n = 2; n < MaxTextAttempts && unique == null; n++)
                    {
                        var candidate = WithSuffix(node.TestValue, separator + n.ToString(CultureInfo.InvariantCulture), maxLength);
                        if (candidate == null || !XsdValueValidator.IsValid(candidate, probe))
                        {
                            break; // this style does not fit the XSD for this field; longer numbers will not either
                        }

                        if (used.Add(candidate))
                        {
                            unique = candidate;
                        }
                    }
                }

                result.Add((unique == null) ? node : node.With(copy => { copy.TestValue = unique; }));
            }

            return result;
        }

        private static string WithSuffix(string value, string suffix, int maxLength)
        {
            if (suffix.Length > maxLength)
            {
                return null;
            }

            var keep = Math.Min(value.Length, maxLength - suffix.Length);
            return (value.Substring(0, keep).TrimEnd() + suffix).Trim();
        }

        private static readonly System.Text.RegularExpressions.Regex FieldReferenceInstance = new System.Text.RegularExpressions.Regex(@"(?<relative>\$\d*)?(?:\[(?<names>[A-Za-z_][A-Za-z0-9_.-]*)\])+", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);

        private static readonly System.Text.RegularExpressions.Regex TableReferenceInstance = new System.Text.RegularExpressions.Regex(@"\[([A-Za-z_][A-Za-z0-9_.-]*)\]\[([A-Za-z_][A-Za-z0-9_.-]*)\](?=\s*(?::|$|\)|;))", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);

        private static readonly System.Text.RegularExpressions.Regex NullCheckInstance = new System.Text.RegularExpressions.Regex(@"ISNULL\(\s*\$?\d*(?:\[[^\[\]()]+\])+\s*\)", System.Text.RegularExpressions.RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

    /// <summary>Refilled sample values: the nodes (with their new sample values), the mappings and the solver's sample rows.</summary>
    public sealed class SampleRefill : IRecord<SampleRefill>, IEquatable<SampleRefill>
    {
        public IReadOnlyList<SchemaNodeDto> Nodes { get; set; }

        public IReadOnlyList<MappingEntryDto> Mappings { get; set; }

        public IReadOnlyList<SampleRowDto> SampleRows { get; set; }

        public IReadOnlyList<string> OmittedForms { get; set; }

        public SampleRefill(IReadOnlyList<SchemaNodeDto> Nodes, IReadOnlyList<MappingEntryDto> Mappings, IReadOnlyList<SampleRowDto> SampleRows, IReadOnlyList<string> OmittedForms)
    {
    this.Nodes = Nodes;
    this.Mappings = Mappings;
    this.SampleRows = SampleRows;
    this.OmittedForms = OmittedForms;
    }

        public void Deconstruct(out IReadOnlyList<SchemaNodeDto> Nodes, out IReadOnlyList<MappingEntryDto> Mappings, out IReadOnlyList<SampleRowDto> SampleRows, out IReadOnlyList<string> OmittedForms)
    {
    Nodes = this.Nodes;
    Mappings = this.Mappings;
    SampleRows = this.SampleRows;
    OmittedForms = this.OmittedForms;
    }

        public bool Equals(SampleRefill other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<SchemaNodeDto>>.Default.Equals(Nodes, other.Nodes)
    && EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.Equals(Mappings, other.Mappings)
    && EqualityComparer<IReadOnlyList<SampleRowDto>>.Default.Equals(SampleRows, other.SampleRows)
    && EqualityComparer<IReadOnlyList<string>>.Default.Equals(OmittedForms, other.OmittedForms);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SampleRefill);
    }

        public static bool operator ==(SampleRefill left, SampleRefill right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SampleRefill left, SampleRefill right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 92463;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SchemaNodeDto>>.Default.GetHashCode(Nodes);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.GetHashCode(Mappings);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SampleRowDto>>.Default.GetHashCode(SampleRows);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(OmittedForms);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SampleRefill { " + "Nodes = " + Nodes + ", " + "Mappings = " + Mappings + ", " + "SampleRows = " + SampleRows + ", " + "OmittedForms = " + OmittedForms + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SampleRefill CloneRecord()
    {
    return (SampleRefill)MemberwiseClone();
    }

    }

}
