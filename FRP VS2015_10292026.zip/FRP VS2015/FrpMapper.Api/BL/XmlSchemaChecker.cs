using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Checks an XML file against an XSD the way the Workbench's "Validate an XML File Using XSD" did: every error and
    /// warning with its line and the elements open at that point ("Node Tree"). Neither file may load anything from
    /// elsewhere: DTDs are refused and schemaLocation hints are not followed.
    /// </summary>
    public static class XmlSchemaChecker
    {
        /// <summary>Messages kept in memory; a file with more says so in the last one.</summary>
        public const int MaxIssues = 100000;

        /// <summary>Null when the text is an XSD that compiles; otherwise what is wrong with it.</summary>
        public static string SchemaProblem(string xsd)
        {
            try
            {
                Load(xsd);
                return null;
            }
            catch (Exception ex) when (ex is XmlException || ex is XmlSchemaException)
            {
                return ex.Message;
            }
        }

        public static XmlSchemaSet Load(string xsd)
        {
            var schemas = new XmlSchemaSet { XmlResolver = null };
            using (var reader = XmlReader.Create(new StringReader(xsd), new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null }))
            {
                schemas.Add(null, reader);
            }

            schemas.Compile();
            return schemas;
        }

        /// <summary>Reads the XSD's text, which must be UTF-8 (with or without BOM) or what its declaration says.</summary>
        public static string ReadText(byte[] content)
        {
            using (var reader = new StreamReader(new MemoryStream(content, false), Encoding.UTF8, true))
            {
                return reader.ReadToEnd();
            }
        }

        /// <summary>Every message of the check, in the order they were found.</summary>
        public static List<XmlSchemaIssueDto> Check(Stream xml, XmlSchemaSet schemas)
        {
            var issues = new List<XmlSchemaIssueDto>();
            var open = new List<string>();
            var settings = new XmlReaderSettings
            {
                ValidationType = ValidationType.Schema,
                Schemas = schemas,
                DtdProcessing = DtdProcessing.Prohibit,
                XmlResolver = null
            };
            settings.ValidationFlags |= XmlSchemaValidationFlags.ReportValidationWarnings;
            settings.ValidationEventHandler += (sender, args) => Add(issues, args.Severity == XmlSeverityType.Warning ? "Warning" : "Error", args.Message,
                args.Exception == null ? 0 : args.Exception.LineNumber, args.Exception == null ? 0 : args.Exception.LinePosition, open);

            try
            {
                using (var reader = XmlReader.Create(xml, settings))
                {
                    while (reader.Read())
                    {
                        // The open elements after each node, as the Workbench's trail: an empty element never opens.
                        if (reader.NodeType == XmlNodeType.Element && !reader.IsEmptyElement)
                        {
                            open.Add(reader.Name);
                        }
                        else if (reader.NodeType == XmlNodeType.EndElement && open.Count > 0)
                        {
                            open.RemoveAt(open.Count - 1);
                        }
                    }
                }
            }
            catch (XmlException ex)
            {
                Add(issues, "Error", ex.Message, ex.LineNumber, ex.LinePosition, open);
            }
            catch (XmlSchemaValidationException ex)
            {
                Add(issues, "Error", ex.Message, ex.LineNumber, ex.LinePosition, open);
            }

            return issues;
        }

        private static void Add(List<XmlSchemaIssueDto> issues, string severity, string message, int line, int position, List<string> open)
        {
            if (issues.Count == MaxIssues)
            {
                issues.Add(new XmlSchemaIssueDto { Severity = "Warning", Message = "More than " + MaxIssues.ToString("N0", CultureInfo.InvariantCulture) + " messages: the rest are not listed." });
            }

            if (issues.Count > MaxIssues)
            {
                return;
            }

            issues.Add(new XmlSchemaIssueDto
            {
                Severity = severity,
                Message = message,
                Line = line,
                Position = position,
                Path = string.Concat(open.Select(name => "<" + name + ">"))
            });
        }

        /// <summary>
        /// The messages as a CSV file with the Workbench's columns (Line, Severity, Error Description, Node Tree), for
        /// Excel: UTF-8 with BOM, every value quoted.
        /// </summary>
        public static byte[] Report(IEnumerable<XmlSchemaIssueDto> issues)
        {
            var text = new StringBuilder();
            text.Append("Line,Position,Severity,Error Description,Node Tree\r\n");
            foreach (var issue in issues)
            {
                text.Append(Csv(issue.Line.ToString(CultureInfo.InvariantCulture))).Append(',')
                    .Append(Csv(issue.Position.ToString(CultureInfo.InvariantCulture))).Append(',')
                    .Append(Csv(issue.Severity)).Append(',')
                    .Append(Csv(issue.Message)).Append(',')
                    .Append(Csv(issue.Path)).Append("\r\n");
            }

            var preamble = Encoding.UTF8.GetPreamble();
            var body = Encoding.UTF8.GetBytes(text.ToString());
            return preamble.Concat(body).ToArray();
        }

        /// <summary>A CSV value, quoted; a value Excel would read as a formula is prefixed with an apostrophe.</summary>
        private static string Csv(string value)
        {
            value = value ?? "";
            if (value.Length > 0 && "=+-@".IndexOf(value[0]) >= 0 && !char.IsDigit(value.Length > 1 ? value[1] : 'x'))
            {
                value = "'" + value;
            }

            return "\"" + value.Replace("\"", "\"\"") + "\"";
        }

        /// <summary>The check's result for the page: the first <paramref name="shown"/> messages and the totals.</summary>
        public static XmlSchemaCheckDto Summary(List<XmlSchemaIssueDto> issues, string xsdFileName, int shown)
        {
            return new XmlSchemaCheckDto
            {
                Valid = issues.All(i => i.Severity != "Error"),
                XsdFileName = xsdFileName ?? "",
                Issues = issues.Take(shown).ToList(),
                IssueCount = issues.Count
            };
        }
    }
}
