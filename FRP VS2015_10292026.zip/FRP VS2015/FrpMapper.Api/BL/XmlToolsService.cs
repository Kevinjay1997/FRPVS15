using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using FrpMapper.Api.BL.XmlTools;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// The Workbench's general XML tools for the people who prepare submissions (submission.prepare):
    /// <list type="bullet">
    /// <item>Merge: an existing report XML file → merged, cleaned and (optionally) filtered to one reporting period with
    /// the approved XML tools configuration, then normalized with its XSD and checked against it (see <see cref="XmlMerger"/>
    /// and <see cref="XmlNormalizer"/>);</item>
    /// <item>Validate: any XML file checked against any XSD (see <see cref="XmlSchemaChecker"/>).</item>
    /// </list>
    /// Results are kept a day for the person who ran them; every run is written to the audit trail with the files' SHA-256.
    /// </summary>
    public sealed class XmlToolsService : IXmlToolsService
    {
        private const int IssuesShown = 500;

        private readonly WorkbenchConfigWorkflow workflow;
        private readonly ICocreeOutputStore outputs;
        private readonly ICurrentUser user;
        private readonly IAuditLog audit;
        private readonly IOptionsMonitor<FileStorageOptions> storage;

        public XmlToolsService(IWorkbenchConfigRepository versions, ICocreeOutputStore outputs, ICurrentUser user, IAuditLog audit, IOptionsMonitor<FileStorageOptions> storage)
        {
            workflow = new WorkbenchConfigWorkflow(versions, user, WorkbenchConfigKind.XmlTools, "XML tools configuration");
            this.outputs = outputs;
            this.user = user;
            this.audit = audit;
            this.storage = storage;
        }

        private static WorkflowException Invalid(string message) { return WorkbenchConfigWorkflow.Invalid(message); }

        private void Authorize()
        {
            if (!workflow.Can(Permissions.SubmissionPrepare))
                throw WorkbenchConfigWorkflow.Forbidden("Your role cannot use the XML tools.");
        }

        public async Task<XmlToolsSetupDto> SetupAsync(CancellationToken cancellation)
        {
            Authorize();
            var setup = new XmlToolsSetupDto { ReportPeriods = XmlToolsConfiguration.Periods.ToList(), MaxUploadBytes = storage.CurrentValue.MaxUploadBytes };
            var active = await workflow.ActiveAsync(cancellation);
            var configuration = active == null ? null : Configuration(active);
            if (configuration != null)
            {
                setup.Configured = true;
                setup.Configuration = active.Version;
                setup.MergeRules = configuration.Merge.Count;
                setup.CleanupElements = configuration.Cleanup.ToList();
            }

            return setup;
        }

        private static XmlToolsConfiguration Configuration(StoredWorkbenchConfig stored)
        {
            var problems = new List<string>();
            var configuration = XmlToolsConfiguration.Load(JsonSerializer.Deserialize<XmlToolsConfigDto>(stored.Content), problems);
            if (configuration == null)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, "The approved XML tools configuration cannot be used: " + string.Join(" ", problems.Take(5))
                    + " Ask a Maker to upload a corrected one.");
            }

            return configuration;
        }

        // ---------- merge ----------

        public async Task<XmlMergeResultDto> MergeAsync(XmlMergeRequest request, CancellationToken cancellation, IProgress<ValidationProgressDto> progress = null)
        {
            Authorize();
            Action<int, string> report = (percent, stage) =>
            {
                if (progress != null) progress.Report(new ValidationProgressDto { Percent = percent, Stage = stage });
            };

            RequireFile(request.Xml, ".xml", "XML file");
            var period = (request.ReportPeriod ?? "").Trim();
            if (period.Length > 0 && !XmlToolsConfiguration.Periods.Contains(period))
                throw Invalid("Choose a reporting period from the list, or none.");
            if (request.Xsd != null)
                RequireFile(request.Xsd, ".xsd", "XSD");

            var active = await workflow.ActiveAsync(cancellation);
            if (active == null)
                throw new WorkflowException(WorkflowErrorKind.Conflict, "No XML tools configuration has been approved yet. A Maker uploads merge.csv, cleanup.csv and reportperiod.csv on the Settings tab and a Checker approves them.");
            var configuration = Configuration(active);

            var xmlBytes = Read(request.Xml);
            var schemas = request.Xsd == null ? null : Schemas(Read(request.Xsd));
            var run = outputs.CreateRun(user.Name);
            var result = new XmlMergeResultDto { OutputId = run.Id };
            var baseName = CocreeOutputNames.Safe(Path.GetFileNameWithoutExtension(request.Xml.FileName));
            await Task.Run(() =>
            {
                report(5, "Reading " + request.Xml.FileName);
                var input = LoadXml(xmlBytes, request.Xml.FileName);

                report(30, "Merging the elements");
                XDocument merged;
                try
                {
                    merged = new XmlMerger(configuration).Merge(input, period, result);
                }
                catch (XmlToolsException ex)
                {
                    throw Invalid("The file cannot be merged: " + ex.Message);
                }

                result.OutputFile = baseName + "_EXPORTED_ON_" + DateTime.Now.ToString("yyyyMMdd", CultureInfo.InvariantCulture) + ".xml";
                var mergedBytes = Save(merged);
                Write(run, result.OutputFile, mergedBytes);
                result.Log.Add("Merged file: " + result.OutputFile + " (" + result.Elements.Count + " elements).");

                var final = mergedBytes;
                if (schemas != null && request.Normalize)
                {
                    report(55, "Normalizing with " + request.Xsd.FileName);
                    final = Normalize(mergedBytes, result, run, configuration, schemas);
                }

                if (schemas != null)
                {
                    report(80, "Checking against " + request.Xsd.FileName);
                    result.Schema = Check(final, schemas, request.Xsd.FileName, run, Path.GetFileNameWithoutExtension(result.NormalizedFile ?? result.OutputFile));
                    result.Log.Add(result.Schema.Valid ? "The file passed the XSD check." : result.Schema.IssueCount + " XSD messages.");
                }

                report(100, "Done");
            }, cancellation);

            await audit.AppendAsync(new AuditEntryDto
            {
                Id = Guid.NewGuid().ToString("N"), At = DateTimeOffset.UtcNow, User = user.Name, Action = "XML merged",
                Details = request.Xml.FileName + " (SHA-256 " + WorkbenchConfigWorkflow.Sha256(xmlBytes) + ") with configuration " + active.Version.Id
                    + (period.Length > 0 ? ", period " + period : "") + (request.Xsd != null ? ", XSD " + request.Xsd.FileName : "") + ": "
                    + result.Merged.Count + " merged, " + result.RemovedEmpty.Count + " empty and " + result.OutsidePeriod.Count + " outside the period left out"
                    + (result.NormalizedFile != null ? ", normalized (" + result.NormalizerItemsRemoved + " rows, " + result.NormalizerSectionsRemoved + " sections removed)" : "")
                    + (result.Schema != null ? ", XSD " + (result.Schema.Valid ? "passed" : "failed") : "") + "."
            }, cancellation);
            return result;
        }

        /// <summary>The Workbench reloaded the merged file before normalizing it; so does this, from the saved bytes.</summary>
        private static byte[] Normalize(byte[] merged, XmlMergeResultDto result, CocreeOutputRun run, XmlToolsConfiguration configuration, XmlSchemaSet schemas)
        {
            var document = LoadXml(merged, result.OutputFile);
            var normalizer = new XmlNormalizer(schemas, configuration.NonRemovableItems);
            var log = new List<string>
            {
                "FRP XML NORMALIZER LOG STARTED",
                "Timestamp : " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                "Input File: " + result.OutputFile,
                new string('-', 60)
            };
            normalizer.Normalize(document, log);
            log.Add(new string('-', 60));
            log.Add("SUMMARY");
            log.Add("_Item removed    : " + normalizer.ItemsRemoved);
            log.Add("Sections removed : " + normalizer.SectionsRemoved);
            log.Add(new string('-', 60));
            log.Add("NORMALIZATION COMPLETE");

            var baseName = Path.GetFileNameWithoutExtension(result.OutputFile);
            result.NormalizedFile = baseName + "_NORMALIZED.xml";
            result.NormalizerLog = baseName + "_NORMALIZATION_LOG_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".log";
            result.NormalizerItemsRemoved = normalizer.ItemsRemoved;
            result.NormalizerSectionsRemoved = normalizer.SectionsRemoved;
            var bytes = Save(document);
            Write(run, result.NormalizedFile, bytes);
            Write(run, result.NormalizerLog, new System.Text.UTF8Encoding(true).GetPreamble().Concat(System.Text.Encoding.UTF8.GetBytes(string.Join("\r\n", log) + "\r\n")).ToArray());
            result.Log.Add("Normalized file: " + result.NormalizedFile + " (" + normalizer.ItemsRemoved + " _Item rows and " + normalizer.SectionsRemoved + " sections removed).");
            return bytes;
        }

        // ---------- validate with XSD ----------

        public async Task<XmlValidateResultDto> ValidateAsync(IFormFile xml, IFormFile xsd, CancellationToken cancellation)
        {
            Authorize();
            RequireFile(xml, ".xml", "XML file");
            RequireFile(xsd, ".xsd", "XSD");
            var xmlBytes = Read(xml);
            var xsdBytes = Read(xsd);
            var schemas = Schemas(xsdBytes);
            var run = outputs.CreateRun(user.Name);
            var result = new XmlValidateResultDto { OutputId = run.Id, XmlFileName = xml.FileName, XmlSize = xmlBytes.Length };
            await Task.Run(() =>
            {
                result.Schema = Check(xmlBytes, schemas, xsd.FileName, run, CocreeOutputNames.Safe(Path.GetFileNameWithoutExtension(xml.FileName)));
            }, cancellation);

            await audit.AppendAsync(new AuditEntryDto
            {
                Id = Guid.NewGuid().ToString("N"), At = DateTimeOffset.UtcNow, User = user.Name, Action = "XML checked against XSD",
                Details = xml.FileName + " (SHA-256 " + WorkbenchConfigWorkflow.Sha256(xmlBytes) + ") with " + xsd.FileName + " (SHA-256 " + WorkbenchConfigWorkflow.Sha256(xsdBytes) + "): "
                    + (result.Schema.Valid ? "passed" : "failed") + ", " + result.Schema.IssueCount + " messages."
            }, cancellation);
            return result;
        }

        private static XmlSchemaCheckDto Check(byte[] xml, XmlSchemaSet schemas, string xsdFileName, CocreeOutputRun run, string baseName)
        {
            var issues = XmlSchemaChecker.Check(new MemoryStream(xml, false), schemas);
            var check = XmlSchemaChecker.Summary(issues, xsdFileName, IssuesShown);
            if (issues.Count > 0)
            {
                check.Report = baseName + "_XSD_Validation_Result_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".csv";
                Write(run, check.Report, XmlSchemaChecker.Report(issues));
            }

            return check;
        }

        // ---------- downloads ----------

        public ToolDownload Download(string runId, string fileName)
        {
            Authorize();
            var stream = outputs.Open(runId, fileName, user.Name);
            if (stream == null) return null;
            var type = fileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase) ? "text/csv"
                : fileName.EndsWith(".log", StringComparison.OrdinalIgnoreCase) ? "text/plain" : "application/xml";
            return new ToolDownload(stream, fileName, type);
        }

        // ---------- helpers ----------

        private void RequireFile(IFormFile file, string extension, string description)
        {
            if (file == null)
                throw Invalid("Choose the " + description + ".");
            if (!string.Equals(Path.GetExtension(file.FileName), extension, StringComparison.OrdinalIgnoreCase))
                throw Invalid("The " + description + " must be a " + extension + " file.");
            if (file.Length > storage.CurrentValue.MaxUploadBytes)
                throw Invalid("The " + description + " is larger than " + storage.CurrentValue.MaxUploadMegabytes + " MB.");
        }

        private static XmlSchemaSet Schemas(byte[] xsd)
        {
            try
            {
                return XmlSchemaChecker.Load(XmlSchemaChecker.ReadText(xsd));
            }
            catch (Exception ex) when (ex is XmlException || ex is XmlSchemaException)
            {
                throw Invalid("The XSD cannot be used: " + ex.Message);
            }
        }

        /// <summary>The file with its whitespace, as the Workbench loaded it; DTDs are refused.</summary>
        private static XDocument LoadXml(byte[] content, string fileName)
        {
            try
            {
                using (var stream = new MemoryStream(content, false))
                {
                    return SafeXml.Load(stream, LoadOptions.PreserveWhitespace);
                }
            }
            catch (XmlException ex)
            {
                throw Invalid(fileName + " is not readable XML: " + ex.Message);
            }
        }

        /// <summary>Saved as the Workbench's XDocument.Save did: indented, in the declaration's encoding (UTF-8 with BOM).</summary>
        private static byte[] Save(XDocument document)
        {
            using (var stream = new MemoryStream())
            {
                document.Save(stream);
                return stream.ToArray();
            }
        }

        private static void Write(CocreeOutputRun run, string name, byte[] content)
        {
            using (var stream = run.Create(name))
            {
                stream.Write(content, 0, content.Length);
            }
        }

        private static byte[] Read(IFormFile file)
        {
            using (var stream = file.OpenReadStream())
            using (var copy = new MemoryStream())
            {
                stream.CopyTo(copy);
                return copy.ToArray();
            }
        }
    }
}
