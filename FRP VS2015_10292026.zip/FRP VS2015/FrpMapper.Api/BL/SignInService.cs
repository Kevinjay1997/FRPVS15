﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Sign-in rules of the Application Security Checklist, applied for the Platform's sign-in page:
    /// <list type="bullet">
    /// <item>After SignIn:MaxFailedAttempts (3) failed sign-ins in a row the account is locked until SRAU re-enables it; an
    /// administrator account (SRAU or PARAM) is instead delayed SignIn:AdministratorDelayMinutes (5).</item>
    /// <item>An account without a sign-in for SignIn:InactiveDays (30) is deactivated until SRAU re-enables it.</item>
    /// <item>The person sees their previous sign-in and the failed attempts since.</item>
    /// <item>Only the newest session of an account may be used: signing in again ends the earlier one.</item>
    /// </list>
    /// Every attempt, lockout, delay, deactivation and refusal is written to the audit trail (never the password).
    /// </summary>
    public sealed partial class SignInService: ISignInService
    {
        private readonly ISignInRepository repository;
        private readonly IAccessService access;
        private readonly IAuditLog auditLog;
        private readonly IOptions<SignInOptions> options;
        private readonly TimeProvider clock;

        public SignInService(ISignInRepository repository, IAccessService access, IAuditLog auditLog, IOptions<SignInOptions> options, TimeProvider clock)
    {
        this.repository = repository;
        this.access = access;
        this.auditLog = auditLog;
        this.options = options;
        this.clock = clock;
    }
        public const string SignInBlockedAction = "Sign-in blocked";

        public async Task<SignInCheckResultDto> CheckAsync(SignInCheckDto check, CancellationToken cancellationToken) =>
            new SignInCheckResultDto() { DelayedUntil = await repository.GetDelayedUntilAsync(Name(check.UserName), clock.GetUtcNow(), cancellationToken) };

        public Task<string> RecordFailureAsync(SignInFailedDto failure, CancellationToken cancellationToken)
        {
            var settings = options.Value;
            return repository.RecordFailureAsync(Name(failure.UserName), clock.GetUtcNow(), Detail(failure.Detail), failure.CountsTowardLockout,
                settings.MaxFailedAttempts, settings.AdministratorDelayMinutes, cancellationToken);
        }

        public Task RecordBlockedAsync(SignInFailedDto blocked, CancellationToken cancellationToken) =>
            auditLog.AppendAsync(new AuditEntryDto
            {
                Id = Guid.NewGuid().ToString("N"),
                At = clock.GetUtcNow(),
                User = Name(blocked.UserName),
                Action = SignInBlockedAction,
                Details = Detail(blocked.Detail)
            }, cancellationToken);

        public async Task<SignInResultDto> RecordSuccessAsync(SignInSucceededDto success, CancellationToken cancellationToken)
        {
            var name = Name(success.UserName);
            var sessionId = SessionId(success.SessionId);
            // The roles this sign-in gives: those of the account's AD groups (or the test user's), plus those SRAU gave in
            // the app. The administrator flag decides between a lockout and a delay after failed sign-ins.
            var catalog = await access.GetCatalogAsync(cancellationToken);
            var groups = (success.DirectoryGroups ?? new List<string>()).Select(g => (g ?? "").Trim()).Where(g => g.Length > 0).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var fromGroups = catalog.Roles.Where(r => r.DirectoryGroups.Any(groups.Contains)).Select(r => r.Key);
            string conflict;
            bool disabled;
            var roles = AccessRules.Resolve(catalog, name, fromGroups.Concat(success.Roles ?? new List<string>()), out conflict, out disabled);
            var isAdministrator = catalog.PermissionsOf(roles).Any(Permissions.Administration.Contains);
            var roleList = string.Join(", ", roles.Order(StringComparer.OrdinalIgnoreCase));
            return await repository.RecordSuccessAsync(name, clock.GetUtcNow(), Detail(success.Detail), isAdministrator,
                roleList.Length > 1000 ? roleList.Substring(0, 1000) : roleList, sessionId, options.Value.InactiveDays, cancellationToken);
        }

        public async Task<SessionCheckResultDto> CheckSessionAsync(SessionCheckDto session, CancellationToken cancellationToken)
        {
            var current = await repository.GetSessionAsync(Name(session.UserName), cancellationToken);
            return new SessionCheckResultDto { Current = current != null && string.Equals(current, SessionId(session.SessionId), StringComparison.Ordinal) };
        }

        public Task EndSessionAsync(SessionEndDto session, CancellationToken cancellationToken) =>
            repository.EndSessionAsync(Name(session.UserName), SessionId(session.SessionId), clock.GetUtcNow(),
                session.Idle ? "Signed out after the idle timeout." : "Signed out.", cancellationToken);

        private static string Name(string userName)
        {
            var name = (userName ?? "").Trim();
            return name.Length == 0 || name.Length > 256 || name.Any(char.IsControl)
                ? CompatThrow.As<string>(new WorkflowException(WorkflowErrorKind.Invalid, "The user name is missing or too long."))
                : name;
        }

        private static string SessionId(string sessionId) =>
            sessionId != null && object.Equals(sessionId.Length, 32) && SessionIdRegex().IsMatch(sessionId)
                ? sessionId
                : CompatThrow.As<string>(new WorkflowException(WorkflowErrorKind.Invalid, "The session id is not valid."));

        private static string Detail(string detail)
        {
            var text = detail?.Trim();
            return string.IsNullOrEmpty(text) ? null : text.Length > 500 ? text.Substring(0, 500) : text;
        }

        private static System.Text.RegularExpressions.Regex SessionIdRegex() { return SessionIdRegexInstance; }

        private static readonly System.Text.RegularExpressions.Regex SessionIdRegexInstance = new System.Text.RegularExpressions.Regex("^[0-9a-f]{32}$", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

}
