using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// The rules of a BSP environment (Sandbox, Production, …): what a Maker may propose, what a Checker may approve and
    /// what a request may be sent to. The base URL is HTTPS on port 443, on a host the API's Bsp:AllowedHosts lists, with a
    /// plain path; each operation's path is a plain relative path, the follow-up ones with {submissionId} exactly once.
    /// No query, fragment, user name, port, "." or ".." can be written, so a URL can never leave the allowed host.
    /// </summary>
    public static class BspEndpointRules
    {
        public const string SubmissionIdToken = "{submissionId}";
        public const int MaxBaseUrlLength = 300;
        public const int MaxPathLength = 200;

        private static readonly Regex Key = new Regex(@"\A[A-Z][A-Z0-9_]{1,31}\z", RegexOptions.CultureInvariant);
        private static readonly Regex Host = new Regex(@"\A(?=.{1,253}\z)[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*\z", RegexOptions.CultureInvariant);
        private static readonly Regex BaseUrl = new Regex(@"\Ahttps://([A-Za-z0-9.-]+)((?:/[A-Za-z0-9_-][A-Za-z0-9_.-]*)*)/?\z", RegexOptions.CultureInvariant);
        private static readonly Regex Path = new Regex(@"\A(?:[A-Za-z0-9_-][A-Za-z0-9_.-]*|\{submissionId\})(?:/(?:[A-Za-z0-9_-][A-Za-z0-9_.-]*|\{submissionId\}))*\z", RegexOptions.CultureInvariant);

        /// <summary>The operations of the Report API, in the order the settings show them.</summary>
        public static readonly IReadOnlyList<string> Operations = new[] { "submit", "status", "pdf", "xml", "excel", "receipt" };

        public static bool IsHostName(string value)
        {
            return value != null && Host.IsMatch(value);
        }

        private static WorkflowException Invalid(string message)
        {
            return new WorkflowException(WorkflowErrorKind.Invalid, message);
        }

        /// <summary>The path an operation uses in an environment, or null for an unknown operation.</summary>
        public static string PathOf(SubmissionEnvironmentDto environment, string operation)
        {
            switch (operation)
            {
                case "submit": return environment.SubmitPath;
                case "status": return environment.StatusPath;
                case "pdf": return environment.ResultPdfPath;
                case "xml": return environment.ResultXmlPath;
                case "excel": return environment.ResultExcelPath;
                case "receipt": return environment.ReceiptPath;
                default: return null;
            }
        }

        /// <summary>
        /// Checks a Maker's proposal and returns it normalized (key in upper case, trimmed, base URL ending with "/", paths
        /// without a leading "/"). Throws <see cref="WorkflowException"/> (Invalid) with what to correct.
        /// </summary>
        public static SubmissionEnvironmentDto Normalize(SubmissionEnvironmentRequest request, IReadOnlyList<string> allowedHosts)
        {
            if (request == null) throw Invalid("Fill in the environment.");
            var key = (request.Key ?? "").Trim().ToUpperInvariant();
            if (!Key.IsMatch(key))
                throw Invalid("The key is 2 to 32 letters, digits or underscores, starting with a letter (for example SANDBOX or PRODUCTION).");
            var name = (request.Name ?? "").Trim();
            if (name.Length == 0 || name.Length > 100 || name.Any(char.IsControl))
                throw Invalid("The name is 1 to 100 characters (for example BSP sandbox).");
            var kind = (request.Kind ?? "").Trim();
            if (kind != SubmissionEnvironmentKind.Test && kind != SubmissionEnvironmentKind.Production)
                throw Invalid("Choose whether the environment is for tests or production.");
            if (request.SortOrder < 0 || request.SortOrder > 999)
                throw Invalid("The order is a whole number from 0 to 999.");

            var environment = new SubmissionEnvironmentDto
            {
                Key = key, Name = name, Kind = kind, SortOrder = request.SortOrder,
                BaseUrl = NormalizeBaseUrl(request.BaseUrl, allowedHosts),
                SubmitPath = NormalizePath(request.SubmitPath, "Submit report", false),
                StatusPath = NormalizePath(request.StatusPath, "Status", true),
                ResultPdfPath = NormalizePath(request.ResultPdfPath, "Validation result (PDF)", true),
                ResultXmlPath = NormalizePath(request.ResultXmlPath, "Validation result (XML)", true),
                ResultExcelPath = NormalizePath(request.ResultExcelPath, "Excel visualization", true),
                ReceiptPath = NormalizePath(request.ReceiptPath, "Submission receipt", true)
            };
            var follow = new[] { environment.StatusPath, environment.ResultPdfPath, environment.ResultXmlPath, environment.ResultExcelPath, environment.ReceiptPath };
            if (follow.Distinct(StringComparer.Ordinal).Count() != follow.Length)
                throw Invalid("Each follow-up operation needs its own path.");
            return environment;
        }

        /// <summary>https://host/path/ with the host lower case; refused when the host is not allowed.</summary>
        public static string NormalizeBaseUrl(string value, IReadOnlyList<string> allowedHosts)
        {
            var text = (value ?? "").Trim();
            var match = BaseUrl.Match(text);
            if (text.Length > MaxBaseUrlLength || !match.Success)
                throw Invalid("The base URL is https:// followed by the host and a plain path, for example https://rapi.bsp.gov.ph/api/sandbox/submission/"
                    + " (no port, user name, query or fragment).");
            var host = match.Groups[1].Value.ToLowerInvariant();
            if (!IsHostName(host))
                throw Invalid("The base URL's host is not a valid host name.");
            if (!IsAllowedHost(host, allowedHosts))
                throw Invalid("The host " + host + " is not allowed on this server. Allowed: " + string.Join(", ", allowedHosts)
                    + ". IT adds hosts to Bsp:AllowedHosts in FrpMapper.Api's configuration.");
            return "https://" + host + match.Groups[2].Value + "/";
        }

        /// <summary>A relative path; follow-up paths contain {submissionId} exactly once, the submit path not at all.</summary>
        public static string NormalizePath(string value, string label, bool needsSubmissionId)
        {
            var text = (value ?? "").Trim().TrimStart('/');
            if (text.Length == 0 || text.Length > MaxPathLength || !Path.IsMatch(text))
                throw Invalid(label + ": write a path relative to the base URL, made of letters, digits, '-', '_' and '.', with '/' between the parts"
                    + (needsSubmissionId ? " and " + SubmissionIdToken + " where the submission ID goes (for example {submissionId}/status)." : " (for example submitReport)."));
            var tokens = (text.Length - text.Replace(SubmissionIdToken, "").Length) / SubmissionIdToken.Length;
            if (needsSubmissionId && tokens != 1)
                throw Invalid(label + ": the path must contain " + SubmissionIdToken + " exactly once.");
            if (!needsSubmissionId && tokens != 0)
                throw Invalid(label + ": the submit path cannot contain " + SubmissionIdToken + ".");
            return text;
        }

        public static bool IsAllowedHost(string host, IReadOnlyList<string> allowedHosts)
        {
            return host != null && allowedHosts != null && allowedHosts.Contains(host.ToLowerInvariant(), StringComparer.Ordinal);
        }

        /// <summary>
        /// The URL of one operation in an environment, checked again against the current rules (an approved environment
        /// whose host was later removed from Bsp:AllowedHosts can no longer be used).
        /// </summary>
        public static Uri Url(SubmissionEnvironmentDto environment, string operation, string submissionId, IReadOnlyList<string> allowedHosts)
        {
            var baseUrl = NormalizeBaseUrl(environment.BaseUrl, allowedHosts);
            var path = PathOf(environment, operation);
            if (path == null) throw Invalid("Unknown BSP operation.");
            path = NormalizePath(path, operation, operation != "submit");
            if (operation != "submit")
            {
                Guid id;
                if (!Guid.TryParseExact(submissionId ?? "", "D", out id)) throw Invalid("Enter the submission ID returned by BSP.");
                path = path.Replace(SubmissionIdToken, id.ToString("D"));
            }

            return new Uri(baseUrl + path, UriKind.Absolute);
        }
    }
}
