﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;
using FrpMapper.Shared.Validation;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Validates a project's mappings and values against its XSD:
    /// 1. Mapping checks (unknown paths, duplicate cells, required elements without a mapping).
    /// 2. Value checks per mapped cell using the XSD facets (type, enumeration, pattern, range, digits, length).
    /// 3. Full schema validation of the generated submission XML with <see cref="XmlSchemaSet"/>.
    /// </summary>
    public sealed class XsdProjectValidator
    {
        private readonly XmlSubmissionWriter xmlWriter;
        private readonly BspSpecificationValidator specificationValidator;

        public XsdProjectValidator(XmlSubmissionWriter xmlWriter, BspSpecificationValidator specificationValidator)
    {
        this.xmlWriter = xmlWriter;
        this.specificationValidator = specificationValidator;
    }
        private const int MaxSchemaIssues = 500;

        /// <param name="rules">Reports the BSP specification rules as they are checked (optional).</param>
        public ProjectValidationResultDto Validate(FrpProjectDto project, ValidationStep rules = null)
        {
            var issues = new List<ValidationIssueDto>();
            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var mappings = project.Mappings;
            var mappingByPath = mappings
                .GroupBy(m => m.SchemaPath, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);

            // 1. Mapping checks
            foreach (var duplicate in mappings
                         .Where(m => !string.IsNullOrWhiteSpace(m.SheetName) && !string.IsNullOrWhiteSpace(m.CellAddress))
                         .GroupBy(m => $"{m.SheetName}!{m.CellAddress}", StringComparer.OrdinalIgnoreCase)
                         .Where(g => g.Count() > 1))
            {
                foreach (var mapping in duplicate.Skip(1))
                {
                    issues.Add(Issue("Error", "Mapping", $"Cell {duplicate.Key} is mapped to more than one XSD element.", mapping));
                }
            }

            foreach (var duplicate in mappings.GroupBy(m => m.SchemaPath, StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1))
            {
                foreach (var mapping in duplicate.Skip(1))
                {
                    issues.Add(Issue("Error", "Mapping", "This XSD element is mapped to more than one cell.", mapping));
                }
            }

            foreach (var mapping in mappings.Where(m => !nodesByPath.ContainsKey(m.SchemaPath)))
            {
                issues.Add(Issue("Error", "Mapping", "The XSD does not contain this element path.", mapping));
            }

            foreach (var node in project.SchemaNodes.Where(n => n.DataType != "complex" && n.IsRequired && !mappingByPath.ContainsKey(n.Path)))
            {
                issues.Add(new ValidationIssueDto
                {
                    Severity = "Warning",
                    Category = "Mapping",
                    Message = "Required XSD element is not mapped to a cell; the generated test value is used in the XML.",
                    SchemaPath = node.Path
                });
            }

            // 2. Value checks
            var checkedValues = 0;
            foreach (var mapping in mappings)
            {
                SchemaNodeDto node;
                if (!nodesByPath.TryGetValue(mapping.SchemaPath, out node) || node.DataType == "complex")
                {
                    continue;
                }

                checkedValues++;
                if (XmlSubmissionWriter.IsCleared(mapping))
                {
                    // The sample value was removed and nothing entered yet.
                    if (node.IsRequired)
                    {
                        issues.Add(Issue("Error", "Value", "Required, but it has no value yet.", mapping));
                    }

                    continue;
                }

                var value = string.IsNullOrWhiteSpace(mapping.DefaultValue) ? node.TestValue : mapping.DefaultValue;
                foreach (var error in XsdValueValidator.Validate(value, node))
                {
                    issues.Add(Issue("Error", "Value", error, mapping));
                }
            }

            // 3. Full XSD validation of the generated document
            XDocument document = null;
            try
            {
                document = xmlWriter.BuildDocument(project);
            }
            catch (InvalidOperationException ex)
            {
                issues.Add(new ValidationIssueDto { Severity = "Error", Category = "Schema", Message = ex.Message });
            }

            if (document != null)
            {
                issues.AddRange(ValidateDocument(project, document, mappingByPath));
            }

            // Excel limitation: a list inside another list cannot be bound in an Excel XML map. A form whose item fills its
            // own sheet is bound with one item (SheetSplitRules.ExcelItemForms); other such lists stay plain input cells.
            var excelItems = SheetSplitRules.ExcelItemForms(project).Select(f => f.GroupPath).ToList();
            Func<string, bool> InExcelItem = null;
            InExcelItem = (string path) =>
            {
                return excelItems.Any(g => path == g || path.StartsWith(g + "/", StringComparison.Ordinal));
            };
            var unmappable = OpenXmlMappedTemplateWriter.UnmappableListGroups(project).Where(p => !InExcelItem(p)).ToList();
            if (unmappable.Count > 0)
            {
                var sheets = unmappable
                    .Select(p => p.Split('/', StringSplitOptions.RemoveEmptyEntries))
                    .Where(t => t.Length >= 2)
                    .Select(t => t[1])
                    .Distinct(StringComparer.OrdinalIgnoreCase)
                    .ToList();
                issues.Add(new ValidationIssueDto
                {
                    Severity = "Info",
                    Category = "Mapping",
                    Message = $"Excel cannot bind a list inside another list, so the mapped template keeps {string.Join(", ", sheets)} as plain input cells. "
                        + "Excel's own 'Export XML' leaves these sheets out; the app's 'Submission XML' export includes them."
                });
            }

            var unsplitItems = SheetSplitRules.ExcelItemForms(project)
                .Where(f => f.NestedLists.Count > 0 && !SheetSplitRules.Resolve(project).Any(s => s.Form.GroupPath == f.GroupPath))
                .Select(f => SheetSplitRules.FormName(f.GroupPath))
                .ToList();
            if (unsplitItems.Count > 0)
            {
                issues.Add(new ValidationIssueDto
                {
                    Severity = "Info",
                    Category = "Mapping",
                    Message = $"{string.Join(", ", unsplitItems)}: Excel cannot export a list inside another list, so its XML map holds one item of "
                        + (unsplitItems.Count == 1 ? "this form" : "each of these forms")
                        + " (e.g. one currency) and Excel's own 'Export XML' writes that one item under the XSD's names. For more items, use "
                        + "the Sheet copies tab and upload the filled template to the app."
                });
            }

            // Forms entered on one sheet per key value (sheet copies), and copies that no longer match the mappings.
            var splitProblems = new List<string>();
            var clonedGroups = SheetCopyMap.BoundGroups(project);
            foreach (var split in SheetSplitRules.Resolve(project, splitProblems))
            {
                var form = SheetSplitRules.FormName(split.Form.GroupPath);
                var excel = !InExcelItem(split.Form.GroupPath)
                    ? "Excel's own 'Export XML' leaves this form out."
                    : split.Sheets.Count == 1
                        ? $"Excel's own 'Export XML' writes it from the sheet {split.Sheets[0].SheetName}."
                        : clonedGroups.Contains(split.Form.GroupPath)
                            ? $"Every sheet is mapped in Excel's XML map: {split.Sheets[0].SheetName} as {form}, the other {split.Sheets.Count - 1} as "
                              + $"{form}_{{value}} (e.g. {form}_{split.Sheets[1].Value}), because Excel maps an element only once. Those extra elements are not in "
                              + "BSP's XSD: run an XML exported by Excel through 'Download the merged XML' (Validate page, after 'Validate an XML file') before it goes to BSP, "
                              + "or upload the filled template to the app."
                            : $"Excel's own 'Export XML' can write only one item of {form}: it writes the first sheet, {split.Sheets[0].SheetName} "
                              + "(a key value gives an element name the XSD already uses, so the other sheets are not mapped). "
                              + $"The other {split.Sheets.Count - 1} sheet(s) reach the XML only when the filled template is uploaded to the app.";
                issues.Add(new ValidationIssueDto
                {
                    Severity = split.Sheets.Count > 1 ? "Warning" : "Info",
                    Category = "Mapping",
                    SchemaPath = split.Form.GroupPath,
                    SheetName = split.Form.SheetName,
                    Message = $"{form} is entered on one sheet per {split.Key.SchemaPath.Split('/').Last()} "
                        + $"({split.Sheets.Count} sheets: {string.Join(", ", split.Sheets.Take(4).Select(s => s.SheetName))}{(split.Sheets.Count > 4 ? ", …" : "")}). "
                        + "The app reads every sheet when it builds the XML from a filled template. " + excel
                });
            }

            issues.AddRange(splitProblems.Select(problem => new ValidationIssueDto { Severity = "Warning", Category = "Mapping", Message = problem }));

            // 4. BSP specification: input fields and assertions
            var specification = (document == null)
                ? SpecificationCheckResult.NotChecked
                : specificationValidator.CheckProject(project, document, mappingByPath, rules);
            issues.AddRange(specification.Issues);

            var sheetGroups = project.SchemaNodes
                .Where(n => n.DataType != "complex")
                .Select(n => new VT_Node_Tokens<SchemaNodeDto, string[]>(n, n.Path.Split('/', StringSplitOptions.RemoveEmptyEntries)))
                .Where(x => x.Tokens.Length >= 3)
                .GroupBy(x => x.Tokens[1], StringComparer.OrdinalIgnoreCase)
                .ToList();

            return new ProjectValidationResultDto
            {
                IsValid = issues.All(i => i.Severity != "Error"),
                ErrorCount = issues.Count(i => i.Severity == "Error"),
                WarningCount = issues.Count(i => i.Severity == "Warning"),
                CheckedValues = checkedValues,
                TotalSheets = sheetGroups.Count,
                MappedSheets = sheetGroups.Count(g => g.All(x => mappingByPath.ContainsKey(x.Node.Path))),
                SpecificationChecked = specification.Checked,
                SpecInputFieldsConfirmed = specification.InputFieldsConfirmed,
                SpecRulesPassed = specification.RulesPassed,
                SpecRulesFailed = specification.RulesFailed,
                SpecRulesNotApplicable = specification.RulesNotApplicable,
                SpecRulesNotEvaluated = specification.RulesNotEvaluated,
                Issues = issues
            };
        }

        private static IEnumerable<ValidationIssueDto> ValidateDocument(FrpProjectDto project, XDocument generated, IReadOnlyDictionary<string, MappingEntryDto> mappingByPath)
        {
            var issues = new List<ValidationIssueDto>();
            if (project.XsdFile == null || !File.Exists(project.XsdFile.StoredPath))
            {
                issues.Add(new ValidationIssueDto { Severity = "Warning", Category = "Schema", Message = "The stored XSD file is missing, so full schema validation was skipped." });
                return issues;
            }

            XmlSchemaSet schemas;
            try
            {
                schemas = LoadSchemas(project.XsdFile.StoredPath);
            }
            catch (Exception ex) when ((ex is XmlException || ex is XmlSchemaException))
            {
                issues.Add(new ValidationIssueDto { Severity = "Error", Category = "Schema", Message = $"The XSD could not be compiled: {ex.Message}" });
                return issues;
            }

            // Validate a copy: XDocument.Validate can annotate the tree.
            var document = new XDocument(generated);
            var seen = new HashSet<string>(StringComparer.Ordinal);
            var truncated = false;
            document.Validate(schemas, (sender, args) =>
            {
                if (issues.Count >= MaxSchemaIssues)
                {
                    truncated = true;
                    return;
                }

                XAttribute attribute__2;
                XElement element__1;
                var path = CompatPattern.Is(sender, out element__1) ? ElementPath(element__1) : CompatPattern.Is(sender, out attribute__2) && attribute__2.Parent != null ? ElementPath(attribute__2.Parent) : ((string)null);
                var key = $"{path}|{args.Message}";
                if (!seen.Add(key))
                {
                    return;
                }

                MappingEntryDto mapping = null;
                if (path != null)
                {
                    mappingByPath.TryGetValue(path, out mapping);
                }

                issues.Add(new ValidationIssueDto
                {
                    Severity = args.Severity == XmlSeverityType.Error ? "Error" : "Warning",
                    Category = "Schema",
                    Message = $"XSD validation: {args.Message}",
                    SchemaPath = path,
                    SheetName = mapping?.SheetName,
                    CellAddress = mapping?.CellAddress
                });
            });

            if (truncated)
            {
                issues.Add(new ValidationIssueDto
                {
                    Severity = "Warning",
                    Category = "Schema",
                    Message = $"Only the first {MaxSchemaIssues} XSD validation messages are shown."
                });
            }

            return issues;
        }

        private static XmlSchemaSet LoadSchemas(string xsdPath)
        {
            var settings = new XmlReaderSettings
            {
                DtdProcessing = DtdProcessing.Prohibit,
                XmlResolver = null
            };
            var schemas = new XmlSchemaSet { XmlResolver = null };
            using (var reader = XmlReader.Create(xsdPath, settings))
            {
            schemas.Add(null, reader);
            schemas.Compile();
            return schemas;
            }
        }

        private static string ElementPath(XElement element)
        {
            return "/" + string.Join("/", element.AncestorsAndSelf().Reverse().Select(e => e.Name.LocalName));
        }

        private static ValidationIssueDto Issue(string severity, string category, string message, MappingEntryDto mapping)
        {
            return new ValidationIssueDto
            {
                Severity = severity,
                Category = category,
                Message = message,
                SchemaPath = mapping.SchemaPath,
                SheetName = mapping.SheetName,
                CellAddress = mapping.CellAddress
            };
        }
    }

}
