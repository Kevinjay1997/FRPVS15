﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Reads the values a Maker typed into an Excel input template and builds the submission XML from them, the way
    /// Excel's XML export does: the workbook's XML map says which cell (or XML list-table column) holds which XSD
    /// element. Without an XML map, the project's mappings (sheet and cell per field) are used. Only what is in the
    /// workbook is written: blank cells stay blank (no sample values are filled in), and a required field that is blank
    /// is reported with its cell.
    /// </summary>
    public sealed class FilledTemplateReader
    {
        private static readonly XNamespace Main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private static readonly XNamespace PackageRel = "http://schemas.openxmlformats.org/package/2006/relationships";
        private const int MaxProblems = 500;

        /// <param name="step">Progress while the sheets are read (optional).</param>
        public FilledTemplate Read(FrpProjectDto project, byte[] workbookBytes, ValidationStep step = null)
        {
            if (string.IsNullOrWhiteSpace(project.RootElement) || project.SchemaNodes.Count == 0)
            {
                return FilledTemplate.Unreadable("The project has no XSD structure to build the XML from.");
            }

            ZipArchive archive;
            try
            {
                archive = new ZipArchive(new MemoryStream(workbookBytes), ZipArchiveMode.Read);
            }
            catch (InvalidDataException)
            {
                return FilledTemplate.Unreadable("The file is not an Excel .xlsx workbook.");
            }

            using (archive)
            {
                try
                {
                    return ReadArchive(project, archive, step);
                }
                catch (Exception ex) when ((ex is XmlException || ex is InvalidDataException))
                {
                    return FilledTemplate.Unreadable($"The workbook contains an unreadable part: {ex.Message}");
                }
            }
        }

        private static FilledTemplate ReadArchive(FrpProjectDto project, ZipArchive archive, ValidationStep step)
        {
            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.Ordinal)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.Ordinal);
            var problems = new List<XsdValidationMessageDto>();
            bool usedXmlMap;
            var bindings = ReadBindings(project, archive, problems, out usedXmlMap);
            if (bindings == null)
            {
                return new FilledTemplate(null, problems, new Dictionary<string, string>(), new Dictionary<string, string>(), 0, usedXmlMap);
            }

            // Forms the app reads from their sheets itself (split into one sheet per key value, or holding a list inside
            // their item, which Excel cannot bind): every sheet is one item. Any binding of theirs is ignored.
            var forms = SheetSplitRules.AppReadForms(project);
            var splits = SheetSplitRules.Resolve(project).ToDictionary(s => s.Form.GroupPath, StringComparer.Ordinal);
            if (forms.Count > 0)
            {
                // (Split forms' copies are also bound in Excel through clone elements, e.g. CAR_Part_IV_4c_PHP.)
                bindings = WithoutGroups(bindings, forms.Select(f => f.GroupPath + "/").Concat(SheetCopyMap.Copies(project).Select(c => c.ClonePath + "/")).ToList());
            }

            var workbookSheets = TemplateCoverageChecker.Sheets(archive);
            var workbookSheetNames = workbookSheets.Select(s => s.Name).ToList();
            var formSheets = new List<VT_Form_Sheet_KeyValue<SheetSplitRules.FormLayout, string, string>>();
            foreach (var form in forms)
            {
                SheetSplitRules.ResolvedSplit split;
                var wanted = splits.TryGetValue(form.GroupPath, out split)
                    ? split.Sheets.Select(s => new VT_SheetName_Value<string, string>(s.SheetName, (string)s.Value)).ToList()
                    : new List<VT_SheetName_Value<string, string>> { new VT_SheetName_Value<string, string>(form.SheetName, (string)null) };
                // A template downloaded before part names (CAR_Part_V_2a…) has its copies as "Base (value)": read those too.
                var present = new List<VT_SheetName_Value<string, string>>();
                foreach (var w in wanted)
                {
                    var legacy = (w.Value == null) ? null : SheetSplitNames.WithSuffix(form.SheetName, w.Value);
                    if (workbookSheetNames.Contains(w.SheetName, StringComparer.OrdinalIgnoreCase))
                    {
                        present.Add(w);
                    }
                    else if (legacy != null && legacy != w.SheetName && workbookSheetNames.Contains(legacy, StringComparer.OrdinalIgnoreCase))
                    {
                        present.Add(new VT_SheetName_Value<string, string>(legacy, w.Value));
                    }
                }

                // The form's other sheets are items too: a copy of the sheet made in Excel ("CAR_Part_IV_4c (2)", "… (EUR)"), or
                // the single sheet of a template downloaded before the form was split. Each says its key (Currency) in its own
                // cell, so a person can add an item (another currency) by copying the sheet.
                var formName = SheetSplitRules.FormName(form.GroupPath);
                var extra = workbookSheetNames
                    .Where(n => (string.Equals(n, form.SheetName, StringComparison.OrdinalIgnoreCase) || SheetSplitNames.IsCopyOf(n, form.SheetName))
                        && !present.Any(p => string.Equals(p.SheetName, n, StringComparison.OrdinalIgnoreCase)))
                    .ToList();
                if (split != null && present.Count > 0)
                {
                    extra.RemoveAll(n => string.Equals(n, form.SheetName, StringComparison.OrdinalIgnoreCase));
                }

                present.AddRange(extra.Select(n => new VT_SheetName_Value<string, string>(n, (string)null)));
                if (split != null)
                {
                    foreach (var missing in wanted.Where(w => !present.Any(p => p.Value == w.Value)))
                    {
                        problems.Add(new XsdValidationMessageDto
                        {
                            Severity = "Warning",
                            Message = $"The sheet {missing.SheetName} is not in this workbook, so {formName} has no {missing.Value} item in the XML.",
                            SchemaPath = form.GroupPath
                        });
                    }
                }

                foreach (var entry in present)
                {
                    var sheet = entry.SheetName;
                    var keyValue = entry.Value;
                    formSheets.Add(new VT_Form_Sheet_KeyValue<SheetSplitRules.FormLayout, string, string>(form, workbookSheets.First(s => string.Equals(s.Name, sheet, StringComparison.OrdinalIgnoreCase)).Name, keyValue));
                }
            }

            step?.Start("Reading the workbook's text");
            var sharedStrings = ReadSharedStrings(archive);
            var cellsBySheet = new Dictionary<string, Dictionary<string, RawCell>>(StringComparer.Ordinal);
            var boundSheets = bindings.Singles.Select(s => s.Sheet).Concat(bindings.Tables.Select(t => t.Sheet)).Concat(formSheets.Select(f => f.Sheet))
                .ToHashSet(StringComparer.Ordinal);
            var sheetsToRead = workbookSheets.Where(s => boundSheets.Contains(s.Name)).ToList();
            for (var index = 0; index < sheetsToRead.Count; index++)
            {
                var parts = sheetsToRead[index];
                var sheetName = parts.Name;
                var worksheetPath = parts.WorksheetPath;
                step?.Report(index, sheetsToRead.Count, $"Sheet {sheetName} ({index + 1:N0} of {sheetsToRead.Count:N0})");
                cellsBySheet[sheetName] = ReadCells(archive, worksheetPath, sharedStrings);
            }

            step?.Done($"{sheetsToRead.Count:N0} sheets read");
            Func<string, string, RawCell> CellAt = null;
            CellAt = (string sheetArg, string addressArg) =>
            {
                Dictionary<string, RawCell> cells;
                RawCell cell;
                return cellsBySheet.TryGetValue(sheetArg, out cells) && cells.TryGetValue(addressArg, out cell) ? cell : null;
            };
            Action<string, string, string, string> Problem = null;
            Problem = (string severity, string message, string cellArg, string schemaPath) =>
            {
                if (problems.Count < MaxProblems)
                {
                    problems.Add(new XsdValidationMessageDto { Severity = severity, Message = message, Cell = cellArg, SchemaPath = schemaPath });
                }
            };

            // Single cells: one value per field.
            var single = new Scope();
            var cellByPath = new Dictionary<string, string>(StringComparer.Ordinal);
            var valuesRead = 0;
            foreach (var binding in bindings.Singles)
            {
                SchemaNodeDto node;
                if (!nodesByPath.TryGetValue(binding.Path, out node) || node.DataType == "complex")
                {
                    continue; // reported by the template check; nothing to read
                }

                var where = $"{binding.Sheet}!{binding.Address}";
                cellByPath.TryAdd(binding.Path, where);
                single.Cells.TryAdd(binding.Path, where);
                var raw = CellAt(binding.Sheet, binding.Address);
                if (raw == null)
                {
                    continue;
                }

                string error;
                var value = ToXmlValue(node, raw, out error);
                if (error != null)
                {
                    Problem("Error", $"{node.Name}: {error}", where, node.Path);
                }

                if (!string.IsNullOrEmpty(value))
                {
                    single.Values.TryAdd(binding.Path, value);
                    valuesRead++;
                }
            }

            // XML list tables: one repeating item per filled row.
            var rowsByItem = new Dictionary<string, List<Scope>>(StringComparer.Ordinal);
            foreach (var table in bindings.Tables)
            {
                var columns = table.Columns
                    .Where(c => { SchemaNodeDto n; return nodesByPath.TryGetValue(c.Path, out n) && n.DataType != "complex"; })
                    .Select(c => new VT_Offset_Node<int, SchemaNodeDto>(c.Offset, nodesByPath[c.Path]))
                    .ToList();
                var itemPath = columns.Select(c => NearestRepeating(c.Node, nodesByPath)?.Path).FirstOrDefault(p => p != null);
                if (itemPath == null)
                {
                    continue;
                }

                foreach (var column in columns)
                {
                    cellByPath.TryAdd(column.Node.Path, $"{table.Sheet}!{OpenXmlWorkbookInspector.ColumnName(table.FirstColumn + column.Offset)}{table.FirstDataRow}");
                }

                for (var row = table.FirstDataRow; row <= table.LastDataRow; row++)
                {
                    var scope = new Scope();
                    foreach (var column2 in columns)
                    {
                        var offset = column2.Offset;
                        var node = column2.Node;
                        var address = $"{OpenXmlWorkbookInspector.ColumnName(table.FirstColumn + offset)}{row}";
                        var where = $"{table.Sheet}!{address}";
                        scope.Cells.TryAdd(node.Path, where);
                        var raw = CellAt(table.Sheet, address);
                        if (raw == null)
                        {
                            continue;
                        }

                        string error;
                        var value = ToXmlValue(node, raw, out error);
                        if (error != null)
                        {
                            Problem("Error", $"{node.Name}: {error}", where, node.Path);
                        }

                        if (!string.IsNullOrEmpty(value))
                        {
                            scope.Values.TryAdd(node.Path, value);
                        }
                    }

                    if (scope.Values.Count == 0)
                    {
                        continue; // blank rows are not items
                    }

                    valuesRead += scope.Values.Count;
                    List<Scope> rows;
                    if (!rowsByItem.TryGetValue(itemPath, out rows))
                    {
                        rows = new List<Scope>();
                        rowsByItem[itemPath] = rows;
                    }

                    rows.Add(scope.WithContent(nodesByPath, itemPath));
                }
            }

            // Forms read from their sheets: one item per sheet that has values; each list inside it one item per filled row.
            foreach (var formSheet in formSheets)
            {
                var form = formSheet.Form;
                var sheet = formSheet.Sheet;
                var keyValue = formSheet.KeyValue;
                var item = new Scope();
                Func<Scope, MappingEntryDto, int?, string> ReadInto = null;
                ReadInto = (Scope scopeArg, MappingEntryDto fieldArg, int? rowArg) =>
                {
                    SchemaNodeDto node;
                    if (!nodesByPath.TryGetValue(fieldArg.SchemaPath, out node))
                    {
                        return null;
                    }
            
                    var address = (rowArg == null) ? fieldArg.CellAddress.ToUpperInvariant() : $"{SheetSplitRules.ColumnLetters(SheetSplitRules.Column(fieldArg.CellAddress))}{rowArg}";
                    var where = $"{sheet}!{address}";
                    scopeArg.Cells.TryAdd(node.Path, where);
                    cellByPath.TryAdd(node.Path, where);
                    var raw = CellAt(sheet, address);
                    if (raw == null)
                    {
                        return null;
                    }
            
                    string error;
                    var value = ToXmlValue(node, raw, out error);
                    if (error != null)
                    {
                        Problem("Error", $"{node.Name}: {error}", where, node.Path);
                    }
            
                    if (string.IsNullOrEmpty(value))
                    {
                        return null;
                    }
            
                    scopeArg.Values.TryAdd(node.Path, value);
                    return value;
                };

                foreach (var field in form.Fields)
                {
                    ReadInto(item,field,null);
                }

                var listRows = 0;
                foreach (var list in form.NestedLists)
                {
                    var rows = new List<Scope>();
                    var firstRow = list.FirstRow > 0 ? list.FirstRow : (int?)null;
                    var lastRow = list.FirstRow > 0 ? list.LastRow : 0;
                    for (var row = firstRow; row == null || row <= lastRow; row++)
                    {
                        var scope = new Scope();
                        foreach (var field in list.Fields)
                        {
                            ReadInto(scope, field, row);
                        }

                        // The first row's cells locate a blank required field of the list.
                        foreach (var cell2 in scope.Cells)
                        {
                            var path = cell2.Key;
                            var cell = cell2.Value;
                            item.Cells.TryAdd(path, cell);
                        }

                        if (scope.Values.Count > 0)
                        {
                            rows.Add(scope.WithContent(nodesByPath, list.ItemPath));
                        }

                        if (row == null)
                        {
                            break;
                        }
                    }

                    if (rows.Count > 0)
                    {
                        item.Children[list.ItemPath] = rows;
                        item.MarkContent(nodesByPath[list.ItemPath].ParentPath, nodesByPath, stopAt: form.GroupPath);
                        listRows += rows.Sum(r => r.Values.Count);
                    }
                }

                SheetSplitRules.ResolvedSplit formSplit;
                var keyPath = splits.TryGetValue(form.GroupPath, out formSplit) ? formSplit.Key.SchemaPath : null;
                if (listRows == 0 && !item.Values.Keys.Any(path => !string.Equals(path, keyPath, StringComparison.Ordinal)))
                {
                    continue; // a sheet without values (its key cell alone does not make an item)
                }

                if (formSplit != null && keyValue != null)
                {
                    var keyNode = nodesByPath[formSplit.Key.SchemaPath];
                    var keyCell = item.Cells.GetValueOrDefault(keyNode.Path);
                    string actual;
                    if (item.Values.TryGetValue(keyNode.Path, out actual) && !string.Equals(actual, keyValue, StringComparison.OrdinalIgnoreCase))
                    {
                        Problem("Error", $"{keyNode.Name} is {actual} on the sheet {sheet}, which is for {keyValue}. Enter {keyValue} or move the values to the sheet {SheetSplitNames.For(form.SheetName, actual)}.", keyCell, keyNode.Path);
                    }
                    else if (!item.Values.ContainsKey(keyNode.Path) && !keyNode.IsRequired)
                    {
                        Problem("Error", $"{keyNode.Name} is blank on the sheet {sheet}; enter {keyValue}.", keyCell, keyNode.Path);
                    }
                }

                valuesRead += item.Values.Count + listRows;
                List<Scope> items;
                if (!rowsByItem.TryGetValue(form.GroupPath, out items))
                {
                    items = new List<Scope>();
                    rowsByItem[form.GroupPath] = items;
                }

                items.Add(item.WithContent(nodesByPath, form.GroupPath));
            }

            single = single.WithContent(nodesByPath, null);
            foreach (var itemPath in rowsByItem.Keys)
            {
                single.MarkContent(itemPath, nodesByPath);
            }

            var builder = new DocumentBuilder(project, rowsByItem, Problem);
            var document = builder.Build(single);
            if (valuesRead == 0)
            {
                Problem("Error", "No values were found in the template's input cells. Fill in the template and save it before validating.", null, null);
            }

            return new FilledTemplate(document, problems, builder.CellByPosition, cellByPath, valuesRead, usedXmlMap);
        }

        // ---------- bindings (which cell holds which XSD element) ----------

        private sealed class SingleBinding : IRecord<SingleBinding>, IEquatable<SingleBinding>
    {
        public string Sheet { get; set; }

        public string Address { get; set; }

        public string Path { get; set; }

        public SingleBinding(string Sheet, string Address, string Path)
    {
    this.Sheet = Sheet;
    this.Address = Address;
    this.Path = Path;
    }

        public void Deconstruct(out string Sheet, out string Address, out string Path)
    {
    Sheet = this.Sheet;
    Address = this.Address;
    Path = this.Path;
    }

        public bool Equals(SingleBinding other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Sheet, other.Sheet)
    && EqualityComparer<string>.Default.Equals(Address, other.Address)
    && EqualityComparer<string>.Default.Equals(Path, other.Path);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SingleBinding);
    }

        public static bool operator ==(SingleBinding left, SingleBinding right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SingleBinding left, SingleBinding right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 36436;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Sheet);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Address);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Path);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SingleBinding { " + "Sheet = " + Sheet + ", " + "Address = " + Address + ", " + "Path = " + Path + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SingleBinding CloneRecord()
    {
    return (SingleBinding)MemberwiseClone();
    }

    }

        private sealed class TableBinding : IRecord<TableBinding>, IEquatable<TableBinding>
    {
        public string Sheet { get; set; }

        public int FirstColumn { get; set; }

        public int FirstDataRow { get; set; }

        public int LastDataRow { get; set; }

        public IReadOnlyList<VT_Offset_Path<int, string>> Columns { get; set; }

        public TableBinding(string Sheet, int FirstColumn, int FirstDataRow, int LastDataRow, IReadOnlyList<VT_Offset_Path<int, string>> Columns)
    {
    this.Sheet = Sheet;
    this.FirstColumn = FirstColumn;
    this.FirstDataRow = FirstDataRow;
    this.LastDataRow = LastDataRow;
    this.Columns = Columns;
    }

        public void Deconstruct(out string Sheet, out int FirstColumn, out int FirstDataRow, out int LastDataRow, out IReadOnlyList<VT_Offset_Path<int, string>> Columns)
    {
    Sheet = this.Sheet;
    FirstColumn = this.FirstColumn;
    FirstDataRow = this.FirstDataRow;
    LastDataRow = this.LastDataRow;
    Columns = this.Columns;
    }

        public bool Equals(TableBinding other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Sheet, other.Sheet)
    && EqualityComparer<int>.Default.Equals(FirstColumn, other.FirstColumn)
    && EqualityComparer<int>.Default.Equals(FirstDataRow, other.FirstDataRow)
    && EqualityComparer<int>.Default.Equals(LastDataRow, other.LastDataRow)
    && EqualityComparer<IReadOnlyList<VT_Offset_Path<int, string>>>.Default.Equals(Columns, other.Columns);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as TableBinding);
    }

        public static bool operator ==(TableBinding left, TableBinding right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(TableBinding left, TableBinding right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 16488;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Sheet);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(FirstColumn);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(FirstDataRow);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(LastDataRow);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<VT_Offset_Path<int, string>>>.Default.GetHashCode(Columns);
    return hash;
    }
    }

        public override string ToString()
    {
    return "TableBinding { " + "Sheet = " + Sheet + ", " + "FirstColumn = " + FirstColumn + ", " + "FirstDataRow = " + FirstDataRow + ", " + "LastDataRow = " + LastDataRow + ", " + "Columns = " + Columns + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public TableBinding CloneRecord()
    {
    return (TableBinding)MemberwiseClone();
    }

    }

        private sealed class Bindings : IRecord<Bindings>, IEquatable<Bindings>
    {
        public IReadOnlyList<SingleBinding> Singles { get; set; }

        public IReadOnlyList<TableBinding> Tables { get; set; }

        public Bindings(IReadOnlyList<SingleBinding> Singles, IReadOnlyList<TableBinding> Tables)
    {
    this.Singles = Singles;
    this.Tables = Tables;
    }

        public void Deconstruct(out IReadOnlyList<SingleBinding> Singles, out IReadOnlyList<TableBinding> Tables)
    {
    Singles = this.Singles;
    Tables = this.Tables;
    }

        public bool Equals(Bindings other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<SingleBinding>>.Default.Equals(Singles, other.Singles)
    && EqualityComparer<IReadOnlyList<TableBinding>>.Default.Equals(Tables, other.Tables);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as Bindings);
    }

        public static bool operator ==(Bindings left, Bindings right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(Bindings left, Bindings right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 12095;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SingleBinding>>.Default.GetHashCode(Singles);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<TableBinding>>.Default.GetHashCode(Tables);
    return hash;
    }
    }

        public override string ToString()
    {
    return "Bindings { " + "Singles = " + Singles + ", " + "Tables = " + Tables + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public Bindings CloneRecord()
    {
    return (Bindings)MemberwiseClone();
    }

    }

        private static Bindings ReadBindings(FrpProjectDto project, ZipArchive archive, List<XsdValidationMessageDto> problems, out bool usedXmlMap)
        {
            usedXmlMap = false;
            var maps = TemplateCoverageChecker.Load(archive, "xl/xmlMaps.xml")?.Root;
            var map = maps?.Elements(Main + "Map")
                .FirstOrDefault(m => string.Equals((string)m.Attribute("RootElement"), project.RootElement, StringComparison.Ordinal));
            if (map == null)
            {
                XElement other;
                if (CompatPattern.Is(maps?.Elements(Main + "Map").FirstOrDefault(), out other))
                {
                    problems.Add(new XsdValidationMessageDto
                    {
                        Severity = "Error",
                        Message = $"This workbook's XML map is for '{(string)other.Attribute("RootElement")}', not this project's '{project.RootElement}'. "
                            + "Use the input template downloaded from this project."
                    });
                    return null;
                }

                // No XML map: use the project's mappings (sheet and cell per field).
                var singles = project.Mappings
                    .Where(m => !string.IsNullOrWhiteSpace(m.SheetName) && IsCellAddress(m.CellAddress))
                    .Select(m => new SingleBinding(m.SheetName, m.CellAddress.ToUpperInvariant(), m.SchemaPath))
                    .ToList();
                if (singles.Count == 0)
                {
                    problems.Add(new XsdValidationMessageDto
                    {
                        Severity = "Error",
                        Message = "The workbook has no XML map and the project has no cell mappings, so its values cannot be read. Use the input template downloaded from this project."
                    });
                    return null;
                }

                return new Bindings(singles, new List<TableBinding>());
            }

            usedXmlMap = true;
            var mapId = (string)map.Attribute("ID") ?? "1";
            var schemaId = (string)map.Attribute("SchemaID");
            var mapNamespace = (string)maps.Elements(Main + "Schema").FirstOrDefault(s => (string)s.Attribute("ID") == schemaId)?.Attribute("Namespace");
            if (!string.Equals(mapNamespace ?? "", project.TargetNamespace ?? "", StringComparison.Ordinal))
            {
                problems.Add(new XsdValidationMessageDto
                {
                    Severity = "Error",
                    Message = $"This workbook's XML map uses the namespace '{mapNamespace}', not this project's XSD namespace '{project.TargetNamespace}'. "
                        + "Use the input template downloaded from this project (the XSD version may differ)."
                });
                return null;
            }

            var singleBindings = new List<SingleBinding>();
            var tableBindings = new List<TableBinding>();
            foreach (var sheet2 in TemplateCoverageChecker.Sheets(archive))
            {
                var sheetName = sheet2.Name;
                var worksheetPath = sheet2.WorksheetPath;
                var directory = worksheetPath.Contains('/') ? worksheetPath.Substring(0, worksheetPath.LastIndexOf('/')) : "xl/worksheets";
                var rels = TemplateCoverageChecker.Load(archive, $"{directory}/_rels/{worksheetPath.Substring(worksheetPath.LastIndexOf('/') + 1)}.rels")?.Root;
                foreach (var relationship in rels?.Elements(PackageRel + "Relationship") ?? new List<XElement>())
                {
                    var type = (string)relationship.Attribute("Type") ?? "";
                    var isSingleCells = type.EndsWith("/tableSingleCells", StringComparison.OrdinalIgnoreCase);
                    var isTable = type.EndsWith("/table", StringComparison.OrdinalIgnoreCase);
                    if (!isSingleCells && !isTable || (string)relationship.Attribute("TargetMode") == "External")
                    {
                        continue;
                    }

                    var part = TemplateCoverageChecker.Load(archive, TemplateCoverageChecker.Normalize(directory, (string)relationship.Attribute("Target") ?? ""))?.Root;
                    if (part == null)
                    {
                        continue;
                    }

                    string start;
                    string end;
                    if (isSingleCells)
                    {
                        foreach (var cell in part.Elements(Main + "singleXmlCell"))
                        {
                            var pr = cell.Descendants(Main + "xmlPr").FirstOrDefault();
                            var address = ((string)cell.Attribute("r") ?? "").ToUpperInvariant();
                            if (pr != null && (string)pr.Attribute("mapId") == mapId && IsCellAddress(address))
                            {
                                singleBindings.Add(new SingleBinding(sheetName, address, TemplateCoverageChecker.StripPrefixes((string)pr.Attribute("xpath"))));
                            }
                        }
                    }
                    else if ((string)part.Attribute("tableType") == "xml" && TwoParts((string)part.Attribute("ref"), out start, out end)
                             && IsCellAddress(start) && IsCellAddress(end))
                    {
                        var headerRows = (int?)part.Attribute("headerRowCount") ?? 1;
                        var totalsRows = (int?)part.Attribute("totalsRowCount") ?? 0;
                        var columns = new List<VT_Offset_Path<int, string>>();
                        var offset = 0;
                        foreach (var column in part.Descendants(Main + "tableColumn"))
                        {
                            var xmlColumn = column.Element(Main + "xmlColumnPr");
                            if (xmlColumn != null && (string)xmlColumn.Attribute("mapId") == mapId)
                            {
                                columns.Add(new VT_Offset_Path<int, string>(offset, TemplateCoverageChecker.StripPrefixes((string)xmlColumn.Attribute("xpath"))));
                            }

                            offset++;
                        }

                        if (columns.Count > 0)
                        {
                            tableBindings.Add(new TableBinding(
                                sheetName,
                                OpenXmlWorkbookInspector.ColumnIndex(start),
                                OpenXmlWorkbookInspector.RowNumber(start) + Math.Max(headerRows, 0),
                                OpenXmlWorkbookInspector.RowNumber(end) - Math.Max(totalsRows, 0),
                                columns));
                        }
                    }
                }
            }

            // Lists inside lists cannot be bound in an XML map, so the exported template keeps those forms as plain input
            // cells (the project's mappings); their values are read from those cells.
            var unmappable = OpenXmlMappedTemplateWriter.UnmappableListGroups(project);
            if (unmappable.Count > 0)
            {
                var sheetNames = TemplateCoverageChecker.Sheets(archive).Select(s => s.Name).ToHashSet(StringComparer.Ordinal);
                var bound = singleBindings.Select(b => b.Path).Concat(tableBindings.SelectMany(t => t.Columns.Select(c => c.Path))).ToHashSet(StringComparer.Ordinal);
                singleBindings.AddRange(project.Mappings
                    .Where(m => sheetNames.Contains(m.SheetName) && IsCellAddress(m.CellAddress) && !bound.Contains(m.SchemaPath)
                        && unmappable.Any(group => m.SchemaPath.StartsWith(group + "/", StringComparison.Ordinal)))
                    .Select(m => new SingleBinding(m.SheetName, m.CellAddress.ToUpperInvariant(), m.SchemaPath)));
            }

            return new Bindings(singleBindings, tableBindings);
        }

        /// <summary>The bindings without the elements under <paramref name="prefixes"/> (read from their forms' sheets instead).</summary>
        private static Bindings WithoutGroups(Bindings bindings, IReadOnlyList<string> prefixes)
        {
            Func<string, bool> Under = null;
            Under = (string path) =>
            {
                return prefixes.Any(p => path.StartsWith(p, StringComparison.Ordinal));
            };
            var tables = bindings.Tables
                .Select(t => t.With(copy => { copy.Columns = t.Columns.Where(c => !Under(c.Path)).ToList(); }))
                .Where(t => t.Columns.Count > 0)
                .ToList();
            return new Bindings(bindings.Singles.Where(b => !Under(b.Path)).ToList(), tables);
        }

        /// <summary>"A1:B9" as its two parts (a "ref" with exactly one colon).</summary>
        private static bool TwoParts(string text, out string first, out string second)
        {
            var parts = text == null ? null : text.Split(':');
            if (parts == null || parts.Length != 2)
            {
                first = null;
                second = null;
                return false;
            }

            first = parts[0];
            second = parts[1];
            return true;
        }

        private static bool IsCellAddress(string address)
        {
            if (string.IsNullOrEmpty(address))
            {
                return false;
            }

            var letters = address.TakeWhile(CompatChar.IsAsciiLetter).Count();
            var digits = address.Skip(letters);
            return letters > 0 && letters <= 3 && digits.All(CompatChar.IsAsciiDigit) && digits.Any();
        }

        private static SchemaNodeDto NearestRepeating(SchemaNodeDto node, IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath)
        {
            for (var current = node; (current != null); current = (current.ParentPath == null) ? null : nodesByPath.GetValueOrDefault(current.ParentPath))
            {
                if (current.IsRepeating)
                {
                    return current;
                }
            }

            return null;
        }

        // ---------- cells ----------

        private sealed class RawCell : IRecord<RawCell>, IEquatable<RawCell>
    {
        public string Type { get; set; }

        public string Value { get; set; }

        public bool HasFormula { get; set; }

        public RawCell(string Type, string Value, bool HasFormula)
    {
    this.Type = Type;
    this.Value = Value;
    this.HasFormula = HasFormula;
    }

        public void Deconstruct(out string Type, out string Value, out bool HasFormula)
    {
    Type = this.Type;
    Value = this.Value;
    HasFormula = this.HasFormula;
    }

        public bool Equals(RawCell other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(Type, other.Type)
    && EqualityComparer<string>.Default.Equals(Value, other.Value)
    && EqualityComparer<bool>.Default.Equals(HasFormula, other.HasFormula);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as RawCell);
    }

        public static bool operator ==(RawCell left, RawCell right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(RawCell left, RawCell right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 81703;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Type);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Value);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(HasFormula);
    return hash;
    }
    }

        public override string ToString()
    {
    return "RawCell { " + "Type = " + Type + ", " + "Value = " + Value + ", " + "HasFormula = " + HasFormula + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public RawCell CloneRecord()
    {
    return (RawCell)MemberwiseClone();
    }

    }

        private static IReadOnlyList<string> ReadSharedStrings(ZipArchive archive)
        {
            var document = TemplateCoverageChecker.Load(archive, "xl/sharedStrings.xml");
            return document?.Root?.Elements(Main + "si")
                .Select(si => string.Concat(si.Descendants(Main + "t").Where(t => t.Parent?.Name != Main + "rPh" && t.Parent?.Parent?.Name != Main + "rPh").Select(t => t.Value)))
                .ToList() ?? new List<string>();
        }

        private static Dictionary<string, RawCell> ReadCells(ZipArchive archive, string worksheetPath, IReadOnlyList<string> sharedStrings)
        {
            var cells = new Dictionary<string, RawCell>(StringComparer.Ordinal);
            var entry = archive.GetEntry(worksheetPath);
            if (entry == null)
            {
                return cells;
            }

            using (var stream = entry.Open())
            {
            using (var reader = XmlReader.Create(stream, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null }))
            {
            reader.MoveToContent();
            while (!reader.EOF)
            {
                // XNode.ReadFrom leaves the reader on the node after the cell (often the next cell), so it is not skipped.
                if (reader.NodeType != XmlNodeType.Element || reader.LocalName != "c" || reader.NamespaceURI != Main.NamespaceName)
                {
                    reader.Read();
                    continue;
                }

                var address = reader.GetAttribute("r")?.ToUpperInvariant();
                var type = reader.GetAttribute("t");
                XElement cell;
                if (!CompatPattern.Is(XNode.ReadFrom(reader), out cell) || address == null)
                {
                    continue;
                }

                var hasFormula = cell.Element(Main + "f") != null;
                var v = cell.Element(Main + "v")?.Value;
                int index;
                string value = type == "s" ? (int.TryParse(v, NumberStyles.Integer, CultureInfo.InvariantCulture, out index) && index >= 0 && index < sharedStrings.Count ? sharedStrings[index] : null) : type == "inlineStr" ? string.Concat(cell.Element(Main + "is")?.Descendants(Main + "t").Select(t => t.Value) ?? new List<string>()) : v;
                if (value == null && !hasFormula)
                {
                    continue;
                }

                cells[address] = new RawCell(type, value ?? "", hasFormula && value == null);
            }

            return cells;
            }
            }
        }

        /// <summary>
        /// The cell's value as the XSD type expects it (numbers without Excel's floating-point noise, dates as
        /// yyyy-MM-dd, booleans as true/false). Values are not changed otherwise; the XSD check reports what is wrong.
        /// </summary>
        private static string ToXmlValue(SchemaNodeDto node, RawCell cell, out string error)
        {
            error = null;
            if (cell.HasFormula)
            {
                error = "the cell has a formula without a calculated value. Open the workbook in Excel, let it calculate, and save it again.";
                return null;
            }

            if (cell.Type == "e")
            {
                error = $"the cell shows the Excel error {cell.Value}.";
                return null;
            }

            var isNumberCell = cell.Type == null || cell.Type == "n";
            if (cell.Type == "b")
            {
                return node.DataType == "boolean" ? (cell.Value == "1" ? "true" : "false") : (cell.Value == "1" ? "TRUE" : "FALSE");
            }

            if (!isNumberCell)
            {
                var text = node.DataType == "string" ? cell.Value : cell.Value.Trim();
                return text.Length == 0 ? null : text;
            }

            double number;
            if (!double.TryParse(cell.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out number))
            {
                return cell.Value.Trim();
            }

            switch (node.DataType)
            {
                case "date":
                case "dateTime":
                    if (number < -657434 || number > 2958465)
                    {
                        error = $"{cell.Value} is not a date.";
                        return cell.Value;
                    }

                    var date = DateTime.FromOADate(number);
                    return node.DataType == "date" ? date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : date.ToString("yyyy-MM-ddTHH:mm:ss", CultureInfo.InvariantCulture);
                case "boolean":
                    return number == 1 ? "true" : number == 0 ? "false" : cell.Value;
                default:
                    return FormatNumber(cell.Value);
            }
        }

        /// <summary>A stored Excel number (e.g. "0.30000000000000004" or "1.5E-3") as Excel shows it: 15 significant digits, no exponent.</summary>
        internal static string FormatNumber(string stored)
        {
            decimal value;
            if (!decimal.TryParse(stored, NumberStyles.Float, CultureInfo.InvariantCulture, out value))
            {
                // Beyond decimal's range: keep Excel's 15 significant digits.
                return double.Parse(stored, NumberStyles.Float, CultureInfo.InvariantCulture).ToString("G15", CultureInfo.InvariantCulture);
            }

            if (value != 0)
            {
                var digitsBeforePoint = (int)Math.Floor(Math.Log10((double)Math.Abs(value))) + 1;
                var decimals = CompatMath.Clamp(15 - digitsBeforePoint, 0, 28);
                value = Math.Round(value, decimals, MidpointRounding.AwayFromZero);
            }

            return value.ToString("0.############################", CultureInfo.InvariantCulture);
        }

        // ---------- the XML document ----------

        /// <summary>Values (by schema path) of one scope: the single cells, or one row of an XML list table.</summary>
        private sealed class Scope
        {
            public Dictionary<string, string> Values { get; } = new Dictionary<string, string>(StringComparer.Ordinal);
            public Dictionary<string, string> Cells { get; } = new Dictionary<string, string>(StringComparer.Ordinal);
            public HashSet<string> Content { get; } = new HashSet<string>(StringComparer.Ordinal);
            /// <summary>Items of the lists inside this scope's item, by the list item's schema path.</summary>
            public Dictionary<string, List<Scope>> Children { get; } = new Dictionary<string, List<Scope>>(StringComparer.Ordinal);

            public Scope WithContent(IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath, string stopAt)
            {
                foreach (var path in Values.Keys)
                {
                    for (var node = nodesByPath.GetValueOrDefault(path); (node != null); node = (node.ParentPath == null) ? null : nodesByPath.GetValueOrDefault(node.ParentPath))
                    {
                        if (!Content.Add(node.Path) || string.Equals(node.Path, stopAt, StringComparison.Ordinal))
                        {
                            break;
                        }
                    }
                }

                return this;
            }

            public void MarkContent(string path, IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath, string stopAt = null)
            {
                for (var node = nodesByPath.GetValueOrDefault(path);
                     node != null && !string.Equals(node.Path, stopAt, StringComparison.Ordinal) && Content.Add(node.Path);
                     node = (node.ParentPath == null) ? null : nodesByPath.GetValueOrDefault(node.ParentPath))
                {
                }
            }
        }

        private sealed class DocumentBuilder
        {
        private readonly FrpProjectDto project;
        private readonly IReadOnlyDictionary<string, List<Scope>> rowsByItem;
        private readonly Action<string, string, string, string> problem;

        public DocumentBuilder(FrpProjectDto project, IReadOnlyDictionary<string, List<Scope>> rowsByItem, Action<string, string, string, string> problem)
    {
        this.project = project;
        this.rowsByItem = rowsByItem;
        this.problem = problem;
        this.ns = project.TargetNamespace ?? "";
        this.children = project.SchemaNodes.Where(n => n.ParentPath != null).GroupBy(n => n.ParentPath, StringComparer.Ordinal).ToDictionary(g => g.Key, g => g.GroupBy(n => n.Path, StringComparer.Ordinal).Select(x => x.First()).ToList(), StringComparer.Ordinal);
    }
            private readonly XNamespace ns ;
            private readonly Dictionary<string, List<SchemaNodeDto>> children ;
            private readonly Dictionary<XElement, string> cells = new Dictionary<XElement, string>();

            /// <summary>Cell of each written leaf, by its position in the document (e.g. /A/B[2]/C).</summary>
            public Dictionary<string, string> CellByPosition { get; } = new Dictionary<string, string>(StringComparer.Ordinal);

            public XDocument Build(Scope single)
            {
                var rootNode = project.SchemaNodes.First(n => n.ParentPath == null);
                var root = new XElement(ns + rootNode.Name);
                WriteChildren(rootNode, root, single);
                var document = new XDocument(new XDeclaration("1.0", "UTF-8", "yes"), root);
                foreach (var cell2 in cells)
                {
                    var element = cell2.Key;
                    var cell = cell2.Value;
                    CellByPosition[PositionOf(element)] = cell;
                }

                return document;
            }

            private void WriteChildren(SchemaNodeDto parentNode, XElement parent, Scope scope)
            {
                foreach (var node in children.GetValueOrDefault(parentNode.Path) ?? new List<SchemaNodeDto>())
                {
                    List<Scope> rows;
                    if (node.IsRepeating && (scope.Children.TryGetValue(node.Path, out rows) || rowsByItem.TryGetValue(node.Path, out rows)))
                    {
                        foreach (var row in rows)
                        {
                            Write(node, parent, row);
                        }

                        continue;
                    }

                    if (scope.Content.Contains(node.Path) || node.IsRequired)
                    {
                        Write(node, parent, scope);
                    }
                }
            }

            private void Write(SchemaNodeDto node, XElement parent, Scope scope)
            {
                var element = new XElement(ns + node.Name);
                parent.Add(element);
                if (node.DataType == "complex")
                {
                    WriteChildren(node, element, scope);
                    return;
                }

                var cell = scope.Cells.GetValueOrDefault(node.Path);
                if (cell != null)
                {
                    cells[element] = cell;
                }

                string value;
                if (scope.Values.TryGetValue(node.Path, out value))
                {
                    element.Value = value;
                }
                else if (node.IsRequired)
                {
                    problem("Error", (cell == null)
                        ? $"Required field {node.Name} ({node.Path}) has no cell in this workbook."
                        : $"Required field {node.Name} is blank.", cell, node.Path);
                }
            }
        }

        /// <summary>The element's position in the document, e.g. /FRP/Form/Table/Item[2]/Field.</summary>
        internal static string PositionOf(XElement element) =>
            "/" + string.Join("/", element.AncestorsAndSelf().Reverse().Select(e =>
            {
                var index = e.ElementsBeforeSelf(e.Name).Count();
                return index == 0 && !e.ElementsAfterSelf(e.Name).Any() ? e.Name.LocalName : $"{e.Name.LocalName}[{index + 1}]";
            }));
    }

    /// <summary>The XML built from a filled Excel template, and where each value came from.</summary>
    /// <param name="Document">Null when the workbook could not be read.</param>
    /// <param name="Problems">Cells whose values could not be read, blank required fields, and workbook problems.</param>
    /// <param name="CellByPosition">"Sheet!A1" of each written field, by position (/A/B[2]/C).</param>
    /// <param name="CellBySchemaPath">"Sheet!A1" of each bound field (the first row of a list table).</param>
    public sealed class FilledTemplate : IRecord<FilledTemplate>, IEquatable<FilledTemplate>
    {
        public XDocument Document { get; set; }

        public IReadOnlyList<XsdValidationMessageDto> Problems { get; set; }

        public IReadOnlyDictionary<string, string> CellByPosition { get; set; }

        public IReadOnlyDictionary<string, string> CellBySchemaPath { get; set; }

        public int ValuesRead { get; set; }

        public bool UsedXmlMap { get; set; }

        public FilledTemplate(XDocument Document, IReadOnlyList<XsdValidationMessageDto> Problems, IReadOnlyDictionary<string, string> CellByPosition, IReadOnlyDictionary<string, string> CellBySchemaPath, int ValuesRead, bool UsedXmlMap)
    {
    this.Document = Document;
    this.Problems = Problems;
    this.CellByPosition = CellByPosition;
    this.CellBySchemaPath = CellBySchemaPath;
    this.ValuesRead = ValuesRead;
    this.UsedXmlMap = UsedXmlMap;
    }

        public void Deconstruct(out XDocument Document, out IReadOnlyList<XsdValidationMessageDto> Problems, out IReadOnlyDictionary<string, string> CellByPosition, out IReadOnlyDictionary<string, string> CellBySchemaPath, out int ValuesRead, out bool UsedXmlMap)
    {
    Document = this.Document;
    Problems = this.Problems;
    CellByPosition = this.CellByPosition;
    CellBySchemaPath = this.CellBySchemaPath;
    ValuesRead = this.ValuesRead;
    UsedXmlMap = this.UsedXmlMap;
    }

        public static FilledTemplate Unreadable(string message) =>
            new FilledTemplate(null, new List<XsdValidationMessageDto> { new XsdValidationMessageDto { Severity = "Error", Message = message } }, new Dictionary<string, string>(), new Dictionary<string, string>(), 0, false);

        public bool Equals(FilledTemplate other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<XDocument>.Default.Equals(Document, other.Document)
    && EqualityComparer<IReadOnlyList<XsdValidationMessageDto>>.Default.Equals(Problems, other.Problems)
    && EqualityComparer<IReadOnlyDictionary<string, string>>.Default.Equals(CellByPosition, other.CellByPosition)
    && EqualityComparer<IReadOnlyDictionary<string, string>>.Default.Equals(CellBySchemaPath, other.CellBySchemaPath)
    && EqualityComparer<int>.Default.Equals(ValuesRead, other.ValuesRead)
    && EqualityComparer<bool>.Default.Equals(UsedXmlMap, other.UsedXmlMap);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as FilledTemplate);
    }

        public static bool operator ==(FilledTemplate left, FilledTemplate right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(FilledTemplate left, FilledTemplate right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 69651;
    hash = hash * -1521134295 + EqualityComparer<XDocument>.Default.GetHashCode(Document);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<XsdValidationMessageDto>>.Default.GetHashCode(Problems);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyDictionary<string, string>>.Default.GetHashCode(CellByPosition);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyDictionary<string, string>>.Default.GetHashCode(CellBySchemaPath);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(ValuesRead);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(UsedXmlMap);
    return hash;
    }
    }

        public override string ToString()
    {
    return "FilledTemplate { " + "Document = " + Document + ", " + "Problems = " + Problems + ", " + "CellByPosition = " + CellByPosition + ", " + "CellBySchemaPath = " + CellBySchemaPath + ", " + "ValuesRead = " + ValuesRead + ", " + "UsedXmlMap = " + UsedXmlMap + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public FilledTemplate CloneRecord()
    {
    return (FilledTemplate)MemberwiseClone();
    }

    }

    /// <summary>The XML built from a filled template (null when the workbook could not be read) and its validation.</summary>
    /// <param name="CanAttach">False when the workbook or some of its cells could not be read, so the XML would not match the workbook.</param>
    public sealed class FilledTemplateXml : IRecord<FilledTemplateXml>, IEquatable<FilledTemplateXml>
    {
        public byte[] Xml { get; set; }

        public bool CanAttach { get; set; }

        public XsdValidationResultDto Result { get; set; }

        public FilledTemplateXml(byte[] Xml, bool CanAttach, XsdValidationResultDto Result)
    {
    this.Xml = Xml;
    this.CanAttach = CanAttach;
    this.Result = Result;
    }

        public void Deconstruct(out byte[] Xml, out bool CanAttach, out XsdValidationResultDto Result)
    {
    Xml = this.Xml;
    CanAttach = this.CanAttach;
    Result = this.Result;
    }

        public bool Equals(FilledTemplateXml other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<byte[]>.Default.Equals(Xml, other.Xml)
    && EqualityComparer<bool>.Default.Equals(CanAttach, other.CanAttach)
    && EqualityComparer<XsdValidationResultDto>.Default.Equals(Result, other.Result);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as FilledTemplateXml);
    }

        public static bool operator ==(FilledTemplateXml left, FilledTemplateXml right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(FilledTemplateXml left, FilledTemplateXml right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 87222;
    hash = hash * -1521134295 + EqualityComparer<byte[]>.Default.GetHashCode(Xml);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(CanAttach);
    hash = hash * -1521134295 + EqualityComparer<XsdValidationResultDto>.Default.GetHashCode(Result);
    return hash;
    }
    }

        public override string ToString()
    {
    return "FilledTemplateXml { " + "Xml = " + Xml + ", " + "CanAttach = " + CanAttach + ", " + "Result = " + Result + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public FilledTemplateXml CloneRecord()
    {
    return (FilledTemplateXml)MemberwiseClone();
    }

    }

}
