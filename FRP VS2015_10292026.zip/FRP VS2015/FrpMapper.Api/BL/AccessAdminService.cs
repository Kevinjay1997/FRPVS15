﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Access administration by the two Administrator teams, each with a Maker who requests and a Checker who approves:
    /// the SRAU Maker (<see cref="Permissions.UsersManage"/>) requests adding people, the roles they hold and disabling
    /// them, and the SRAU Checker (<see cref="Permissions.UsersApprove"/>) approves; the PARAM Maker
    /// (<see cref="Permissions.RolesManage"/>) requests new roles, role changes and their permissions, and the PARAM
    /// Checker (<see cref="Permissions.RolesApprove"/>) approves. Either Maker can request a change to the Active
    /// Directory groups that grant a role; the Checker of the same team approves it. Both SRAU roles see people's activity.
    /// A request takes effect only when a Checker of the requester's team, who is not the requester, approves it.
    /// Nobody can request or approve a change to their own access, and no role or person may combine managing access
    /// with preparing or reviewing submissions, or SRAU with PARAM (<see cref="AccessRules"/>).
    /// Every request and decision is written to the audit trail.
    /// </summary>
    public sealed partial class AccessAdminService: IAccessAdminService
    {
        private readonly IAccessAdminRepository repository;
        private readonly IAccessService access;
        private readonly IAuditLog auditLog;
        private readonly ICurrentUser currentUser;

        public AccessAdminService(IAccessAdminRepository repository, IAccessService access, IAuditLog auditLog, ICurrentUser currentUser)
    {
        this.repository = repository;
        this.access = access;
        this.auditLog = auditLog;
        this.currentUser = currentUser;
    }
        private const int DecidedShown = 50;
        private const int MaxGroupsPerRole = 50;
        private const int ActivityShown = 100;

        public async Task<AccessAdministrationDto> GetAsync(CancellationToken cancellationToken)
        {
            if (!IsAdministrator)
            {
                throw new WorkflowException(WorkflowErrorKind.Forbidden, "Only the SRAU and PARAM teams can open access administration.");
            }

            return await repository.GetAsync(DecidedShown, cancellationToken);
        }

        public async Task<AccessChangeRequestDto> RequestUserChangeAsync(UserChangeDto change, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.UsersManage, "request changes to people's access (SRAU Maker)");
            var state = await repository.GetAsync(DecidedShown, cancellationToken);
            var clean = CleanUser(change);
            RequireNotSelf(clean.UserName);
            var current = state.Users.FirstOrDefault(u => SameName(u.UserName, clean.UserName));
            if (clean.Delete)
            {
                var existing = current ?? CompatThrow.As<AdminUserDto>(new WorkflowException(WorkflowErrorKind.Invalid, $"{clean.UserName} is not in the list."));
                var deletion = new UserChangeDto
                {
                    UserName = existing.UserName, DisplayName = existing.DisplayName, IsActive = false, Roles = new List<string>(), Department = existing.Department,
                    AccessUntil = existing.AccessUntil, Delete = true
                };
                return await CreateAsync(AccessTeams.Users, AccessKinds.User, existing.UserName, DescribeUserDeletion(existing), deletion, null, null, cancellationToken,
                    Snapshot(existing));
            }

            ValidateUser(clean, current, state);
            var summary = DescribeUser(clean, current);
            return await CreateAsync(AccessTeams.Users, AccessKinds.User, clean.UserName, summary, clean, null, null, cancellationToken,
                (current == null) ? null : Snapshot(current));
        }

        public async Task<AccessChangeRequestDto> RequestRoleChangeAsync(RoleChangeDto change, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.RolesManage, "request changes to roles (PARAM Maker)");
            var state = await repository.GetAsync(DecidedShown, cancellationToken);
            if (change.Delete)
            {
                var key = (change.Key ?? "").Trim();
                RequireNotHolding(key);
                var existing = state.Roles.FirstOrDefault(r => SameName(r.Key, key))
                               ?? CompatThrow.As<AdminRoleDto>(new WorkflowException(WorkflowErrorKind.Invalid, $"There is no role {key}."));
                ValidateRoleDeletion(existing, state);
                var deletion = new RoleChangeDto
                {
                    Key = existing.Key, DisplayName = existing.DisplayName, Description = existing.Description, IsActive = false,
                    Permissions = existing.Permissions.ToList(), Delete = true
                };
                return await CreateAsync(AccessTeams.Roles, AccessKinds.Role, existing.Key, DescribeRoleDeletion(existing), null, deletion, null, cancellationToken,
                    Snapshot(existing));
            }

            var clean = CleanRole(change);
            RequireNotHolding(clean.Key);
            var current = state.Roles.FirstOrDefault(r => SameName(r.Key, clean.Key));
            if (current == null && state.DeletedRoleKeys.Contains(clean.Key, StringComparer.OrdinalIgnoreCase))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"A deleted role used the key {clean.Key}; choose another key.");
            }

            ValidateRole(clean, current, state);
            var summary = DescribeRole(clean, current);
            return await CreateAsync(AccessTeams.Roles, AccessKinds.Role, clean.Key, summary, null, clean, null, cancellationToken,
                (current == null) ? null : Snapshot(current));
        }

        /// <summary>SRAU or PARAM Maker: the Active Directory groups that grant a role; the Checker of the requester's team approves.</summary>
        public async Task<AccessChangeRequestDto> RequestGroupsChangeAsync(RoleGroupsChangeDto change, CancellationToken cancellationToken)
        {
            var team = MakerTeamOfCurrentUser()
                       ?? CompatThrow.As<string>(new WorkflowException(WorkflowErrorKind.Forbidden, "Only the SRAU Maker and the PARAM Maker can request a change to which AD groups grant a role."));
            var state = await repository.GetAsync(DecidedShown, cancellationToken);
            var clean = CleanGroups(change);
            RequireNotHolding(clean.RoleKey);
            var role = state.Roles.FirstOrDefault(r => SameName(r.Key, clean.RoleKey))
                       ?? CompatThrow.As<AdminRoleDto>(new WorkflowException(WorkflowErrorKind.Invalid, $"There is no role {clean.RoleKey}."));
            clean = clean.With(copy => { copy.RoleKey = role.Key; });
            ValidateGroups(clean, role);
            return await CreateAsync(team, AccessKinds.Groups, role.Key, DescribeGroups(clean, role), null, null, clean, cancellationToken,
                new RoleGroupsChangeDto { RoleKey = role.Key, DirectoryGroups = role.DirectoryGroups.ToList() });
        }

        /// <summary>SRAU Maker or Checker: what a person did (sign-ins included) and the access changes made to them.</summary>
        public async Task<UserActivityDto> GetUserActivityAsync(string userName, CancellationToken cancellationToken)
        {
            if (!currentUser.IsAuthenticated || !(currentUser.HasPermission(Permissions.UsersManage) || currentUser.HasPermission(Permissions.UsersApprove)))
            {
                throw new WorkflowException(WorkflowErrorKind.Forbidden, "Only the SRAU team can see people's activity.");
            }

            var name = (userName ?? "").Trim();
            if (name.Length == 0 || name.Length > 256 || !UserNameRegex().IsMatch(name))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Choose a person.");
            }

            var state = await repository.GetAsync(DecidedShown, cancellationToken);
            var entries = await auditLog.QueryByUserAsync(name, ActivityShown, cancellationToken);
            var lastSignIn = state.Users.FirstOrDefault(u => SameName(u.UserName, name))?.LastSignInAt
                             ?? state.OtherSignIns.FirstOrDefault(u => SameName(u.UserName, name))?.LastSignInAt;
            return new UserActivityDto
            {
                UserName = name,
                LastSignInAt = lastSignIn,
                Entries = entries,
                AccessChanges = state.Requests.Where(r => r.Kind == AccessKinds.User && SameName(r.TargetKey, name)).ToList()
            };
        }

        public async Task<bool> DecideAsync(string requestId, string decision, AccessDecisionRequest body, CancellationToken cancellationToken)
        {
            if (!(decision == AccessRequestStatus.Approved || decision == AccessRequestStatus.Rejected || decision == AccessRequestStatus.Cancelled))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Unknown decision.");
            }

            if (!IsAdministrator)
            {
                throw new WorkflowException(WorkflowErrorKind.Forbidden, "Only the SRAU and PARAM teams can decide access changes.");
            }

            var state = await repository.GetAsync(DecidedShown, cancellationToken);
            var request = state.Requests.FirstOrDefault(r => r.Id == requestId && r.Status == AccessRequestStatus.Pending);
            if (request == null)
            {
                return false;
            }

            var comment = body.Comment?.Trim();
            if (comment != null && comment.Length > 1000 || (comment?.Any(ch => char.IsControl(ch) && !(ch == '\n') && !(ch == '\r')) ?? false))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "The comment must be at most 1,000 characters.");
            }

            if (decision == AccessRequestStatus.Cancelled)
            {
                if (!SameName(request.RequestedBy, currentUser.Name))
                {
                    throw new WorkflowException(WorkflowErrorKind.Forbidden, "Only the person who requested a change can cancel it.");
                }
            }
            else
            {
                // Maker / Checker: only the Checker of the requester's team approves or rejects, never the requester.
                if (!currentUser.HasPermission(AccessTeams.ApprovePermission(request.Team)))
                {
                    await AuditAsync("Access change refused", $"{Subject(request.Kind)} {request.TargetKey}: {currentUser.Name} is not {AccessTeams.WithArticle(request.Team)} Checker and tried to {DecisionVerb(decision)} it.", cancellationToken);
                    throw new WorkflowException(WorkflowErrorKind.Forbidden, $"Only {AccessTeams.WithArticle(request.Team)} Checker can approve or reject this change.");
                }

                if (SameName(request.RequestedBy, currentUser.Name))
                {
                    await AuditAsync("Access change refused", $"{Subject(request.Kind)} {request.TargetKey}: the requester tried to {DecisionVerb(decision)} their own request.", cancellationToken);
                    throw new WorkflowException(WorkflowErrorKind.Forbidden, $"{Capital(AccessTeams.WithArticle(request.Team))} Checker other than you must approve or reject your request.");
                }

                if (request.Kind == AccessKinds.User)
                {
                    RequireNotSelf(request.TargetKey);
                }
                else
                {
                    RequireNotHolding(request.TargetKey);
                }

                if (decision == AccessRequestStatus.Rejected && string.IsNullOrEmpty(comment))
                {
                    throw new WorkflowException(WorkflowErrorKind.Invalid, "Say why the change is rejected.");
                }
            }

            if (decision == AccessRequestStatus.Approved)
            {
                // Checked again: roles or people may have changed since the request was made.
                try
                {
                    UserChangeDto deletedUser;
                    if (CompatPattern.Is(request.User, out deletedUser) && object.Equals(deletedUser.Delete, true))
                    {
                        if (state.Users.FirstOrDefault(u => SameName(u.UserName, deletedUser.UserName)) == null)
                        {
                            throw new WorkflowException(WorkflowErrorKind.Invalid, $"{deletedUser.UserName} is no longer in the list.");
                        }
                    }
                    else 
                    {
                        UserChangeDto user;
    if (CompatPattern.Is(request.User, out user))
                    {
                        ValidateUser(user, state.Users.FirstOrDefault(u => SameName(u.UserName, user.UserName)), state, requireChange: false);
                    }
                    else 
                    {
                        RoleChangeDto deletedRole;
    if (CompatPattern.Is(request.Role, out deletedRole) && object.Equals(deletedRole.Delete, true))
                    {
                        ValidateRoleDeletion(state.Roles.FirstOrDefault(r => SameName(r.Key, deletedRole.Key))
                            ?? CompatThrow.As<AdminRoleDto>(new WorkflowException(WorkflowErrorKind.Invalid, $"There is no role {deletedRole.Key}.")), state);
                    }
                    else 
                    {
                        RoleChangeDto role;
    if (CompatPattern.Is(request.Role, out role))
                    {
                        var current = state.Roles.FirstOrDefault(r => SameName(r.Key, role.Key));
                        if (current == null && state.DeletedRoleKeys.Contains(role.Key, StringComparer.OrdinalIgnoreCase))
                        {
                            throw new WorkflowException(WorkflowErrorKind.Invalid, $"A deleted role used the key {role.Key}.");
                        }

                        ValidateRole(role, current, state, requireChange: false);
                    }
                    else 
                    {
                        RoleGroupsChangeDto groups;
    if (CompatPattern.Is(request.Groups, out groups))
                    {
                        ValidateGroups(groups, state.Roles.FirstOrDefault(r => SameName(r.Key, groups.RoleKey))
                            ?? CompatThrow.As<AdminRoleDto>(new WorkflowException(WorkflowErrorKind.Invalid, $"There is no role {groups.RoleKey}.")), requireChange: false);
                    }
                    else
                    {
                        throw new WorkflowException(WorkflowErrorKind.Invalid, "The request has no change.");
                    }
                    }
                    }
                    }
                    }
                }
                catch (WorkflowException ex) when (ex.Kind == WorkflowErrorKind.Invalid)
                {
                    throw new WorkflowException(WorkflowErrorKind.Conflict, $"This change can no longer be approved: {ex.Message} Reject it instead.");
                }
            }

            var version = Version(body.Version);
            bool decided;
            try
            {
                decided = await repository.DecideAsync(request, version, decision, currentUser.Name, DateTimeOffset.UtcNow, comment, cancellationToken);
            }
            catch (AccessDecisionRefusedException ex)
            {
                throw new WorkflowException(WorkflowErrorKind.Forbidden, ex.Message);
            }
            catch (ConcurrencyConflictException)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, "This request was decided or changed by someone else. Reload and try again.");
            }

            if (!decided)
            {
                return false;
            }

            if (decision == AccessRequestStatus.Approved)
            {
                access.Invalidate();
            }

            await AuditAsync(decision == AccessRequestStatus.Approved ? "Access change approved" : decision == AccessRequestStatus.Rejected ? "Access change rejected" : "Access change cancelled",
                $"{Subject(request.Kind)} {request.TargetKey}: {request.Summary} Requested by {request.RequestedBy}."
                    + (string.IsNullOrEmpty(comment) ? "" : $" Comment: {comment}"), cancellationToken);
            return true;
        }

        // ------------------------------------------------------------------ people (SRAU)

        private static UserChangeDto CleanUser(UserChangeDto change)
        {
            var name = (change.UserName ?? "").Trim();
            if (name.Length == 0 || name.Length > 256 || !UserNameRegex().IsMatch(name) || name.Count(ch => ch == '\\') > 1)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid,
                    "Enter the person's Active Directory account, e.g. CORP\\jdelacruz or jdelacruz@corp.local (at most 256 characters).");
            }

            var display = string.IsNullOrWhiteSpace(change.DisplayName) ? null : change.DisplayName.Trim();
            if (display != null && display.Length > 200 || (display?.Any(char.IsControl) ?? false))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "The display name must be at most 200 characters.");
            }

            var department = string.IsNullOrWhiteSpace(change.Department) ? null : change.Department.Trim();
            if (department != null && department.Length > 100 || (department?.Any(char.IsControl) ?? false))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "The branch or department must be at most 100 characters.");
            }

            return new UserChangeDto
            {
                UserName = name,
                DisplayName = display,
                IsActive = change.IsActive,
                Department = department,
                AccessUntil = change.AccessUntil,
                Roles = (change.Roles ?? new List<string>()).Select(r => (r ?? "").Trim()).Where(r => r.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
                Delete = change.Delete
            };
        }

        private static void ValidateUser(UserChangeDto change, AdminUserDto current, AccessAdministrationDto state, bool requireChange = true)
        {
            foreach (var key in change.Roles)
            {
                var role = state.Roles.FirstOrDefault(r => SameName(r.Key, key))
                           ?? CompatThrow.As<AdminRoleDto>(new WorkflowException(WorkflowErrorKind.Invalid, $"There is no role {key}."));
                var alreadyHeld = current?.Roles.Contains(role.Key, StringComparer.OrdinalIgnoreCase) == true;
                if (!role.IsActive && !alreadyHeld)
                {
                    throw new WorkflowException(WorkflowErrorKind.Invalid, $"Role {role.Key} is disabled and cannot be given.");
                }
            }

            string conflict;
            if (change.IsActive && CompatPattern.Is(AccessRules.Conflict(PermissionsOf(change.Roles, state)), out conflict))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"These roles cannot be held together: {conflict}");
            }

            DateOnly until;
            if (requireChange && CompatPattern.Is(change.AccessUntil, out until) && until != current?.AccessUntil && until < DateOnly.FromDateTime(DateTime.Now))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "The last day of access cannot be in the past. To end the access now, disable the person.");
            }

            if (requireChange && current != null && Same(current, change))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Nothing changes: the person already has exactly this access.");
            }

            if (requireChange && current == null && change.Roles.Count == 0 && change.IsActive)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Give the person at least one role, or add them as disabled to block their access.");
            }
        }

        private static string Until(DateOnly? date) => date?.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture) ?? "no end";

        private static string DescribeUserDeletion(AdminUserDto current) =>
            $"Delete {current.UserName}{((current.DisplayName == null) ? "" : $" ({current.DisplayName})")} from the list: the roles given in the app"
            + (current.Roles.Count == 0 ? "" : $" ({string.Join(", ", current.Roles.Order(StringComparer.OrdinalIgnoreCase))})")
            + " are removed; roles from their AD groups still apply.";

        private static bool Same(AdminUserDto current, UserChangeDto change) =>
            current.IsActive == change.IsActive
            && string.Equals(current.DisplayName ?? "", change.DisplayName ?? "", StringComparison.Ordinal)
            && string.Equals(current.Department ?? "", change.Department ?? "", StringComparison.Ordinal)
            && current.AccessUntil == change.AccessUntil
            && current.Roles.ToHashSet(StringComparer.OrdinalIgnoreCase).SetEquals(change.Roles);

        private static string DescribeUser(UserChangeDto change, AdminUserDto current)
        {
            if (current == null)
            {
                return $"Add {change.UserName}{((change.DisplayName == null) ? "" : $" ({change.DisplayName})")} with roles: {Roles(change.Roles)}"
                    + ((change.Department == null) ? "" : $"; branch/department {change.Department}")
                    + ((change.AccessUntil == null) ? "" : $"; access until {Until(change.AccessUntil)}")
                    + (change.IsActive ? "." : ", disabled.");
            }

            var parts = new List<string>();
            if (!current.Roles.ToHashSet(StringComparer.OrdinalIgnoreCase).SetEquals(change.Roles))
            {
                parts.Add($"Roles: {Roles(current.Roles)} → {Roles(change.Roles)}");
            }

            if (current.IsActive != change.IsActive)
            {
                parts.Add(change.IsActive ? "Enable" : "Disable (no access at all)");
            }

            if (!string.Equals(current.DisplayName ?? "", change.DisplayName ?? "", StringComparison.Ordinal))
            {
                parts.Add($"Name: {current.DisplayName ?? "(none)"} → {change.DisplayName ?? "(none)"}");
            }

            if (!string.Equals(current.Department ?? "", change.Department ?? "", StringComparison.Ordinal))
            {
                parts.Add($"Branch/department: {current.Department ?? "(none)"} → {change.Department ?? "(none)"}");
            }

            if (current.AccessUntil != change.AccessUntil)
            {
                parts.Add($"Access until: {Until(current.AccessUntil)} → {Until(change.AccessUntil)}");
            }

            return string.Join("; ", parts) + ".";
        }

        // ------------------------------------------------------------------ roles (PARAM)

        private static RoleChangeDto CleanRole(RoleChangeDto change)
        {
            var key = (change.Key ?? "").Trim();
            if (!RoleKeyRegex().IsMatch(key))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid,
                    "The role key must start with a letter and have 2 to 50 letters, digits, '-' or '_' (e.g. Viewer).");
            }

            var name = (change.DisplayName ?? "").Trim();
            if (name.Length == 0 || name.Length > 100 || name.Any(char.IsControl))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Enter a role name of at most 100 characters.");
            }

            var description = string.IsNullOrWhiteSpace(change.Description) ? null : change.Description.Trim();
            if (description != null && description.Length > 500 || (description?.Any(ch => char.IsControl(ch) && !(ch == '\n') && !(ch == '\r')) ?? false))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "The description must be at most 500 characters.");
            }

            return new RoleChangeDto
            {
                Key = key,
                DisplayName = name,
                Description = description,
                IsActive = change.IsActive,
                Permissions = (change.Permissions ?? new List<string>()).Select(p => (p ?? "").Trim()).Where(p => p.Length > 0).Distinct(StringComparer.Ordinal).ToList()
            };
        }

        private static void ValidateRole(RoleChangeDto change, AdminRoleDto current, AccessAdministrationDto state, bool requireChange = true)
        {
            var unknown = change.Permissions.Where(p => !state.Permissions.Any(x => x.Key == p)).ToList();
            if (unknown.Count > 0)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"Unknown permission(s): {string.Join(", ", unknown)}.");
            }

            if (current == null && !change.IsActive)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "A new role starts enabled.");
            }

            string conflict;
            if (CompatPattern.Is(AccessRules.Conflict(change.Permissions), out conflict))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"This role cannot have these permissions together: {conflict}");
            }

            // People SRAU gave this role together with others must not end up with a forbidden combination.
            var clashes = new List<string>();
            foreach (var user in state.Users.Where(u => u.IsActive && u.Roles.Contains(change.Key, StringComparer.OrdinalIgnoreCase)))
            {
                var permissions = PermissionsOf(user.Roles.Where(r => !SameName(r, change.Key)), state)
                    .Concat(change.IsActive ? change.Permissions : new List<string>());
                if (AccessRules.Conflict(permissions) != null)
                {
                    clashes.Add(user.UserName);
                }
            }

            if (clashes.Count > 0)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid,
                    $"With these permissions, people who also hold other roles would break the segregation of duties: {string.Join(", ", clashes.Take(10))}"
                    + (clashes.Count > 10 ? $" and {clashes.Count - 10} more" : "") + ". Ask SRAU to change their roles first.");
            }

            if (requireChange && current != null
                && current.IsActive == change.IsActive
                && string.Equals(current.DisplayName, change.DisplayName, StringComparison.Ordinal)
                && string.Equals(current.Description ?? "", change.Description ?? "", StringComparison.Ordinal)
                && current.Permissions.ToHashSet(StringComparer.Ordinal).SetEquals(change.Permissions))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Nothing changes: the role is already exactly like this.");
            }
        }

        /// <summary>A role can be deleted only when nobody in the app's list holds it (SRAU changes their roles first).</summary>
        private static void ValidateRoleDeletion(AdminRoleDto role, AccessAdministrationDto state)
        {
            var holders = state.Users.Where(u => u.Roles.Contains(role.Key, StringComparer.OrdinalIgnoreCase)).Select(u => u.UserName).ToList();
            if (holders.Count > 0)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid,
                    $"Role {role.Key} is still given to {string.Join(", ", holders.Take(10))}"
                    + (holders.Count > 10 ? $" and {holders.Count - 10} more" : "") + ". Ask SRAU to remove it from them first.");
            }
        }

        private static string DescribeRoleDeletion(AdminRoleDto role) =>
            $"Delete role {role.Key} ({role.DisplayName}): nobody gets it any more"
            + (role.DirectoryGroups.Count == 0 ? "" : $", and its AD groups ({string.Join(", ", role.DirectoryGroups)}) no longer grant it")
            + ". Its key cannot be used again.";

        private static string DescribeRole(RoleChangeDto change, AdminRoleDto current)
        {
            if (current == null)
            {
                return $"New role {change.Key} ({change.DisplayName}); permissions: {List(change.Permissions)}.";
            }

            var parts = new List<string>();
            var added = change.Permissions.Except(current.Permissions, StringComparer.Ordinal).ToList();
            var removed = current.Permissions.Except(change.Permissions, StringComparer.Ordinal).ToList();
            if (added.Count > 0) parts.Add($"Add permissions: {List(added)}");
            if (removed.Count > 0) parts.Add($"Remove permissions: {List(removed)}");
            if (current.IsActive != change.IsActive) parts.Add(change.IsActive ? "Enable the role" : "Disable the role (nobody gets it)");
            if (!string.Equals(current.DisplayName, change.DisplayName, StringComparison.Ordinal)) parts.Add($"Name: {current.DisplayName} → {change.DisplayName}");
            if (!string.Equals(current.Description ?? "", change.Description ?? "", StringComparison.Ordinal)) parts.Add("New description");
            return string.Join("; ", parts) + ".";
        }

        // ------------------------------------------------------------------ Active Directory groups (SRAU or PARAM)

        private static RoleGroupsChangeDto CleanGroups(RoleGroupsChangeDto change)
        {
            var groups = (change.DirectoryGroups ?? new List<string>()).Select(g => (g ?? "").Trim()).Where(g => g.Length > 0)
                .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            if (groups.Count > MaxGroupsPerRole || groups.Any(g => g.Length > 256 || !UserNameRegex().IsMatch(g) || g.Count(ch => ch == '\\') > 1))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid,
                    $"Enter at most {MaxGroupsPerRole} Active Directory groups, one per line, e.g. CORP\\FRP-Makers (at most 256 characters each).");
            }

            return new RoleGroupsChangeDto { RoleKey = (change.RoleKey ?? "").Trim(), DirectoryGroups = groups };
        }

        private static void ValidateGroups(RoleGroupsChangeDto change, AdminRoleDto role, bool requireChange = true)
        {
            if (requireChange && role.DirectoryGroups.ToHashSet(StringComparer.OrdinalIgnoreCase).SetEquals(change.DirectoryGroups))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Nothing changes: the role already has exactly these AD groups.");
            }
        }

        private static string DescribeGroups(RoleGroupsChangeDto change, AdminRoleDto role)
        {
            var added = change.DirectoryGroups.Except(role.DirectoryGroups, StringComparer.OrdinalIgnoreCase).ToList();
            var removed = role.DirectoryGroups.Except(change.DirectoryGroups, StringComparer.OrdinalIgnoreCase).ToList();
            var parts = new List<string>();
            if (added.Count > 0) parts.Add($"Add AD groups: {ListLocal(added)}");
            if (removed.Count > 0) parts.Add($"Remove AD groups: {ListLocal(removed)}");
            return string.Join("; ", parts) + ".";
        }

        // ------------------------------------------------------------------ helpers

        private bool IsAdministrator => currentUser.IsAuthenticated && Permissions.Administration.Any(currentUser.HasPermission);

        /// <summary>The team whose Maker the signed-in person is: SRAU or PARAM (nobody holds both: the roles forbid it).</summary>
        private string MakerTeamOfCurrentUser() =>
            !currentUser.IsAuthenticated ? null
            : currentUser.HasPermission(Permissions.UsersManage) ? AccessTeams.Users
            : currentUser.HasPermission(Permissions.RolesManage) ? AccessTeams.Roles
            : null;

        private static string TeamName(string team) => AccessTeams.Name(team);

        private static string Capital(string text) => text.Length == 0 ? text : char.ToUpperInvariant(text[0]) + text.Substring(1);

        private static string DecisionVerb(string decision) => decision == AccessRequestStatus.Approved ? "approve" : "reject";

        private static string Subject(string kind) => kind == AccessKinds.User ? "Person" : kind == AccessKinds.Groups ? "AD groups of role" : "Role";

        private async Task<AccessChangeRequestDto> CreateAsync(string team, string kind, string target, string summary, UserChangeDto user, RoleChangeDto role,
            RoleGroupsChangeDto groups, CancellationToken cancellationToken, object before = null)
        {
            var request = new AccessChangeRequestDto
            {
                Id = Guid.NewGuid().ToString("N"),
                Team = team,
                Kind = kind,
                TargetKey = target,
                Summary = summary.Length > 2000 ? summary.Substring(0, 1997) + "…" : summary,
                User = user,
                Role = role,
                Groups = groups,
                UserBefore = before as UserChangeDto,
                RoleBefore = before as RoleChangeDto,
                GroupsBefore = before as RoleGroupsChangeDto,
                RequestedBy = currentUser.Name,
                RequestedAt = DateTimeOffset.UtcNow
            };
            try
            {
                request = await repository.CreateRequestAsync(request, cancellationToken);
            }
            catch (AccessRequestOpenException)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, kind == AccessKinds.User ? "This person already has a change waiting for approval. Approve, reject or cancel it first." : kind == AccessKinds.Groups ? "This role's AD groups already have a change waiting for approval. Approve, reject or cancel it first." : "This role already has a change waiting for approval. Approve, reject or cancel it first.");
            }

            await AuditAsync("Access change requested", $"{Subject(kind)} {target}: {request.Summary} ({TeamName(team)})", cancellationToken);
            return request;
        }

        /// <summary>The person as they are now (the old values of a change).</summary>
        private static UserChangeDto Snapshot(AdminUserDto user) => new UserChangeDto() {
            UserName = user.UserName, DisplayName = user.DisplayName, IsActive = user.IsActive, Roles = user.Roles.ToList(),
            Department = user.Department, AccessUntil = user.AccessUntil
        };

        /// <summary>The role as it is now (the old values of a change).</summary>
        private static RoleChangeDto Snapshot(AdminRoleDto role) => new RoleChangeDto() {
            Key = role.Key, DisplayName = role.DisplayName, Description = role.Description, IsActive = role.IsActive, Permissions = role.Permissions.ToList()
        };

        private void RequireNotSelf(string userName)
        {
            if (SameName(userName, currentUser.Name))
            {
                throw new WorkflowException(WorkflowErrorKind.Forbidden, "You cannot request or approve a change to your own access.");
            }
        }

        private void RequireNotHolding(string roleKey)
        {
            if (currentUser.Roles.Contains(roleKey, StringComparer.OrdinalIgnoreCase))
            {
                throw new WorkflowException(WorkflowErrorKind.Forbidden, $"You hold the role {roleKey}, so you cannot request or approve changes to it.");
            }
        }

        private static IEnumerable<string> PermissionsOf(IEnumerable<string> roleKeys, AccessAdministrationDto state)
        {
            var keys = roleKeys.ToHashSet(StringComparer.OrdinalIgnoreCase);
            return state.Roles.Where(r => r.IsActive && keys.Contains(r.Key)).SelectMany(r => r.Permissions);
        }

        private static byte[] Version(string value)
        {
            try
            {
                var bytes = Convert.FromBase64String(value ?? "");
                return bytes.Length == 8 ? bytes : CompatThrow.As<byte[]>(new FormatException());
            }
            catch (FormatException)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Reload the page and try again.");
            }
        }

        private static bool SameName(string a, string b) => string.Equals(a?.Trim(), b?.Trim(), StringComparison.OrdinalIgnoreCase);

        private Task AuditAsync(string action, string details, CancellationToken cancellationToken) =>
            auditLog.AppendAsync(new AuditEntryDto
            {
                Id = Guid.NewGuid().ToString("N"),
                At = DateTimeOffset.UtcNow,
                User = currentUser.Name,
                Action = action,
                Details = details
            }, cancellationToken);

            private static System.Text.RegularExpressions.Regex UserNameRegex() { return UserNameRegexInstance; }

        private static System.Text.RegularExpressions.Regex RoleKeyRegex() { return RoleKeyRegexInstance; }

            private static string Roles(IEnumerable<string> roles)
    {
        return roles.Any() ? string.Join(", ", roles.Order(StringComparer.OrdinalIgnoreCase)) : "none";
    }

            private static string List(IEnumerable<string> items)
    {
        return items.Any() ? string.Join(", ", items) : "none";
    }

            private static string ListLocal(IEnumerable<string> items)
    {
        return string.Join(", ", items);
    }

        private static readonly System.Text.RegularExpressions.Regex UserNameRegexInstance = new System.Text.RegularExpressions.Regex(@"^[^\p{C}""/\[\]:;|=,+*?<>]+$", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);

        private static readonly System.Text.RegularExpressions.Regex RoleKeyRegexInstance = new System.Text.RegularExpressions.Regex(@"^[A-Za-z][A-Za-z0-9_-]{1,49}$", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

}
