﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL.Cocree
{
    /// <summary>
    /// The COCREE configuration in the shape the export and the validation use. It is built from the files the Regulatory
    /// Reports Workbench kept in its Config folder:
    /// <list type="bullet">
    /// <item>cocree_config.xlsx: the input files (input_files), their sheets (input_file_sheets) and columns
    /// (input_file_sheet_columns), the XML elements and attributes (xml_entities), which column fills which attribute
    /// (xml_mapping) and which "Record Type" on which sheet becomes which element (source_record_type);</item>
    /// <item>cocree_dropdown_options.xlsx: one code list per sheet, turning the BU's wording (input_template) into BSP's
    /// code (xml_code);</item>
    /// <item>cocree_validations.xlsx: BSP's validation rules, one formula per element and error code;</item>
    /// <item>optionally BSP's COCREE XSD, which the validation checks the files against.</item>
    /// </list>
    /// Identifiers are compared as the Workbench did: as text, without regard to case or surrounding spaces.
    /// </summary>
    public sealed class CocreeConfiguration
    {
        // The sheets and columns the export reads. Other sheets and columns may be present and are kept.
        private static readonly Dictionary<string, string[]> RequiredColumns = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
        {
            { "input_files", new[] { "source_filename_id", "filename", "subject_hierarchy" } },
            { "input_file_sheets", new[] { "source_file_sheet_id", "source_filename_id", "sheet_name" } },
            { "input_file_sheet_columns", new[] { "column_id", "source_file_sheet_id", "column_name" } },
            { "xml_entities", new[] { "attribute_id", "element", "attribute", "data_type", "dropdown" } },
            { "xml_mapping", new[] { "column_id", "attribute_id", "column_name" } },
            { "source_record_type", new[] { "element", "source_file_sheet_id", "record_type", "xml_body_sequence" } }
        };

        public const string FileInfoSheet = "FILE INFO";

        private CocreeConfiguration()
        {
        }

        public IReadOnlyList<InputFile> InputFiles { get; private set; }

        public IReadOnlyList<InputSheet> Sheets { get; private set; }

        public IReadOnlyList<InputColumn> Columns { get; private set; }

        public IReadOnlyList<XmlAttribute> Attributes { get; private set; }

        public IReadOnlyList<ColumnMapping> Mappings { get; private set; }

        public IReadOnlyList<RecordTypeRule> RecordTypes { get; private set; }

        /// <summary>
        /// Code list name (upper case) → the BU's wording (cleaned) → BSP's code. When a wording is listed twice, the first
        /// row counts, as in the Workbench.
        /// </summary>
        public IReadOnlyDictionary<string, IReadOnlyDictionary<string, string>> CodeLists { get; private set; }

        /// <summary>BSP's validation rules (cocree_validations.xlsx), in the workbook's order.</summary>
        public IReadOnlyList<CocreeValidationRule> ValidationRules { get; private set; }

        /// <summary>BSP's COCREE XSD (text) and its file name; empty when none was uploaded.</summary>
        public string Xsd { get; private set; }

        public string XsdFileName { get; private set; }

        /// <summary>The same text the Workbench compared: upper case, without surrounding spaces.</summary>
        public static string Clean(string value)
        {
            return (value ?? "").Trim().ToUpperInvariant();
        }

        // ---------- reading the uploaded workbooks ----------

        /// <summary>
        /// The configuration as uploaded: every sheet of the three workbooks, cells as text (empty rows are left out), and
        /// the XSD as text when one is given.
        /// </summary>
        public static CocreeConfigDto FromFiles(Stream configWorkbook, Stream codeListWorkbook, Stream validationWorkbook, string xsdFileName, string xsd)
        {
            return new CocreeConfigDto
            {
                Tables = CocreeWorkbookReader.Read(configWorkbook).Select(ToTable).ToList(),
                CodeLists = CocreeWorkbookReader.Read(codeListWorkbook).Select(ToTable).ToList(),
                Validations = CocreeWorkbookReader.Read(validationWorkbook).Select(ToTable).ToList(),
                Xsd = xsd ?? "",
                XsdFileName = string.IsNullOrEmpty(xsd) ? "" : xsdFileName ?? ""
            };
        }

        private static WorkbenchTableDto ToTable(CocreeSheet sheet)
        {
            var table = new WorkbenchTableDto { Name = sheet.Name, Columns = sheet.Columns.ToList() };
            foreach (var row in sheet.Rows)
            {
                if (row.Any(cell => !cell.IsEmpty))
                {
                    table.Rows.Add(row.Select(cell => cell.Value).ToList());
                }
            }

            return table;
        }

        // ---------- checking and typing ----------

        /// <summary>
        /// Reads a stored configuration. <paramref name="problems"/> lists what makes it unusable (it is null then) and
        /// <paramref name="notes"/> what is odd but harmless (rows the export ignores, as the Workbench did).
        /// </summary>
        public static CocreeConfiguration Load(CocreeConfigDto content, List<string> problems, List<string> notes)
        {
            var tables = new Dictionary<string, Table>(StringComparer.OrdinalIgnoreCase);
            foreach (var table in content.Tables)
            {
                if (!tables.ContainsKey(table.Name.Trim()))
                {
                    tables[table.Name.Trim()] = new Table(table);
                }
            }

            foreach (var required in RequiredColumns)
            {
                Table table;
                if (!tables.TryGetValue(required.Key, out table))
                {
                    problems.Add("The configuration workbook has no sheet named " + required.Key + ".");
                    continue;
                }

                foreach (var column in required.Value.Where(c => !table.Has(c)))
                {
                    problems.Add("The sheet " + required.Key + " has no column " + column + ".");
                }
            }

            if (problems.Count > 0)
            {
                return null;
            }

            var configuration = new CocreeConfiguration();
            configuration.InputFiles = ReadInputFiles(tables["input_files"], problems);
            configuration.Sheets = ReadSheets(tables["input_file_sheets"], configuration.InputFiles, problems);
            configuration.Columns = ReadColumns(tables["input_file_sheet_columns"], configuration.Sheets, problems, notes);
            configuration.CodeLists = ReadCodeLists(content.CodeLists, problems);
            configuration.Attributes = ReadAttributes(tables["xml_entities"], configuration.CodeLists, problems);
            configuration.Mappings = ReadMappings(tables["xml_mapping"], configuration.Columns, configuration.Attributes, notes);
            configuration.RecordTypes = ReadRecordTypes(tables["source_record_type"], configuration.Sheets, configuration.Attributes, problems);
            configuration.ValidationRules = CocreeValidationRule.Read(content.Validations ?? new List<WorkbenchTableDto>(), problems, notes);
            configuration.Xsd = content.Xsd ?? "";
            configuration.XsdFileName = content.XsdFileName ?? "";

            foreach (var part in new[] { "Header", "Footer" })
            {
                if (!configuration.Attributes.Any(a => Clean(a.Element) == Clean(part)))
                {
                    problems.Add("xml_entities has no attributes for the " + part + " element.");
                }
            }

            foreach (var file in configuration.InputFiles)
            {
                var fileInfo = configuration.Sheets.FirstOrDefault(s => s.FileId == file.Id && Clean(s.Name) == FileInfoSheet);
                if (fileInfo == null)
                {
                    problems.Add("The input file " + file.Name + " has no File Info sheet in input_file_sheets.");
                }
                else
                {
                    var columns = configuration.Columns.Where(c => c.SheetId == fileInfo.Id).Select(c => Clean(c.Name)).ToList();
                    foreach (var column in new[] { "FILE", "MONTH", "YEAR" }.Where(c => !columns.Contains(c)))
                    {
                        problems.Add("The File Info sheet of " + file.Name + " has no " + column.ToLowerInvariant() + " column in input_file_sheet_columns.");
                    }
                }
            }

            if (problems.Count > 0)
            {
                return null;
            }

            // Every rule must be a formula the validation can evaluate on its element's attributes (the Workbench refused
            // to validate when one could not be added), and the XSD must be a schema.
            problems.AddRange(CocreeValidator.FormulaProblems(configuration));
            if (configuration.Xsd.Length > 0)
            {
                var xsdProblem = XmlSchemaChecker.SchemaProblem(configuration.Xsd);
                if (xsdProblem != null)
                {
                    problems.Add("The XSD " + configuration.XsdFileName + " cannot be used: " + xsdProblem);
                }
            }

            return problems.Count > 0 ? null : configuration;
        }

        /// <summary>The summary shown with a version: how many files, sheets, columns, … it has.</summary>
        public WorkbenchConfigSummaryDto Summary()
        {
            var facts = new List<WorkbenchConfigFactDto>
            {
                Fact("input files", InputFiles.Count),
                Fact("sheets", Sheets.Count),
                Fact("columns", Columns.Count),
                Fact("XML attributes", Attributes.Count),
                Fact("column mappings", Mappings.Count),
                Fact("record types", RecordTypes.Count),
                Fact("code lists", CodeLists.Count),
                Fact("codes", CodeLists.Values.Sum(list => list.Count)),
                Fact("validation rules", ValidationRules.Count),
                Fact(Xsd.Length > 0 ? "XSD (" + XsdFileName + ")" : "XSD", Xsd.Length > 0 ? 1 : 0)
            };
            return new WorkbenchConfigSummaryDto { Facts = facts };
        }

        private static WorkbenchConfigFactDto Fact(string label, int count)
        {
            return new WorkbenchConfigFactDto { Label = label, Count = count };
        }

        /// <summary>One line per sheet that differs between two configurations ("xml_mapping: 3 rows added, 1 removed").</summary>
        public static List<string> Differences(CocreeConfigDto before, CocreeConfigDto after)
        {
            var lines = new List<string>();
            Compare("", before.Tables, after.Tables, lines);
            Compare("code list ", before.CodeLists, after.CodeLists, lines);
            Compare("validations ", before.Validations ?? new List<WorkbenchTableDto>(), after.Validations ?? new List<WorkbenchTableDto>(), lines);
            if ((before.Xsd ?? "") != (after.Xsd ?? ""))
            {
                lines.Add(string.IsNullOrEmpty(after.Xsd) ? "XSD removed." : string.IsNullOrEmpty(before.Xsd) ? "XSD added (" + after.XsdFileName + ")." : "XSD changed (" + after.XsdFileName + ").");
            }

            return lines;
        }

        public static void Compare(string prefix, List<WorkbenchTableDto> before, List<WorkbenchTableDto> after, List<string> lines)
        {
            var names = before.Select(t => t.Name).Union(after.Select(t => t.Name), StringComparer.OrdinalIgnoreCase).ToList();
            foreach (var name in names)
            {
                var old = before.FirstOrDefault(t => string.Equals(t.Name, name, StringComparison.OrdinalIgnoreCase));
                var now = after.FirstOrDefault(t => string.Equals(t.Name, name, StringComparison.OrdinalIgnoreCase));
                if (old == null)
                {
                    lines.Add(prefix + name + ": new sheet with " + Rows(now.Rows.Count) + ".");
                    continue;
                }

                if (now == null)
                {
                    lines.Add(prefix + name + ": sheet removed (it had " + Rows(old.Rows.Count) + ").");
                    continue;
                }

                // Rows are compared as a whole: a changed row counts as one removed and one added.
                var remaining = old.Rows.Select(RowText).GroupBy(r => r).ToDictionary(g => g.Key, g => g.Count());
                var added = 0;
                foreach (var row in now.Rows.Select(RowText))
                {
                    int count;
                    if (remaining.TryGetValue(row, out count) && count > 0)
                    {
                        remaining[row] = count - 1;
                    }
                    else
                    {
                        added++;
                    }
                }

                var removed = remaining.Values.Sum();
                var columnsChanged = !old.Columns.SequenceEqual(now.Columns, StringComparer.Ordinal);
                if (added > 0 || removed > 0 || columnsChanged)
                {
                    var parts = new List<string>();
                    if (columnsChanged) parts.Add("columns changed");
                    if (added > 0) parts.Add(Rows(added) + " added");
                    if (removed > 0) parts.Add(Rows(removed) + " removed");
                    lines.Add(prefix + name + ": " + string.Join(", ", parts) + ".");
                }
            }
        }

        private static bool IsXmlName(string name)
        {
            try
            {
                System.Xml.XmlConvert.VerifyNCName(name);
                return true;
            }
            catch (System.Xml.XmlException)
            {
                return false;
            }
            catch (ArgumentNullException)
            {
                return false;
            }
        }

        private static string RowText(List<string> row)
        {
            return string.Join("\u001f", row);
        }

        private static string Rows(int count)
        {
            return count.ToString("N0", CultureInfo.InvariantCulture) + (count == 1 ? " row" : " rows");
        }

        // ---------- reading each sheet ----------

        private static List<InputFile> ReadInputFiles(Table table, List<string> problems)
        {
            var files = new List<InputFile>();
            foreach (var row in table.Rows.Where(r => table.Text(r, "source_filename_id").Length > 0))
            {
                int hierarchy;
                var id = Clean(table.Text(row, "source_filename_id"));
                var name = table.Text(row, "filename");
                if (!int.TryParse(table.Text(row, "subject_hierarchy"), NumberStyles.Integer, CultureInfo.InvariantCulture, out hierarchy))
                {
                    problems.Add("input_files: the subject_hierarchy of " + name + " must be a whole number.");
                }

                if (files.Any(f => f.Id == id))
                {
                    problems.Add("input_files: the source_filename_id " + id + " is used twice.");
                }

                if (files.Any(f => Clean(f.Name) == Clean(name)))
                {
                    problems.Add("input_files: the filename " + name + " is listed twice.");
                }

                files.Add(new InputFile(id, name.Trim(), hierarchy));
            }

            if (files.Count == 0)
            {
                problems.Add("input_files lists no input file.");
            }

            return files;
        }

        private static List<InputSheet> ReadSheets(Table table, IReadOnlyList<InputFile> files, List<string> problems)
        {
            var sheets = new List<InputSheet>();
            foreach (var row in table.Rows.Where(r => table.Text(r, "source_file_sheet_id").Length > 0))
            {
                var id = Clean(table.Text(row, "source_file_sheet_id"));
                var fileId = Clean(table.Text(row, "source_filename_id"));
                if (sheets.Any(s => s.Id == id))
                {
                    problems.Add("input_file_sheets: the source_file_sheet_id " + id + " is used twice.");
                }

                if (!files.Any(f => f.Id == fileId))
                {
                    problems.Add("input_file_sheets: the sheet " + id + " belongs to source_filename_id " + fileId + ", which input_files does not have.");
                }

                sheets.Add(new InputSheet(id, fileId, table.Text(row, "sheet_name").Trim()));
            }

            return sheets;
        }

        private static List<InputColumn> ReadColumns(Table table, IReadOnlyList<InputSheet> sheets, List<string> problems, List<string> notes)
        {
            var columns = new List<InputColumn>();
            var ids = new HashSet<string>();
            var withoutSheet = 0;
            foreach (var row in table.Rows.Where(r => table.Text(r, "column_id").Length > 0))
            {
                var id = Clean(table.Text(row, "column_id"));
                var sheetId = Clean(table.Text(row, "source_file_sheet_id"));
                if (!ids.Add(id))
                {
                    problems.Add("input_file_sheet_columns: the column_id " + id + " is used twice.");
                }

                if (sheetId.Length == 0 || !sheets.Any(s => s.Id == sheetId))
                {
                    withoutSheet++;
                    continue;
                }

                columns.Add(new InputColumn(id, sheetId, table.Text(row, "column_name").Trim()));
            }

            if (withoutSheet > 0)
            {
                notes.Add("input_file_sheet_columns: " + Rows(withoutSheet) + " without a known sheet are not used.");
            }

            return columns;
        }

        private static Dictionary<string, IReadOnlyDictionary<string, string>> ReadCodeLists(List<WorkbenchTableDto> sheets, List<string> problems)
        {
            var lists = new Dictionary<string, IReadOnlyDictionary<string, string>>(StringComparer.Ordinal);
            foreach (var sheet in sheets)
            {
                var table = new Table(sheet);
                var name = Clean(sheet.Name);
                if (lists.ContainsKey(name))
                {
                    problems.Add("The code list workbook has two sheets named " + sheet.Name + ".");
                    continue;
                }

                // A sheet without input_template / xml_code (e.g. city_codes) is not a code list the export can use;
                // it is a problem only if an attribute uses it (checked with the attributes).
                if (!table.Has("input_template") || !table.Has("xml_code"))
                {
                    continue;
                }

                var codes = new Dictionary<string, string>(StringComparer.Ordinal);
                foreach (var row in table.Rows)
                {
                    var wording = Clean(table.Text(row, "input_template"));
                    if (!codes.ContainsKey(wording))
                    {
                        codes[wording] = table.Text(row, "xml_code");
                    }
                }

                lists[name] = codes;
            }

            return lists;
        }

        private static List<XmlAttribute> ReadAttributes(Table table, IReadOnlyDictionary<string, IReadOnlyDictionary<string, string>> codeLists, List<string> problems)
        {
            var attributes = new List<XmlAttribute>();
            foreach (var row in table.Rows.Where(r => table.Text(r, "attribute_id").Length > 0))
            {
                var id = Clean(table.Text(row, "attribute_id"));
                var element = table.Text(row, "element").Trim();
                var name = table.Text(row, "attribute").Trim();
                var codeList = Clean(table.Text(row, "dropdown"));
                if (attributes.Any(a => a.Id == id))
                {
                    problems.Add("xml_entities: the attribute_id " + id + " is used twice.");
                }

                if (attributes.Any(a => Clean(a.Element) == Clean(element) && Clean(a.Name) == Clean(name)))
                {
                    problems.Add("xml_entities: " + element + " has the attribute " + name + " twice.");
                }

                if (!IsXmlName(element) || !IsXmlName(name))
                {
                    problems.Add("xml_entities: '" + element + "/" + name + "' cannot be an XML element and attribute name.");
                }

                if (codeList.Length > 0 && !codeLists.ContainsKey(codeList))
                {
                    problems.Add("xml_entities: " + element + "/" + name + " uses the code list " + table.Text(row, "dropdown").Trim()
                        + ", which the code list workbook does not have (a sheet with input_template and xml_code columns).");
                }

                int order;
                int.TryParse(id, NumberStyles.Integer, CultureInfo.InvariantCulture, out order);
                var inReport = Clean(table.Text(row, "include_in_error_report")) == "TRUE";
                attributes.Add(new XmlAttribute(id, order, element, name, Clean(table.Text(row, "data_type")), codeList, inReport));
            }

            return attributes;
        }

        private static List<ColumnMapping> ReadMappings(Table table, IReadOnlyList<InputColumn> columns, IReadOnlyList<XmlAttribute> attributes, List<string> notes)
        {
            var mappings = new List<ColumnMapping>();
            var unused = 0;
            foreach (var row in table.Rows)
            {
                var columnId = Clean(table.Text(row, "column_id"));
                var attributeId = Clean(table.Text(row, "attribute_id"));
                // As in the Workbench: a mapping counts only when its column and its attribute exist.
                if (attributeId.Length == 0 || !columns.Any(c => c.Id == columnId) || !attributes.Any(a => a.Id == attributeId))
                {
                    unused++;
                    continue;
                }

                mappings.Add(new ColumnMapping(columnId, attributeId, table.Text(row, "column_name").Trim()));
            }

            if (unused > 0)
            {
                notes.Add("xml_mapping: " + Rows(unused) + " without an attribute, or naming a column or attribute that does not exist, are not used.");
            }

            return mappings;
        }

        private static List<RecordTypeRule> ReadRecordTypes(Table table, IReadOnlyList<InputSheet> sheets, IReadOnlyList<XmlAttribute> attributes, List<string> problems)
        {
            var rules = new List<RecordTypeRule>();
            foreach (var row in table.Rows.Where(r => table.Text(r, "element").Length > 0))
            {
                var element = table.Text(row, "element").Trim();
                var sheetId = Clean(table.Text(row, "source_file_sheet_id"));
                int sequence;
                if (!int.TryParse(table.Text(row, "xml_body_sequence"), NumberStyles.Integer, CultureInfo.InvariantCulture, out sequence))
                {
                    problems.Add("source_record_type: the xml_body_sequence of " + element + " on sheet " + sheetId + " must be a whole number.");
                }

                if (!sheets.Any(s => s.Id == sheetId))
                {
                    problems.Add("source_record_type: " + element + " refers to source_file_sheet_id " + sheetId + ", which input_file_sheets does not have.");
                }

                if (!attributes.Any(a => Clean(a.Element) == Clean(element)))
                {
                    problems.Add("source_record_type: the element " + element + " has no attributes in xml_entities.");
                }

                rules.Add(new RecordTypeRule(element, sheetId, table.Text(row, "record_type").Trim(), sequence));
            }

            return rules;
        }

        // ---------- the typed rows ----------

        /// <summary>An input file the BU sends (input_files).</summary>
        public sealed class InputFile
        {
            public InputFile(string id, string name, int subjectHierarchy)
            {
                Id = id;
                Name = name;
                SubjectHierarchy = subjectHierarchy;
            }

            public string Id { get; }

            /// <summary>The name written in the workbook's File Info sheet ("1. OLR - Installments").</summary>
            public string Name { get; }

            /// <summary>When a subject is in several files, the one from the file with the lowest number is kept.</summary>
            public int SubjectHierarchy { get; }
        }

        /// <summary>A sheet an input file has (input_file_sheets).</summary>
        public sealed class InputSheet
        {
            public InputSheet(string id, string fileId, string name)
            {
                Id = id;
                FileId = fileId;
                Name = name;
            }

            public string Id { get; }

            public string FileId { get; }

            public string Name { get; }
        }

        /// <summary>A column a sheet must have, in order (input_file_sheet_columns).</summary>
        public sealed class InputColumn
        {
            public InputColumn(string id, string sheetId, string name)
            {
                Id = id;
                SheetId = sheetId;
                Name = name;
            }

            public string Id { get; }

            public string SheetId { get; }

            public string Name { get; }
        }

        /// <summary>An XML attribute of an element (xml_entities); the order of the rows is the order of the attributes.</summary>
        public sealed class XmlAttribute
        {
            public XmlAttribute(string id, int order, string element, string name, string dataType, string codeList, bool includeInErrorReport)
            {
                Id = id;
                Order = order;
                Element = element;
                Name = name;
                DataType = dataType;
                CodeList = codeList;
                IncludeInErrorReport = includeInErrorReport;
            }

            public string Id { get; }

            /// <summary>The attribute_id as a number: Header and Footer attributes are written in this order.</summary>
            public int Order { get; }

            public string Element { get; }

            public string Name { get; }

            /// <summary>MONEY, DATE, INTEGER or empty (upper case).</summary>
            public string DataType { get; }

            /// <summary>The code list (upper case) that turns the BU's wording into BSP's code; empty for none.</summary>
            public string CodeList { get; }

            public bool IsMoney => DataType == "MONEY";

            /// <summary>The validation report names a wrong record by its attributes that have this set (include_in_error_report).</summary>
            public bool IncludeInErrorReport { get; }
        }

        /// <summary>Which column of a sheet fills which attribute (xml_mapping).</summary>
        public sealed class ColumnMapping
        {
            public ColumnMapping(string columnId, string attributeId, string columnName)
            {
                ColumnId = columnId;
                AttributeId = attributeId;
                ColumnName = columnName;
            }

            public string ColumnId { get; }

            public string AttributeId { get; }

            /// <summary>The column the value is read from, by name.</summary>
            public string ColumnName { get; }
        }

        /// <summary>The rows of a sheet whose "Record Type" is <see cref="RecordType"/> become <see cref="Element"/> records.</summary>
        public sealed class RecordTypeRule
        {
            public RecordTypeRule(string element, string sheetId, string recordType, int bodySequence)
            {
                Element = element;
                SheetId = sheetId;
                RecordType = recordType;
                BodySequence = bodySequence;
            }

            public string Element { get; }

            public string SheetId { get; }

            public string RecordType { get; }

            /// <summary>The position of the element in the XML Body (Individuals 1, Companies 2, …).</summary>
            public int BodySequence { get; }
        }

        /// <summary>A stored sheet with its columns found by name (without regard to case).</summary>
        private sealed class Table
        {
            private readonly Dictionary<string, int> index = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            public Table(WorkbenchTableDto table)
            {
                for (var i = 0; i < table.Columns.Count; i++)
                {
                    var name = table.Columns[i].Trim();
                    if (!index.ContainsKey(name))
                    {
                        index[name] = i;
                    }
                }

                Rows = table.Rows;
            }

            public List<List<string>> Rows { get; }

            public bool Has(string column)
            {
                return index.ContainsKey(column);
            }

            public string Text(List<string> row, string column)
            {
                int i;
                return index.TryGetValue(column, out i) && i < row.Count ? (row[i] ?? "").Trim() : "";
            }
        }
    }
}
