using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security;
using System.Text;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL.Cocree
{
    /// <summary>
    /// Writes simple .xlsx workbooks: one sheet per table, the column names in row 1 (bold) and the rows below. A cell
    /// that holds a plain number ("1", "102801000", "1234.5") is written as a number, everything else as text, so the
    /// workbook reads back exactly as it was stored. Used to download a COCREE configuration for editing in Excel.
    /// </summary>
    public static class CocreeWorkbookWriter
    {
        public static byte[] Write(IEnumerable<WorkbenchTableDto> tables)
        {
            var sheets = tables.ToList();
            using (var buffer = new MemoryStream())
            {
                using (var zip = new ZipArchive(buffer, ZipArchiveMode.Create, true))
                {
                    Add(zip, "[Content_Types].xml", ContentTypes(sheets.Count));
                    Add(zip, "_rels/.rels",
                        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                        + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
                    Add(zip, "xl/workbook.xml", Workbook(sheets));
                    Add(zip, "xl/_rels/workbook.xml.rels", WorkbookRelationships(sheets.Count));
                    Add(zip, "xl/styles.xml",
                        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                        + "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>"
                        + "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>"
                        + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                        + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                        + "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs>"
                        + "</styleSheet>");
                    for (var i = 0; i < sheets.Count; i++)
                    {
                        Add(zip, "xl/worksheets/sheet" + (i + 1).ToString(CultureInfo.InvariantCulture) + ".xml", Sheet(sheets[i]));
                    }
                }

                return buffer.ToArray();
            }
        }

        private static void Add(ZipArchive zip, string path, string content)
        {
            using (var writer = new StreamWriter(zip.CreateEntry(path, CompressionLevel.Optimal).Open(), new UTF8Encoding(false)))
            {
                writer.Write(content);
            }
        }

        private static string ContentTypes(int sheetCount)
        {
            var text = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
            for (var i = 1; i <= sheetCount; i++)
            {
                text.Append("<Override PartName=\"/xl/worksheets/sheet").Append(i).Append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            }

            return text.Append("</Types>").ToString();
        }

        private static string Workbook(List<WorkbenchTableDto> sheets)
        {
            var text = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
                + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
            for (var i = 0; i < sheets.Count; i++)
            {
                text.Append("<sheet name=\"").Append(Escape(SheetName(sheets[i].Name, i))).Append("\" sheetId=\"").Append(i + 1).Append("\" r:id=\"rId").Append(i + 1).Append("\"/>");
            }

            return text.Append("</sheets></workbook>").ToString();
        }

        /// <summary>Excel's limits on sheet names: 31 characters, none of \ / ? * [ ] :.</summary>
        private static string SheetName(string name, int index)
        {
            var clean = new string((name ?? "").Where(ch => "\\/?*[]:".IndexOf(ch) < 0).ToArray()).Trim();
            if (clean.Length == 0) clean = "Sheet" + (index + 1).ToString(CultureInfo.InvariantCulture);
            return clean.Length > 31 ? clean.Substring(0, 31) : clean;
        }

        private static string WorkbookRelationships(int sheetCount)
        {
            var text = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
            for (var i = 1; i <= sheetCount; i++)
            {
                text.Append("<Relationship Id=\"rId").Append(i).Append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").Append(i).Append(".xml\"/>");
            }

            text.Append("<Relationship Id=\"rId").Append(sheetCount + 1).Append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>");
            return text.Append("</Relationships>").ToString();
        }

        private static string Sheet(WorkbenchTableDto table)
        {
            var text = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
            AppendRow(text, 1, table.Columns, true);
            for (var r = 0; r < table.Rows.Count; r++)
            {
                AppendRow(text, r + 2, table.Rows[r], false);
            }

            return text.Append("</sheetData></worksheet>").ToString();
        }

        private static void AppendRow(StringBuilder text, int rowNumber, IList<string> cells, bool header)
        {
            text.Append("<row r=\"").Append(rowNumber).Append("\">");
            for (var c = 0; c < cells.Count; c++)
            {
                var value = cells[c] ?? "";
                if (value.Length == 0)
                {
                    continue;
                }

                var reference = ColumnName(c) + rowNumber.ToString(CultureInfo.InvariantCulture);
                double number;
                if (!header && IsPlainNumber(value, out number))
                {
                    text.Append("<c r=\"").Append(reference).Append("\"><v>").Append(value).Append("</v></c>");
                }
                else
                {
                    text.Append("<c r=\"").Append(reference).Append("\" t=\"inlineStr\"").Append(header ? " s=\"1\"" : "")
                        .Append("><is><t xml:space=\"preserve\">").Append(Escape(value)).Append("</t></is></c>");
                }
            }

            text.Append("</row>");
        }

        /// <summary>True when the text is a number that reads back as the same text ("1", "12.5"; not "007" or "1e5").</summary>
        private static bool IsPlainNumber(string value, out double number)
        {
            return double.TryParse(value, NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out number)
                && number.ToString("G15", CultureInfo.InvariantCulture) == value;
        }

        /// <summary>0 → A, 25 → Z, 26 → AA.</summary>
        internal static string ColumnName(int index)
        {
            var name = "";
            for (var n = index + 1; n > 0; n = (n - 1) / 26)
            {
                name = (char)('A' + (n - 1) % 26) + name;
            }

            return name;
        }

        private static string Escape(string text)
        {
            var clean = new string(text.Where(ch => ch >= 0x20 || ch == '\t' || ch == '\n' || ch == '\r').ToArray());
            return SecurityElement.Escape(clean);
        }
    }
}
