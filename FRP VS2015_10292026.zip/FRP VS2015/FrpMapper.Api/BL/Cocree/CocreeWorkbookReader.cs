using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace FrpMapper.Api.BL.Cocree
{
    /// <summary>What a cell holds, as the Regulatory Reports Workbench's Excel reader (ExcelDataReader) gave it.</summary>
    public enum CocreeCellKind
    {
        Empty,
        Text,
        Number,
        Date,
        Boolean
    }

    /// <summary>One cell of a COCREE workbook.</summary>
    public struct CocreeCell
    {
        public static readonly CocreeCell Empty = new CocreeCell(CocreeCellKind.Empty, "", 0);

        public CocreeCell(CocreeCellKind kind, string text, double number)
        {
            Kind = kind;
            Text = text ?? "";
            Number = number;
        }

        public CocreeCellKind Kind { get; }

        /// <summary>Text cells: the text; booleans: "True"/"False"; numbers and dates: the value as stored in the file.</summary>
        public string Text { get; }

        /// <summary>Numbers and dates: the stored number (dates as Excel serial days).</summary>
        public double Number { get; }

        public bool IsEmpty => Kind == CocreeCellKind.Empty || (Kind == CocreeCellKind.Text && Text.Length == 0);

        /// <summary>
        /// The text the Workbench wrote for this cell (DataRow value ToString() on .NET Framework): numbers with up to 15
        /// significant digits, booleans as True/False. Dates are written as yyyyMMdd, the format COCREE expects (the
        /// Workbench wrote the culture's date and time, which BSP rejects).
        /// </summary>
        public string Value
        {
            get
            {
                switch (Kind)
                {
                    case CocreeCellKind.Number:
                        return Number.ToString("G15", CultureInfo.InvariantCulture);
                    case CocreeCellKind.Date:
                        return AsDate().ToString("yyyyMMdd", CultureInfo.InvariantCulture);
                    case CocreeCellKind.Empty:
                        return "";
                    default:
                        return Text;
                }
            }
        }

        /// <summary>A date cell's day (Excel stores dates as a number of days; the time of day is ignored).</summary>
        public DateTime AsDate()
        {
            return DateTime.FromOADate(Math.Floor(Number));
        }
    }

    /// <summary>
    /// A worksheet read the way the Workbench read it (ExcelDataReader, first row as column names): <see cref="Columns"/>
    /// are the names in row 1 ("Column{n}" when empty, "_2" … added to a repeated name) and <see cref="Rows"/> every row
    /// after it, padded to the number of columns.
    /// </summary>
    public sealed class CocreeSheet
    {
        public CocreeSheet(string name, IList<string> columns, IList<CocreeCell[]> rows, IList<int> rowNumbers)
        {
            Name = name;
            Columns = columns;
            Rows = rows;
            RowNumbers = rowNumbers;
            var index = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < columns.Count; i++)
            {
                if (!index.ContainsKey(columns[i]))
                {
                    index[columns[i]] = i;
                }
            }

            ColumnIndex = index;
        }

        public string Name { get; }

        public IList<string> Columns { get; }

        public IList<CocreeCell[]> Rows { get; }

        /// <summary>The Excel row number of each entry in <see cref="Rows"/> (for messages).</summary>
        public IList<int> RowNumbers { get; }

        /// <summary>Column name → index; names are matched without regard to case, as a DataTable does.</summary>
        public IReadOnlyDictionary<string, int> ColumnIndex { get; }

        public CocreeCell Cell(int row, string column)
        {
            int index;
            return ColumnIndex.TryGetValue(column, out index) ? Rows[row][index] : CocreeCell.Empty;
        }
    }

    /// <summary>
    /// Reads .xlsx workbooks for COCREE (the BU's input files and the Workbench's configuration files) without Excel:
    /// sheets in workbook order, cell values typed as text, number, date or boolean. External references (DTDs) are
    /// refused. Binary workbooks (.xlsb) are not supported.
    /// </summary>
    public static class CocreeWorkbookReader
    {
        private static readonly XmlReaderSettings Settings = new XmlReaderSettings
        {
            DtdProcessing = DtdProcessing.Prohibit,
            XmlResolver = null,
            IgnoreComments = true,
            IgnoreProcessingInstructions = true,
            CloseInput = true
        };

        private const string Main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private const string Relationships = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        private static readonly int[] BuiltInDateFormats = { 14, 15, 16, 17, 18, 19, 20, 21, 22, 27, 30, 36, 45, 46, 47, 50, 57 };

        /// <summary>The names of the workbook's sheets, in order.</summary>
        public static IList<string> SheetNames(Stream workbook)
        {
            using (var archive = Open(workbook))
            {
                return SheetParts(archive).Select(s => s.Key).ToList();
            }
        }

        /// <summary>Every sheet of the workbook, in order. <paramref name="onSheet"/> is called before each sheet is read.</summary>
        public static IList<CocreeSheet> Read(Stream workbook, Action<string> onSheet = null)
        {
            using (var archive = Open(workbook))
            {
                var shared = SharedStrings(archive);
                var dateStyles = DateStyles(archive);
                var sheets = new List<CocreeSheet>();
                foreach (var part in SheetParts(archive))
                {
                    if (onSheet != null)
                    {
                        onSheet(part.Key);
                    }

                    sheets.Add(ReadSheet(archive, part.Key, part.Value, shared, dateStyles));
                }

                return sheets;
            }
        }

        private static ZipArchive Open(Stream workbook)
        {
            try
            {
                var archive = new ZipArchive(workbook, ZipArchiveMode.Read, true);
                if (archive.GetEntry("xl/workbook.xml") == null)
                {
                    archive.Dispose();
                    throw new InvalidDataException("not an Excel .xlsx workbook");
                }

                return archive;
            }
            catch (InvalidDataException)
            {
                throw new CocreeFileException("The file is not an Excel .xlsx workbook (a binary .xlsb or an older .xls must be saved as .xlsx first).");
            }
        }

        private static XmlReader Reader(ZipArchive archive, string path)
        {
            var entry = archive.GetEntry(path);
            return entry == null ? null : XmlReader.Create(entry.Open(), Settings);
        }

        /// <summary>Sheet name → worksheet part path, in workbook order.</summary>
        private static List<KeyValuePair<string, string>> SheetParts(ZipArchive archive)
        {
            var targets = new Dictionary<string, string>(StringComparer.Ordinal);
            using (var rels = Reader(archive, "xl/_rels/workbook.xml.rels"))
            {
                while (rels != null && rels.Read())
                {
                    if (rels.NodeType == XmlNodeType.Element && rels.LocalName == "Relationship")
                    {
                        var id = rels.GetAttribute("Id");
                        var target = rels.GetAttribute("Target") ?? "";
                        if (id != null)
                        {
                            targets[id] = target.StartsWith("/", StringComparison.Ordinal) ? target.TrimStart('/') : "xl/" + target;
                        }
                    }
                }
            }

            var sheets = new List<KeyValuePair<string, string>>();
            using (var workbook = Reader(archive, "xl/workbook.xml"))
            {
                while (workbook.Read())
                {
                    if (workbook.NodeType == XmlNodeType.Element && workbook.LocalName == "sheet" && workbook.NamespaceURI == Main)
                    {
                        string target;
                        var id = workbook.GetAttribute("id", Relationships);
                        if (id != null && targets.TryGetValue(id, out target) && archive.GetEntry(Normalize(target)) != null)
                        {
                            sheets.Add(new KeyValuePair<string, string>(workbook.GetAttribute("name") ?? "", Normalize(target)));
                        }
                    }
                }
            }

            return sheets;
        }

        private static string Normalize(string path)
        {
            var parts = new List<string>();
            foreach (var part in path.Replace('\\', '/').Split('/'))
            {
                if (part == "..")
                {
                    if (parts.Count > 0) parts.RemoveAt(parts.Count - 1);
                }
                else if (part.Length > 0 && part != ".")
                {
                    parts.Add(part);
                }
            }

            return string.Join("/", parts);
        }

        private static List<string> SharedStrings(ZipArchive archive)
        {
            var strings = new List<string>();
            using (var reader = Reader(archive, "xl/sharedStrings.xml"))
            {
                if (reader == null)
                {
                    return strings;
                }

                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element && reader.LocalName == "si")
                    {
                        strings.Add(ReadText(reader));
                    }
                }
            }

            return strings;
        }

        /// <summary>
        /// The text of an si or is element: its t element, or the t of every formatted run. Phonetic guides (rPh) are
        /// not part of the cell's text and are left out.
        /// </summary>
        private static string ReadText(XmlReader reader)
        {
            if (reader.IsEmptyElement)
            {
                return "";
            }

            var text = new StringBuilder();
            using (var subtree = reader.ReadSubtree())
            {
                var phoneticDepth = -1;
                while (subtree.Read())
                {
                    if (subtree.NodeType != XmlNodeType.Element)
                    {
                        continue;
                    }

                    if (phoneticDepth >= 0 && subtree.Depth <= phoneticDepth)
                    {
                        phoneticDepth = -1; // left the phonetic guide
                    }

                    if (subtree.LocalName == "rPh")
                    {
                        phoneticDepth = subtree.Depth;
                    }
                    else if (subtree.LocalName == "t" && phoneticDepth < 0)
                    {
                        text.Append(subtree.ReadElementContentAsString());
                    }
                }
            }

            return text.ToString();
        }

        /// <summary>The cell style indexes (xf) whose number format shows a date or time.</summary>
        private static HashSet<int> DateStyles(ZipArchive archive)
        {
            var custom = new Dictionary<int, string>();
            var styles = new HashSet<int>();
            using (var reader = Reader(archive, "xl/styles.xml"))
            {
                if (reader == null)
                {
                    return styles;
                }

                var inCellXfs = false;
                var index = 0;
                while (reader.Read())
                {
                    if (reader.NodeType == XmlNodeType.Element && reader.LocalName == "numFmt")
                    {
                        int id;
                        if (int.TryParse(reader.GetAttribute("numFmtId"), NumberStyles.Integer, CultureInfo.InvariantCulture, out id))
                        {
                            custom[id] = reader.GetAttribute("formatCode") ?? "";
                        }
                    }
                    else if (reader.NodeType == XmlNodeType.Element && reader.LocalName == "cellXfs")
                    {
                        inCellXfs = !reader.IsEmptyElement;
                    }
                    else if (reader.NodeType == XmlNodeType.EndElement && reader.LocalName == "cellXfs")
                    {
                        inCellXfs = false;
                    }
                    else if (inCellXfs && reader.NodeType == XmlNodeType.Element && reader.LocalName == "xf")
                    {
                        int format;
                        int.TryParse(reader.GetAttribute("numFmtId"), NumberStyles.Integer, CultureInfo.InvariantCulture, out format);
                        string code;
                        if (Array.IndexOf(BuiltInDateFormats, format) >= 0 || (custom.TryGetValue(format, out code) && IsDateFormat(code)))
                        {
                            styles.Add(index);
                        }

                        index++;
                    }
                }
            }

            return styles;
        }

        /// <summary>A custom format shows a date when it has d, m, y, h or s outside quotes, brackets and escapes.</summary>
        internal static bool IsDateFormat(string code)
        {
            var section = (code ?? "").Split(';')[0];
            section = Regex.Replace(section, "\"[^\"]*\"|\\\\.|\\[[^\\]]*\\]|_.|\\*.", "");
            return Regex.IsMatch(section, "[dmyhsDMYHS]") && !Regex.IsMatch(section, "^[#0.,%E+\\-\\s]*$");
        }

        private static CocreeSheet ReadSheet(ZipArchive archive, string name, string path, List<string> shared, HashSet<int> dateStyles)
        {
            // Every row from row 1 to the last one with a cell, gaps included (as ExcelDataReader returns them).
            var rows = new SortedDictionary<int, List<KeyValuePair<int, CocreeCell>>>();
            var width = 0;
            using (var reader = Reader(archive, path))
            {
                var rowNumber = 0;
                List<KeyValuePair<int, CocreeCell>> current = null;
                while (reader.Read())
                {
                    if (reader.NodeType != XmlNodeType.Element)
                    {
                        continue;
                    }

                    if (reader.LocalName == "row")
                    {
                        int number;
                        rowNumber = int.TryParse(reader.GetAttribute("r"), NumberStyles.Integer, CultureInfo.InvariantCulture, out number) ? number : rowNumber + 1;
                        current = new List<KeyValuePair<int, CocreeCell>>();
                        rows[rowNumber] = current;
                    }
                    else if (reader.LocalName == "c" && current != null)
                    {
                        var reference = reader.GetAttribute("r");
                        var column = reference == null ? (current.Count == 0 ? 0 : current[current.Count - 1].Key + 1) : ColumnOf(reference);
                        var cell = ReadCell(reader, shared, dateStyles);
                        if (cell.Kind != CocreeCellKind.Empty)
                        {
                            current.Add(new KeyValuePair<int, CocreeCell>(column, cell));
                            width = Math.Max(width, column + 1);
                        }
                    }
                }
            }

            var lastRow = rows.Where(r => r.Value.Count > 0).Select(r => r.Key).DefaultIfEmpty(0).Max();
            var header = new CocreeCell[width];
            for (var c = 0; c < width; c++) header[c] = CocreeCell.Empty;
            List<KeyValuePair<int, CocreeCell>> first;
            if (rows.TryGetValue(1, out first))
            {
                foreach (var cell in first) header[cell.Key] = cell.Value;
            }

            var columns = new List<string>();
            var seen = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (var c = 0; c < width; c++)
            {
                var columnName = header[c].IsEmpty ? "Column" + c.ToString(CultureInfo.InvariantCulture) : header[c].Value;
                int count;
                if (seen.TryGetValue(columnName, out count))
                {
                    seen[columnName] = count + 1;
                    columnName = columnName + "_" + (count + 1).ToString(CultureInfo.InvariantCulture);
                }
                else
                {
                    seen[columnName] = 1;
                }

                columns.Add(columnName);
            }

            var data = new List<CocreeCell[]>();
            var numbers = new List<int>();
            for (var r = 2; r <= lastRow; r++)
            {
                var values = new CocreeCell[width];
                for (var c = 0; c < width; c++) values[c] = CocreeCell.Empty;
                List<KeyValuePair<int, CocreeCell>> cells;
                if (rows.TryGetValue(r, out cells))
                {
                    foreach (var cell in cells) values[cell.Key] = cell.Value;
                }

                data.Add(values);
                numbers.Add(r);
            }

            return new CocreeSheet(name, columns, data, numbers);
        }

        private static CocreeCell ReadCell(XmlReader reader, List<string> shared, HashSet<int> dateStyles)
        {
            var type = reader.GetAttribute("t") ?? "n";
            int style;
            int.TryParse(reader.GetAttribute("s"), NumberStyles.Integer, CultureInfo.InvariantCulture, out style);
            if (reader.IsEmptyElement)
            {
                return CocreeCell.Empty;
            }

            // The stored value (v) or, for an inline string, its text (is). A formula (f) is ignored: its cached value is in v.
            string value = null, inline = null;
            using (var cell = reader.ReadSubtree())
            {
                while (cell.Read())
                {
                    if (cell.NodeType == XmlNodeType.Element && cell.LocalName == "v")
                    {
                        value = cell.ReadElementContentAsString();
                    }
                    else if (cell.NodeType == XmlNodeType.Element && cell.LocalName == "is")
                    {
                        inline = ReadText(cell);
                    }
                }
            }

            switch (type)
            {
                case "s":
                    int index;
                    return int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out index) && index >= 0 && index < shared.Count
                        ? new CocreeCell(CocreeCellKind.Text, shared[index], 0) : CocreeCell.Empty;
                case "inlineStr":
                    return inline == null ? CocreeCell.Empty : new CocreeCell(CocreeCellKind.Text, inline, 0);
                case "str":
                    return value == null ? CocreeCell.Empty : new CocreeCell(CocreeCellKind.Text, value, 0);
                case "b":
                    return value == null ? CocreeCell.Empty : new CocreeCell(CocreeCellKind.Boolean, value == "1" ? "True" : "False", value == "1" ? 1 : 0);
                case "e":
                    return CocreeCell.Empty;
                case "d":
                    DateTime date;
                    return DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out date)
                        ? new CocreeCell(CocreeCellKind.Date, value, date.ToOADate()) : CocreeCell.Empty;
                default:
                    double number;
                    if (value == null || !double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out number))
                    {
                        return CocreeCell.Empty;
                    }

                    return new CocreeCell(dateStyles.Contains(style) ? CocreeCellKind.Date : CocreeCellKind.Number, value, number);
            }
        }

        /// <summary>"AB12" → 27 (zero-based column).</summary>
        internal static int ColumnOf(string reference)
        {
            var column = 0;
            foreach (var ch in reference)
            {
                if (ch >= 'A' && ch <= 'Z') column = column * 26 + (ch - 'A' + 1);
                else if (ch >= 'a' && ch <= 'z') column = column * 26 + (ch - 'a' + 1);
                else break;
            }

            return Math.Max(0, column - 1);
        }
    }

    /// <summary>A COCREE file that cannot be read or is not what was expected; the message says why (shown as is).</summary>
    public sealed class CocreeFileException : Exception
    {
        public CocreeFileException(string message) : base(message) { }
    }
}
