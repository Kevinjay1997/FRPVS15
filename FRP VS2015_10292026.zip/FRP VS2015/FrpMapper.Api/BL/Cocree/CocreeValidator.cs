using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using System.Xml.Schema;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL.Cocree
{
    /// <summary>
    /// Validates a CSDF XML file as the Workbench's "Validate a COCREE v2.0 XML File" (step 2) and "Validate with XSD"
    /// (step 3) did:
    /// <list type="number">
    /// <item>Stage 1: the file name, UTF-8 without BOM, and the file's layout (Header, Body, Footer, known record types).
    /// A file that fails here is not checked further.</item>
    /// <item>Preliminary checks: duplicate subjects and contracts, company links and negative events whose subjects are
    /// not in the file, and the data types (dates, whole numbers, amounts). When any is found, the Workbench wrote the
    /// Preliminary_Validation report and did not apply the rules; so does this.</item>
    /// <item>BSP's rules (cocree_validations.xlsx), each a DataColumn expression evaluated on every record of its element
    /// with the same .NET engine the Workbench used. The COCREE_v2_Validation report lists, per rule, the records for which
    /// it is FALSE ("Error") and those it could not decide ("Invalid").</item>
    /// <item>The XSD, when the configuration has one.</item>
    /// </list>
    /// Where this differs from the Workbench it is deliberate (see the README): the Header and Footer rules are reported
    /// (the Workbench evaluated them but left them out of the report), the Footer rules get the Header's values they
    /// compare with, negative events are checked against the file's subjects (the Workbench compared them with
    /// themselves), the data types of OffBalanceSheets and the dates of negative events are checked as dates, and a zero
    /// written with decimals ("0.00") is a valid amount.
    /// </summary>
    public sealed class CocreeValidator
    {
        public const string RulesReport = "COCREE_v2_Validation";
        public const string PreliminaryReport = "Preliminary_Validation";
        public const string NoResultRemarks = "No validation result. Please verify that the attribute exists in the XML file (not null).";

        private const int RecordsPerBatch = 2000;
        private const int ExamplesPerRule = 5;
        private const int IssuesShown = 500;

        private static readonly string[] HeaderAndFooter = { "HEADER", "FOOTER" };
        private static readonly string[] SubjectElements = { "INDIVIDUALS", "COMPANIES" };
        private static readonly string[] ExposureElements = { "INSTALLMENTS", "NONINSTALLMENTS", "CREDITCARDS", "OTHERCREDITACCOMODATIONS", "INVESTMENTS", "OFFBALANCESHEETS" };

        // Rates have at most 3 digits and 4 decimals; other amounts 17 digits and 2 decimals (Workbench).
        private static readonly string[] Rates = { "NOMINALINTERESTRATE", "PROBABILITYDEFAULT", "EFFECTIVEINTERESTRATE" };
        private static readonly string[] RateElements = { "INSTALLMENTS", "NONINSTALLMENTS", "CREDITCARDS", "OTHERCREDITACCOMODATIONS", "INVESTMENTS" };

        // Checks the Workbench made that xml_entities does not declare: FrequencyRepricing, and the identification
        // numbers of SSS (type 11) and GSIS (type 12), which must be whole numbers.
        private static readonly Dictionary<string, string> FrequencyRepricing = new Dictionary<string, string>
        {
            { "INSTALLMENTS", "INTEGER" }, { "CREDITCARDS", "INTEGER" }, { "INVESTMENTS", "INTEGER" },
            { "NONINSTALLMENTS", "MONEY" }, { "OTHERCREDITACCOMODATIONS", "MONEY" }
        };

        private static readonly string[][] NumericIdentifications =
        {
            new[] { "INDIVIDUALS", "IdentificationNumber2", "IdentificationType2" },
            new[] { "INDIVIDUALS", "IdentificationNumber3", "IdentificationType3" },
            new[] { "INDIVIDUALS", "STIdentificationNumber2", "STIdentificationType2" },
            new[] { "COMPANIES", "IdentificationNumber2", "IdentificationType2" }
        };

        private static readonly string[] NumericIdentificationTypes = { "11", "12" };

        private readonly CocreeConfiguration configuration;
        private readonly XmlSchemaSet schemas;
        private readonly IReadOnlyList<string> providerCodes;
        private readonly DateTime today;

        /// <param name="schemas">The configuration's XSD, compiled; null when it has none.</param>
        /// <param name="providerCodes">The provider codes a file name may have (the approved bank profiles').</param>
        public CocreeValidator(CocreeConfiguration configuration, XmlSchemaSet schemas, IReadOnlyList<string> providerCodes, DateTime today)
        {
            this.configuration = configuration;
            this.schemas = schemas;
            this.providerCodes = providerCodes;
            this.today = today;
        }

        /// <summary>The configuration's elements in xml_entities order (Header, Individuals, …, Footer), as the Workbench looped over them.</summary>
        private IEnumerable<string> Elements => configuration.Attributes.Select(a => a.Element).Distinct(StringComparer.OrdinalIgnoreCase);

        private IEnumerable<CocreeConfiguration.XmlAttribute> AttributesOf(string element) =>
            configuration.Attributes.Where(a => CocreeConfiguration.Clean(a.Element) == CocreeConfiguration.Clean(element));

        private IEnumerable<CocreeValidationRule> RulesOf(string element) =>
            configuration.ValidationRules.Where(r => CocreeConfiguration.Clean(r.Element) == CocreeConfiguration.Clean(element));

        // ---------- checking the rules themselves ----------

        /// <summary>
        /// The rules that cannot be evaluated on their element's attributes (a mistyped formula or attribute name), checked
        /// when a configuration is uploaded. Rules of elements the configuration does not have are never evaluated.
        /// </summary>
        public static List<string> FormulaProblems(CocreeConfiguration configuration)
        {
            var problems = new List<string>();
            var validator = new CocreeValidator(configuration, null, new string[0], DateTime.Today);
            foreach (var element in validator.Elements)
            {
                var table = validator.NewTable(element);
                foreach (var rule in validator.RulesOf(element))
                {
                    try
                    {
                        table.Columns.Add(new DataColumn(rule.Code, typeof(string), rule.Expression));
                    }
                    catch (Exception ex) when (IsFormulaError(ex))
                    {
                        problems.Add("Validations: the rule " + rule.Code.Trim() + " of " + element + " cannot be used (" + rule.Expression + "): " + ex.Message);
                    }
                }
            }

            return problems;
        }

        // ---------- one file ----------

        /// <summary>
        /// Validates one file. <paramref name="writeReport"/> receives each report (file name, content) to keep.
        /// </summary>
        public CocreeFileValidationDto Validate(string fileName, byte[] content, Action<string, Action<Stream>> writeReport, Action<string> progress = null)
        {
            var result = new CocreeFileValidationDto { Name = fileName, Size = content.Length };
            var stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture);
            var baseName = Contracts.DAL.CocreeOutputNames.Safe(Path.GetFileNameWithoutExtension(fileName));
            progress = progress ?? (s => { });

            // Stage 1 and the layout.
            progress("Stage 1: " + fileName);
            var stage1 = CocreeRules.CheckFileName(fileName, providerCodes, today);
            var csdf = CocreeRules.ReadCsdf(fileName, content, null);
            result.Issues.AddRange(stage1);
            result.Issues.AddRange(csdf.Issues);
            XElement root = csdf.Document == null ? null : csdf.Document.Root;
            string headerDate = null;
            if (root != null && !result.Issues.Any(i => i.Severity == CocreeRules.Error))
            {
                var header = Child(root, "HEADER");
                var raw = (string)header.Attribute("FileReferenceDate") ?? "";
                DateTime date;
                if (raw.Length < 8 || !DateTime.TryParseExact(raw.Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                {
                    Error(result, "", "Invalid header reference date: " + raw);
                }
                else
                {
                    headerDate = date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                }

                var known = Elements.Select(CocreeConfiguration.Clean).ToList();
                foreach (var unknown in Child(root, "BODY").Elements().Select(e => e.Name.LocalName).Distinct().Where(n => !known.Contains(CocreeConfiguration.Clean(n))))
                {
                    Error(result, "30-009", "'RECORD TYPE' IS NOT VALID = " + unknown);
                }
            }

            result.Records = csdf.Subjects + csdf.Contracts + csdf.NegativeEvents;

            // Step 3 runs on every readable file, so its messages are there even when the rules are not applied.
            if (schemas != null && root != null)
            {
                progress("XSD: " + fileName);
                var issues = XmlSchemaChecker.Check(new MemoryStream(content, false), schemas);
                result.XsdValid = issues.All(i => i.Severity != "Error");
                result.XsdIssueCount = issues.Count;
                result.XsdIssues = issues.Take(IssuesShown).ToList();
                if (issues.Count > 0)
                {
                    result.XsdReport = baseName + "_XSD_Validation_Result_" + stamp + ".csv";
                    var csv = XmlSchemaChecker.Report(issues);
                    writeReport(result.XsdReport, stream => stream.Write(csv, 0, csv.Length));
                }
            }

            if (headerDate == null)
            {
                result.Outcome = "Stopped";
                return Finish(result);
            }

            // Preliminary checks.
            progress("Preliminary checks: " + fileName);
            var body = Child(root, "BODY").Elements().ToList();
            var preliminary = new XElement("Preliminary_Validation_Error_List");
            PreliminaryChecks(body, preliminary);
            var outcomes = ApplyRules(root, body, headerDate, ProviderOf(fileName), preliminary, result, progress, fileName);

            if (preliminary.HasElements)
            {
                result.Stage = "Preliminary";
                result.Outcome = "Failed";
                result.Report = baseName + "_" + PreliminaryReport + "_Result_" + stamp + ".xml";
                AddPreliminaryIssues(preliminary, result);
                writeReport(result.Report, stream => CocreeRules.Save(new XDocument(preliminary), stream));
                return Finish(result);
            }

            // The rules' report.
            result.Stage = "Rules";
            var report = new XElement("COCREE_v2_Validation_Result");
            foreach (var pair in outcomes)
            {
                var element = pair.Key;
                var group = new XElement("Element", new XAttribute("Type", element));
                foreach (var outcome in pair.Value)
                {
                    var validation = new XElement("Validation", new XAttribute("Code", outcome.Rule.Code), new XAttribute("Message", outcome.Rule.Message));
                    AddRecords(validation, "Error", outcome.Errors, null);
                    AddRecords(validation, "Invalid", outcome.Undecided, NoResultRemarks);
                    if (validation.HasElements)
                    {
                        group.Add(validation);
                    }

                    result.RulesApplied++;
                    if (outcome.Errors.Count > 0 || outcome.Undecided.Count > 0)
                    {
                        result.Rules.Add(new CocreeRuleResultDto
                        {
                            Element = element, Code = outcome.Rule.Code.Trim(), Message = outcome.Rule.Message, Errors = outcome.Errors.Count, Undecided = outcome.Undecided.Count,
                            Examples = outcome.Errors.Concat(outcome.Undecided).Take(ExamplesPerRule)
                                .Select(record => string.Join(", ", record.Select(a => a.Key + " " + a.Value))).ToList()
                        });
                    }

                    result.RecordErrors += outcome.Errors.Count;
                    result.Undecided += outcome.Undecided.Count;
                }

                if (group.HasElements)
                {
                    report.Add(group);
                }
            }

            if (!report.HasElements)
            {
                report.Add(new XElement("Result", new XAttribute("Message", "No validation error found.")));
            }

            report.Add(new XAttribute("File", fileName));
            report.Add(new XAttribute("ValidationCompletedOn", stamp));
            result.Report = baseName + "_" + RulesReport + "_Result_" + stamp + ".xml";
            writeReport(result.Report, stream => CocreeRules.Save(new XDocument(report), stream));
            result.Rules = result.Rules.OrderByDescending(r => r.Errors).ThenByDescending(r => r.Undecided).ToList();
            result.Outcome = result.RecordErrors > 0 || result.Undecided > 0 ? "Failed" : "Passed";
            return Finish(result);
        }

        private CocreeFileValidationDto Finish(CocreeFileValidationDto result)
        {
            if (result.XsdValid == false && result.Outcome == "Passed")
            {
                result.Outcome = "Failed";
            }

            if (result.Issues.Count > IssuesShown)
            {
                var total = result.Issues.Count;
                result.Issues = result.Issues.Take(IssuesShown).ToList();
                result.Issues.Add(new CocreeIssueDto { Severity = CocreeRules.Information, Message = "The first " + IssuesShown + " of " + total.ToString("N0", CultureInfo.InvariantCulture) + " messages are listed; the report has all of them.", File = result.Name });
            }

            return result;
        }

        private static void Error(CocreeFileValidationDto result, string code, string message)
        {
            result.Issues.Add(new CocreeIssueDto { Severity = CocreeRules.Error, Code = code, Message = message, File = result.Name });
        }

        private static XElement Child(XElement root, string name)
        {
            return root.Elements().First(e => CocreeConfiguration.Clean(e.Name.LocalName) == name);
        }

        /// <summary>The provider code of a file name ("0000000135_CSDF_…" → 0000000135).</summary>
        private static string ProviderOf(string fileName)
        {
            var name = Path.GetFileNameWithoutExtension(fileName) ?? "";
            var underscore = name.IndexOf('_');
            return underscore < 0 ? name : name.Substring(0, underscore);
        }

        private static string Value(XElement record, string attribute)
        {
            var found = record.Attributes().FirstOrDefault(a => a.Name.LocalName == attribute);
            return found == null ? null : found.Value;
        }

        // ---------- preliminary checks ----------

        private static void PreliminaryChecks(List<XElement> body, XElement report)
        {
            Func<XElement, string> name = e => CocreeConfiguration.Clean(e.Name.LocalName);
            var subjects = body.Where(e => SubjectElements.Contains(name(e))).ToList();
            var subjectNumbers = new HashSet<string>(subjects.Select(e => Value(e, "ProviderSubjectNumber") ?? ""));

            ListFound(report, "10-090", "THE SAME 'PROVIDER SUBJECT NO' IS ALREADY ASSIGNED TO ANOTHER SUBJECT",
                Duplicates(subjects, e => Value(e, "ProviderSubjectNumber") ?? "").Select(n => new[] { new XAttribute("ProviderSubjectNumber", n) }));

            ListFound(report, "20-310", "MORE THAN ONE CONTRACT WITH THE SAME PROVIDER CONTRACT NUMBER AND REFERENCE DATE IS PRESENT",
                Duplicates(body.Where(e => ExposureElements.Contains(name(e))), e => Value(e, "ProviderContractNo") ?? "").Select(n => new[] { new XAttribute("ProviderContractNo", n) }));

            var links = body.Where(e => name(e) == "COMPANYLINKS")
                .Select(e => new { Parent = Value(e, "ParentProviderSubjectNo") ?? "", Child = Value(e, "ChildProviderSubjectNo") ?? "" }).ToList();
            ListFound(report, "EWB-ERR", "COMPANY LINKS: DUPLICATE COMPANY LINKS DETECTED.",
                links.GroupBy(l => l.Parent + "\u001f" + l.Child).Where(g => g.Count() > 1)
                    .Select(g => new[] { new XAttribute("ParentProviderSubjectNo", g.First().Parent), new XAttribute("ChildProviderSubjectNo", g.First().Child) }));
            ListFound(report, "EWB-ERR", "COMPANY LINKS: ParentProviderSubjectNo NOT FOUND IN THE FILE'S SUBJECT LIST.",
                links.Where(l => !subjectNumbers.Contains(l.Parent)).Select(l => new[] { new XAttribute("ParentProviderSubjectNo", l.Parent) }));
            ListFound(report, "EWB-ERR", "COMPANY LINKS: ChildProviderSubjectNo NOT FOUND IN THE FILE'S SUBJECT LIST.",
                links.Where(l => !subjectNumbers.Contains(l.Child)).Select(l => new[] { new XAttribute("ChildProviderSubjectNo", l.Child) }));

            var events = body.Where(e => name(e) == "SUBJECTNEGATIVEEVENTS").ToList();
            ListFound(report, "EWB-ERR", "SUBJECT NEGATIVE EVENTS: DUPLICATE NEGATIVE RECORDS FOUND.",
                events.GroupBy(e => string.Join("\u001f", new[] { "ProviderSubjectNo", "EventCode", "EventDetail", "EventStatus" }.Select(a => Value(e, a) ?? "")))
                    .Where(g => g.Count() > 1).Select(g => new[] { new XAttribute("ProviderSubjectNo", Value(g.First(), "ProviderSubjectNo") ?? "") }));
            ListFound(report, "EWB-ERR", "SUBJECT NEGATIVE EVENTS: ProviderSubjectNo NOT FOUND IN THE FILE'S SUBJECT LIST.",
                events.Where(e => !subjectNumbers.Contains(Value(e, "ProviderSubjectNo") ?? "")).Select(e => new[] { new XAttribute("ProviderSubjectNo", Value(e, "ProviderSubjectNo") ?? "") }));
        }

        private static IEnumerable<string> Duplicates(IEnumerable<XElement> records, Func<XElement, string> key)
        {
            return records.GroupBy(key).Where(g => g.Count() > 1).Select(g => g.Key);
        }

        private static void ListFound(XElement report, string code, string message, IEnumerable<XAttribute[]> records)
        {
            var found = records.ToList();
            if (found.Count == 0)
            {
                return;
            }

            var validation = new XElement("Validation", new XAttribute("Code", code), new XAttribute("Message", message));
            foreach (var record in found)
            {
                validation.Add(new XElement("Record", record));
            }

            report.Add(validation);
        }

        // ---------- data types ----------

        private sealed class TypeCheck
        {
            public string Attribute;
            public string Kind;            // DATE, INTEGER or MONEY
            public int Digits = 17;
            public int Decimals = 2;
            public string WhenTypeIs;      // the identification type attribute for SSS / GSIS numbers
        }

        /// <summary>The attributes of an element whose values must be dates, whole numbers or amounts: dates first, as the Workbench listed them.</summary>
        private List<TypeCheck> TypeChecks(string element)
        {
            var key = CocreeConfiguration.Clean(element);
            var checks = AttributesOf(element)
                .Where(a => a.DataType == "DATE" || a.DataType == "INTEGER" || a.DataType == "MONEY")
                .Select(a => new TypeCheck { Attribute = a.Name, Kind = a.DataType })
                .ToList();

            string frequencyKind;
            if (FrequencyRepricing.TryGetValue(key, out frequencyKind) && !checks.Any(c => CocreeConfiguration.Clean(c.Attribute) == "FREQUENCYREPRICING")
                && AttributesOf(element).Any(a => CocreeConfiguration.Clean(a.Name) == "FREQUENCYREPRICING"))
            {
                checks.Add(new TypeCheck { Attribute = "FrequencyRepricing", Kind = frequencyKind });
            }

            if (RateElements.Contains(key))
            {
                foreach (var rate in checks.Where(c => c.Kind == "MONEY" && Rates.Contains(CocreeConfiguration.Clean(c.Attribute))))
                {
                    rate.Digits = 3;
                    rate.Decimals = 4;
                }
            }

            var order = new[] { "DATE", "INTEGER", "MONEY" };
            checks = checks.OrderBy(c => Array.IndexOf(order, c.Kind)).ToList();
            foreach (var id in NumericIdentifications.Where(i => i[0] == key))
            {
                checks.Add(new TypeCheck { Attribute = id[1], Kind = "INTEGER", WhenTypeIs = id[2] });
            }

            return checks;
        }

        /// <summary>The attribute that names a record in the data type messages.</summary>
        private string IdentifierOf(string element)
        {
            var key = CocreeConfiguration.Clean(element);
            if (SubjectElements.Contains(key)) return "ProviderSubjectNumber";
            if (ExposureElements.Contains(key)) return "ProviderContractNo";
            if (key == "COMPANYLINKS") return "ParentProviderSubjectNo";
            if (key == "SUBJECTNEGATIVEEVENTS") return "ProviderSubjectNo";
            var first = AttributesOf(element).FirstOrDefault(a => a.IncludeInErrorReport);
            return first == null ? null : first.Name;
        }

        private void CheckDataTypes(string element, List<XElement> body, XElement report)
        {
            var records = body.Where(e => CocreeConfiguration.Clean(e.Name.LocalName) == CocreeConfiguration.Clean(element)).ToList();
            var checks = TypeChecks(element);
            if (records.Count == 0 || checks.Count == 0)
            {
                return;
            }

            // Like the Workbench: a record without one of the checked attributes (or its identifier) stops the check of
            // the element, with one message.
            var identifier = IdentifierOf(element);
            var needed = checks.Select(c => c.Attribute).Concat(checks.Where(c => c.WhenTypeIs != null).Select(c => c.WhenTypeIs))
                .Concat(identifier == null ? new string[0] : new[] { identifier }).Distinct().ToList();
            var missing = needed.Select(a => new { Attribute = a, Count = records.Count(r => Value(r, a) == null) }).Where(m => m.Count > 0).ToList();
            if (missing.Count > 0)
            {
                report.Add(new XElement("XML_Format_Error", new XAttribute("Element", element),
                    new XAttribute("Message", "One or more elements have a missing attribute that needs to be checked. Ensure that every element attribute exists in accordance to the XSD."),
                    new XAttribute("ExceptionMessage", string.Join("; ", missing.Select(m => m.Attribute + " is missing on " + m.Count.ToString("N0", CultureInfo.InvariantCulture) + " records")))));
                return;
            }

            foreach (var check in checks)
            {
                foreach (var record in records)
                {
                    if (check.WhenTypeIs != null && !NumericIdentificationTypes.Contains(Value(record, check.WhenTypeIs)))
                    {
                        continue;
                    }

                    var value = Value(record, check.Attribute);
                    string message = null;
                    if (check.WhenTypeIs != null)
                    {
                        message = IsInteger(value) ? null : "Invalid Integer (refer to error code 20-251 and/or 20-052)";
                    }
                    else if (check.Kind == "DATE")
                    {
                        message = IsDate(value) ? null : "Invalid date";
                    }
                    else if (check.Kind == "INTEGER")
                    {
                        message = IsInteger(value) ? null : "Invalid integer value";
                    }
                    else
                    {
                        message = IsDecimal(value, check.Digits, check.Decimals) ? null : "Invalid decimal value";
                    }

                    if (message != null)
                    {
                        report.Add(new XElement("Error", new XAttribute("Message", message), new XAttribute("Type", element), new XAttribute("Attribute", check.Attribute),
                            identifier == null ? null : new XAttribute(identifier, Value(record, identifier))));
                    }
                }
            }
        }

        /// <summary>Empty, or yyyyMMdd (the first 8 characters) after 1900-01-01.</summary>
        public static bool IsDate(string value)
        {
            if (value.Trim().Length == 0) return true;
            DateTime date;
            return value.Length >= 8 && DateTime.TryParseExact(value.Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date)
                && date > new DateTime(1900, 1, 1);
        }

        /// <summary>Empty, or a whole number that fits in 64 bits.</summary>
        public static bool IsInteger(string value)
        {
            long number;
            return value.Length == 0 || long.TryParse(value, out number);
        }

        /// <summary>Empty, or a number with at most <paramref name="digits"/> digits before the point and <paramref name="decimals"/> after it.</summary>
        public static bool IsDecimal(string value, int digits, int decimals)
        {
            if (value.Length == 0) return true;
            decimal number;
            if (!decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out number)) return false;
            var parts = value.Split('.');
            return parts.Length < 2 || (parts[0].Length <= digits && parts[1].Length <= decimals);
        }

        // ---------- BSP's rules ----------

        private sealed class RuleOutcome
        {
            public CocreeValidationRule Rule;
            public readonly List<List<KeyValuePair<string, string>>> Errors = new List<List<KeyValuePair<string, string>>>();
            public readonly List<List<KeyValuePair<string, string>>> Undecided = new List<List<KeyValuePair<string, string>>>();
        }

        /// <summary>The table one element's records are evaluated in, without the rules (all values as text, as the Workbench).</summary>
        private DataTable NewTable(string element)
        {
            var key = CocreeConfiguration.Clean(element);
            var table = new DataTable(element) { Locale = CultureInfo.InvariantCulture };
            if (HeaderAndFooter.Contains(key))
            {
                table.Columns.Add("FileName_ProviderCode", typeof(string));
            }
            else
            {
                table.Columns.Add("FileReferenceDate", typeof(string));
            }

            if (key == "FOOTER")
            {
                table.Columns.Add("Header_FileReferenceDate", typeof(string));
                table.Columns.Add("Header_NumberOfRecords", typeof(int));
            }

            foreach (var attribute in AttributesOf(element))
            {
                if (!table.Columns.Contains(attribute.Name))
                {
                    table.Columns.Add(attribute.Name, typeof(string));
                }
            }

            return table;
        }

        /// <summary>
        /// Goes through the elements in xml_entities order, as the Workbench did: a Body element's data types are checked
        /// first, and its rules are applied only while the preliminary report is still empty; a record a rule cannot be
        /// evaluated on (a value its formula cannot convert) goes to the preliminary report. The Header's and Footer's
        /// rules are always applied; a formula error there makes the rule undecided and is listed as a message.
        /// </summary>
        private List<KeyValuePair<string, List<RuleOutcome>>> ApplyRules(XElement root, List<XElement> body, string headerDate, string fileProvider, XElement preliminary,
            CocreeFileValidationDto result, Action<string> progress, string fileName)
        {
            var outcomes = new List<KeyValuePair<string, List<RuleOutcome>>>();
            var header = Child(root, "HEADER");
            var footer = Child(root, "FOOTER");
            foreach (var element in Elements)
            {
                var key = CocreeConfiguration.Clean(element);
                var isHeaderOrFooter = HeaderAndFooter.Contains(key);
                if (!isHeaderOrFooter)
                {
                    CheckDataTypes(element, body, preliminary);
                    if (preliminary.HasElements)
                    {
                        continue;
                    }
                }

                var rules = RulesOf(element).ToList();
                List<XElement> records;
                if (key == "HEADER") records = new List<XElement> { header };
                else if (key == "FOOTER") records = new List<XElement> { footer };
                else records = body.Where(e => CocreeConfiguration.Clean(e.Name.LocalName) == key).ToList();
                if (records.Count == 0 || rules.Count == 0)
                {
                    continue;
                }

                progress("Rules of " + element + ": " + records.Count.ToString("N0", CultureInfo.InvariantCulture) + " records × " + rules.Count + " rules (" + fileName + ")");
                var dates = new HashSet<string>(AttributesOf(element).Where(a => a.DataType == "DATE").Select(a => a.Name), StringComparer.OrdinalIgnoreCase);
                var identifiers = AttributesOf(element).Where(a => a.IncludeInErrorReport).Select(a => a.Name).ToList();
                var elementOutcomes = rules.Select(r => new RuleOutcome { Rule = r }).ToList();
                outcomes.Add(new KeyValuePair<string, List<RuleOutcome>>(element, elementOutcomes));

                for (var start = 0; start < records.Count; start += RecordsPerBatch)
                {
                    var table = NewTable(element);
                    foreach (var record in records.Skip(start).Take(RecordsPerBatch))
                    {
                        table.Rows.Add(NewRow(table, element, record, headerDate, fileProvider, header, body.Count, dates, preliminary));
                    }

                    var formulaErrors = new List<FormulaError>();
                    var results = Evaluate(table, rules, formulaErrors);
                    foreach (var error in formulaErrors.OrderBy(f => f.Row).ThenBy(f => f.Rule))
                    {
                        var rule = rules[error.Rule];
                        if (isHeaderOrFooter)
                        {
                            result.Issues.Add(new CocreeIssueDto
                            {
                                Severity = CocreeRules.Warning, Code = rule.Code.Trim(), Element = element, File = fileName,
                                Message = "The rule could not be evaluated: " + error.Message
                            });
                        }
                        else
                        {
                            preliminary.Add(new XElement("Formula", new XAttribute("Type", "Error"), new XAttribute("Element", element), new XAttribute("Code", rule.Code),
                                new XAttribute("Message", error.Message), Identify(table.Rows[error.Row], identifiers).Select(a => new XAttribute(a.Key, a.Value))));
                        }
                    }

                    for (var r = 0; r < rules.Count; r++)
                    {
                        for (var i = 0; i < table.Rows.Count; i++)
                        {
                            var value = CocreeConfiguration.Clean(results[r][i]);
                            if (value == "FALSE") elementOutcomes[r].Errors.Add(Identify(table.Rows[i], identifiers));
                            else if (value.Length == 0) elementOutcomes[r].Undecided.Add(Identify(table.Rows[i], identifiers));
                        }
                    }
                }
            }

            return outcomes;
        }

        /// <summary>
        /// One record as the Workbench put it in the table: Body records with the Header's FileReferenceDate (yyyy-MM-dd)
        /// and their dates as yyyy-MM-dd; the Header and Footer with the file name's provider code, the Footer with the
        /// Header's FileReferenceDate and the number of Body records it must give.
        /// </summary>
        private static DataRow NewRow(DataTable table, string element, XElement record, string headerDate, string fileProvider, XElement header, int bodyRecords,
            HashSet<string> dates, XElement preliminary)
        {
            var key = CocreeConfiguration.Clean(element);
            var row = table.NewRow();
            if (HeaderAndFooter.Contains(key))
            {
                row["FileName_ProviderCode"] = fileProvider;
            }
            else
            {
                row["FileReferenceDate"] = headerDate;
            }

            if (key == "FOOTER")
            {
                row["Header_FileReferenceDate"] = (string)header.Attribute("FileReferenceDate") ?? "";
                row["Header_NumberOfRecords"] = bodyRecords;
            }

            foreach (var attribute in record.Attributes().Where(a => !a.IsNamespaceDeclaration))
            {
                var name = attribute.Name.LocalName;
                if (!table.Columns.Contains(name))
                {
                    preliminary.Add(new XElement("Record", new XAttribute("Element", element),
                        new XAttribute("Message", "Column '" + name + "' does not belong to table " + element + ".")));
                    continue;
                }

                var value = attribute.Value;
                row[name] = !HeaderAndFooter.Contains(key) && dates.Contains(name) && value.Trim().Length >= 8
                    ? value.Substring(0, 4) + "-" + value.Substring(4, 2) + "-" + value.Substring(6, 2)
                    : value;
            }

            return row;
        }

        private sealed class FormulaError
        {
            public int Row;
            public int Rule;
            public string Message;
        }

        /// <summary>
        /// The result of every rule on every row of the batch ("True", "False" or "" for no result). A rule that fails on
        /// the whole batch is retried row by row, so only the rows it cannot be evaluated on are reported.
        /// </summary>
        private static List<string[]> Evaluate(DataTable table, List<CocreeValidationRule> rules, List<FormulaError> formulaErrors)
        {
            var results = new List<string[]>();
            for (var r = 0; r < rules.Count; r++)
            {
                var values = rules[r].EvaluatedPerRecord ? null : EvaluateBatch(table, rules[r]);
                results.Add(values ?? EvaluateRecordByRecord(table, rules[r], r, formulaErrors));
            }

            return results;
        }

        /// <summary>The rule on every row at once; null when it cannot be evaluated on one of them.</summary>
        private static string[] EvaluateBatch(DataTable table, CocreeValidationRule rule)
        {
            var values = new string[table.Rows.Count];
            var column = new DataColumn(rule.Code, typeof(string), rule.Expression);
            try
            {
                table.Columns.Add(column);
                for (var i = 0; i < table.Rows.Count; i++)
                {
                    values[i] = Convert.ToString(table.Rows[i][column], CultureInfo.InvariantCulture);
                }

                return values;
            }
            catch (Exception ex) when (IsFormulaError(ex))
            {
                return null;
            }
            finally
            {
                if (table.Columns.Contains(column.ColumnName))
                {
                    table.Columns.Remove(column.ColumnName);
                }
            }
        }

        /// <summary>The rule on one row at a time, as the Workbench evaluated it; a row it fails on has no result and a formula error.</summary>
        private static string[] EvaluateRecordByRecord(DataTable table, CocreeValidationRule rule, int ruleIndex, List<FormulaError> formulaErrors)
        {
            var values = new string[table.Rows.Count];
            for (var i = 0; i < table.Rows.Count; i++)
            {
                var single = table.Clone();
                single.ImportRow(table.Rows[i]);
                try
                {
                    single.Columns.Add(new DataColumn(rule.Code, typeof(string), rule.Expression));
                    values[i] = Convert.ToString(single.Rows[0][rule.Code], CultureInfo.InvariantCulture);
                }
                catch (Exception ex) when (IsFormulaError(ex))
                {
                    values[i] = "";
                    formulaErrors.Add(new FormulaError { Row = i, Rule = ruleIndex, Message = ex.Message });
                }
            }

            return values;
        }

        /// <summary>What a DataColumn expression throws when it cannot be parsed or evaluated.</summary>
        private static bool IsFormulaError(Exception ex)
        {
            return ex is DataException || ex is FormatException || ex is InvalidCastException || ex is OverflowException || ex is ArgumentException;
        }

        private static List<KeyValuePair<string, string>> Identify(DataRow row, List<string> identifiers)
        {
            return identifiers.Select(name => new KeyValuePair<string, string>(name, Convert.ToString(row[name], CultureInfo.InvariantCulture))).ToList();
        }

        private static void AddRecords(XElement validation, string name, List<List<KeyValuePair<string, string>>> records, string remarks)
        {
            if (records.Count == 0)
            {
                return;
            }

            var list = new XElement(name);
            foreach (var record in records)
            {
                list.Add(new XElement("Record", record.Select(a => new XAttribute(a.Key, a.Value))));
            }

            if (remarks != null)
            {
                list.Add(new XAttribute("Remarks", remarks));
            }

            validation.Add(new XAttribute(name + "Count", records.Count.ToString(CultureInfo.InvariantCulture)));
            validation.Add(list);
        }

        /// <summary>The preliminary report's findings as messages for the page.</summary>
        private static void AddPreliminaryIssues(XElement preliminary, CocreeFileValidationDto result)
        {
            foreach (var item in preliminary.Elements())
            {
                var code = (string)item.Attribute("Code") ?? "";
                var message = (string)item.Attribute("Message") ?? "";
                if (item.Name.LocalName == "Validation")
                {
                    foreach (var record in item.Elements())
                    {
                        result.Issues.Add(new CocreeIssueDto
                        {
                            Severity = CocreeRules.Error, Code = code, Message = message, File = result.Name,
                            ProviderSubjectNo = (string)record.Attribute("ProviderSubjectNumber") ?? (string)record.Attribute("ProviderSubjectNo")
                                ?? (string)record.Attribute("ParentProviderSubjectNo") ?? (string)record.Attribute("ChildProviderSubjectNo"),
                            ProviderContractNo = (string)record.Attribute("ProviderContractNo")
                        });
                    }

                    continue;
                }

                var attribute = (string)item.Attribute("Attribute");
                var detail = (string)item.Attribute("ExceptionMessage");
                result.Issues.Add(new CocreeIssueDto
                {
                    Severity = CocreeRules.Error, Code = code,
                    Message = (item.Name.LocalName == "Formula" ? "The rule could not be evaluated: " : "") + message + (attribute != null ? ": " + attribute : "") + (detail != null ? " (" + detail + ")" : ""),
                    File = result.Name, Element = item.Name.LocalName == "Formula" ? (string)item.Attribute("Element") : (string)item.Attribute("Type") ?? (string)item.Attribute("Element"),
                    ProviderSubjectNo = (string)item.Attribute("ProviderSubjectNumber") ?? (string)item.Attribute("ProviderSubjectNo") ?? (string)item.Attribute("ParentProviderSubjectNo"),
                    ProviderContractNo = (string)item.Attribute("ProviderContractNo")
                });
            }
        }
    }
}
