﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL.Cocree
{
    /// <summary>
    /// BSP's COCREE rules the Workbench applied (limits, file names, the CSDF layout) and the small conversions the
    /// export and the header totals share.
    /// </summary>
    public static class CocreeRules
    {
        public const string Error = "Error";
        public const string Warning = "Warning";
        public const string Information = "Info";

        /// <summary>BSP accepts at most this many records in one file (40-004).</summary>
        public const int BspRecordsPerFile = 300000;

        /// <summary>The largest records-per-file the Workbench let the person choose.</summary>
        public const int MaxRecordsPerFile = 1000000;

        /// <summary>File names number files 01–59 and provisions 00–59.</summary>
        public const int MaxFileNumber = 59;
        public const int MaxProvisionNumber = 59;

        public const string UnrecognizedPrefix = "**^ Unrecognized Value: ";
        public const string UnrecognizedSuffix = " ^**";

        /// <summary>Header SubmissionType values the Workbench offered.</summary>
        public static readonly IReadOnlyList<string> SubmissionTypes = new[] { "0", "1" };

        // The Body elements BSP's CSDF has, by what they count as in the Header.
        private static readonly string[] SubjectElements = { "INDIVIDUALS", "COMPANIES", "COMPANYLINKS" };
        private static readonly string[] ContractElements = { "INSTALLMENTS", "NONINSTALLMENTS", "CREDITCARDS", "OTHERCREDITACCOMODATIONS", "INVESTMENTS", "OFFBALANCESHEETS" };
        private const string NegativeEventElement = "SUBJECTNEGATIVEEVENTS";

        public const string SubjectSheet = "subject";
        public const string ExposureSheet = "exposure";

        /// <summary>Subject and Links sheets give subjects, Exposure and Negative sheets exposures; other sheets (File Info) none.</summary>
        public static string SheetKind(string sheetName)
        {
            switch (CocreeConfiguration.Clean(sheetName))
            {
                case "SUBJECT":
                case "LINKS":
                    return SubjectSheet;
                case "EXPOSURE":
                case "NEGATIVE":
                    return ExposureSheet;
                default:
                    return null;
            }
        }

        public static bool IsCompanyLink(string element) => CocreeConfiguration.Clean(element) == "COMPANYLINKS";

        public static bool IsNegativeEvent(string element) => CocreeConfiguration.Clean(element) == NegativeEventElement;

        // ---------- values ----------

        /// <summary>
        /// True when the File Info sheet's Month (a name such as "September" or "Sep", or 1–12) and Year are the
        /// reference date's month and year.
        /// </summary>
        public static bool IsSameMonth(string month, string year, DateTime referenceDate)
        {
            int yearNumber;
            if (!int.TryParse((year ?? "").Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out yearNumber) || yearNumber != referenceDate.Year)
            {
                return false;
            }

            var text = (month ?? "").Trim();
            int monthNumber;
            if (int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out monthNumber))
            {
                return monthNumber == referenceDate.Month;
            }

            var names = CultureInfo.InvariantCulture.DateTimeFormat;
            return string.Equals(text, names.GetMonthName(referenceDate.Month), StringComparison.OrdinalIgnoreCase)
                || string.Equals(text, names.GetAbbreviatedMonthName(referenceDate.Month), StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// An amount as the Workbench wrote it: a number cell as a decimal (15 significant digits, no exponent), a text
        /// cell parsed as a number with optional thousands separators ("1,234.50" → 1234.50). Empty stays empty.
        /// </summary>
        public static bool TryMoney(CocreeCell cell, out string value)
        {
            value = "";
            switch (cell.Kind)
            {
                case CocreeCellKind.Empty:
                    return true;
                case CocreeCellKind.Number:
                    value = Convert.ToDecimal(cell.Number).ToString(CultureInfo.InvariantCulture);
                    return true;
                case CocreeCellKind.Text:
                    if (cell.Text.Trim().Length == 0)
                    {
                        return true;
                    }

                    decimal amount;
                    if (decimal.TryParse(cell.Text.Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out amount))
                    {
                        value = amount.ToString(CultureInfo.InvariantCulture);
                        return true;
                    }

                    return false;
                default:
                    return false; // a date or TRUE/FALSE is not an amount
            }
        }

        /// <summary>False when the text has a character an XML file cannot hold (control characters other than tab and line breaks).</summary>
        public static bool IsXmlText(string text)
        {
            foreach (var ch in text)
            {
                if (ch < 0x20 && ch != '\t' && ch != '\n' && ch != '\r')
                {
                    return false;
                }

                if (ch == '￾' || ch == '￿')
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>Sets an attribute's value where it is, or adds it at the end (as XElement.SetAttributeValue does).</summary>
        public static void SetValue(List<KeyValuePair<string, string>> attributes, string name, string value)
        {
            var index = attributes.FindIndex(a => a.Key == name);
            if (index < 0)
            {
                attributes.Add(new KeyValuePair<string, string>(name, value));
            }
            else
            {
                attributes[index] = new KeyValuePair<string, string>(name, value);
            }
        }

        // ---------- writing CSDF XML ----------

        /// <summary>How the Workbench wrote every COCREE file: UTF-8 without BOM, tab indentation, LF line ends.</summary>
        public static XmlWriterSettings WriterSettings()
        {
            return new XmlWriterSettings
            {
                Encoding = new UTF8Encoding(false),
                Indent = true,
                IndentChars = "\t",
                NewLineChars = "\n",
                NewLineHandling = NewLineHandling.Entitize,
                CloseOutput = false
            };
        }

        public static void Save(XDocument document, Stream stream)
        {
            document.Declaration = new XDeclaration("1.0", "UTF-8", null);
            using (var writer = XmlWriter.Create(stream, WriterSettings()))
            {
                document.Save(writer);
            }
        }

        // ---------- checking CSDF files (Stage 1 and the layout) ----------

        /// <summary>
        /// BSP's Stage 1 checks of a file name, as the Workbench made them:
        /// &lt;provider code&gt;_CSDF_&lt;yyyyMMdd&gt;&lt;attempt 00–23&gt;&lt;provision 00–59&gt;&lt;file 01–59&gt;.xml, for one of
        /// <paramref name="providerCodes"/>, with a date that is not in the future.
        /// </summary>
        public static List<CocreeIssueDto> CheckFileName(string fileName, IEnumerable<string> providerCodes, DateTime today)
        {
            var issues = new List<CocreeIssueDto>();
            Action<string, string> add = (code, message) => issues.Add(new CocreeIssueDto { Severity = Error, Code = code, Message = message, File = fileName });
            var match = Regex.Match(fileName ?? "", @"\A(?<provider>[^_]*)_(?<kind>[^_]*)_(?<date>\d{8})(?<attempt>\d{2})(?<provision>\d{2})(?<file>\d{2})\.(?i:xml)\z");
            if (!match.Success)
            {
                add("EW-ERR", "Invalid filename format: it must be <provider code>_CSDF_<yyyyMMdd><attempt 00–23><provision 00–59><file 01–59>.xml.");
                return issues;
            }

            if (!providerCodes.Contains(match.Groups["provider"].Value) || match.Groups["kind"].Value != "CSDF")
            {
                add("EW-ERR", "Invalid filename format: " + match.Groups["provider"].Value + " is not the provider code of an approved bank profile, or the name does not say CSDF.");
            }

            DateTime date;
            if (!DateTime.TryParseExact(match.Groups["date"].Value, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date) || date.Date > today.Date)
            {
                add("30-007", "'FILE REFERENCE DATE' INTO THE HEADER/ FOOTER IS NOT VALID OR IT IS GREATER THAN SYSDATE");
            }

            if (int.Parse(match.Groups["attempt"].Value, CultureInfo.InvariantCulture) > 23)
            {
                add("EW-ERR", "FILENAME: SUBMISSION ATTEMPTS MUST BE BETWEEN 0 TO 23");
            }

            if (int.Parse(match.Groups["provision"].Value, CultureInfo.InvariantCulture) > MaxProvisionNumber)
            {
                add("EW-ERR", "FILENAME: PROVISION MUST BE BETWEEN 0 TO 59");
            }

            var number = int.Parse(match.Groups["file"].Value, CultureInfo.InvariantCulture);
            if (number < 1 || number > MaxFileNumber)
            {
                add("EW-ERR", "FILENAME: FILE NUMBER MUST BE BETWEEN 1 TO 59");
            }

            return issues;
        }

        /// <summary>30-017: the file must be UTF-8 without a byte order mark.</summary>
        public static bool HasByteOrderMark(byte[] start)
        {
            return (start.Length >= 3 && start[0] == 0xEF && start[1] == 0xBB && start[2] == 0xBF)
                || (start.Length >= 2 && ((start[0] == 0xFF && start[1] == 0xFE) || (start[0] == 0xFE && start[1] == 0xFF)));
        }

        /// <summary>
        /// Reads a CSDF file and counts its records the way the Workbench's Update Header did, checking its layout: one
        /// Header, Body and Footer under CRIMS_Submission_Input (30-013, 30-014), a Body with records (30-016) of known
        /// elements, at most 300,000 records (40-004, a warning) and, when <paramref name="referenceDate"/> is given, that
        /// FileReferenceDate.
        /// </summary>
        public static CsdfFile ReadCsdf(string fileName, byte[] content, DateTime? referenceDate)
        {
            var file = new CsdfFile(fileName);
            Action<string, string, string> add = (severity, code, message) => file.Issues.Add(new CocreeIssueDto { Severity = severity, Code = code, Message = message, File = fileName });
            if (HasByteOrderMark(content.Take(3).ToArray()))
            {
                add(Error, "30-017", "CHARACTER SET OF FILE MUST BE UTF-8 WITHOUT BOM");
            }

            try
            {
                using (var stream = new MemoryStream(content, false))
                {
                    file.Document = SafeXml.Load(stream);
                }
            }
            catch (XmlException ex)
            {
                add(Error, "", "The file is not readable XML: " + ex.Message);
                return file;
            }

            var root = file.Document.Root;
            if (root == null || CocreeConfiguration.Clean(root.Name.LocalName) != "CRIMS_SUBMISSION_INPUT")
            {
                add(Error, "", "INVALID XML FORMAT: the root element must be CRIMS_Submission_Input.");
                return file;
            }

            var parts = root.Elements().GroupBy(e => CocreeConfiguration.Clean(e.Name.LocalName)).ToDictionary(g => g.Key, g => g.Count());
            foreach (var unknown in parts.Keys.Where(k => k != "HEADER" && k != "BODY" && k != "FOOTER"))
            {
                add(Error, "", "Element '" + unknown + "' is unrecognized!");
            }

            Action<string, string> once = (part, code) =>
            {
                int count;
                parts.TryGetValue(part, out count);
                if (count == 0) add(Error, code, part + " IS NOT PRESENT");
                else if (count > 1) add(Error, code, "MORE THAN 1 OCCURENCE OF '" + part + "' FOUND");
            };
            once("HEADER", "30-013");
            once("BODY", "EW-ERR");
            once("FOOTER", "30-014");
            if (file.Issues.Any(i => i.Severity == Error))
            {
                return file;
            }

            var header = root.Elements().First(e => CocreeConfiguration.Clean(e.Name.LocalName) == "HEADER");
            var date = (string)header.Attribute("FileReferenceDate") ?? "";
            if (referenceDate.HasValue && date != referenceDate.Value.ToString("yyyyMMdd", CultureInfo.InvariantCulture))
            {
                add(Error, "", "There was an issue with the Header>FileReferenceDate: the reference dates don't match (" + date + ").");
            }

            var body = root.Elements().First(e => CocreeConfiguration.Clean(e.Name.LocalName) == "BODY");
            var records = body.Elements().ToList();
            if (records.Count == 0)
            {
                add(Error, "30-016", "FILE SPECIFIED IS EMPTY");
            }
            else if (body.Descendants().Count() > BspRecordsPerFile)
            {
                add(Warning, "40-004", "WARNING! The total subject and exposure records exceeded " + BspRecordsPerFile.ToString("N0", CultureInfo.InvariantCulture) + ".");
            }

            foreach (var group in records.GroupBy(e => e.Name.LocalName))
            {
                var name = CocreeConfiguration.Clean(group.Key);
                if (SubjectElements.Contains(name)) file.Subjects += group.Count();
                else if (ContractElements.Contains(name)) file.Contracts += group.Count();
                else if (name == NegativeEventElement) file.NegativeEvents += group.Count();
                else add(Error, "30-009", "'RECORD TYPE' IS NOT VALID = " + group.Key);

                file.Elements.Add(new CocreeElementCountDto { Element = group.Key, Count = group.Count() });
            }

            return file;
        }

        /// <summary>Writes the submission's totals into a file's Header (TotalSubjectRecords, TotalContractRecords, TotalNegativeEventRecords).</summary>
        public static void WriteTotals(XDocument document, int subjects, int contracts, int negativeEvents, Stream output)
        {
            var header = document.Root.Elements().First(e => CocreeConfiguration.Clean(e.Name.LocalName) == "HEADER");
            header.SetAttributeValue("TotalSubjectRecords", subjects);
            header.SetAttributeValue("TotalContractRecords", contracts);
            header.SetAttributeValue("TotalNegativeEventRecords", negativeEvents);
            Save(document, output);
        }

        /// <summary>A CSDF file read for its totals.</summary>
        public sealed class CsdfFile
        {
            public CsdfFile(string name)
            {
                Name = name;
            }

            public string Name { get; }

            public XDocument Document { get; set; }

            public int Subjects { get; set; }

            public int Contracts { get; set; }

            public int NegativeEvents { get; set; }

            public List<CocreeElementCountDto> Elements { get; } = new List<CocreeElementCountDto>();

            public List<CocreeIssueDto> Issues { get; } = new List<CocreeIssueDto>();
        }
    }
}
