using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL.Cocree
{
    /// <summary>
    /// One of BSP's validation rules from the Workbench's cocree_validations.xlsx. A row is a rule when it has both a Left
    /// and a Right Formula; the rule is the DataColumn expression "(Left)Operator(Right)", evaluated on each record of its
    /// element, and the record is wrong when it is FALSE.
    /// </summary>
    public sealed class CocreeValidationRule
    {
        private static readonly string[] RequiredColumns = { "Error Code", "Message", "Element", "Left Formula", "Operator", "Right Formula" };

        public CocreeValidationRule(string element, string code, string message, string expression)
        {
            Element = element;
            Code = code;
            Message = message;
            Expression = expression;
        }

        public string Element { get; }

        /// <summary>BSP's error code, e.g. "10-002" or "10-191 (e)"; also the name of the rule's result column.</summary>
        public string Code { get; }

        public string Message { get; }

        public string Expression { get; }

        /// <summary>
        /// True for a formula with an aggregate (Sum, Count, …): the Workbench evaluated every rule on a table of one record,
        /// so such a rule must see one record at a time to give the same result.
        /// </summary>
        public bool EvaluatedPerRecord => System.Text.RegularExpressions.Regex.IsMatch(Expression, @"\b(SUM|COUNT|AVG|MIN|MAX|STDEV|VAR)\s*\(", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

        /// <summary>
        /// The rules of the workbook's Validations sheet (or of its first sheet, as the Workbench read it). Rows without both
        /// formulas are explanations, not rules.
        /// </summary>
        public static List<CocreeValidationRule> Read(List<WorkbenchTableDto> workbook, List<string> problems, List<string> notes)
        {
            var rules = new List<CocreeValidationRule>();
            var sheet = workbook.FirstOrDefault(t => string.Equals(t.Name.Trim(), "Validations", StringComparison.OrdinalIgnoreCase)) ?? workbook.FirstOrDefault();
            if (sheet == null)
            {
                problems.Add("The validation rules workbook (cocree_validations.xlsx) is missing.");
                return rules;
            }

            var columns = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < sheet.Columns.Count; i++)
            {
                if (!columns.ContainsKey(sheet.Columns[i].Trim()))
                {
                    columns[sheet.Columns[i].Trim()] = i;
                }
            }

            var missing = RequiredColumns.Where(c => !columns.ContainsKey(c)).ToList();
            if (missing.Count > 0)
            {
                problems.Add("The sheet " + sheet.Name + " of the validation rules workbook has no column " + string.Join(", ", missing) + ".");
                return rules;
            }

            Func<List<string>, string, string> cell = (row, column) =>
            {
                var i = columns[column];
                return i < row.Count ? row[i] ?? "" : "";
            };

            var withoutFormula = 0;
            foreach (var row in sheet.Rows)
            {
                var left = cell(row, "Left Formula");
                var right = cell(row, "Right Formula");
                if (left.Trim().Length == 0 || right.Trim().Length == 0)
                {
                    withoutFormula++;
                    continue;
                }

                var element = cell(row, "Element").Trim();
                var code = cell(row, "Error Code");
                if (code.Trim().Length == 0 || element.Length == 0)
                {
                    problems.Add("Validations: a rule (" + left.Trim() + ") has no Error Code or Element.");
                    continue;
                }

                if (rules.Any(r => CocreeConfiguration.Clean(r.Element) == CocreeConfiguration.Clean(element) && string.Equals(r.Code, code, StringComparison.OrdinalIgnoreCase)))
                {
                    problems.Add("Validations: " + element + " has the error code " + code.Trim() + " twice.");
                    continue;
                }

                rules.Add(new CocreeValidationRule(element, code, cell(row, "Message"), "(" + left + ")" + cell(row, "Operator") + "(" + right + ")"));
            }

            if (withoutFormula > 0)
            {
                notes.Add("Validations: " + withoutFormula.ToString("N0", CultureInfo.InvariantCulture) + " rows without both formulas are not checked.");
            }

            return rules;
        }
    }
}
