using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL.Cocree
{
    /// <summary>What the person chose on the Generate tab.</summary>
    public sealed class CocreeExportParameters
    {
        /// <summary>The 10-digit provider code (Header and file name).</summary>
        public string ProviderCode { get; set; } = "";

        /// <summary>Header FileReferenceDate; the month and year of every input file must match it.</summary>
        public DateTime ReferenceDate { get; set; }

        /// <summary>Header SubmissionType ("0" or "1").</summary>
        public string SubmissionType { get; set; } = "0";

        /// <summary>Header Version ("1.0").</summary>
        public string Version { get; set; } = "1.0";

        public string ProviderComments { get; set; } = "";

        /// <summary>At most this many records (subjects, contracts and negative events) go into one file.</summary>
        public int MaxRecordsPerFile { get; set; } = CocreeRules.BspRecordsPerFile;
    }

    /// <summary>An uploaded input workbook.</summary>
    public sealed class CocreeInput
    {
        public CocreeInput(string name, Func<Stream> open)
        {
            Name = name;
            Open = open;
        }

        public string Name { get; }

        public Func<Stream> Open { get; }
    }

    /// <summary>
    /// Builds the CSDF XML (CRIMS_Submission_Input) from the BU's COCREE input workbooks, step for step as the
    /// Regulatory Reports Workbench's "Generate XML File - COCREE v2.0" did:
    /// <list type="number">
    /// <item>each workbook must start with its File Info sheet, name an input file of the configuration, be for the
    /// reference month and have the configured sheets with the configured columns in the configured order;</item>
    /// <item>every row whose Record Type the configuration knows becomes an element (Individuals, Installments, …), its
    /// attributes filled from the mapped columns, wording turned into BSP codes with the code lists (an unknown value is
    /// written as "**^ Unrecognized Value: … ^**" so BSP's validation catches it), amounts as plain decimals;</item>
    /// <item>a subject sent in several files is kept once, from the file highest in the subject hierarchy;</item>
    /// <item>subjects without exposures, exposures without a subject and duplicate contract numbers stop the export and are
    /// listed in the Workbench's error report (Export_to_XML_Errors);</item>
    /// <item>subjects with their exposures are packed into files of at most <see cref="CocreeExportParameters.MaxRecordsPerFile"/>
    /// records, named &lt;provider&gt;_CSDF_&lt;yyyyMMdd&gt;00&lt;provision&gt;&lt;file number&gt;.xml, each with its own
    /// Header and Footer totals.</item>
    /// </list>
    /// Where the Workbench silently lost data (rows skipped, values left out), this run reports an error or a warning instead.
    /// </summary>
    public sealed class CocreeExporter
    {
        private readonly CocreeConfiguration configuration;
        private readonly CocreeExportParameters parameters;
        private readonly Action<string, int> progress;
        private readonly CocreeExportResultDto result = new CocreeExportResultDto();
        private readonly List<Record> subjects = new List<Record>();
        private readonly List<Record> exposures = new List<Record>();
        private int recordsRead;

        /// <param name="progress">Called with what is being done and the percent done (0–100).</param>
        public CocreeExporter(CocreeConfiguration configuration, CocreeExportParameters parameters, Action<string, int> progress = null)
        {
            this.configuration = configuration;
            this.parameters = parameters;
            this.progress = progress ?? ((stage, percent) => { });
        }

        /// <summary>Reads the input workbooks, checks them and, when nothing stops it, writes the XML files to <paramref name="output"/>.</summary>
        public CocreeExportResultDto Run(IList<CocreeInput> inputs, ICocreeOutput output)
        {
            Log("Batch conversion process started.");

            // 1. Read every workbook; one with a problem is reported and its data left out (nothing is written then).
            for (var i = 0; i < inputs.Count; i++)
            {
                progress("Reading " + inputs[i].Name, 5 + 60 * i / Math.Max(1, inputs.Count));
                Log("Loading file data: " + inputs[i].Name);
                ReadInput(inputs[i]);
            }

            if (HasErrors)
            {
                Log("The input files have errors, so no XML was written.");
                return result;
            }

            if (subjects.Count == 0 && exposures.Count == 0)
            {
                Error("", "The input files have no records to export.", null);
                return result;
            }

            // 2. One record per subject, then the checks between subjects and exposures.
            progress("Consolidating subjects and exposures", 70);
            Log("All data loaded. Consolidation started...");
            var distinctSubjects = DistinctSubjects();
            if (!CheckSubjectsAndExposures(distinctSubjects, output))
            {
                Log("Error(s) found during XML export. Please see the XML report.");
                return result;
            }

            // 3. The files.
            Log("Consolidation successful. XML conversion started...");
            WriteFiles(distinctSubjects, output);
            result.Subjects = distinctSubjects.Count;
            result.Contracts = exposures.Count(e => !CocreeRules.IsNegativeEvent(e.Element));
            result.NegativeEvents = exposures.Count(e => CocreeRules.IsNegativeEvent(e.Element));
            result.Succeeded = !HasErrors;
            Log("Total valid Subjects in this batch: " + result.Subjects.ToString("N0", CultureInfo.InvariantCulture));
            Log("Total valid Contracts (Exposures) in this batch: " + result.Contracts.ToString("N0", CultureInfo.InvariantCulture));
            Log("Total valid Negative Event Records in this batch: " + result.NegativeEvents.ToString("N0", CultureInfo.InvariantCulture));
            Log("Batch conversion process ended.");
            return result;
        }

        private bool HasErrors => result.Issues.Any(i => i.Severity == CocreeRules.Error);

        // ---------- 1. reading one input workbook ----------

        private void ReadInput(CocreeInput input)
        {
            IList<CocreeSheet> sheets;
            try
            {
                using (var stream = input.Open())
                {
                    sheets = CocreeWorkbookReader.Read(stream);
                }
            }
            catch (CocreeFileException ex)
            {
                Error("", ex.Message, input.Name);
                return;
            }
            catch (Exception ex) when (ex is InvalidDataException || ex is XmlException || ex is IOException)
            {
                Error("", "The workbook could not be read: " + ex.Message, input.Name);
                return;
            }

            // The first sheet is File Info: it names the input file and the month and year it is for.
            if (sheets.Count == 0 || CocreeConfiguration.Clean(sheets[0].Name) != CocreeConfiguration.FileInfoSheet)
            {
                Error("", "The first sheet must be 'File Info'.", input.Name);
                return;
            }

            var fileInfo = sheets[0];
            var fileName = fileInfo.Rows.Count > 0 ? fileInfo.Cell(0, "File").Value : "";
            var file = configuration.InputFiles.FirstOrDefault(f => CocreeConfiguration.Clean(f.Name) == CocreeConfiguration.Clean(fileName));
            if (file == null)
            {
                Error("", "File type not found: the File Info sheet names '" + fileName + "', which is not an input file of the COCREE configuration.", input.Name);
                return;
            }

            var month = fileInfo.Rows.Count > 0 ? fileInfo.Cell(0, "Month").Value : "";
            var year = fileInfo.Rows.Count > 0 ? fileInfo.Cell(0, "Year").Value : "";
            if (!CocreeRules.IsSameMonth(month, year, parameters.ReferenceDate))
            {
                Error("", "The file reference date is not equal with the Month and Year in the input file '" + file.Name + "' ("
                    + month + " " + year + "; reference date " + parameters.ReferenceDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) + ").", input.Name);
                return;
            }

            // Every sheet must be a configured sheet of this file, with the configured columns in the configured order.
            var configuredSheets = configuration.Sheets.Where(s => s.FileId == file.Id).ToList();
            var problems = false;
            foreach (var sheet in sheets)
            {
                var configured = configuredSheets.FirstOrDefault(s => CocreeConfiguration.Clean(s.Name) == CocreeConfiguration.Clean(sheet.Name));
                if (configured == null)
                {
                    Error("", sheet.Name.Trim() + " is an invalid sheet for '" + file.Name + "'.", input.Name, sheet.Name);
                    problems = true;
                    continue;
                }

                var expected = configuration.Columns.Where(c => c.SheetId == configured.Id).ToList();
                for (var x = 0; x < expected.Count; x++)
                {
                    if (x >= sheet.Columns.Count)
                    {
                        Error("", "The sheet '" + sheet.Name.Trim() + "' ends before the column '" + expected[x].Name + "' (column " + (x + 1).ToString(CultureInfo.InvariantCulture)
                            + " of the configuration).", input.Name, sheet.Name);
                        problems = true;
                        break;
                    }

                    if (CocreeConfiguration.Clean(expected[x].Name) != CocreeConfiguration.Clean(sheet.Columns[x]))
                    {
                        Error("", "The column sequence between the config and the file do not match for '" + sheet.Name.Trim() + "'. [Configuration: "
                            + expected[x].Name + "] vs [File: " + sheet.Columns[x].Trim() + "]", input.Name, sheet.Name);
                        problems = true;
                        break;
                    }
                }
            }

            foreach (var missing in configuredSheets.Where(s => !sheets.Any(sheet => CocreeConfiguration.Clean(sheet.Name) == CocreeConfiguration.Clean(s.Name))))
            {
                Warning("", "The sheet '" + missing.Name + "' of '" + file.Name + "' is not in the workbook, so it adds no records.", input.Name, missing.Name);
            }

            if (problems)
            {
                return;
            }

            // The data sheets: Subject and Links give subjects, Exposure and Negative give exposures.
            foreach (var sheet in sheets)
            {
                var configured = configuredSheets.First(s => CocreeConfiguration.Clean(s.Name) == CocreeConfiguration.Clean(sheet.Name));
                var kind = CocreeRules.SheetKind(configured.Name);
                if (kind != null)
                {
                    ReadRecords(input.Name, file, configured, sheet, kind == CocreeRules.SubjectSheet ? subjects : exposures, kind == CocreeRules.SubjectSheet);
                }
            }
        }

        /// <summary>Turns the rows of one data sheet into records, one record type (element) at a time.</summary>
        private void ReadRecords(string inputName, CocreeConfiguration.InputFile file, CocreeConfiguration.InputSheet configured, CocreeSheet sheet,
            List<Record> target, bool isSubject)
        {
            int recordTypeColumn;
            if (!sheet.ColumnIndex.TryGetValue("Record Type", out recordTypeColumn))
            {
                Error("", "The sheet has no 'Record Type' column, so its rows cannot be read.", inputName, sheet.Name);
                return;
            }

            // The columns of this sheet that fill an attribute.
            var columnIds = new HashSet<string>(configuration.Columns.Where(c => c.SheetId == configured.Id).Select(c => c.Id));
            var mapped = configuration.Mappings.Where(m => columnIds.Contains(m.ColumnId)).ToList();
            var rules = configuration.RecordTypes.Where(r => r.SheetId == configured.Id)
                .OrderBy(r => r.Element, StringComparer.InvariantCulture).ThenBy(r => r.RecordType, StringComparer.InvariantCulture).ToList();
            if (rules.Count > 0 && mapped.Count == 0)
            {
                Error("", "No mapping found for sheet '" + sheet.Name.Trim() + "'.", inputName, sheet.Name);
                return;
            }

            var dateCells = 0;
            var unknownCodes = new UnknownCodes();
            foreach (var rule in rules)
            {
                var fields = Fields(rule.Element, mapped, sheet, inputName);
                if (fields == null)
                {
                    continue;
                }

                var recordType = CocreeConfiguration.Clean(rule.RecordType);
                var read = 0;
                for (var row = 0; row < sheet.Rows.Count; row++)
                {
                    if (CocreeConfiguration.Clean(sheet.Rows[row][recordTypeColumn].Value) != recordType)
                    {
                        continue;
                    }

                    var record = ReadRecord(rule, fields, sheet, row, inputName, unknownCodes, ref dateCells);
                    if (record == null)
                    {
                        continue;
                    }

                    record.Hierarchy = file.SubjectHierarchy;
                    record.IsSubject = isSubject;
                    record.SubjectNumber = isSubject ? record.Value("ProviderSubjectNumber") : record.Value("ProviderSubjectNo");
                    record.ContractNumber = isSubject ? "" : record.Value("ProviderContractNo");
                    target.Add(record);
                    read++;
                }

                Log(sheet.Name.Trim() + " (" + inputName + "): " + read.ToString("N0", CultureInfo.InvariantCulture) + " " + rule.Element + " records (record type " + rule.RecordType + ").");
            }

            // Rows the Workbench skipped without a word: a Record Type the configuration does not know, or none at all.
            var known = new HashSet<string>(rules.Select(r => CocreeConfiguration.Clean(r.RecordType)));
            var skipped = new Dictionary<string, int>(StringComparer.Ordinal);
            for (var row = 0; row < sheet.Rows.Count; row++)
            {
                var type = CocreeConfiguration.Clean(sheet.Rows[row][recordTypeColumn].Value);
                if (!known.Contains(type) && sheet.Rows[row].Any(cell => !cell.IsEmpty))
                {
                    int count;
                    skipped.TryGetValue(type, out count);
                    skipped[type] = count + 1;
                }
            }

            foreach (var type in skipped)
            {
                Warning("", type.Value.ToString("N0", CultureInfo.InvariantCulture) + (type.Value == 1 ? " row has " : " rows have ")
                    + (type.Key.Length == 0 ? "no Record Type" : "the Record Type '" + type.Key + "', which the configuration does not have for this sheet")
                    + "; " + (type.Value == 1 ? "it was" : "they were") + " left out.", inputName, sheet.Name);
            }

            // Wording the code lists do not have: one warning per column and value (the rows are counted).
            foreach (var unknown in unknownCodes.All)
            {
                Warning("", "'" + unknown.Value + "' is not in the code list " + unknown.CodeList.ToLowerInvariant() + " (" + unknown.Attribute + "): "
                    + unknown.Rows.ToString("N0", CultureInfo.InvariantCulture) + (unknown.Rows == 1 ? " row" : " rows, the first is row " + unknown.FirstRow.ToString(CultureInfo.InvariantCulture))
                    + ". It was written as " + CocreeRules.UnrecognizedPrefix + unknown.Value + CocreeRules.UnrecognizedSuffix + " for BSP's validation to report.",
                    inputName, sheet.Name, unknown.FirstRow, unknown.Column);
            }

            if (dateCells > 0)
            {
                Info("", dateCells.ToString("N0", CultureInfo.InvariantCulture) + " cells were Excel dates and were written as yyyyMMdd.", inputName, sheet.Name);
            }
        }

        /// <summary>
        /// The attributes of an element in configuration order, each with the column it is read from (or none). Null when
        /// a mapped column is missing from the sheet.
        /// </summary>
        private List<Field> Fields(string element, List<CocreeConfiguration.ColumnMapping> mapped, CocreeSheet sheet, string inputName)
        {
            var fields = new List<Field>();
            var missing = false;
            foreach (var attribute in configuration.Attributes.Where(a => CocreeConfiguration.Clean(a.Element) == CocreeConfiguration.Clean(element)))
            {
                var mappings = mapped.Where(m => m.AttributeId == attribute.Id).ToList();
                if (mappings.Count > 1)
                {
                    Warning("", "The attribute " + element + "/" + attribute.Name + " is mapped to " + mappings.Count.ToString(CultureInfo.InvariantCulture)
                        + " columns; the first (" + mappings[0].ColumnName + ") is used.", inputName, sheet.Name);
                }

                var column = -1;
                if (mappings.Count > 0 && !sheet.ColumnIndex.TryGetValue(mappings[0].ColumnName, out column))
                {
                    Error("", "The column '" + mappings[0].ColumnName + "' (for " + element + "/" + attribute.Name + ") is not in the sheet.", inputName, sheet.Name);
                    missing = true;
                }

                fields.Add(new Field(attribute, mappings.Count > 0 ? mappings[0].ColumnName : null, column));
            }

            return missing ? null : fields;
        }

        private Record ReadRecord(CocreeConfiguration.RecordTypeRule rule, List<Field> fields, CocreeSheet sheet, int row, string inputName,
            UnknownCodes unknownCodes, ref int dateCells)
        {
            var record = new Record(recordsRead++, rule.Element, rule.BodySequence, fields.Select(f => f.Attribute.Name).ToArray(), new string[fields.Count])
            {
                Source = inputName,
                Sheet = sheet.Name,
                Row = sheet.RowNumbers[row]
            };

            var valid = true;
            for (var i = 0; i < fields.Count; i++)
            {
                var field = fields[i];
                if (field.Column < 0)
                {
                    record.Values[i] = ""; // an attribute no column fills is written empty
                    continue;
                }

                var cell = sheet.Rows[row][field.Column];
                if (cell.Kind == CocreeCellKind.Date)
                {
                    dateCells++;
                }

                string value;
                if (field.Attribute.CodeList.Length > 0)
                {
                    value = Code(field.Attribute.CodeList, cell);
                    if (value.StartsWith(CocreeRules.UnrecognizedPrefix, StringComparison.Ordinal))
                    {
                        unknownCodes.Add(rule.Element + "/" + field.Attribute.Name, field.Attribute.CodeList, field.ColumnName, cell.Value, record.Row);
                    }
                }
                else if (field.Attribute.IsMoney)
                {
                    if (!CocreeRules.TryMoney(cell, out value))
                    {
                        Error("", "'" + cell.Value + "' is not an amount (" + rule.Element + "/" + field.Attribute.Name + ").", inputName, sheet.Name, record.Row, field.ColumnName);
                        valid = false;
                        continue;
                    }
                }
                else
                {
                    value = cell.Value;
                }

                if (!CocreeRules.IsXmlText(value))
                {
                    Error("", "The value has a character XML cannot hold (a control character) (" + rule.Element + "/" + field.Attribute.Name + ").",
                        inputName, sheet.Name, record.Row, field.ColumnName);
                    valid = false;
                    continue;
                }

                record.Values[i] = value;
            }

            return valid ? record : null;
        }

        /// <summary>BSP's code for the BU's wording; empty stays empty; anything else unknown is marked for BSP's validation.</summary>
        private string Code(string codeList, CocreeCell cell)
        {
            string code;
            if (configuration.CodeLists[codeList].TryGetValue(CocreeConfiguration.Clean(cell.Value), out code))
            {
                return code;
            }

            return cell.Value.Length == 0 ? "" : CocreeRules.UnrecognizedPrefix + cell.Value + CocreeRules.UnrecognizedSuffix;
        }

        // ---------- 2. subjects and the checks between subjects and exposures ----------

        /// <summary>
        /// One record per subject number, in order of first appearance: the one from the file with the lowest
        /// subject_hierarchy (the first of them when a file has it twice). A subject without a number (and every company
        /// link) counts on its own.
        /// </summary>
        private List<Record> DistinctSubjects()
        {
            var order = new List<string>();
            var best = new Dictionary<string, Record>(StringComparer.Ordinal);
            var counter = 0;
            foreach (var subject in subjects)
            {
                var key = subject.SubjectNumber.Length > 0 ? subject.SubjectNumber : "\u0000" + (counter++).ToString(CultureInfo.InvariantCulture);
                subject.SubjectKey = key;
                Record kept;
                if (!best.TryGetValue(key, out kept))
                {
                    best[key] = subject;
                    order.Add(key);
                }
                else if (subject.Hierarchy < kept.Hierarchy)
                {
                    best[key] = subject;
                }
            }

            var duplicates = subjects.Count - order.Count;
            if (duplicates > 0)
            {
                Info("", duplicates.ToString("N0", CultureInfo.InvariantCulture) + " subject records repeat a subject already sent in another row or file; "
                    + "each subject was kept once, from the file highest in the subject hierarchy.", null);
            }

            foreach (var exposure in exposures)
            {
                exposure.SubjectKey = exposure.SubjectNumber;
            }

            return order.Select(key => best[key]).ToList();
        }

        /// <summary>The Workbench's four checks. False (with the error report written) when one fails.</summary>
        private bool CheckSubjectsAndExposures(List<Record> distinctSubjects, ICocreeOutput output)
        {
            var report = new XElement("Export_to_XML_Errors");
            var exposuresPerSubject = exposures.GroupBy(e => e.SubjectKey, StringComparer.Ordinal).ToDictionary(g => g.Key, g => g.Count(), StringComparer.Ordinal);
            var subjectKeys = new HashSet<string>(distinctSubjects.Select(s => s.SubjectKey), StringComparer.Ordinal);

            // Subjects (not company links) without any exposure.
            var noExposures = distinctSubjects.Where(s => !CocreeRules.IsCompanyLink(s.Element) && !exposuresPerSubject.ContainsKey(s.SubjectKey)).ToList();
            if (noExposures.Count > 0)
            {
                var errors = new XElement("NoExposures", new XAttribute("Message", "Subject record with no corresponding exposure data."), new XAttribute("TotalFound", noExposures.Count));
                foreach (var subject in noExposures)
                {
                    errors.Add(new XElement("Record", new XAttribute("ProviderSubjectNumber", subject.SubjectNumber), new XAttribute("Element", subject.Element)));
                    Issue(CocreeRules.Error, "", "Subject record with no corresponding exposure data.", subject, subject.SubjectNumber, null);
                }

                report.Add(errors);
            }

            // The same contract number twice for one element.
            var duplicateNumbers = exposures.Where(e => e.ContractNumber.Length > 0)
                .GroupBy(e => e.Element + "\u0000" + e.ContractNumber, StringComparer.Ordinal).Where(g => g.Count() > 1).ToList();
            if (duplicateNumbers.Count > 0)
            {
                var errors = new XElement("DuplicateExposureNumber", new XAttribute("Error", "Duplicate exposure number."), new XAttribute("TotalFound", duplicateNumbers.Count));
                foreach (var group in duplicateNumbers)
                {
                    var first = group.First();
                    errors.Add(new XElement("Record", new XAttribute("ProviderContractNo", first.ContractNumber), new XAttribute("Element", first.Element)));
                    Issue(CocreeRules.Error, "", "Duplicate exposure number (" + group.Count().ToString(CultureInfo.InvariantCulture) + " records).", first, first.SubjectNumber, first.ContractNumber);
                }

                report.Add(errors);
            }

            // Exposures (and negative events) whose subject is not among the subjects.
            var noSubject = exposures.Where(e => !subjectKeys.Contains(e.SubjectKey)).OrderBy(e => e.ContractNumber, StringComparer.InvariantCulture).ToList();
            if (noSubject.Count > 0)
            {
                var errors = new XElement("NoSubjects", new XAttribute("Error", "Exposure record with no corresponding subject data found."), new XAttribute("TotalFound", noSubject.Count));
                foreach (var exposure in noSubject)
                {
                    errors.Add(CocreeRules.IsNegativeEvent(exposure.Element)
                        ? new XElement("Record", new XAttribute("ProviderSubjectNo", exposure.SubjectNumber), new XAttribute("Element", exposure.Element))
                        : new XElement("Record", new XAttribute("ProviderContractNo", exposure.ContractNumber), new XAttribute("Element", exposure.Element)));
                    Issue(CocreeRules.Error, "", "Exposure record with no corresponding subject data found.", exposure, exposure.SubjectNumber, exposure.ContractNumber);
                }

                report.Add(errors);
            }

            // The same contract number, subject and element twice (the same record sent twice).
            var duplicateRecords = exposures.Where(e => e.ContractNumber.Length > 0)
                .GroupBy(e => e.SubjectKey + "\u0000" + e.ContractNumber + "\u0000" + e.Element, StringComparer.Ordinal).Where(g => g.Count() > 1).ToList();
            if (duplicateRecords.Count > 0)
            {
                var errors = new XElement("DuplicateExposure",
                    new XAttribute("Error", "Exposure data with a duplicate combination of contract number, subject number, and element (record type)"),
                    new XAttribute("TotalFound", duplicateRecords.Count));
                foreach (var group in duplicateRecords)
                {
                    errors.Add(new XElement("Record", new XAttribute("ProviderContractNo", group.First().ContractNumber)));
                }

                report.Add(errors);
            }

            if (!report.HasElements)
            {
                return true;
            }

            var name = "Export_to_XML_Result_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".xml";
            using (var stream = output.Create(name))
            {
                CocreeRules.Save(new XDocument(report), stream);
            }

            result.ErrorReport = name;
            return false;
        }

        // ---------- 3. the files ----------

        private void WriteFiles(List<Record> distinctSubjects, ICocreeOutput output)
        {
            // Each subject travels with its exposures: a file takes whole subjects until the next would pass the limit.
            var exposuresOf = exposures.GroupBy(e => e.SubjectKey, StringComparer.Ordinal).ToDictionary(g => g.Key, g => g.ToList(), StringComparer.Ordinal);
            var batches = new List<List<Record>>();
            var current = new List<Record>();
            var room = parameters.MaxRecordsPerFile;
            foreach (var subject in distinctSubjects)
            {
                List<Record> own;
                var size = 1 + (exposuresOf.TryGetValue(subject.SubjectKey, out own) ? own.Count : 0);
                if (room - size < 0 && current.Count > 0)
                {
                    batches.Add(current);
                    current = new List<Record>();
                    room = parameters.MaxRecordsPerFile;
                }

                current.Add(subject);
                room -= size;
            }

            batches.Add(current);
            if (batches.Count > CocreeRules.MaxFileNumber * (CocreeRules.MaxProvisionNumber + 1))
            {
                Error("", "The records need " + batches.Count.ToString("N0", CultureInfo.InvariantCulture) + " files, more than BSP's file names allow. Raise the records per file.", null);
                return;
            }

            var provision = 0;
            var fileNumber = 1;
            for (var b = 0; b < batches.Count; b++)
            {
                // Subjects first, then exposures; each in Body order (Individuals, Companies, …), else in reading order.
                var batchSubjects = batches[b].OrderBy(s => s.Sequence).ToList();
                var batchExposures = batches[b].SelectMany(s => { List<Record> own; return exposuresOf.TryGetValue(s.SubjectKey, out own) ? own : new List<Record>(); })
                    .OrderBy(e => e.Sequence).ThenBy(e => e.Index).ToList();
                var name = string.Format(CultureInfo.InvariantCulture, "{0}_CSDF_{1:yyyyMMdd}00{2:00}{3:00}.xml", parameters.ProviderCode.Trim().ToUpperInvariant(),
                    parameters.ReferenceDate, provision, fileNumber);
                progress("Writing " + name, 75 + 24 * b / batches.Count);
                result.Files.Add(WriteFile(name, batchSubjects, batchExposures, output));

                if (fileNumber >= CocreeRules.MaxFileNumber)
                {
                    fileNumber = 1;
                    provision++;
                }
                else
                {
                    fileNumber++;
                }
            }
        }

        private CocreeOutputFileDto WriteFile(string name, List<Record> fileSubjects, List<Record> fileExposures, ICocreeOutput output)
        {
            var contracts = fileExposures.Count(e => !CocreeRules.IsNegativeEvent(e.Element));
            var negatives = fileExposures.Count - contracts;
            var header = HeaderValues("Header");
            CocreeRules.SetValue(header, "TotalSubjectRecords", fileSubjects.Count.ToString(CultureInfo.InvariantCulture));
            CocreeRules.SetValue(header, "TotalContractRecords", contracts.ToString(CultureInfo.InvariantCulture));
            CocreeRules.SetValue(header, "TotalNegativeEventRecords", negatives.ToString(CultureInfo.InvariantCulture));
            var footer = HeaderValues("Footer");
            CocreeRules.SetValue(footer, "NumberOfRecords", (fileSubjects.Count + fileExposures.Count).ToString(CultureInfo.InvariantCulture));

            long size;
            using (var stream = output.Create(name))
            using (var counting = new CountingStream(stream))
            {
                using (var writer = XmlWriter.Create(counting, CocreeRules.WriterSettings()))
                {
                    writer.WriteStartDocument();
                    writer.WriteStartElement("CRIMS_Submission_Input");
                    WriteElement(writer, "Header", header);
                    writer.WriteStartElement("Body");
                    foreach (var record in fileSubjects.Concat(fileExposures))
                    {
                        writer.WriteStartElement(record.Element);
                        for (var i = 0; i < record.Names.Length; i++)
                        {
                            writer.WriteAttributeString(record.Names[i], record.Values[i]);
                        }

                        writer.WriteEndElement();
                    }

                    writer.WriteEndElement();
                    WriteElement(writer, "Footer", footer);
                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                }

                size = counting.Written;
            }

            var file = new CocreeOutputFileDto
            {
                Name = name,
                Size = size,
                Subjects = fileSubjects.Count,
                Contracts = contracts,
                NegativeEvents = negatives,
                Records = fileSubjects.Count + fileExposures.Count,
                Elements = fileSubjects.Concat(fileExposures).GroupBy(r => r.Element).Select(g => new CocreeElementCountDto { Element = g.Key, Count = g.Count() }).ToList()
            };

            var summary = new StringBuilder("Export to XML successful: " + name + ".");
            foreach (var element in file.Elements)
            {
                summary.Append("\n - ").Append(element.Element).Append(": ").Append(element.Count.ToString("N0", CultureInfo.InvariantCulture));
            }

            Log(summary.ToString());
            if (file.Records > CocreeRules.BspRecordsPerFile)
            {
                result.Issues.Add(new CocreeIssueDto
                {
                    Severity = CocreeRules.Warning, Code = "40-004", File = name,
                    Message = "WARNING! The total subject and exposure records exceeded " + CocreeRules.BspRecordsPerFile.ToString("N0", CultureInfo.InvariantCulture) + "."
                });
            }

            return file;
        }

        /// <summary>The Header or Footer attributes in attribute_id order, filled from what the person chose.</summary>
        private List<KeyValuePair<string, string>> HeaderValues(string element)
        {
            var values = new List<KeyValuePair<string, string>>();
            foreach (var attribute in configuration.Attributes.Where(a => CocreeConfiguration.Clean(a.Element) == CocreeConfiguration.Clean(element)).OrderBy(a => a.Order))
            {
                string value;
                switch (CocreeConfiguration.Clean(attribute.Name))
                {
                    case "PROVIDERCODE": value = parameters.ProviderCode.Trim(); break;
                    case "PROVIDERCOMMENTS": value = (parameters.ProviderComments ?? "").Trim(); break;
                    case "FILEREFERENCEDATE": value = parameters.ReferenceDate.ToString("yyyyMMdd", CultureInfo.InvariantCulture); break;
                    case "VERSION": value = (parameters.Version ?? "").Trim(); break;
                    case "SUBMISSIONTYPE": value = parameters.SubmissionType ?? ""; break;
                    default: value = ""; break;
                }

                values.Add(new KeyValuePair<string, string>(attribute.Name, value));
            }

            return values;
        }

        private static void WriteElement(XmlWriter writer, string name, List<KeyValuePair<string, string>> attributes)
        {
            writer.WriteStartElement(name);
            foreach (var attribute in attributes)
            {
                writer.WriteAttributeString(attribute.Key, attribute.Value);
            }

            writer.WriteEndElement();
        }

        // ---------- messages ----------

        private void Log(string line)
        {
            result.Log.Add(line);
        }

        private void Error(string code, string message, string file, string sheet = null, int row = 0, string column = null)
        {
            result.Issues.Add(new CocreeIssueDto { Severity = CocreeRules.Error, Code = code, Message = message, File = file, Sheet = sheet, Row = row, Column = column });
            Log(message);
        }

        private void Warning(string code, string message, string file, string sheet = null, int row = 0, string column = null)
        {
            result.Issues.Add(new CocreeIssueDto { Severity = CocreeRules.Warning, Code = code, Message = message, File = file, Sheet = sheet, Row = row, Column = column });
        }

        private void Info(string code, string message, string file, string sheet = null)
        {
            result.Issues.Add(new CocreeIssueDto { Severity = CocreeRules.Information, Code = code, Message = message, File = file, Sheet = sheet });
        }

        private void Issue(string severity, string code, string message, Record record, string subject, string contract)
        {
            result.Issues.Add(new CocreeIssueDto
            {
                Severity = severity, Code = code, Message = message, File = record.Source, Sheet = record.Sheet, Row = record.Row, Element = record.Element,
                ProviderSubjectNo = subject, ProviderContractNo = string.IsNullOrEmpty(contract) ? null : contract
            });
        }

        // ---------- types ----------

        /// <summary>An attribute of an element and the sheet column it is read from (-1: no column, written empty).</summary>
        private sealed class Field
        {
            public Field(CocreeConfiguration.XmlAttribute attribute, string columnName, int column)
            {
                Attribute = attribute;
                ColumnName = columnName;
                Column = column;
            }

            public CocreeConfiguration.XmlAttribute Attribute { get; }

            public string ColumnName { get; }

            public int Column { get; }
        }

        /// <summary>One element of the Body: its attribute names and values, and where it came from.</summary>
        private sealed class Record
        {
            public Record(int index, string element, int sequence, string[] names, string[] values)
            {
                Index = index;
                Element = element;
                Sequence = sequence;
                Names = names;
                Values = values;
            }

            public string Element { get; }

            /// <summary>The element's place in the Body (Individuals 1 … SubjectNegativeEvents 10).</summary>
            public int Sequence { get; }

            public string[] Names { get; }

            public string[] Values { get; }

            /// <summary>Reading order, so sorting by <see cref="Sequence"/> keeps the order of the input.</summary>
            public int Index { get; }

            public bool IsSubject { get; set; }

            public int Hierarchy { get; set; }

            public string SubjectNumber { get; set; } = "";

            /// <summary>The subject number, or a key of its own for a subject without one (company links).</summary>
            public string SubjectKey { get; set; } = "";

            public string ContractNumber { get; set; } = "";

            public string Source { get; set; }

            public string Sheet { get; set; }

            public int Row { get; set; }

            public string Value(string attribute)
            {
                var i = Array.FindIndex(Names, n => string.Equals(n, attribute, StringComparison.OrdinalIgnoreCase));
                return i < 0 ? "" : (Values[i] ?? "");
            }
        }

        /// <summary>Values not found in a code list, grouped by attribute and value, in the order they were met.</summary>
        private sealed class UnknownCodes
        {
            private readonly Dictionary<string, UnknownCode> found = new Dictionary<string, UnknownCode>(StringComparer.Ordinal);

            public List<UnknownCode> All { get; } = new List<UnknownCode>();

            public void Add(string attribute, string codeList, string column, string value, int row)
            {
                var key = attribute + "\u0000" + value;
                UnknownCode unknown;
                if (!found.TryGetValue(key, out unknown))
                {
                    unknown = new UnknownCode { Attribute = attribute, CodeList = codeList, Column = column, Value = value, FirstRow = row };
                    found[key] = unknown;
                    All.Add(unknown);
                }

                unknown.Rows++;
            }
        }

        private sealed class UnknownCode
        {
            public string Attribute { get; set; }

            public string CodeList { get; set; }

            public string Column { get; set; }

            public string Value { get; set; }

            public int FirstRow { get; set; }

            public int Rows { get; set; }
        }

        /// <summary>Counts the bytes written (the file size shown) without buffering the file.</summary>
        private sealed class CountingStream : Stream
        {
            private readonly Stream inner;

            public CountingStream(Stream inner)
            {
                this.inner = inner;
            }

            public long Written { get; private set; }

            public override bool CanRead => false;

            public override bool CanSeek => false;

            public override bool CanWrite => true;

            public override long Length => Written;

            public override long Position { get { return Written; } set { throw new NotSupportedException(); } }

            public override void Flush() => inner.Flush();

            public override int Read(byte[] buffer, int offset, int count) { throw new NotSupportedException(); }

            public override long Seek(long offset, SeekOrigin origin) { throw new NotSupportedException(); }

            public override void SetLength(long value) { throw new NotSupportedException(); }

            public override void Write(byte[] buffer, int offset, int count)
            {
                inner.Write(buffer, offset, count);
                Written += count;
            }
        }
    }
}
