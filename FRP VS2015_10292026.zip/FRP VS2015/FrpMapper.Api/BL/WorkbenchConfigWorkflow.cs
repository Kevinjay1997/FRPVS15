using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// The Maker / Checker steps every configuration of the Workbench's tools goes through (COCREE, XML tools): a Maker
    /// (reference.manage) uploads a version, a Checker (reference.approve) who is not the Maker approves or rejects it, the
    /// Maker may cancel it. The stored procedures repeat these rules and write every step to the audit trail.
    /// </summary>
    public sealed class WorkbenchConfigWorkflow
    {
        private readonly IWorkbenchConfigRepository versions;
        private readonly ICurrentUser user;
        private readonly string kind;
        private readonly string title;

        /// <param name="kind">The <see cref="WorkbenchConfigKind"/>.</param>
        /// <param name="title">How messages name it, e.g. "COCREE configuration".</param>
        public WorkbenchConfigWorkflow(IWorkbenchConfigRepository versions, ICurrentUser user, string kind, string title)
        {
            this.versions = versions;
            this.user = user;
            this.kind = kind;
            this.title = title;
        }

        public static WorkflowException Invalid(string message) { return new WorkflowException(WorkflowErrorKind.Invalid, message); }

        public static WorkflowException Forbidden(string message) { return new WorkflowException(WorkflowErrorKind.Forbidden, message); }

        public bool Can(string permission) => user.IsAuthenticated && user.HasPermission(permission);

        public bool IsMakerOrChecker => Can(Permissions.ReferenceManage) || Can(Permissions.ReferenceApprove);

        public async Task<WorkbenchSettingsDto> ListAsync(CancellationToken cancellation)
        {
            if (!IsMakerOrChecker)
                throw Forbidden("Only the Makers and Checkers of reference data can see the " + title + " versions.");
            return new WorkbenchSettingsDto { Versions = (await versions.ListAsync(kind, cancellation)).ToList() };
        }

        /// <summary>The Active version, or null before the first approval.</summary>
        public Task<StoredWorkbenchConfig> ActiveAsync(CancellationToken cancellation)
        {
            return versions.GetActiveAsync(kind, cancellation);
        }

        /// <summary>Checks that the person may upload, and the note.</summary>
        public string BeginUpload(string note)
        {
            if (!Can(Permissions.ReferenceManage))
                throw Forbidden("Only a Maker of reference data can upload a " + title + ".");
            note = (note ?? "").Trim();
            if (note.Length > 1000 || note.Any(ch => char.IsControl(ch) && ch != '\n' && ch != '\r'))
                throw Invalid("The note must be at most 1,000 characters.");
            return note;
        }

        /// <summary>
        /// Stores checked content as a Pending version. <paramref name="differences"/> compares the Active version's JSON
        /// with the new one (one line per change).
        /// </summary>
        public async Task<WorkbenchConfigVersionDto> RequestAsync(string sourceFiles, string note, WorkbenchConfigSummaryDto summary, string json,
            Func<string, List<string>> differences, CancellationToken cancellation)
        {
            var hash = Sha256(json);
            var active = await versions.GetActiveAsync(kind, cancellation);
            if (active != null)
            {
                if (active.Version.ContentHash == hash)
                    throw Invalid("Nothing changed: these files are the " + title + " in use.");
                summary.Changes = differences(active.Content);
            }

            var version = new WorkbenchConfigVersionDto
            {
                Id = Guid.NewGuid().ToString("N"),
                Kind = kind,
                SourceFiles = sourceFiles.Length <= 400 ? sourceFiles : sourceFiles.Substring(0, 400),
                Note = note.Length == 0 ? null : note,
                Summary = summary,
                ContentHash = hash,
                RequestedBy = user.Name,
                RequestedAt = DateTimeOffset.UtcNow
            };

            try
            {
                return await versions.RequestAsync(new StoredWorkbenchConfig { Version = version, Content = json }, cancellation);
            }
            catch (AccessRequestOpenException)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, "A " + title + " is already waiting for approval. Approve, reject or cancel it first.");
            }
        }

        /// <summary>approve / reject / cancel a Pending version. False when it does not exist (or is of another kind).</summary>
        public async Task<bool> DecideAsync(string configId, string decision, AccessDecisionRequest body, CancellationToken cancellation)
        {
            string status;
            switch (decision)
            {
                case "approve": status = "Approved"; break;
                case "reject": status = "Rejected"; break;
                case "cancel": status = "Cancelled"; break;
                default: throw Invalid("Unknown decision.");
            }

            if (!IsId(configId)) return false;
            body = body ?? new AccessDecisionRequest();
            var comment = body.Comment == null ? null : body.Comment.Trim();
            if (comment != null && (comment.Length > 1000 || comment.Any(ch => char.IsControl(ch) && ch != '\n' && ch != '\r')))
                throw Invalid("The comment must be at most 1,000 characters.");
            if (comment == "") comment = null;

            var version = (await versions.ListAsync(kind, cancellation)).FirstOrDefault(v => v.Id == configId);
            if (version == null) return false;
            var mine = string.Equals(version.RequestedBy, user.Name, StringComparison.OrdinalIgnoreCase);
            if (status == "Cancelled")
            {
                if (!mine || !Can(Permissions.ReferenceManage))
                    throw Forbidden("Only the person who uploaded a configuration can cancel it.");
            }
            else
            {
                if (!Can(Permissions.ReferenceApprove))
                    throw Forbidden("Only a Checker of reference data can approve or reject a " + title + ".");
                if (mine)
                    throw Forbidden("A Checker other than you must approve or reject the configuration you uploaded.");
                if (status == "Rejected" && comment == null)
                    throw Invalid("Say why the configuration is rejected.");
            }

            byte[] rowVersion;
            try { rowVersion = Convert.FromBase64String(body.Version ?? ""); }
            catch (FormatException) { throw Invalid("Reload the page and try again."); }
            if (rowVersion.Length != 8) throw Invalid("Reload the page and try again.");
            try
            {
                return await versions.DecideAsync(configId, rowVersion, status, user.Name, DateTimeOffset.UtcNow, comment, cancellation);
            }
            catch (ConcurrencyConflictException)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, "This configuration was decided or changed by someone else. Reload and try again.");
            }
            catch (AccessDecisionRefusedException ex)
            {
                throw Forbidden(ex.Message);
            }
        }

        /// <summary>
        /// A version to download. Makers and Checkers get any version; the people who use the tools
        /// (submission.prepare) only the one in use. Null when it does not exist or may not be seen.
        /// </summary>
        public async Task<StoredWorkbenchConfig> GetForDownloadAsync(string configId, CancellationToken cancellation)
        {
            if (!IsMakerOrChecker && !Can(Permissions.SubmissionPrepare))
                throw Forbidden("Your role cannot see the " + title + ".");
            if (!IsId(configId)) return null;
            var stored = await versions.GetAsync(configId, cancellation);
            if (stored == null || stored.Version.Kind != kind) return null;
            if (!IsMakerOrChecker && stored.Version.Status != WorkbenchConfigStatus.Active) return null;
            return stored;
        }

        public static string Sha256(string text)
        {
            using (var sha = SHA256.Create())
            {
                return string.Concat(sha.ComputeHash(Encoding.UTF8.GetBytes(text)).Select(b => b.ToString("x2")));
            }
        }

        public static string Sha256(byte[] content)
        {
            using (var sha = SHA256.Create())
            {
                return string.Concat(sha.ComputeHash(content).Select(b => b.ToString("x2")));
            }
        }

        private static bool IsId(string configId) => Regex.IsMatch(configId ?? "", @"\A[0-9a-f]{32}\z");
    }
}
