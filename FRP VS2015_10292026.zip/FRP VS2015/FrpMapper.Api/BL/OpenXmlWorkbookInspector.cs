﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    public sealed partial class OpenXmlWorkbookInspector
    {
        private static readonly XNamespace Main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private static readonly XNamespace Relationships = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        private static readonly XNamespace PackageRelationships = "http://schemas.openxmlformats.org/package/2006/relationships";

        public WorkbookSummaryDto Inspect(string workbookPath)
        {
            using (var archive = ZipFile.OpenRead(workbookPath))
            {
            var sharedStrings = ReadSharedStrings(archive);
            var workbook = ReadXml(archive, "xl/workbook.xml");
            var workbookRels = ReadXml(archive, "xl/_rels/workbook.xml.rels");
            var rels = workbookRels.Root?.Elements(PackageRelationships + "Relationship")
                .ToDictionary(e => (string)e.Attribute("Id"), e => (string)e.Attribute("Target")) ?? new Dictionary<string, string>();

            var sheets = new List<WorkbookSheetDto>();
            foreach (var sheet in workbook.Descendants(Main + "sheet"))
            {
                var name = (string)sheet.Attribute("name") ?? "Sheet";
                var relationshipId = (string)sheet.Attribute(Relationships + "id") ?? "";
                string target;
                if (!rels.TryGetValue(relationshipId, out target))
                {
                    continue;
                }

                var worksheetPath = NormalizePartPath("xl", target);
                var read = ReadCells(archive, worksheetPath, sharedStrings);
                var cells = read.Cells;
                var storedCellCount = read.StoredCellCount;
                sheets.Add(new WorkbookSheetDto
                {
                    Name = name,
                    RelationshipId = relationshipId,
                    WorksheetPath = worksheetPath,
                    TotalStoredCellCount = storedCellCount,
                    Cells = cells
                });
            }

            var existingMappings = ReadExistingMappings(archive, sheets);
            return new WorkbookSummaryDto
            {
                FileName = Path.GetFileName(workbookPath),
                Sheets = sheets,
                ExistingMappings = existingMappings,
                ExistingMappingCount = existingMappings.Count
            };
            }
        }

        private static IReadOnlyList<string> ReadSharedStrings(ZipArchive archive)
        {
            var entry = archive.GetEntry("xl/sharedStrings.xml");
            if (entry == null)
            {
                return new List<string>();
            }

            using (var stream = entry.Open())
            {
            var document = SafeXml.Load(stream);
            return document.Descendants(Main + "si")
                .Select(si => string.Concat(si.Descendants(Main + "t").Select(t => t.Value)))
                .ToList();
            }
        }

        /// <summary>Returns the cells that hold text (used for layout matching) and the total number of stored cells.</summary>
        private static VT_Cells_StoredCellCount<IReadOnlyList<WorkbookCellDto>, int> ReadCells(ZipArchive archive, string worksheetPath, IReadOnlyList<string> sharedStrings)
        {
            var entry = archive.GetEntry(worksheetPath);
            if (entry == null)
            {
                return new VT_Cells_StoredCellCount<IReadOnlyList<WorkbookCellDto>, int>(new List<WorkbookCellDto>(), 0);
            }

            using (var stream = entry.Open())
            {
            var document = SafeXml.Load(stream);
            var stored = document.Descendants(Main + "c").ToList();
            var cells = stored
                .Select(c =>
                {
                    var type = (string)c.Attribute("t");
                    var rawValue = c.Element(Main + "v")?.Value ?? "";
                    int sharedIndex;
                    var value = type == "s" && int.TryParse(rawValue, out sharedIndex) && sharedIndex >= 0 && sharedIndex < sharedStrings.Count ? sharedStrings[sharedIndex] : type == "inlineStr" ? string.Concat(c.Element(Main + "is")?.Descendants(Main + "t").Select(t => t.Value) ?? new List<string>()) : type == "b" ? (rawValue == "1" ? "TRUE" : "FALSE") : rawValue;
                    return new WorkbookCellDto
                    {
                        Address = (string)c.Attribute("r") ?? "",
                        DisplayValue = value,
                        Style = (string)c.Attribute("s")
                    };
                })
                .Where(c => !string.IsNullOrWhiteSpace(c.Address) && !string.IsNullOrWhiteSpace(c.DisplayValue))
                .ToList();
            return new VT_Cells_StoredCellCount<IReadOnlyList<WorkbookCellDto>, int>(cells, stored.Count);
            }
        }

        private static IReadOnlyList<ExistingXmlMappingDto> ReadExistingMappings(ZipArchive archive, IReadOnlyList<WorkbookSheetDto> sheets)
        {
            var result = new List<ExistingXmlMappingDto>();
            foreach (var sheet in sheets)
            {
                var relPath = GetWorksheetRelationshipPath(sheet.WorksheetPath);
                var relEntry = archive.GetEntry(relPath);
                if (relEntry == null)
                {
                    continue;
                }

                using (var relStream = relEntry.Open())
                {
                var relDocument = SafeXml.Load(relStream);
                var worksheetDirectory = Path.GetDirectoryName(sheet.WorksheetPath)?.Replace('\\', '/') ?? "xl/worksheets";
                var relationships = relDocument.Root?.Elements(PackageRelationships + "Relationship").ToList() ?? new List<XElement>();
                var tableTargets = relationships
                    .Where(e => ((string)e.Attribute("Type"))?.EndsWith("/tableSingleCells", StringComparison.OrdinalIgnoreCase) == true)
                    .Select(e => NormalizePartPath(worksheetDirectory, (string)e.Attribute("Target")))
                    .ToList();

                // Excel XML-mapped list tables: each mapped column binds a repeating element.
                // The first data row under the header is the input cell for that element.
                var listTableTargets = relationships
                    .Where(e => ((string)e.Attribute("Type"))?.EndsWith("/table", StringComparison.OrdinalIgnoreCase) == true)
                    .Select(e => NormalizePartPath(worksheetDirectory, (string)e.Attribute("Target")))
                    .ToList();
                foreach (var listTableTarget in listTableTargets)
                {
                    var listEntry = archive.GetEntry(listTableTarget);
                    if (listEntry == null)
                    {
                        continue;
                    }

                    using (var listStream = listEntry.Open())
                    {
                    var listDocument = SafeXml.Load(listStream);
                    var table = listDocument.Root;
                    var reference = (string)table?.Attribute("ref");
                    if (table == null || string.IsNullOrWhiteSpace(reference))
                    {
                        continue;
                    }

                    var start = reference.Split(':')[0];
                    var startColumn = ColumnIndex(start);
                    var headerRow = RowNumber(start);
                    var headerRowCount = (int?)table.Attribute("headerRowCount") ?? 1;
                    var dataRow = headerRow + Math.Max(headerRowCount, 0);
                    var columnOffset = 0;
                    foreach (var column in table.Descendants(Main + "tableColumn"))
                    {
                        var xmlColumn = column.Element(Main + "xmlColumnPr");
                        var xpath = (string)xmlColumn?.Attribute("xpath");
                        if (!string.IsNullOrWhiteSpace(xpath))
                        {
                            result.Add(new ExistingXmlMappingDto
                            {
                                SheetName = sheet.Name,
                                CellAddress = $"{ColumnName(startColumn + columnOffset)}{dataRow}",
                                XPath = xpath,
                                DataType = (string)xmlColumn.Attribute("xmlDataType") ?? "string",
                                ElementName = LastPathToken(xpath),
                                IsListColumn = true
                            });
                        }

                        columnOffset++;
                    }
                    }
                }

                foreach (var tableTarget in tableTargets)
                {
                    var tableEntry = archive.GetEntry(tableTarget);
                    if (tableEntry == null)
                    {
                        continue;
                    }

                    using (var tableStream = tableEntry.Open())
                    {
                    var tableDocument = SafeXml.Load(tableStream);
                    foreach (var singleCell in tableDocument.Descendants(Main + "singleXmlCell"))
                    {
                        var xmlPr = singleCell.Descendants(Main + "xmlPr").FirstOrDefault();
                        var cellAddress = (string)singleCell.Attribute("r") ?? "";
                        var xpath = (string)xmlPr?.Attribute("xpath") ?? "";
                        result.Add(new ExistingXmlMappingDto
                        {
                            SheetName = sheet.Name,
                            CellAddress = cellAddress,
                            XPath = xpath,
                            DataType = (string)xmlPr?.Attribute("xmlDataType") ?? "string",
                            ElementName = LastPathToken(xpath)
                        });
                    }
                    }
                }
                }
            }

            return result;
        }

        internal static int ColumnIndex(string address)
        {
            var index = 0;
            foreach (var ch in address.TakeWhile(char.IsLetter))
            {
                index = (index * 26) + char.ToUpperInvariant(ch) - 'A' + 1;
            }

            return index;
        }

        internal static int RowNumber(string address)
        {
            int row;
            return int.TryParse(string.Concat(address.SkipWhile(char.IsLetter)), out row) ? row : 0;
        }

        internal static string ColumnName(int index)
        {
            var name = "";
            while (index > 0)
            {
                var remainder = (index - 1) % 26;
                name = (char)('A' + remainder) + name;
                index = (index - 1) / 26;
            }

            return name;
        }

        private static XDocument ReadXml(ZipArchive archive, string path)
        {
            var entry = archive.GetEntry(path) ?? CompatThrow.As<ZipArchiveEntry>(new InvalidOperationException($"Workbook part '{path}' was not found."));
            using (var stream = entry.Open())
            {
            return SafeXml.Load(stream);
            }
        }

        private static string GetWorksheetRelationshipPath(string worksheetPath)
        {
            var directory = Path.GetDirectoryName(worksheetPath)?.Replace('\\', '/') ?? "xl/worksheets";
            var fileName = Path.GetFileName(worksheetPath);
            return $"{directory}/_rels/{fileName}.rels";
        }

        internal static string NormalizePartPath(string basePath, string target)
        {
            var combined = target.StartsWith("/", StringComparison.Ordinal)
                ? target.TrimStart('/')
                : $"{basePath.TrimEnd('/')}/{target}";
            var parts = new Stack<string>();
            foreach (var part in combined.Split('/', StringSplitOptions.RemoveEmptyEntries))
            {
                if (part == ".")
                {
                    continue;
                }

                if (part == "..")
                {
                    if (parts.Count > 0)
                    {
                        parts.Pop();
                    }
                    continue;
                }

                parts.Push(part);
            }

            return string.Join("/", parts.Reverse());
        }

        private static string LastPathToken(string xpath)
        {
            if (string.IsNullOrWhiteSpace(xpath))
            {
                return null;
            }

            var last = xpath.Split('/', StringSplitOptions.RemoveEmptyEntries).LastOrDefault();
            return (last == null) ? null : PrefixRegex().Replace(last, "");
        }

        private static System.Text.RegularExpressions.Regex PrefixRegex() { return PrefixRegexInstance; }

        private static readonly System.Text.RegularExpressions.Regex PrefixRegexInstance = new System.Text.RegularExpressions.Regex("^[^:]+:", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

}
