﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    public sealed class SandboxResultReader
    {
        private const string RefPattern = @"(?:\[[A-Za-z0-9_]+(?::\d+)?\]\s*)+";
        public SandboxImportDto Read(byte[] bytes, string filename, byte[] submittedXml, BankProfileDto bank, FrpProjectDto project, BspSpecification specification)
        {
            // The text of BSP's "Sandbox processing result" (the text export of its PDF); PDF files are not read.
            var text = System.Text.Encoding.UTF8.GetString(bytes);
            if (text.Length > 8000000) throw Invalid("The report text is too large.");
            text = Regex.Replace(text, @"(?m)^\s*\d+\s*/\s*\d+\s*$|SANDBOX SUBMISSION", " ");
            text = Regex.Replace(text, @"\s+", " ");
            var metadata = Regex.Match(text, @"period\s+(?<period>\d{4}-\d{2})\s+and\s+undertaking\s+(?<bank>.+?)\s+submitted at", RegexOptions.IgnoreCase);
            if (!metadata.Success) throw Invalid("The BSP report header could not be read. Upload the text export (.txt) of BSP's sandbox processing result.");
            var provider = Regex.Match(filename, @"SandboxProcessingResult-(\d+)-", RegexOptions.IgnoreCase);
            if (provider.Success && BankReferenceContext.Code(provider.Groups[1].Value) != BankReferenceContext.Code(bank.ProviderCode))
                throw Invalid("The BSP report provider does not match the selected bank.");
            if (!string.Equals(metadata.Groups["bank"].Value.Trim(), bank.Name.Trim(), StringComparison.OrdinalIgnoreCase))
                throw Invalid("The report's undertaking name does not match the bank profile. Save the BSP bank name first.");
            using (var input = new MemoryStream(submittedXml))
            {
            using (var reader = XmlReader.Create(input, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 40000000 }))
            {
            var document = XDocument.Load(reader);
            var root = document.Root ?? CompatThrow.As<XElement>(Invalid("The submitted XML has no root."));
            if (root.Name.LocalName != project.RootElement || root.Name.NamespaceName != project.TargetNamespace)
                throw Invalid("The submitted XML does not match the project's report and XSD version.");
            var isConsolidated = text.Substring(0, metadata.Index).Contains("Consolidated", StringComparison.OrdinalIgnoreCase);
            if (isConsolidated != root.Name.LocalName.Contains("CONSO", StringComparison.OrdinalIgnoreCase)) throw Invalid("The BSP report and the XML are for different reports.");
            if (metadata.Groups["period"].Value != $"{BankReferenceContext.Header(root, "Year")}-{BankReferenceContext.Header(root, "Period").PadLeft(2, '0')}")
                throw Invalid("The BSP report and the XML are for different periods.");
            var xmlProvider = BankReferenceContext.Header(root, "Undertaking");
            if (BankReferenceContext.Code(xmlProvider) != BankReferenceContext.Code(bank.ProviderCode) && !(xmlProvider == "Sample" && provider.Success))
                throw Invalid("The submitted XML provider does not match this bank.");
            var findings = Regex.Matches(text, @"(?<!\S)(?:ASSERTION-[A-Za-z0-9_-]+|COND-\d+|DYN-\d+)\s");
            var exclusions = new List<FieldExclusionDto>();
            var history = new List<HistoricalValueDto>();
            var warnings = new List<string>();
            var dynamicFields = new SortedSet<string>(StringComparer.Ordinal);
            var rules = specification.Assertions.GroupBy(a => a.Code.Replace("ASSERTION-", "")).ToDictionary(g => g.Key, g => g.First());
            foreach (var finding2 in findings.Cast<System.Text.RegularExpressions.Match>().Select((f, i) => new VT_f_i<Match, int>(f, i)))
            {
                var finding = finding2.f;
                var index = finding2.i;
                var block = text.Substring(finding.Index, (index + 1 < findings.Count ? findings[index + 1].Index : text.Length) - finding.Index);
                var code = finding.Value.Trim();
                var exclusion = Regex.Match(block, @"Conditional field\s+(?<ref>" + RefPattern + @")should not be reported", RegexOptions.IgnoreCase);
                if (exclusion.Success)
                {
                    var reference = Regex.Replace(exclusion.Groups["ref"].Value, @"\s+", "");
                    var selector = Selector(root, reference);
                    if (selector == null) warnings.Add($"Could not identify the exact row for {reference}; exclusion was not learned.");
                    else exclusions.Add(new FieldExclusionDto(reference, selector, Excerpt(block)));
                    continue;
                }
                var dynamic = Regex.Match(block, @"Invalid value for dynamic ENUM field\s*\(\s*(?<ref>" + RefPattern + @")", RegexOptions.IgnoreCase);
                if (dynamic.Success)
                {
                    dynamicFields.Add(Regex.Replace(Regex.Replace(dynamic.Groups["ref"].Value, @"\s+", ""), @":\d+", ""));
                    continue;
                }
                BspAssertion rule;
                if (!rules.TryGetValue(code.Replace("ASSERTION-", ""), out rule)) continue;
                var result = Regex.Match(block, @"Result:\s*(?<left>-?[\d,]+(?:\.\d+)?)\s*(?:=|>=|<=|<>|!=|>|<)\s*(?<right>-?[\d,]+(?:\.\d+)?)");
                if (!result.Success || !string.IsNullOrEmpty(rule.Loop)) continue;
                foreach (var entry in new[] { new VT_Item1_Item2<string, string>(rule.Left, "left"), new VT_Item1_Item2<string, string>(rule.Right, "right") })
                {
                    var formula = entry.Item1;
                    var side = entry.Item2;
                    // Store only an entirely historical expression. A mixed live/historical total is not a prior value.
                    var withoutDwhs = Regex.Replace(formula, @"DWHS\(\s*""[^""]+""\s*;\s*(?:\[[A-Za-z0-9_]+\])+\s*\)", "0", RegexOptions.IgnoreCase);
                    if (withoutDwhs == formula || withoutDwhs.Contains('[') || withoutDwhs.Contains("DWHS", StringComparison.OrdinalIgnoreCase)) continue;
                    decimal value;
                    if (decimal.TryParse(result.Groups[side].Value, NumberStyles.Number, CultureInfo.InvariantCulture, out value))
                        history.Add(new HistoricalValueDto(rule.Code, formula, value, Excerpt(block)));
                }
            }
            var conflicts = history.GroupBy(h => BankReferenceContext.FormulaKey(h.Formula)).Where(g => g.Select(h => h.Value).Distinct().Count() > 1).Select(g => g.Key).ToHashSet();
            if (conflicts.Count > 0) warnings.Add($"{conflicts.Count} conflicting historical expressions were not learned.");
            history = history.Where(h => !conflicts.Contains(BankReferenceContext.FormulaKey(h.Formula))).DistinctBy(h => BankReferenceContext.FormulaKey(h.Formula)).ToList();
            // BSP checks these against its own lists. Branch codes (BRIS C0030) come from the bank's branch register;
            // for the others BSP does not publish the list, so the value has to be entered by hand.
            var otherDynamic = dynamicFields.Where(f => !Regex.IsMatch(f, @"^\[BRIS_[A-Za-z0-9_]+\].*\[C0030\]$")).ToList();
            if (dynamicFields.Count > otherDynamic.Count)
                warnings.Add("BSP rejected branch codes: complete the branch register (and mark it complete) so the sample uses the bank's branch codes.");
            if (otherDynamic.Count > 0)
                warnings.Add($"BSP expects a value from its own list in {string.Join(", ", otherDynamic)}; BSP does not publish these lists, so enter a valid value there by hand.");
            warnings.Add("Unmatched findings remain validation failures; importing this report does not mean BSP acceptance.");
            return new SandboxImportDto() { BankKey = bank.Key, ProviderCode = bank.ProviderCode, ProjectId = project.Id, Report = root.Name.LocalName,
                Namespace = root.Name.NamespaceName, Period = metadata.Groups["period"].Value,
                SpecificationHash = project.SpecificationFile?.Sha256 ?? "", FileName = Path.GetFileName(filename), Sha256 = CompatHex.ToHexString(CompatHash.Sha256(bytes)),
                FindingCount = findings.Count, Exclusions = exclusions.DistinctBy(e => e.Selector).ToList(), HistoricalValues = history, Warnings = warnings };
            }
            }
        }
        // Uses local-name XPath with explicit numeric row positions. Scope is the exact source period/report;
        // repeating rows are bound to their stable Bookcode/CURRENCY/branch code instead of an ordinal.
        internal static string Selector(XElement root, string reference)
        {
            XElement current = root;
            var path = "/*";
            foreach (Match part in Regex.Matches(reference, @"\[(?<name>[A-Za-z0-9_]+)(?::(?<row>\d+))?\]"))
            {
                var name = part.Groups["name"].Value;
                var children = current.Elements().Where(e => e.Name.LocalName == name).ToList();
                if (children.Count != 1) return null;
                current = children[0]; path += $"/*[local-name()='{name}']";
                if (part.Groups["row"].Success)
                {
                    var rows = current.Elements().Where(e => e.Name.LocalName.EndsWith("_Item", StringComparison.Ordinal)).ToList();
                    var row = int.Parse(part.Groups["row"].Value, CultureInfo.InvariantCulture);
                    if (row < 1 || row > rows.Count) return null;
                    current = rows[row - 1];
                    var key = current.Elements().FirstOrDefault(e => (e.Name.LocalName == "Bookcode" || e.Name.LocalName == "CURRENCY" || e.Name.LocalName == "C0030") && !e.HasElements);
                    if (key == null || !Regex.IsMatch(key.Value, @"^[A-Za-z0-9_.-]+$")) return null;
                    if (rows.Count(r => r.Elements().Any(e => e.Name == key.Name && e.Value == key.Value)) != 1) return null;
                    path += $"/*[local-name()='{current.Name.LocalName}'][*[local-name()='{key.Name.LocalName}']='{key.Value}']";
                }
            }
            return path;
        }
        /// <summary>The start of the finding as evidence; the whole report is not kept.</summary>
        private static string Excerpt(string block) => block.Length <= 400 ? block.Trim() : block.Substring(0, 400).Trim() + "…";

        private static WorkflowException Invalid(string message) => new WorkflowException(WorkflowErrorKind.Invalid, message);
    }

}
