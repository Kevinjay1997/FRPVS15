﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// The sheet view of the Mappings tab. Projects are read through <see cref="IFrpMappingService.GetAsync"/>, so the
    /// same visibility rules (<see cref="ProjectAccess"/>) and the same read cache apply: a project the person may not
    /// see reads as not found. Nothing here changes a project; mappings changed on the sheet are saved with the
    /// existing PUT projects/{id}/mappings (Maker, editable project).
    /// </summary>
    public sealed class TemplateGridService : ITemplateGridService
    {
        /// <summary>Excel's limit for a sheet name.</summary>
        public const int MaxSheetNameLength = 31;

        private static readonly TimeSpan CacheFor = TimeSpan.FromMinutes(30);

        private readonly IFrpMappingService projects;
        private readonly TemplateGridReader gridReader;
        private readonly OpenXmlWorkbookInspector workbookInspector;
        private readonly MappingSuggestionEngine suggestionEngine;
        private readonly XsdInputTemplateGenerator templateGenerator;
        private readonly BspSpecificationReader specificationReader;
        private readonly ICurrentUser currentUser;
        private readonly IMemoryCache cache;
        private readonly OpenXmlMappedTemplateWriter templateWriter;

        public TemplateGridService(IFrpMappingService projects, TemplateGridReader gridReader, OpenXmlWorkbookInspector workbookInspector,
            MappingSuggestionEngine suggestionEngine, XsdInputTemplateGenerator templateGenerator, BspSpecificationReader specificationReader,
            ICurrentUser currentUser, IMemoryCache cache, OpenXmlMappedTemplateWriter templateWriter)
        {
            this.templateWriter = templateWriter;
            this.projects = projects;
            this.gridReader = gridReader;
            this.workbookInspector = workbookInspector;
            this.suggestionEngine = suggestionEngine;
            this.templateGenerator = templateGenerator;
            this.specificationReader = specificationReader;
            this.currentUser = currentUser;
            this.cache = cache;
        }

        public async Task<TemplateGridDto> GetSheetAsync(string projectId, string sheetName, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectRead, "read projects");
            if (string.IsNullOrWhiteSpace(sheetName) || sheetName.Length > MaxSheetNameLength || sheetName.Any(char.IsControl))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"Give the name of a sheet of the template (at most {MaxSheetNameLength} characters).");
            }

            var project = await projects.GetAsync(projectId, cancellationToken);
            if (project?.TemplateFile == null || string.IsNullOrEmpty(project.TemplateFile.StoredPath))
            {
                return null;
            }

            var grid = gridReader.Read(project.TemplateFile.StoredPath, sheetName);
            return grid == null ? null : AsDownloaded(project, grid);
        }

        /// <summary>
        /// The sheet as the downloaded input template lays it out. A list whose form the template turns into a table with
        /// one row per item (item rows, e.g. CAR_Part_IV_1d per currency) is shown that way, with a link from each of the
        /// table's cells to the form's cell the field is mapped to. Other sheets are the uploaded template's own.
        /// The sheet's template is made from its own mappings and kept until they, or the files, change.
        /// </summary>
        private TemplateGridDto AsDownloaded(FrpProjectDto project, TemplateGridDto grid)
        {
            var sheetMappings = project.Mappings
                .Where(m => string.Equals(m.SheetName, grid.SheetName, StringComparison.OrdinalIgnoreCase) && !string.IsNullOrWhiteSpace(m.CellAddress))
                .ToList();
            var inLists = new HashSet<string>(project.SchemaNodes.Where(n => n.IsInRepeatingGroup).Select(n => n.Path), StringComparer.Ordinal);
            if (project.TemplateGenerated || !sheetMappings.Any(m => inLists.Contains(m.SchemaPath)))
            {
                return grid; // no list on the sheet, or the app's own template (its lists are tables already)
            }

            var key = "template-grid-downloaded|" + project.Id + "|" + FileKey(project.TemplateFile) + "|" + FileKey(project.XsdFile) + "|" + grid.SheetName.ToUpperInvariant()
                + "|" + string.Join(";", sheetMappings.OrderBy(m => m.SchemaPath, StringComparer.Ordinal).Select(m => m.SchemaPath + "=" + m.CellAddress.ToUpperInvariant()))
                + "|" + string.Join(";", project.SheetSplits.Select(sp => sp.GroupPath + ":" + string.Join(",", sp.Values)));
            TemplateGridDto shown;
            if (cache.TryGetValue(key, out shown))
            {
                return shown;
            }

            shown = grid;
            try
            {
                var placements = new List<ItemRowsPlacement>();
                var sheetProject = project.With(p => { p.Mappings = sheetMappings; });
                var workbook = templateWriter.Write(sheetProject, writeValues: false, placements: placements);
                var onSheet = placements.Where(p => string.Equals(p.SheetName, grid.SheetName, StringComparison.OrdinalIgnoreCase)).ToList();
                var downloaded = onSheet.Count == 0 ? null : gridReader.Read(workbook, key, grid.SheetName);
                if (downloaded != null)
                {
                    shown = downloaded.With(g =>
                    {
                        g.Links = onSheet.SelectMany(p => p.Cells)
                            .Select(c => new TemplateGridLinkDto { TemplateCell = c.TemplateCell, FormCell = c.FormCell, SchemaPath = c.SchemaPath })
                            .ToList();
                        g.ItemTables = onSheet.Select(p => new TemplateGridItemTableDto { ItemPath = p.ItemPath, Range = p.Range, DataRow = p.DataRow }).ToList();
                    });
                }
            }
            catch (Exception ex) when (ex is InvalidOperationException || ex is InvalidDataException || ex is System.Xml.XmlException || ex is IOException)
            {
                // The template could not be made (an unreadable file): the sheet is shown as uploaded.
            }

            cache.Set(key, shown, new MemoryCacheEntryOptions { SlidingExpiration = CacheFor });
            return shown;
        }

        public async Task<SuggestedMappingsDto> GetSuggestedMappingsAsync(string projectId, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectRead, "read projects");
            var project = await projects.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            // The app's mappings depend only on the XSD fields and the template, so they are worked out once per template file.
            var key = "suggested-mappings|" + project.Id + "|" + FileKey(project.TemplateFile) + "|" + FileKey(project.SpecificationFile)
                + "|" + project.TemplateGenerated + "|" + project.SchemaNodes.Count.ToString(CultureInfo.InvariantCulture);
            SuggestedMappingsDto suggested;
            if (cache.TryGetValue(key, out suggested))
            {
                return suggested;
            }

            suggested = new SuggestedMappingsDto { Mappings = Suggest(project) };
            cache.Set(key, suggested, new MemoryCacheEntryOptions { SlidingExpiration = CacheFor });
            return suggested;
        }

        /// <summary>What <see cref="FrpMappingService"/> maps when a project is created (AnalyzeAsync), from the stored files.</summary>
        private IReadOnlyList<MappingEntryDto> Suggest(FrpProjectDto project)
        {
            if (project.TemplateGenerated)
            {
                BspSpecification specification = null;
                if (project.SpecificationFile != null && File.Exists(project.SpecificationFile.StoredPath))
                {
                    try
                    {
                        specification = specificationReader.Read(project.SpecificationFile.StoredPath);
                    }
                    catch (Exception ex) when (ex is InvalidOperationException || ex is InvalidDataException || ex is System.Xml.XmlException || ex is IOException)
                    {
                        // As when the project was created: labels are optional, validation reports an unreadable specification.
                    }
                }

                var draft = new FrpProjectDto { RootElement = project.RootElement, TargetNamespace = project.TargetNamespace, SchemaNodes = project.SchemaNodes };
                return templateGenerator.Generate(draft, specification).Mappings;
            }

            var workbook = project.TemplateFile != null && File.Exists(project.TemplateFile.StoredPath)
                ? workbookInspector.Inspect(project.TemplateFile.StoredPath)
                : null;
            return suggestionEngine.CreateInitialMappings(project.SchemaNodes, workbook).Mappings;
        }

        private static string FileKey(UploadedFileDto file)
        {
            if (file == null || string.IsNullOrEmpty(file.StoredPath))
            {
                return "-";
            }

            var info = new FileInfo(file.StoredPath);
            return info.Exists
                ? info.FullName + ":" + info.Length.ToString(CultureInfo.InvariantCulture) + ":" + info.LastWriteTimeUtc.Ticks.ToString(CultureInfo.InvariantCulture)
                : file.StoredPath;
        }
    }
}
