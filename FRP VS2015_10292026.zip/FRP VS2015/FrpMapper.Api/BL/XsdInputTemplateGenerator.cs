﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Security;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Builds an Excel input template from the XSD alone (no BSP template needed), laid out like BSP's templates:
    /// - one worksheet per XSD sheet element, in XSD order, starting with Header;
    /// - grids for RxxxxCyyyy fields: column codes across, row codes down, an input cell where the XSD has a field
    ///   and a grey cell where it has none;
    /// - list tables for repeating items (header row of element codes, one input row), which the exporter turns
    ///   into Excel XML list tables;
    /// - label/value rows for single fields (Currency, ClosingRate, MarketRiskApproach, Header fields).
    /// With a BSP specification, form titles, table titles, field titles, row descriptions, account codes and column
    /// headings come from it. The template has no XML map yet; the mapped-template export adds it.
    /// </summary>
    public sealed partial class XsdInputTemplateGenerator
    {
        public const string Source = "Generated input template";

        // Style indexes (see StylesXml)
        private const int StyleTitle = 1;
        private const int StyleHeader = 2;
        private const int StyleCode = 3;
        private const int StyleInput = 4;
        private const int StyleLabel = 5;
        private const int StyleSection = 6;
        private const int StyleDisabled = 7;
        private const int StyleNote = 8;

        public GeneratedInputTemplate Generate(FrpProjectDto project, BspSpecification specification)
        {
            var labels = specification?.Labels ?? new BspSpecLabels();
            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var leaves = project.SchemaNodes.Where(n => n.DataType != "complex").ToList();
            var root = project.RootElement ?? "Root";

            var sheetKeys = leaves
                .Select(l => l.Path.Split('/', StringSplitOptions.RemoveEmptyEntries))
                .Where(t => t.Length >= 3)
                .Select(t => t[1])
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            var sheets = new List<SheetBuilder>();
            var mappings = new List<MappingEntryDto>();
            var usedSheetNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var sheetKey in sheetKeys)
            {
                var sheetPath = $"/{root}/{sheetKey}";
                var sheetLeaves = leaves.Where(l => l.Path.StartsWith(sheetPath + "/", StringComparison.OrdinalIgnoreCase)).ToList();
                var sheet = new SheetBuilder(UniqueSheetName(sheetKey, usedSheetNames));
                sheets.Add(sheet);

                sheet.Set(1, 1, sheetKey, StyleSection);
                sheet.Set(2, 1, labels.FormTitles.GetValueOrDefault(sheetKey) ?? Humanize(sheetKey), StyleTitle);
                var row = 4;

                foreach (var block in Blocks(sheetLeaves, nodesByPath))
                {
                    row = (block.Kind == BlockKind.Fields ? WriteFields(sheet, row, sheetKey, sheetPath, block, labels, mappings) : block.Kind == BlockKind.Grid ? WriteGrid(sheet, row, sheetKey, sheetPath, block, labels, mappings) : WriteList(sheet, row, sheetKey, block, labels, mappings));
                    row += 1;
                }
            }

            var bytes = BuildWorkbook(sheets);
            return new GeneratedInputTemplate(bytes, mappings);
        }

        // ---------- blocks ----------

        private enum BlockKind { Fields, Grid, List }

        private sealed class Block : IRecord<Block>, IEquatable<Block>
    {
        public BlockKind Kind { get; set; }

        public string ContainerPath { get; set; }

        public List<SchemaNodeDto> Leaves { get; set; }

        public Block(BlockKind Kind, string ContainerPath, List<SchemaNodeDto> Leaves)
    {
    this.Kind = Kind;
    this.ContainerPath = ContainerPath;
    this.Leaves = Leaves;
    }

        public void Deconstruct(out BlockKind Kind, out string ContainerPath, out List<SchemaNodeDto> Leaves)
    {
    Kind = this.Kind;
    ContainerPath = this.ContainerPath;
    Leaves = this.Leaves;
    }

        public bool Equals(Block other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<BlockKind>.Default.Equals(Kind, other.Kind)
    && EqualityComparer<string>.Default.Equals(ContainerPath, other.ContainerPath)
    && EqualityComparer<List<SchemaNodeDto>>.Default.Equals(Leaves, other.Leaves);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as Block);
    }

        public static bool operator ==(Block left, Block right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(Block left, Block right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 75228;
    hash = hash * -1521134295 + EqualityComparer<BlockKind>.Default.GetHashCode(Kind);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ContainerPath);
    hash = hash * -1521134295 + EqualityComparer<List<SchemaNodeDto>>.Default.GetHashCode(Leaves);
    return hash;
    }
    }

        public override string ToString()
    {
    return "Block { " + "Kind = " + Kind + ", " + "ContainerPath = " + ContainerPath + ", " + "Leaves = " + Leaves + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public Block CloneRecord()
    {
    return (Block)MemberwiseClone();
    }

    }

        /// <summary>
        /// Groups a sheet's leaves in XSD order: repeating items become lists, RxxxxCyyyy fields under one parent
        /// become a grid, other fields under one parent become a label/value block.
        /// </summary>
        private static IEnumerable<Block> Blocks(IEnumerable<SchemaNodeDto> sheetLeaves, IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath)
        {
            var blocks = new List<Block>();
            var byKey = new Dictionary<string, Block>(StringComparer.OrdinalIgnoreCase);
            foreach (var leaf in sheetLeaves)
            {
                var repeating = OpenXmlMappedTemplateWriter.NearestRepeatingNode(leaf, nodesByPath);
                Block block;
                string key;
                if (repeating != null)
                {
                    key = "list|" + repeating.Path;
                    if (!byKey.TryGetValue(key, out block))
                    {
                        block = new Block(BlockKind.List, repeating.Path, new List<SchemaNodeDto>());
                    }
                }
                else if (GridCodeRegex().IsMatch(leaf.Name))
                {
                    key = "grid|" + leaf.ParentPath;
                    if (!byKey.TryGetValue(key, out block))
                    {
                        block = new Block(BlockKind.Grid, leaf.ParentPath ?? "", new List<SchemaNodeDto>());
                    }
                }
                else
                {
                    key = "fields|" + leaf.ParentPath;
                    if (!byKey.TryGetValue(key, out block))
                    {
                        block = new Block(BlockKind.Fields, leaf.ParentPath ?? "", new List<SchemaNodeDto>());
                    }
                }

                if (!byKey.ContainsKey(key))
                {
                    byKey[key] = block;
                    blocks.Add(block);
                }

                block.Leaves.Add(leaf);
            }

            return blocks;
        }

        /// <summary>Label/value rows: A = element name, B = title, C = input cell.</summary>
        private static int WriteFields(SheetBuilder sheet, int row, string sheetKey, string sheetPath, Block block, BspSpecLabels labels, List<MappingEntryDto> mappings)
        {
            var container = ContainerName(block.ContainerPath, sheetPath);
            if (container != null)
            {
                sheet.Set(row, 1, container, StyleSection);
                row++;
            }

            foreach (var leaf in block.Leaves)
            {
                var title = labels.FieldTitles.GetValueOrDefault($"{sheetKey}|{leaf.Name}")
                    ?? labels.RowLabels.GetValueOrDefault($"{sheetKey}|{container ?? ""}|{leaf.Name}")?.Description
                    ?? Humanize(leaf.Name);
                sheet.Set(row, 1, leaf.Name, StyleCode);
                sheet.Set(row, 2, string.IsNullOrWhiteSpace(title) ? leaf.Name : title, StyleLabel);
                sheet.Set(row, 3, null, StyleInput);
                sheet.AddValidation(leaf, $"C{row}");
                sheet.SetNote(row, 4, Hint(leaf));
                mappings.Add(Mapping(leaf, sheet.Name, $"C{row}"));
                row++;
            }

            return row;
        }

        /// <summary>
        /// Grid: B = row description, C = account code, D = row code; columns E.. carry the column codes.
        /// Input cells where the XSD has RxxxxCyyyy, grey cells elsewhere.
        /// </summary>
        private static int WriteGrid(SheetBuilder sheet, int row, string sheetKey, string sheetPath, Block block, BspSpecLabels labels, List<MappingEntryDto> mappings)
        {
            var container = ContainerName(block.ContainerPath, sheetPath);
            var table = container ?? "";
            if (container != null)
            {
                sheet.Set(row, 1, container, StyleSection);
                var title = labels.TableTitles.GetValueOrDefault($"{sheetKey}|{table}");
                if (!string.IsNullOrWhiteSpace(title) && title != "- none -")
                {
                    sheet.Set(row, 2, title, StyleTitle);
                }

                row++;
            }

            var cells = block.Leaves
                .Select(l => new VT_Leaf_Match<SchemaNodeDto, Match>(l, GridCodeRegex().Match(l.Name)))
                .Select(x => new VT_Leaf_Row_Column<SchemaNodeDto, string, string>(x.Leaf, x.Match.Groups[1].Value, x.Match.Groups[2].Value))
                .ToList();
            var rowCodes = cells.Select(c => c.Row).Distinct().OrderBy(CodeNumber).ToList();
            var columnCodes = cells.Select(c => c.Column).Distinct().OrderBy(CodeNumber).ToList();
            const int firstColumn = 5; // E

            var headerRow = row;
            var codeRow = row + 1;
            sheet.Set(headerRow, 2, "Item", StyleHeader);
            sheet.Set(headerRow, 3, "Account code", StyleHeader);
            sheet.Set(headerRow, 4, "", StyleHeader);
            sheet.Set(codeRow, 2, "", StyleCode);
            sheet.Set(codeRow, 3, "", StyleCode);
            sheet.Set(codeRow, 4, "", StyleCode);
            for (var i = 0; i < columnCodes.Count; i++)
            {
                var label = labels.ColumnLabels.GetValueOrDefault($"{sheetKey}|{table}|{columnCodes[i]}") ?? "";
                sheet.Set(headerRow, firstColumn + i, label, StyleHeader);
                sheet.Set(codeRow, firstColumn + i, columnCodes[i], StyleCode);
            }

            var byPosition = cells.ToDictionary(c => new VT_Row_Column<string, string>(c.Row, c.Column), c => c.Leaf);
            var current = codeRow + 1;
            foreach (var rowCode in rowCodes)
            {
                var rowLabel = labels.RowLabels.GetValueOrDefault($"{sheetKey}|{table}|{rowCode}");
                sheet.Set(current, 2, string.IsNullOrWhiteSpace(rowLabel?.Description) ? rowCode : rowLabel.Description, StyleLabel);
                sheet.Set(current, 3, rowLabel?.AccountCode ?? "", StyleCode);
                sheet.Set(current, 4, rowCode, StyleCode);
                for (var i = 0; i < columnCodes.Count; i++)
                {
                    SchemaNodeDto leaf;
                    if (byPosition.TryGetValue(new VT_Row_Column<string, string>(rowCode, columnCodes[i]), out leaf))
                    {
                        sheet.Set(current, firstColumn + i, null, StyleInput);
                        sheet.AddValidation(leaf, $"{ColumnName(firstColumn + i)}{current}");
                        mappings.Add(Mapping(leaf, sheet.Name, $"{ColumnName(firstColumn + i)}{current}"));
                    }
                    else
                    {
                        sheet.Set(current, firstColumn + i, null, StyleDisabled);
                    }
                }

                current++;
            }

            sheet.WidenColumns(firstColumn, firstColumn + columnCodes.Count - 1);
            return current;
        }

        /// <summary>
        /// List: a label row, a header row of element codes (the XML list table header) and one input row.
        /// Columns start at B.
        /// </summary>
        private static int WriteList(SheetBuilder sheet, int row, string sheetKey, Block block, BspSpecLabels labels, List<MappingEntryDto> mappings)
        {
            var itemTokens = block.ContainerPath.Split('/', StringSplitOptions.RemoveEmptyEntries);
            var anchor = itemTokens.Length >= 2 ? itemTokens[itemTokens.Length - 2] : itemTokens.LastOrDefault() ?? "List";
            if (itemTokens.Length >= 2 && string.Equals(itemTokens[itemTokens.Length - 2], sheetKey, StringComparison.OrdinalIgnoreCase))
            {
                anchor = itemTokens[itemTokens.Length - 1];
            }

            sheet.Set(row, 1, anchor, StyleSection);
            var title = labels.TableTitles.GetValueOrDefault($"{sheetKey}|{anchor}");
            sheet.Set(row, 2, !string.IsNullOrWhiteSpace(title) && title != "- none -" ? $"{title} (add rows as needed)" : "List: one row per item (add rows as needed)", StyleNote);
            row++;

            var names = OpenXmlMappedTemplateWriter.ListColumnNames(block.ContainerPath, block.Leaves);
            const int firstColumn = 2; // B
            var labelRow = row;
            var headerRow = row + 1;
            var dataRow = row + 2;
            for (var i = 0; i < block.Leaves.Count; i++)
            {
                var leaf = block.Leaves[i];
                var column = firstColumn + i;
                var tokens = leaf.Path.Split('/', StringSplitOptions.RemoveEmptyEntries);
                var table = tokens.Length >= 2 ? tokens[tokens.Length - 2] : "";
                var label = GridLabel(labels, sheetKey, table, leaf.Name)
                    ?? labels.ColumnLabels.GetValueOrDefault($"{sheetKey}|{anchor}|{leaf.Name}")
                    ?? labels.ColumnLabels.GetValueOrDefault($"{sheetKey}|{table}|{leaf.Name}")
                    ?? labels.FieldTitles.GetValueOrDefault($"{sheetKey}|{leaf.Name}")
                    ?? labels.RowLabels.GetValueOrDefault($"{sheetKey}|{anchor}|{RowPart(leaf.Name)}")?.Description
                    ?? "";
                sheet.Set(labelRow, column, label, StyleHeader);
                sheet.Set(headerRow, column, names[leaf.Path], StyleCode);
                sheet.Set(dataRow, column, null, StyleInput);
                sheet.AddValidation(leaf, $"{ColumnName(column)}{dataRow}");
                mappings.Add(Mapping(leaf, sheet.Name, $"{ColumnName(column)}{dataRow}"));
            }

            sheet.WidenColumns(firstColumn, firstColumn + block.Leaves.Count - 1);
            return dataRow + 1;
        }

        /// <summary>For a grid field inside a list item (RxxxxCyyyy): "row description / column heading".</summary>
        private static string GridLabel(BspSpecLabels labels, string sheetKey, string table, string name)
        {
            var match = GridCodeRegex().Match(name);
            if (!match.Success)
            {
                return null;
            }

            var row = labels.RowLabels.GetValueOrDefault($"{sheetKey}|{table}|{match.Groups[1].Value}")?.Description;
            var column = labels.ColumnLabels.GetValueOrDefault($"{sheetKey}|{table}|{match.Groups[2].Value}");
            var parts = new[] { row, column }.Where(p => !string.IsNullOrWhiteSpace(p)).ToList();
            return parts.Count == 0 ? null : string.Join(" / ", parts);
        }

        private static MappingEntryDto Mapping(SchemaNodeDto leaf, string sheetName, string address) => new MappingEntryDto() {
            SheetName = sheetName,
            CellAddress = address,
            SchemaPath = leaf.Path,
            DataType = leaf.DataType,
            Required = leaf.IsRequired,
            DefaultValue = leaf.TestValue,
            Source = Source
        };

        private static string ContainerName(string containerPath, string sheetPath)
        {
            if (string.Equals(containerPath, sheetPath, StringComparison.OrdinalIgnoreCase) || containerPath.Length <= sheetPath.Length)
            {
                return null;
            }

            return containerPath.Substring(sheetPath.Length + 1).Replace('/', ' ');
        }

        private static string Hint(SchemaNodeDto leaf)
        {
            var v = leaf.Validation;
            if (v.Enumerations.Count > 0)
            {
                return v.Enumerations.Count <= 8
                    ? "One of: " + string.Join(", ", v.Enumerations)
                    : $"One of {v.Enumerations.Count} codes, e.g. {string.Join(", ", v.Enumerations.Take(5))}";
            }

            int max;
            int d;
            return leaf.DataType == "date" ? "Date (yyyy-mm-dd)" : leaf.DataType == "dateTime" ? "Date and time (yyyy-mm-ddThh:mm:ss)" : leaf.DataType == "integer" ? ("Whole number" + Range(v)) : leaf.DataType == "decimal" ? ((CompatPattern.Is(v.FractionDigits, out d) ? $"Number, up to {d} decimals" : "Number") + Range(v)) : (CompatPattern.Is(v.MaxLength, out max) ? $"Text, up to {max} characters" : "");
        }

        private static string Range(SchemaValidationDto v) =>
            v.MinInclusive != null && v.MaxInclusive != null && v.MaxInclusive.Length <= 6 ? $" ({v.MinInclusive} to {v.MaxInclusive})" : "";

        private static string RowPart(string name)
        {
            var match = GridCodeRegex().Match(name);
            return match.Success ? match.Groups[1].Value : name;
        }

        private static int CodeNumber(string code)  {
        int number;
        return int.TryParse(code.Substring(1), NumberStyles.Integer, CultureInfo.InvariantCulture, out number) ? number : int.MaxValue;
    }

        private static string Humanize(string name)
        {
            var spaced = Regex.Replace(name.Replace('_', ' '), "(?<=[a-z])(?=[A-Z])", " ");
            return spaced.Trim();
        }

        private static string UniqueSheetName(string sheetKey, HashSet<string> used)
        {
            var name = MappingSuggestionEngine.SafeSheetName(sheetKey);
            var candidate = name;
            var suffix = 2;
            while (!used.Add(candidate))
            {
                var tail = $"~{suffix++}";
                candidate = (name.Length + tail.Length > 31 ? name.Substring(0, 31 - tail.Length) : name) + tail;
            }

            return candidate;
        }

        internal static string ColumnName(int index)
        {
            var name = "";
            while (index > 0)
            {
                var remainder = (index - 1) % 26;
                name = (char)('A' + remainder) + name;
                index = (index - 1) / 26;
            }

            return name;
        }

        private static System.Text.RegularExpressions.Regex GridCodeRegex() { return GridCodeRegexInstance; }

        // ---------- workbook ----------

        private sealed class SheetBuilder
        {

        public SheetBuilder(string name)
    {
        this.Name = name;
    }
            private readonly SortedDictionary<int, SortedDictionary<int, VT_Text_Style<string, int>>> _rows = new SortedDictionary<int, SortedDictionary<int, VT_Text_Style<string, int>>>();
            private readonly Dictionary<int, double> _widths = new Dictionary<int, double>() { [1] = 22, [2] = 46, [3] = 20, [4] = 10 };
            private readonly List<XElement> _validations = new List<XElement>();

            public string Name { get; } 
            public void Set(int row, int column, string text, int style)
            {
                SortedDictionary<int, VT_Text_Style<string, int>> cells;
                if (!_rows.TryGetValue(row, out cells))
                {
                    cells = new SortedDictionary<int, VT_Text_Style<string, int>>();
                    _rows[row] = cells;
                }

                cells[column] = new VT_Text_Style<string, int>(text, style);
            }

            public void SetNote(int row, int column, string text)
            {
                if (!string.IsNullOrWhiteSpace(text))
                {
                    Set(row, column, text, StyleNote);
                }
            }

            public void AddValidation(SchemaNodeDto node, string address)
            {
                var validation = XsdExcelValidationBuilder.Build(node, address);
                if (validation != null)
                {
                    _validations.Add(validation);
                }
            }

            public void WidenColumns(int first, int last)
            {
                for (var column = first; column <= last; column++)
                {
                    _widths[column] = Math.Max(_widths.GetValueOrDefault(column), 16);
                }
            }

            public string ToXml()
            {
                var xml = new StringBuilder();
                xml.Append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">");
                var lastRow = _rows.Count == 0 ? 1 : _rows.Keys.Max();
                var lastColumn = _rows.Count == 0 ? 1 : _rows.Values.SelectMany(r => r.Keys).DefaultIfEmpty(1).Max();
                xml.Append($"<dimension ref=\"A1:{ColumnName(Math.Max(1, lastColumn))}{lastRow}\"/>");
                xml.Append("<sheetViews><sheetView workbookViewId=\"0\"/></sheetViews>");
                xml.Append("<sheetFormatPr defaultRowHeight=\"15\"/>");
                xml.Append("<cols>");
                foreach (var width2 in _widths.OrderBy(w => w.Key))
                {
                    var column = width2.Key;
                    var width = width2.Value;
                    xml.Append(CultureInfo.InvariantCulture, $"<col min=\"{column}\" max=\"{column}\" width=\"{width}\" customWidth=\"1\"/>");
                }

                xml.Append("</cols><sheetData>");
                foreach (var row2 in _rows)
                {
                    var row = row2.Key;
                    var cells = row2.Value;
                    xml.Append(CultureInfo.InvariantCulture, $"<row r=\"{row}\">");
                    foreach (var cell2 in cells)
                    {
                        var column = cell2.Key;
                        var cell = cell2.Value;
                        var address = $"{ColumnName(column)}{row}";
                        if (string.IsNullOrEmpty(cell.Text))
                        {
                            xml.Append(CultureInfo.InvariantCulture, $"<c r=\"{address}\" s=\"{cell.Style}\"/>");
                        }
                        else
                        {
                            xml.Append(CultureInfo.InvariantCulture, $"<c r=\"{address}\" s=\"{cell.Style}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">{SecurityElement.Escape(cell.Text)}</t></is></c>");
                        }
                    }

                    xml.Append("</row>");
                }

                xml.Append("</sheetData>");
                if (_validations.Count > 0)
                {
                    xml.Append(CultureInfo.InvariantCulture, $"<dataValidations count=\"{_validations.Count}\">");
                    foreach (var validation in _validations)
                    {
                        xml.Append(validation.ToString(SaveOptions.DisableFormatting));
                    }

                    xml.Append("</dataValidations>");
                }

                xml.Append("<pageMargins left=\"0.5\" right=\"0.5\" top=\"0.75\" bottom=\"0.75\" header=\"0.3\" footer=\"0.3\"/>");
                xml.Append("</worksheet>");
                return xml.ToString();
            }
        }

        private static byte[] BuildWorkbook(IReadOnlyList<SheetBuilder> sheets)
        {
            using (var output = new MemoryStream())
            {
            using (var archive = new ZipArchive(output, ZipArchiveMode.Create, leaveOpen: true))
            {
                var contentTypes = new StringBuilder();
                contentTypes.Append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">");
                contentTypes.Append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>");
                contentTypes.Append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>");
                contentTypes.Append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>");
                contentTypes.Append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
                var workbook = new StringBuilder();
                workbook.Append("<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">");
                workbook.Append("<bookViews><workbookView activeTab=\"0\"/></bookViews><sheets>");
                var rels = new StringBuilder();
                rels.Append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
                for (var i = 0; i < sheets.Count; i++)
                {
                    var index = i + 1;
                    contentTypes.Append(CultureInfo.InvariantCulture, $"<Override PartName=\"/xl/worksheets/sheet{index}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
                    workbook.Append(CultureInfo.InvariantCulture, $"<sheet name=\"{SecurityElement.Escape(sheets[i].Name)}\" sheetId=\"{index}\" r:id=\"rId{index}\"/>");
                    rels.Append(CultureInfo.InvariantCulture, $"<Relationship Id=\"rId{index}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet{index}.xml\"/>");
                    Write(archive, $"xl/worksheets/sheet{index}.xml", sheets[i].ToXml());
                }

                rels.Append(CultureInfo.InvariantCulture, $"<Relationship Id=\"rId{sheets.Count + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>");
                rels.Append("</Relationships>");
                workbook.Append("</sheets><calcPr calcId=\"191029\"/></workbook>");
                contentTypes.Append("</Types>");

                Write(archive, "[Content_Types].xml", contentTypes.ToString());
                Write(archive, "_rels/.rels", "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
                Write(archive, "xl/workbook.xml", workbook.ToString());
                Write(archive, "xl/_rels/workbook.xml.rels", rels.ToString());
                Write(archive, "xl/styles.xml", StylesXml);
            }

            return output.ToArray();
            }
        }

        private static void Write(ZipArchive archive, string path, string xml)
        {
            var entry = archive.CreateEntry(path, CompressionLevel.Optimal);
            using (var writer = new StreamWriter(entry.Open(), new UTF8Encoding(encoderShouldEmitUTF8Identifier: false)))
            {
            writer.Write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\r\n");
            writer.Write(xml);
            }
        }

        /// <summary>
        /// 0 default · 1 title (bold 13) · 2 column heading (bold, blue-grey fill, border, wrap) · 3 code (grey 9pt, border)
        /// · 4 input (white, border) · 5 label (wrap, border) · 6 section (bold dark blue) · 7 not applicable (grey fill, border)
        /// · 8 note (italic grey)
        /// </summary>
        private const string StylesXml =
            "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<fonts count=\"6\">" +
            "<font><sz val=\"10\"/><name val=\"Arial\"/></font>" +
            "<font><b/><sz val=\"13\"/><name val=\"Arial\"/></font>" +
            "<font><b/><sz val=\"10\"/><name val=\"Arial\"/></font>" +
            "<font><sz val=\"9\"/><color rgb=\"FF555555\"/><name val=\"Arial\"/></font>" +
            "<font><b/><sz val=\"10\"/><color rgb=\"FF1F4E79\"/><name val=\"Arial\"/></font>" +
            "<font><i/><sz val=\"9\"/><color rgb=\"FF666666\"/><name val=\"Arial\"/></font>" +
            "</fonts>" +
            "<fills count=\"5\">" +
            "<fill><patternFill patternType=\"none\"/></fill>" +
            "<fill><patternFill patternType=\"gray125\"/></fill>" +
            "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFDCE6F1\"/><bgColor indexed=\"64\"/></patternFill></fill>" +
            "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFF2F2F2\"/><bgColor indexed=\"64\"/></patternFill></fill>" +
            "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFBFBFBF\"/><bgColor indexed=\"64\"/></patternFill></fill>" +
            "</fills>" +
            "<borders count=\"2\">" +
            "<border><left/><right/><top/><bottom/><diagonal/></border>" +
            "<border><left style=\"thin\"><color rgb=\"FFA6A6A6\"/></left><right style=\"thin\"><color rgb=\"FFA6A6A6\"/></right><top style=\"thin\"><color rgb=\"FFA6A6A6\"/></top><bottom style=\"thin\"><color rgb=\"FFA6A6A6\"/></bottom><diagonal/></border>" +
            "</borders>" +
            "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
            "<cellXfs count=\"9\">" +
            "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
            "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
            "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\" vertical=\"center\" wrapText=\"1\"/></xf>" +
            "<xf numFmtId=\"49\" fontId=\"3\" fillId=\"3\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\"/></xf>" +
            "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\"/>" +
            "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\" applyAlignment=\"1\"><alignment vertical=\"center\" wrapText=\"1\"/></xf>" +
            "<xf numFmtId=\"0\" fontId=\"4\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
            "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"4\" borderId=\"1\" xfId=\"0\" applyFill=\"1\" applyBorder=\"1\"/>" +
            "<xf numFmtId=\"0\" fontId=\"5\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
            "</cellXfs>" +
            "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>" +
            "</styleSheet>";

        private static readonly System.Text.RegularExpressions.Regex GridCodeRegexInstance = new System.Text.RegularExpressions.Regex(@"^(R\d{3,4})(C\d{3,4})$", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

    public sealed class GeneratedInputTemplate : IRecord<GeneratedInputTemplate>, IEquatable<GeneratedInputTemplate>
    {
        public byte[] Bytes { get; set; }

        public IReadOnlyList<MappingEntryDto> Mappings { get; set; }

        public GeneratedInputTemplate(byte[] Bytes, IReadOnlyList<MappingEntryDto> Mappings)
    {
    this.Bytes = Bytes;
    this.Mappings = Mappings;
    }

        public void Deconstruct(out byte[] Bytes, out IReadOnlyList<MappingEntryDto> Mappings)
    {
    Bytes = this.Bytes;
    Mappings = this.Mappings;
    }

        public bool Equals(GeneratedInputTemplate other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<byte[]>.Default.Equals(Bytes, other.Bytes)
    && EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.Equals(Mappings, other.Mappings);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as GeneratedInputTemplate);
    }

        public static bool operator ==(GeneratedInputTemplate left, GeneratedInputTemplate right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(GeneratedInputTemplate left, GeneratedInputTemplate right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 33402;
    hash = hash * -1521134295 + EqualityComparer<byte[]>.Default.GetHashCode(Bytes);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.GetHashCode(Mappings);
    return hash;
    }
    }

        public override string ToString()
    {
    return "GeneratedInputTemplate { " + "Bytes = " + Bytes + ", " + "Mappings = " + Mappings + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public GeneratedInputTemplate CloneRecord()
    {
    return (GeneratedInputTemplate)MemberwiseClone();
    }

    }

}
