﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Builds the submission XML in XSD element order.
    /// An element is written when it (or a descendant) has a mapped value, or when the XSD requires it
    /// under an element that is being written; required leaves without a mapped value use their generated test value.
    /// </summary>
    public sealed class XmlSubmissionWriter
    {
        public byte[] Write(FrpProjectDto project)
        {
            var document = BuildDocument(project);
            using (var stream = new MemoryStream())
            {
            document.Save(stream);
            return stream.ToArray();
            }
        }

        public XDocument BuildDocument(FrpProjectDto project)
        {
            if (string.IsNullOrWhiteSpace(project.RootElement) || project.SchemaNodes.Count == 0)
            {
                throw new InvalidOperationException("The project does not have a root element.");
            }

            XNamespace ns = project.TargetNamespace ?? "";
            var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            // Fields whose value was removed: written empty when the XSD requires them (the XSD check then reports them).
            var cleared = new HashSet<string>(project.Mappings.Where(IsCleared).Select(m => m.SchemaPath), StringComparer.OrdinalIgnoreCase);
            foreach (var mapping in GetEffectiveMappings(project))
            {
                var value = ResolveExportValue(project, mapping);
                if (!string.IsNullOrWhiteSpace(value))
                {
                    values.TryAdd(mapping.SchemaPath, value);
                }
            }

            // Paths that contain at least one mapped value (the element itself or any descendant).
            var hasContent = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            foreach (var path in values.Keys)
            {
                var current = nodesByPath.GetValueOrDefault(path);
                while (current != null && hasContent.Add(current.Path))
                {
                    current = (current.ParentPath == null) ? null : nodesByPath.GetValueOrDefault(current.ParentPath);
                }
            }

            var elements = new Dictionary<string, XElement>(StringComparer.OrdinalIgnoreCase);
            XElement root = null;
            foreach (var node in project.SchemaNodes)
            {
                XElement parent = null;
                if (node.ParentPath == null)
                {
                    if (root != null)
                    {
                        continue;
                    }
                }
                else if (!elements.TryGetValue(node.ParentPath, out parent))
                {
                    continue; // Parent is not written, so neither is this node.
                }

                if (parent != null && !hasContent.Contains(node.Path) && !node.IsRequired)
                {
                    continue;
                }

                var element = new XElement(ns + node.Name);
                if (node.DataType != "complex")
                {
                    element.Value = values.GetValueOrDefault(node.Path) ?? (cleared.Contains(node.Path) ? "" : node.TestValue ?? "");
                }

                if (parent == null)
                {
                    root = element;
                }
                else
                {
                    parent.Add(element);
                }

                elements[node.Path] = element;
            }

            AppendSampleRows(project, elements, nodesByPath);
            OmitExcludedSampleForms(project, root, nodesByPath);
            var result = new XDocument(new XDeclaration("1.0", "UTF-8", "yes"), root ?? new XElement(ns + project.RootElement));
            foreach (var selector in project.SampleExcludedSelectors)
                foreach (var element in System.Xml.XPath.Extensions.XPathSelectElements(result, selector).ToList()) element.Remove();
            return result;
        }

        /// <summary>
        /// Leaves out the forms the specification says are not submitted with the sample's Header values
        /// (e.g. CAR Part IV-5 when MarketRiskApproach is 1), while they still hold only sample values.
        /// </summary>
        private static void OmitExcludedSampleForms(FrpProjectDto project, XElement root, IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath)
        {
            if (root == null || project.SampleOmittedForms.Count == 0)
            {
                return;
            }

            foreach (var form in root.Elements().Where(e => project.SampleOmittedForms.Contains(e.Name.LocalName)).ToList())
            {
                var formPath = PathOf(form);
                var onlySample = form.Descendants().Where(e => !e.HasElements).All(leaf =>
    { SchemaNodeDto node; return nodesByPath.TryGetValue(PathOf(leaf), out node) && string.Equals(leaf.Value, node.TestValue ?? "", StringComparison.Ordinal); });
                SchemaNodeDto formNode;
                if (onlySample && nodesByPath.TryGetValue(formPath, out formNode) && !formNode.IsRequired)
                {
                    form.Remove();
                }
            }
        }

        /// <summary>
        /// Adds the extra sample rows the specification requires (e.g. one row per Bookcode) after a repeating item,
        /// but only while that item's first row still holds the sample values, so they never mix with the bank's own data.
        /// </summary>
        private static void AppendSampleRows(FrpProjectDto project, IReadOnlyDictionary<string, XElement> elements, IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath)
        {
            foreach (var group in project.SampleRows.GroupBy(r => r.ItemPath, StringComparer.OrdinalIgnoreCase))
            {
                XElement first;
                if (!elements.TryGetValue(group.Key, out first) || first.Parent == null)
                {
                    continue;
                }

                var firstIsSample = first.Descendants().Where(e => !e.HasElements).All(leaf =>
    { SchemaNodeDto node; return nodesByPath.TryGetValue(PathOf(leaf), out node) && string.Equals(leaf.Value, node.TestValue ?? "", StringComparison.Ordinal); });
                if (!firstIsSample)
                {
                    continue;
                }

                var last = first;
                foreach (var row in group)
                {
                    var copy = new XElement(first);
                    last.AddAfterSelf(copy); // Attached first, so the leaves' paths match the sample row's keys.
                    last = copy;
                    foreach (var leaf in copy.Descendants().Where(e => !e.HasElements))
                    {
                        string value;
                        if (row.Values.TryGetValue(PathOf(leaf), out value))
                        {
                            leaf.Value = value;
                        }
                    }
                }
            }
        }

        private static string PathOf(XElement element) =>
            "/" + string.Join("/", element.AncestorsAndSelf().Reverse().Select(e => e.Name.LocalName));

        internal static IReadOnlyList<MappingEntryDto> GetEffectiveMappings(FrpProjectDto project)
        {
            if (project.Mappings.Count > 0)
            {
                return project.Mappings;
            }

            return project.SchemaNodes
                .Where(n => n.DataType != "complex")
                .Select((node, index) => new MappingEntryDto
                {
                    SheetName = "Mapped Template",
                    CellAddress = $"B{index + 2}",
                    SchemaPath = node.Path,
                    DataType = node.DataType,
                    Required = node.IsRequired,
                    DefaultValue = node.TestValue,
                    Source = "Generated from XSD"
                })
                .ToList();
        }

        /// <summary>
        /// The value a mapped field exports: what was entered; "" when its value was removed (an empty cell: the sample
        /// value is not used); the field's sample value when it has none of its own (null, as before values could be removed).
        /// </summary>
        internal static string ResolveExportValue(FrpProjectDto project, MappingEntryDto mapping)
        {
            if (IsCleared(mapping))
            {
                return "";
            }

            if (!string.IsNullOrWhiteSpace(mapping.DefaultValue))
            {
                return mapping.DefaultValue;
            }

            return project.SchemaNodes.FirstOrDefault(n => string.Equals(n.Path, mapping.SchemaPath, StringComparison.OrdinalIgnoreCase))?.TestValue ?? "";
        }

        /// <summary>True when the mapped field's value was removed (stored as an empty text, not NULL).</summary>
        internal static bool IsCleared(MappingEntryDto mapping) => mapping.DefaultValue != null && mapping.DefaultValue.Trim().Length == 0;
    }

}
