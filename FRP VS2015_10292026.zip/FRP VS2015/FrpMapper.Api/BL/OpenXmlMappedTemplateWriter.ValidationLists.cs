﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Api.BL
{
    public sealed partial class OpenXmlMappedTemplateWriter
    {
        /// <summary>
        /// Allowed-value lists too long for Excel's 255-character inline list (e.g. 249 country codes): each list is written
        /// once to a column of a hidden sheet, and the mapped cells' dropdown validations refer to it through a workbook
        /// name (_FRP_LIST_1, _FRP_LIST_2…), which every Excel version accepts in a data validation.
        /// </summary>
        private sealed class ValidationLists
        {
            private const string SheetBaseName = "_FRP_LISTS";
            private const string NamePrefix = "_FRP_LIST_";
            private readonly Dictionary<string, VT_Name_Values<string, IReadOnlyList<string>>> _lists = new Dictionary<string, VT_Name_Values<string, IReadOnlyList<string>>>(StringComparer.Ordinal);

            /// <summary>The workbook name for these values (the same list is written once).</summary>
            public string Reference(IReadOnlyList<string> values)
            {
                var key = string.Join("\u001f", values);
                VT_Name_Values<string, IReadOnlyList<string>> list;
                if (!_lists.TryGetValue(key, out list))
                {
                    list = new VT_Name_Values<string, IReadOnlyList<string>>($"{NamePrefix}{_lists.Count + 1}", values);
                    _lists[key] = list;
                }

                return list.Name;
            }

            public void WriteTo(ZipArchive archive)
            {
                if (_lists.Count == 0)
                {
                    return;
                }

                var workbook = ReadXml(archive, "xl/workbook.xml") ?? CompatThrow.As<XDocument>(new InvalidOperationException("Workbook is missing xl/workbook.xml."));
                var rels = ReadXml(archive, "xl/_rels/workbook.xml.rels") ?? new XDocument(new XElement(PackageRel + "Relationships"));
                var root = workbook.Root;
                var sheetsElement = root.Element(Main + "sheets") ?? CompatThrow.As<XElement>(new InvalidOperationException("Workbook has no sheets."));
                var names = sheetsElement.Elements(Main + "sheet").Select(s => (string)s.Attribute("name") ?? "").ToHashSet(StringComparer.OrdinalIgnoreCase);
                var sheetName = SheetBaseName;
                for (var n = 2; names.Contains(sheetName); n++)
                {
                    sheetName = $"{SheetBaseName}{n}";
                }

                var partIndex = 1;
                while (archive.GetEntry($"xl/worksheets/frpLists{partIndex}.xml") != null)
                {
                    partIndex++;
                }

                var partPath = $"xl/worksheets/frpLists{partIndex}.xml";
                var relationshipId = NextRelationshipId(rels.Root);
                rels.Root.Add(new XElement(PackageRel + "Relationship",
                    new XAttribute("Id", relationshipId),
                    new XAttribute("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"),
                    new XAttribute("Target", $"worksheets/frpLists{partIndex}.xml")));
                var nextSheetId = sheetsElement.Elements(Main + "sheet").Select(e => (int?)e.Attribute("sheetId") ?? 0).DefaultIfEmpty(0).Max() + 1;
                // Last, so no sheet-scoped name or active tab moves; hidden, so it does not get in the way of data entry.
                sheetsElement.Add(new XElement(Main + "sheet",
                    new XAttribute("name", sheetName),
                    new XAttribute("sheetId", nextSheetId),
                    new XAttribute("state", "hidden"),
                    new XAttribute(Rel + "id", relationshipId)));

                var definedNames = root.Element(Main + "definedNames");
                if (definedNames == null)
                {
                    definedNames = new XElement(Main + "definedNames");
                    var next = root.Elements().FirstOrDefault(e => e.Name.Namespace == Main && ElementsAfterDefinedNames.Contains(e.Name.LocalName));
                    if (next == null)
                    {
                        root.Add(definedNames);
                    }
                    else
                    {
                        next.AddBeforeSelf(definedNames);
                    }
                }

                var column = 1;
                var columns = new List<VT_Letter_Values<string, IReadOnlyList<string>>>();
                foreach (var list2 in _lists.Values)
                {
                    var name = list2.Name;
                    var values = list2.Values;
                    var letter = ColumnName(column++);
                    columns.Add(new VT_Letter_Values<string, IReadOnlyList<string>>(letter, values));
                    definedNames.Elements(Main + "definedName").Where(e => string.Equals((string)e.Attribute("name"), name, StringComparison.OrdinalIgnoreCase)).Remove();
                    definedNames.Add(new XElement(Main + "definedName",
                        new XAttribute("name", name),
                        new XAttribute("hidden", "1"),
                        $"'{sheetName}'!${letter}$1:${letter}${values.Count}"));
                }

                UpsertEntry(archive, "xl/_rels/workbook.xml.rels", rels.ToString(SaveOptions.DisableFormatting));
                UpsertEntry(archive, "xl/workbook.xml", workbook.ToString(SaveOptions.DisableFormatting));

                var rows = new StringBuilder();
                var rowCount = columns.Max(c => c.Values.Count);
                for (var row = 1; row <= rowCount; row++)
                {
                    rows.Append($"<row r=\"{row}\">");
                    foreach (var column2 in columns.Where(c => c.Values.Count >= row))
                    {
                        var letter = column2.Letter;
                        var values = column2.Values;
                        rows.Append($"<c r=\"{letter}{row}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">{Escape(values[row - 1])}</t></is></c>");
                    }

                    rows.Append("</row>");
                }

                UpsertEntry(archive, partPath,
                    $"<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><dimension ref=\"A1:{columns[columns.Count - 1].Letter}{rowCount}\"/><sheetViews><sheetView workbookViewId=\"0\"/></sheetViews><sheetData>{rows}</sheetData></worksheet>");
                EnsureContentType(archive, $"/{partPath}", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml");
            }

            /// <summary>CT_Workbook elements that come after definedNames.</summary>
            private static readonly HashSet<string> ElementsAfterDefinedNames =
            new HashSet<string> { "calcPr", "oleSize", "customWorkbookViews", "pivotCaches", "smartTagPr", "smartTagTypes", "webPublishing", "fileRecoveryPr", "webPublishObjects", "extLst" };
        }
    }

}
