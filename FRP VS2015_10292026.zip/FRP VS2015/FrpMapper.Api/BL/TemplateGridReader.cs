﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// One worksheet of a project's Excel input template as Excel lays it out: the text of each cell (the cached value of
    /// a formula), bold text, fill and text colours, alignment, merged ranges, column widths and hidden rows and columns.
    /// The Mappings tab draws it as a grid so a Maker can map XSD fields to cells on the sheet itself. The workbook is
    /// only read; a sheet is read once per template file and kept in memory.
    /// </summary>
    public sealed class TemplateGridReader
    {
        /// <summary>The largest grid returned; BSP's biggest template sheets are about 700 rows and 130 columns.</summary>
        public const int MaxRows = 2000;

        public const int MaxColumns = 200;

        private const double ExcelDefaultColumnWidth = 8.43;

        private static readonly TimeSpan CacheFor = TimeSpan.FromMinutes(30);
        private static readonly XNamespace Main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private static readonly XNamespace Relationships = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        private static readonly XNamespace PackageRelationships = "http://schemas.openxmlformats.org/package/2006/relationships";

        private readonly IMemoryCache cache;

        public TemplateGridReader(IMemoryCache cache)
        {
            this.cache = cache;
        }

        /// <summary>The sheet named <paramref name="sheetName"/> (ignoring case), or null when the file or the sheet does not exist.</summary>
        public TemplateGridDto Read(string workbookPath, string sheetName)
        {
            var file = new FileInfo(workbookPath);
            if (!file.Exists || string.IsNullOrWhiteSpace(sheetName))
            {
                return null;
            }

            // Keyed by the file's path, size and time: a replaced file is read again.
            var key = "template-grid|" + file.FullName + "|" + file.Length.ToString(CultureInfo.InvariantCulture) + "|"
                + file.LastWriteTimeUtc.Ticks.ToString(CultureInfo.InvariantCulture) + "|" + sheetName.ToUpperInvariant();
            TemplateGridDto grid;
            if (cache.TryGetValue(key, out grid))
            {
                return grid;
            }

            grid = ReadSheet(file.FullName, sheetName);
            if (grid != null)
            {
                cache.Set(key, grid, new MemoryCacheEntryOptions { SlidingExpiration = CacheFor });
            }

            return grid;
        }

        /// <summary>
        /// The sheet of a workbook made in memory (the downloaded template for a project), kept under
        /// <paramref name="cacheKey"/>, which must change whenever the workbook would.
        /// </summary>
        public TemplateGridDto Read(byte[] workbook, string cacheKey, string sheetName)
        {
            var key = "template-grid-made|" + cacheKey + "|" + sheetName.ToUpperInvariant();
            TemplateGridDto grid;
            if (cache.TryGetValue(key, out grid))
            {
                return grid;
            }

            using (var archive = new ZipArchive(new MemoryStream(workbook), ZipArchiveMode.Read))
            {
                grid = ReadSheet(archive, sheetName);
            }

            if (grid != null)
            {
                cache.Set(key, grid, new MemoryCacheEntryOptions { SlidingExpiration = CacheFor });
            }

            return grid;
        }

        private static TemplateGridDto ReadSheet(string workbookPath, string sheetName)
        {
            using (var archive = ZipFile.OpenRead(workbookPath))
            {
                return ReadSheet(archive, sheetName);
            }
        }

        private static TemplateGridDto ReadSheet(ZipArchive archive, string sheetName)
        {
            {
                var workbook = Load(archive, "xl/workbook.xml");
                var rels = Load(archive, "xl/_rels/workbook.xml.rels");
                if (workbook == null || rels == null)
                {
                    return null;
                }

                var sheet = workbook.Descendants(Main + "sheet")
                    .FirstOrDefault(s => string.Equals((string)s.Attribute("name"), sheetName, StringComparison.OrdinalIgnoreCase));
                if (sheet == null)
                {
                    return null;
                }

                var relationshipId = (string)sheet.Attribute(Relationships + "id") ?? "";
                var target = rels.Root.Elements(PackageRelationships + "Relationship")
                    .Where(r => (string)r.Attribute("Id") == relationshipId)
                    .Select(r => (string)r.Attribute("Target"))
                    .FirstOrDefault();
                var worksheet = string.IsNullOrEmpty(target) ? null : Load(archive, OpenXmlWorkbookInspector.NormalizePartPath("xl", target));
                if (worksheet == null)
                {
                    return null;
                }

                var styles = Styles.Read(Load(archive, "xl/styles.xml"));
                return Layout((string)sheet.Attribute("name"), worksheet, SharedStrings(archive), styles);
            }
        }

        private static TemplateGridDto Layout(string sheetName, XDocument worksheet, IReadOnlyList<string> sharedStrings, Styles styles)
        {
            var root = worksheet.Root;
            var truncated = false;
            var cells = new List<TemplateGridCellDto>();
            var maxRow = 0;
            var maxColumn = 0;
            foreach (var c in root.Descendants(Main + "c"))
            {
                var address = ((string)c.Attribute("r") ?? "").ToUpperInvariant();
                var row = OpenXmlWorkbookInspector.RowNumber(address);
                var column = OpenXmlWorkbookInspector.ColumnIndex(address);
                if (row <= 0 || column <= 0)
                {
                    continue;
                }

                var style = styles.For((string)c.Attribute("s"));
                var text = CellText(c, sharedStrings);
                if (text.Length == 0 && style.Fill == null)
                {
                    continue; // an empty, unfilled cell looks like no cell at all
                }

                if (row > MaxRows || column > MaxColumns)
                {
                    truncated = true;
                    continue;
                }

                maxRow = Math.Max(maxRow, row);
                maxColumn = Math.Max(maxColumn, column);
                cells.Add(new TemplateGridCellDto
                {
                    Address = address,
                    Text = text,
                    Bold = style.Bold,
                    Fill = style.Fill,
                    Color = style.Color,
                    Align = style.Align
                });
            }

            var filled = new HashSet<string>(cells.Select(cell => cell.Address), StringComparer.Ordinal);
            var merges = new List<string>();
            foreach (var merge in root.Descendants(Main + "mergeCell"))
            {
                var range = ((string)merge.Attribute("ref") ?? "").ToUpperInvariant();
                var corners = range.Split(':');
                if (corners.Length != 2)
                {
                    continue;
                }

                int firstRow = OpenXmlWorkbookInspector.RowNumber(corners[0]), firstColumn = OpenXmlWorkbookInspector.ColumnIndex(corners[0]);
                int lastRow = OpenXmlWorkbookInspector.RowNumber(corners[1]), lastColumn = OpenXmlWorkbookInspector.ColumnIndex(corners[1]);
                if (firstRow <= 0 || firstColumn <= 0 || lastRow < firstRow || lastColumn < firstColumn)
                {
                    continue;
                }

                if (lastRow > MaxRows || lastColumn > MaxColumns)
                {
                    truncated = true;
                    continue;
                }

                // Only merges that hold something widen the grid; empty ones further out are drawn only when in view.
                if (filled.Contains(corners[0]))
                {
                    maxRow = Math.Max(maxRow, lastRow);
                    maxColumn = Math.Max(maxColumn, lastColumn);
                }

                merges.Add(range);
            }

            var format = root.Element(Main + "sheetFormatPr");
            var defaultWidth = Number((string)format?.Attribute("defaultColWidth"))
                ?? (Number((string)format?.Attribute("baseColWidth")) + 0.71)
                ?? ExcelDefaultColumnWidth;
            var columns = new List<TemplateGridColumnDto>();
            foreach (var col in root.Descendants(Main + "col"))
            {
                var min = (int)(Number((string)col.Attribute("min")) ?? 0);
                var max = Math.Min((int)(Number((string)col.Attribute("max")) ?? 0), MaxColumns);
                var hidden = Flag((string)col.Attribute("hidden"));
                var width = Number((string)col.Attribute("width")) ?? defaultWidth;
                for (var index = Math.Max(min, 1); index <= max; index++)
                {
                    columns.Add(new TemplateGridColumnDto { Index = index, Width = Math.Round(width, 2), Hidden = hidden });
                }
            }

            var hiddenRows = root.Descendants(Main + "row")
                .Where(r => Flag((string)r.Attribute("hidden")))
                .Select(r => (int)(Number((string)r.Attribute("r")) ?? 0))
                .Where(r => r > 0 && r <= MaxRows)
                .ToList();

            return new TemplateGridDto
            {
                SheetName = sheetName,
                MaxRow = maxRow,
                MaxColumn = maxColumn,
                Truncated = truncated,
                DefaultColumnWidth = Math.Round(defaultWidth, 2),
                Columns = columns,
                HiddenRows = hiddenRows,
                Merges = merges,
                Cells = cells
            };
        }

        private static string CellText(XElement cell, IReadOnlyList<string> sharedStrings)
        {
            var type = (string)cell.Attribute("t");
            var raw = cell.Element(Main + "v")?.Value ?? "";
            int index;
            if (type == "s")
            {
                return int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out index) && index >= 0 && index < sharedStrings.Count ? sharedStrings[index] : "";
            }

            if (type == "inlineStr")
            {
                return string.Concat(cell.Element(Main + "is")?.Descendants(Main + "t").Select(t => t.Value) ?? new List<string>());
            }

            if (type == "b")
            {
                return raw == "1" ? "TRUE" : raw == "0" ? "FALSE" : "";
            }

            double number;
            if ((type == null || type == "n") && double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out number))
            {
                return number.ToString("G15", CultureInfo.InvariantCulture); // 0.1+0.2 shows as 0.3, as in Excel
            }

            return raw;
        }

        private static IReadOnlyList<string> SharedStrings(ZipArchive archive)
        {
            var document = Load(archive, "xl/sharedStrings.xml");
            return document == null
                ? new List<string>()
                : document.Root.Elements(Main + "si").Select(si => string.Concat(si.Descendants(Main + "t").Select(t => t.Value))).ToList();
        }

        private static XDocument Load(ZipArchive archive, string path)
        {
            var entry = archive.GetEntry(path);
            if (entry == null)
            {
                return null;
            }

            using (var stream = entry.Open())
            {
                return SafeXml.Load(stream);
            }
        }

        private static double? Number(string text)
        {
            double value;
            return double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) ? value : (double?)null;
        }

        private static bool Flag(string text) => text == "1" || string.Equals(text, "true", StringComparison.OrdinalIgnoreCase);

        /// <summary>The formatting of the workbook's cell styles (cellXfs) that the grid shows.</summary>
        private sealed class Styles
        {
            private static readonly CellStyle Plain = new CellStyle();

            // Excel's legacy indexed colours 0-63 (used by older templates instead of RGB values).
            private static readonly string[] Indexed =
            {
                "000000", "FFFFFF", "FF0000", "00FF00", "0000FF", "FFFF00", "FF00FF", "00FFFF",
                "000000", "FFFFFF", "FF0000", "00FF00", "0000FF", "FFFF00", "FF00FF", "00FFFF",
                "800000", "008000", "000080", "808000", "800080", "008080", "C0C0C0", "808080",
                "9999FF", "993366", "FFFFCC", "CCFFFF", "660066", "FF8080", "0066CC", "CCCCFF",
                "000080", "FF00FF", "FFFF00", "00FFFF", "800080", "800000", "008080", "0000FF",
                "00CCFF", "CCFFFF", "CCFFCC", "FFFF99", "99CCFF", "FF99CC", "CC99FF", "FFCC99",
                "3366FF", "33CCCC", "99CC00", "FFCC00", "FF9900", "FF6600", "666699", "969696",
                "003366", "339966", "003300", "333300", "993300", "993366", "333399", "333333"
            };

            private readonly List<CellStyle> cellStyles = new List<CellStyle>();

            public static Styles Read(XDocument document)
            {
                var styles = new Styles();
                if (document == null)
                {
                    return styles;
                }

                var root = document.Root;
                var fonts = (root.Element(Main + "fonts")?.Elements(Main + "font") ?? Enumerable.Empty<XElement>())
                    .Select(f =>
                    {
                        var bold = f.Element(Main + "b");
                        return new CellStyle
                        {
                            Bold = bold != null && (string)bold.Attribute("val") != "0" && (string)bold.Attribute("val") != "false",
                            Color = Colour(f.Element(Main + "color"))
                        };
                    })
                    .ToList();
                var fills = (root.Element(Main + "fills")?.Elements(Main + "fill") ?? Enumerable.Empty<XElement>())
                    .Select(f =>
                    {
                        var pattern = f.Element(Main + "patternFill");
                        var kind = (string)pattern?.Attribute("patternType");
                        return pattern == null || kind == null || kind == "none" ? null : Colour(pattern.Element(Main + "fgColor"));
                    })
                    .ToList();
                foreach (var xf in root.Element(Main + "cellXfs")?.Elements(Main + "xf") ?? Enumerable.Empty<XElement>())
                {
                    var font = (int)(Number((string)xf.Attribute("fontId")) ?? 0);
                    var fill = (int)(Number((string)xf.Attribute("fillId")) ?? 0);
                    var horizontal = (string)xf.Element(Main + "alignment")?.Attribute("horizontal");
                    styles.cellStyles.Add(new CellStyle
                    {
                        Bold = font >= 0 && font < fonts.Count && fonts[font].Bold,
                        Color = font >= 0 && font < fonts.Count ? fonts[font].Color : null,
                        Fill = fill >= 0 && fill < fills.Count ? fills[fill] : null,
                        Align = horizontal == "left" || horizontal == "right" ? horizontal
                            : horizontal == "center" || horizontal == "centerContinuous" ? "center" : null
                    });
                }

                return styles;
            }

            public CellStyle For(string styleIndex)
            {
                var index = (int)(Number(styleIndex) ?? 0);
                return index >= 0 && index < cellStyles.Count ? cellStyles[index] : Plain;
            }

            /// <summary>#RRGGBB from an RGB or indexed colour; null for theme colours and automatic colours.</summary>
            private static string Colour(XElement color)
            {
                if (color == null)
                {
                    return null;
                }

                var rgb = (string)color.Attribute("rgb");
                if (rgb != null && (rgb.Length == 8 || rgb.Length == 6) && rgb.All(Uri.IsHexDigit))
                {
                    return "#" + rgb.Substring(rgb.Length - 6).ToUpperInvariant();
                }

                var indexed = Number((string)color.Attribute("indexed"));
                return indexed.HasValue && indexed.Value >= 0 && indexed.Value < Indexed.Length ? "#" + Indexed[(int)indexed.Value] : null;
            }
        }

        private sealed class CellStyle
        {
            public bool Bold { get; set; }

            public string Fill { get; set; }

            public string Color { get; set; }

            public string Align { get; set; }
        }
    }
}
