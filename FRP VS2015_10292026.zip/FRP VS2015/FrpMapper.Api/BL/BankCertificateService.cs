using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// A bank profile's BSP certificate, uploaded once by a Maker (reference.manage) and approved by a different Checker
    /// (reference.approve). The PFX and its password are encrypted (CertificateProtector) before they are stored and are
    /// never returned to any page; BSP submission opens them on the server for one request at a time.
    /// </summary>
    public sealed class BankCertificateService : IBankCertificateService
    {
        private readonly IBankCertificateRepository certificates;
        private readonly IReferenceDataRepository references;
        private readonly CertificateProtector protector;
        private readonly ICurrentUser user;

        public BankCertificateService(IBankCertificateRepository certificates, IReferenceDataRepository references, CertificateProtector protector, ICurrentUser user)
        {
            this.certificates = certificates;
            this.references = references;
            this.protector = protector;
            this.user = user;
        }

        private static WorkflowException Invalid(string message) { return new WorkflowException(WorkflowErrorKind.Invalid, message); }

        private static WorkflowException Forbidden(string message) { return new WorkflowException(WorkflowErrorKind.Forbidden, message); }

        public async Task<IReadOnlyList<BankCertificateDto>> ListAsync(CancellationToken cancellation)
        {
            if (!user.HasPermission(Permissions.ReferenceManage) && !user.HasPermission(Permissions.ReferenceApprove))
                throw Forbidden("Only the Makers and Checkers of bank profiles can see the banks' certificates.");
            return await certificates.ListAsync(cancellation);
        }

        public async Task<BankCertificateDto> UploadAsync(string bankKey, IFormFile certificate, string password, CancellationToken cancellation)
        {
            if (!user.HasPermission(Permissions.ReferenceManage))
                throw Forbidden("Only a Maker of bank profiles can upload a bank's certificate.");
            var data = await references.ReadAsync(cancellation);
            var bank = data.Banks.SingleOrDefault(b => b.Key == bankKey);
            if (bank == null) throw Invalid("Choose a bank profile that has been approved.");
            if (certificate == null) throw Invalid("Choose the bank's PFX certificate.");

            var bytes = await SandboxService.ReadAsync(certificate, new[] { ".pfx", ".p12" }, "PFX certificate", SandboxService.MaxCertificateBytes, cancellation);
            try
            {
                var id = Guid.NewGuid().ToString("N");
                var dto = new BankCertificateDto { Id = id, BankKey = bank.Key, RequestedBy = user.Name, RequestedAt = DateTimeOffset.UtcNow };
                // Opened here exactly as BSP submission will open it: the password must work and the certificate must be current.
                int others;
                var opened = SandboxService.OpenOrThrow(bytes, password, out others);
                try
                {
                    dto.Subject = Limit(opened.Subject, 1000);
                    dto.Issuer = Limit(opened.Issuer, 1000);
                    dto.Thumbprint = opened.Thumbprint.ToUpperInvariant();
                    dto.ValidFrom = Second(opened.NotBefore.ToUniversalTime());
                    dto.ValidUntil = Second(opened.NotAfter.ToUniversalTime());
                }
                finally { opened.Reset(); }
                var name = Path.GetFileName(certificate.FileName ?? "");
                dto.FileName = Limit(Regex.Replace(name, @"[\x00-\x1f]", ""), 260);
                var protectedPfx = protector.Protect(bytes, password, id, bank.Key);
                try
                {
                    return await certificates.RequestAsync(dto, protectedPfx, cancellation);
                }
                catch (AccessRequestOpenException)
                {
                    throw new WorkflowException(WorkflowErrorKind.Conflict, "This bank already has a certificate waiting for approval. Approve, reject or cancel it first.");
                }
            }
            finally { Array.Clear(bytes, 0, bytes.Length); }
        }

        public async Task<bool> DecideAsync(string certificateId, string decision, AccessDecisionRequest body, CancellationToken cancellation)
        {
            string status;
            switch (decision)
            {
                case "approve": status = "Approved"; break;
                case "reject": status = "Rejected"; break;
                case "cancel": status = "Cancelled"; break;
                case "remove": status = "Removed"; break;
                default: throw Invalid("Unknown decision.");
            }
            if (!Regex.IsMatch(certificateId ?? "", @"\A[0-9a-f]{32}\z")) return false;
            body = body ?? new AccessDecisionRequest();
            var comment = body.Comment == null ? null : body.Comment.Trim();
            if (comment != null && (comment.Length > 1000 || comment.Any(ch => char.IsControl(ch) && ch != '\n' && ch != '\r')))
                throw Invalid("The comment must be at most 1,000 characters.");
            if (comment == "") comment = null;

            var list = await certificates.ListAsync(cancellation);
            var certificate = list.FirstOrDefault(c => c.Id == certificateId);
            if (certificate == null) return false;
            var mine = string.Equals(certificate.RequestedBy, user.Name, StringComparison.OrdinalIgnoreCase);
            if (status == "Cancelled")
            {
                if (!mine || !user.HasPermission(Permissions.ReferenceManage))
                    throw Forbidden("Only the person who uploaded a certificate can cancel it.");
            }
            else
            {
                if (!user.HasPermission(Permissions.ReferenceApprove))
                    throw Forbidden("Only a Checker of bank profiles can approve, reject or remove a certificate.");
                if (status != "Removed" && mine)
                    throw Forbidden("A Checker other than you must approve or reject the certificate you uploaded.");
                if (status == "Rejected" && comment == null)
                    throw Invalid("Say why the certificate is rejected.");
                if (status == "Removed" && comment == null)
                    throw Invalid("Say why the certificate is removed.");
                if (status == "Approved" && certificate.ValidUntil <= DateTime.UtcNow)
                    throw new WorkflowException(WorkflowErrorKind.Conflict, "This certificate has expired. Reject it instead.");
            }

            byte[] version;
            try { version = Convert.FromBase64String(body.Version ?? ""); }
            catch (FormatException) { throw Invalid("Reload the page and try again."); }
            if (version.Length != 8) throw Invalid("Reload the page and try again.");
            try
            {
                return await certificates.DecideAsync(certificateId, version, status, user.Name, DateTimeOffset.UtcNow, comment, cancellation);
            }
            catch (ConcurrencyConflictException)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, "This certificate was decided or changed by someone else. Reload and try again.");
            }
            catch (AccessDecisionRefusedException ex)
            {
                throw Forbidden(ex.Message);
            }
        }

        private static string Limit(string value, int length)
        {
            value = value ?? "";
            return value.Length <= length ? value : value.Substring(0, length);
        }

        private static DateTime Second(DateTime value)
        {
            return new DateTime(value.Ticks - value.Ticks % TimeSpan.TicksPerSecond, DateTimeKind.Utc);
        }
    }
}
