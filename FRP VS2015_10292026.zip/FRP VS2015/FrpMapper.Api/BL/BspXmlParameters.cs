using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Reads the BSP submission parameters from a report XML, so nobody has to type them: report code = the root element
    /// (FRP, FRP_CONSO, CAR_M, BCCR…; BSP's XSDs carry no report code in the Header), period = Header Year and Period as
    /// YYYY-MM, bank = the one bank profile whose provider code is Header/Undertaking (leading zeros ignored).
    /// </summary>
    public static class BspXmlParameters
    {
        public static SandboxParametersDto Read(XElement root, IEnumerable<BankProfileDto> banks)
        {
            var parameters = new SandboxParametersDto();
            if (root == null) return parameters;
            if (Regex.IsMatch(root.Name.LocalName, @"\A[A-Za-z0-9_]{1,40}\z")) parameters.ReportCode = root.Name.LocalName;
            var year = BankReferenceContext.Header(root, "Year").Trim();
            var month = BankReferenceContext.Header(root, "Period").Trim();
            int number;
            if (Regex.IsMatch(year, @"\A[0-9]{4}\z") && int.TryParse(month, out number) && number >= 1 && number <= 12 && Regex.IsMatch(month, @"\A[0-9]{1,2}\z"))
                parameters.Period = year + "-" + number.ToString("00", System.Globalization.CultureInfo.InvariantCulture);
            parameters.Undertaking = BankReferenceContext.Header(root, "Undertaking").Trim();
            if (parameters.Undertaking.Length > 0)
            {
                var matching = banks.Where(b => BankReferenceContext.Code(b.ProviderCode) == BankReferenceContext.Code(parameters.Undertaking)).ToList();
                if (matching.Count == 1)
                {
                    parameters.BankKey = matching[0].Key;
                    parameters.BankName = matching[0].Name;
                }
            }

            return parameters;
        }
    }
}
