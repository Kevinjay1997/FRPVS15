﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Places every XSD leaf on an input cell of the workbook.
    ///
    /// BSP templates follow a fixed layout that mirrors the XSD:
    ///   /ROOT/SHEET/SECTION[/SECTION_Item]/LEAF
    /// - SHEET is the worksheet name (A1 also holds it).
    /// - SECTION (e.g. MAIN, MAIN_1, MAIN_X1) is written in column A above its table.
    /// - Grid leaves are named RxxxxCyyyy: the value cell is where the "Rxxxx" row-code row
    ///   meets the "Cyyyy" column-code column inside that section.
    /// - List leaves are named Cyyyy: the value cell is the first data row under the "Cyyyy" header.
    /// - Leaves named Rxxxx inside an item are written in the column right of the row codes.
    /// - Other leaves (Undertaking, ClosingRate, Currency...) are placed next to / under their label.
    /// Values are always written to input cells, never to code, header or label cells.
    /// Leaves that cannot be located get a row on a generated sheet so every XSD field is still mapped.
    /// </summary>
    public sealed partial class MappingSuggestionEngine
    {
        public const string SourceExistingSingle = "Existing Excel XML map";
        public const string SourceExistingList = "Existing Excel XML list";
        public const string SourceLayout = "Matched BSP row/column codes";
        public const string SourceLabel = "Matched field label";
        public const string SourceGenerated = "Generated sheet";
        public const string SourceListExtension = "Added column to existing XML list";
        public const string UnplacedSheetName = "FRP_Unplaced";

        public MappingPlan CreateInitialMappings(IReadOnlyList<SchemaNodeDto> schemaNodes, WorkbookSummaryDto workbook)
        {
            var leafNodes = schemaNodes.Where(n => n.DataType != "complex").ToList();
            var leafByPath = leafNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);

            var mappings = new Dictionary<string, MappingEntryDto>(StringComparer.OrdinalIgnoreCase);
            var usedCells = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var notes = new List<ValidationIssueDto>();
            Action<SchemaNodeDto, string, string, string> Add = null;
            Add = (SchemaNodeDto nodeArg, string sheetNameArg, string cellAddress, string source) =>
            {
                var address = cellAddress.ToUpperInvariant();
                mappings[nodeArg.Path] = new MappingEntryDto
                {
                    SheetName = sheetNameArg,
                    CellAddress = address,
                    SchemaPath = nodeArg.Path,
                    DataType = nodeArg.DataType,
                    Required = nodeArg.IsRequired,
                    DefaultValue = nodeArg.TestValue,
                    Source = source
                };
                usedCells[$"{sheetNameArg}!{address}"] = nodeArg.Path;
            };

            // 1. Bindings already defined in the template's Excel XML map are authoritative.
            foreach (var existing in workbook?.ExistingMappings ?? new List<ExistingXmlMappingDto>())
            {
                var path = NormalizeXPath(existing.XPath);
                SchemaNodeDto node;
                if (!leafByPath.TryGetValue(path, out node) || mappings.ContainsKey(node.Path))
                {
                    continue;
                }

                Add(node, existing.SheetName, existing.CellAddress, existing.IsListColumn ? SourceExistingList : SourceExistingSingle);
            }

            // 2. Resolve the remaining leaves from the sheet layout.
            var layouts = new Dictionary<string, SheetLayout>(StringComparer.OrdinalIgnoreCase);
            var sectionNamesBySheet = BuildSectionNames(leafNodes);
            var nodesByPathLookup = schemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var siblingsByParent = leafNodes
                .Where(n => n.ParentPath != null)
                .GroupBy(n => n.ParentPath, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => (IReadOnlyList<string>)g.Select(n => n.Name).ToList(), StringComparer.OrdinalIgnoreCase);
            var unplaced = new List<VT_Node_Reason_TargetSheet<SchemaNodeDto, string, string>>();
            var sheetLookup = (workbook == null)
                ? new Dictionary<string, WorkbookSheetDto>(StringComparer.OrdinalIgnoreCase)
                : ResolveSheets(workbook, leafNodes);
            var listHeaders = new Dictionary<string, IReadOnlyDictionary<string, string>>(StringComparer.OrdinalIgnoreCase);

            foreach (var node in leafNodes.Where(n => !mappings.ContainsKey(n.Path)))
            {
                var tokens = node.Path.Split('/', StringSplitOptions.RemoveEmptyEntries);
                if (tokens.Length < 3)
                {
                    unplaced.Add(new VT_Node_Reason_TargetSheet<SchemaNodeDto, string, string>(node, "The element is not inside a sheet-level XSD element.", null));
                    continue;
                }

                var sheetKey = tokens[1];
                WorkbookSheetDto sheet;
                if (!sheetLookup.TryGetValue(sheetKey, out sheet))
                {
                    sheet = (workbook == null) ? null : FindSheet(workbook, sheetKey);
                    sheetLookup[sheetKey] = sheet;
                }

                if (sheet == null)
                {
                    unplaced.Add(new VT_Node_Reason_TargetSheet<SchemaNodeDto, string, string>(node, (workbook == null)
                        ? "No template uploaded; the field is placed on a generated sheet."
                        : $"The template has no worksheet named '{sheetKey}'.", sheetKey));
                    continue;
                }

                SheetLayout layout;
                if (!layouts.TryGetValue(sheet.Name, out layout))
                {
                    layout = new SheetLayout(sheet);
                    layouts[sheet.Name] = layout;
                }

                var sectionNames = sectionNamesBySheet.GetValueOrDefault(sheetKey) ?? new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                var resolution = default(Resolution);
                if (node.IsInRepeatingGroup && node.ParentPath != null)
                {
                    // List items: a header row naming the item's elements (C0010.., COUNTRY, R0010, R0020C0020..)
                    // with the input row directly underneath.
                    var headerKey = $"{sheet.Name}|{node.ParentPath}";
                    IReadOnlyDictionary<string, string> headerCells;
                    if (!listHeaders.TryGetValue(headerKey, out headerCells))
                    {
                        var itemSection = layout.FindSection(CompatArray.Slice(tokens, 2, tokens.Length - 1), sectionNames);
                        headerCells = layout.FindListHeader(siblingsByParent.GetValueOrDefault(node.ParentPath) ?? new List<string>(), itemSection);
                        listHeaders[headerKey] = headerCells;
                    }

                    string listCell;
                    if (headerCells != null && headerCells.TryGetValue(node.Name, out listCell))
                    {
                        resolution = new Resolution(listCell, SourceLayout, null);
                    }
                }

                if (resolution.Address == null)
                {
                    resolution = Resolve(layout, tokens, sectionNames);
                }

                if (resolution.Address == null && node.IsInRepeatingGroup && node.ParentPath != null)
                {
                    // The template's existing XML list for this item has no column for the element (e.g. an element only one
                    // currency's XSD has): use the next free column right of the list; the exporter extends the table.
                    resolution = ExtendExistingList(node, sheet.Name, layout, mappings, usedCells, nodesByPathLookup);
                }

                if (resolution.Address == null)
                {
                    unplaced.Add(new VT_Node_Reason_TargetSheet<SchemaNodeDto, string, string>(node, resolution.Reason ?? "The input cell could not be located.", null));
                    continue;
                }

                var cellKey = $"{sheet.Name}!{resolution.Address}";
                string owner;
                if (usedCells.TryGetValue(cellKey, out owner))
                {
                    unplaced.Add(new VT_Node_Reason_TargetSheet<SchemaNodeDto, string, string>(node, $"Resolved to {cellKey}, which is already mapped to {owner}.", null));
                    continue;
                }

                Add(node, sheet.Name, resolution.Address, resolution.Source);
            }

            // 3. Anything still unplaced gets a row on a generated sheet so it is mapped and filled.
            // XSD sheets missing from the template (e.g. Header) use the BSP layout: labels in B from row 4, values in C.
            // Fields that could not be placed on an existing sheet go to FRP_Unplaced: XSD path in A, value in B.
            var generatedRows = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in unplaced)
            {
                var node = entry.Node;
                var reason = entry.Reason;
                var targetSheet = entry.TargetSheet;
                var sheetName = GeneratedSheetName(targetSheet, workbook);
                var isUnplacedSheet = sheetName == UnplacedSheetName;
                var row = generatedRows.GetValueOrDefault(sheetName, isUnplacedSheet ? 1 : 3) + 1;
                generatedRows[sheetName] = row;
                var address = isUnplacedSheet ? $"B{row}" : $"C{row}";
                Add(node, sheetName, address, SourceGenerated);
                if (workbook != null)
                {
                    notes.Add(new ValidationIssueDto
                    {
                        Category = "Mapping",
                        Severity = isUnplacedSheet ? "Warning" : "Info",
                        Message = $"{reason} Placed on generated sheet '{sheetName}' at {address}.",
                        SchemaPath = node.Path,
                        SheetName = sheetName,
                        CellAddress = address
                    });
                }
            }

            // Keep schema order so the UI and exports follow the XSD.
            var ordered = leafNodes
                .Where(n => mappings.ContainsKey(n.Path))
                .Select(n => mappings[n.Path])
                .ToList();

            return new MappingPlan(ordered, notes);
        }

        private static Resolution ExtendExistingList(
            SchemaNodeDto node,
            string sheetName,
            SheetLayout layout,
            IReadOnlyDictionary<string, MappingEntryDto> mappings,
            IReadOnlyDictionary<string, string> usedCells,
            IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath)
        {
            var siblings = mappings.Values
                .Where(m => { SchemaNodeDto sibling; return (m.Source == SourceExistingList || m.Source == SourceListExtension)
                    && string.Equals(m.SheetName, sheetName, StringComparison.OrdinalIgnoreCase)
                    && nodesByPath.TryGetValue(m.SchemaPath, out sibling)
                    && string.Equals(sibling.ParentPath, node.ParentPath, StringComparison.OrdinalIgnoreCase); })
                .Select(m => new VT_Column_Row<int, int>(OpenXmlWorkbookInspector.ColumnIndex(m.CellAddress), OpenXmlWorkbookInspector.RowNumber(m.CellAddress)))
                .ToList();
            if (siblings.Count == 0 || siblings.Select(s => s.Row).Distinct().Count() != 1 || siblings[0].Row < 2)
            {
                return Resolution.Fail("No column for it in the template's XML list.");
            }

            var row = siblings[0].Row;
            var column = siblings.Max(s => s.Column) + 1;
            var address = $"{OpenXmlWorkbookInspector.ColumnName(column)}{row}";
            if (layout.HasText(column, row) || layout.HasText(column, row - 1) || usedCells.ContainsKey($"{sheetName}!{address}"))
            {
                return Resolution.Fail("No column for it in the template's XML list, and the next column is not free.");
            }

            return new Resolution(address, SourceListExtension, null);
        }

        /// <summary>Generated sheets use the XSD sheet name when the template lacks it, otherwise a shared "unplaced" sheet.</summary>
        private static string GeneratedSheetName(string targetSheet, WorkbookSummaryDto workbook)
        {
            if (string.IsNullOrWhiteSpace(targetSheet))
            {
                return UnplacedSheetName;
            }

            var name = SafeSheetName(targetSheet);
            return workbook != null && FindSheet(workbook, name) != null ? UnplacedSheetName : name;
        }

        internal static string SafeSheetName(string value)
        {
            var cleaned = string.Concat(value.Where(ch => !(ch == ':' || ch == '\\' || ch == '/' || ch == '?' || ch == '*' || ch == '[' || ch == ']'))).Trim('\'');
            if (cleaned.Length == 0)
            {
                cleaned = "Sheet";
            }

            return cleaned.Length > 31 ? cleaned.Substring(0, 31) : cleaned;
        }

        private static Resolution Resolve(SheetLayout layout, string[] tokens, ISet<string> sectionNames)
        {
            var name = tokens[tokens.Length - 1];
            var containers = CompatArray.Slice(tokens, 2, tokens.Length - 1);
            var section = layout.FindSection(containers, sectionNames);

            var gridMatch = GridCodeRegex().Match(name);
            if (gridMatch.Success)
            {
                var rowCode = gridMatch.Groups[1].Value;
                var columnCode = gridMatch.Groups[2].Value;
                var rowCell = layout.FindCode(rowCode, section).FirstOrDefault();
                if (rowCell == null)
                {
                    return Resolution.Fail($"Row code {rowCode} was not found on sheet '{layout.Name}'{section.Describe()}.");
                }

                var columnCell = layout.FindCode(columnCode, section)
                    .Where(c => c.Row < rowCell.Row)
                    .OrderByDescending(c => c.Row)
                    .FirstOrDefault()
                    ?? layout.FindCode(columnCode, section).FirstOrDefault();
                if (columnCell == null)
                {
                    return Resolution.Fail($"Column code {columnCode} was not found on sheet '{layout.Name}'{section.Describe()}.");
                }

                // Transposed grids list R codes across a header row and C codes down a column:
                // the value then sits in the R code's column on the C code's row.
                if (columnCell.Row > rowCell.Row && columnCell.Column < rowCell.Column)
                {
                    return layout.InputCell(rowCell.Column, columnCell.Row, SourceLayout);
                }

                return layout.InputCell(columnCell.Column, rowCell.Row, SourceLayout);
            }

            if (ColumnCodeRegex().IsMatch(name))
            {
                var header = layout.FindCode(name, section).FirstOrDefault();
                if (header == null)
                {
                    return Resolution.Fail($"Column code {name} was not found on sheet '{layout.Name}'{section.Describe()}.");
                }

                // For a row-code grid inside the section use the first code row; otherwise the first data row under the header.
                var firstRowCode = layout.RowCodes(section).FirstOrDefault(c => c.Row > header.Row);
                var row = firstRowCode?.Row ?? header.Row + 1;
                return layout.InputCell(header.Column, row, SourceLayout);
            }

            if (RowCodeRegex().IsMatch(name))
            {
                var rowCell = layout.FindCode(name, section).FirstOrDefault();
                if (rowCell == null)
                {
                    return Resolution.Fail($"Row code {name} was not found on sheet '{layout.Name}'{section.Describe()}.");
                }

                return layout.InputCell(rowCell.Column + 1, rowCell.Row, SourceLayout);
            }

            return ResolveLabel(layout, name, section);
        }

        private static Resolution ResolveLabel(SheetLayout layout, string name, Section section)
        {
            var target = Normalize(name);
            var matches = layout.Cells
                .Where(c => section.Contains(c.Row) && Normalize(c.Text) == target)
                .OrderBy(c => c.Row).ThenBy(c => c.Column)
                .ToList();
            if (matches.Count == 0 && !section.IsWholeSheet)
            {
                matches = layout.Cells
                    .Where(c => Normalize(c.Text) == target)
                    .OrderBy(c => c.Row).ThenBy(c => c.Column)
                    .ToList();
            }

            if (matches.Count == 0)
            {
                return Resolution.Fail($"No label '{name}' was found on sheet '{layout.Name}'.");
            }

            // Inside a coded grid the label sits in the row-code column; the value goes to the right.
            var codeColumns = layout.RowCodes(section).Select(c => c.Column).ToHashSet();
            var inCodeColumn = matches.FirstOrDefault(c => codeColumns.Contains(c.Column));
            if (inCodeColumn != null)
            {
                return layout.InputCell(inCodeColumn.Column + 1, inCodeColumn.Row, SourceLabel);
            }

            var label = matches[0];
            if (label.Column == 1)
            {
                // Parameter blocks: element name in column A (A4), caption under it (A5), input cell under the caption (A6).
                // The input cell may already hold a preset value (e.g. the sheet's currency), so it is not required to be empty.
                var captionRow = label.Row + 1;
                var inputRow = layout.HasText(1, captionRow) ? captionRow + 1 : captionRow;
                if (inputRow < label.Row + 1 + 1 && Normalize(layout.TextAt(1, captionRow) ?? "") == target)
                {
                    inputRow = captionRow + 1;
                }

                return layout.InputCell(1, inputRow, SourceLabel);
            }

            // Header style: caption in one column, value in the next empty cell to the right.
            for (var column = label.Column + 1; column <= label.Column + 3; column++)
            {
                if (!layout.HasText(column, label.Row))
                {
                    return layout.InputCell(column, label.Row, SourceLabel);
                }
            }

            return Resolution.Fail($"No empty input cell was found next to label '{name}' on sheet '{layout.Name}'.");
        }

        private static Dictionary<string, ISet<string>> BuildSectionNames(IEnumerable<SchemaNodeDto> leaves)
        {
            return leaves
                .Select(n => n.Path.Split('/', StringSplitOptions.RemoveEmptyEntries))
                .Where(t => t.Length >= 3)
                .GroupBy(t => t[1], StringComparer.OrdinalIgnoreCase)
                .ToDictionary(
                    g => g.Key,
                    // Every container level (MAIN, MAIN_Y2, ADD1...) and non-code leaf names (ClosingRate, Currency...)
                    // can appear in column A as the start of a block, so all of them act as section boundaries.
                    g => (ISet<string>)g
                        .SelectMany(t => CompatArray.Slice(t, 2, t.Length - 1).Append(t[t.Length - 1]).Where(name => !AnyCodeRegex().IsMatch(name)))
                        .ToHashSet(StringComparer.OrdinalIgnoreCase),
                    StringComparer.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Maps every XSD sheet element to a worksheet. Direct matches first; then sheets that share a title in A1
        /// (e.g. several "RCBP" sheets) are matched to the remaining XSD names by their distinguishing suffix
        /// (RCBP_OTHER -> "RCBP (OTH CURR)", INTRA_USD -> "INTRADAY_USD").
        /// </summary>
        private static Dictionary<string, WorkbookSheetDto> ResolveSheets(WorkbookSummaryDto workbook, IEnumerable<SchemaNodeDto> leaves)
        {
            var keys = leaves
                .Select(n => n.Path.Split('/', StringSplitOptions.RemoveEmptyEntries))
                .Where(t => t.Length >= 3)
                .Select(t => t[1])
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
            var result = new Dictionary<string, WorkbookSheetDto>(StringComparer.OrdinalIgnoreCase);
            foreach (var key in keys)
            {
                result[key] = FindSheet(workbook, key);
            }

            var claimed = result.Values.Where(s => s != null).Select(s => s.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
            foreach (var key in keys.Where(k => result[k] == null))
            {
                var keyTokens = key.Split('_', StringSplitOptions.RemoveEmptyEntries);
                var candidates = workbook.Sheets
                    .Where(s => !claimed.Contains(s.Name))
                    .Select(s => new VT_Sheet_Title<WorkbookSheetDto, string>(s, Normalize(s.Cells.FirstOrDefault(c => c.Address == "A1")?.DisplayValue ?? "")))
                    .Where(x => x.Title.Length > 0 && Normalize(key).StartsWith(x.Title, StringComparison.Ordinal))
                    .Select(x => new VT_Sheet_Score<WorkbookSheetDto, int>(x.Sheet, SuffixScore(keyTokens, x.Sheet.Name)))
                    .Where(x => x.Score > 0)
                    .OrderByDescending(x => x.Score)
                    .ToList();
                if (candidates.Count > 0 && (candidates.Count == 1 || candidates[0].Score > candidates[1].Score))
                {
                    result[key] = candidates[0].Sheet;
                    claimed.Add(candidates[0].Sheet.Name);
                }
            }

            return result;
        }

        /// <summary>How well the XSD name's tokens (after the first) match the sheet name's tokens, allowing prefixes (OTHER ~ OTH).</summary>
        private static int SuffixScore(IReadOnlyList<string> keyTokens, string sheetName)
        {
            var sheetTokens = System.Text.RegularExpressions.Regex.Split(sheetName.ToUpperInvariant(), "[^A-Z0-9]+")
                .Where(t => t.Length > 0)
                .ToList();
            var score = 0;
            foreach (var token in keyTokens.Skip(1).Select(t => t.ToUpperInvariant()))
            {
                if (sheetTokens.Any(t => t == token))
                {
                    score += 3;
                }
                else if (sheetTokens.Any(t => t.Length >= 2 && (token.StartsWith(t, StringComparison.Ordinal) || t.StartsWith(token, StringComparison.Ordinal))))
                {
                    score += 1;
                }
            }

            return score;
        }

        /// <summary>
        /// Finds the worksheet for an XSD sheet element: exact name, then the name in A1,
        /// then a punctuation-insensitive match (XSD "CAR_Part_IV_1d_PHP" vs tab "CAR_Part_IV_1d (PHP)").
        /// </summary>
        private static WorkbookSheetDto FindSheet(WorkbookSummaryDto workbook, string sheetKey)
        {
            var normalizedKey = Normalize(sheetKey);
            return workbook.Sheets.FirstOrDefault(s => string.Equals(s.Name, sheetKey, StringComparison.OrdinalIgnoreCase))
                ?? workbook.Sheets.FirstOrDefault(s => s.Cells.Any(c => c.Address == "A1" && string.Equals(c.DisplayValue.Trim(), sheetKey, StringComparison.OrdinalIgnoreCase)))
                ?? workbook.Sheets.FirstOrDefault(s => Normalize(s.Name) == normalizedKey)
                ?? workbook.Sheets.FirstOrDefault(s => s.Cells.Any(c => c.Address == "A1" && Normalize(c.DisplayValue) == normalizedKey));
        }

        private static string Normalize(string value)
        {
            return string.Concat(value.Where(char.IsLetterOrDigit)).ToUpperInvariant();
        }

        private static string NormalizeXPath(string xpath)
        {
            var tokens = xpath.Split('/', StringSplitOptions.RemoveEmptyEntries)
                .Select(token =>
                {
                    var index = token.IndexOf(':', StringComparison.Ordinal);
                    return index >= 0 ? token.Substring(index + 1) : token;
                });
            return "/" + string.Join("/", tokens);
        }

        private static System.Text.RegularExpressions.Regex GridCodeRegex() { return GridCodeRegexInstance; }

        private static System.Text.RegularExpressions.Regex ColumnCodeRegex() { return ColumnCodeRegexInstance; }

        private static System.Text.RegularExpressions.Regex RowCodeRegex() { return RowCodeRegexInstance; }

        private static System.Text.RegularExpressions.Regex AnyCodeRegex() { return AnyCodeRegexInstance; }

        private sealed class LayoutCell : IRecord<LayoutCell>, IEquatable<LayoutCell>
    {
        public int Column { get; set; }

        public int Row { get; set; }

        public string Text { get; set; }

        public LayoutCell(int Column, int Row, string Text)
    {
    this.Column = Column;
    this.Row = Row;
    this.Text = Text;
    }

        public void Deconstruct(out int Column, out int Row, out string Text)
    {
    Column = this.Column;
    Row = this.Row;
    Text = this.Text;
    }

        public bool Equals(LayoutCell other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<int>.Default.Equals(Column, other.Column)
    && EqualityComparer<int>.Default.Equals(Row, other.Row)
    && EqualityComparer<string>.Default.Equals(Text, other.Text);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as LayoutCell);
    }

        public static bool operator ==(LayoutCell left, LayoutCell right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(LayoutCell left, LayoutCell right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 99133;
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Column);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(Row);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Text);
    return hash;
    }
    }

        public override string ToString()
    {
    return "LayoutCell { " + "Column = " + Column + ", " + "Row = " + Row + ", " + "Text = " + Text + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public LayoutCell CloneRecord()
    {
    return (LayoutCell)MemberwiseClone();
    }

    }

        private struct Section : IEquatable<Section>
    {
        public int FirstRow { get; set; }

        public int LastRow { get; set; }

        public string Name { get; set; }

        public Section(int FirstRow, int LastRow, string Name)
    {
    this.FirstRow = FirstRow;
    this.LastRow = LastRow;
    this.Name = Name;
    }

        public void Deconstruct(out int FirstRow, out int LastRow, out string Name)
    {
    FirstRow = this.FirstRow;
    LastRow = this.LastRow;
    Name = this.Name;
    }

            public static Section WholeSheet => new Section(1, int.MaxValue, null);

            public bool IsWholeSheet => Name == null;

            public bool Contains(int row) => row >= FirstRow && row <= LastRow;

            public string Describe() => (Name == null) ? "" : $" in section {Name}";

        public bool Equals(Section other)
    {
    return EqualityComparer<int>.Default.Equals(FirstRow, other.FirstRow) && EqualityComparer<int>.Default.Equals(LastRow, other.LastRow) && EqualityComparer<string>.Default.Equals(Name, other.Name);
    }

        public override bool Equals(object obj)
    {
    return obj is Section && Equals((Section)obj);
    }

        public static bool operator ==(Section left, Section right)
    {
    return left.Equals(right);
    }

        public static bool operator !=(Section left, Section right)
    {
    return !left.Equals(right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 68140;
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(FirstRow);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(LastRow);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
    return hash;
    }
    }

        public override string ToString()
    {
    return "Section { " + "FirstRow = " + FirstRow + ", " + "LastRow = " + LastRow + ", " + "Name = " + Name + ", " + "IsWholeSheet = " + IsWholeSheet + " }";
    }

    }

        private struct Resolution : IEquatable<Resolution>
    {
        public string Address { get; set; }

        public string Source { get; set; }

        public string Reason { get; set; }

        public Resolution(string Address, string Source, string Reason)
    {
    this.Address = Address;
    this.Source = Source;
    this.Reason = Reason;
    }

        public void Deconstruct(out string Address, out string Source, out string Reason)
    {
    Address = this.Address;
    Source = this.Source;
    Reason = this.Reason;
    }

            public static Resolution Fail(string reason) => new Resolution(null, "", reason);

        public bool Equals(Resolution other)
    {
    return EqualityComparer<string>.Default.Equals(Address, other.Address) && EqualityComparer<string>.Default.Equals(Source, other.Source) && EqualityComparer<string>.Default.Equals(Reason, other.Reason);
    }

        public override bool Equals(object obj)
    {
    return obj is Resolution && Equals((Resolution)obj);
    }

        public static bool operator ==(Resolution left, Resolution right)
    {
    return left.Equals(right);
    }

        public static bool operator !=(Resolution left, Resolution right)
    {
    return !left.Equals(right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 67715;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Address);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Source);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Reason);
    return hash;
    }
    }

        public override string ToString()
    {
    return "Resolution { " + "Address = " + Address + ", " + "Source = " + Source + ", " + "Reason = " + Reason + " }";
    }

    }

        private sealed class SheetLayout
        {
            private readonly Dictionary<VT_Column_Row<int, int>, string> _text = new Dictionary<VT_Column_Row<int, int>, string>();
            private readonly Dictionary<string, List<LayoutCell>> _codes = new Dictionary<string, List<LayoutCell>>(StringComparer.OrdinalIgnoreCase);

            public SheetLayout(WorkbookSheetDto sheet)
            {
                Name = sheet.Name;
                foreach (var cell in sheet.Cells)
                {
                    var column = OpenXmlWorkbookInspector.ColumnIndex(cell.Address);
                    var row = OpenXmlWorkbookInspector.RowNumber(cell.Address);
                    var text = cell.DisplayValue.Trim();
                    if (column == 0 || row == 0 || text.Length == 0)
                    {
                        continue;
                    }

                    var layoutCell = new LayoutCell(column, row, text);
                    Cells.Add(layoutCell);
                    _text[new VT_Column_Row<int, int>(column, row)] = text;
                    if (AnyCodeRegex().IsMatch(text))
                    {
                        List<LayoutCell> list;
                        if (!_codes.TryGetValue(text, out list))
                        {
                            list = new List<LayoutCell>();
                            _codes[text] = list;
                        }

                        list.Add(layoutCell);
                    }
                }

                Cells.Sort((a, b) => a.Row != b.Row ? a.Row.CompareTo(b.Row) : a.Column.CompareTo(b.Column));
                foreach (var list in _codes.Values)
                {
                    list.Sort((a, b) => a.Row != b.Row ? a.Row.CompareTo(b.Row) : a.Column.CompareTo(b.Column));
                }
            }

            public string Name { get; }

            public List<LayoutCell> Cells { get; } = new List<LayoutCell>();

            private List<LayoutCell> _anchors;
            private List<LayoutCell> _rowCodes;

            public bool HasText(int column, int row) => _text.ContainsKey(new VT_Column_Row<int, int>(column, row));

            public string TextAt(int column, int row) => _text.GetValueOrDefault(new VT_Column_Row<int, int>(column, row));

            /// <summary>
            /// Finds the header row of an XML list: the row naming the most sibling elements (at least two),
            /// and returns element name -> input cell (one row below the header).
            /// </summary>
            public IReadOnlyDictionary<string, string> FindListHeader(IReadOnlyList<string> siblingNames, Section section)
            {
                if (siblingNames.Count < 2)
                {
                    return null;
                }

                // Prefer a header inside the item's own section (the same C-code header repeats per section).
                return FindListHeaderIn(siblingNames, section)
                    ?? (section.IsWholeSheet ? null : FindListHeaderIn(siblingNames, Section.WholeSheet));
            }

            private IReadOnlyDictionary<string, string> FindListHeaderIn(IReadOnlyList<string> siblingNames, Section section)
            {
                var names = siblingNames.ToHashSet(StringComparer.OrdinalIgnoreCase);
                var best = Cells
                    .Where(c => section.Contains(c.Row) && names.Contains(c.Text))
                    .GroupBy(c => c.Row)
                    .Select(g => new VT_Row_Cells<int, List<LayoutCell>>(g.Key, g.GroupBy(c => c.Text, StringComparer.OrdinalIgnoreCase).Select(x => x.First()).ToList()))
                    .Where(x => x.Cells.Count >= 2)
                    .OrderByDescending(x => x.Cells.Count)
                    .ThenBy(x => x.Row)
                    .FirstOrDefault();
                if (best.Cells == null)
                {
                    return null;
                }

                var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (var cell in best.Cells)
                {
                    result[cell.Text] = $"{OpenXmlWorkbookInspector.ColumnName(cell.Column)}{best.Row + 1}";
                }

                return result;
            }

            public IEnumerable<LayoutCell> FindCode(string code, Section section)
            {
                List<LayoutCell> list;
                return _codes.TryGetValue(code, out list) ? list.Where(c => section.Contains(c.Row)) : new List<LayoutCell>();
            }

            public IEnumerable<LayoutCell> RowCodes(Section section)
            {
                if (_rowCodes == null) _rowCodes = _codes
                    .Where(kv => kv.Key.StartsWith('R') || kv.Key.StartsWith('r'))
                    .SelectMany(kv => kv.Value)
                    .OrderBy(c => c.Row)
                    .ToList();
                return _rowCodes.Where(c => section.Contains(c.Row));
            }

            /// <summary>
            /// Finds the section (table) for a leaf: the deepest container element whose name appears in column A.
            /// The section ends where the next section name of the same sheet starts.
            /// </summary>
            public Section FindSection(IReadOnlyList<string> containers, ISet<string> sectionNames)
            {
                if (_anchors == null) _anchors = Cells
                    .Where(c => c.Column == 1 && sectionNames.Contains(c.Text))
                    .ToList();
                var anchors = _anchors;
                // Most specific container first: .../MAIN_Y2/MAIN_Y2_Item/C0060 belongs to the MAIN_Y2 block.
                foreach (var container in containers.Reverse())
                {
                    var anchor = anchors.FirstOrDefault(c => string.Equals(c.Text, container, StringComparison.OrdinalIgnoreCase));
                    if (anchor == null)
                    {
                        continue;
                    }

                    var next = anchors.FirstOrDefault(c => c.Row > anchor.Row);
                    return new Section(anchor.Row, (next == null) ? int.MaxValue : next.Row - 1, container);
                }

                return Section.WholeSheet;
            }

            /// <summary>Returns the cell as an input target, refusing cells that hold a row/column code.</summary>
            public Resolution InputCell(int column, int row, string source)
            {
                if (column <= 0 || row <= 0)
                {
                    return Resolution.Fail("The computed cell is outside the worksheet.");
                }

                var address = $"{OpenXmlWorkbookInspector.ColumnName(column)}{row}";
                string text;
                if (_text.TryGetValue(new VT_Column_Row<int, int>(column, row), out text) && AnyCodeRegex().IsMatch(text))
                {
                    return Resolution.Fail($"The computed cell {Name}!{address} holds the code '{text}', not an input field.");
                }

                return new Resolution(address, source, null);
            }
        }

        private static readonly System.Text.RegularExpressions.Regex GridCodeRegexInstance = new System.Text.RegularExpressions.Regex(@"^(R\d{3,4})(C\d{3,4})$", RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Compiled);

        private static readonly System.Text.RegularExpressions.Regex ColumnCodeRegexInstance = new System.Text.RegularExpressions.Regex(@"^C\d{3,4}$", RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Compiled);

        private static readonly System.Text.RegularExpressions.Regex RowCodeRegexInstance = new System.Text.RegularExpressions.Regex(@"^R\d{3,4}$", RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Compiled);

        private static readonly System.Text.RegularExpressions.Regex AnyCodeRegexInstance = new System.Text.RegularExpressions.Regex(@"^[RC]\d{3,4}$", RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

    public sealed class MappingPlan : IRecord<MappingPlan>, IEquatable<MappingPlan>
    {
        public IReadOnlyList<MappingEntryDto> Mappings { get; set; }

        public IReadOnlyList<ValidationIssueDto> Notes { get; set; }

        public MappingPlan(IReadOnlyList<MappingEntryDto> Mappings, IReadOnlyList<ValidationIssueDto> Notes)
    {
    this.Mappings = Mappings;
    this.Notes = Notes;
    }

        public void Deconstruct(out IReadOnlyList<MappingEntryDto> Mappings, out IReadOnlyList<ValidationIssueDto> Notes)
    {
    Mappings = this.Mappings;
    Notes = this.Notes;
    }

        public bool Equals(MappingPlan other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.Equals(Mappings, other.Mappings)
    && EqualityComparer<IReadOnlyList<ValidationIssueDto>>.Default.Equals(Notes, other.Notes);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as MappingPlan);
    }

        public static bool operator ==(MappingPlan left, MappingPlan right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(MappingPlan left, MappingPlan right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 85338;
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.GetHashCode(Mappings);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<ValidationIssueDto>>.Default.GetHashCode(Notes);
    return hash;
    }
    }

        public override string ToString()
    {
    return "MappingPlan { " + "Mappings = " + Mappings + ", " + "Notes = " + Notes + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public MappingPlan CloneRecord()
    {
    return (MappingPlan)MemberwiseClone();
    }

    }

}
