using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// The Workbench's "View Logs", for the server: the API's log files, read by the people who may read the whole audit
    /// trail (audit.read-all). Values that look like secrets (passwords, keys, tokens, connection strings) are masked
    /// before a line leaves the server.
    /// </summary>
    public sealed class LogService : ILogService
    {
        public const int MaxLines = 5000;

        // name=value or name: value where the name says it is secret; the value is masked up to ; , & or whitespace.
        private static readonly Regex Secret = new Regex(
            @"(?i)\b(password|pwd|passphrase|secret|token|api[-_ ]?key|x-api-key|internal[-_ ]?key|access[-_ ]?key|authorization|user id|uid)(\s*[=:]\s*)(""[^""]*""|'[^']*'|[^;,&\s]+)",
            RegexOptions.Compiled);

        private static readonly Regex Bearer = new Regex(@"(?i)\b(bearer|basic)\s+[A-Za-z0-9\-._~+/]+=*", RegexOptions.Compiled);

        private readonly ILogFileStore files;
        private readonly ICurrentUser user;

        public LogService(ILogFileStore files, ICurrentUser user)
        {
            this.files = files;
            this.user = user;
        }

        private void Authorize()
        {
            if (!user.IsAuthenticated || !user.HasPermission(Permissions.AuditReadAll))
                throw new WorkflowException(WorkflowErrorKind.Forbidden, "Only the people who may read the whole audit trail can read the logs.");
        }

        public LogListDto List()
        {
            Authorize();
            return new LogListDto
            {
                Files = files.List().Select(f => new LogFileDto { Name = f.Name, Size = f.Size, LastWritten = f.LastWritten }).ToList()
            };
        }

        public LogContentDto Read(string name, int lines)
        {
            Authorize();
            lines = Math.Max(1, Math.Min(lines, MaxLines));
            using (var stream = files.Open(name))
            {
                if (stream == null) return null;
                var tail = new Queue<string>(lines);
                var content = new LogContentDto { Name = name };
                using (var reader = new StreamReader(stream, Encoding.UTF8))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (IsEntry(line, "Error") || IsEntry(line, "Critical")) content.Errors++;
                        else if (IsEntry(line, "Warning")) content.Warnings++;
                        if (tail.Count == lines)
                        {
                            tail.Dequeue();
                            content.Truncated = true;
                        }

                        tail.Enqueue(Mask(line));
                    }
                }

                content.Lines = tail.ToList();
                return content;
            }
        }

        public ToolDownload Download(string name)
        {
            Authorize();
            using (var stream = files.Open(name))
            {
                if (stream == null) return null;
                string text;
                using (var reader = new StreamReader(stream, Encoding.UTF8))
                {
                    text = reader.ReadToEnd();
                }

                var masked = string.Join("\n", text.Split('\n').Select(Mask));
                return new ToolDownload(new MemoryStream(new UTF8Encoding(false).GetBytes(masked), false), name, "text/plain");
            }
        }

        /// <summary>A log entry starts "yyyy-MM-dd HH:mm:ss.fff Level …".</summary>
        private static bool IsEntry(string line, string level)
        {
            return line.Length > 24 && line[4] == '-' && line.Substring(24).StartsWith(level, StringComparison.Ordinal);
        }

        public static string Mask(string line)
        {
            line = Bearer.Replace(line, m => m.Groups[1].Value + " ***");
            return Secret.Replace(line, m => m.Groups[1].Value + m.Groups[2].Value + "***");
        }
    }
}
