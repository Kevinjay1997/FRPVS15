﻿using System;
using System.Collections.Generic;
using System.Linq;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// The last few projects read, kept per version so the project page does not read a large project (FRP: about 50,000
    /// XSD fields and mappings) from SQL Server and work out its sample values again on every request. A project is found
    /// only under the version it was read at (its UpdatedAt, which every save of a project changes), so a changed project
    /// is always read again. Holds no access decisions: callers check the person's access first (ProjectAccess).
    /// </summary>
    public sealed class ProjectReadCache
    {
        /// <summary>How many projects are kept; an FRP project takes some tens of MB.</summary>
        public const int MaxProjects = 3;

        private static readonly TimeSpan KeepFor = TimeSpan.FromMinutes(20);

        private readonly object gate = new object();
        private readonly List<Entry> entries = new List<Entry>();

        /// <summary>The project as stored, when it was read at this version.</summary>
        public FrpProjectDto Stored(string projectId, DateTimeOffset version)
        {
            return Find(projectId, version)?.Stored;
        }

        /// <summary>The project as the project page shows it (with current sample values), when worked out at this version.</summary>
        public FrpProjectDto View(string projectId, DateTimeOffset version)
        {
            return Find(projectId, version)?.View;
        }

        public void KeepStored(FrpProjectDto project)
        {
            Keep(project).Stored = project;
        }

        public void KeepView(FrpProjectDto stored, FrpProjectDto view)
        {
            var entry = Keep(stored);
            entry.Stored = stored;
            entry.View = view;
        }

        private Entry Find(string projectId, DateTimeOffset version)
        {
            lock (gate)
            {
                Expire();
                var entry = entries.FirstOrDefault(e => e.ProjectId == projectId && e.Version == version);
                if (entry != null)
                {
                    entry.LastUsed = DateTime.UtcNow;
                }

                return entry;
            }
        }

        private Entry Keep(FrpProjectDto project)
        {
            lock (gate)
            {
                Expire();
                // An older version of the same project is never needed again.
                entries.RemoveAll(e => e.ProjectId == project.Id && e.Version != project.UpdatedAt);
                var entry = entries.FirstOrDefault(e => e.ProjectId == project.Id);
                if (entry == null)
                {
                    entry = new Entry { ProjectId = project.Id, Version = project.UpdatedAt };
                    entries.Add(entry);
                    while (entries.Count > MaxProjects)
                    {
                        entries.Remove(entries.OrderBy(e => e.LastUsed).First());
                    }
                }

                entry.LastUsed = DateTime.UtcNow;
                return entry;
            }
        }

        private void Expire()
        {
            var cutoff = DateTime.UtcNow - KeepFor;
            entries.RemoveAll(e => e.LastUsed < cutoff);
        }

        private sealed class Entry
        {
            public string ProjectId { get; set; }
            public DateTimeOffset Version { get; set; }
            public FrpProjectDto Stored { get; set; }
            public FrpProjectDto View { get; set; }
            public DateTime LastUsed { get; set; }
        }
    }
}
