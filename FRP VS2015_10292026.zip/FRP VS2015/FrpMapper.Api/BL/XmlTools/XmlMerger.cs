using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace FrpMapper.Api.BL.XmlTools
{
    /// <summary>
    /// The Workbench's "Merge Elements From an Existing XML" (MyElements.MergeXml), kept as it behaved so a file merged
    /// here is the file the Workbench made:
    /// <list type="bullet">
    /// <item>every top-level element listed in merge.csv as From is merged into its To element: the first one becomes the
    /// To element, the rows (_Item) of later ones are added to its tables of _Item rows;</item>
    /// <item>an element listed in cleanup.csv is left out when it has no content (only self-closing elements), a merged
    /// From element stops at its first sub-element without content, and "_EWB_RECURSIVE_ELEMENT_" is removed from its
    /// element names;</item>
    /// <item>with a reporting period, only the Header and the reports reportperiod.csv gives that period are kept.</item>
    /// </list>
    /// "Without content" means what it meant in the Workbench: every innermost element is self-closing (&lt;a/&gt;).
    /// </summary>
    public sealed class XmlMerger
    {
        private const string RecursiveSuffix = "_EWB_RECURSIVE_ELEMENT_";

        private readonly XmlToolsConfiguration configuration;

        public XmlMerger(XmlToolsConfiguration configuration)
        {
            this.configuration = configuration;
        }

        /// <summary>An element of the merged file and its name; one object may be listed twice, as in the Workbench.</summary>
        private sealed class Entry
        {
            public string Name;
            public XElement Members;
        }

        /// <param name="reportPeriod">Empty for none, else one of <see cref="XmlToolsConfiguration.Periods"/>.</param>
        public XDocument Merge(XDocument input, string reportPeriod, Shared.Models.XmlMergeResultDto result)
        {
            var output = new XDocument { Declaration = new XDeclaration("1.0", "utf-8", "yes") };
            var export = new XElement(input.Root.Name);
            var source = new XElement(input.Root);
            source.Name = source.Name.LocalName;

            var entries = new List<Entry>();
            foreach (var element in source.Elements())
            {
                var entry = new Entry();
                var mergeTo = MergeTarget(element.Name.LocalName);
                if (mergeTo == null)
                {
                    entry.Name = element.Name.LocalName;
                    entry.Members = element;
                    entries.Add(entry);
                    continue;
                }

                result.Merged.Add(element.Name.LocalName + " → " + mergeTo);
                var rows = LastRows(element);
                foreach (var part in element.Elements())
                {
                    if (IsCleaned(mergeTo) && !HasContent(part))
                    {
                        break;
                    }

                    // As in the Workbench: an existing target is found only after the first position (index > 0). A row
                    // (_Item) is added itself; the Workbench added the element's last row once per row, which lost the
                    // rows in between and repeated the last one.
                    var index = entries.FindIndex(e => string.Equals(e.Name, mergeTo, StringComparison.OrdinalIgnoreCase));
                    if (index > 0)
                    {
                        entries[index].Members = AddToFirstTable(entries[index].Members, IsItem(part) ? new XElement(part) : rows);
                    }
                    else
                    {
                        entry.Name = mergeTo;
                        entry.Members = new XElement(element.Name.Namespace + mergeTo, new XAttribute("xmlns", element.Name.Namespace), new XElement(part));
                        entries.Add(entry);
                    }
                }
            }

            HashSet<string> inPeriod = null;
            if (!string.IsNullOrEmpty(reportPeriod))
            {
                inPeriod = new HashSet<string>(configuration.ReportsByPeriod[reportPeriod], StringComparer.OrdinalIgnoreCase);
            }

            foreach (var entry in entries)
            {
                var name = entry.Members.Name.LocalName;
                if (IsCleaned(name) && !HasContent(entry.Members))
                {
                    result.RemovedEmpty.Add(name);
                    continue;
                }

                if (inPeriod != null && !inPeriod.Contains(name) && !string.Equals(name, "HEADER", StringComparison.OrdinalIgnoreCase))
                {
                    result.OutsidePeriod.Add(name);
                    continue;
                }

                if (IsCleaned(name))
                {
                    entry.Members = WithoutRecursiveSuffix(entry.Members);
                }

                export.Add(entry.Members);
                result.Elements.Add(entry.Members.Name.LocalName);
            }

            output.Add(export);
            output.Descendants().Attributes().Where(a => a.IsNamespaceDeclaration).Remove();
            return output;
        }

        private string MergeTarget(string name)
        {
            foreach (var pair in configuration.Merge)
            {
                if (string.Equals(pair.Key, name, StringComparison.OrdinalIgnoreCase))
                {
                    return pair.Value;
                }
            }

            return null;
        }

        private bool IsCleaned(string name)
        {
            return configuration.Cleanup.Any(c => string.Equals(c, name, StringComparison.OrdinalIgnoreCase));
        }

        private static bool IsItem(XElement element)
        {
            return element.Name.LocalName.ToUpperInvariant().EndsWith("_ITEM", StringComparison.Ordinal);
        }

        /// <summary>
        /// The rows a merged element brings (ElementHierarchy): going down its last children that are not _Item rows, the
        /// last _Item element reached (or the element itself when none is).
        /// </summary>
        private static XElement LastRows(XElement element)
        {
            var found = new XElement(element);
            foreach (var child in element.Elements())
            {
                if (child.HasElements)
                {
                    found = IsItem(child) ? new XElement(child) : new XElement(LastItem(child));
                }
            }

            return found;
        }

        private static XElement LastItem(XElement element)
        {
            var found = new XElement(element);
            foreach (var child in element.Elements())
            {
                found = IsItem(child) ? new XElement(child) : new XElement(LastItem(child));
            }

            return found;
        }

        /// <summary>True when one innermost element is not self-closing (the Workbench's EmptyElement).</summary>
        private static bool HasContent(XElement element)
        {
            if (!element.HasElements)
            {
                return !element.IsEmpty;
            }

            var content = false;
            foreach (var child in element.Elements())
            {
                if (content)
                {
                    break;
                }

                content = HasContent(child);
            }

            return content;
        }

        /// <summary>
        /// Adds the rows to every table under the element: an element whose first child is an _Item row (MergeItemNode).
        /// Going down, an element without children before a table is reached means there is nowhere to add them.
        /// </summary>
        private static XElement AddToFirstTable(XElement into, XElement rows)
        {
            var first = into.Elements().FirstOrDefault();
            if (first == null)
            {
                throw new XmlToolsException("The element " + into.Name.LocalName + " has no rows to add the merged rows to.");
            }

            if (IsItem(first))
            {
                into.Add(rows);
            }
            else
            {
                foreach (var child in into.Elements().ToList())
                {
                    AddToFirstTable(child, rows);
                }
            }

            return into;
        }

        /// <summary>
        /// Removes "_EWB_RECURSIVE_ELEMENT_" (and what follows) from element names (NodeNameClean). Elements are rebuilt
        /// from their child elements, so attributes are not kept, as in the Workbench.
        /// </summary>
        private static XElement WithoutRecursiveSuffix(XElement element)
        {
            var name = element.Name.LocalName;
            var at = name.ToUpperInvariant().IndexOf(RecursiveSuffix, StringComparison.Ordinal);
            if (at >= 0)
            {
                var renamed = new XElement(element.Name.Namespace + name.Substring(0, at), new XAttribute("xmlns", element.Name.Namespace));
                foreach (var child in element.Elements())
                {
                    renamed.Add(child);
                }

                return new XElement(renamed);
            }

            var copy = new XElement(element.Name);
            foreach (var child in element.Elements())
            {
                copy.Add(child.HasElements ? WithoutRecursiveSuffix(child) : child);
            }

            return copy;
        }
    }

    /// <summary>A file the XML tools cannot process, with the reason for the person.</summary>
    public sealed class XmlToolsException : Exception
    {
        public XmlToolsException(string message) : base(message)
        {
        }
    }
}
