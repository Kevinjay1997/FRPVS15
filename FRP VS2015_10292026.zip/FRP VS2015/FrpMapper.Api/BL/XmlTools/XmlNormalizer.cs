using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Xml.Schema;

namespace FrpMapper.Api.BL.XmlTools
{
    /// <summary>
    /// The Workbench's FRP XML normalizer (NormalizerMain.NormalizeFrpXml), run after a merge when an XSD is given. From
    /// the XSD it learns which elements are tables (their content has *_Item rows) and which children each element
    /// requires (minOccurs ≥ 1), then:
    /// <list type="number">
    /// <item>removes _Item rows whose values are all zero or empty, or with an empty code (an element whose name starts
    /// with C), unless the row is one to keep and has a value;</item>
    /// <item>removes _Item rows none of whose required tables has a row;</item>
    /// <item>removes tables left without rows (only tables that had rows in the file), repeatedly;</item>
    /// <item>removes elements (not tables, not rows) missing a required child with a value.</item>
    /// </list>
    /// Each removal is written to the log, as in the Workbench.
    /// </summary>
    public sealed class XmlNormalizer
    {
        private readonly HashSet<string> tables;
        private readonly Dictionary<string, string[]> requiredChildren;
        private readonly HashSet<string> keptItems;

        public XmlNormalizer(XmlSchemaSet schemas, IEnumerable<string> keptItems)
        {
            tables = ExtractTables(schemas);
            requiredChildren = ExtractRequiredChildren(schemas);
            this.keptItems = new HashSet<string>(keptItems, StringComparer.OrdinalIgnoreCase);
        }

        public int ItemsRemoved { get; private set; }

        public int SectionsRemoved { get; private set; }

        public void Normalize(XDocument document, List<string> log)
        {
            log.Add("Loaded " + tables.Count + " table containers from XSD");
            log.Add("Loaded " + requiredChildren.Count + " RequiredChildren rules from XSD");
            log.Add("Loaded " + keptItems.Count + " NonRemovableItems from config");

            // 1. _Item rows with all values zero or an empty code.
            foreach (var item in document.Descendants().Where(IsItem).ToList())
            {
                if (keptItems.Contains(item.Name.LocalName) && item.Elements().Any(e => !string.IsNullOrWhiteSpace(e.Value)))
                {
                    continue;
                }

                if (item.Elements().All(IsZeroValue) || item.Elements().Any(IsEmptyCode))
                {
                    log.Add("REMOVED _Item (invalid data): " + PathOf(item));
                    item.Remove();
                    ItemsRemoved++;
                }
            }

            // 1.5 _Item rows none of whose required tables has a row.
            foreach (var item in document.Descendants().Where(IsItem).ToList())
            {
                if (keptItems.Contains(item.Name.LocalName) && item.Elements().Any(e => !string.IsNullOrWhiteSpace(e.Value)))
                {
                    continue;
                }

                string[] required;
                if (!requiredChildren.TryGetValue(item.Name.LocalName, out required))
                {
                    continue;
                }

                var requiredTables = required.Where(tables.Contains).ToList();
                if (requiredTables.Count == 0)
                {
                    continue;
                }

                var hasRows = requiredTables.Any(name =>
                {
                    var table = item.Elements().FirstOrDefault(e => e.Name.LocalName == name);
                    return table != null && table.Elements().Any(IsItem);
                });
                if (!hasRows)
                {
                    log.Add("REMOVED _Item (no data in required sub‑tables): " + PathOf(item));
                    item.Remove();
                    ItemsRemoved++;
                }
            }

            // 2. Tables left without rows (only tables that had rows in the file), until none is left.
            var tablesWithRows = new HashSet<string>(document.Descendants().Where(e => e.Elements().Any(IsItem)).Select(e => e.Name.LocalName));
            bool removed;
            do
            {
                removed = false;
                var empty = document.Descendants()
                    .Where(e => tables.Contains(e.Name.LocalName) && tablesWithRows.Contains(e.Name.LocalName) && !e.Elements().Any(IsItem))
                    .ToList();
                foreach (var table in empty)
                {
                    log.Add("REMOVED EMPTY ITEM‑CONTAINER: " + PathOf(table));
                    table.Remove();
                    SectionsRemoved++;
                    removed = true;
                }
            }
            while (removed);

            // 3. Elements (not tables, not rows) missing a required child with a value.
            foreach (var rule in requiredChildren)
            {
                foreach (var parent in document.Descendants().Where(e => e.Name.LocalName == rule.Key).ToList())
                {
                    if (tables.Contains(parent.Name.LocalName) || IsItem(parent))
                    {
                        continue;
                    }

                    var missing = rule.Value.Any(name => !tables.Contains(name)
                        && !parent.Elements().Any(c => c.Name.LocalName == name && !string.IsNullOrWhiteSpace(c.Value)));
                    if (missing)
                    {
                        log.Add("REMOVED " + rule.Key + " (missing required child)");
                        parent.Remove();
                        SectionsRemoved++;
                    }
                }
            }
        }

        private static bool IsItem(XElement element) => element.Name.LocalName.EndsWith("_Item", StringComparison.Ordinal);

        private static bool IsZeroValue(XElement element)
        {
            var value = (element.Value ?? "").Trim();
            return value == "" || value == "0" || value == "0.0" || value == "0.00";
        }

        /// <summary>FRP's coded fields are named Cxxxx; an empty one makes the row invalid.</summary>
        private static bool IsEmptyCode(XElement element)
        {
            return element.Name.LocalName.StartsWith("C", StringComparison.Ordinal) && string.IsNullOrEmpty(element.Value.Trim());
        }

        private static string PathOf(XElement element)
        {
            return string.Join("/", element.AncestorsAndSelf().Reverse().Select(e => e.Name.LocalName));
        }

        // ---------- rules from the XSD (TableRuleExtractor, RequiredChildrenExtractor, RequiredChildrenFilter) ----------

        /// <summary>The elements whose content has an *_Item element: the tables.</summary>
        private static HashSet<string> ExtractTables(XmlSchemaSet schemas)
        {
            var found = new HashSet<string>();
            foreach (XmlSchema schema in schemas.Schemas())
            {
                foreach (var item in schema.Items.OfType<XmlSchemaElement>())
                {
                    var type = item.ElementSchemaType as XmlSchemaComplexType;
                    if (type != null)
                    {
                        ScanForTables(type.ContentTypeParticle, found);
                    }
                }
            }

            return found;
        }

        private static void ScanForTables(XmlSchemaParticle particle, HashSet<string> found)
        {
            var element = particle as XmlSchemaElement;
            if (element != null)
            {
                var type = element.ElementSchemaType as XmlSchemaComplexType;
                if (type != null)
                {
                    if (type.ContentTypeParticle != null && HasItemElement(type.ContentTypeParticle) && !string.IsNullOrEmpty(element.Name))
                    {
                        found.Add(element.Name);
                    }

                    ScanForTables(type.ContentTypeParticle, found);
                }

                return;
            }

            var group = particle as XmlSchemaGroupBase;
            if (group != null)
            {
                foreach (var child in group.Items.OfType<XmlSchemaParticle>())
                {
                    ScanForTables(child, found);
                }
            }
        }

        private static bool HasItemElement(XmlSchemaParticle particle)
        {
            var element = particle as XmlSchemaElement;
            if (element != null)
            {
                return element.Name != null && element.Name.EndsWith("_Item", StringComparison.Ordinal);
            }

            var group = particle as XmlSchemaGroupBase;
            return group != null && group.Items.OfType<XmlSchemaParticle>().Any(HasItemElement);
        }

        /// <summary>
        /// Element name → its required children, from the global elements down through their sequences. The root FRP
        /// element, and elements whose only required child is an _Item row, have no rule.
        /// </summary>
        private static Dictionary<string, string[]> ExtractRequiredChildren(XmlSchemaSet schemas)
        {
            var complexTypes = new Dictionary<string, XmlSchemaComplexType>();
            foreach (XmlSchema schema in schemas.Schemas())
            {
                foreach (var type in schema.Items.OfType<XmlSchemaComplexType>().Where(t => !string.IsNullOrEmpty(t.Name)))
                {
                    complexTypes[type.Name] = type;
                }
            }

            var rules = new Dictionary<string, List<string>>();
            foreach (XmlSchema schema in schemas.Schemas())
            {
                foreach (var element in schema.Items.OfType<XmlSchemaElement>())
                {
                    ExtractRequired(element, complexTypes, rules);
                }
            }

            return rules
                .Where(r => !r.Key.Equals("FRP", StringComparison.OrdinalIgnoreCase)
                    && !(r.Value.Count == 1 && r.Value[0].EndsWith("_Item", StringComparison.OrdinalIgnoreCase)))
                .ToDictionary(r => r.Key, r => r.Value.ToArray());
        }

        private static void ExtractRequired(XmlSchemaElement element, Dictionary<string, XmlSchemaComplexType> complexTypes, Dictionary<string, List<string>> rules)
        {
            var type = element.SchemaType as XmlSchemaComplexType;
            if (type == null && !element.SchemaTypeName.IsEmpty)
            {
                complexTypes.TryGetValue(element.SchemaTypeName.Name, out type);
            }

            if (type == null)
            {
                return;
            }

            var group = type.ContentTypeParticle as XmlSchemaGroupBase;
            var required = group == null ? new List<string>()
                : group.Items.OfType<XmlSchemaElement>().Where(c => c.MinOccurs >= 1).Select(c => c.Name).Distinct().ToList();
            if (required.Count > 0)
            {
                rules[element.Name] = required;
            }

            if (group == null)
            {
                return;
            }

            foreach (var child in group.Items.OfType<XmlSchemaElement>())
            {
                ExtractRequired(child, complexTypes, rules);
            }
        }
    }
}
