using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using FrpMapper.Api.BL.Cocree;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL.XmlTools
{
    /// <summary>
    /// The XML tools' configuration in the shape the merge uses, built from the Workbench's Config files:
    /// <list type="bullet">
    /// <item>merge.csv (From,To): an element From is merged into the element To (e.g. FRP_9A2 → FRP_9A234);</item>
    /// <item>cleanup.csv (Clean): elements whose empty rows are left out and whose "_EWB_RECURSIVE_ELEMENT_" suffix is removed;</item>
    /// <item>reportperiod.csv (Report, Daily, Weekly, Monthly, Quarterly, Midyear, Yearly, Remarks): "1" when the period has the report;</item>
    /// <item>the _Item rows the normalizer keeps when they have a value (the Workbench's FRP.NonRemovableItems setting).</item>
    /// </list>
    /// Element names are compared without regard to case, as the Workbench did. The files are read as the Workbench read
    /// them: one value per comma, no quoting.
    /// </summary>
    public sealed class XmlToolsConfiguration
    {
        public static readonly IReadOnlyList<string> Periods = new[] { "Daily", "Weekly", "Monthly", "Quarterly", "Midyear", "Yearly" };

        private XmlToolsConfiguration()
        {
        }

        /// <summary>From (as written) → To, the first row for a From counting.</summary>
        public IReadOnlyList<KeyValuePair<string, string>> Merge { get; private set; }

        public IReadOnlyList<string> Cleanup { get; private set; }

        /// <summary>Period → the reports it has.</summary>
        public IReadOnlyDictionary<string, IReadOnlyList<string>> ReportsByPeriod { get; private set; }

        public IReadOnlyList<string> NonRemovableItems { get; private set; }

        // ---------- the uploaded files ----------

        /// <summary>The configuration as uploaded: the three CSV files as tables, and the normalizer's kept rows.</summary>
        public static XmlToolsConfigDto FromFiles(byte[] mergeCsv, byte[] cleanupCsv, byte[] reportPeriodCsv, string nonRemovableItems)
        {
            return new XmlToolsConfigDto
            {
                Merge = ReadCsv("merge", mergeCsv),
                Cleanup = ReadCsv("cleanup", cleanupCsv),
                ReportPeriods = ReadCsv("reportperiod", reportPeriodCsv),
                NonRemovableItems = (nonRemovableItems ?? "").Split(new[] { ',', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(i => i.Trim()).Where(i => i.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList()
            };
        }

        /// <summary>A CSV file as the Workbench read it: row 1 the column names, every other non-blank line one row.</summary>
        private static WorkbenchTableDto ReadCsv(string name, byte[] content)
        {
            string text;
            using (var reader = new StreamReader(new MemoryStream(content, false), Encoding.UTF8, true))
            {
                text = reader.ReadToEnd();
            }

            var lines = text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None).Where(l => l.Trim().Length > 0).ToList();
            var table = new WorkbenchTableDto { Name = name };
            if (lines.Count == 0)
            {
                return table;
            }

            table.Columns = lines[0].Split(',').Select(c => c.Trim()).ToList();
            table.Rows = lines.Skip(1).Select(l => l.Split(',').Select(c => c.Trim()).ToList()).ToList();
            return table;
        }

        /// <summary>Back to the CSV file the Workbench kept (to download, check or edit).</summary>
        public static byte[] ToCsv(WorkbenchTableDto table)
        {
            var text = new StringBuilder();
            text.Append(string.Join(",", table.Columns)).Append("\r\n");
            foreach (var row in table.Rows)
            {
                text.Append(string.Join(",", row)).Append("\r\n");
            }

            return new UTF8Encoding(false).GetBytes(text.ToString());
        }

        // ---------- checking ----------

        /// <summary>Reads a stored configuration; null with <paramref name="problems"/> when it cannot be used.</summary>
        public static XmlToolsConfiguration Load(XmlToolsConfigDto content, List<string> problems)
        {
            var configuration = new XmlToolsConfiguration();

            var merge = Columns(content.Merge, "merge.csv", problems, "From", "To");
            var pairs = new List<KeyValuePair<string, string>>();
            if (merge != null)
            {
                foreach (var row in content.Merge.Rows)
                {
                    var from = Cell(row, merge["From"]);
                    var to = Cell(row, merge["To"]);
                    if (from.Length == 0 || to.Length == 0)
                    {
                        problems.Add("merge.csv: the row \"" + string.Join(",", row) + "\" needs a From and a To.");
                    }
                    else if (!IsXmlName(to))
                    {
                        problems.Add("merge.csv: " + to + " cannot be an XML element name.");
                    }
                    else
                    {
                        pairs.Add(new KeyValuePair<string, string>(from, to));
                    }
                }
            }

            var cleanup = Columns(content.Cleanup, "cleanup.csv", problems, "Clean");
            var clean = cleanup == null ? new List<string>()
                : content.Cleanup.Rows.Select(r => Cell(r, cleanup["Clean"])).Where(c => c.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

            var periods = Columns(content.ReportPeriods, "reportperiod.csv", problems, new[] { "Report" }.Concat(Periods).ToArray());
            var byPeriod = new Dictionary<string, IReadOnlyList<string>>(StringComparer.OrdinalIgnoreCase);
            if (periods != null)
            {
                foreach (var period in Periods)
                {
                    byPeriod[period] = content.ReportPeriods.Rows.Where(r => Cell(r, periods[period]) == "1").Select(r => Cell(r, periods["Report"]))
                        .Where(r => r.Length > 0).ToList();
                }
            }

            if (problems.Count > 0)
            {
                return null;
            }

            configuration.Merge = pairs;
            configuration.Cleanup = clean;
            configuration.ReportsByPeriod = byPeriod;
            configuration.NonRemovableItems = content.NonRemovableItems ?? new List<string>();
            return configuration;
        }

        public WorkbenchConfigSummaryDto Summary()
        {
            return new WorkbenchConfigSummaryDto
            {
                Facts = new List<WorkbenchConfigFactDto>
                {
                    new WorkbenchConfigFactDto { Label = "merge rules", Count = Merge.Count },
                    new WorkbenchConfigFactDto { Label = "elements cleaned", Count = Cleanup.Count },
                    new WorkbenchConfigFactDto { Label = "reports with periods", Count = ReportsByPeriod.Values.SelectMany(r => r).Distinct(StringComparer.OrdinalIgnoreCase).Count() },
                    new WorkbenchConfigFactDto { Label = "kept _Item rows", Count = NonRemovableItems.Count }
                }
            };
        }

        /// <summary>One line per file that differs between two configurations.</summary>
        public static List<string> Differences(XmlToolsConfigDto before, XmlToolsConfigDto after)
        {
            var lines = new List<string>();
            CocreeConfiguration.Compare("", new List<WorkbenchTableDto> { before.Merge, before.Cleanup, before.ReportPeriods },
                new List<WorkbenchTableDto> { after.Merge, after.Cleanup, after.ReportPeriods }, lines);
            var kept = string.Join(",", before.NonRemovableItems ?? new List<string>());
            var now = string.Join(",", after.NonRemovableItems ?? new List<string>());
            if (!string.Equals(kept, now, StringComparison.OrdinalIgnoreCase))
            {
                lines.Add("kept _Item rows: " + (kept.Length == 0 ? "none" : kept) + " → " + (now.Length == 0 ? "none" : now) + ".");
            }

            return lines;
        }

        private static Dictionary<string, int> Columns(WorkbenchTableDto table, string file, List<string> problems, params string[] required)
        {
            if (table == null || table.Columns.Count == 0)
            {
                problems.Add(file + " is empty.");
                return null;
            }

            var index = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < table.Columns.Count; i++)
            {
                if (!index.ContainsKey(table.Columns[i]))
                {
                    index[table.Columns[i]] = i;
                }
            }

            var missing = required.Where(c => !index.ContainsKey(c)).ToList();
            if (missing.Count > 0)
            {
                problems.Add(file + " has no column " + string.Join(", ", missing) + " in its first row.");
                return null;
            }

            return index;
        }

        private static string Cell(List<string> row, int index)
        {
            return index < row.Count ? (row[index] ?? "").Trim() : "";
        }

        private static bool IsXmlName(string name)
        {
            try
            {
                System.Xml.XmlConvert.VerifyNCName(name);
                return true;
            }
            catch (System.Xml.XmlException)
            {
                return false;
            }
        }
    }
}
