﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    public sealed class FrpMappingService: IFrpMappingService, IValidationXmlSource
    {
        private readonly IProjectRepository repository;
        private readonly ProjectAccess access;
        private readonly BankReferenceContext reference;
        private readonly XsdSchemaParser xsdParser;
        private readonly OpenXmlWorkbookInspector workbookInspector;
        private readonly MappingSuggestionEngine suggestionEngine;
        private readonly XmlSubmissionWriter xmlWriter;
        private readonly OpenXmlMappedTemplateWriter templateWriter;
        private readonly XsdValidationService validationService;
        private readonly XsdProjectValidator projectValidator;
        private readonly BspSpecificationReader specificationReader;
        private readonly BspSpecificationValidator specificationValidator;
        private readonly TemplateCoverageChecker coverageChecker;
        private readonly XsdInputTemplateGenerator templateGenerator;
        private readonly BspSampleValueSolver sampleValueSolver;
        private readonly SampleValueRefill sampleValueRefill;
        private readonly ICurrentUser currentUser;
        private readonly IAuditLog auditLog;
        private readonly IProjectFileStore fileStore;
        private readonly UploadRules uploadRules;
        private readonly FilledTemplateReader filledTemplateReader;
        private readonly TemplateAccountCodeReader accountCodeReader;
        private readonly ILogger<FrpMappingService> logger;
        private readonly ProjectReadCache readCache;

        public FrpMappingService(IProjectRepository repository, ProjectAccess access, BankReferenceContext reference, XsdSchemaParser xsdParser, OpenXmlWorkbookInspector workbookInspector, MappingSuggestionEngine suggestionEngine, XmlSubmissionWriter xmlWriter, OpenXmlMappedTemplateWriter templateWriter, XsdValidationService validationService, XsdProjectValidator projectValidator, BspSpecificationReader specificationReader, BspSpecificationValidator specificationValidator, TemplateCoverageChecker coverageChecker, XsdInputTemplateGenerator templateGenerator, BspSampleValueSolver sampleValueSolver, SampleValueRefill sampleValueRefill, ICurrentUser currentUser, IAuditLog auditLog, IProjectFileStore fileStore, UploadRules uploadRules, FilledTemplateReader filledTemplateReader, TemplateAccountCodeReader accountCodeReader, ILogger<FrpMappingService> logger, ProjectReadCache readCache)
    {
        this.repository = repository;
        this.access = access;
        this.reference = reference;
        this.xsdParser = xsdParser;
        this.workbookInspector = workbookInspector;
        this.suggestionEngine = suggestionEngine;
        this.xmlWriter = xmlWriter;
        this.templateWriter = templateWriter;
        this.validationService = validationService;
        this.projectValidator = projectValidator;
        this.specificationReader = specificationReader;
        this.specificationValidator = specificationValidator;
        this.coverageChecker = coverageChecker;
        this.templateGenerator = templateGenerator;
        this.sampleValueSolver = sampleValueSolver;
        this.sampleValueRefill = sampleValueRefill;
        this.currentUser = currentUser;
        this.auditLog = auditLog;
        this.fileStore = fileStore;
        this.uploadRules = uploadRules;
        this.filledTemplateReader = filledTemplateReader;
        this.accountCodeReader = accountCodeReader;
        this.logger = logger;
        this.readCache = readCache;
    }
        /// <summary>Longest project name (frp.Project.Name).</summary>
        public const int MaxProjectNameLength = 200;
        private const int MaxSheetNameLength = 128;
        private const int MaxCellAddressLength = 64;
        private const int MaxSourceLength = 100;
        private const int MaxMappingIdLength = 64;

        public async Task<ReusableProjectFilesDto> GetReusableFilesAsync(string projectId, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectCreate, "create a project");
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectRead, "read projects");
            var uploads = await access.GetUploadsAsync(projectId, cancellationToken);
            return (uploads == null)
                ? null
                : new ReusableProjectFilesDto
                {
                    ProjectId = uploads.ProjectId,
                    ProjectName = uploads.ProjectName,
                    Xsd = ToReusable(uploads.Xsd),
                    Template = ToReusable(uploads.Template),
                    Specification = ToReusable(uploads.Specification)
                };
        }

        public async Task<FrpProjectDto> AnalyzeAsync(string projectName, IFormFile xsdFile, IFormFile templateFile, IFormFile specificationFile, ProjectFileReuse reuse, CancellationToken cancellationToken,
            IProgress<ValidationProgressDto> progress = null)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectCreate, "create a project");
            if (reuse == null || !reuse.Any)
            {
                return (xsdFile == null)
                    ? CompatThrow.As<FrpProjectDto>(new WorkflowException(WorkflowErrorKind.Invalid, "Upload a BSP XSD file first."))
                    : await CreateAsync(projectName, xsdFile, templateFile, specificationFile, null, cancellationToken, progress);
            }

            // Files of an existing project the user can read are taken as if uploaded again; the file store then finds
            // them already stored (by SHA-256), so nothing is copied.
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectRead, "read projects");
            var source = await access.GetUploadsAsync(reuse.SourceProjectId, cancellationToken)
                         ?? CompatThrow.As<ProjectUploads>(new WorkflowException(WorkflowErrorKind.Invalid, "The project to reuse files from was not found."));
            var opened = new List<Stream>();
            try
            {
                new ValidationStep(progress, 0, 2, "Checking the files taken from " + source.ProjectName).Start();
                var xsd = await PickAsync(reuse.Xsd, xsdFile, source.Xsd, "XSD", source, opened, cancellationToken);
                var template = await PickAsync(reuse.Template, templateFile, source.Template, "BSP Excel input template", source, opened, cancellationToken);
                var specification = await PickAsync(reuse.Specification, specificationFile, source.Specification, "BSP specification", source, opened, cancellationToken);
                if (xsd == null)
                {
                    throw new WorkflowException(WorkflowErrorKind.Invalid, "Upload a BSP XSD file first.");
                }

                var reusedNames = new[] { new VT_Item1_Item2<bool, string>(reuse.Xsd, "XSD"), new VT_Item1_Item2<bool, string>(reuse.Template, "template"), new VT_Item1_Item2<bool, string>(reuse.Specification, "specification") }
                    .Where(r => r.Item1).Select(r => r.Item2);
                var note = $" Files taken from project {source.ProjectName} ({source.ProjectId}): {string.Join(", ", reusedNames)}.";
                return await CreateAsync(projectName, xsd, template, specification, note, cancellationToken, progress);
            }
            finally
            {
                foreach (var stream in opened)
                {
                    stream.Dispose();
                }
            }
        }

        /// <summary>
        /// The upload for one slot: the new upload, or (when <paramref name="reuse"/> is set) the source project's stored
        /// file, after checking it still has the SHA-256 recorded when it was uploaded.
        /// </summary>
        private static async Task<IFormFile> PickAsync(bool reuse, IFormFile upload, UploadedFileDto stored, string description,
            ProjectUploads source, List<Stream> opened, CancellationToken cancellationToken)
        {
            if (!reuse)
            {
                return upload;
            }

            if (upload != null)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"Send either a new {description} or reuse the stored one, not both.");
            }

            if (stored == null)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"Project {source.ProjectName} has no uploaded {description} to reuse.");
            }

            FileStream stream;
            try
            {
                stream = new FileStream(stored.StoredPath, FileMode.Open, FileAccess.Read, FileShare.Read, 81920, useAsync: true);
            }
            catch (Exception ex) when ((ex is FileNotFoundException || ex is DirectoryNotFoundException))
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, $"The stored {description} of project {source.ProjectName} is missing. Upload it again.");
            }

            opened.Add(stream);
            if (stored.Sha256 != null)
            {
                var actual = CompatHex.ToHexString(await CompatHash.Sha256Async(stream, cancellationToken)).ToLowerInvariant();
                if (actual != stored.Sha256)
                {
                    throw new WorkflowException(WorkflowErrorKind.Conflict,
                        $"The stored {description} of project {source.ProjectName} changed after it was uploaded, so it is not reused. Upload it again.");
                }

                stream.Position = 0;
            }

            return new FormFile(stream, 0, stream.Length, "reused", stored.OriginalName);
        }

        /// <remarks>
        /// Progress (optional) runs 0-100 %: storing and reading the XSD 2-8, the Excel template 8-24, the specification
        /// 24-34, sample values 34-68, mapping 68-74, checking the project 74-97, saving 97-100.
        /// </remarks>
        private async Task<FrpProjectDto> CreateAsync(string projectName, IFormFile xsdFile, IFormFile templateFile, IFormFile specificationFile, string sourceNote, CancellationToken cancellationToken,
            IProgress<ValidationProgressDto> progress = null)
        {
            if (xsdFile.Length == 0)
            {
                throw new InvalidOperationException("Upload a BSP XSD file first.");
            }

            uploadRules.Require(xsdFile, UploadKinds.Xsd, "XSD");
            if (templateFile != null && templateFile.Length > 0)
            {
                uploadRules.Require(templateFile, UploadKinds.Template, "Excel template");
            }

            if (specificationFile != null && specificationFile.Length > 0)
            {
                uploadRules.Require(specificationFile, UploadKinds.Specification, "BSP specification");
            }

            var requestedName = string.IsNullOrWhiteSpace(projectName) ? Path.GetFileNameWithoutExtension(xsdFile.FileName) : projectName.Trim();
            if (requestedName.Length > MaxProjectNameLength)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"The project name is longer than {MaxProjectNameLength} characters.");
            }

            var projectId = Guid.NewGuid().ToString("N");
            var now = DateTimeOffset.UtcNow;
            var timer = System.Diagnostics.Stopwatch.StartNew();
            var phases = new List<string>();
            Action<string> Phase = null;
            Phase = (string name) =>
            {
                phases.Add($"{name} {timer.ElapsedMilliseconds} ms");
                timer.Restart();
            };

            // Uploads are stored once by content: an identical file uploaded before is reused, not stored again.
            new ValidationStep(progress, 1, 2, "Checking for a project with the same files").Start();
            var xsdStored = await fileStore.StoreUploadAsync(xsdFile, cancellationToken);
            StoredUpload templateStored = (templateFile != null && templateFile.Length > 0) ? await fileStore.StoreUploadAsync(templateFile, cancellationToken) : null;
            StoredUpload specificationStored = (specificationFile != null && specificationFile.Length > 0) ? await fileStore.StoreUploadAsync(specificationFile, cancellationToken) : null;

            // One project per set of XSD, template and specification (the database enforces it too).
            var existing = await repository.FindByFilesAsync(currentUser.Name, xsdStored.Sha256, templateStored?.Sha256 ?? ProjectFileKeys.None,
                specificationStored?.Sha256 ?? ProjectFileKeys.None, cancellationToken);
            if (existing.Count > 0)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, SameFilesMessage(existing));
            }

            var built = await BuildFromFilesAsync(projectId, requestedName,
                new UploadedFileDto { OriginalName = xsdFile.FileName, StoredPath = xsdStored.FullPath, Size = xsdFile.Length, Sha256 = xsdStored.Sha256 },
                (templateFile != null && templateStored != null)
                    ? new UploadedFileDto { OriginalName = templateFile.FileName, StoredPath = templateStored.FullPath, Size = templateFile.Length, Sha256 = templateStored.Sha256 }
                    : null,
                (specificationFile != null && specificationStored != null)
                    ? new UploadedFileDto { OriginalName = specificationFile.FileName, StoredPath = specificationStored.FullPath, Size = specificationFile.Length, Sha256 = specificationStored.Sha256 }
                    : null,
                "template.xlsx", progress, Phase, cancellationToken);
            var templateUpload = built.Project.TemplateFile;
            var project = built.Project.With(copy =>
            {
                copy.Id = projectId;
                copy.Name = requestedName;
                copy.CreatedAt = now;
                copy.UpdatedAt = now;
                copy.Workflow = new ProjectWorkflowDto
                {
                    Status = ProjectStatus.Draft,
                    CreatedBy = currentUser.Name,
                    CreatedAt = now,
                    LastModifiedBy = currentUser.Name,
                    LastModifiedAt = now,
                    Contributors = new List<string> { currentUser.Name }
                };
            });

            Phase("mapping");
            var checking = new ValidationStep(progress, 74, 97, "Checking the mappings and the BSP rules");
            checking.Start($"{project.Mappings.Count:N0} mappings");
            project = WithValidation(project, built.Notes, checking);
            Phase("validation");
            new ValidationStep(progress, 97, 100, "Saving the project").Start();
            try
            {
                project = await repository.CreateAsync(project, cancellationToken);
            }
            catch (DuplicateProjectFilesException)
            {
                // Someone created a project with the same files while this one was being analyzed.
                var created = await repository.FindByFilesAsync(currentUser.Name, xsdStored.Sha256, templateStored?.Sha256 ?? ProjectFileKeys.None,
                    specificationStored?.Sha256 ?? ProjectFileKeys.None, cancellationToken);
                throw new WorkflowException(WorkflowErrorKind.Conflict, created.Count > 0
                    ? SameFilesMessage(created)
                    : "You already have a project with the same XSD, template and specification. Open that project instead of creating another.");
            }

            Phase("save");
            await AuditAsync("Project created", project,
                $"XSD {xsdFile.FileName}; template {((templateUpload == null) ? "none" : templateFile?.FileName ?? "generated from the XSD")}; "
                + $"specification {specificationFile?.FileName ?? "none"}; {project.Mappings.Count:N0} mappings."
                + ReusedNote(new VT_Label_Upload<string, StoredUpload>("XSD", xsdStored), new VT_Label_Upload<string, StoredUpload>("template", templateStored), new VT_Label_Upload<string, StoredUpload>("specification", specificationStored)) + sourceNote, cancellationToken);
            logger.LogInformation("Analyzed project {ProjectId} ({Name}): {Phases}", projectId, project.Name, string.Join(", ", phases));
            return project;
        }

        /// <summary>A project read from its files (no id, name or workflow yet), and the notes the mapping left.</summary>
        private sealed class BuiltProject
        {
            public FrpProjectDto Project { get; set; }

            public IReadOnlyList<ValidationIssueDto> Notes { get; set; }
        }

        /// <summary>
        /// Reads the stored XSD, template (null: generate one from the XSD, saved in the project's folder as
        /// <paramref name="generatedFileName"/>) and specification (optional), chooses the sample values and maps the XSD
        /// fields to the template's cells. Used when a project is created and when its files are replaced.
        /// Progress runs 2-74 % (as creating a project).
        /// </summary>
        private async Task<BuiltProject> BuildFromFilesAsync(string projectId, string displayName, UploadedFileDto xsdUpload, UploadedFileDto templateUpload,
            UploadedFileDto specificationUpload, string generatedFileName, IProgress<ValidationProgressDto> progress, Action<string> phase, CancellationToken cancellationToken)
        {
            new ValidationStep(progress, 2, 8, "Reading the XSD").Start(xsdUpload.OriginalName);
            var xsdPath = xsdUpload.StoredPath;
            var parsed = xsdParser.Parse(xsdPath);
            phase("XSD");

            WorkbookSummaryDto workbook = null;
            if (templateUpload != null)
            {
                new ValidationStep(progress, 8, 24, "Reading the BSP Excel template").Start($"{templateUpload.OriginalName} · {parsed.Nodes.Count:N0} XSD fields");
                workbook = workbookInspector.Inspect(templateUpload.StoredPath);
            }

            WorkbookSummaryDto specificationWorkbook = null;
            if (specificationUpload != null)
            {
                new ValidationStep(progress, 24, 34, "Reading the BSP specification").Start(specificationUpload.OriginalName);
                specificationWorkbook = workbookInspector.Inspect(specificationUpload.StoredPath);
            }

            phase("workbooks");
            // Every XSD field gets its own unique, valid sample value (saved in frp.SchemaNode); with a BSP specification the
            // values also respect its rules (allowed values, totals, schedules per period).
            var schemaNodes = parsed.Nodes;
            IReadOnlyList<SampleRowDto> sampleRows = new List<SampleRowDto>();
            IReadOnlyList<string> omittedForms = new List<string>();
            try
            {
                new ValidationStep(progress, 34, 40, "Choosing sample values").Start("A unique value for every XSD field");
                var sample2 = ChooseSampleValues(new FrpProjectDto
                {
                    RootElement = parsed.RootElement,
                    TargetNamespace = parsed.TargetNamespace,
                    SchemaNodes = schemaNodes,
                    XsdFile = new UploadedFileDto { StoredPath = xsdPath },
                    SpecificationFile = specificationUpload
                }, projectId, new ValidationStep(progress, 40, 68, "Making the sample values pass the BSP rules"));
                var chosen = sample2.Refill;
                schemaNodes = chosen.Nodes;
                sampleRows = chosen.SampleRows;
                omittedForms = chosen.OmittedForms;
            }
            catch (Exception ex) when ((ex is InvalidOperationException || ex is InvalidDataException || ex is System.Xml.XmlException || ex is IOException))
            {
                // The specification is re-read during validation, which reports the problem to the user.
            }

            phase("sample values");
            new ValidationStep(progress, 68, 74, (templateUpload == null) ? "Generating the input template from the XSD" : "Mapping XSD fields to template cells")
                .Start((templateUpload == null) ? null : $"{schemaNodes.Count(n => n.DataType != "complex"):N0} fields");
            MappingPlan plan;
            var templateGenerated = false;
            if (templateUpload == null)
            {
                // No BSP template: build the input template from the XSD (with specification labels when available)
                // and store it as the project's template, so exports, validation and coverage work the same way.
                BspSpecification specification = null;
                if (specificationUpload != null)
                {
                    try
                    {
                        specification = specificationReader.Read(specificationUpload.StoredPath);
                    }
                    catch (Exception ex) when ((ex is InvalidOperationException || ex is InvalidDataException || ex is System.Xml.XmlException || ex is IOException))
                    {
                        // Labels are optional; validation reports an unreadable specification.
                    }
                }

                var draft = new FrpProjectDto { RootElement = parsed.RootElement, TargetNamespace = parsed.TargetNamespace, SchemaNodes = schemaNodes };
                var generated = templateGenerator.Generate(draft, specification);
                var fileName = $"{SafeFileName(displayName)}_input_template.xlsx";
                var generatedPath = await fileStore.SaveFileAsync(projectId, generatedFileName, generated.Bytes, cancellationToken);
                templateUpload = new UploadedFileDto { OriginalName = fileName, StoredPath = generatedPath, Size = generated.Bytes.Length };
                workbook = workbookInspector.Inspect(generatedPath);
                templateGenerated = true;
                plan = new MappingPlan(generated.Mappings, new List<ValidationIssueDto>());
            }
            else
            {
                plan = suggestionEngine.CreateInitialMappings(schemaNodes, workbook);
            }

            return new BuiltProject
            {
                Notes = plan.Notes,
                Project = new FrpProjectDto
                {
                    XsdFile = xsdUpload,
                    TemplateFile = templateUpload,
                    TemplateGenerated = templateGenerated,
                    SpecificationFile = specificationUpload,
                    TargetNamespace = parsed.TargetNamespace,
                    RootElement = parsed.RootElement,
                    SchemaNodes = schemaNodes,
                    Workbook = ForStorage(workbook),
                    SpecificationWorkbook = ForStorage(specificationWorkbook),
                    Mappings = plan.Mappings,
                    SampleRows = sampleRows,
                    SampleOmittedForms = omittedForms
                }
            };
        }

        /// <summary>A project name: trimmed, 1-200 characters, no control characters.</summary>
        private static string CheckProjectName(string name)
        {
            var trimmed = (name ?? "").Trim();
            if (trimmed.Length == 0)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Give the project a name.");
            }

            if (trimmed.Length > MaxProjectNameLength || trimmed.Any(char.IsControl))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"The project name is at most {MaxProjectNameLength} characters, without line breaks or control characters.");
            }

            return trimmed;
        }

        /// <summary>A Maker renames a draft or returned project. Null: no such project (or one the person may not see).</summary>
        public async Task<FrpProjectDto> RenameAsync(string projectId, string name, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectEdit, "rename the project");
            if (!ProjectIds.IsValid(projectId))
            {
                return null;
            }

            var newName = CheckProjectName(name);
            using (var gate = await repository.LockAsync(projectId, cancellationToken))
            {
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            WorkflowRules.RequireEditable(project, currentUser, Permissions.ProjectEdit, "rename the project");
            if (string.Equals(project.Name, newName, StringComparison.Ordinal))
            {
                return project;
            }

            var now = DateTimeOffset.UtcNow;
            var renamed = await repository.RenameAsync(project.With(copy =>
            {
                copy.Name = newName;
                copy.UpdatedAt = now;
                copy.Workflow = project.Workflow.With(inner => { inner.LastModifiedBy = currentUser.Name; inner.LastModifiedAt = now; });
            }), cancellationToken);
            await AuditAsync("Project renamed", renamed, $"\"{project.Name}\" renamed to \"{newName}\".", cancellationToken);
            return renamed;
            }
        }

        /// <summary>
        /// A Maker replaces a draft or returned project's XSD, Excel template and/or BSP specification (or generates the
        /// template from the XSD, or removes the specification). The project is read again from its files, as when it was
        /// created, and the person's work is carried over: mappings of fields still in the XSD (on sheets still in the
        /// template; with a new template, its own cells unless <see cref="ProjectFilesEdit.KeepCells"/>), entered and
        /// emptied values, and sheet copies whose fields still exist. Sample values are chosen again. The XML attached for
        /// review is removed (it was made for the old files). Old files stay stored and named in the audit trail.
        /// Null: no such project (or one the person may not see). Progress runs 0-100 %.
        /// </summary>
        public async Task<ProjectEditResultDto> ReplaceFilesAsync(string projectId, ProjectFilesEdit edit, CancellationToken cancellationToken,
            IProgress<ValidationProgressDto> progress = null)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectEdit, "change the project's files");
            if (!ProjectIds.IsValid(projectId))
            {
                return null;
            }

            edit = edit ?? new ProjectFilesEdit();
            var newXsd = (edit.XsdFile != null && edit.XsdFile.Length > 0) ? edit.XsdFile : null;
            var newTemplate = (edit.TemplateFile != null && edit.TemplateFile.Length > 0) ? edit.TemplateFile : null;
            var newSpecification = (edit.SpecificationFile != null && edit.SpecificationFile.Length > 0) ? edit.SpecificationFile : null;
            if (edit.GenerateTemplate && newTemplate != null)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Upload a new Excel template or generate one from the XSD, not both.");
            }

            if (edit.RemoveSpecification && newSpecification != null)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Upload a new BSP specification or remove it, not both.");
            }

            if (newXsd == null && newTemplate == null && newSpecification == null && !edit.GenerateTemplate && !edit.RemoveSpecification)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Choose a file to replace.");
            }

            if (newXsd != null)
            {
                uploadRules.Require(newXsd, UploadKinds.Xsd, "XSD");
            }

            if (newTemplate != null)
            {
                uploadRules.Require(newTemplate, UploadKinds.Template, "Excel template");
            }

            if (newSpecification != null)
            {
                uploadRules.Require(newSpecification, UploadKinds.Specification, "BSP specification");
            }

            var newName = edit.Name == null ? null : CheckProjectName(edit.Name);
            using (var gate = await repository.LockAsync(projectId, cancellationToken))
            {
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            WorkflowRules.RequireEditable(project, currentUser, Permissions.ProjectEdit, "change the project's files");
            if (edit.RemoveSpecification && project.SpecificationFile == null)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "The project has no BSP specification to remove.");
            }

            new ValidationStep(progress, 0, 2, "Storing the new files").Start();
            var xsd = newXsd != null ? await StoreNewAsync(newXsd, cancellationToken) : await StoredFileAsync(project.XsdFile, "XSD", cancellationToken);
            // null: the template is generated from the XSD (asked for, or the project's template was generated and no new one was uploaded).
            var template = newTemplate != null ? await StoreNewAsync(newTemplate, cancellationToken)
                : (edit.GenerateTemplate || project.TemplateGenerated || project.TemplateFile == null) ? null
                : await StoredFileAsync(project.TemplateFile, "Excel template", cancellationToken);
            var specification = edit.RemoveSpecification ? null
                : newSpecification != null ? await StoreNewAsync(newSpecification, cancellationToken)
                : project.SpecificationFile == null ? null
                : await StoredFileAsync(project.SpecificationFile, "BSP specification", cancellationToken);

            var xsdChanged = !string.Equals(xsd.Sha256, project.XsdFile?.Sha256, StringComparison.OrdinalIgnoreCase);
            var specificationChanged = !string.Equals(specification?.Sha256, project.SpecificationFile?.Sha256, StringComparison.OrdinalIgnoreCase);
            var templateChanged = (template == null)
                ? !project.TemplateGenerated
                : project.TemplateGenerated || !string.Equals(template.Sha256, project.TemplateFile?.Sha256, StringComparison.OrdinalIgnoreCase);
            var filesReplaced = new List<string>();
            if (xsdChanged)
            {
                filesReplaced.Add("XSD");
            }

            if (templateChanged)
            {
                filesReplaced.Add(template == null ? "Excel template generated from the XSD" : "Excel template");
            }

            if (specificationChanged)
            {
                filesReplaced.Add(specification == null ? "BSP specification removed" : project.SpecificationFile == null ? "BSP specification added" : "BSP specification");
            }

            if (filesReplaced.Count == 0)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "These are the files the project already uses, so nothing would change.");
            }

            // One project per person per set of files: the creator may not already have another project with these files.
            var owner = project.Workflow.CreatedBy ?? currentUser.Name;
            var sameFiles = (await repository.FindByFilesAsync(owner, xsd.Sha256, template?.Sha256 ?? ProjectFileKeys.None,
                specification?.Sha256 ?? ProjectFileKeys.None, cancellationToken)).Where(p => p.Id != project.Id).ToList();
            if (sameFiles.Count > 0)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, SameFilesForEditMessage(sameFiles));
            }

            var now = DateTimeOffset.UtcNow;
            Action<string> noPhase = name => { };
            var built = await BuildFromFilesAsync(project.Id, newName ?? project.Name, xsd, template, specification,
                // A new file each time: the previous version's generated template is never overwritten.
                "template-" + Guid.NewGuid().ToString("N") + ".xlsx", progress, noPhase, cancellationToken);

            // Generated templates are laid out by the app, so their cells follow the new XSD; an uploaded template's own
            // cells are used unless the person keeps theirs.
            var layoutChanged = templateChanged || (built.Project.TemplateGenerated && (xsdChanged || specificationChanged));
            var useNewCells = layoutChanged && (built.Project.TemplateGenerated || !edit.KeepCells);
            var summary = new ProjectEditSummaryDto { FilesReplaced = filesReplaced };
            var mappings = CarryOverMappings(project, built.Project, useNewCells, summary);
            var nodePaths = new HashSet<string>(built.Project.SchemaNodes.Select(n => n.Path), StringComparer.OrdinalIgnoreCase);
            var splits = project.SheetSplits.Where(s => nodePaths.Contains(s.GroupPath) && nodePaths.Contains(s.KeyPath)).ToList();
            summary.SheetCopiesDropped = project.SheetSplits.Count - splits.Count;
            summary.SubmissionRemoved = project.Workflow.Submission != null;

            var touched = WorkflowRules.Touched(project.Workflow, currentUser, now).With(copy => { copy.Submission = null; });
            var updated = built.Project.With(copy =>
            {
                copy.Id = project.Id;
                copy.Name = newName ?? project.Name;
                copy.CreatedAt = project.CreatedAt;
                copy.UpdatedAt = now;
                copy.Version = project.Version;
                copy.Workflow = touched;
                copy.SheetSplits = splits;
            });
            updated = updated.With(copy => { copy.Mappings = CleanMappings(updated, mappings); });

            var checking = new ValidationStep(progress, 74, 97, "Checking the mappings and the BSP rules");
            checking.Start($"{updated.Mappings.Count:N0} mappings");
            updated = WithValidation(updated, built.Notes, checking);
            new ValidationStep(progress, 97, 100, "Saving the project").Start();
            try
            {
                updated = await repository.ReplaceSourcesAsync(updated, cancellationToken);
            }
            catch (DuplicateProjectFilesException)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict,
                    "Another project of yours already uses these XSD, template and specification files. Open that project, or choose other files.");
            }

            await AuditAsync("Project files replaced", updated, EditDetails(project, updated, newName, summary), cancellationToken);
            logger.LogInformation("Replaced the files of project {ProjectId}: {Files}", project.Id, string.Join(", ", filesReplaced));
            return new ProjectEditResultDto { Project = updated, Summary = summary };
            }
        }

        private async Task<UploadedFileDto> StoreNewAsync(IFormFile file, CancellationToken cancellationToken)
        {
            var stored = await fileStore.StoreUploadAsync(file, cancellationToken);
            return new UploadedFileDto { OriginalName = file.FileName, StoredPath = stored.FullPath, Size = file.Length, Sha256 = stored.Sha256 };
        }

        /// <summary>A file the project keeps: it must still be stored, with the SHA-256 recorded when it was uploaded.</summary>
        private static async Task<UploadedFileDto> StoredFileAsync(UploadedFileDto stored, string description, CancellationToken cancellationToken)
        {
            if (stored == null || string.IsNullOrEmpty(stored.StoredPath) || !File.Exists(stored.StoredPath))
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, $"The project's stored {description} is missing. Upload it again with the other files.");
            }

            if (stored.Sha256 != null)
            {
                using (var stream = new FileStream(stored.StoredPath, FileMode.Open, FileAccess.Read, FileShare.Read, 81920, useAsync: true))
                {
                    var actual = CompatHex.ToHexString(await CompatHash.Sha256Async(stream, cancellationToken)).ToLowerInvariant();
                    if (!string.Equals(actual, stored.Sha256, StringComparison.OrdinalIgnoreCase))
                    {
                        throw new WorkflowException(WorkflowErrorKind.Conflict,
                            $"The project's stored {description} changed after it was uploaded, so it is not used. Upload it again with the other files.");
                    }
                }
            }

            return stored;
        }

        /// <summary>
        /// The mappings of a project whose files were replaced: what the person mapped and entered, carried over to the
        /// new XSD fields and template. Values: an entered or emptied value stays with its field; a sample value becomes
        /// the new sample value (null here; <see cref="CleanMappings"/> fills it in).
        /// </summary>
        internal static IReadOnlyList<MappingEntryDto> CarryOverMappings(FrpProjectDto before, FrpProjectDto rebuilt, bool useNewCells, ProjectEditSummaryDto summary)
        {
            Func<IEnumerable<SchemaNodeDto>, Dictionary<string, SchemaNodeDto>> byPath = nodes => nodes
                .Where(n => n.DataType != "complex")
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var oldNodes = byPath(before.SchemaNodes);
            var newNodes = byPath(rebuilt.SchemaNodes);
            var sheets = new HashSet<string>((rebuilt.Workbook?.Sheets ?? new List<WorkbookSheetDto>()).Select(s => s.Name), StringComparer.OrdinalIgnoreCase);

            // What the person entered (or emptied), by field; sample values are not carried (the new ones are used).
            var entered = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var mapping in before.Mappings)
            {
                SchemaNodeDto oldNode;
                oldNodes.TryGetValue(mapping.SchemaPath ?? "", out oldNode);
                var isSample = mapping.DefaultValue == null
                    || (!XmlSubmissionWriter.IsCleared(mapping)
                        && (string.Equals(mapping.DefaultValue, oldNode?.TestValue, StringComparison.Ordinal) || LooksGeneratedPlaceholder(mapping.DefaultValue)));
                if (!isSample && !entered.ContainsKey(mapping.SchemaPath))
                {
                    entered[mapping.SchemaPath] = XmlSubmissionWriter.IsCleared(mapping) ? "" : mapping.DefaultValue;
                }
            }

            var result = new List<MappingEntryDto>();
            var mapped = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (useNewCells)
            {
                foreach (var suggested in rebuilt.Mappings)
                {
                    result.Add(suggested);
                    mapped.Add(suggested.SchemaPath);
                }

                summary.MappingsFromTemplate = result.Count;
                // Fields the new template does not map keep the person's cell when its sheet is still there.
                var templateMapped = new HashSet<string>(mapped, StringComparer.OrdinalIgnoreCase);
                foreach (var mapping in before.Mappings)
                {
                    if (newNodes.ContainsKey(mapping.SchemaPath ?? "") && !templateMapped.Contains(mapping.SchemaPath) && sheets.Contains(mapping.SheetName ?? ""))
                    {
                        result.Add(mapping);
                        mapped.Add(mapping.SchemaPath);
                        summary.MappingsKept++;
                    }
                }
            }
            else
            {
                foreach (var mapping in before.Mappings)
                {
                    if (newNodes.ContainsKey(mapping.SchemaPath ?? "") && sheets.Contains(mapping.SheetName ?? ""))
                    {
                        result.Add(mapping);
                        mapped.Add(mapping.SchemaPath);
                        summary.MappingsKept++;
                    }
                }

                // Fields new in the XSD get the app's mapping; fields the person left unmapped stay unmapped.
                foreach (var suggested in rebuilt.Mappings)
                {
                    if (!mapped.Contains(suggested.SchemaPath) && !oldNodes.ContainsKey(suggested.SchemaPath))
                    {
                        result.Add(suggested);
                        summary.MappingsFromTemplate++;
                    }
                }

                foreach (var suggested in result)
                {
                    mapped.Add(suggested.SchemaPath);
                }
            }

            var oldMapped = before.Mappings.Select(m => m.SchemaPath).Where(p => p != null).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            var removed = oldMapped.Where(p => !newNodes.ContainsKey(p)).ToList();
            summary.FieldsRemovedCount = removed.Count;
            summary.FieldsRemoved = removed.Take(50).ToList();
            summary.MappingsDropped = oldMapped.Count(p => !mapped.Contains(p));
            summary.FieldsAdded = newNodes.Keys.Count(p => !oldNodes.ContainsKey(p));
            summary.ValuesKept = entered.Keys.Count(p => mapped.Contains(p) && newNodes.ContainsKey(p));
            summary.ValuesDropped = entered.Count - summary.ValuesKept;

            return result.Select(m =>
            {
                string value;
                var hasValue = entered.TryGetValue(m.SchemaPath ?? "", out value);
                return m.With(copy => { copy.DefaultValue = hasValue ? value : null; });
            }).ToList();
        }

        private static string SameFilesForEditMessage(IReadOnlyList<ProjectSummaryDto> projects)
        {
            var names = string.Join("; ", projects.Take(3).Select(p => $"\"{p.Name}\" ({p.RootElement}, {p.Status})"));
            return "Another project of yours already uses these XSD, template and specification files: " + names
                + ". Each person has one project per set of files, so open that project or choose other files.";
        }

        private static string EditDetails(FrpProjectDto before, FrpProjectDto after, string newName, ProjectEditSummaryDto summary)
        {
            Func<UploadedFileDto, bool, string> name = (file, generated) => generated ? "generated from the XSD" : file == null ? "none" : file.OriginalName;
            var parts = new List<string>();
            if (!string.Equals(before.XsdFile?.Sha256, after.XsdFile?.Sha256, StringComparison.OrdinalIgnoreCase))
            {
                parts.Add($"XSD {name(before.XsdFile, false)} (SHA-256 {before.XsdFile?.Sha256}) replaced by {name(after.XsdFile, false)} (SHA-256 {after.XsdFile?.Sha256})");
            }

            if (summary.FilesReplaced.Any(f => f.StartsWith("Excel template", StringComparison.Ordinal)))
            {
                parts.Add($"template {name(before.TemplateFile, before.TemplateGenerated)} replaced by {name(after.TemplateFile, after.TemplateGenerated)}");
            }

            if (summary.FilesReplaced.Any(f => f.StartsWith("BSP specification", StringComparison.Ordinal)))
            {
                parts.Add($"specification {name(before.SpecificationFile, false)} replaced by {name(after.SpecificationFile, false)}");
            }

            var text = string.Join("; ", parts) + ". "
                + $"Mappings: {summary.MappingsKept:N0} kept, {summary.MappingsFromTemplate:N0} from the new files, {summary.MappingsDropped:N0} field(s) no longer mapped"
                + (summary.FieldsRemovedCount > 0 ? $" ({summary.FieldsRemovedCount:N0} no longer in the XSD: {string.Join(", ", summary.FieldsRemoved.Take(10))}{(summary.FieldsRemovedCount > 10 ? ", …" : "")})" : "")
                + $"; {summary.FieldsAdded:N0} new XSD field(s). Values: {summary.ValuesKept:N0} entered value(s) kept, {summary.ValuesDropped:N0} dropped; sample values chosen again."
                + (summary.SheetCopiesDropped > 0 ? $" {summary.SheetCopiesDropped} sheet cop(ies) removed (their fields are no longer in the XSD)." : "")
                + (summary.SubmissionRemoved ? " The XML attached for review was removed (it was made for the old files)." : "");
            if (newName != null && !string.Equals(newName, before.Name, StringComparison.Ordinal))
            {
                text += $" Renamed \"{before.Name}\" to \"{newName}\".";
            }

            return text;
        }

        public async Task<FrpProjectDto> GetAsync(string projectId, CancellationToken cancellationToken)
        {
            var version = await VisibleVersionAsync(projectId, cancellationToken);
            if (version == null)
            {
                return null;
            }

            // The page's view (with current sample values) is worked out once per version of the project.
            var view = readCache.View(projectId, version.Value);
            if (view != null)
            {
                return view;
            }

            var project = await ReadAsync(projectId, version.Value, cancellationToken);
            if (project == null)
            {
                return null;
            }

            view = WithCurrentSampleValues(project);
            readCache.KeepView(project, view);
            return view;
        }

        /// <summary>
        /// The version (UpdatedAt) of a project the person may see, from the list of projects (one light query), or null.
        /// Every save of a project changes its UpdatedAt, so it identifies what was read.
        /// </summary>
        private async Task<DateTimeOffset?> VisibleVersionAsync(string projectId, CancellationToken cancellationToken)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                return null;
            }

            var summary = (await access.ListAsync(cancellationToken)).FirstOrDefault(p => p.Id == projectId);
            return summary?.UpdatedAt;
        }

        /// <summary>The project as stored, for reading only: from the cache when this version was read before.</summary>
        private async Task<FrpProjectDto> ReadAsync(string projectId, DateTimeOffset version, CancellationToken cancellationToken)
        {
            var project = readCache.Stored(projectId, version);
            if (project != null)
            {
                return project;
            }

            project = await access.GetAsync(projectId, cancellationToken);
            if (project != null)
            {
                readCache.KeepStored(project);
            }

            return project;
        }

        private async Task<FrpProjectDto> ReadAsync(string projectId, CancellationToken cancellationToken)
        {
            var version = await VisibleVersionAsync(projectId, cancellationToken);
            return (version == null) ? null : await ReadAsync(projectId, version.Value, cancellationToken);
        }

        /// <summary>
        /// The projects that already use the files a new project would be created from (checked before uploading:
        /// the Platform sends the SHA-256 of each new file; reused files are taken from the source project).
        /// </summary>
        public async Task<IReadOnlyList<ProjectSummaryDto>> FindProjectsWithFilesAsync(ProjectFilesCheckRequest request, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectCreate, "create a project");
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectRead, "read projects");
            ProjectUploads source = null;
            if (request.ReuseXsd || request.ReuseTemplate || request.ReuseSpecification)
            {
                source = await access.GetUploadsAsync(request.SourceProjectId ?? "", cancellationToken)
                         ?? CompatThrow.As<ProjectUploads>(new WorkflowException(WorkflowErrorKind.Invalid, "The project to reuse files from was not found."));
            }

            var xsd = request.ReuseXsd ? source.Xsd?.Sha256 : Sha(request.XsdSha256);
            if (xsd == null)
            {
                return new List<ProjectSummaryDto>();
            }

            var template = request.ReuseTemplate ? source.Template?.Sha256 : Sha(request.TemplateSha256);
            var specification = request.ReuseSpecification ? source.Specification?.Sha256 : Sha(request.SpecificationSha256);
            if (request.ReuseTemplate && template == null || request.ReuseSpecification && specification == null)
            {
                return new List<ProjectSummaryDto>(); // a reused file without a recorded SHA-256; creating the project reports what is wrong
            }

            return await repository.FindByFilesAsync(currentUser.Name, xsd, template ?? ProjectFileKeys.None, specification ?? ProjectFileKeys.None, cancellationToken);
        }

        private static string SameFilesMessage(IReadOnlyList<ProjectSummaryDto> projects)
        {
            var names = string.Join("; ", projects.Take(3).Select(p =>
                $"\"{p.Name}\" ({p.RootElement}, {p.Status}, updated {p.UpdatedAt.ToLocalTime():d MMM yyyy HH:mm})"));
            return (projects.Count == 1 ? "You already have these files in project " : $"You already have these files in {projects.Count} projects: ")
                + names + ". Open " + (projects.Count == 1 ? "it" : "one of them") + " instead of creating another project: "
                + "each person has one project per set of XSD, Excel template and specification.";
        }

        /// <summary>The account code shown on each row of the project's Excel input template (null: no such project).</summary>
        public async Task<TemplateAccountCodesDto> GetAccountCodesAsync(string projectId, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectRead, "read projects");
            var project = await ReadAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            var sheets = (project.TemplateFile == null) ? new Dictionary<string, IReadOnlyDictionary<int, string>>() : accountCodeReader.Read(project.TemplateFile.StoredPath);
            return new TemplateAccountCodesDto { Sheets = sheets };
        }

        public async Task<FrpProjectDto> UpdateMappingsAsync(string projectId, IReadOnlyList<MappingEntryDto> mappings, CancellationToken cancellationToken)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                return null;
            }

            using (var gate = await repository.LockAsync(projectId, cancellationToken))
            {
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            WorkflowRules.RequireEditable(project, currentUser, Permissions.ProjectEdit, "change the mappings");
            var now = DateTimeOffset.UtcNow;
            var updated = WithValidation(project.With(copy => { copy.UpdatedAt = now; copy.Mappings = CleanMappings(project, mappings); copy.Workflow = WorkflowRules.Touched(project.Workflow, currentUser, now); }));
            updated = await repository.SaveMappingsAsync(updated, cancellationToken);
            await AuditAsync("Mappings saved", updated, $"{updated.Mappings.Count:N0} mappings; validation {(updated.Validation?.IsValid == true ? "passed" : $"has {updated.Validation?.ErrorCount ?? 0} error(s)")}.", cancellationToken);
            return updated;
            }
        }

        /// <summary>
        /// Removes the sample values (action "remove": every field still holding its sample value gets an empty cell) or
        /// puts them back (action "restore": every emptied field gets its sample value again), on one sheet or the whole
        /// project. Values people entered are never touched. A Maker, while the project can be edited.
        /// </summary>
        public async Task<SampleValuesResultDto> ChangeSampleValuesAsync(string projectId, string action, string sheetName, CancellationToken cancellationToken)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                return null;
            }

            var remove = string.Equals(action, "remove", StringComparison.Ordinal);
            if (!remove && !string.Equals(action, "restore", StringComparison.Ordinal))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "The action must be \"remove\" or \"restore\".");
            }

            sheetName = string.IsNullOrWhiteSpace(sheetName) ? null : sheetName.Trim();
            if (sheetName != null && (sheetName.Length > MaxSheetNameLength || sheetName.Any(char.IsControl)))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "The sheet name is not valid.");
            }

            using (var gate = await repository.LockAsync(projectId, cancellationToken))
            {
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            WorkflowRules.RequireEditable(project, currentUser, Permissions.ProjectEdit, remove ? "remove the sample values" : "restore the sample values");
            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var changed = 0;
            var mappings = project.Mappings.Select(m =>
            {
                SchemaNodeDto node;
                if ((sheetName != null && !string.Equals(m.SheetName, sheetName, StringComparison.OrdinalIgnoreCase))
                    || !nodesByPath.TryGetValue(m.SchemaPath, out node) || node.DataType == "complex")
                {
                    return m;
                }

                var isSample = m.DefaultValue == null
                    || string.Equals(m.DefaultValue, node.TestValue, StringComparison.Ordinal)
                    || LooksGeneratedPlaceholder(m.DefaultValue);
                if (remove && isSample && !XmlSubmissionWriter.IsCleared(m))
                {
                    changed++;
                    return m.With(copy => { copy.DefaultValue = ""; });
                }

                if (!remove && XmlSubmissionWriter.IsCleared(m))
                {
                    changed++;
                    return m.With(copy => { copy.DefaultValue = node.TestValue; });
                }

                return m;
            }).ToList();
            if (changed == 0)
            {
                return new SampleValuesResultDto { Project = project, Changed = 0 };
            }

            var now = DateTimeOffset.UtcNow;
            var updated = WithValidation(project.With(copy => { copy.UpdatedAt = now; copy.Mappings = mappings; copy.Workflow = WorkflowRules.Touched(project.Workflow, currentUser, now); }));
            updated = await repository.SaveMappingsAsync(updated, cancellationToken);
            await AuditAsync(remove ? "Sample values removed" : "Sample values restored", updated,
                $"{changed:N0} field(s) on {(sheetName == null ? "every sheet" : "sheet " + sheetName)} {(remove ? "emptied; entered values kept" : "given their sample value again")}.", cancellationToken);
            return new SampleValuesResultDto { Project = updated, Changed = changed };
            }
        }

        /// <summary>Most values one save may carry (the Sheet view saves a few at a time, as they are typed).</summary>
        public const int MaxValuesPerSave = 1000;

        /// <summary>Longest value accepted (XSD rules are narrower for every BSP field).</summary>
        public const int MaxValueLength = 4000;

        /// <summary>
        /// Saves values typed into mapped cells (a Maker, while the project can be edited). Every value is checked against
        /// its field's XSD rules first; when one breaks them nothing is saved and the refused values are returned. A blank
        /// value empties the cell (its sample value is removed); a null value puts the field's sample value back. The
        /// mappings themselves are not changed.
        /// </summary>
        public async Task<SaveValuesResultDto> SaveValuesAsync(string projectId, IReadOnlyList<CellValueDto> values, CancellationToken cancellationToken)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                return null;
            }

            values = values ?? new List<CellValueDto>();
            if (values.Count == 0 || values.Count > MaxValuesPerSave)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"Send between 1 and {MaxValuesPerSave} values.");
            }

            using (var gate = await repository.LockAsync(projectId, cancellationToken))
            {
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            WorkflowRules.RequireEditable(project, currentUser, Permissions.ProjectEdit, "change the values");
            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var mapped = new HashSet<string>(project.Mappings.Select(m => m.SchemaPath), StringComparer.OrdinalIgnoreCase);
            var errors = new List<ValueErrorDto>();
            var typed = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var item in values)
            {
                var path = item?.SchemaPath ?? "";
                var useSample = item != null && item.Value == null;
                var value = item?.Value ?? "";
                SchemaNodeDto node;
                IReadOnlyList<string> problems;
                if (!nodesByPath.TryGetValue(path, out node) || node.DataType == "complex")
                {
                    problems = new[] { "The XSD does not contain this field." };
                }
                else if (!mapped.Contains(path))
                {
                    problems = new[] { "The field is not mapped to a cell. Save the mapping first." };
                }
                else if (value.Length > MaxValueLength || value.Any(char.IsControl))
                {
                    problems = new[] { $"A value can have at most {MaxValueLength} characters and no control characters." };
                }
                else if (useSample || value.Trim().Length == 0)
                {
                    problems = new string[0]; // the sample value, or an empty cell (a required one is reported by validation)
                }
                else
                {
                    problems = FrpMapper.Shared.Validation.XsdValueValidator.Validate(value, node);
                }

                if (problems.Count > 0)
                {
                    errors.Add(new ValueErrorDto { SchemaPath = path, Errors = problems });
                }
                else
                {
                    typed[node.Path] = useSample ? node.TestValue : value.Trim().Length == 0 ? "" : value;
                }
            }

            if (errors.Count > 0)
            {
                return new SaveValuesResultDto { Errors = errors };
            }

            var now = DateTimeOffset.UtcNow;
            var mappings = project.Mappings
                .Select(m => { string value; return typed.TryGetValue(m.SchemaPath, out value) ? m.With(copy => { copy.DefaultValue = value; }) : m; })
                .ToList();
            var updated = WithValidation(project.With(copy => { copy.UpdatedAt = now; copy.Mappings = mappings; copy.Workflow = WorkflowRules.Touched(project.Workflow, currentUser, now); }));
            updated = await repository.SaveMappingsAsync(updated, cancellationToken);
            await AuditAsync("Values saved", updated, $"{typed.Count:N0} value(s) typed on the sheet: "
                + string.Join(", ", typed.Keys.Take(5).Select(p => p.Split('/').Last())) + (typed.Count > 5 ? ", ..." : "")
                + $"; validation {(updated.Validation?.IsValid == true ? "passed" : $"has {updated.Validation?.ErrorCount ?? 0} error(s)")}.", cancellationToken);
            return new SaveValuesResultDto { Project = updated };
            }
        }

        /// <summary>The forms that can be entered on one sheet per key value (e.g. Currency) and the project's current splits.</summary>
        public async Task<SheetSplitSettingsDto> GetSheetSplitsAsync(string projectId, CancellationToken cancellationToken)
        {
            var project = await ReadAsync(projectId, cancellationToken);
            return (project == null) ? null : SheetSplitSettings(project);
        }

        /// <summary>
        /// Saves which forms are entered on one sheet per key value (a Maker, while the project can be edited). The
        /// values are checked against the key field's XSD type and code list; the project is validated again.
        /// </summary>
        public async Task<FrpProjectDto> SaveSheetSplitsAsync(string projectId, IReadOnlyList<SheetSplitDto> splits, CancellationToken cancellationToken)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                return null;
            }

            using (var gate = await repository.LockAsync(projectId, cancellationToken))
            {
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            WorkflowRules.RequireEditable(project, currentUser, Permissions.ProjectEdit, "change the sheet copies");
            var normalized = SheetSplitRules.Normalize(project, splits);
            var now = DateTimeOffset.UtcNow;
            var updated = WithValidation(project.With(copy => { copy.UpdatedAt = now; copy.SheetSplits = normalized; copy.Workflow = WorkflowRules.Touched(project.Workflow, currentUser, now); }));
            updated = await repository.SaveSheetSplitsAsync(updated, cancellationToken);
            await AuditAsync("Sheet copies saved", updated, normalized.Count == 0
                ? "No form is split into sheet copies."
                : string.Join("; ", normalized.Select(split =>
                    $"{SheetSplitRules.FormName(split.GroupPath)} by {split.KeyPath.Split('/').Last()}: {string.Join(", ", split.Values)}")), cancellationToken);
            return updated;
            }
        }

        private static SheetSplitSettingsDto SheetSplitSettings(FrpProjectDto project) => new SheetSplitSettingsDto() {
            Options = SheetSplitRules.Options(project),
            Splits = project.SheetSplits,
            MaxValues = SheetSplitRules.MaxValues
        };

        public async Task<SampleRefillDto> RefillSampleValuesAsync(string projectId, CancellationToken cancellationToken)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                return null;
            }

            using (var gate = await repository.LockAsync(projectId, cancellationToken))
            {
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            WorkflowRules.RequireEditable(project, currentUser, Permissions.ProjectEdit, "refill the sample values");
            var sample2 = ChooseSampleValues(project, Guid.NewGuid().ToString("N"));
            var refill = sample2.Refill;
            var validation = sample2.Validation;
            var now = DateTimeOffset.UtcNow;
            var updated = WithValidation(project.With(copy => { copy.UpdatedAt = now; copy.SchemaNodes = refill.Nodes; copy.Mappings = CleanMappings(project, refill.Mappings); copy.SampleRows = refill.SampleRows; copy.SampleOmittedForms = refill.OmittedForms; copy.Workflow = WorkflowRules.Touched(project.Workflow, currentUser, now); }));
            updated = await repository.SaveSampleValuesAsync(updated, cancellationToken);

            var counted = updated.SchemaNodes.Where(n => (n.DataType == "decimal" || n.DataType == "integer" || n.DataType == "string") && n.Validation.Enumerations.Count == 0
                && HeaderField(n.Path) == null).Select(n => n.TestValue ?? "").ToList();
            var counts = updated.SchemaNodes.Where(n => n.DataType != "complex").Select(n => n.TestValue ?? "")
                .GroupBy(v => v, StringComparer.Ordinal).ToDictionary(g => g.Key, g => g.Count(), StringComparer.Ordinal);
            var unique = counted.Count(v => counts.GetValueOrDefault(v) == 1);
            var errors = validation?.Messages.Where(m => string.Equals(m.Severity, "Error", StringComparison.OrdinalIgnoreCase)).ToList() ?? new List<XsdValidationMessageDto>();
            await AuditAsync("Sample values refilled", updated,
                $"{unique:N0} of {counted.Count:N0} amounts, numbers and texts unique; {updated.Mappings.Count:N0} mapped values replaced; "
                + $"BSP rules {validation?.SpecRulesPassed ?? 0:N0} passed, {validation?.SpecRulesFailed ?? 0:N0} failed.", cancellationToken);
            return new SampleRefillDto
            {
                Project = updated,
                Refilled = updated.Mappings.Count,
                Unique = unique,
                Shared = counted.Count - unique,
                XsdValid = validation?.IsValid ?? true,
                XsdErrors = errors.Count(m => !m.Message.StartsWith("Specification:", StringComparison.Ordinal)),
                RulesPassed = validation?.SpecRulesPassed ?? 0,
                RulesFailed = validation?.SpecRulesFailed ?? 0,
                Problems = errors.Select(m => m.Message).Take(20).ToList()
            };
            }
        }

        /// <summary>
        /// A unique, valid sample value for every XSD field (see <see cref="SampleValueRefill"/>), checked against the XSD and
        /// the BSP rules. Codes the rules compare keep their values; when making the other values unique still breaks a
        /// rule, every field the rules mention keeps its value instead (whichever has fewer problems is used).
        /// </summary>
        private VT_Refill_Validation<SampleRefill, XsdValidationResultDto> ChooseSampleValues(FrpProjectDto project, string seed, ValidationStep progress = null)
        {
            Func<bool, VT_Refill_Validation<SampleRefill, XsdValidationResultDto>> Attempt = null;
            Attempt = (bool keepAllRuleFields) =>
            {
                var refill = sampleValueRefill.Refill(project, seed, keepAllRuleFields, progress);
                if (project.XsdFile == null || !File.Exists(project.XsdFile.StoredPath))
                {
                    return new VT_Refill_Validation<SampleRefill, XsdValidationResultDto>(refill, null);
                }
        
                var candidate = project.With(copy =>
                {
                    copy.SchemaNodes = refill.Nodes;
                    copy.Mappings = refill.Mappings;
                    copy.SampleRows = refill.SampleRows;
                    copy.SampleOmittedForms = refill.OmittedForms;
                });
                return new VT_Refill_Validation<SampleRefill, XsdValidationResultDto>(refill, ValidateXml(candidate, GenerateSubmissionXml(candidate), "Sample values"));
            };

            var chosen = Attempt(false);
            if (Problems(chosen.Validation) > 0)
            {
                var safer = Attempt(true);
                if (Problems(safer.Validation) < Problems(chosen.Validation))
                {
                    chosen = safer;
                }
            }

            return chosen;
        }

        public async Task<ProjectValidationResultDto> ValidateAsync(string projectId, IReadOnlyList<MappingEntryDto> mappings, CancellationToken cancellationToken)
        {
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            // Validate the caller's unsaved edits when supplied; otherwise the saved mappings.
            var candidate = (mappings == null) ? project : project.With(copy => { copy.Mappings = CleanMappings(project, mappings); });
            return projectValidator.Validate(candidate);
        }

        public async Task<VT_FileName_ContentType_Bytes<string, string, byte[]>?> ExportXmlAsync(string projectId, ExportValues values, CancellationToken cancellationToken)
        {
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            if (values != ExportValues.Sample)
            {
                // Segregation of duties: the submission XML is released only through the Checker's approval.
                throw new WorkflowException(WorkflowErrorKind.Conflict,
                    "The submission XML is available only after a Checker approves the project (download the approved file). "
                    + "Sample-value XML can be exported at any time.");
            }

            var sample = SheetSplitRules.WithAlignedKeys(WithSampleValues(project));
            var bytes = xmlWriter.Write(sample);
            EnsureValidSampleXml(ValidateSampleXml(sample, bytes));
            await AuditAsync("Sample XML exported", project, "Validated against the XSD and BSP specification rules before export.", cancellationToken);
            return new VT_FileName_ContentType_Bytes<string, string, byte[]>($"{SafeFileName(project.Name)}_submission_sample.xml", "application/xml", bytes);
        }

        public async Task<VT_FileName_ContentType_Bytes<string, string, byte[]>?> ExportMappedTemplateAsync(string projectId, ExportValues values, CancellationToken cancellationToken)
        {
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            // A split form's values go on the sheet of their key value (the first sheet when the value is not one of the
            // split's values; the XML then uses that sheet's value too, so template and XML agree).
            var source = SheetSplitRules.WithAlignedKeys(values == ExportValues.Sample ? WithSampleValues(project) : project);
            if (values == ExportValues.Sample)
            {
                EnsureValidSampleXml(ValidateSampleXml(source, xmlWriter.Write(source)));
            }

            // The sample template leaves the forms the specification excludes for the sample Header unbound:
            // Excel's XML export writes every mapped form, so this is the only way its export can leave them out.
            var bytes = templateWriter.Write(source, writeValues: values != ExportValues.Blank,
                unboundForms: values == ExportValues.Sample ? source.SampleOmittedForms : null);
            var suffix = values == ExportValues.Blank ? "_mapped_template_blank" : values == ExportValues.Sample ? "_mapped_template_sample" : "_mapped_template";
            await AuditAsync("Mapped template exported", project, values == ExportValues.Blank ? "Blank (for data entry)" : values == ExportValues.Sample ? "XSD sample values" : "Project values", cancellationToken);
            return new VT_FileName_ContentType_Bytes<string, string, byte[]>($"{SafeFileName(project.Name)}{suffix}.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", bytes);
        }

        /// <summary>Builds the mapped template the app would export and checks its XML map against the XSD.</summary>
        public async Task<TemplateCoverageDto> CheckExportedTemplateAsync(string projectId, ExportValues values, CancellationToken cancellationToken)
        {
            var export = await ExportMappedTemplateAsync(projectId, values, cancellationToken);
            var project = (export == null) ? null : await access.GetAsync(projectId, cancellationToken);
            return (project == null) ? null : coverageChecker.Check(project, export.Value.Bytes, export.Value.FileName);
        }

        /// <summary>Checks an uploaded Excel workbook's XML map against the project's XSD.</summary>
        public async Task<TemplateCoverageDto> CheckUploadedTemplateAsync(string projectId, IFormFile workbook, CancellationToken cancellationToken)
        {
            uploadRules.Require(workbook, UploadKinds.WorkbookToCheck, "Excel workbook");
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            using (var stream = workbook.OpenReadStream())
            {
            using (var buffer = new MemoryStream())
            {
            await stream.CopyToAsync(buffer, cancellationToken);
            return coverageChecker.Check(project, buffer.ToArray(), workbook.FileName);
            }
            }
        }

        /// <summary>The XML from the project's values (a split form's key value aligned with its first sheet, as in the exported template).</summary>
        public byte[] GenerateSubmissionXml(FrpProjectDto project) => xmlWriter.Write(SheetSplitRules.WithAlignedKeys(project));

        public Task<IReadOnlyList<ProjectSummaryDto>> ListAsync(CancellationToken cancellationToken) => access.ListAsync(cancellationToken);

        /// <summary>Validates XML bytes against the project's XSD and BSP specification (used for the submission file too).</summary>
        public XsdValidationResultDto ValidateXml(FrpProjectDto project, byte[] xmlBytes, string label)
        {
            return WithSpecificationRules(project, xmlBytes, validationService.ValidateBytes(xmlBytes, project.XsdFile.StoredPath, label));
        }

        private XsdValidationResultDto ValidateSampleXml(FrpProjectDto sampleProject, byte[] xmlBytes)
        {
            var xsd = validationService.ValidateBytes(xmlBytes, sampleProject.XsdFile.StoredPath, "Generated sample XML");
            return WithSpecificationRules(sampleProject, xmlBytes, xsd);
        }

        private static void EnsureValidSampleXml(XsdValidationResultDto validation)
        {
            if (validation.IsValid)
            {
                return;
            }

            var problems = validation.Messages
                .Where(m => string.Equals(m.Severity, "Error", StringComparison.OrdinalIgnoreCase)
                    || string.Equals(m.Severity, "Warning", StringComparison.OrdinalIgnoreCase))
                .Take(3)
                .Select(m => string.IsNullOrWhiteSpace(m.SchemaPath) ? m.Message : $"{m.SchemaPath}: {m.Message}")
                .ToList();
            var detail = problems.Count == 0
                ? "Review the XSD and BSP specification validation messages."
                : string.Join(" ", problems);

            throw new WorkflowException(WorkflowErrorKind.Conflict,
                "The generated sample XML is not valid yet, so it was not exported. " + detail);
        }

        public async Task<XsdValidationResultDto> ValidateGeneratedXmlAsync(string projectId, CancellationToken cancellationToken,
            IProgress<ValidationProgressDto> progress = null)
        {
            new ValidationStep(progress, 0, 5, "Loading the project").Start();
            var project = await access.GetAsync(projectId, cancellationToken);
            if ((project?.XsdFile) == null || !File.Exists(project.XsdFile.StoredPath))
            {
                return null;
            }

            new ValidationStep(progress, 5, 10, "Building the XML from the project's values").Start();
            var bytes = xmlWriter.Write(project);
            var xsd = validationService.ValidateBytes(bytes, project.XsdFile.StoredPath, "Generated XML export", new ValidationStep(progress, 10, 30, "Checking the XML against the XSD"));
            return WithSpecificationRules(project, bytes, xsd, rules: new ValidationStep(progress, 30, 99, "Checking the BSP specification rules"));
        }

        /// <summary>
        /// An XML exported by Excel from a template with sheet copies (CAR_Part_IV_4c_PHP…) in the XSD's structure
        /// (one CAR_Part_IV_4c with an item per copy), to check it with other tools or keep it. The same conversion is
        /// applied when such an XML is validated or attached as the submission file.
        /// </summary>
        public async Task<VT_FileName_Bytes<string, byte[]>?> MergeSheetCopiesXmlAsync(string projectId, IFormFile xmlFile, CancellationToken cancellationToken)
        {
            var project = ProjectIds.IsValid(projectId) ? await access.GetAsync(projectId, cancellationToken) : null;
            if (project == null)
            {
                return null;
            }

            uploadRules.Require(xmlFile, UploadKinds.XmlToValidate, "XML file");
            using (var stream = xmlFile.OpenReadStream())
            {
            using (var buffer = new MemoryStream())
            {
            await stream.CopyToAsync(buffer, cancellationToken);
            var bytes = buffer.ToArray();
            var merged = SheetCopyMap.Normalize(project, bytes)
                ?? CompatThrow.As<VT_Xml_Note<byte[], string>>(new WorkflowException(WorkflowErrorKind.Invalid,
                    "This XML has no sheet-copy elements (such as CAR_Part_IV_4c_PHP), so there is nothing to merge: it is already in the XSD's structure."));
            var name = $"{SafeFileName(Path.GetFileNameWithoutExtension(xmlFile.FileName))}_merged.xml";
            await AuditAsync("Excel XML merged", project,
                $"{Path.GetFileName(xmlFile.FileName)} (SHA-256 {Sha256Hex(bytes)}) to {name} (SHA-256 {Sha256Hex(merged.Xml)}). {merged.Note}", cancellationToken);
            return new VT_FileName_Bytes<string, byte[]>(name, merged.Xml);
            }
            }
        }

        public async Task<VT_FileName_Bytes<string, byte[]>?> XmlForSandboxAsync(string projectId, string source, IFormFile file, CancellationToken cancellationToken)
        {
            var project = ProjectIds.IsValid(projectId) ? await access.GetAsync(projectId, cancellationToken) : null;
            if (project == null)
            {
                return null;
            }

            switch (source)
            {
                case "generated":
                    if (project.XsdFile == null || !File.Exists(project.XsdFile.StoredPath))
                    {
                        throw new WorkflowException(WorkflowErrorKind.Conflict, "The project's XSD file is missing.");
                    }

                    return new VT_FileName_Bytes<string, byte[]>($"{SafeFileName(project.Name)}.xml", xmlWriter.Write(project));
                case "workbook":
                {
                    uploadRules.Require(file, UploadKinds.WorkbookToCheck, "Excel workbook");
                    var workbookBytes = await ReadAllAsync(file, cancellationToken);
                    var built = BuildFromFilledTemplate(project, workbookBytes, Path.GetFileName(file.FileName));
                    if (built.Xml == null)
                    {
                        throw new WorkflowException(WorkflowErrorKind.Invalid,
                            $"The values in {Path.GetFileName(file.FileName)} could not all be read, so no XML was built. Correct the cells the validation names first.");
                    }

                    return new VT_FileName_Bytes<string, byte[]>($"{SafeFileName(Path.GetFileNameWithoutExtension(file.FileName))}.xml", built.Xml);
                }
                case "file":
                {
                    uploadRules.Require(file, UploadKinds.XmlToValidate, "XML file");
                    var bytes = await ReadAllAsync(file, cancellationToken);
                    // Excel's export from sheet copies is sent merged, in the XSD's structure, as the Validate page checked it.
                    var merged = SheetCopyMap.Normalize(project, bytes);
                    return merged == null
                        ? new VT_FileName_Bytes<string, byte[]>(Path.GetFileName(file.FileName), bytes)
                        : new VT_FileName_Bytes<string, byte[]>($"{SafeFileName(Path.GetFileNameWithoutExtension(file.FileName))}_merged.xml", merged.Value.Xml);
                }
                default:
                    throw new WorkflowException(WorkflowErrorKind.Invalid, "Choose what to send: the XML built from the project, a filled Excel template or an XML file.");
            }
        }

        private static async Task<byte[]> ReadAllAsync(IFormFile file, CancellationToken cancellationToken)
        {
            using (var stream = file.OpenReadStream())
            using (var buffer = new MemoryStream())
            {
                await stream.CopyToAsync(buffer, 81920, cancellationToken);
                return buffer.ToArray();
            }
        }

        public async Task<XsdValidationResultDto> ValidateUploadedXmlAsync(string projectId, IFormFile xmlFile, CancellationToken cancellationToken,
            IProgress<ValidationProgressDto> progress = null)
        {
            new ValidationStep(progress, 0, 5, "Loading the project").Start();
            var project = await access.GetAsync(projectId, cancellationToken);
            if ((project?.XsdFile) == null || !File.Exists(project.XsdFile.StoredPath))
            {
                return null;
            }

            uploadRules.Require(xmlFile, UploadKinds.XmlToValidate, "XML file");
            new ValidationStep(progress, 5, 8, "Reading the XML file").Start(Path.GetFileName(xmlFile.FileName));
            using (var stream = xmlFile.OpenReadStream())
            {
            using (var buffer = new MemoryStream())
            {
            await stream.CopyToAsync(buffer, cancellationToken);
            var bytes = buffer.ToArray();
            // An XML exported by Excel from sheet copies (CAR_Part_IV_4c_PHP…) is checked in the XSD's structure, as it is stored.
            var normalized = SheetCopyMap.Normalize(project, bytes);
            var xsd = validationService.ValidateBytes(normalized?.Xml ?? bytes, project.XsdFile.StoredPath, Path.GetFileName(xmlFile.FileName), new ValidationStep(progress, 8, 28, "Checking the XML against the XSD"));
            var result = WithSpecificationRules(project, normalized?.Xml ?? bytes, xsd, rules: new ValidationStep(progress, 28, 99, "Checking the BSP specification rules"));
            VT_Xml_Note<byte[], string> n;
            return CompatPattern.Is(normalized, out n)
                ? result.With(copy => { copy.Messages = new XsdValidationMessageDto[] { new XsdValidationMessageDto { Severity = "Info", Message = n.Note } }.Concat((IEnumerable<XsdValidationMessageDto>)result.Messages).ToList(); })
                : result;
            }
            }
        }

        public async Task<XsdValidationResultDto> ValidateFilledTemplateAsync(string projectId, IFormFile workbook, CancellationToken cancellationToken,
            IProgress<ValidationProgressDto> progress = null)
        {
            new ValidationStep(progress, 0, 5, "Loading the project").Start();
            var project = await access.GetAsync(projectId, cancellationToken);
            if ((project?.XsdFile) == null || !File.Exists(project.XsdFile.StoredPath))
            {
                return null;
            }

            uploadRules.Require(workbook, UploadKinds.WorkbookToCheck, "Excel workbook");
            using (var stream = workbook.OpenReadStream())
            {
            using (var buffer = new MemoryStream())
            {
            await stream.CopyToAsync(buffer, cancellationToken);
            return BuildFromFilledTemplate(project, buffer.ToArray(), Path.GetFileName(workbook.FileName), progress).Result;
            }
            }
        }

        public FilledTemplateXml BuildFromFilledTemplate(FrpProjectDto project, byte[] workbookBytes, string fileName,
            IProgress<ValidationProgressDto> progress = null)
        {
            if (project.XsdFile == null || !File.Exists(project.XsdFile.StoredPath))
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, "The project's XSD file is missing.");
            }

            var filled = filledTemplateReader.Read(project, workbookBytes, new ValidationStep(progress, 5, 35, "Reading the values from the template"));
            if (filled.Document == null)
            {
                return new FilledTemplateXml(null, false, new XsdValidationResultDto { Target = fileName, IsValid = false, Messages = filled.Problems });
            }

            new ValidationStep(progress, 35, 38, "Building the XML from the template's values").Start($"{filled.ValuesRead:N0} values");
            byte[] xmlBytes;
            using (var output = new MemoryStream())
            {
                filled.Document.Save(output);
                xmlBytes = output.ToArray();
            }

            var target = $"{fileName} ({filled.ValuesRead:N0} value{(filled.ValuesRead == 1 ? "" : "s")} read from the template)";
            var xsdResult = validationService.ValidateBytes(xmlBytes, project.XsdFile.StoredPath, target, new ValidationStep(progress, 38, 48, "Checking the XML against the XSD"));
            xsdResult = xsdResult.With(copy => { copy.Messages = LocateXsdMessages(project, xmlBytes, xsdResult.Messages, filled.CellByPosition); });
            var locations = filled.CellBySchemaPath.ToDictionary(
                kv => kv.Key,
                kv => new MappingEntryDto { SchemaPath = kv.Key, SheetName = kv.Value.Substring(0, kv.Value.LastIndexOf('!')), CellAddress = kv.Value.Substring(kv.Value.LastIndexOf('!') + 1) },
                StringComparer.Ordinal);
            var result = WithSpecificationRules(project, xmlBytes, xsdResult, locations, new ValidationStep(progress, 48, 99, "Checking the BSP specification rules"));
            var readErrors = filled.Problems.Any(p => p.Severity == "Error");
            result = result.With(copy => { copy.IsValid = result.IsValid && !readErrors; copy.Messages = ((IEnumerable<XsdValidationMessageDto>)filled.Problems).Concat((IEnumerable<XsdValidationMessageDto>)result.Messages).ToList(); });
            var cellsUnreadable = filled.Problems.Any(p => p.Severity == "Error" && p.Cell != null && !p.Message.EndsWith(" is blank.", StringComparison.Ordinal));
            return new FilledTemplateXml(xmlBytes, !cellsUnreadable && filled.ValuesRead > 0, result);
        }

        /// <summary>
        /// Adds the cell and schema path to each XSD message (found from its line in the built XML). A message about a
        /// blank required field is dropped: the reader already reported it with its cell.
        /// </summary>
        private static IReadOnlyList<XsdValidationMessageDto> LocateXsdMessages(FrpProjectDto project, byte[] xmlBytes,
            IReadOnlyList<XsdValidationMessageDto> messages, IReadOnlyDictionary<string, string> cellByPosition)
        {
            if (messages.Count == 0)
            {
                return messages;
            }

            System.Xml.Linq.XDocument document;
            using (var input = new MemoryStream(xmlBytes))
            using (var reader = System.Xml.XmlReader.Create(input, new System.Xml.XmlReaderSettings { DtdProcessing = System.Xml.DtdProcessing.Prohibit, XmlResolver = null }))
            {
                document = System.Xml.Linq.XDocument.Load(reader, System.Xml.Linq.LoadOptions.SetLineInfo);
            }

            var byLine = document.Descendants()
                .Select(e => new VT_Element_Info<System.Xml.Linq.XElement, System.Xml.IXmlLineInfo>(e, (System.Xml.IXmlLineInfo)e))
                .GroupBy(x => x.Info.LineNumber)
                .ToDictionary(g => g.Key, g => g.OrderBy(x => x.Info.LinePosition).ToList());
            var required = project.SchemaNodes.Where(n => n.IsRequired && n.DataType != "complex").Select(n => n.Path).ToHashSet(StringComparer.Ordinal);
            var located = new List<XsdValidationMessageDto>();
            foreach (var message in messages)
            {
                List<VT_Element_Info<System.Xml.Linq.XElement, System.Xml.IXmlLineInfo>> onLine;
                if (message.LineNumber <= 0 || !byLine.TryGetValue(message.LineNumber, out onLine))
                {
                    located.Add(message);
                    continue;
                }

                var element = onLine.LastOrDefault(x => x.Info.LinePosition <= message.LinePosition).Element ?? onLine[0].Element;
                var schemaPath = "/" + string.Join("/", element.AncestorsAndSelf().Reverse().Select(e => e.Name.LocalName));
                if (!element.HasElements && element.Value.Length == 0 && required.Contains(schemaPath))
                {
                    continue;
                }

                located.Add(message.With(copy => { copy.Cell = cellByPosition.GetValueOrDefault(FilledTemplateReader.PositionOf(element)); copy.SchemaPath = schemaPath; }));
            }

            return located;
        }

        /// <summary>Adds the BSP specification rule results (when a specification was uploaded) to an XSD validation result.</summary>
        private XsdValidationResultDto WithSpecificationRules(FrpProjectDto project, byte[] xmlBytes, XsdValidationResultDto xsdResult,
            IReadOnlyDictionary<string, MappingEntryDto> locations = null, ValidationStep rules = null)
        {
            rules?.Start("Reading the XML");
            System.Xml.Linq.XDocument document;
            try
            {
                using (var input = new MemoryStream(xmlBytes))
                {
                using (var reader = System.Xml.XmlReader.Create(input, new System.Xml.XmlReaderSettings { DtdProcessing = System.Xml.DtdProcessing.Prohibit, XmlResolver = null }))
                {
                document = System.Xml.Linq.XDocument.Load(reader);
                }
                }
            }
            catch (System.Xml.XmlException)
            {
                return xsdResult; // Not well-formed: the XSD result already reports it.
            }

            var check = specificationValidator.CheckDocument(project, document, locations, rules);
            if (!check.Checked && check.Issues.Count == 0)
            {
                return xsdResult;
            }

            var messages = xsdResult.Messages.ToList();
            messages.AddRange(check.Issues.Select(issue => new XsdValidationMessageDto
            {
                Severity = issue.Severity,
                Message = $"Specification: {issue.Message}",
                Cell = issue.SheetName != null && issue.CellAddress != null ? $"{issue.SheetName}!{issue.CellAddress}" : null,
                SchemaPath = issue.SchemaPath,
                Rule = issue.Rule,
                BranchCode = issue.BranchCode,
                BranchName = issue.BranchName
            }));
            // Forms made only of lists inside lists cannot be bound in Excel, so an XML exported by Excel lacks them.
            var presentForms = document.Root?.Elements().Select(e => e.Name.LocalName).ToHashSet(StringComparer.Ordinal) ?? new HashSet<string>();
            var unmappable = SheetSplitRules.NotBoundInExcel(project);
            var excelOnlyMissing = project.SchemaNodes
                .Where(n => n.DataType != "complex")
                .GroupBy(n => n.Path.Split('/', StringSplitOptions.RemoveEmptyEntries).ElementAtOrDefault(1) ?? "")
                .Where(g => g.Key.Length > 0 && !presentForms.Contains(g.Key)
                    && g.All(n => unmappable.Any(u => n.Path.StartsWith(u + "/", StringComparison.Ordinal))))
                .Select(g => g.Key)
                .ToList();
            if (excelOnlyMissing.Count > 0)
            {
                messages.Add(new XsdValidationMessageDto
                {
                    Severity = "Info",
                    Message = $"Specification: {string.Join(", ", excelOnlyMissing)} {(excelOnlyMissing.Count == 1 ? "is" : "are")} not in this XML. "
                        + "Excel's XML map does not bind a list inside another list, or a form entered on one sheet per value, so an XML exported "
                        + "from Excel cannot contain " + (excelOnlyMissing.Count == 1 ? "this form" : "these forms")
                        + "; build the XML in the app from the workbook instead."
                });
            }

            var excludedPresent = document.Root?.Elements()
                .Select(e => e.Name.LocalName)
                .Where(name => project.SampleOmittedForms.Contains(name))
                .ToList() ?? new List<string>();
            if (excludedPresent.Count > 0)
            {
                messages.Add(new XsdValidationMessageDto
                {
                    Severity = "Info",
                    Message = $"Specification: this XML contains {string.Join(", ", excludedPresent)}, which the specification says are not submitted "
                        + "for the sample's Header values (the app's XML export and the \"XSD sample values\" template leave them out). "
                        + "Excel's XML export writes every mapped form, even blank ones."
                });
            }
            return xsdResult.With(copy => { copy.IsValid = xsdResult.IsValid && check.RulesFailed == 0 && check.Issues.All(i => i.Severity != "Error"); copy.Messages = messages; copy.SpecificationChecked = check.Checked; copy.SpecRulesPassed = check.RulesPassed; copy.SpecRulesFailed = check.RulesFailed; copy.SpecRulesNotApplicable = check.RulesNotApplicable; copy.SpecRulesNotEvaluated = check.RulesNotEvaluated; copy.SpecRuleForms = check.Forms; });
        }

        /// <summary>The project with every mapped value replaced by its XSD sample value.</summary>
        private FrpProjectDto WithSampleValues(FrpProjectDto project)
        {
            project = WithCurrentSampleValues(project);

            // With a bank chosen (?bank=), the sample is that bank's: its provider code and branches, and — when a BSP
            // sandbox result was imported for this report and specification — that result's period, prior figures and exclusions.
            BankProfileDto bank;
            if (CompatPattern.Is(reference.SampleBank, out bank))
            {
                var scoped = new BankReferenceContext { SampleBankKey = bank.Key, Data = reference.Data.With(copy => { copy.Imports = reference.Data.Imports.Where(i => i.SpecificationHash == project.SpecificationFile?.Sha256).ToList(); }) };
                scoped.SamplePeriod = scoped.LatestImport(bank, project.RootElement, project.TargetNamespace)?.Period;
                project = project.With(copy => { copy.SchemaNodes = project.SchemaNodes.Select(n => WithBankHeader(n, bank, scoped.SamplePeriod)).ToList(); });
                if (project.SpecificationFile != null)
                {
                    var solved = sampleValueSolver.Apply(project.SchemaNodes, project.RootElement, project.TargetNamespace, specificationReader.Read(project.SpecificationFile.StoredPath), scoped);
                    project = project.With(copy => { copy.SchemaNodes = solved.Nodes; copy.SampleRows = solved.SampleRows; copy.SampleOmittedForms = solved.OmittedForms; });
                }

                var ns = System.Xml.Linq.XNamespace.Get(project.TargetNamespace ?? "");
                var sampleRoot = new System.Xml.Linq.XElement(ns + (project.RootElement ?? "FRP"),
                    new System.Xml.Linq.XElement(ns + "Header", project.SchemaNodes.Where(n => n.DataType != "complex" && HeaderField(n.Path) != null)
                        .Select(n => new System.Xml.Linq.XElement(ns + n.Name, n.TestValue))));
                project = project.With(copy => { copy.SampleExcludedSelectors = scoped.Imports(sampleRoot).SelectMany(i => i.Exclusions).Select(e => e.Selector).Distinct().ToList(); });
            }

            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            return project.With(copy => { copy.Mappings = project.Mappings
                    .Select(m => m.With(inner => { inner.DefaultValue = nodesByPath.GetValueOrDefault(m.SchemaPath)?.TestValue; }))
                    .ToList(); });
        }

        private FrpProjectDto WithCurrentSampleValues(FrpProjectDto project)
        {
            try
            {
                var oldNodesByPath = project.SchemaNodes
                    .Where(n => n.DataType != "complex")
                    .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                    .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
                var usedAmounts = project.SchemaNodes.Where(n => n.DataType == "decimal")
                    .Select(n => { decimal value; return decimal.TryParse(n.TestValue, System.Globalization.NumberStyles.Number,
                        System.Globalization.CultureInfo.InvariantCulture, out value) ? value : 0m; })
                    .Where(v => v != 125000.75m).ToHashSet();
                var refreshed = project.SchemaNodes.Select(node => { decimal amount; return node.DataType == "decimal"
                    && decimal.TryParse(node.TestValue, System.Globalization.NumberStyles.Number,
                        System.Globalization.CultureInfo.InvariantCulture, out amount) && amount == 125000.75m
                        ? node.With(copy => { copy.TestValue = XsdTestValueGenerator.Generate(node.Name, node.DataType, node.Validation,
                            sampleKey: node.Path, usedAmounts: usedAmounts); })
                        : node; }).ToList();
                var specification = project.SpecificationFile != null && File.Exists(project.SpecificationFile.StoredPath)
                    ? specificationReader.Read(project.SpecificationFile.StoredPath) : null;
                var refined = (specification == null) ? refreshed : BspSampleValueRefiner.Apply(refreshed, specification);
                var solved = (specification == null) ? null
                    : sampleValueSolver.Apply(refined, project.RootElement, project.TargetNamespace, specification);
                var currentNodes = solved?.Nodes ?? refined;
                var newNodesByPath = currentNodes
                    .Where(n => n.DataType != "complex")
                    .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                    .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);

                var mappings = project.Mappings.Select(mapping =>
                {
                    SchemaNodeDto current;
                    if (!newNodesByPath.TryGetValue(mapping.SchemaPath, out current))
                    {
                        return mapping;
                    }

                    SchemaNodeDto previous;
                    oldNodesByPath.TryGetValue(mapping.SchemaPath, out previous);
                    // A removed value ("") stays removed; NULL, a sample value and a placeholder get the current sample value.
                    var shouldRefresh = mapping.DefaultValue == null
                        || (!XmlSubmissionWriter.IsCleared(mapping)
                            && (string.Equals(mapping.DefaultValue, previous?.TestValue, StringComparison.Ordinal) || LooksGeneratedPlaceholder(mapping.DefaultValue)));
                    return shouldRefresh ? mapping.With(copy => { copy.DefaultValue = current.TestValue; }) : mapping;
                }).ToList();

                return project.With(copy => { copy.SchemaNodes = currentNodes; copy.Mappings = mappings; copy.SampleRows = solved?.SampleRows ?? project.SampleRows; copy.SampleOmittedForms = solved?.OmittedForms ?? project.SampleOmittedForms; });
            }
            catch (Exception ex) when ((ex is InvalidOperationException || ex is InvalidDataException || ex is System.Xml.XmlException || ex is IOException))
            {
                return project;
            }
        }

        private static bool LooksGeneratedPlaceholder(string value) =>
            !string.IsNullOrWhiteSpace(value)
            && (value.Equals("Sample", StringComparison.OrdinalIgnoreCase)
                || value.StartsWith("Sample", StringComparison.OrdinalIgnoreCase)
                || value.Equals("TEST", StringComparison.OrdinalIgnoreCase));

        private static string HeaderField(string path)
        {
            var parts = path.Split('/', StringSplitOptions.RemoveEmptyEntries);
            return parts.Length == 3 && parts[1] == "Header" ? parts[2] : null;
        }

        /// <summary>The bank's provider code in Header/Undertaking; the imported result's year and month in Header/Year and Header/Period.</summary>
        private static SchemaNodeDto WithBankHeader(SchemaNodeDto node, BankProfileDto bank, string period)
        {
            string[] candidates = CompatFn.Let<string, string[]>(HeaderField(node.Path), field => field == "Undertaking" ? ((string[])new string[] { bank.ProviderCode }) : field == "Year" && period != null && object.Equals(period.Length, 7) ? ((string[])new string[] { period.Substring(0, 4) }) : field == "Period" && period != null && object.Equals(period.Length, 7) ? ((string[])new string[] { int.Parse(period.Substring(5), System.Globalization.CultureInfo.InvariantCulture).ToString(System.Globalization.CultureInfo.InvariantCulture), period.Substring(5) }) : ((string[])new string[0]));
            var value = candidates.FirstOrDefault(c => FrpMapper.Shared.Validation.XsdValueValidator.IsValid(c, node));
            return (value == null) ? node : node.With(copy => { copy.TestValue = value; });
        }

        private static IReadOnlyList<MappingEntryDto> CleanMappings(FrpProjectDto project, IReadOnlyList<MappingEntryDto> mappings)
        {
            // Field lengths of frp.Mapping; longer values would not fit, so they are rejected with a clear message.
            foreach (var mapping in mappings)
            {
                if ((mapping.SheetName?.Trim().Length ?? 0) > MaxSheetNameLength
                    || (mapping.CellAddress?.Trim().Length ?? 0) > MaxCellAddressLength
                    || (mapping.Source?.Length ?? 0) > MaxSourceLength)
                {
                    throw new WorkflowException(WorkflowErrorKind.Invalid,
                        $"A mapping has a sheet name longer than {MaxSheetNameLength}, a cell address longer than {MaxCellAddressLength} "
                        + $"or a source longer than {MaxSourceLength} characters.");
                }
            }

            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);

            return mappings
                .Where(m => nodesByPath.ContainsKey(m.SchemaPath) && !string.IsNullOrWhiteSpace(m.SheetName) && !string.IsNullOrWhiteSpace(m.CellAddress))
                .Select(m =>
                {
                    var node = nodesByPath[m.SchemaPath];
                    return m.With(copy => { copy.Id = string.IsNullOrWhiteSpace(m.Id) || m.Id.Length > MaxMappingIdLength || m.Id.Any(char.IsControl) ? Guid.NewGuid().ToString("N") : m.Id; copy.Source = string.IsNullOrWhiteSpace(m.Source) ? "Manual" : m.Source; copy.SheetName = m.SheetName.Trim(); copy.CellAddress = m.CellAddress.Trim().ToUpperInvariant(); copy.SchemaPath = node.Path; copy.DataType = node.DataType; copy.Required = node.IsRequired; copy.DefaultValue = m.DefaultValue == null ? node.TestValue : m.DefaultValue.Trim().Length == 0 ? "" : m.DefaultValue; });
                })
                .ToList();
        }

        private FrpProjectDto WithValidation(FrpProjectDto project, IReadOnlyList<ValidationIssueDto> mappingNotes = null, ValidationStep rules = null)
        {
            var result = projectValidator.Validate(project, rules);
            var issues = new List<ValidationIssueDto>();
            if (project.TemplateGenerated)
            {
                issues.Add(new ValidationIssueDto
                {
                    Severity = "Info",
                    Category = "Mapping",
                    Message = (project.SpecificationFile == null)
                        ? "No BSP template was uploaded, so the input template was generated from the XSD. Upload the BSP specification too for BSP titles, row descriptions and account codes."
                        : "No BSP template was uploaded, so the input template was generated from the XSD, with titles, row descriptions and account codes from the BSP specification."
                });
            }
            else if (project.Workbook == null)
            {
                issues.Add(new ValidationIssueDto
                {
                    Severity = "Info",
                    Category = "Mapping",
                    Message = "No template was uploaded. Each XSD sheet is generated as its own worksheet in the mapped template."
                });
            }

            if (project.SampleOmittedForms.Count > 0)
            {
                var header = project.SchemaNodes
                    .Where(n => { string[] t; return n.DataType != "complex" && CompatPattern.Is(n.Path.Split('/', StringSplitOptions.RemoveEmptyEntries), out t) && object.Equals(t.Length, 3) && t[1] == "Header" && !string.IsNullOrEmpty(n.TestValue); })
                    .Select(n => $"{n.Name} {n.TestValue}");
                issues.Add(new ValidationIssueDto
                {
                    Severity = "Info",
                    Category = "Specification",
                    Message = $"Sample values follow the BSP specification for the sample Header ({string.Join(", ", header)}): "
                        + $"{project.SampleOmittedForms.Count} form(s) are left out of the sample XML and unbound in the \"XSD sample values\" template, "
                        + "because the specification says they are not submitted then: "
                        + string.Join(", ", project.SampleOmittedForms) + "."
                });
            }

            issues.AddRange(mappingNotes ?? new List<ValidationIssueDto>());
            issues.AddRange(result.Issues);
            return project.With(copy => { copy.Issues = issues; copy.Validation = result.With(inner => { inner.Issues = new List<ValidationIssueDto>(); }); });
        }

        /// <summary>
        /// Cell text is only needed while analyzing; the stored project keeps sheet names and counts
        /// (large BSP templates would otherwise produce very large project files and UI payloads).
        /// </summary>
        private static WorkbookSummaryDto ForStorage(WorkbookSummaryDto workbook)
        {
            if (workbook == null)
            {
                return null;
            }

            return workbook.With(copy => { copy.Sheets = workbook.Sheets.Select(s => s.With(inner => { inner.Cells = new List<WorkbookCellDto>(); })).ToList(); copy.ExistingMappings = workbook.ExistingMappings.Take(200).ToList(); });
        }

        /// <summary>" Reused already stored XSD, template." when identical uploads were reused; otherwise empty.</summary>
        private static string ReusedNote(params VT_Label_Upload<string, StoredUpload>[] uploads)
        {
            var reused = uploads.Where(u => u.Upload?.Reused == true).Select(u => u.Label).ToList();
            return reused.Count == 0 ? "" : $" Reused the already stored {string.Join(", ", reused)} (identical content; not stored again).";
        }

        private static string SafeFileName(string value)
        {
            var invalid = Path.GetInvalidFileNameChars().ToHashSet();
            return string.Concat(value.Select(ch => invalid.Contains(ch) ? '_' : ch));
        }

        private Task AuditAsync(string action, FrpProjectDto project, string details, CancellationToken cancellationToken) =>
            auditLog.AppendAsync(new AuditEntryDto
            {
                Id = Guid.NewGuid().ToString("N"),
                At = DateTimeOffset.UtcNow,
                User = currentUser.Name,
                Action = action,
                ProjectId = project.Id,
                ProjectName = project.Name,
                Details = details
            }, cancellationToken);

        public static string Sha256Hex(byte[] bytes) => CompatHex.ToHexString(CompatHash.Sha256(bytes)).ToLowerInvariant();

            private static ReusableFileDto ToReusable(UploadedFileDto file)
    {
        return (file == null) ? null : new ReusableFileDto
        {
            FileName = file.OriginalName,
            Size = file.Size
        };
    }

            private static string Sha(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return null;
        }

        var sha = value.Trim().ToLowerInvariant();
        return sha.Length == 64 && sha.All(Uri.IsHexDigit) ? sha : CompatThrow.As<string>(new WorkflowException(WorkflowErrorKind.Invalid, "A file's SHA-256 must be 64 hexadecimal characters."));
    }

            private static int Problems(XsdValidationResultDto result)
    {
        return result?.Messages.Count(m => string.Equals(m.Severity, "Error", StringComparison.OrdinalIgnoreCase)) ?? 0;
    }
    }

}
