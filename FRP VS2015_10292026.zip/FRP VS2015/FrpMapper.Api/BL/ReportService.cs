﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Maintenance, user extraction and sign-in reports (read only). Each changed field of each processed change is a row
    /// with its original and new value, the Maker who requested it and the Checker who decided it. The original value is
    /// the one recorded with the request, or, for requests made before that was recorded, the value of the previous
    /// approved change. Every report generated is written to the audit trail.
    /// </summary>
    public sealed partial class ReportService: IReportService
    {
        private readonly IReportRepository repository;
        private readonly IAuditLog auditLog;
        private readonly ICurrentUser currentUser;
        private readonly TimeProvider clock;

        public ReportService(IReportRepository repository, IAuditLog auditLog, ICurrentUser currentUser, TimeProvider clock)
    {
        this.repository = repository;
        this.auditLog = auditLog;
        this.currentUser = currentUser;
        this.clock = clock;
    }
        private const int MaxDays = 366;
        private const int MaxSignIns = 10000;
        private const string None = "—";

        public async Task<MaintenanceReportDto> UserMaintenanceAsync(DateOnly from, DateOnly to, CancellationToken cancellationToken)
        {
            RequireAny("see the user maintenance report (SRAU)", Permissions.UsersManage, Permissions.UsersApprove);
            var range = Range(from, to);
            var start = range.Start;
            var end = range.End;
            var history = await repository.GetAccessChangesAsync(end, cancellationToken);
            var rows = AccessRows(history, start, end, new List<string> { AccessKinds.User });
            await AuditAsync("User maintenance", from, to, rows.Count, cancellationToken);
            return new MaintenanceReportDto { From = from, To = to, GeneratedAt = clock.GetUtcNow(), GeneratedBy = currentUser.Name, Categories = new List<string> { ReportCategories.Users }, Rows = rows };
        }

        public async Task<MaintenanceReportDto> ParameterMaintenanceAsync(DateOnly from, DateOnly to, CancellationToken cancellationToken)
        {
            var roles = Has(Permissions.RolesManage, Permissions.RolesApprove);
            var groups = roles || Has(Permissions.UsersManage, Permissions.UsersApprove);
            var banks = Has(Permissions.ReferenceManage, Permissions.ReferenceApprove);
            if (!groups && !banks)
            {
                throw new WorkflowException(WorkflowErrorKind.Forbidden, "Your roles do not allow you to see the parameter maintenance report.");
            }

            var range = Range(from, to);
            var start = range.Start;
            var end = range.End;
            var rows = new List<MaintenanceRowDto>();
            var categories = new List<string>();
            if (groups)
            {
                var kinds = roles ? new[] { AccessKinds.Role, AccessKinds.Groups } : new string[] { AccessKinds.Groups };
                rows.AddRange(AccessRows(await repository.GetAccessChangesAsync(end, cancellationToken), start, end, kinds));
                if (roles) categories.Add(ReportCategories.Roles);
                categories.Add(ReportCategories.DirectoryGroups);
            }

            if (banks)
            {
                rows.AddRange(BankRows(await repository.GetBankChangesAsync(end, cancellationToken), start, end));
                categories.Add(ReportCategories.BankProfiles);
            }

            rows = rows.OrderByDescending(r => r.DecidedAt).ThenBy(r => r.Category).ThenBy(r => r.TargetId, StringComparer.OrdinalIgnoreCase).ToList();
            await AuditAsync("Parameter maintenance", from, to, rows.Count, cancellationToken);
            return new MaintenanceReportDto { From = from, To = to, GeneratedAt = clock.GetUtcNow(), GeneratedBy = currentUser.Name, Categories = categories, Rows = rows };
        }

        public async Task<UserExtractionReportDto> UserExtractionAsync(CancellationToken cancellationToken)
        {
            RequireAny("see the user extraction report (SRAU)", Permissions.UsersManage, Permissions.UsersApprove);
            var data = await repository.GetUsersAsync(cancellationToken);
            var today = DateOnly.FromDateTime(clock.GetLocalNow().DateTime);
            var signIns = data.SignIns.ToDictionary(s => s.UserName, StringComparer.OrdinalIgnoreCase);
            var rows = data.Users.Select(u => { ReportSignIn s; DateOnly until; ReportSignIn last; return new UserExtractionRowDto
            {
                UserId = u.UserName,
                UserName = u.DisplayName,
                Roles = u.Roles.Count == 0 ? (signIns.TryGetValue(u.UserName, out s) && !string.IsNullOrEmpty(s.LastRoles) ? $"{s.LastRoles} (AD groups at last sign-in)" : None) : string.Join(", ", u.Roles),
                Department = u.Department,
                CreatedAt = Utc(u.CreatedAtUtc),
                Status = u.IsDeleted ? "Deleted"
                    : !u.IsActive ? (u.DisabledReason == SignInOutcomes.Locked ? "Locked" : u.DisabledReason == SignInOutcomes.Dormant ? "Deactivated (inactivity)" : "Disabled")
                    : CompatPattern.Is(u.AccessUntil, out until) && until < today ? "Access ended"
                    : "Active",
                LastModifiedAt = Utc(u.UpdatedAtUtc),
                AccessUntil = u.AccessUntil,
                LastSignInAt = signIns.TryGetValue(u.UserName, out last) ? last.LastSignInAt : null,
                Source = "App list"
            }; }).ToList();
            var listed = data.Users.Select(u => u.UserName).ToHashSet(StringComparer.OrdinalIgnoreCase);
            rows.AddRange(data.SignIns.Where(s => !listed.Contains(s.UserName) && s.LastSignInAt != null).Select(s => new UserExtractionRowDto
            {
                UserId = s.UserName,
                Roles = string.IsNullOrEmpty(s.LastRoles) ? None : $"{s.LastRoles} (AD groups at last sign-in)",
                Status = "Active (AD groups)",
                LastSignInAt = s.LastSignInAt,
                Source = "AD groups only"
            }));
            rows = rows.OrderBy(r => r.UserId, StringComparer.OrdinalIgnoreCase).ToList();
            await auditLog.AppendAsync(new AuditEntryDto
            {
                Id = Guid.NewGuid().ToString("N"), At = clock.GetUtcNow(), User = currentUser.Name, Action = "Report generated",
                Details = $"User extraction: {rows.Count} account(s)."
            }, cancellationToken);
            return new UserExtractionReportDto { GeneratedAt = clock.GetUtcNow(), GeneratedBy = currentUser.Name, Rows = rows };
        }

        public async Task<SignInReportDto> SignInsAsync(DateOnly from, DateOnly to, string userName, CancellationToken cancellationToken)
        {
            RequireAny("see the sign-in report (SRAU)", Permissions.UsersManage, Permissions.UsersApprove);
            var range = Range(from, to);
            var start = range.Start;
            var end = range.End;
            var name = string.IsNullOrWhiteSpace(userName) ? null : userName.Trim();
            if (name != null && name.Length > 256 || (name?.Any(char.IsControl) ?? false))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "Enter an account of at most 256 characters.");
            }

            var entries = await repository.GetSignInsAsync(start, end.AddTicks(1), name, MaxSignIns + 1, cancellationToken);
            var truncated = entries.Count > MaxSignIns;
            entries = entries.Take(MaxSignIns).ToList();
            var summary = entries.GroupBy(e => e.User, StringComparer.OrdinalIgnoreCase).Select(g => new SignInSummaryDto
            {
                UserName = g.Key,
                SignedIn = g.Count(e => e.Action == "Signed in"),
                Failed = g.Count(e => e.Action == "Sign-in failed"),
                Blocked = g.Count(e => e.Action == "Sign-in blocked" || e.Action == "Sign-in delayed"),
                Refused = g.Count(e => e.Action == "Sign-in refused"),
                Locked = g.Count(e => e.Action == "Account locked" || e.Action == "Account deactivated"),
                LastFailedAt = g.Where(e => e.Action == "Sign-in failed").Select(e => (DateTimeOffset?)e.At).Max(),
                FailedFrom = g.Where(e => e.Action == "Sign-in failed").Select(AddressOf).OfType<string>()
                    .Distinct(StringComparer.OrdinalIgnoreCase).Order(StringComparer.OrdinalIgnoreCase).ToList()
            }).OrderByDescending(s => s.Failed + s.Blocked + s.Locked).ThenBy(s => s.UserName, StringComparer.OrdinalIgnoreCase).ToList();
            await AuditAsync("Sign-in attempts" + ((name == null) ? "" : $" of {name}"), from, to, entries.Count, cancellationToken);
            return new SignInReportDto
            {
                From = from, To = to, GeneratedAt = clock.GetUtcNow(), GeneratedBy = currentUser.Name, Summary = summary, Entries = entries, Truncated = truncated
            };
        }

        // ------------------------------------------------------------------ maintenance rows

        private static List<MaintenanceRowDto> AccessRows(AccessChangeHistory history, DateTimeOffset start, DateTimeOffset end, IReadOnlyCollection<string> kinds)
        {
            var users = history.Users.ToDictionary(u => u.Key, StringComparer.OrdinalIgnoreCase);
            var roles = history.Roles.ToDictionary(r => r.Key, StringComparer.OrdinalIgnoreCase);
            // The state after the previous approved change of each person, role and role's groups (for old requests).
            var lastUser = new Dictionary<string, UserChangeDto>(StringComparer.OrdinalIgnoreCase);
            var lastRole = new Dictionary<string, RoleChangeDto>(StringComparer.OrdinalIgnoreCase);
            var lastGroups = new Dictionary<string, RoleGroupsChangeDto>(StringComparer.OrdinalIgnoreCase);
            var rows = new List<MaintenanceRowDto>();
            foreach (var request in history.Requests.Where(r => r.DecidedAt != null).OrderBy(r => r.DecidedAt).ThenBy(r => r.RequestedAt))
            {
                var fields = new List<VT_Field_Before_After<string, string, string>>();
                string category;
                string name;
                ReportTarget target;
                {
                    UserChangeDto after;
                    RoleChangeDto after2;
                    RoleGroupsChangeDto after3;
                    if (request.Kind == AccessKinds.User && CompatPattern.Is(request.User, out after))
                    {
                        var userBefore = request.UserBefore ?? lastUser.GetValueOrDefault(request.TargetKey);
                        fields = UserFields(userBefore, after);
                        if (request.Status == AccessRequestStatus.Approved) lastUser[request.TargetKey] = after;
                        category = ReportCategories.Users;
                        target = users.GetValueOrDefault(request.TargetKey);
                        name = after.DisplayName ?? target?.Name;
                    }
                    else if (request.Kind == AccessKinds.Role && CompatPattern.Is(request.Role, out after2))
                    {
                        var roleBefore = request.RoleBefore ?? lastRole.GetValueOrDefault(request.TargetKey);
                        fields = RoleFields(roleBefore, after2);
                        if (request.Status == AccessRequestStatus.Approved) lastRole[request.TargetKey] = after2;
                        category = ReportCategories.Roles;
                        target = roles.GetValueOrDefault(request.TargetKey);
                        name = after2.DisplayName;
                    }
                    else if (request.Kind == AccessKinds.Groups && CompatPattern.Is(request.Groups, out after3))
                    {
                        var groupsBefore = request.GroupsBefore ?? lastGroups.GetValueOrDefault(request.TargetKey);
                        fields = new List<VT_Field_Before_After<string, string, string>> { new VT_Field_Before_After<string, string, string>("AD groups", (groupsBefore == null) ? None : List(groupsBefore.DirectoryGroups), List(after3.DirectoryGroups)) };
                        if (request.Status == AccessRequestStatus.Approved) lastGroups[request.TargetKey] = after3;
                        category = ReportCategories.DirectoryGroups;
                        target = roles.GetValueOrDefault(request.TargetKey);
                        name = target?.Name;
                    }
                    else
                    {
                        continue;
                    }
                }

                if (!kinds.Contains(request.Kind) || request.DecidedAt < start || request.DecidedAt > end)
                {
                    continue;
                }

                rows.AddRange(Rows(request, category, name, target, fields, request.Summary));
            }

            return rows.OrderByDescending(r => r.DecidedAt).ToList();
        }

        private static IEnumerable<MaintenanceRowDto> BankRows(BankChangeHistory history, DateTimeOffset start, DateTimeOffset end)
        {
            var banks = history.Banks.ToDictionary(b => b.Key, StringComparer.OrdinalIgnoreCase);
            return history.Requests.Where(r => { DateTimeOffset at; return CompatPattern.Is(r.DecidedAt, out at) && at >= start && at <= end; }).SelectMany(request =>
            {
                var target = banks.GetValueOrDefault(request.BankKey);
                var fields = request.Changes.Select(c => new VT_Field_Before_After<string, string, string>(c.Field, c.Before, c.After)).ToList();
                var fromCreate = (target == null) ? null : new ReportTarget(target.Key, request.Proposed.Name, target.CreatedAtUtc, target.UpdatedAtUtc);
                return Rows(new AccessChangeRequestDto
                {
                    TargetKey = request.BankKey, Status = request.Status, RequestedBy = request.RequestedBy, RequestedAt = request.RequestedAt,
                    DecidedBy = request.DecidedBy, DecidedAt = request.DecidedAt, DecisionComment = request.DecisionComment
                }, ReportCategories.BankProfiles, request.Proposed.Name, fromCreate, fields, request.Summary);
            });
        }

        private static IEnumerable<MaintenanceRowDto> Rows(AccessChangeRequestDto request, string category, string name, ReportTarget target,
            List<VT_Field_Before_After<string, string, string>> fields, string summary)
        {
            var changed = fields.Where(f => !string.Equals(f.Before, f.After, StringComparison.Ordinal)).ToList();
            if (changed.Count == 0)
            {
                changed.Add(new VT_Field_Before_After<string, string, string>("(summary)", None, summary));
            }

            return changed.Select(f => { DateTime updated; return new MaintenanceRowDto
            {
                Category = category,
                TargetId = request.TargetKey,
                TargetName = name,
                CreatedAt = (target == null) ? (DateTimeOffset?)null : (DateTimeOffset?)Utc(target.CreatedAtUtc),
                LastModifiedAt = CompatPattern.Is(target?.UpdatedAtUtc, out updated) ? (DateTimeOffset?)Utc(updated) : (DateTimeOffset?)null,
                Field = f.Field,
                Before = f.Before,
                After = f.After,
                Status = request.Status,
                Maker = request.RequestedBy,
                RequestedAt = request.RequestedAt,
                Approver = request.DecidedBy,
                DecidedAt = request.DecidedAt,
                Comment = request.DecisionComment
            }; });
        }

        private static List<VT_Field_Before_After<string, string, string>> UserFields(UserChangeDto before, UserChangeDto after)
        {
            return
            new List<VT_Field_Before_After<string, string, string>> { new VT_Field_Before_After<string, string, string>("Status", Status(before), Status(after)), new VT_Field_Before_After<string, string, string>("Display name", Text(before?.DisplayName, before), Text(after.Delete ? before?.DisplayName : after.DisplayName, after)), new VT_Field_Before_After<string, string, string>("Branch / department", Text(before?.Department, before), Text(after.Department, after)), new VT_Field_Before_After<string, string, string>("Access until", (before == null) ? None : Date(before.AccessUntil), Date(after.AccessUntil)), new VT_Field_Before_After<string, string, string>("Roles", (before == null) ? None : List(before.Roles), after.Delete ? None : List(after.Roles)) };
        }

        private static List<VT_Field_Before_After<string, string, string>> RoleFields(RoleChangeDto before, RoleChangeDto after)
        {
            return
            new List<VT_Field_Before_After<string, string, string>> { new VT_Field_Before_After<string, string, string>("Status", StatusLocal(before), StatusLocal(after)), new VT_Field_Before_After<string, string, string>("Name", Text(before?.DisplayName, before), Text(after.DisplayName, after)), new VT_Field_Before_After<string, string, string>("Description", Text(before?.Description, before), Text(after.Description, after)), new VT_Field_Before_After<string, string, string>("Permissions", (before == null) ? None : List(before.Permissions), after.Delete ? None : List(after.Permissions)) };
        }

        private static string Text(string value, object owner) => owner == null || string.IsNullOrWhiteSpace(value) ? None : value.Trim();
        private static string Date(DateOnly? value) => value?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) ?? "no end";
        private static string List(IEnumerable<string> values) => values.Any() ? string.Join(", ", values.Order(StringComparer.OrdinalIgnoreCase)) : "none";
        private static DateTimeOffset Utc(DateTime value) => new DateTimeOffset(DateTime.SpecifyKind(value, DateTimeKind.Utc));

        // ------------------------------------------------------------------ helpers

        /// <summary>From the start of <paramref name="from"/> to the end of <paramref name="to"/>, in the server's local time.</summary>
        private VT_Start_End<DateTimeOffset, DateTimeOffset> Range(DateOnly from, DateOnly to)
        {
            if (to < from || to.DayNumber - from.DayNumber >= MaxDays)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"Choose a date range of at most {MaxDays} days, with the start on or before the end.");
            }

            var zone = clock.LocalTimeZone;
            Func<DateOnly, DateTimeOffset> Local = null;
            Local = (DateOnly day) =>
            {
                var local = day.ToDateTime(TimeOnly.MinValue);
                return new DateTimeOffset(local, zone.GetUtcOffset(local));
            };
            return new VT_Start_End<DateTimeOffset, DateTimeOffset>(Local(from), Local(to.AddDays(1)).AddTicks(-1));
        }

        private bool Has(params string[] permissions) => currentUser.IsAuthenticated && permissions.Any(currentUser.HasPermission);

        private void RequireAny(string what, params string[] permissions)
        {
            if (!Has(permissions))
            {
                throw new WorkflowException(WorkflowErrorKind.Forbidden, $"Your roles do not allow you to {what}.");
            }
        }

        private Task AuditAsync(string report, DateOnly from, DateOnly to, int rows, CancellationToken cancellationToken) =>
            auditLog.AppendAsync(new AuditEntryDto
            {
                Id = Guid.NewGuid().ToString("N"), At = clock.GetUtcNow(), User = currentUser.Name, Action = "Report generated",
                Details = $"{report}: {from:yyyy-MM-dd} to {to:yyyy-MM-dd}, {rows} row(s)."
            }, cancellationToken);

        /// <summary>The address of a sign-in entry: its recorded client address, or (entries recorded before the address was kept) the one in the details.</summary>
        private static string AddressOf(AuditEntryDto entry)  {
        string address;
        Match match;
        return (CompatPattern.Is(entry.Address, out address) && address.Length > 0) ? address : (CompatPattern.Is(AddressRegex().Match(entry.Details ?? ""), out match) && object.Equals(match.Success, true)) ? match.Groups[1].Value : null;
    }

            private static System.Text.RegularExpressions.Regex AddressRegex() { return AddressRegexInstance; }

            private static string Status(UserChangeDto u)
    {
        return (u == null) ? None : u.Delete ? "Deleted" : u.IsActive ? "Active" : "Disabled";
    }

            private static string StatusLocal(RoleChangeDto r)
    {
        return (r == null) ? None : r.Delete ? "Deleted" : r.IsActive ? "Active" : "Disabled";
    }

        private static readonly System.Text.RegularExpressions.Regex AddressRegexInstance = new System.Text.RegularExpressions.Regex(@"^From ([^;\s]+?)(?:;|\.?\s*$)", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

}
