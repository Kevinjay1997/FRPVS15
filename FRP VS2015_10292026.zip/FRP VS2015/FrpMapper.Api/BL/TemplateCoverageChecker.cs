﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Opens an Excel workbook and checks its XML map against the project's XSD: which leaf elements are bound
    /// (single cells or XML list-table columns), which are not, and which bindings Excel cannot export
    /// (a repeating element bound to a single cell, an element bound twice, a path the XSD does not have).
    /// This is the same information as Excel's XML Source pane (bound elements shown in bold).
    /// </summary>
    public sealed class TemplateCoverageChecker
    {
        private static readonly XNamespace Main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        private static readonly XNamespace Rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        private static readonly XNamespace PackageRel = "http://schemas.openxmlformats.org/package/2006/relationships";
        private const int MaxListedFields = 2000;

        public TemplateCoverageDto Check(FrpProjectDto project, byte[] workbookBytes, string fileName)
        {
            ZipArchive archive;
            try
            {
                archive = new ZipArchive(new MemoryStream(workbookBytes), ZipArchiveMode.Read);
            }
            catch (InvalidDataException)
            {
                return new TemplateCoverageDto { FileName = fileName, Problems = new List<string> { "The file is not an Excel .xlsx workbook." } };
            }

            using (archive)
            {
                try
                {
                    return CheckArchive(project, archive, fileName);
                }
                catch (XmlException ex)
                {
                    return new TemplateCoverageDto { FileName = fileName, Problems = new List<string> { $"The workbook contains an unreadable part: {ex.Message}" } };
                }
            }
        }

        private static TemplateCoverageDto CheckArchive(FrpProjectDto project, ZipArchive archive, string fileName)
        {
            var problems = new List<string>();
            var maps = Load(archive, "xl/xmlMaps.xml")?.Root;
            var map = maps?.Elements(Main + "Map")
                .FirstOrDefault(m => string.Equals((string)m.Attribute("RootElement"), project.RootElement, StringComparison.Ordinal))
                ?? maps?.Elements(Main + "Map").FirstOrDefault();
            if (map == null)
            {
                return Summarize(project, fileName, false, null, false, new List<VT_Path_Where<string, string>>(), new List<VT_Path_Where<string, string>>(), new List<string> { "The workbook has no XML map (Developer > Source shows no maps)." });
            }

            var mapId = (string)map.Attribute("ID") ?? "1";
            var schemaId = (string)map.Attribute("SchemaID");
            var mapNamespace = (string)maps.Elements(Main + "Schema")
                .FirstOrDefault(s => (string)s.Attribute("ID") == schemaId)?.Attribute("Namespace");
            var matchesXsd = string.Equals((string)map.Attribute("RootElement"), project.RootElement, StringComparison.Ordinal)
                && string.Equals(mapNamespace ?? "", project.TargetNamespace ?? "", StringComparison.Ordinal);
            if (!matchesXsd)
            {
                problems.Add($"The XML map '{(string)map.Attribute("Name")}' is for root '{(string)map.Attribute("RootElement")}' ({mapNamespace}), not this XSD's '{project.RootElement}' ({project.TargetNamespace}).");
            }

            var singles = new List<VT_Path_Where<string, string>>();
            var lists = new List<VT_Path_Where<string, string>>();
            foreach (var sheet in Sheets(archive))
            {
                var sheetName = sheet.Name;
                var worksheetPath = sheet.WorksheetPath;
                var directory = worksheetPath.Contains('/') ? worksheetPath.Substring(0, worksheetPath.LastIndexOf('/')) : "xl/worksheets";
                var rels = Load(archive, $"{directory}/_rels/{worksheetPath.Substring(worksheetPath.LastIndexOf('/') + 1)}.rels")?.Root;
                foreach (var relationship in rels?.Elements(PackageRel + "Relationship") ?? new List<XElement>())
                {
                    var type = (string)relationship.Attribute("Type") ?? "";
                    var isSingleCells = type.EndsWith("/tableSingleCells", StringComparison.OrdinalIgnoreCase);
                    var isTable = type.EndsWith("/table", StringComparison.OrdinalIgnoreCase);
                    if (!isSingleCells && !isTable || (string)relationship.Attribute("TargetMode") == "External")
                    {
                        continue; // drawings, comments, printer settings... are not XML map bindings
                    }

                    var part = Load(archive, Normalize(directory, (string)relationship.Attribute("Target") ?? ""))?.Root;
                    if (part == null)
                    {
                        continue;
                    }

                    if (isSingleCells)
                    {
                        foreach (var cell in part.Elements(Main + "singleXmlCell"))
                        {
                            var pr = cell.Descendants(Main + "xmlPr").FirstOrDefault();
                            if (pr != null && (string)pr.Attribute("mapId") == mapId)
                            {
                                singles.Add(new VT_Path_Where<string, string>(StripPrefixes((string)pr.Attribute("xpath")), $"{sheetName}!{(string)cell.Attribute("r")}"));
                            }
                        }
                    }
                    else if ((string)part.Attribute("tableType") == "xml")
                    {
                        foreach (var column in part.Descendants(Main + "xmlColumnPr").Where(c => (string)c.Attribute("mapId") == mapId))
                        {
                            lists.Add(new VT_Path_Where<string, string>(StripPrefixes((string)column.Attribute("xpath")), $"{sheetName} table {(string)part.Attribute("name")}"));
                        }
                    }
                }
            }

            return Summarize(project, fileName, true, (string)map.Attribute("RootElement"), matchesXsd, singles, lists, problems);
        }

        private static TemplateCoverageDto Summarize(
            FrpProjectDto project,
            string fileName,
            bool mapFound,
            string mapRoot,
            bool matchesXsd,
            IReadOnlyList<VT_Path_Where<string, string>> singles,
            IReadOnlyList<VT_Path_Where<string, string>> lists,
            List<string> problems)
        {
            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.Ordinal)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.Ordinal);
            var leaves = project.SchemaNodes.Where(n => n.DataType != "complex").ToList();
            var notBindable = SheetSplitRules.NotBoundInExcel(project);
            var splitGroups = SheetSplitRules.Resolve(project).Select(s => s.Form.GroupPath).ToList();

            // Forms whose item the map lets occur once (SheetSplitRules.ExcelItemForms): their own fields are single cells.
            var excelItems = SheetSplitRules.ExcelItemForms(project);
            Func<string, bool> OwnFieldOfExcelItem = null;
            OwnFieldOfExcelItem = (string pathArg) =>
            {
                return excelItems.Any(f => pathArg.StartsWith(f.GroupPath + "/", StringComparison.Ordinal) && !f.NestedLists.Any(l => pathArg.StartsWith(l.ItemPath + "/", StringComparison.Ordinal)));
            };

            // Sheet copies are bound through clone elements (CAR_Part_IV_4c_PHP/...): each counts for the XSD's own field,
            // and every copy binding it once is expected, not a duplicate.
            var copies = SheetCopyMap.Copies(project);
            var copyBound = new HashSet<string>(StringComparer.Ordinal);
            Func<VT_Path_Where<string, string>, VT_Path_Where<string, string>> Translate = null;
            Translate = (VT_Path_Where<string, string> binding) =>
            {
                var formPath = SheetCopyMap.ToForm(copies, binding.Path);
                if (formPath == null)
                {
                    return binding;
                }
        
                copyBound.Add(formPath);
                return new VT_Path_Where<string, string>("", binding.Where);
            };

            singles = singles.Select(Translate).Where(b => b.Path.Length > 0).ToList();
            lists = lists.Select(Translate).Where(b => b.Path.Length > 0).ToList();

            foreach (var entry in singles)
            {
                var path = entry.Path;
                var where = entry.Where;
                SchemaNodeDto node;
                if (!nodesByPath.TryGetValue(path, out node))
                {
                    problems.Add($"{where} is bound to {path}, which is not in the XSD.");
                }
                else if (node.IsInRepeatingGroup && !OwnFieldOfExcelItem(path))
                {
                    problems.Add($"{where} binds the repeating element {path} to a single cell; Excel cannot export it. Use an XML list table.");
                }
            }

            foreach (var list2 in lists.Where(l => !nodesByPath.ContainsKey(l.Path)))
            {
                var path = list2.Path;
                var where = list2.Where;
                problems.Add($"{where} has a column bound to {path}, which is not in the XSD.");
            }

            foreach (var duplicate in singles.Concat(lists).GroupBy(b => b.Path, StringComparer.Ordinal).Where(g => g.Count() > 1))
            {
                problems.Add($"{duplicate.Key} is bound {duplicate.Count()} times ({string.Join(", ", duplicate.Select(d => d.Where).Take(3))}); Excel allows one binding per element.");
            }

            var singlePaths = singles.Select(s => s.Path).ToHashSet(StringComparer.Ordinal);
            var listPaths = lists.Select(l => l.Path).ToHashSet(StringComparer.Ordinal);

            // Forms the specification excludes for the sample's Header values, left completely unbound on purpose.
            var leftOutForms = project.SampleOmittedForms
                .Where(form => !singlePaths.Concat(listPaths).Any(p => p.StartsWith($"/{project.RootElement}/{form}/", StringComparison.Ordinal)))
                .ToHashSet(StringComparer.Ordinal);
            var leftOutCount = 0;
            var unbound = new List<TemplateUnboundFieldDto>();
            var sheets = new Dictionary<string, VT_Total_Bound_Unbound_NotBindable<int, int, int, int>>(StringComparer.Ordinal);
            var boundSingle = 0;
            var boundList = 0;
            var notBindableCount = 0;

            foreach (var leaf in leaves)
            {
                var tokens = leaf.Path.Split('/', StringSplitOptions.RemoveEmptyEntries);
                var sheet = tokens.Length >= 2 ? tokens[1] : tokens.FirstOrDefault() ?? "";
                var stats = sheets.GetValueOrDefault(sheet);
                stats.Total++;
                if (leftOutForms.Contains(sheet))
                {
                    leftOutCount++;
                }
                else if (singlePaths.Contains(leaf.Path) && (!leaf.IsInRepeatingGroup || OwnFieldOfExcelItem(leaf.Path)))
                {
                    boundSingle++;
                    stats.Bound++;
                }
                else if (listPaths.Contains(leaf.Path))
                {
                    boundList++;
                    stats.Bound++;
                }
                else if (copyBound.Contains(leaf.Path))
                {
                    // Bound on every sheet copy (single cells for the item, list tables for its lists).
                    if (leaf.Path.Count(c => c == '/') > 3 && project.SchemaNodes.Any(n => n.IsRepeating && leaf.Path.StartsWith(n.Path + "/", StringComparison.Ordinal)
                            && !splitGroups.Contains(n.Path)))
                    {
                        boundList++;
                    }
                    else
                    {
                        boundSingle++;
                    }

                    stats.Bound++;
                }
                else if (notBindable.Any(group => leaf.Path.StartsWith(group + "/", StringComparison.Ordinal)))
                {
                    notBindableCount++;
                    stats.NotBindable++;
                    unbound.Add(new TemplateUnboundFieldDto
                    {
                        SchemaPath = leaf.Path,
                        Reason = splitGroups.Any(group => leaf.Path.StartsWith(group + "/", StringComparison.Ordinal))
                            ? "Entered on one sheet per key value (sheet copies); the app reads every sheet and its Submission XML includes them."
                            : "Excel cannot bind a list inside another list (XSD structure); the app's Submission XML export includes it."
                    });
                }
                else
                {
                    stats.Unbound++;
                    unbound.Add(new TemplateUnboundFieldDto
                    {
                        SchemaPath = leaf.Path,
                        Reason = leaf.IsInRepeatingGroup ? "Not bound: repeating element needs an XML list-table column." : "Not bound to any cell."
                    });
                }

                sheets[sheet] = stats;
            }

            var unboundCount = unbound.Count - notBindableCount;
            return new TemplateCoverageDto
            {
                FileName = fileName,
                XmlMapFound = mapFound,
                MapRootElement = mapRoot,
                MatchesXsd = matchesXsd,
                IsComplete = mapFound && matchesXsd && unboundCount == 0 && problems.Count == 0,
                TotalFields = leaves.Count,
                BoundSingleCells = boundSingle,
                BoundListColumns = boundList,
                Unbound = unboundCount,
                NotBindableInExcel = notBindableCount,
                LeftOutBySpecification = leftOutCount,
                LeftOutForms = leftOutForms.Order(StringComparer.Ordinal).ToList(),
                Sheets = sheets.Select(kv => new TemplateSheetCoverageDto
                {
                    XsdSheet = kv.Key,
                    Total = kv.Value.Total,
                    Bound = kv.Value.Bound,
                    Unbound = kv.Value.Unbound,
                    NotBindableInExcel = kv.Value.NotBindable
                }).ToList(),
                // Real gaps first, then the fields Excel cannot bind.
                UnboundFields = unbound
                    .OrderBy(u => u.Reason.StartsWith("Excel cannot", StringComparison.Ordinal) ? 1 : 0)
                    .Take(MaxListedFields)
                    .ToList(),
                Problems = problems.Take(200).ToList()
            };
        }

        internal static IEnumerable<VT_Name_WorksheetPath<string, string>> Sheets(ZipArchive archive)
        {
            var workbook = Load(archive, "xl/workbook.xml")?.Root;
            var rels = Load(archive, "xl/_rels/workbook.xml.rels")?.Root;
            var targets = rels?.Elements(PackageRel + "Relationship")
                .ToDictionary(r => (string)r.Attribute("Id") ?? "", r => (string)r.Attribute("Target") ?? "") ?? new Dictionary<string, string>();
            foreach (var sheet in workbook?.Descendants(Main + "sheet") ?? new List<XElement>())
            {
                string target;
                if (targets.TryGetValue((string)sheet.Attribute(Rel + "id") ?? "", out target))
                {
                    yield return new VT_Name_WorksheetPath<string, string>((string)sheet.Attribute("name") ?? "", Normalize("xl", target));
                }
            }
        }

        internal static XDocument Load(ZipArchive archive, string path)
        {
            var entry = archive.GetEntry(path);
            if (entry == null)
            {
                return null;
            }

            using (var stream = entry.Open())
            {
            using (var reader = XmlReader.Create(stream, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null }))
            {
            return XDocument.Load(reader);
            }
            }
        }

        internal static string Normalize(string basePath, string target)
        {
            var combined = target.StartsWith('/') ? target.TrimStart('/') : $"{basePath.TrimEnd('/')}/{target}";
            var parts = new Stack<string>();
            foreach (var part in combined.Split('/', StringSplitOptions.RemoveEmptyEntries))
            {
                if (part == ".")
                {
                    continue;
                }

                if (part == "..")
                {
                    if (parts.Count > 0)
                    {
                        parts.Pop();
                    }

                    continue;
                }

                parts.Push(part);
            }

            return string.Join("/", parts.Reverse());
        }

        internal static string StripPrefixes(string xpath)
        {
            return "/" + string.Join("/", (xpath ?? "").Split('/', StringSplitOptions.RemoveEmptyEntries)
                .Select(p => p.Contains(':') ? p.Substring(p.IndexOf(':') + 1) : p));
        }
    }

}
