﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>What went wrong with a workflow action; the API maps it to 403, 409 or 400.</summary>
    public enum WorkflowErrorKind
    {
        /// <summary>The user's role or segregation of duties does not allow the action (403).</summary>
        Forbidden,
        /// <summary>The project's status does not allow the action (409).</summary>
        Conflict,
        /// <summary>The request is incomplete, e.g. a required comment is missing (400).</summary>
        Invalid
    }

    public sealed class WorkflowException: Exception{

        public WorkflowException(WorkflowErrorKind kind, string message) : base(message)
    {
        this.Kind = kind;
    }
        public WorkflowErrorKind Kind { get; } }

    /// <summary>
    /// Segregation-of-duties rules for the Maker / Checker workflow, enforced by the business layer for every action
    /// (the API's permission policies are a first gate; these rules also cover a person holding several roles):
    /// - each action needs its permission (which roles hold which permission is data in the database);
    /// - nobody who created, edited, attached, submitted, withdrew or reopened a project may approve or return it;
    /// - a project can change only while Draft or Returned; InReview and Approved projects are frozen.
    /// </summary>
    public static class WorkflowRules
    {
        public const int MaxCommentLength = 2000;

        public static void RequirePermission(ICurrentUser user, string permission, string action)
        {
            if (!user.IsAuthenticated || !user.HasPermission(permission))
            {
                throw new WorkflowException(WorkflowErrorKind.Forbidden, $"Your roles do not allow you to {action}.");
            }
        }

        public static void RequireEditable(FrpProjectDto project, ICurrentUser user, string permission, string action)
        {
            RequirePermission(user, permission, action);
            if (!(project.Workflow.Status == ProjectStatus.Draft || project.Workflow.Status == ProjectStatus.Returned))
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict,
                    $"The project is {Describe(project.Workflow.Status)}, so it cannot change. "
                    + (project.Workflow.Status == ProjectStatus.InReview ? "Withdraw it from review first." : "Reopen it first; this voids the approval."));
            }
        }

        public static void RequireIndependentReviewer(FrpProjectDto project, ICurrentUser user, string action)
        {
            RequirePermission(user, Permissions.SubmissionReview, action);
            if (project.Workflow.Status != ProjectStatus.InReview)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, $"Only a project in review can be {action}d; this one is {Describe(project.Workflow.Status)}.");
            }

            if (IsContributor(project, user.Name))
            {
                throw new WorkflowException(WorkflowErrorKind.Forbidden,
                    "Segregation of duties: you prepared or changed this project, so another Checker must review it.");
            }
        }

        public static bool IsContributor(FrpProjectDto project, string userName) =>
            project.Workflow.Contributors.Contains(userName, StringComparer.OrdinalIgnoreCase)
            || string.Equals(project.Workflow.CreatedBy, userName, StringComparison.OrdinalIgnoreCase);

        public static string CleanComment(string comment, bool required, string purpose)
        {
            var text = comment?.Trim();
            if (string.IsNullOrEmpty(text))
            {
                return required ? (string)CompatThrow.As<string>(new WorkflowException(WorkflowErrorKind.Invalid, $"A comment is required {purpose}.")) : (string)null;
            }

            if (text.Length > MaxCommentLength)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"The comment is longer than {MaxCommentLength} characters.");
            }

            return new string(text.Where(ch => !char.IsControl(ch) || ch == '\n' || ch == '\r' || ch == '\t').ToArray());
        }

        /// <summary>The workflow after a Maker changed the project (edit, attach, submit, withdraw, reopen).</summary>
        public static ProjectWorkflowDto Touched(ProjectWorkflowDto workflow, ICurrentUser user, DateTimeOffset at) => workflow.With(copy => { copy.LastModifiedBy = user.Name; copy.LastModifiedAt = at; copy.Contributors = workflow.Contributors.Contains(user.Name, StringComparer.OrdinalIgnoreCase)
                ? workflow.Contributors
                : ((IEnumerable<string>)workflow.Contributors).Concat(new string[] { user.Name }).ToList(); });

        public static string Describe(ProjectStatus status) => status == ProjectStatus.Draft ? "a draft" : status == ProjectStatus.InReview ? "in review" : status == ProjectStatus.Returned ? "returned for changes" : status == ProjectStatus.Approved ? "approved" : status.ToString();
    }

}
