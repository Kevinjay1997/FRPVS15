﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    public sealed partial class OpenXmlMappedTemplateWriter
    {
        /// <summary>
        /// Writes the extra sample rows the BSP specification requires (e.g. one FRP_11A234 row per Bookcode, three
        /// BCCR months per branch) below the data row of the XML list table bound to that repeating item, and grows
        /// the table so Excel exports them. Only while the list's first row still holds the sample values, and only
        /// where the rows below the table are free (no values, merges, other tables or mapped cells).
        /// </summary>
        /// <returns>Item paths whose sample rows could not be placed.</returns>
        private static IReadOnlyList<string> WriteSampleRows(ZipArchive archive, FrpProjectDto project, IReadOnlyList<MappingEntryDto> mappings)
        {
            var skipped = new List<string>();
            if (project.SampleRows.Count == 0)
            {
                return skipped;
            }

            var nodesByPath = project.SchemaNodes
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var groups = project.SampleRows
                .GroupBy(r => r.ItemPath, StringComparer.OrdinalIgnoreCase)
                .Where(g => FirstRowIsSample(project, mappings, nodesByPath, g.Key))
                .ToDictionary(g => g.Key, g => g.ToList(), StringComparer.OrdinalIgnoreCase);
            if (groups.Count == 0)
            {
                return skipped;
            }

            var placed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var sharedStrings = ReadSharedStrings(archive);
            foreach (var sheet in ReadSheets(archive))
            {
                var document = ReadXml(archive, sheet.WorksheetPath);
                var worksheet = document?.Root;
                var sheetData = worksheet?.Element(Main + "sheetData");
                if (worksheet == null || sheetData == null)
                {
                    continue;
                }

                var directory = Path.GetDirectoryName(sheet.WorksheetPath)?.Replace('\\', '/') ?? "xl/worksheets";
                var rels = ReadXml(archive, $"{directory}/_rels/{Path.GetFileName(sheet.WorksheetPath)}.rels");
                var changed = false;
                foreach (var relationship in rels?.Root?.Elements(PackageRel + "Relationship") ?? new List<XElement>())
                {
                    var target = (string)relationship.Attribute("Target");
                    if (target == null || !((string)relationship.Attribute("Type") ?? "").EndsWith("/table", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    var tablePath = NormalizePartPath(directory, target);
                    var table = ReadXml(archive, tablePath);
                    var tableRoot = table?.Root;
                    VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int> area;
                    if (tableRoot == null || !TryParseRange((string)tableRoot.Attribute("ref"), out area))
                    {
                        continue;
                    }

                    // Columns without an XML binding (BSP-computed columns) are allowed; they get the data row's style
                    // and the table's calculated-column formula, if any.
                    var tableColumns = tableRoot.Descendants(Main + "tableColumn").ToList();
                    var columnPaths = tableColumns
                        .Select(c => SchemaPathOf((string)c.Element(Main + "xmlColumnPr")?.Attribute("xpath")))
                        .ToList();
                    var bound = columnPaths.Where(p => p != null).ToList();
                    var itemPath = bound.Count == 0 ? null : groups.Keys.FirstOrDefault(item =>
                        !placed.Contains(item) && bound.All(p => p.StartsWith(item + "/", StringComparison.OrdinalIgnoreCase)));
                    if (itemPath == null || columnPaths.Count != area.LastColumn - area.FirstColumn + 1)
                    {
                        continue;
                    }

                    var rows = groups[itemPath];
                    var dataRow = area.LastRow;
                    var blocked = BlockedAreas(archive, sheet.WorksheetPath, worksheet)
                        .Where(b => b != area)
                        .ToList();
                    var free = Enumerable.Range(dataRow + 1, rows.Count).All(row =>
                        Enumerable.Range(area.FirstColumn, area.LastColumn - area.FirstColumn + 1).All(column =>
                            string.IsNullOrEmpty(CellText(sheetData, ColumnName(column), row, sharedStrings))
                            && !blocked.Any(b => b.FirstRow <= row && b.LastRow >= row && b.FirstColumn <= column && b.LastColumn >= column)));
                    if (!free)
                    {
                        continue;
                    }

                    for (var k = 0; k < rows.Count; k++)
                    {
                        for (var i = 0; i < columnPaths.Count; i++)
                        {
                            var columnName = ColumnName(area.FirstColumn + i);
                            var template = GetOrCreateCell(sheetData, columnName, dataRow);
                            var cell = GetOrCreateCell(sheetData, columnName, dataRow + 1 + k);
                            XAttribute style;
                            if (CompatPattern.Is(template.Attribute("s"), out style))
                            {
                                cell.SetAttributeValue("s", style.Value);
                            }

                            string columnPath;
                            if (!CompatPattern.Is(columnPaths[i], out columnPath))
                            {
                                var calculated = (string)tableColumns[i].Element(Main + "calculatedColumnFormula");
                                if (!string.IsNullOrEmpty(calculated))
                                {
                                    cell.Elements(Main + "f").Remove();
                                    cell.Elements(Main + "v").Remove();
                                    cell.AddFirst(new XElement(Main + "f", calculated));
                                }

                                continue;
                            }

                            string value;
                            rows[k].Values.TryGetValue(columnPath, out value);
                            SetCellValue(cell, string.IsNullOrEmpty(value) ? null : value, nodesByPath.GetValueOrDefault(columnPath)?.DataType ?? "string");
                        }
                    }

                    var reference = $"{ColumnName(area.FirstColumn)}{area.FirstRow}:{ColumnName(area.LastColumn)}{dataRow + rows.Count}";
                    tableRoot.SetAttributeValue("ref", reference);
                    tableRoot.Element(Main + "autoFilter")?.SetAttributeValue("ref", reference);
                    UpsertEntry(archive, tablePath, table.ToString(SaveOptions.DisableFormatting));
                    placed.Add(itemPath);
                    changed = true;
                }

                if (changed)
                {
                    UpsertEntry(archive, sheet.WorksheetPath, document.ToString(SaveOptions.DisableFormatting));
                }
            }

            skipped.AddRange(groups.Keys.Where(k => !placed.Contains(k)));
            return skipped;
        }

        /// <summary>The list's first row still holds the sample values (the bank has not entered its own data there).</summary>
        private static bool FirstRowIsSample(FrpProjectDto project, IReadOnlyList<MappingEntryDto> mappings, IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath, string itemPath)
        {
            return mappings
                .Where(m => m.SchemaPath.StartsWith(itemPath + "/", StringComparison.OrdinalIgnoreCase))
                .All(m => string.Equals(XmlSubmissionWriter.ResolveExportValue(project, m), nodesByPath.GetValueOrDefault(m.SchemaPath)?.TestValue ?? "", StringComparison.Ordinal));
        }

        /// <summary>/ns1:FRP/ns1:FRP_11A234/ns1:FRP_11A234_Item/ns1:Bookcode to /FRP/FRP_11A234/FRP_11A234_Item/Bookcode.</summary>
        private static string SchemaPathOf(string xpath)
        {
            if (string.IsNullOrWhiteSpace(xpath))
            {
                return null;
            }

            var steps = xpath.Split('/', StringSplitOptions.RemoveEmptyEntries)
                .Select(step => step.Contains(':') ? step.Substring(step.IndexOf(':') + 1) : step);
            return "/" + string.Join("/", steps);
        }
    }

}
