﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// The account code of each row of the project's Excel input template, as the template shows it: BSP's templates
    /// (and the template generated from the XSD) have an "Account Code" column next to the row description, e.g.
    /// FRP_BS row 9: "(1) Cash on Hand" | 105050000000000000 | R0010. A cell's account code is the value in that column
    /// on the cell's row, taken from the nearest "Account Code" header above it (a sheet can hold several tables).
    /// The workbook is read once per template file and kept in memory.
    /// </summary>
    public sealed partial class TemplateAccountCodeReader
    {
        private readonly OpenXmlWorkbookInspector workbookInspector;
        private readonly IMemoryCache cache;

        public TemplateAccountCodeReader(OpenXmlWorkbookInspector workbookInspector, IMemoryCache cache)
    {
        this.workbookInspector = workbookInspector;
        this.cache = cache;
    }
        private static readonly TimeSpan CacheFor = TimeSpan.FromMinutes(30);

        /// <summary>Account codes by sheet name, then row number. Empty when the template has no "Account Code" column.</summary>
        public IReadOnlyDictionary<string, IReadOnlyDictionary<int, string>> Read(string templatePath)
        {
            var file = new FileInfo(templatePath);
            if (!file.Exists)
            {
                return new Dictionary<string, IReadOnlyDictionary<int, string>>();
            }

            // Keyed by the file's path, size and time: a replaced file is read again.
            var key = new VT_Item1_FullName_Length_LastWriteTimeUtc<string, string, long, DateTime>("account-codes", file.FullName, file.Length, file.LastWriteTimeUtc);
            return cache.GetOrCreate(key, entry =>
            {
                entry.SlidingExpiration = CacheFor;
                return ReadWorkbook(workbookInspector.Inspect(templatePath));
            });
        }

        private static IReadOnlyDictionary<string, IReadOnlyDictionary<int, string>> ReadWorkbook(WorkbookSummaryDto workbook)
        {
            var result = new Dictionary<string, IReadOnlyDictionary<int, string>>(StringComparer.OrdinalIgnoreCase);
            foreach (var sheet in workbook.Sheets)
            {
                var cells = sheet.Cells
                    .Select(c => new VT_Row_Column_Text<int, int, string>(OpenXmlWorkbookInspector.RowNumber(c.Address), OpenXmlWorkbookInspector.ColumnIndex(c.Address), c.DisplayValue.Trim()))
                    .Where(c => c.Row > 0 && c.Column > 0)
                    .OrderBy(c => c.Row)
                    .ThenBy(c => c.Column)
                    .ToList();
                var codes = new Dictionary<int, string>();
                int? accountColumn = null;
                foreach (var row in cells.GroupBy(c => c.Row))
                {
                    var header = row.FirstOrDefault(c => HeaderRegex().IsMatch(c.Text));
                    if (header.Row > 0)
                    {
                        accountColumn = header.Column;
                        continue;
                    }

                    int column;
                    VT_Row_Column_Text<int, int, string> code;
                    if (CompatPattern.Is(accountColumn, out column)
                        && CompatPattern.Is(row.FirstOrDefault(c => c.Column == column), out code) && code.Row > 0
                        && CodeRegex().IsMatch(code.Text))
                    {
                        codes[row.Key] = code.Text;
                    }
                }

                if (codes.Count > 0)
                {
                    result[sheet.Name] = codes;
                }
            }

            return result;
        }

        private static System.Text.RegularExpressions.Regex HeaderRegex() { return HeaderRegexInstance; }

            private static System.Text.RegularExpressions.Regex CodeRegex() { return CodeRegexInstance; }

        private static readonly System.Text.RegularExpressions.Regex HeaderRegexInstance = new System.Text.RegularExpressions.Regex(@"^account\s*code$", RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Compiled);

        private static readonly System.Text.RegularExpressions.Regex CodeRegexInstance = new System.Text.RegularExpressions.Regex(@"^\d{3,30}$", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

}
