﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// One step of a validation, reported as a share of the whole: the step covers <paramref name="from"/> to
    /// <paramref name="to"/> percent, and <see cref="Report"/> moves through that range as the step's work gets done.
    /// </summary>
    public sealed class ValidationStep
    {
        private readonly IProgress<ValidationProgressDto> target;
        private readonly int from;
        private readonly int to;
        private readonly string stage;

        public ValidationStep(IProgress<ValidationProgressDto> target, int from, int to, string stage)
    {
        this.target = target;
        this.from = from;
        this.to = to;
        this.stage = stage;
    }
        public void Start(string detail = null) => Report(0, 1, detail);

        public void Report(long done, long total, string detail = null)
        {
            if (target == null)
            {
                return;
            }

            var share = total <= 0 ? 1d : CompatMath.Clamp((double)done / total, 0, 1);
            target.Report(new ValidationProgressDto { Percent = (int)Math.Floor(from + (to - from) * share), Stage = stage, Detail = detail });
        }

        public void Done(string detail = null) => Report(1, 1, detail);
    }

}
