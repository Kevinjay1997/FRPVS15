﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    public sealed class AccessService: IAccessService
    {
        private readonly IAccessRepository repository;
        private readonly IMemoryCache cache;
        private readonly IOptions<DatabaseOptions> options;

        public AccessService(IAccessRepository repository, IMemoryCache cache, IOptions<DatabaseOptions> options)
    {
        this.repository = repository;
        this.cache = cache;
        this.options = options;
    }
        private const string CatalogKey = "frp:access-catalog";

        public async Task<AccessCatalogDto> GetCatalogAsync(CancellationToken cancellationToken)
        {
            AccessCatalogDto cached;
            if (cache.TryGetValue(CatalogKey, out cached) && cached != null)
            {
                return cached;
            }

            var catalog = await repository.GetCatalogAsync(cancellationToken);
            var seconds = options.Value.AccessCacheSeconds;
            if (seconds > 0)
            {
                cache.Set(CatalogKey, catalog, TimeSpan.FromSeconds(seconds));
            }

            return catalog;
        }

        public void Invalidate() => cache.Remove(CatalogKey);

        public Task<IReadOnlyList<DevelopmentUserDto>> GetDevelopmentUsersAsync(CancellationToken cancellationToken) =>
            repository.GetDevelopmentUsersAsync(cancellationToken);
    }

}
