﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    // One immutable snapshot per request. Never shared between users or banks.
    public sealed class BankReferenceContext
    {
        public ReferenceDataDto Data { get; set; } = new ReferenceDataDto();
        public string SampleBankKey { get; set; }
        /// <summary>Region code by region name and code, from the specification's rules (BspDerivedValues.RegionCodes); empty when not known.</summary>
        public IReadOnlyDictionary<string, string> RegionCodes { get; set; } = new Dictionary<string, string>();
        public BankProfileDto SampleBank => Data.Banks.SingleOrDefault(b => b.Key == SampleBankKey);
        /// <summary>"YYYY-MM" of the imported BSP result the sample is built for; null keeps the sample's own period.</summary>
        public string SamplePeriod { get; set; }
        /// <summary>The newest saved BSP result for this bank, report and XSD version (already scoped to the specification).</summary>
        public SandboxImportDto LatestImport(BankProfileDto bank, string report, string ns) => Data.Imports
            .Where(i => Code(i.ProviderCode) == Code(bank.ProviderCode) && i.Report == report && i.Namespace == (ns ?? ""))
            .OrderByDescending(i => i.ImportedAt).FirstOrDefault();
        public static string Code(string value)  {
        string c;
        return (CompatPattern.Is(value.Trim().TrimStart('0'), out c) && c.Length > 0) ? c : "0";
    }
        public static string Header(XElement root, string name) => root.Elements().FirstOrDefault(e => e.Name.LocalName == "Header")?.Elements().FirstOrDefault(e => e.Name.LocalName == name)?.Value ?? "";
        public BankProfileDto Bank(XElement root) => Data.Banks.SingleOrDefault(b => Code(b.ProviderCode) == Code(Header(root, "Undertaking")));
        public IEnumerable<SandboxImportDto> Imports(XElement root) => Data.Imports.Where(i =>
            Code(i.ProviderCode) == Code(Header(root, "Undertaking")) && i.Report == root.Name.LocalName && i.Namespace == root.Name.NamespaceName
            && i.Period == $"{Header(root, "Year")}-{Header(root, "Period").PadLeft(2, '0')}")
            .OrderByDescending(i => i.ImportedAt);
        public object Lookup(XElement root, string table, string field, string provider, string branch)
        {
            var bank = Data.Banks.SingleOrDefault(b => Code(b.ProviderCode) == Code(provider));
            if (bank == null) return null;
            if (table == "BRANCH" && field == "REGION")
                return RegionCode(bank.Branches.FirstOrDefault(b => Code(b.Code) == Code(branch ?? ""))?.Region);
            if (table != "BANK") return null;
            return field == "BNKGRP" ? ((object)bank.BankGroup) : field == "PARENTBNKGRP" ? ((object)bank.ParentBankGroup) : field == "ISDOMESTIC" ? ((object)bank.IsDomestic) : field == "ISSUBFOREIGN" ? ((object)bank.IsSubsidiaryForeign) : field == "ISBRANCHFOREIGN" ? ((object)bank.IsBranchForeign) : field == "A_TRUST" ? ((object)bank.HasTrustLicense) : field == "A_EMI" ? ((object)bank.HasEmoneyLicense) : field == "SUBSIDIARYCOUNT" ? ((object)bank.SubsidiaryCount) : field == "BRANCHCOUNT" && bank.BranchRegisterComplete ? ((object)bank.Branches.Count) : field == "DOMESTICBRANCHCOUNT" && bank.BranchRegisterComplete ? ((object)bank.Branches.Count(b => b.IsDomestic)) : ((object)null);
        }
        /// <summary>The code BSP's rules compare a branch's region with: "NCR", "04" and "4" all give "4" when the specification uses "4" for NCR.</summary>
        public string RegionCode(string region)
        {
            if (region == null) return null;
            var text = region.Trim();
            var key = text.Length > 0 && text.All(char.IsDigit) ? Code(text) : text;
            string code;
            return RegionCodes != null && RegionCodes.TryGetValue(key, out code) ? code : text;
        }
        public static string FormulaKey(string value) => Regex.Replace(value, @"\s+", "").ToUpperInvariant();
        public decimal? Historical(XElement root, string formula) => Imports(root).SelectMany(i => i.HistoricalValues)
            .FirstOrDefault(h => FormulaKey(h.Formula) == FormulaKey(formula))?.Value;
        public bool HasHistoricalForm(XElement root, string offset, string form) => Imports(root).SelectMany(i => i.HistoricalValues)
            .Any(h => FormulaKey(h.Formula).Contains($"DWHS(\"{offset}\";[{form}]".ToUpperInvariant(), StringComparison.Ordinal));
    }

}
