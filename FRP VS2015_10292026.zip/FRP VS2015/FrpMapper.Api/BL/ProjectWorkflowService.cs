﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Maker / Checker workflow. The file a Checker approves is frozen with its SHA-256 hash: an approval applies to
    /// exactly those bytes, and the file is re-hashed on every download so a changed file is never released.
    /// Every action is written to the audit trail.
    /// </summary>
    public sealed class ProjectWorkflowService: IProjectWorkflowService
    {
        private readonly IProjectRepository repository;
        private readonly ProjectAccess access;
        private readonly IProjectFileStore fileStore;
        private readonly IFrpMappingService mappingService;
        private readonly IAuditLog auditLog;
        private readonly ICurrentUser currentUser;
        private readonly UploadRules uploadRules;

        public ProjectWorkflowService(IProjectRepository repository, ProjectAccess access, IProjectFileStore fileStore, IFrpMappingService mappingService, IAuditLog auditLog, ICurrentUser currentUser, UploadRules uploadRules)
    {
        this.repository = repository;
        this.access = access;
        this.fileStore = fileStore;
        this.mappingService = mappingService;
        this.auditLog = auditLog;
        this.currentUser = currentUser;
        this.uploadRules = uploadRules;
    }
        /// <summary>
        /// Each attached submission gets its own file (submission-{id}.xml), so the database always points at exactly the
        /// bytes whose hash it recorded, even if saving the project fails after the file was written.
        /// </summary>
        private const string SubmissionFilePrefix = "submission-";

        public async Task<FrpProjectDto> AttachSubmissionAsync(string projectId, IFormFile xmlFile, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.SubmissionPrepare, "set the submission file");
            uploadRules.Require(xmlFile, UploadKinds.SubmissionXml, "submission file");
            using (var stream = xmlFile.OpenReadStream())
            {
            using (var buffer = new MemoryStream())
            {
            await stream.CopyToAsync(buffer, cancellationToken);
            return await AttachAsync(projectId, buffer.ToArray(), Path.GetFileName(xmlFile.FileName), "Uploaded", cancellationToken, normalizeSheetCopies: true);
            }
            }
        }

        public Task<FrpProjectDto> UseGeneratedSubmissionAsync(string projectId, CancellationToken cancellationToken) =>
            AttachAsync(projectId, null, null, "Generated", cancellationToken);

        public async Task<FrpProjectDto> AttachFilledTemplateAsync(string projectId, IFormFile workbook, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.SubmissionPrepare, "set the submission file");
            uploadRules.Require(workbook, UploadKinds.WorkbookToCheck, "Excel workbook");
            using (var stream = workbook.OpenReadStream())
            {
            using (var buffer = new MemoryStream())
            {
            await stream.CopyToAsync(buffer, cancellationToken);
            var workbookBytes = buffer.ToArray();
            var workbookName = Path.GetFileName(workbook.FileName);
            return await ChangeAsync(projectId, async project =>
            {
                WorkflowRules.RequireEditable(project, currentUser, Permissions.SubmissionPrepare, "set the submission file");
                var built = mappingService.BuildFromFilledTemplate(project, workbookBytes, workbookName);
                if (built.Xml == null || !built.CanAttach)
                {
                    throw new WorkflowException(WorkflowErrorKind.Invalid,
                        $"The values in {workbookName} could not all be read, so no XML was attached. Validate the template to see which cells, correct them and try again.");
                }

                var xmlName = $"{SafeName(Path.GetFileNameWithoutExtension(workbookName))}.xml";
                var updated = await WithSubmissionAsync(project, built.Xml, xmlName, "Uploaded", cancellationToken);
                var submission = updated.Workflow.Submission;
                return new VT_Project_Action_Details<FrpProjectDto, string, string>(updated, "Submission file built from the Excel template", $"{submission.FileName} built from {workbookName} (SHA-256 of the XML {submission.Sha256}; workbook SHA-256 {FrpMappingService.Sha256Hex(workbookBytes)}); "
                    + $"XSD {(submission.XsdValid ? "valid" : $"{submission.XsdErrors} error(s)")}; "
                    + (submission.SpecificationChecked ? $"specification rules passed {submission.SpecRulesPassed}, failed {submission.SpecRulesFailed}." : "no specification."));
            }, cancellationToken);
            }
            }
        }

        public Task<FrpProjectDto> SubmitAsync(string projectId, string comment, CancellationToken cancellationToken) =>
            ChangeAsync(projectId, async project =>
            {
                WorkflowRules.RequireEditable(project, currentUser, Permissions.SubmissionPrepare, "submit a project for review");
                var submission = project.Workflow.Submission;
                if (submission == null)
                {
                    project = await WithSubmissionAsync(project, null, null, "Generated", cancellationToken);
                    submission = project.Workflow.Submission;
                }

                if (!submission.XsdValid)
                {
                    throw new WorkflowException(WorkflowErrorKind.Conflict,
                        $"The submission file {submission.FileName} is not XSD-valid ({submission.XsdErrors} error(s)). Correct it before submitting.");
                }

                var text = WorkflowRules.CleanComment(comment, submission.SpecRulesFailed > 0,
                    "to explain the failed BSP specification rules");
                var now = DateTimeOffset.UtcNow;
                var workflow = WorkflowRules.Touched(project.Workflow, currentUser, now).With(copy => { copy.Status = ProjectStatus.InReview; copy.SubmittedBy = currentUser.Name; copy.SubmittedAt = now; copy.SubmissionComment = text; copy.ReviewedBy = null; copy.ReviewedAt = null; copy.ReviewComment = null; });
                return new VT_Project_Action_Details<FrpProjectDto, string, string>(project.With(copy => { copy.UpdatedAt = now; copy.Workflow = workflow; }), "Submitted for review", $"File {submission.FileName} (SHA-256 {submission.Sha256}).{Suffix(text)}");
            }, cancellationToken);

        public Task<FrpProjectDto> WithdrawAsync(string projectId, string comment, CancellationToken cancellationToken) =>
            ChangeAsync(projectId, project =>
            {
                WorkflowRules.RequirePermission(currentUser, Permissions.SubmissionWithdraw, "withdraw a project from review");
                if (project.Workflow.Status != ProjectStatus.InReview)
                {
                    throw new WorkflowException(WorkflowErrorKind.Conflict, $"Only a project in review can be withdrawn; this one is {WorkflowRules.Describe(project.Workflow.Status)}.");
                }

                var text = WorkflowRules.CleanComment(comment, false, "");
                var now = DateTimeOffset.UtcNow;
                var workflow = WorkflowRules.Touched(project.Workflow, currentUser, now).With(copy => { copy.Status = ProjectStatus.Draft; });
                string s;
                return Task.FromResult<VT_Project_Action_Details<FrpProjectDto, string, string>>(new VT_Project_Action_Details<FrpProjectDto, string, string>(project.With(copy => { copy.UpdatedAt = now; copy.Workflow = workflow; }), "Withdrawn from review", (CompatPattern.Is(Suffix(text).Trim(), out s) && s.Length > 0) ? s : null));
            }, cancellationToken);

        public Task<FrpProjectDto> ApproveAsync(string projectId, string comment, CancellationToken cancellationToken) =>
            ChangeAsync(projectId, project =>
            {
                WorkflowRules.RequireIndependentReviewer(project, currentUser, "approve");
                var submission = project.Workflow.Submission
                    ?? CompatThrow.As<SubmissionFileDto>(new WorkflowException(WorkflowErrorKind.Conflict, "There is no submission file to approve."));
                RequireIntact(project, submission);
                var text = WorkflowRules.CleanComment(comment, false, "");
                var now = DateTimeOffset.UtcNow;
                var workflow = project.Workflow.With(copy => { copy.Status = ProjectStatus.Approved; copy.ReviewedBy = currentUser.Name; copy.ReviewedAt = now; copy.ReviewComment = text; });
                return Task.FromResult<VT_Project_Action_Details<FrpProjectDto, string, string>>(new VT_Project_Action_Details<FrpProjectDto, string, string>(project.With(copy => { copy.UpdatedAt = now; copy.Workflow = workflow; }), "Approved", $"File {submission.FileName} (SHA-256 {submission.Sha256}).{Suffix(text)}"));
            }, cancellationToken);

        public Task<FrpProjectDto> ReturnAsync(string projectId, string comment, CancellationToken cancellationToken) =>
            ChangeAsync(projectId, project =>
            {
                WorkflowRules.RequireIndependentReviewer(project, currentUser, "return");
                var text = WorkflowRules.CleanComment(comment, true, "to tell the Maker what to change");
                var now = DateTimeOffset.UtcNow;
                var workflow = project.Workflow.With(copy => { copy.Status = ProjectStatus.Returned; copy.ReviewedBy = currentUser.Name; copy.ReviewedAt = now; copy.ReviewComment = text; });
                return Task.FromResult<VT_Project_Action_Details<FrpProjectDto, string, string>>(new VT_Project_Action_Details<FrpProjectDto, string, string>(project.With(copy => { copy.UpdatedAt = now; copy.Workflow = workflow; }), "Returned for changes", text));
            }, cancellationToken);

        public Task<FrpProjectDto> ReopenAsync(string projectId, string comment, CancellationToken cancellationToken) =>
            ChangeAsync(projectId, project =>
            {
                WorkflowRules.RequirePermission(currentUser, Permissions.SubmissionReopen, "reopen an approved project");
                if (project.Workflow.Status != ProjectStatus.Approved)
                {
                    throw new WorkflowException(WorkflowErrorKind.Conflict, $"Only an approved project can be reopened; this one is {WorkflowRules.Describe(project.Workflow.Status)}.");
                }

                var text = WorkflowRules.CleanComment(comment, true, "to record why the approval is voided");
                var now = DateTimeOffset.UtcNow;
                var workflow = WorkflowRules.Touched(project.Workflow, currentUser, now).With(copy => { copy.Status = ProjectStatus.Draft; });
                return Task.FromResult<VT_Project_Action_Details<FrpProjectDto, string, string>>(new VT_Project_Action_Details<FrpProjectDto, string, string>(project.With(copy => { copy.UpdatedAt = now; copy.Workflow = workflow; }), "Reopened (approval voided)", $"Approval by {project.Workflow.ReviewedBy} on {project.Workflow.ReviewedAt:yyyy-MM-dd HH:mm} UTC voided. {text}"));
            }, cancellationToken);

        public async Task<VT_FileName_Bytes<string, byte[]>?> DownloadSubmissionAsync(string projectId, CancellationToken cancellationToken)
        {
            var project = ProjectIds.IsValid(projectId) ? await access.GetAsync(projectId, cancellationToken) : null;
            if (project == null)
            {
                return null;
            }

            var submission = project.Workflow.Submission;
            var status = project.Workflow.Status;
            if (submission == null || status == ProjectStatus.Draft || status == ProjectStatus.Returned)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict,
                    "The submission file can be downloaded while it is in review (Checkers) or once it is approved.");
            }

            WorkflowRules.RequirePermission(currentUser,
                status == ProjectStatus.InReview ? Permissions.SubmissionDownloadInReview : Permissions.SubmissionDownloadApproved,
                status == ProjectStatus.InReview ? "download a file that is still in review" : "download the approved submission file");

            var bytes = RequireIntact(project, submission);
            var approved = status == ProjectStatus.Approved;
            await AuditAsync(approved ? "Approved submission downloaded" : "Submission under review downloaded", project,
                $"{submission.FileName} (SHA-256 {submission.Sha256})", cancellationToken);
            var name = $"{SafeName(project.Name)}_{(approved ? "APPROVED" : "IN_REVIEW")}.xml";
            return new VT_FileName_Bytes<string, byte[]>(name, bytes);
        }

        public async Task<IReadOnlyList<AuditEntryDto>> AuditAsync(string projectId, int take, CancellationToken cancellationToken)
        {
            if (projectId != null && !ProjectIds.IsValid(projectId))
            {
                return new List<AuditEntryDto>();
            }

            // A project's history is shown only to people who may see the project.
            if (projectId != null && (await access.GetAsync(projectId, cancellationToken)) == null)
            {
                return new List<AuditEntryDto>();
            }

            return await auditLog.QueryAsync(projectId, CompatMath.Clamp(take, 1, 2000), cancellationToken);
        }

        /// <summary>The page sizes the audit trail and History can be shown in.</summary>
        public static readonly IReadOnlyList<int> AuditPageSizes = new[] { 10, 25, 50, 100 };

        /// <summary>The longest search text and action name (the database columns are wider; nobody types more).</summary>
        public const int MaxAuditFilterLength = 200;

        private const int MaxAuditPage = 1000000;

        public async Task<AuditPageDto> AuditPageAsync(string projectId, int page, int pageSize, string search, string action, CancellationToken cancellationToken)
        {
            if (projectId == null)
            {
                WorkflowRules.RequirePermission(currentUser, Permissions.AuditReadAll, "read the audit trail");
            }
            else
            {
                WorkflowRules.RequirePermission(currentUser, Permissions.ProjectRead, "read projects");
            }

            if (page < 1 || page > MaxAuditPage)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "page must be 1 or more.");
            }

            if (!AuditPageSizes.Contains(pageSize))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, "pageSize must be one of " + string.Join(", ", AuditPageSizes) + ".");
            }

            search = string.IsNullOrWhiteSpace(search) ? null : search.Trim();
            action = string.IsNullOrWhiteSpace(action) ? null : action.Trim();
            if ((search != null && (search.Length > MaxAuditFilterLength || search.Any(char.IsControl)))
                || (action != null && (action.Length > MaxAuditFilterLength || action.Any(char.IsControl))))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"The search and the action are at most {MaxAuditFilterLength} characters, without control characters.");
            }

            if (projectId != null)
            {
                // A project's history is shown only to people who may see the project.
                if (!ProjectIds.IsValid(projectId) || (await access.GetAsync(projectId, cancellationToken)) == null)
                {
                    return null;
                }
            }

            var result = await auditLog.QueryPageAsync(projectId, search, action, (page - 1) * pageSize, pageSize, cancellationToken);
            result.Page = page;
            result.PageSize = pageSize;
            return result;
        }

        /// <summary>
        /// Deletes a draft or returned project; only the person who created it can. The project is marked deleted in the
        /// database (its rows, files and audit trail are kept) and no longer appears anywhere. False: no such project.
        /// </summary>
        public async Task<bool> DeleteAsync(string projectId, CancellationToken cancellationToken)
        {
            WorkflowRules.RequirePermission(currentUser, Permissions.ProjectDelete, "delete a project");
            if (!ProjectIds.IsValid(projectId))
            {
                return false;
            }

            using (var gate = await repository.LockAsync(projectId, cancellationToken))
            {
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return false;
            }

            if (!access.IsCreator(project))
            {
                const string reason = "Only the person who created a project can delete it.";
                await AuditAsync("Action refused", project, "Delete: " + reason, cancellationToken);
                throw new WorkflowException(WorkflowErrorKind.Forbidden, reason);
            }

            if (!(project.Workflow.Status == ProjectStatus.Draft || project.Workflow.Status == ProjectStatus.Returned))
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, project.Workflow.Status == ProjectStatus.InReview
                    ? "This project is in review. Withdraw it from review before deleting it."
                    : $"This project is {WorkflowRules.Describe(project.Workflow.Status)}; only a draft or returned project can be deleted.");
            }

            var version = project.Version ?? CompatThrow.As<byte[]>(new InvalidOperationException("The project was read without its version."));
            if (!await repository.DeleteAsync(project.Id, version, currentUser.Name, DateTimeOffset.UtcNow, cancellationToken))
            {
                return false;
            }

            await AuditAsync("Project deleted", project,
                $"{project.Name} ({project.RootElement}, {WorkflowRules.Describe(project.Workflow.Status)}, {project.Mappings.Count:N0} mappings). "
                + "Marked deleted; its data and history are kept.", cancellationToken);
            return true;
            }
        }

        /// <param name="normalizeSheetCopies">
        /// An uploaded XML exported by Excel from sheet copies (CAR_Part_IV_4c_PHP…) is stored in the XSD's structure
        /// (<see cref="SheetCopyMap.Normalize"/>): that is the file the Checker reviews and BSP receives.
        /// </param>
        private Task<FrpProjectDto> AttachAsync(string projectId, byte[] uploaded, string fileName, string source, CancellationToken cancellationToken,
            bool normalizeSheetCopies = false) =>
            ChangeAsync(projectId, async project =>
            {
                WorkflowRules.RequireEditable(project, currentUser, Permissions.SubmissionPrepare, "set the submission file");
                var normalized = normalizeSheetCopies && uploaded != null ? SheetCopyMap.Normalize(project, uploaded) : null;
                var updated = await WithSubmissionAsync(project, normalized?.Xml ?? uploaded, fileName, source, cancellationToken);
                var submission = updated.Workflow.Submission;
                VT_Xml_Note<byte[], string> n;
                return new VT_Project_Action_Details<FrpProjectDto, string, string>(updated, source == "Uploaded" ? "Submission file uploaded" : "Submission file generated from project values", $"{submission.FileName} (SHA-256 {submission.Sha256}); XSD {(submission.XsdValid ? "valid" : $"{submission.XsdErrors} error(s)")}; "
                    + (submission.SpecificationChecked ? $"specification rules passed {submission.SpecRulesPassed}, failed {submission.SpecRulesFailed}." : "no specification.")
                    + (CompatPattern.Is(normalized, out n) ? $" {n.Note} (SHA-256 of the uploaded file {FrpMappingService.Sha256Hex(uploaded)})" : ""));
            }, cancellationToken);

        /// <summary>Stores the submission file, validates it (XSD + specification) and records its hash.</summary>
        private async Task<FrpProjectDto> WithSubmissionAsync(FrpProjectDto project, byte[] uploaded, string fileName, string source, CancellationToken cancellationToken)
        {
            if (project.XsdFile == null || !File.Exists(project.XsdFile.StoredPath))
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, "The project's XSD file is missing.");
            }

            var bytes = uploaded ?? mappingService.GenerateSubmissionXml(project);
            var name = fileName ?? $"{SafeName(project.Name)}_submission.xml";
            var validation = mappingService.ValidateXml(project, bytes, name);
            var storedPath = await fileStore.SaveFileAsync(project.Id, $"{SubmissionFilePrefix}{Guid.NewGuid():N}.xml", bytes, cancellationToken);
            var now = DateTimeOffset.UtcNow;
            var submission = new SubmissionFileDto
            {
                FileName = name,
                StoredPath = storedPath,
                Size = bytes.LongLength,
                Sha256 = FrpMappingService.Sha256Hex(bytes),
                Source = source,
                AttachedBy = currentUser.Name,
                AttachedAt = now,
                XsdValid = validation.Messages.All(m => !(m.Severity == "Error" && !m.Message.StartsWith("Specification:", StringComparison.Ordinal))),
                XsdErrors = validation.Messages.Count(m => m.Severity == "Error" && !m.Message.StartsWith("Specification:", StringComparison.Ordinal)),
                SpecificationChecked = validation.SpecificationChecked,
                SpecRulesPassed = validation.SpecRulesPassed,
                SpecRulesFailed = validation.SpecRulesFailed
            };
            return project.With(copy => { copy.UpdatedAt = now; copy.Workflow = WorkflowRules.Touched(project.Workflow, currentUser, now).With(inner => { inner.Submission = submission; }); });
        }

        /// <summary>Reads the stored submission and checks it still has the hash recorded when it was attached.</summary>
        private byte[] RequireIntact(FrpProjectDto project, SubmissionFileDto submission)
        {
            var fullPath = Path.GetFullPath(submission.StoredPath);
            var inProjectFolder = string.Equals(Path.GetDirectoryName(fullPath), Path.GetFullPath(fileStore.GetProjectDirectory(project.Id)),
                                      CompatOs.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal)
                                  && Path.GetFileName(fullPath).StartsWith(SubmissionFilePrefix, StringComparison.Ordinal);
            if (!inProjectFolder || !File.Exists(fullPath))
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, "The submission file is missing.");
            }

            var bytes = File.ReadAllBytes(fullPath);
            if (!string.Equals(FrpMappingService.Sha256Hex(bytes), submission.Sha256, StringComparison.Ordinal))
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict,
                    "The submission file changed after it was attached (SHA-256 mismatch); it cannot be approved or released.");
            }

            return bytes;
        }

        /// <summary>Load, check and change a project under its lock, save it and write the audit entry.</summary>
        private async Task<FrpProjectDto> ChangeAsync(
            string projectId,
            Func<FrpProjectDto, Task<VT_Project_Action_Details<FrpProjectDto, string, string>>> change,
            CancellationToken cancellationToken)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                return null;
            }

            using (var gate = await repository.LockAsync(projectId, cancellationToken))
            {
            var project = await access.GetAsync(projectId, cancellationToken);
            if (project == null)
            {
                return null;
            }

            FrpProjectDto updated;
            string action;
            string details;
            try
            {
                var result = await change(project);
                updated = result.Project;
                action = result.Action;
                details = result.Details;
            }
            catch (WorkflowException ex) when (ex.Kind == WorkflowErrorKind.Forbidden)
            {
                await AuditAsync("Action refused", project, ex.Message, cancellationToken);
                throw;
            }

            updated = await repository.SaveWorkflowAsync(updated, cancellationToken);
            await AuditAsync(action, updated, details, cancellationToken);
            return updated;
            }
        }

        private Task AuditAsync(string action, FrpProjectDto project, string details, CancellationToken cancellationToken) =>
            auditLog.AppendAsync(new AuditEntryDto
            {
                Id = Guid.NewGuid().ToString("N"),
                At = DateTimeOffset.UtcNow,
                User = currentUser.Name,
                Action = action,
                ProjectId = project.Id,
                ProjectName = project.Name,
                Details = details
            }, cancellationToken);

        private static string Suffix(string comment) => string.IsNullOrEmpty(comment) ? "" : $" Comment: {comment}";

        private static string SafeName(string name)
        {
            var safe = string.Concat(name.Select(ch => char.IsLetterOrDigit(ch) || ch == '-' || ch == '_' ? ch : '_')).Trim('_');
            return safe.Length == 0 ? "project" : safe;
        }
    }

}
