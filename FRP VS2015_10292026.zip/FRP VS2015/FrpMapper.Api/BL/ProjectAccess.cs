﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Which projects the signed-in person may see. With <see cref="Permissions.ProjectReadAll"/> (Checkers in the
    /// starting configuration) every project; otherwise only the projects the person created or
    /// worked on (the project's contributors). A project the person may not see reads as not found, so its existence is
    /// not revealed. Every business-layer read of a project goes through here.
    /// </summary>
    public sealed class ProjectAccess
    {
        private readonly IProjectRepository repository;
        private readonly ICurrentUser currentUser;

        public ProjectAccess(IProjectRepository repository, ICurrentUser currentUser)
    {
        this.repository = repository;
        this.currentUser = currentUser;
    }
        public bool SeesAll => currentUser.HasPermission(Permissions.ProjectReadAll);

        public bool CanSee(FrpProjectDto project) => CanSee(project.Workflow.CreatedBy, project.Workflow.Contributors);

        public bool CanSee(ProjectSummaryDto project) => CanSee(project.CreatedBy, project.Contributors);

        /// <summary>True when the signed-in person created the project.</summary>
        public bool IsCreator(FrpProjectDto project) => SameUser(project.Workflow.CreatedBy);

        /// <summary>The project, or null when it does not exist or the person may not see it.</summary>
        public async Task<FrpProjectDto> GetAsync(string projectId, CancellationToken cancellationToken)
        {
            var project = await repository.GetAsync(projectId, cancellationToken);
            return project != null && CanSee(project) ? project : null;
        }

        /// <summary>The projects the person may see, newest first.</summary>
        public async Task<IReadOnlyList<ProjectSummaryDto>> ListAsync(CancellationToken cancellationToken) =>
            (await repository.ListAsync(cancellationToken)).Where(CanSee).ToList();

        /// <summary>The project's uploaded files, or null when it does not exist or the person may not see it.</summary>
        public async Task<ProjectUploads> GetUploadsAsync(string projectId, CancellationToken cancellationToken)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                return null;
            }

            if (!SeesAll && !(await ListAsync(cancellationToken)).Any(p => p.Id == projectId))
            {
                return null;
            }

            return await repository.GetUploadsAsync(projectId, cancellationToken);
        }

        private bool CanSee(string createdBy, IEnumerable<string> contributors) =>
            SeesAll || SameUser(createdBy) || contributors.Any(SameUser);

        private bool SameUser(string name) =>
            !string.IsNullOrWhiteSpace(name) && !string.IsNullOrWhiteSpace(currentUser.Name)
            && string.Equals(name.Trim(), currentUser.Name.Trim(), StringComparison.OrdinalIgnoreCase);
    }

}
