﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;
using FrpMapper.Shared.Validation;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Makes generated sample values respect simple specification rules of the form
    /// ISANYOF($[C0040]; 0; 0.0025; 0.01) = TRUE (or = 1) on a loop table, e.g. CAR "specific capital charge"
    /// percentages. The first listed value that also satisfies the XSD facets becomes the field's sample value.
    /// When several rules restrict the same field (e.g. BCCR month by reporting period), the first rule in the
    /// specification is used; it matches the generated Header sample (Period = 1).
    /// </summary>
    public static partial class BspSampleValueRefiner
    {
        public static IReadOnlyList<SchemaNodeDto> Apply(IReadOnlyList<SchemaNodeDto> nodes, BspSpecification specification)
        {
            var allowed = new Dictionary<VT_Sheet_Table_Field<string, string, string>, List<string>>();
            foreach (var assertion in specification.Assertions)
            {
                if (assertion.Operator.Trim() != "=")
                {
                    continue;
                }

                var right = assertion.Right.Trim().ToUpperInvariant();
                if (!(right == "TRUE" || right == "1"))
                {
                    continue;
                }

                var rule = IsAnyOfRegex().Match(assertion.Left.Trim());
                var loop = LoopRegex().Match(assertion.Loop.Trim());
                if (!rule.Success || !loop.Success)
                {
                    continue;
                }

                var values = rule.Groups["values"].Value
                    .Split(';')
                    .Select(v => v.Trim())
                    .Where(v => v.Length > 0)
                    .Select(v => v.Trim('"'))
                    .ToList();
                if (values.Count > 0)
                {
                    allowed.TryAdd(new VT_Sheet_Table_Field<string, string, string>(loop.Groups["sheet"].Value, loop.Groups["table"].Value, rule.Groups["field"].Value), values);
                }
            }

            return nodes.Select(node =>
            {
                if (node.DataType == "complex")
                {
                    return node;
                }

                var tokens = node.Path.Split('/', StringSplitOptions.RemoveEmptyEntries);
                if (tokens.Length < 4)
                {
                    return node;
                }

                foreach (var entry in allowed)
                {
                    var sheet = entry.Key.Sheet;
                    var table = entry.Key.Table;
                    var field = entry.Key.Field;
                    var allowedValues = entry.Value;
                    if (!string.Equals(tokens[1], sheet, StringComparison.OrdinalIgnoreCase)
                        || !string.Equals(tokens[tokens.Length - 1], field, StringComparison.OrdinalIgnoreCase)
                        || !tokens.Contains(table, StringComparer.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    var sample = allowedValues
                        .Select(v => Format(v, node))
                        .FirstOrDefault(v => XsdValueValidator.IsValid(v, node));
                    return (sample == null) ? node : node.With(copy => { copy.TestValue = sample; });
                }

                return RefineTextValue(node, specification.Labels);
            }).ToList();
        }

        private static SchemaNodeDto RefineTextValue(SchemaNodeDto node, BspSpecLabels labels)
        {
            if (!(node.DataType == "string") || !LooksPlaceholder(node.TestValue))
            {
                return node;
            }

            var context = ContextText(node, labels);
            if (string.IsNullOrWhiteSpace(context))
            {
                return node.With(copy => { copy.TestValue = XsdTestValueGenerator.Generate(node.Name, node.DataType, node.Validation); });
            }

            var sample = XsdTestValueGenerator.Generate(node.Name, node.DataType, node.Validation, context);
            return string.Equals(sample, node.TestValue, StringComparison.Ordinal) ? node : node.With(copy => { copy.TestValue = sample; });
        }

        private static string ContextText(SchemaNodeDto node, BspSpecLabels labels)
        {
            var tokens = node.Path.Split('/', StringSplitOptions.RemoveEmptyEntries);
            if (tokens.Length < 3)
            {
                return "";
            }

            var sheet = tokens[1];
            var field = tokens[tokens.Length - 1];
            var table = tokens.Length >= 4 ? tokens[tokens.Length - 2] : "";
            if (table.EndsWith("_Item", StringComparison.OrdinalIgnoreCase) && tokens.Length >= 5)
            {
                table = tokens[tokens.Length - 3];
            }

            var parts = new List<string>();
            Action<string> Add = null;
            Add = (string value) => {
        if (!string.IsNullOrWhiteSpace(value) && value != "- none -")
        {
            parts.Add(value);
        }
    };
            Add(labels.FormTitles.GetValueOrDefault(sheet));
            Add(labels.TableTitles.GetValueOrDefault($"{sheet}|{table}"));
            Add(labels.FieldTitles.GetValueOrDefault($"{sheet}|{field}"));

            var match = FieldCodeRegex().Match(field);
            if (match.Success)
            {
                var rowCode = match.Groups["row"].Value;
                var columnCode = match.Groups["column"].Value;
                var row = labels.RowLabels.GetValueOrDefault($"{sheet}|{table}|{rowCode}");
                Add(row?.Description);
                Add(row?.AccountCode);
                Add(labels.ColumnLabels.GetValueOrDefault($"{sheet}|{table}|{columnCode}"));
            }
            else
            {
                Add(labels.RowLabels.GetValueOrDefault($"{sheet}|{table}|{field}")?.Description);
                Add(labels.ColumnLabels.GetValueOrDefault($"{sheet}|{table}|{field}"));
            }

            return string.Join(" ", parts);
        }

        private static bool LooksPlaceholder(string value) =>
            !string.IsNullOrWhiteSpace(value)
            && (value.Equals("Sample", StringComparison.OrdinalIgnoreCase)
                || value.StartsWith("Sample", StringComparison.OrdinalIgnoreCase)
                || value.Equals("TEST", StringComparison.OrdinalIgnoreCase));

        /// <summary>Formats a rule value like the XSD expects (e.g. 0.0025 with the element's fraction digits).</summary>
        private static string Format(string value, SchemaNodeDto node)
        {
            decimal number;
            int digits;
            if (node.DataType == "decimal"
                && decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out number)
                && CompatPattern.Is(node.Validation.FractionDigits, out digits))
            {
                return number.ToString($"F{CompatMath.Clamp(digits, 0, 10)}", CultureInfo.InvariantCulture);
            }

            return value;
        }

        private static System.Text.RegularExpressions.Regex IsAnyOfRegex() { return IsAnyOfRegexInstance; }

        private static System.Text.RegularExpressions.Regex LoopRegex() { return LoopRegexInstance; }

        private static System.Text.RegularExpressions.Regex FieldCodeRegex() { return FieldCodeRegexInstance; }

        private static readonly System.Text.RegularExpressions.Regex IsAnyOfRegexInstance = new System.Text.RegularExpressions.Regex(@"^\(*\s*ISANYOF\(\s*\$\[(?<field>[^\]]+)\]\s*;(?<values>[^()]*)\)\s*\)*$", RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Compiled);

        private static readonly System.Text.RegularExpressions.Regex LoopRegexInstance = new System.Text.RegularExpressions.Regex(@"^\[(?<sheet>[^\]]+)\]\[(?<table>[^\]]+)\]$", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);

        private static readonly System.Text.RegularExpressions.Regex FieldCodeRegexInstance = new System.Text.RegularExpressions.Regex(@"^(?<row>R\d{3,4})(?<column>C\d{3,4})$", RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

}
