﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;
using FrpMapper.Shared.Validation;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Generates a sample value for an XSD leaf that satisfies its facets.
    /// Candidates are tried in order of "realism" and each one is checked with <see cref="XsdValueValidator"/>.
    /// </summary>
    public static class XsdTestValueGenerator
    {
        public static string Generate(string elementName, string dataType, SchemaValidationDto validation, string contextText = null,
            string sampleKey = null, ISet<decimal> usedAmounts = null)
        {
            string fixedValue;
            if (CompatPattern.Is(validation.FixedValue, out fixedValue)) return fixedValue;
            int length;
            if (CompatPattern.Is(validation.Length, out length)) validation = validation.With(copy => { copy.MinLength = length; copy.MaxLength = length; });
            var probe = new SchemaNodeDto { Name = elementName, DataType = dataType, Validation = validation, IsRequired = true };
            var random = (sampleKey == null) ? CompatRandom.Shared : new Random(
                CompatBinary.ReadInt32LittleEndian(CompatHash.Sha256(Encoding.UTF8.GetBytes(sampleKey))));
            var candidates = BuildCandidates(elementName, dataType, validation, contextText, random).Where(c => !string.IsNullOrEmpty(c)).ToList();
            string validFallback = null;
            foreach (var candidate in candidates)
            {
                if (XsdValueValidator.IsValid(candidate, probe))
                {
                    if (validFallback == null) validFallback = candidate;
                    decimal amount;
                    if (dataType == "decimal" && usedAmounts != null
                        && decimal.TryParse(candidate, NumberStyles.Number, CultureInfo.InvariantCulture, out amount)
                        && !usedAmounts.Add(amount))
                    {
                        continue;
                    }
                    return candidate;
                }
            }

            return validFallback ?? candidates.FirstOrDefault() ?? "TEST";
        }

        private static IEnumerable<string> BuildCandidates(string elementName, string dataType, SchemaValidationDto validation, string contextText, Random random)
        {
            if (validation.Enumerations.Count > 0)
            {
                foreach (var value in OrderedEnumerations(elementName, validation.Enumerations))
                {
                    yield return value;
                }

                yield break;
            }

            switch (dataType)
            {
                case "integer":
                    foreach (var value in IntegerCandidates(elementName, validation))
                    {
                        yield return value;
                    }
                    break;
                case "decimal":
                    foreach (var value in DecimalCandidates(validation, random))
                    {
                        yield return value;
                    }
                    break;
                case "date":
                    yield return $"{DateTime.Today.Year}-03-31";
                    yield return $"{DateTime.Today.Year}-12-31";
                    yield return validation.MinInclusive ?? "";
                    yield return validation.MaxInclusive ?? "";
                    break;
                case "dateTime":
                    yield return $"{DateTime.Today.Year}-03-31T17:00:00";
                    yield return validation.MinInclusive ?? "";
                    break;
                case "boolean":
                    yield return "true";
                    break;
                default:
                    foreach (var value in StringCandidates(elementName, validation, contextText))
                    {
                        yield return value;
                    }
                    break;
            }
        }

        private static IEnumerable<string> IntegerCandidates(string elementName, SchemaValidationDto validation)
        {
            if (LooksLike(elementName, "year", "reportyear", "fiscalyear"))
            {
                yield return DateTime.Today.Year.ToString(CultureInfo.InvariantCulture);
            }

            if (LooksLike(elementName, "month", "period"))
            {
                yield return "3";
            }

            if (LooksLike(elementName, "quarter", "qtr"))
            {
                yield return "1";
            }

            if (LooksLike(elementName, "code", "id", "sequence", "seq"))
            {
                yield return "1001";
            }

            if (elementName.Contains("Year", StringComparison.OrdinalIgnoreCase))
            {
                yield return DateTime.Today.Year.ToString(CultureInfo.InvariantCulture);
            }

            // Counts default low; decimal amount fields use real-looking balances and are rebalanced by the BSP solver.
            yield return "0";
            yield return "12";
            yield return "100";
            yield return "1";
            yield return validation.MinInclusive ?? "";
            yield return validation.MaxInclusive ?? "";
            yield return "0";
            if (validation.Pattern != null)
            {
                yield return PatternSampler.Sample(validation.Pattern) ?? "";
            }
        }

        private static IEnumerable<string> DecimalCandidates(SchemaValidationDto validation, Random random)
        {
            var fractionDigits = CompatMath.Clamp(validation.FractionDigits ?? 2, 0, 6);
            Func<decimal, string> Format = null;
            Format = (decimal value) =>
            {
                return value.ToString($"F{fractionDigits}", CultureInfo.InvariantCulture);
            };

            // Stable per-path randomness keeps previews and exports consistent. The solver still owns totals.
            var lower = 0m;
            var upper = 999999.99m;
            decimal lowerBound;
            if (decimal.TryParse(validation.MinInclusive, NumberStyles.Number, CultureInfo.InvariantCulture, out lowerBound))
                lower = Math.Max(lower, lowerBound);
            decimal upperBound;
            if (decimal.TryParse(validation.MaxInclusive, NumberStyles.Number, CultureInfo.InvariantCulture, out upperBound))
            {
                upper = Math.Min(upper, upperBound);
                if (upper < 0m)
                    lower = decimal.TryParse(validation.MinInclusive, NumberStyles.Number, CultureInfo.InvariantCulture, out lowerBound)
                        ? Math.Max(lowerBound, upper - 999999m) : upper - 999999m;
            }
            if (lower > upper && lower > 999999.99m)
                upper = decimal.TryParse(validation.MaxInclusive, NumberStyles.Number, CultureInfo.InvariantCulture, out upperBound)
                    ? upperBound : lower;
            int totalDigits;
            if (CompatPattern.Is(validation.TotalDigits, out totalDigits))
            {
                var limit = (decimal)Math.Pow(10, CompatMath.Clamp(totalDigits - fractionDigits, 0, 18))
                    - 1m / (decimal)Math.Pow(10, fractionDigits);
                upper = Math.Min(upper, limit);
                lower = Math.Max(lower, -limit);
            }
            if (lower <= upper)
            {
                for (var attempt = 0; attempt < 64; attempt++)
                {
                    var ratio = (decimal)random.NextDouble();
                    yield return Format(lower * (1m - ratio) + upper * ratio);
                }
            }
            yield return Format(25000m);
            yield return Format(6.25m);
            yield return Format(100m);
            yield return Format(1m);
            yield return Format(0m);
            decimal min;
            if (decimal.TryParse(validation.MinInclusive, NumberStyles.Number, CultureInfo.InvariantCulture, out min))
            {
                yield return Format(min);
            }

            decimal max;
            if (decimal.TryParse(validation.MaxInclusive, NumberStyles.Number, CultureInfo.InvariantCulture, out max))
            {
                yield return Format(max);
            }

            yield return "1";
        }

        private static IEnumerable<string> StringCandidates(string elementName, SchemaValidationDto validation, string contextText)
        {
            var semanticText = string.Join(" ", new[] { elementName, contextText }.Where(s => !string.IsNullOrWhiteSpace(s)));
            foreach (var realistic in RealisticStringCandidates(semanticText))
            {
                yield return FitLength(realistic, validation);
            }

            if (LooksLike(elementName, "year", "reportyear", "fiscalyear"))
            {
                yield return DateTime.Today.Year.ToString(CultureInfo.InvariantCulture);
            }

            if (LooksLike(elementName, "period", "month"))
            {
                yield return "03";
                yield return "3";
            }

            var minLength = Math.Max(validation.MinLength ?? 0, 0);
            var maxLength = validation.MaxLength ?? int.MaxValue;
            var baseText = FallbackBusinessText(semanticText);
            if (minLength > baseText.Length)
            {
                baseText = baseText.PadRight(minLength, 'X');
            }

            yield return maxLength < baseText.Length ? baseText.Substring(0, Math.Max(1, maxLength)) : baseText;
            if (validation.Pattern != null)
            {
                yield return PatternSampler.Sample(validation.Pattern, minLength) ?? "";
            }

            yield return new string('1', CompatMath.Clamp(minLength, 1, Math.Min(maxLength, 20)));
            yield return "BUSINESS01".Substring(0, CompatMath.Clamp(Math.Min(maxLength, 10), 1, 10));
        }

        private static IEnumerable<string> OrderedEnumerations(string elementName, IReadOnlyList<string> values)
        {
            var preferred = PreferredEnumerationValues(elementName).ToList();
            foreach (var candidate in preferred)
            {
                var match = values.FirstOrDefault(v => string.Equals(v, candidate, StringComparison.OrdinalIgnoreCase));
                if (match != null)
                {
                    yield return match;
                }
            }

            foreach (var value in values.Where(v => !string.IsNullOrWhiteSpace(v)).OrderBy(v => IsPlaceholderCode(v)).ThenBy(v => v.Length).ThenBy(v => v, StringComparer.OrdinalIgnoreCase))
            {
                yield return value;
            }
        }

        private static IEnumerable<string> PreferredEnumerationValues(string elementName)
        {
            if (LooksLike(elementName, "currency", "ccy"))
            {
                yield return "PHP";
                yield return "608";
            }

            if (LooksLike(elementName, "country", "nationality"))
            {
                yield return "PH";
                yield return "PHL";
                yield return "608";
            }

            if (LooksLike(elementName, "yesno", "flag", "indicator", "ind"))
            {
                yield return "Y";
                yield return "1";
                yield return "TRUE";
            }

            if (LooksLike(elementName, "quarter", "period"))
            {
                yield return "1";
                yield return "Q1";
            }
        }

        private static IEnumerable<string> RealisticStringCandidates(string elementName)
        {
            if (LooksLike(elementName, "currency", "ccy"))
            {
                yield return "PHP";
            }

            if (LooksLike(elementName, "country", "nationality"))
            {
                yield return "PH";
                yield return "PHL";
            }

            if (LooksLike(elementName, "entity", "company", "bank", "institution", "borrower", "customer", "client", "name"))
            {
                yield return "Juan Dela Cruz Trading";
            }

            if (LooksLike(elementName, "firstname", "givenname"))
            {
                yield return "Juan";
            }

            if (LooksLike(elementName, "lastname", "surname"))
            {
                yield return "Dela Cruz";
            }

            if (LooksLike(elementName, "address", "street"))
            {
                yield return "123 Mabini St Manila";
            }

            if (LooksLike(elementName, "city", "municipality"))
            {
                yield return "Manila";
            }

            if (LooksLike(elementName, "province"))
            {
                yield return "Metro Manila";
            }

            if (LooksLike(elementName, "zipcode", "postal"))
            {
                yield return "1000";
            }

            if (LooksLike(elementName, "email"))
            {
                yield return "sample@example.com";
            }

            if (LooksLike(elementName, "phone", "mobile", "contact"))
            {
                yield return "09171234567";
            }

            if (LooksLike(elementName, "tin", "tax"))
            {
                yield return "123456789000";
            }

            if (LooksLike(elementName, "account", "acct"))
            {
                yield return "1000001234";
            }

            if (LooksLike(elementName, "code", "id"))
            {
                yield return "PH001";
                yield return "1001";
            }

            if (LooksLike(elementName, "description", "remarks", "purpose"))
            {
                yield return "Regular business transaction";
            }

            if (LooksLike(elementName, "loan", "lending", "credit", "facility"))
            {
                yield return "Working capital loan";
            }

            if (LooksLike(elementName, "security", "securities", "bond", "investment"))
            {
                yield return "Government securities";
            }

            if (LooksLike(elementName, "sector", "industry", "economicactivity"))
            {
                yield return "Wholesale and retail trade";
            }

            if (LooksLike(elementName, "classification", "class", "status"))
            {
                yield return "Performing";
            }

            if (LooksLike(elementName, "branch", "office"))
            {
                yield return "Main Office";
            }

            if (LooksLike(elementName, "basis", "method", "approach"))
            {
                yield return "Standardized approach";
            }
        }

        private static string FallbackBusinessText(string semanticText)
        {
            if (LooksLike(semanticText, "amount", "balance", "asset", "liability", "capital", "exposure", "income", "expense"))
            {
                return "Regular reported balance";
            }

            if (LooksLike(semanticText, "memo", "remarks", "description", "purpose", "nature"))
            {
                return "Regular business transaction";
            }

            if (LooksLike(semanticText, "counterparty", "borrower", "issuer", "customer"))
            {
                return "Juan Dela Cruz Trading";
            }

            return "Regular banking data";
        }

        private static string FitLength(string value, SchemaValidationDto validation)
        {
            var minLength = Math.Max(validation.MinLength ?? 0, 0);
            var maxLength = validation.MaxLength ?? int.MaxValue;
            if (value.Length < minLength)
            {
                value = value.PadRight(minLength, 'A');
            }

            return maxLength < value.Length ? value.Substring(0, Math.Max(1, maxLength)) : value;
        }

        private static bool LooksLike(string elementName, params string[] tokens)
        {
            var normalized = new string(elementName.Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());
            return tokens.Any(token => normalized.Contains(token.ToLowerInvariant(), StringComparison.Ordinal));
        }

        private static bool IsPlaceholderCode(string value)
        {
            return value == "0" || value == "00" || value == "000" || value == "N/A" || value == "NA" || value == "-";
        }

        /// <summary>
        /// Produces one string matching a (simple) XSD regular expression: literals, escapes (\d, \w, \-),
        /// character classes, groups, alternation (first branch) and quantifiers.
        /// </summary>
        private static class PatternSampler
        {
            public static string Sample(string pattern, int minLength = 0)
            {
                try
                {
                    var position = 0;
                    var result = SampleSequence(pattern, ref position);
                    if (result.Length < minLength)
                    {
                        return null;
                    }

                    return result;
                }
                catch (Exception)
                {
                    return null;
                }
            }

            private static string SampleSequence(string pattern, ref int position)
            {
                var output = new StringBuilder();
                while (position < pattern.Length && pattern[position] != ')')
                {
                    if (pattern[position] == '|')
                    {
                        // Keep the first alternative, skip the rest of this group/level.
                        SkipToGroupEnd(pattern, ref position);
                        break;
                    }

                    var atom = SampleAtom(pattern, ref position);
                    var quantifier = ReadQuantifier(pattern, ref position);
                    var minRepeat = quantifier.Min;
                    var maxRepeat = quantifier.Max;
                    var repeat = Math.Max(minRepeat, Math.Min(1, maxRepeat));
                    for (var i = 0; i < repeat; i++)
                    {
                        output.Append(atom);
                    }
                }

                return output.ToString();
            }

            private static string SampleAtom(string pattern, ref int position)
            {
                var ch = pattern[position++];
                switch (ch)
                {
                    case '(':
                        if (position + 1 < pattern.Length && pattern[position] == '?' && pattern[position + 1] == ':')
                        {
                            position += 2;
                        }

                        var inner = SampleSequence(pattern, ref position);
                        position++; // ')'
                        return inner;
                    case '[':
                        return SampleClass(pattern, ref position);
                    case '\\':
                        return SampleEscape(pattern[position++]).ToString();
                    case '.':
                        return "A";
                    default:
                        return ch.ToString();
                }
            }

            private static string SampleClass(string pattern, ref int position)
            {
                var negated = pattern[position] == '^';
                if (negated)
                {
                    position++;
                }

                char? first = null;
                var depth = 1;
                while (position < pattern.Length && depth > 0)
                {
                    var ch = pattern[position++];
                    if (ch == '[')
                    {
                        depth++;
                        continue;
                    }

                    if (ch == ']')
                    {
                        depth--;
                        continue;
                    }

                    if (first == null && depth == 1)
                    {
                        first = ch == '\\' ? SampleEscape(pattern[position++]) : ch;
                    }
                }

                if (negated)
                {
                    return first == 'A' ? "B" : "A";
                }

                return (first ?? 'A').ToString();
            }

            private static char SampleEscape(char escaped)
            {
                return escaped == 'd' ? '1' : escaped == 'w' ? 'A' : escaped == 's' ? ' ' : (escaped == 'i' || escaped == 'c') ? 'A' : escaped;
            }

            private static VT_Min_Max<int, int> ReadQuantifier(string pattern, ref int position)
            {
                if (position >= pattern.Length)
                {
                    return new VT_Min_Max<int, int>(1, 1);
                }

                switch (pattern[position])
                {
                    case '?':
                        position++;
                        return new VT_Min_Max<int, int>(0, 1);
                    case '*':
                        position++;
                        return new VT_Min_Max<int, int>(0, int.MaxValue);
                    case '+':
                        position++;
                        return new VT_Min_Max<int, int>(1, int.MaxValue);
                    case '{':
                        var end = pattern.IndexOf('}', position);
                        var body = pattern.Substring(position + 1, end - (position + 1));
                        position = end + 1;
                        var parts = body.Split(',');
                        var min = int.Parse(parts[0], CultureInfo.InvariantCulture);
                        var max = parts.Length == 1 ? min : string.IsNullOrEmpty(parts[1]) ? int.MaxValue : int.Parse(parts[1], CultureInfo.InvariantCulture);
                        return new VT_Min_Max<int, int>(min, max);
                    default:
                        return new VT_Min_Max<int, int>(1, 1);
                }
            }

            private static void SkipToGroupEnd(string pattern, ref int position)
            {
                var depth = 0;
                while (position < pattern.Length)
                {
                    var ch = pattern[position];
                    if (ch == '\\')
                    {
                        position += 2;
                        continue;
                    }

                    if (ch == '(')
                    {
                        depth++;
                    }
                    else if (ch == ')')
                    {
                        if (depth == 0)
                        {
                            return;
                        }

                        depth--;
                    }

                    position++;
                }
            }
        }
    }

}
