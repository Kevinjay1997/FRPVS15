﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO.Compression;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Item rows: a repeating item whose form is not already one table row — a whole grid per item, such as
    /// CAR_Part_IV_1d's MAIN and ADD1 per currency, a column of R0010.. per country, or one row without its codes above
    /// it — is entered in an XML list table with one row per item (one row per currency), so a person can add items by
    /// adding rows, as many as the XSD allows.
    ///
    /// The form's rows on the sheet are replaced by:
    /// <list type="bullet">
    /// <item>a note saying that each row is one item;</item>
    /// <item>heading rows taken from the form, so every column says where its value was: the block (MAIN, ADD1), the
    /// form's column headings ("Individual Positions", "Long"), its row headings ("Zone", "Times Bands – Coupon 3% or
    /// more"), each with the form's caption on the left, and the account code;</item>
    /// <item>the table: a header row of element names (as in the helper table) and the data row, with the XSD's data
    /// validation on the data row and the rows below it (rows a person adds).</item>
    /// </list>
    /// Cells keep the form's own styles (headings, labels and input cells). Rows above the form (the sheet's title, or
    /// another form's cells) and below it are kept. When the form shares its rows with other mapped cells, or there is no
    /// room, the helper table is used instead (see <see cref="BuildHelperTable"/>).
    /// </summary>
    /// <summary>Where the template put a list as item rows (for the Mappings tab's sheet view, which shows the template).</summary>
    public sealed class ItemRowsPlacement
    {
        public string SheetName { get; set; }

        /// <summary>The repeating XSD element, e.g. /CAR_M/CAR_Part_IV_1d/CAR_Part_IV_1d_Item.</summary>
        public string ItemPath { get; set; }

        /// <summary>The rows the form had and the item rows now take, from column A to the table's last column (e.g. A3:BR15).</summary>
        public string Range { get; set; }

        /// <summary>The table's first data row.</summary>
        public int DataRow { get; set; }

        /// <summary>Each field: its cell in the table's first data row and its mapped cell on the form.</summary>
        public IReadOnlyList<ItemRowsCell> Cells { get; set; }
    }

    /// <summary>A field of an item-rows table: its cell in the template and the form's cell it is mapped to.</summary>
    public sealed class ItemRowsCell
    {
        public string SchemaPath { get; set; }

        public string FormCell { get; set; }

        public string TemplateCell { get; set; }
    }

    public sealed partial class OpenXmlMappedTemplateWriter
    {
        /// <summary>The data row and the rows below it that get the columns' data validation (rows a person adds).</summary>
        private const int ItemRowsValidatedRows = 500;

        /// <summary>Most columns one heading label is merged over; a label over more columns is repeated in each.</summary>
        private const int ItemRowsMergedLabelColumns = 8;

        /// <summary>Column of the first table column; the captions of the heading rows are in A:B.</summary>
        private const int ItemRowsFirstColumn = 3;

        private static readonly Regex RowCodeText = new Regex(@"^R\d{4}$", RegexOptions.CultureInvariant);
        private static readonly Regex ColumnCodeText = new Regex(@"^C\d{4}$", RegexOptions.CultureInvariant);
        private static readonly Regex AccountCodeText = new Regex(@"^\d{10,}$", RegexOptions.CultureInvariant);

        /// <summary>A text on the form and the style of the cell that shows it.</summary>
        private sealed class FormLabel
        {
            public string Text;
            public string Style;

            /// <summary>For a column heading: rows above the block's row of codes (1 = the row just above them).</summary>
            public int Depth;
        }

        /// <summary>One field of the item: where it was on the form and what the form says about it.</summary>
        private sealed class ItemRowField
        {
            public SchemaNodeDto Node;
            public MappingEntryDto Mapping;
            public int Column;
            public int Row;
            public string Section;
            public string Style;
            public List<FormLabel> ColumnLabels = new List<FormLabel>();
            public Dictionary<string, FormLabel> RowLabels = new Dictionary<string, FormLabel>(StringComparer.Ordinal);
            public FormLabel AccountCode;
        }

        /// <summary>A heading row above the table: its caption (left of the table) and one label per table column.</summary>
        private sealed class HeadingRow
        {
            public string Caption;
            public FormLabel[] Labels;
        }

        /// <summary>The form's cells by position, with merged cells read as their top-left cell.</summary>
        private sealed class FormCells
        {
            private readonly Dictionary<VT_Column_Row<int, int>, XElement> cells = new Dictionary<VT_Column_Row<int, int>, XElement>();
            private readonly Dictionary<VT_Column_Row<int, int>, VT_Column_Row<int, int>> mergedInto = new Dictionary<VT_Column_Row<int, int>, VT_Column_Row<int, int>>();
            private readonly IReadOnlyList<string> sharedStrings;

            public FormCells(XElement worksheet, XElement sheetData, IReadOnlyList<string> sharedStrings)
            {
                this.sharedStrings = sharedStrings;
                foreach (var cell in sheetData.Elements(Main + "row").Elements(Main + "c"))
                {
                    string column;
                    int row;
                    var address = (string)cell.Attribute("r") ?? "";
                    if (TryParseCellAddress(address, out column, out row))
                    {
                        cells[new VT_Column_Row<int, int>(CellColumnIndex(address), row)] = cell;
                    }
                }

                foreach (var merge in worksheet.Elements(Main + "mergeCells").Elements(Main + "mergeCell"))
                {
                    VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int> area;
                    if (!TryParseRange((string)merge.Attribute("ref"), out area) || (area.LastRow - area.FirstRow + 1) * (area.LastColumn - area.FirstColumn + 1) > 100000)
                    {
                        continue;
                    }

                    var topLeft = new VT_Column_Row<int, int>(area.FirstColumn, area.FirstRow);
                    for (var row = area.FirstRow; row <= area.LastRow; row++)
                    {
                        for (var column = area.FirstColumn; column <= area.LastColumn; column++)
                        {
                            mergedInto[new VT_Column_Row<int, int>(column, row)] = topLeft;
                        }
                    }
                }
            }

            /// <summary>The trimmed text shown at the position (a merged cell shows its top-left cell), or "".</summary>
            public string Text(int column, int row)
            {
                var cell = Source(column, row);
                if (cell == null)
                {
                    return "";
                }

                var type = (string)cell.Attribute("t");
                var value = cell.Element(Main + "v")?.Value;
                int index;
                var text = type == "s" && int.TryParse(value, out index) && index >= 0 && index < sharedStrings.Count ? sharedStrings[index]
                    : type == "inlineStr" ? string.Concat(cell.Element(Main + "is")?.Descendants(Main + "t").Select(t => t.Value) ?? new List<string>())
                    : value;
                return (text ?? "").Trim();
            }

            /// <summary>The style index of the cell shown at the position, or null.</summary>
            public string Style(int column, int row) => (string)Source(column, row)?.Attribute("s");

            public FormLabel Label(int column, int row)
            {
                var text = Text(column, row);
                return text.Length == 0 ? null : new FormLabel { Text = text, Style = Style(column, row) };
            }

            /// <summary>Non-empty texts of a row, by column.</summary>
            public IEnumerable<VT_Column_Row<int, int>> Filled(int row) =>
                cells.Keys.Where(k => k.Row == row && Text(k.Column, k.Row).Length > 0);

            private XElement Source(int column, int row)
            {
                var position = new VT_Column_Row<int, int>(column, row);
                VT_Column_Row<int, int> topLeft;
                if (mergedInto.TryGetValue(position, out topLeft))
                {
                    position = topLeft;
                }

                XElement cell;
                return cells.TryGetValue(position, out cell) ? cell : null;
            }
        }

        /// <summary>
        /// Replaces the item's form on the sheet with heading rows and a table of one row per item (see the class summary).
        /// Null (and the sheet unchanged) when the form does not qualify: other mapped cells or tables share its rows, or
        /// the rows do not fit before the next form. (A form whose fields are in one row under their codes is an in-place
        /// table instead; one in one row without them comes here too.)
        /// </summary>
        /// <param name="sheetMappings">Every mapped cell of this sheet (to find where the item's form starts and ends).</param>
        /// <param name="lastFormRow">The sheet's last row before any table was added below it.</param>
        private static ListTable TryItemRowsTable(
            ZipArchive archive,
            string worksheetPath,
            XElement worksheet,
            XElement sheetData,
            string groupPath,
            List<VT_Node_Mapping<SchemaNodeDto, MappingEntryDto>> fields,
            IReadOnlyList<MappingEntryDto> sheetMappings,
            IReadOnlyList<string> sharedStrings,
            int lastFormRow,
            FrpProjectDto project,
            bool writeValues,
            ValidationLists lists,
            string sheetName = null,
            ICollection<ItemRowsPlacement> placements = null)
        {
            var items = new List<ItemRowField>();
            foreach (var field in fields)
            {
                string unusedColumn;
                int row;
                if (!TryParseCellAddress(field.Mapping.CellAddress ?? "", out unusedColumn, out row))
                {
                    return null;
                }

                var relative = field.Node.Path.Length > groupPath.Length ? field.Node.Path.Substring(groupPath.Length + 1) : field.Node.Name;
                items.Add(new ItemRowField
                {
                    Node = field.Node,
                    Mapping = field.Mapping,
                    Column = CellColumnIndex(field.Mapping.CellAddress),
                    Row = row,
                    Section = relative.IndexOf('/') >= 0 ? relative.Substring(0, relative.LastIndexOf('/')) : ""
                });
            }

            // The form's rows: from below the title (or the cells above that belong to something else) to the row before the
            // next mapped cells (or the sheet's end). Another mapped cell inside the item's own rows: no room for a table.
            var firstFieldRow = items.Min(i => i.Row);
            var lastFieldRow = items.Max(i => i.Row);
            var itemPaths = new HashSet<string>(items.Select(i => i.Node.Path), StringComparer.OrdinalIgnoreCase);
            var otherRows = sheetMappings
                .Where(m => !itemPaths.Contains(m.SchemaPath))
                .Select(m => { string unusedColumn; int row; return TryParseCellAddress(m.CellAddress ?? "", out unusedColumn, out row) ? row : 0; })
                .Where(row => row > 0)
                .ToList();
            if (otherRows.Any(row => row >= firstFieldRow && row <= lastFieldRow))
            {
                return null;
            }

            var form = new FormCells(worksheet, sheetData, sharedStrings);
            var above = otherRows.Where(row => row < firstFieldRow).ToList();
            var below = otherRows.Where(row => row > lastFieldRow).ToList();
            var start = Math.Min(firstFieldRow, above.Count > 0 ? above.Max() + 1 : TitleRows(form, firstFieldRow) + 1);
            var end = below.Count > 0 ? below.Min() - 1 : Math.Max(lastFormRow, lastFieldRow);

            // A table or a bound cell of the template inside those rows stays where it is: keep the form.
            var merges = worksheet.Elements(Main + "mergeCells").Elements(Main + "mergeCell")
                .Select(m => { VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int> area; return TryParseRange((string)m.Attribute("ref"), out area) ? (VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int>?)area : null; })
                .Where(a => a != null)
                .Select(a => a.Value)
                .ToList();
            if (BlockedAreas(archive, worksheetPath, worksheet).Any(b => !merges.Contains(b) && b.FirstRow <= end && b.LastRow >= start))
            {
                return null;
            }

            var mappedCells = new HashSet<VT_Column_Row<int, int>>(sheetMappings
                .Select(m => { string unusedColumn; int row; return TryParseCellAddress(m.CellAddress ?? "", out unusedColumn, out row) ? new VT_Column_Row<int, int>(CellColumnIndex(m.CellAddress), row) : default(VT_Column_Row<int, int>); }));
            var mappedRows = new HashSet<int>(sheetMappings
                .Select(m => { string unusedColumn; int row; return TryParseCellAddress(m.CellAddress ?? "", out unusedColumn, out row) ? row : 0; }));
            var captions = ReadFormLabels(form, items, start, mappedCells, mappedRows);

            var headings = HeadingRows(items, captions);
            var noteRow = start + 1;
            var firstHeadingRow = noteRow + 1;
            var headerRow = firstHeadingRow + headings.Count;
            var dataRow = headerRow + 1;
            if (below.Count > 0 && dataRow > end)
            {
                return null; // the next form starts too soon
            }

            // The form's usual heading style (its column headings', else its row headings').
            var headingStyle = MostCommon(items.SelectMany(i => i.ColumnLabels).Select(l => l.Style))
                ?? MostCommon(items.SelectMany(i => i.RowLabels.Values).Select(l => l.Style));

            ClearFormRows(worksheet, sheetData, start, end);

            // The note, then each heading row with its caption in A:B and same labels side by side merged.
            var groupName = groupPath.Split('/', StringSplitOptions.RemoveEmptyEntries).LastOrDefault() ?? "item";
            var unique = UniqueFields(project).Where(path => items.Any(i => i.Node.Path == path)).ToList();
            SetInlineString(GetOrCreateCell(sheetData, "A", noteRow),
                $"Each row of the table below is one {groupName} (one {items[0].Node.Name}). To add another, type in the row below the table. "
                + (unique.Count > 0 ? $"Each {string.Join(" / ", unique.Select(u => u.Split('/').Last()))} only once (a repeated one turns red). " : "")
                + "The rows above the table show where each value is on the BSP form.");
            var newMerges = new List<string>();
            for (var h = 0; h < headings.Count; h++)
            {
                var row = firstHeadingRow + h;
                var heading = headings[h];
                WriteText(sheetData, 1, row, heading.Caption, headingStyle);
                WriteText(sheetData, 2, row, null, headingStyle);
                newMerges.Add($"A{row}:B{row}");
                var lines = 1;
                for (var i = 0; i < items.Count;)
                {
                    var label = heading.Labels[i];
                    var run = 1;
                    while (label != null && i + run < items.Count && heading.Labels[i + run] != null
                           && heading.Labels[i + run].Text == label.Text && items[i + run].Section == items[i].Section)
                    {
                        run++;
                    }

                    // A few columns share one merged label; over more columns the label is repeated, so it stays in view.
                    var merged = run > 1 && run <= ItemRowsMergedLabelColumns;
                    for (var k = 0; k < run; k++)
                    {
                        WriteText(sheetData, ItemRowsFirstColumn + i + k, row, k == 0 || !merged ? label?.Text : null, label?.Style ?? headingStyle);
                    }

                    if (merged)
                    {
                        newMerges.Add($"{ColumnName(ItemRowsFirstColumn + i)}{row}:{ColumnName(ItemRowsFirstColumn + i + run - 1)}{row}");
                    }

                    lines = Math.Max(lines, TextLines(label?.Text, 24 * (merged ? run : 1)));
                    i += run;
                }

                lines = Math.Max(lines, TextLines(heading.Caption, 48));
                SetRowHeight(sheetData, row, lines);
            }

            // The table: element names, then the data row in the form's input style, with the XSD's validation.
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var columns = new List<ListColumn>();
            var validations = new List<XElement>();
            for (var i = 0; i < items.Count; i++)
            {
                var item = items[i];
                var column = ItemRowsFirstColumn + i;
                var letters = ColumnName(column);
                var name = UniqueColumnName(item.Node, groupPath, names);
                WriteText(sheetData, column, headerRow, name, headingStyle);
                var cell = GetOrCreateCell(sheetData, letters, dataRow);
                SetStyle(cell, item.Style);
                SetCellValue(cell, writeValues ? XmlSubmissionWriter.ResolveExportValue(project, item.Mapping) : null, item.Mapping.DataType);
                columns.Add(new ListColumn(column, name, item.Node));

                var validation = XsdExcelValidationBuilder.Build(item.Node, $"{letters}{dataRow}:{letters}{dataRow + ItemRowsValidatedRows - 1}", lists.Reference);
                if (validation != null)
                {
                    validations.Add(validation);
                }
            }

            SetRowHeight(sheetData, headerRow, 1);
            AddMerges(worksheet, newMerges);

            // The form's validations go with its rows; the table's columns get theirs.
            XsdExcelValidationBuilder.RemoveRows(worksheet, start, end);
            XsdExcelValidationBuilder.UpsertDataValidations(worksheet, validations);

            // The XSD's unique fields (xs:unique, e.g. one item per Currency): a repeated value turns red.
            foreach (var column in columns.Where(c => unique.Contains(c.Node.Path)))
            {
                var letters = ColumnName(column.Column);
                MarkDuplicates(archive, worksheet, $"{letters}{dataRow}:{letters}{dataRow + ItemRowsValidatedRows - 1}");
            }

            placements?.Add(new ItemRowsPlacement
            {
                SheetName = sheetName,
                ItemPath = groupPath,
                Range = $"A{start}:{ColumnName(Math.Max(columns.Max(c => c.Column), 2))}{dataRow}",
                DataRow = dataRow,
                Cells = items.Select((item, i) => new ItemRowsCell
                {
                    SchemaPath = item.Node.Path,
                    FormCell = item.Mapping.CellAddress.ToUpperInvariant(),
                    TemplateCell = $"{ColumnName(columns[i].Column)}{dataRow}"
                }).ToList()
            });
            return new ListTable(headerRow, dataRow, columns);
        }

        /// <summary>
        /// The XSD's unique fields (xs:unique with one field), as schema paths: e.g. /CAR_M/CAR_Part_IV_1d/CAR_Part_IV_1d_Item/Currency
        /// from the root element's unique "ns:CAR_Part_IV_1d/ns:CAR_Part_IV_1d_Item" / "ns:Currency".
        /// </summary>
        private static IReadOnlyList<string> UniqueFields(FrpProjectDto project)
        {
            var path = project.XsdFile?.StoredPath;
            if (string.IsNullOrEmpty(path) || !System.IO.File.Exists(path))
            {
                return new List<string>();
            }

            XNamespace xs = "http://www.w3.org/2001/XMLSchema";
            Func<string, string> Local = xpath => string.Join("/", xpath.Split('/').Select(step => step.Substring(step.IndexOf(':') + 1)));
            var result = new List<string>();
            foreach (var unique in SafeXml.Load(path).Descendants(xs + "unique"))
            {
                var selector = (string)unique.Element(xs + "selector")?.Attribute("xpath");
                var fields = unique.Elements(xs + "field").Select(f => (string)f.Attribute("xpath")).ToList();
                if (selector == null || fields.Count != 1 || fields[0] == null
                    || new[] { selector, fields[0] }.Any(x => x.IndexOfAny(new[] { '|', '@', '*', '.' }) >= 0 || x.StartsWith("/", StringComparison.Ordinal)))
                {
                    continue; // only simple paths
                }

                var declaredOn = unique.Ancestors(xs + "element").Select(e => (string)e.Attribute("name")).Reverse().ToList();
                result.Add("/" + string.Join("/", declaredOn) + "/" + Local(selector) + "/" + Local(fields[0]));
            }

            return result;
        }

        /// <summary>A conditional format that shows repeated values in <paramref name="sqref"/> in red.</summary>
        private static void MarkDuplicates(ZipArchive archive, XElement worksheet, string sqref)
        {
            var styles = ReadXml(archive, "xl/styles.xml");
            if (styles?.Root == null)
            {
                return;
            }

            var dxfId = AppendStyle(styles.Root, "dxfs", "dxf", new XElement(Main + "dxf",
                new XElement(Main + "font", new XElement(Main + "color", new XAttribute("rgb", "FF9C0006"))),
                new XElement(Main + "fill", new XElement(Main + "patternFill", new XElement(Main + "bgColor", new XAttribute("rgb", "FFFFC7CE"))))),
                new[] { "tableStyles", "colors", "extLst" });
            UpsertEntry(archive, "xl/styles.xml", styles.ToString(SaveOptions.DisableFormatting));

            var priority = worksheet.Descendants(Main + "cfRule").Select(r => (int?)r.Attribute("priority") ?? 0).DefaultIfEmpty(0).Max() + 1;
            var format = new XElement(Main + "conditionalFormatting", new XAttribute("sqref", sqref),
                new XElement(Main + "cfRule", new XAttribute("type", "duplicateValues"), new XAttribute("dxfId", dxfId), new XAttribute("priority", priority)));
            var before = worksheet.Elements().FirstOrDefault(e => ConditionalFormattingPrecedes.Contains(e.Name.LocalName));
            if (before != null)
            {
                before.AddBeforeSelf(format);
            }
            else
            {
                worksheet.Add(format);
            }
        }

        /// <summary>Worksheet elements that come after conditionalFormatting (CT_Worksheet sequence).</summary>
        private static readonly HashSet<string> ConditionalFormattingPrecedes = new HashSet<string>(StringComparer.Ordinal)
        {
            "dataValidations", "hyperlinks", "printOptions", "pageMargins", "pageSetup", "headerFooter", "rowBreaks", "colBreaks",
            "customProperties", "cellWatches", "ignoredErrors", "smartTags", "drawing", "legacyDrawing", "legacyDrawingHF",
            "drawingHF", "picture", "oleObjects", "controls", "webPublishItems", "tableParts", "extLst"
        };

        /// <summary>The sheet's title rows above the form: leading rows with one text each (e.g. A1 code, A2 title).</summary>
        private static int TitleRows(FormCells form, int firstFieldRow)
        {
            var row = 1;
            while (row < firstFieldRow && form.Filled(row).Count() == 1)
            {
                row++;
            }

            return row - 1;
        }

        /// <summary>
        /// Reads, for each field, the form's labels: the column headings above its block (the rows above the block's first
        /// row, up to its row of codes C0010.., stopping at a row of another block), the row headings left of the block on
        /// its own row (with the caption above each heading column) and its account code (on its row, else in its column).
        /// </summary>
        /// <returns>The captions of the row headings, block by block and left to right.</returns>
        private static List<string> ReadFormLabels(FormCells form, List<ItemRowField> items, int start, ISet<VT_Column_Row<int, int>> mappedCells, ISet<int> mappedRows)
        {
            Func<string, bool> IsCode = text => RowCodeText.IsMatch(text) || ColumnCodeText.IsMatch(text) || AccountCodeText.IsMatch(text);
            var captionOrder = new List<string>();
            Func<int, bool> StopsHeadings = row => row < start || mappedRows.Contains(row) || form.Filled(row).Any(c => RowCodeText.IsMatch(form.Text(c.Column, c.Row)));

            foreach (var section in items.GroupBy(i => i.Section))
            {
                var sectionItems = section.ToList();
                var firstRow = sectionItems.Min(i => i.Row);
                var firstColumn = sectionItems.Min(i => i.Column);
                var sectionColumns = sectionItems.Select(i => i.Column).Distinct().ToList();

                // Heading rows: up to the nearest row of column codes (C0010...) above the block (past rows the form computes,
                // such as totals, which have row codes but no input), else up to the block.
                var bottom = firstRow - 1;
                for (var row = firstRow - 1; row >= start && !mappedRows.Contains(row); row--)
                {
                    if (sectionColumns.Any(c => ColumnCodeText.IsMatch(form.Text(c, row))))
                    {
                        bottom = row;
                        break;
                    }
                }

                var top = bottom + 1;
                while (top - 1 >= start && top - 1 <= bottom && !StopsHeadings(top - 1))
                {
                    top--;
                }

                foreach (var item in sectionItems)
                {
                    item.Style = form.Style(item.Column, item.Row);
                    for (var row = top; row <= bottom; row++)
                    {
                        var label = form.Label(item.Column, row);
                        if (label != null && !IsCode(label.Text) && !mappedCells.Contains(new VT_Column_Row<int, int>(item.Column, row))
                            && !string.Equals(label.Text, item.Node.Name, StringComparison.OrdinalIgnoreCase))
                        {
                            // A heading merged down over several rows counts at its lowest row.
                            var previous = item.ColumnLabels.LastOrDefault();
                            if (previous == null || previous.Text != label.Text)
                            {
                                item.ColumnLabels.Add(label);
                                previous = label;
                            }

                            previous.Depth = bottom + 1 - row;
                        }
                        else if (label != null && AccountCodeText.IsMatch(label.Text) && item.AccountCode == null)
                        {
                            item.AccountCode = label;
                        }
                    }
                }

                // Row headings: columns left of the block with a heading text on one of the block's rows.
                for (var column = 1; column < firstColumn; column++)
                {
                    var labels = sectionItems.ToDictionary(i => i, i => form.Label(column, i.Row));
                    foreach (var pair in labels.Where(p => p.Value != null && AccountCodeText.IsMatch(p.Value.Text)))
                    {
                        pair.Key.AccountCode = pair.Value;
                    }

                    if (!labels.Values.Any(l => l != null && !IsCode(l.Text)))
                    {
                        continue;
                    }

                    var captions = new List<string>();
                    for (var row = top; row <= bottom; row++)
                    {
                        var text = form.Text(column, row);
                        if (text.Length > 0 && !IsCode(text) && !captions.Contains(text))
                        {
                            captions.Add(text);
                        }
                    }

                    var caption = captions.Count > 0 ? string.Join(" – ", captions) : $"Row heading ({ColumnName(column)})";
                    if (!captionOrder.Contains(caption))
                    {
                        captionOrder.Add(caption);
                    }

                    foreach (var pair in labels.Where(p => p.Value != null && !IsCode(p.Value.Text)))
                    {
                        pair.Key.RowLabels[caption] = pair.Value;
                    }
                }
            }

            return captionOrder;
        }

        /// <summary>
        /// The heading rows above the table: the blocks (when there are several), the form's column headings (aligned on
        /// their lowest level), its row headings (one row per caption) and the account codes. A row of row headings that
        /// only repeats another one is left out.
        /// </summary>
        private static List<HeadingRow> HeadingRows(List<ItemRowField> items, IReadOnlyList<string> captions)
        {
            var headings = new List<HeadingRow>();
            var count = items.Count;
            if (items.Select(i => i.Section).Where(s => s.Length > 0).Distinct().Count() > 1)
            {
                headings.Add(new HeadingRow { Caption = "Block", Labels = items.Select(i => i.Section.Length == 0 ? null : new FormLabel { Text = i.Section.Replace('/', ' ') }).ToArray() });
            }

            // Column headings by their distance from the form's row of codes, so headings of one level stay in one row.
            var depths = items.SelectMany(i => i.ColumnLabels).Select(l => l.Depth).Distinct().OrderByDescending(d => d).ToList();
            foreach (var depth in depths)
            {
                headings.Add(new HeadingRow
                {
                    Caption = depth == depths[0] ? "Column headings" : "",
                    Labels = items.Select(i => i.ColumnLabels.FirstOrDefault(l => l.Depth == depth)).ToArray()
                });
            }

            var rowHeadings = new List<HeadingRow>();
            foreach (var caption in captions)
            {
                var labels = items.Select(i => i.RowLabels.GetValueOrDefault(caption)).ToArray();
                var repeats = Enumerable.Range(0, count).All(i => labels[i] == null
                    || rowHeadings.Any(other => other.Labels[i] != null && other.Labels[i].Text == labels[i].Text));
                if (!repeats)
                {
                    rowHeadings.Add(new HeadingRow { Caption = caption, Labels = labels });
                }
            }

            headings.AddRange(rowHeadings);
            if (items.Any(i => i.AccountCode != null))
            {
                headings.Add(new HeadingRow { Caption = "Account Code", Labels = items.Select(i => i.AccountCode).ToArray() });
            }

            return headings;
        }

        /// <summary>Empties the form's rows: their cells, the merges and conditional formats over them.</summary>
        private static void ClearFormRows(XElement worksheet, XElement sheetData, int start, int end)
        {
            sheetData.Elements(Main + "row").Where(r => { var number = (int?)r.Attribute("r") ?? 0; return number >= start && number <= end; }).Remove();

            var mergeCells = worksheet.Element(Main + "mergeCells");
            if (mergeCells != null)
            {
                mergeCells.Elements(Main + "mergeCell")
                    .Where(m => { VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int> area; return TryParseRange((string)m.Attribute("ref"), out area) && area.FirstRow <= end && area.LastRow >= start; })
                    .Remove();
                var remaining = mergeCells.Elements(Main + "mergeCell").Count();
                if (remaining == 0)
                {
                    mergeCells.Remove();
                }
                else
                {
                    mergeCells.SetAttributeValue("count", remaining);
                }
            }

            worksheet.Elements(Main + "conditionalFormatting")
                .Where(f => ((string)f.Attribute("sqref") ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .All(token => { VT_FirstRow_LastRow_FirstColumn_LastColumn<int, int, int, int> area; return TryParseRange(token, out area) && area.FirstRow >= start && area.LastRow <= end; }))
                .Remove();
        }

        /// <summary>Adds merges in the schema position (after sheetData and the elements Excel puts between).</summary>
        private static void AddMerges(XElement worksheet, IReadOnlyList<string> references)
        {
            if (references.Count == 0)
            {
                return;
            }

            var mergeCells = worksheet.Element(Main + "mergeCells");
            if (mergeCells == null)
            {
                mergeCells = new XElement(Main + "mergeCells");
                var anchor = worksheet.Elements().LastOrDefault(e => MergeCellsFollow.Contains(e.Name.LocalName));
                if (anchor != null)
                {
                    anchor.AddAfterSelf(mergeCells);
                }
                else
                {
                    worksheet.Add(mergeCells);
                }
            }

            foreach (var reference in references)
            {
                mergeCells.Add(new XElement(Main + "mergeCell", new XAttribute("ref", reference)));
            }

            mergeCells.SetAttributeValue("count", mergeCells.Elements(Main + "mergeCell").Count());
        }

        /// <summary>Worksheet elements that come before mergeCells (CT_Worksheet sequence).</summary>
        private static readonly HashSet<string> MergeCellsFollow = new HashSet<string>(StringComparer.Ordinal)
        {
            "sheetPr", "dimension", "sheetViews", "sheetFormatPr", "cols", "sheetData", "sheetCalcPr", "sheetProtection",
            "protectedRanges", "scenarios", "autoFilter", "sortState", "dataConsolidate", "customSheetViews"
        };

        private static void WriteText(XElement sheetData, int column, int row, string text, string style)
        {
            var cell = GetOrCreateCell(sheetData, ColumnName(column), row);
            SetStyle(cell, style);
            if (!string.IsNullOrEmpty(text))
            {
                SetInlineString(cell, text);
            }
        }

        private static void SetStyle(XElement cell, string style)
        {
            if (style != null)
            {
                cell.SetAttributeValue("s", style);
            }
        }

        private static string MostCommon(IEnumerable<string> styles) =>
            styles.Where(s => s != null).GroupBy(s => s, StringComparer.Ordinal).OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefault();

        /// <summary>Lines a wrapped text needs in a width of about <paramref name="characters"/> characters.</summary>
        private static int TextLines(string text, int characters) =>
            string.IsNullOrEmpty(text) ? 1 : Math.Min(6, (text.Length + characters - 1) / characters);

        private static void SetRowHeight(XElement sheetData, int rowNumber, int lines)
        {
            var row = sheetData.Elements(Main + "row").First(r => (int?)r.Attribute("r") == rowNumber);
            row.SetAttributeValue("ht", (lines * 15 + 3).ToString(CultureInfo.InvariantCulture));
            row.SetAttributeValue("customHeight", "1");
        }
    }
}
