﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    public sealed class XsdValidationService
    {
        /// <param name="step">Progress through the XML while it is checked (optional).</param>
        public XsdValidationResultDto ValidateBytes(byte[] xmlBytes, string xsdPath, string target, ValidationStep step = null)
        {
            step?.Start("Loading the XSD");
            var messages = new List<XsdValidationMessageDto>();
            // No resolver: schemas and documents may not pull external resources.
            var schemas = new XmlSchemaSet { XmlResolver = null };
            using (var xsdStream = File.OpenRead(xsdPath))
            using (var xsdReader = XmlReader.Create(xsdStream, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null }))
            {
                schemas.Add(null, xsdReader);
            }

            var settings = new XmlReaderSettings
            {
                ValidationType = ValidationType.Schema,
                Schemas = schemas,
                DtdProcessing = DtdProcessing.Prohibit,
                XmlResolver = null
            };
            settings.ValidationFlags |= XmlSchemaValidationFlags.ReportValidationWarnings;
            settings.ValidationEventHandler += (_, args) =>
            {
                messages.Add(new XsdValidationMessageDto
                {
                    Severity = args.Severity.ToString(),
                    Message = args.Message,
                    LineNumber = args.Exception?.LineNumber ?? 0,
                    LinePosition = args.Exception?.LinePosition ?? 0
                });
            };

            try
            {
                using (var xmlStream = new MemoryStream(xmlBytes))
                {
                using (var reader = XmlReader.Create(xmlStream, settings))
                {
                var nodes = 0;
                string form = null;
                while (reader.Read())
                {
                    if (step != null && reader.NodeType == XmlNodeType.Element && reader.Depth == 1)
                    {
                        form = reader.LocalName;
                    }

                    if (step != null && ++nodes % 2000 == 0)
                    {
                        step.Report(xmlStream.Position, xmlStream.Length, (form == null) ? null : $"Form {form}");
                    }
                }

                step?.Done();
                }
                }
            }
            catch (XmlException ex)
            {
                messages.Add(new XsdValidationMessageDto
                {
                    Severity = "Error",
                    Message = ex.Message,
                    LineNumber = ex.LineNumber,
                    LinePosition = ex.LinePosition
                });
            }
            catch (XmlSchemaValidationException ex)
            {
                messages.Add(new XsdValidationMessageDto
                {
                    Severity = "Error",
                    Message = ex.Message,
                    LineNumber = ex.LineNumber,
                    LinePosition = ex.LinePosition
                });
            }

            return new XsdValidationResultDto
            {
                Target = target,
                IsValid = messages.All(m => !string.Equals(m.Severity, "Error", StringComparison.OrdinalIgnoreCase)),
                Messages = messages
            };
        }
    }

}
