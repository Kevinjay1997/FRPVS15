﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    internal static partial class XsdExcelValidationBuilder
    {
        private static readonly XNamespace Main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

        /// <param name="listSource">
        /// For allowed-value lists too long for Excel's 255-character inline list (e.g. 249 country codes): returns a
        /// workbook name for a range that holds the values. Without it such a field falls back to a text check.
        /// </param>
        public static XElement Build(SchemaNodeDto node, string sqref, Func<IReadOnlyList<string>, string> listSource = null)
        {
            if (node.DataType == "complex")
            {
                return null;
            }

            var validation = node.Validation ?? new SchemaValidationDto();
            var element = BuildListValidation(node, validation, sqref, listSource)
                ?? BuildNumberValidation(node, validation, sqref)
                ?? BuildDateValidation(node, validation, sqref)
                ?? (node.DataType == "boolean" ? BaseValidation("list", sqref, node)
                    .With(new XElement(Main + "formula1", "\"true,false,1,0\"")) : null)
                ?? BuildTextValidation(node, validation, sqref, TopLeftCell(sqref))
                // Any other value (free text without XSD limits, or a type Excel cannot check): still validated, so the
                // cell shows its rule and Excel's error alert (Excel's own limit is 32,767 characters).
                ?? BoundedValidation("textLength", sqref, node, null, "32767");
            return (element == null) ? null : WithInputMessage(element, node, validation);
        }

        /// <summary>
        /// Writes the mapped cells' validations into the worksheet. A validation the template already has (BSP's own,
        /// often without an error alert, and often over a whole range such as F117:F149) keeps only the cells that are not
        /// mapped: Excel applies one validation per cell, so a mapped cell must only have ours. The same is done for the
        /// template's newer x14 validations (e.g. dropdowns that read another sheet) in the worksheet's extLst.
        /// </summary>
        public static void UpsertDataValidations(XElement worksheetRoot, IEnumerable<XElement> validations)
        {
            var newItems = validations.ToList();
            var managed = new HashSet<VT_Column_Row<int, int>>();
            foreach (var token in newItems.SelectMany(v => ((string)v.Attribute("sqref") ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries)))
            {
                VT_C1_R1_C2_R2<int, int, int, int> range;
                if (TryParseRange(token, out range))
                {
                    for (var column = range.C1; column <= range.C2 && managed.Count < 2000000; column++)
                    {
                        for (var row = range.R1; row <= range.R2 && row - range.R1 < 100000; row++)
                        {
                            managed.Add(new VT_Column_Row<int, int>(column, row));
                        }
                    }
                }
            }

            var existingItems = new List<XElement>();
            foreach (var item in worksheetRoot.Elements(Main + "dataValidations").Elements(Main + "dataValidation"))
            {
                var remaining = Subtract((string)item.Attribute("sqref") ?? "", managed);
                if (remaining.Length > 0)
                {
                    item.SetAttributeValue("sqref", remaining);
                    existingItems.Add(item);
                }
            }

            TrimExtensionValidations(worksheetRoot, sqref => Subtract(sqref, managed));
            var items = existingItems.Concat(newItems).ToList();
            worksheetRoot.Elements(Main + "dataValidations").Remove();
            if (items.Count == 0)
            {
                return;
            }

            var dataValidations = new XElement(Main + "dataValidations", new XAttribute("count", items.Count));
            dataValidations.Add(items);

            // CT_Worksheet is a sequence: dataValidations must come before every element that follows it in the schema,
            // or Excel reports the workbook as damaged and offers to repair it.
            var before = worksheetRoot.Elements()
                .FirstOrDefault(element => element.Name.Namespace == Main && ElementsAfterDataValidations.Contains(element.Name.LocalName));
            if (before != null)
            {
                before.AddBeforeSelf(dataValidations);
            }
            else
            {
                worksheetRoot.Add(dataValidations);
            }
        }

        private static readonly XNamespace X14 = "http://schemas.microsoft.com/office/spreadsheetml/2009/9/main";
        private static readonly XNamespace ExcelMain = "http://schemas.microsoft.com/office/excel/2006/main";

        /// <summary>
        /// Removes the validations over rows <paramref name="firstRow"/>..<paramref name="lastRow"/> (rows the writer
        /// emptied): a validation there goes, one that reaches over them keeps its other rows. The x14 ones too.
        /// </summary>
        public static void RemoveRows(XElement worksheetRoot, int firstRow, int lastRow)
        {
            var dataValidations = worksheetRoot.Element(Main + "dataValidations");
            if (dataValidations != null)
            {
                foreach (var item in dataValidations.Elements(Main + "dataValidation").ToList())
                {
                    var remaining = WithoutRows((string)item.Attribute("sqref") ?? "", firstRow, lastRow);
                    if (remaining.Length == 0)
                    {
                        item.Remove();
                    }
                    else
                    {
                        item.SetAttributeValue("sqref", remaining);
                    }
                }

                var count = dataValidations.Elements(Main + "dataValidation").Count();
                if (count == 0)
                {
                    dataValidations.Remove();
                }
                else
                {
                    dataValidations.SetAttributeValue("count", count);
                }
            }

            TrimExtensionValidations(worksheetRoot, sqref => WithoutRows(sqref, firstRow, lastRow));
        }

        /// <summary>An sqref without the rows <paramref name="firstRow"/>..<paramref name="lastRow"/>.</summary>
        private static string WithoutRows(string sqref, int firstRow, int lastRow)
        {
            var result = new List<string>();
            foreach (var token in sqref.Split(' ', StringSplitOptions.RemoveEmptyEntries))
            {
                VT_C1_R1_C2_R2<int, int, int, int> range;
                if (!TryParseRange(token, out range) || range.R2 < firstRow || range.R1 > lastRow)
                {
                    result.Add(token);
                    continue;
                }

                if (range.R1 < firstRow)
                {
                    result.Add(Reference(range.C1, range.R1, range.C2, firstRow - 1));
                }

                if (range.R2 > lastRow)
                {
                    result.Add(Reference(range.C1, lastRow + 1, range.C2, range.R2));
                }
            }

            return string.Join(" ", result);
        }

        /// <summary>The x14 validations in extLst get the same change (<paramref name="trim"/> of their sqref); an emptied list is removed.</summary>
        private static void TrimExtensionValidations(XElement worksheetRoot, Func<string, string> trim)
        {
            foreach (var list in worksheetRoot.Elements(Main + "extLst").Elements(Main + "ext").Elements(X14 + "dataValidations").ToList())
            {
                foreach (var item in list.Elements(X14 + "dataValidation").ToList())
                {
                    var sqref = item.Element(ExcelMain + "sqref");
                    var remaining = (sqref == null) ? "" : trim(sqref.Value);
                    if (remaining.Length == 0)
                    {
                        item.Remove();
                    }
                    else
                    {
                        sqref.Value = remaining;
                    }
                }

                var count = list.Elements(X14 + "dataValidation").Count();
                if (count == 0)
                {
                    var ext = list.Parent;
                    var extLst = ext.Parent;
                    list.Remove();
                    if (!ext.HasElements)
                    {
                        ext.Remove();
                    }

                    if (!extLst.HasElements)
                    {
                        extLst.Remove();
                    }
                }
                else
                {
                    list.SetAttributeValue("count", count);
                }
            }
        }

        /// <summary>An sqref ("A1 C3:C9") without the given cells, as few rectangles as practical.</summary>
        private static string Subtract(string sqref, ISet<VT_Column_Row<int, int>> cells)
        {
            var result = new List<string>();
            foreach (var token in sqref.Split(' ', StringSplitOptions.RemoveEmptyEntries))
            {
                VT_C1_R1_C2_R2<int, int, int, int> range;
                if (!TryParseRange(token, out range) || cells.Count == 0)
                {
                    result.Add(token);
                    continue;
                }

                var inside = cells.Where(c => c.Column >= range.C1 && c.Column <= range.C2 && c.Row >= range.R1 && c.Row <= range.R2)
                    .GroupBy(c => c.Column)
                    .ToDictionary(g => g.Key, g => g.Select(c => c.Row).OrderBy(r => r).ToList());
                if (inside.Count == 0)
                {
                    result.Add(token);
                    continue;
                }

                // Columns without mapped cells stay together as one rectangle; the others are split around the cells.
                var column = range.C1;
                while (column <= range.C2)
                {
                    List<int> rows;
                    if (!inside.TryGetValue(column, out rows))
                    {
                        var last = column;
                        while (last + 1 <= range.C2 && !inside.ContainsKey(last + 1))
                        {
                            last++;
                        }

                        result.Add(Reference(column, range.R1, last, range.R2));
                        column = last + 1;
                        continue;
                    }

                    var start = range.R1;
                    foreach (var row in rows)
                    {
                        if (row > start)
                        {
                            result.Add(Reference(column, start, column, row - 1));
                        }

                        start = row + 1;
                    }

                    if (start <= range.R2)
                    {
                        result.Add(Reference(column, start, column, range.R2));
                    }

                    column++;
                }
            }

            return string.Join(" ", result);
        }

        private static string Reference(int c1, int r1, int c2, int r2) =>
            c1 == c2 && r1 == r2
                ? $"{ColumnLetters(c1)}{r1}"
                : $"{ColumnLetters(c1)}{r1}:{ColumnLetters(c2)}{r2}";

        private static string ColumnLetters(int column)
        {
            var name = "";
            while (column > 0)
            {
                var remainder = (column - 1) % 26;
                name = (char)('A' + remainder) + name;
                column = (column - 1) / 26;
            }

            return name;
        }

        private static bool TryParseRange(string token, out VT_C1_R1_C2_R2<int, int, int, int> range)
        {
            range = default(VT_C1_R1_C2_R2<int, int, int, int>);
            var parts = token.Replace("$", "", StringComparison.Ordinal).Split(':');
            int c1;
            int r1;
            if (parts.Length < 1 || parts.Length > 2 || !TryParseCell(parts[0], out c1, out r1))
            {
                return false;
            }

            var c2 = c1;
            var r2 = r1;
            if (parts.Length == 2 && !TryParseCell(parts[1], out c2, out r2))
            {
                return false;
            }

            range = new VT_C1_R1_C2_R2<int, int, int, int>(Math.Min(c1, c2), Math.Min(r1, r2), Math.Max(c1, c2), Math.Max(r1, r2));
            return true;
        }

        private static bool TryParseCell(string text, out int column, out int row)
        {
            column = 0;
            row = 0;
            var i = 0;
            while (i < text.Length && CompatChar.IsAsciiLetter(text[i]))
            {
                column = column * 26 + (char.ToUpperInvariant(text[i]) - 'A' + 1);
                i++;
            }

            return i > 0 && i < text.Length && int.TryParse(text.Substring(i), System.Globalization.NumberStyles.None, CultureInfo.InvariantCulture, out row) && row > 0;
        }

        private static readonly HashSet<string> ElementsAfterDataValidations =
        new HashSet<string> { "hyperlinks", "printOptions", "pageMargins", "pageSetup", "headerFooter", "rowBreaks", "colBreaks", "customProperties", "cellWatches", "ignoredErrors", "smartTags", "drawing", "legacyDrawing", "legacyDrawingHF", "drawingHF", "picture", "oleObjects", "controls", "webPublishItems", "tableParts", "extLst" };

        private static XElement BuildListValidation(SchemaNodeDto node, SchemaValidationDto validation, string sqref,
            Func<IReadOnlyList<string>, string> listSource)
        {
            if (validation.Enumerations.Count == 0)
            {
                return null;
            }

            var formula = BuildInlineListFormula(validation.Enumerations) ?? listSource?.Invoke(validation.Enumerations);
            if (formula == null)
            {
                return null;
            }

            return BaseValidation("list", sqref, node)
                .With(new XElement(Main + "formula1", formula));
        }

        private static XElement BuildNumberValidation(SchemaNodeDto node, SchemaValidationDto validation, string sqref)
        {
            if (!(node.DataType == "integer" || node.DataType == "decimal"))
            {
                return null;
            }

            var min = NormalizeDecimal(validation.MinInclusive);
            var max = NormalizeDecimal(validation.MaxInclusive);
            var cell = sqref.Split(' ', StringSplitOptions.RemoveEmptyEntries)[0].Split(':')[0];
            var conditions = new List<string> { $"ISNUMBER({cell})" };
            if (min != null) conditions.Add($"{cell}>={min}");
            if (max != null) conditions.Add($"{cell}<={max}");
            var digits = node.DataType == "integer" ? 0 : validation.FractionDigits;
            if (digits != null) conditions.Add($"{cell}=ROUND({cell},{digits.Value})");
            int total;
            if (CompatPattern.Is(validation.TotalDigits, out total))
            {
                // Count digits in the value, not the cell's display format or scientific notation.
                var text = $"SUBSTITUTE(TEXT(ABS({cell}),\"0.############################\"),\".\",\"\")";
                conditions.Add($"LEN({text})-IF(ABS({cell})<1,1,0)<={total}");
            }
            var formula = $"IFERROR(AND({string.Join(",", conditions)}),FALSE)";
            if (!node.IsRequired) formula = $"OR({cell}=\"\",{formula})";
            return BaseValidation("custom", sqref, node).With(new XElement(Main + "formula1", formula));
        }

        private static XElement BuildDateValidation(SchemaNodeDto node, SchemaValidationDto validation, string sqref)
        {
            if (!(node.DataType == "date" || node.DataType == "dateTime"))
            {
                return null;
            }

            var min = NormalizeDate(validation.MinInclusive);
            var max = NormalizeDate(validation.MaxInclusive);
            return BoundedValidation("date", sqref, node, min ?? "DATE(1900,1,1)", max ?? "DATE(9999,12,31)");
        }

        private static XElement BuildTextValidation(SchemaNodeDto node, SchemaValidationDto validation, string sqref, string cell)
        {
            if (node.DataType != "string")
            {
                return null;
            }

            int exactLength;
            if (CompatPattern.Is(validation.Length, out exactLength))
            {
                validation = validation.With(copy => { copy.MinLength = exactLength; copy.MaxLength = exactLength; });
            }

            var pattern = validation.Pattern?.Trim();
            System.Text.RegularExpressions.Match match;
            var exactDigits = (pattern == null) ? null : (CompatPattern.Is(ExactDigitsRegex().Match(pattern), out match) && object.Equals(match.Success, true)) ? match.Groups[1].Value : null;
            var noLeadingSpace = pattern == @"[^\s].*" || pattern == @"\S.*";
            if (exactDigits == null && !noLeadingSpace)
            {
                var min = validation.MinLength?.ToString(CultureInfo.InvariantCulture);
                var max = validation.MaxLength?.ToString(CultureInfo.InvariantCulture);
                if (min == null && max == null)
                {
                    // Free text: nothing to check, except that a required field is not left empty once filled in.
                    return node.IsRequired ? BoundedValidation("textLength", sqref, node, "1", null) : null;
                }

                return BoundedValidation("textLength", sqref, node, min, max);
            }

            var conditions = new List<string>();
            if (exactDigits != null)
            {
                conditions.Add($"LEN({cell})={exactDigits}");
                conditions.Add($"ISNUMBER(--{cell})");
                conditions.Add($"ISERROR(FIND(\".\",{cell}))");
            }
            else
            {
                conditions.Add($"LEFT({cell},1)<>\" \"");
                int minLength;
                if (CompatPattern.Is(validation.MinLength, out minLength))
                {
                    conditions.Add(FormattableString.Invariant($"LEN({cell})>={minLength}"));
                }

                int maxLength;
                if (CompatPattern.Is(validation.MaxLength, out maxLength))
                {
                    conditions.Add(FormattableString.Invariant($"LEN({cell})<={maxLength}"));
                }
            }

            return Custom(sqref, node, $"AND({string.Join(",", conditions)})");
        }

        private static XElement Custom(string sqref, SchemaNodeDto node, string formula) =>
            BaseValidation("custom", sqref, node).With(new XElement(Main + "formula1", formula));

        /// <summary>A relative formula refers to the first cell of the validated range.</summary>
        private static string TopLeftCell(string sqref)
        {
            var first = sqref.Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? sqref;
            return first.Split(':')[0].Replace("$", "", StringComparison.Ordinal).ToUpperInvariant();
        }

        /// <summary>The rule, shown when the cell is selected (Excel allows a 32-character title and a 255-character message).</summary>
        private static XElement WithInputMessage(XElement element, SchemaNodeDto node, SchemaValidationDto validation)
        {
            var rule = RuleText(node, validation);
            element.SetAttributeValue("showInputMessage", "1");
            element.SetAttributeValue("promptTitle", Truncate(node.Name, 32));
            element.SetAttributeValue("prompt", Truncate(rule, 255));
            return element;
        }

        private static string RuleText(SchemaNodeDto node, SchemaValidationDto validation)
        {
            int exactLength;
            if (CompatPattern.Is(validation.Length, out exactLength))
            {
                validation = validation.With(copy => { copy.MinLength = exactLength; copy.MaxLength = exactLength; });
            }

            var parts = new List<string>();
            if (validation.Enumerations.Count > 0)
            {
                parts.Add("Choose a value from the list");
            }
            else
            {
                switch (node.DataType)
                {
                    case "integer":
                        parts.Add("Whole number");
                        break;
                    case "decimal":
                        int digits__3;
                        parts.Add(validation.FractionDigits == 0 ? "Whole number" : validation.FractionDigits == 1 ? "Number, up to 1 decimal" : CompatPattern.Is(validation.FractionDigits, out digits__3) ? FormattableString.Invariant($"Number, up to {digits__3} decimals") : validation.FractionDigits == null ? "Number" : CompatThrow.As<string>(new System.InvalidOperationException("No case of the switch expression matched.")));
                        break;
                    case "date":
                    case "dateTime":
                        parts.Add("Date");
                        break;
                    case "boolean":
                        parts.Add("true or false");
                        break;
                    default:
                        parts.Add("Text");
                        break;
                }

                if (node.DataType == "integer" || node.DataType == "decimal")
                {
                    var min = NormalizeDecimal(validation.MinInclusive);
                    var max = NormalizeDecimal(validation.MaxInclusive);
                    if (min != null && max != null)
                    {
                        parts.Add($"from {min} to {max}");
                    }
                    else if (min != null)
                    {
                        parts.Add($"at least {min}");
                    }
                    else if (max != null)
                    {
                        parts.Add($"at most {max}");
                    }
                }
                else if (node.DataType == "string")
                {
                    var pattern = validation.Pattern?.Trim();
                    System.Text.RegularExpressions.Match digits;
                    if (pattern != null && CompatPattern.Is(ExactDigitsRegex().Match(pattern), out digits) && object.Equals(digits.Success, true))
                    {
                        parts.Add($"exactly {digits.Groups[1].Value} digits");
                    }
                    else
                    {
                        int minLength;
                        int maxLength;
                        if (CompatPattern.Is(validation.MinLength, out minLength) && CompatPattern.Is(validation.MaxLength, out maxLength))
                        {
                            parts.Add(minLength == maxLength
                                ? FormattableString.Invariant($"exactly {maxLength} characters")
                                : FormattableString.Invariant($"{minLength} to {maxLength} characters"));
                        }
                        else 
                        {
                            int onlyMax;
    if (CompatPattern.Is(validation.MaxLength, out onlyMax))
                        {
                            parts.Add(FormattableString.Invariant($"up to {onlyMax} characters"));
                        }
                        else 
                        {
                            int onlyMin;
    if (CompatPattern.Is(validation.MinLength, out onlyMin))
                        {
                            parts.Add(FormattableString.Invariant($"at least {onlyMin} characters"));
                        }
                        }
                        }

                        if (pattern == @"[^\s].*" || pattern == @"\S.*")
                        {
                            parts.Add("not starting with a space");
                        }
                        else if (!string.IsNullOrEmpty(pattern))
                        {
                            parts.Add($"format {pattern}");
                        }
                    }
                }
            }

            var text = string.Join(", ", parts) + ".";
            return node.IsRequired ? text + " Required." : text;
        }

        private static string Truncate(string value, int length) => value.Length <= length ? value : value.Substring(0, length - 1) + "…";

        private static System.Text.RegularExpressions.Regex ExactDigitsRegex() { return ExactDigitsRegexInstance; }

        private static XElement BoundedValidation(string type, string sqref, SchemaNodeDto node, string min, string max)
        {
            var element = BaseValidation(type, sqref, node);
            if (min != null && max != null)
            {
                element.SetAttributeValue("operator", "between");
                element.Add(new XElement(Main + "formula1", min));
                element.Add(new XElement(Main + "formula2", max));
            }
            else if (min != null)
            {
                element.SetAttributeValue("operator", "greaterThanOrEqual");
                element.Add(new XElement(Main + "formula1", min));
            }
            else
            {
                element.SetAttributeValue("operator", "lessThanOrEqual");
                element.Add(new XElement(Main + "formula1", max));
            }

            return element;
        }

        private static XElement BaseValidation(string type, string sqref, SchemaNodeDto node) => new XElement(Main + "dataValidation",
            new XAttribute("type", type),
            new XAttribute("allowBlank", node.IsRequired ? "0" : "1"),
            new XAttribute("showErrorMessage", "1"),
            new XAttribute("errorStyle", "stop"),
            new XAttribute("errorTitle", "Does not match XSD"),
            new XAttribute("error", ErrorText(node)),
            new XAttribute("sqref", sqref));

        private static string ErrorText(SchemaNodeDto node)
        {
            if (node.Validation.Enumerations.Count > 0) return "Choose one of the allowed XSD values.";
            var parts = new List<string> { $"Enter a valid {node.DataType} value." };
            string min;
            if (CompatPattern.Is(node.Validation.MinInclusive, out min)) parts.Add($"Minimum: {min}.");
            string max;
            if (CompatPattern.Is(node.Validation.MaxInclusive, out max)) parts.Add($"Maximum: {max}.");
            int digits;
            if (CompatPattern.Is(node.Validation.FractionDigits, out digits)) parts.Add($"At most {digits} decimal places.");
            int total;
            if (CompatPattern.Is(node.Validation.TotalDigits, out total)) parts.Add($"At most {total} digits.");
            var message = string.Join(" ", parts);
            return message.Length <= 225 ? message : message.Substring(0, 225);
        }

        private static string NormalizeDecimal(string value)
        {
            decimal parsed;
            return decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out parsed)
                ? parsed.ToString(CultureInfo.InvariantCulture)
                : null;
        }

        private static string NormalizeDate(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            var datePart = value.Length >= 10 ? value.Substring(0, 10) : value;
            DateOnly date;
            return DateOnly.TryParseExact(datePart, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date)
                ? FormattableString.Invariant($"DATE({date.Year},{date.Month},{date.Day})")
                : null;
        }

        private static string BuildInlineListFormula(IReadOnlyList<string> values)
        {
            if (values.Any(v => v.Contains(',') || v.Contains('\n') || v.Contains('\r')))
            {
                return null;
            }

            var joined = string.Join(",", values.Select(v => v.Replace("\"", "\"\"", StringComparison.Ordinal)));
            var formula = $"\"{joined}\"";
            return formula.Length <= 255 ? formula : null;
        }

        private static XElement With(this XElement element, params object[] content)
        {
            element.Add(content);
            return element;
        }

        private static readonly System.Text.RegularExpressions.Regex ExactDigitsRegexInstance = new System.Text.RegularExpressions.Regex(@"^\[0-9\]\{(\d{1,2})\}$", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

}
