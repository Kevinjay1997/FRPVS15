﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Excel XML map bindings for the sheet copies of a split form. Excel binds an element once per workbook, and never an
    /// element of a repeating item to a form's cells. The first copy is bound under the XSD's own names (the map's schema
    /// lets the item occur once, see <see cref="SetSingleItem"/>); every other copy gets an extra form element in the map: a
    /// clone of the form named "{Form}_{value}" (e.g. CAR_Part_IV_4c_USD) whose item occurs once. Each copy's cells are
    /// bound to its clone (single cells for the item's own fields, XML list tables for the lists inside it), so Excel's
    /// XML Source shows every copy mapped and Excel can export it.
    /// <para>
    /// The clone elements are not in BSP's XSD: an XML exported by Excel has CAR_Part_IV_4c plus CAR_Part_IV_4c_USD…
    /// where BSP expects one CAR_Part_IV_4c with an item per currency. <see cref="Normalize"/> turns such an XML back into
    /// the XSD's structure; the app does that whenever an XML is uploaded or validated, and on "Download the merged XML".
    /// </para>
    /// </summary>
    public static partial class SheetCopyMap
    {
        private static readonly XNamespace Xs = "http://www.w3.org/2001/XMLSchema";

        /// <summary>One sheet copy and its clone form element.</summary>
        /// <param name="FormPath">The XSD form, e.g. /CAR_M/CAR_Part_IV_4c.</param>
        /// <param name="ClonePath">Its clone for this copy, e.g. /CAR_M/CAR_Part_IV_4c_PHP.</param>
        public sealed class Copy : IRecord<Copy>, IEquatable<Copy>
    {
        public SheetSplitRules.ResolvedSplit Split { get; set; }

        public string Value { get; set; }

        public string SheetName { get; set; }

        public string Form { get; set; }

        public string FormPath { get; set; }

        public string CloneName { get; set; }

        public string ClonePath { get; set; }

        public Copy(SheetSplitRules.ResolvedSplit Split, string Value, string SheetName, string Form, string FormPath, string CloneName, string ClonePath)
    {
    this.Split = Split;
    this.Value = Value;
    this.SheetName = SheetName;
    this.Form = Form;
    this.FormPath = FormPath;
    this.CloneName = CloneName;
    this.ClonePath = ClonePath;
    }

        public void Deconstruct(out SheetSplitRules.ResolvedSplit Split, out string Value, out string SheetName, out string Form, out string FormPath, out string CloneName, out string ClonePath)
    {
    Split = this.Split;
    Value = this.Value;
    SheetName = this.SheetName;
    Form = this.Form;
    FormPath = this.FormPath;
    CloneName = this.CloneName;
    ClonePath = this.ClonePath;
    }

            public string ItemName => Split.Form.GroupPath.Substring(FormPath.Length + 1);


            /// <summary>The path in the clone for a path of the form (…/CAR_Part_IV_4c/… to …/CAR_Part_IV_4c_PHP/…).</summary>
            public string ToClone(string path) => ClonePath + path.Substring(FormPath.Length);

        public bool Equals(Copy other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<SheetSplitRules.ResolvedSplit>.Default.Equals(Split, other.Split)
    && EqualityComparer<string>.Default.Equals(Value, other.Value)
    && EqualityComparer<string>.Default.Equals(SheetName, other.SheetName)
    && EqualityComparer<string>.Default.Equals(Form, other.Form)
    && EqualityComparer<string>.Default.Equals(FormPath, other.FormPath)
    && EqualityComparer<string>.Default.Equals(CloneName, other.CloneName)
    && EqualityComparer<string>.Default.Equals(ClonePath, other.ClonePath);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as Copy);
    }

        public static bool operator ==(Copy left, Copy right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(Copy left, Copy right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 6118;
    hash = hash * -1521134295 + EqualityComparer<SheetSplitRules.ResolvedSplit>.Default.GetHashCode(Split);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Value);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SheetName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Form);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(FormPath);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(CloneName);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ClonePath);
    return hash;
    }
    }

        public override string ToString()
    {
    return "Copy { " + "Split = " + Split + ", " + "Value = " + Value + ", " + "SheetName = " + SheetName + ", " + "Form = " + Form + ", " + "FormPath = " + FormPath + ", " + "CloneName = " + CloneName + ", " + "ClonePath = " + ClonePath + ", " + "ItemName = " + ItemName + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public Copy CloneRecord()
    {
    return (Copy)MemberwiseClone();
    }

    }

        /// <summary>
        /// The copies that get Excel bindings: split forms whose item sits directly in a form under the root element
        /// (/Root/Form/Form_Item), each value with a clone name that is a valid, unused XML name.
        /// </summary>
        public static IReadOnlyList<Copy> Copies(FrpProjectDto project)
        {
            var result = new List<Copy>();
            // Clone names must not be a form the XSD already has.
            var used = project.SchemaNodes
                .Where(n => n.ParentPath == $"/{project.RootElement}")
                .Select(n => n.Name)
                .ToHashSet(StringComparer.Ordinal);
            foreach (var split in SheetSplitRules.Resolve(project))
            {
                var tokens = split.Form.GroupPath.Split('/', StringSplitOptions.RemoveEmptyEntries);
                if (tokens.Length != 3 || tokens[0] != project.RootElement)
                {
                    continue;
                }

                var formPath = $"/{tokens[0]}/{tokens[1]}";
                var copies = new List<Copy>();
                foreach (var sheet in split.Sheets)
                {
                    var value = sheet.Value;
                    var sheetName = sheet.SheetName;
                    var clone = $"{tokens[1]}_{NameChars().Replace(value, "_")}";
                    if (!used.Add(clone))
                    {
                        copies.Clear(); // a name the XSD already has (or two values giving one name): no Excel binding for this form
                        break;
                    }

                    copies.Add(new Copy(split, value, sheetName, tokens[1], formPath, clone, $"/{tokens[0]}/{clone}"));
                }

                result.AddRange(copies);
            }

            return result;
        }

        /// <summary>The split forms whose copies are bound in Excel (all their items' paths start with these).</summary>
        public static ISet<string> BoundGroups(FrpProjectDto project) =>
            Copies(project).Select(c => c.Split.Form.GroupPath).ToHashSet(StringComparer.Ordinal);

        // ---------- the XML map's schema ----------

        /// <summary>
        /// Adds each copy's clone form element to the XML map's schema, right after the form: the same content, with the
        /// item occurring once. Returns the copies whose form could be cloned (an inline form definition is needed).
        /// </summary>
        public static IReadOnlyList<Copy> AddClones(XElement schema, string rootElement, IReadOnlyList<Copy> copies)
        {
            var root = schema.Elements(Xs + "element").FirstOrDefault(e => (string)e.Attribute("name") == rootElement);
            var added = new List<Copy>();
            if (root == null)
            {
                return added;
            }

            foreach (var group in copies.GroupBy(c => c.Form))
            {
                var form = FormElement(root, group.Key);
                if (form == null || form.Attribute("type") != null || form.Attribute("ref") != null)
                {
                    continue;
                }

                var itemName = group.First().ItemName;
                var anchor = form;
                foreach (var copy in group)
                {
                    if (anchor.Parent.Elements(Xs + "element").Any(e => (string)e.Attribute("name") == copy.CloneName))
                    {
                        added.Add(copy); // already in the map (a template exported by the app)
                        continue;
                    }

                    var clone = new XElement(form);
                    clone.SetAttributeValue("name", copy.CloneName);
                    clone.SetAttributeValue("minOccurs", "0");
                    var item = clone.Descendants(Xs + "element").FirstOrDefault(e => (string)e.Attribute("name") == itemName);
                    if (item == null)
                    {
                        break;
                    }

                    // The item occurs once in the clone: on the item itself and on the group (sequence / choice) around it.
                    if (item.Attribute("maxOccurs") != null)
                    {
                        item.SetAttributeValue("maxOccurs", "1");
                    }

                    for (var particle = item.Parent; particle != null && particle != clone; particle = particle.Parent)
                    {
                        if (particle.Name == Xs + "sequence" || particle.Name == Xs + "choice")
                        {
                            if (particle.Attribute("maxOccurs") != null)
                            {
                                particle.SetAttributeValue("maxOccurs", "1");
                            }
                        }
                    }

                    anchor.AddAfterSelf(clone);
                    anchor = clone;
                    added.Add(copy);
                }
            }

            return added;
        }

        /// <summary>The form's local element declaration inside the root element's content (sequence / all / choice).</summary>
        private static XElement FormElement(XElement root, string form)
        {
            var content = root.Element(Xs + "complexType");
            return content?.Descendants(Xs + "element")
                .FirstOrDefault(e => (string)e.Attribute("name") == form
                    && e.Ancestors(Xs + "element").FirstOrDefault() == root);
        }

        // ---------- the XSD nodes of a clone, to bind its cells ----------

        /// <summary>
        /// The project seen through one copy's clone: the clone's schema nodes (the item occurs once, so its own fields are
        /// single cells; the lists inside it stay lists) and the form's mappings moved to the copy's sheet and clone paths.
        /// </summary>
        public static FrpProjectDto ForCopy(FrpProjectDto project, Copy copy)
        {
            var nodes = project.SchemaNodes
                .Where(n => string.Equals(n.Path, copy.FormPath, StringComparison.Ordinal) || n.Path.StartsWith(copy.FormPath + "/", StringComparison.Ordinal))
                .ToList();
            var itemPath = copy.Split.Form.GroupPath;
            var repeating = nodes.Where(n => n.IsRepeating && n.Path != itemPath).Select(n => n.Path).ToList();
            var cloneNodes = nodes.Select(n =>
            {
                var inList = repeating.Any(r => n.Path == r || n.Path.StartsWith(r + "/", StringComparison.Ordinal));
                return n.With(inner => { inner.Path = copy.ToClone(n.Path); inner.Name = n.Path == copy.FormPath ? copy.CloneName : n.Name; inner.ParentPath = n.Path == copy.FormPath ? n.ParentPath : copy.ToClone(n.ParentPath); inner.IsRepeating = n.Path != itemPath && n.IsRepeating; inner.IsInRepeatingGroup = inList; });
            }).ToList();
            var mappings = project.Mappings
                .Where(m => m.SchemaPath.StartsWith(itemPath + "/", StringComparison.Ordinal))
                .Select(m => m.With(inner => { inner.SchemaPath = copy.ToClone(m.SchemaPath); inner.SheetName = copy.SheetName; inner.Source = "Sheet copy"; }))
                .ToList();
            return project.With(inner => { inner.SchemaNodes = cloneNodes; inner.Mappings = mappings; inner.SampleRows = new List<SampleRowDto>(); inner.SampleOmittedForms = new List<string>(); inner.SheetSplits = new List<SheetSplitDto>(); });
        }

        // ---------- one item of a form, bound under the XSD's own names ----------

        /// <summary>
        /// In the XML map's schema only (BSP's XSD is unchanged), the form's item occurs once, so Excel binds the item's own
        /// fields to cells and each list inside it to an XML table, and its export uses the XSD's own element names (one
        /// item, which the XSD allows). Returns false when the form or item is not an inline declaration under the root.
        /// </summary>
        public static bool SetSingleItem(XElement schema, string rootElement, string form, string itemName)
        {
            var root = schema.Elements(Xs + "element").FirstOrDefault(e => (string)e.Attribute("name") == rootElement);
            var formElement = (root == null) ? null : FormElement(root, form);
            if (formElement == null || formElement.Attribute("type") != null || formElement.Attribute("ref") != null)
            {
                return false;
            }

            var item = formElement.Descendants(Xs + "element").FirstOrDefault(e => (string)e.Attribute("name") == itemName
                && e.Ancestors(Xs + "element").FirstOrDefault() == formElement);
            if (item == null)
            {
                return false;
            }

            if (item.Attribute("maxOccurs") != null)
            {
                item.SetAttributeValue("maxOccurs", "1");
            }

            for (var particle = item.Parent; particle != null && particle != formElement; particle = particle.Parent)
            {
                if ((particle.Name == Xs + "sequence" || particle.Name == Xs + "choice") && particle.Attribute("maxOccurs") != null)
                {
                    particle.SetAttributeValue("maxOccurs", "1");
                }
            }

            return true;
        }

        /// <summary>
        /// The project as Excel's map sees a form whose item occurs once (see <see cref="SetSingleItem"/>): the item's own
        /// fields are single elements, the lists inside it are lists; the form's mappings on <paramref name="sheetName"/>.
        /// </summary>
        public static FrpProjectDto ForExcelItem(FrpProjectDto project, SheetSplitRules.FormLayout form, string sheetName)
        {
            var formPath = form.GroupPath.Substring(0, form.GroupPath.LastIndexOf('/'));
            var nodes = project.SchemaNodes
                .Where(n => n.Path == formPath || n.Path.StartsWith(formPath + "/", StringComparison.Ordinal))
                .ToList();
            var lists = nodes.Where(n => n.IsRepeating && n.Path != form.GroupPath).Select(n => n.Path).ToList();
            var itemNodes = nodes.Select(n => n.With(copy => { copy.IsRepeating = n.Path != form.GroupPath && n.IsRepeating; copy.IsInRepeatingGroup = lists.Any(r => n.Path == r || n.Path.StartsWith(r + "/", StringComparison.Ordinal)); })).ToList();
            var mappings = project.Mappings
                .Where(m => m.SchemaPath.StartsWith(form.GroupPath + "/", StringComparison.Ordinal))
                .Select(m => m.With(copy => { copy.SheetName = sheetName; copy.Source = "Excel item"; }))
                .ToList();
            return project.With(copy => { copy.SchemaNodes = itemNodes; copy.Mappings = mappings; copy.SampleRows = new List<SampleRowDto>(); copy.SampleOmittedForms = new List<string>(); copy.SheetSplits = new List<SheetSplitDto>(); });
        }

        /// <summary>A bound path of a clone as the XSD's path (…/CAR_Part_IV_4c_PHP/… to …/CAR_Part_IV_4c/…), or null.</summary>
        public static string ToForm(IReadOnlyList<Copy> copies, string path)
        {
            foreach (var copy in copies)
            {
                if (path.StartsWith(copy.ClonePath + "/", StringComparison.Ordinal))
                {
                    return copy.FormPath + path.Substring(copy.ClonePath.Length);
                }
            }

            return null;
        }

        // ---------- an XML exported by Excel ----------

        /// <summary>
        /// An XML exported by Excel from a template with sheet copies has one clone element per copy
        /// (CAR_Part_IV_4c_PHP, CAR_Part_IV_4c_USD…). This returns the XSD's structure: the copies' items in one form
        /// element (CAR_Part_IV_4c) in the XSD's position, without the copies that hold nothing but their key and without
        /// the empty optional elements Excel writes for blank cells. Null when the XML has no clone elements.
        /// </summary>
        public static VT_Xml_Note<byte[], string>? Normalize(FrpProjectDto project, byte[] xml)
        {
            var copies = Copies(project);
            if (copies.Count == 0)
            {
                return null;
            }

            XDocument document;
            try
            {
                using (var stream = new MemoryStream(xml))
                {
                document = SafeXml.Load(stream);
                }
            }
            catch (Exception ex) when ((ex is System.Xml.XmlException || ex is InvalidOperationException))
            {
                return null; // the XSD check reports it
            }

            var root = document.Root;
            if (root == null || root.Name.LocalName != project.RootElement)
            {
                return null;
            }

            var ns = root.Name.Namespace;
            var nodesByPath = project.SchemaNodes.GroupBy(n => n.Path, StringComparer.Ordinal).ToDictionary(g => g.Key, g => g.First(), StringComparer.Ordinal);
            var formOrder = project.SchemaNodes.Where(n => n.ParentPath == $"/{project.RootElement}").Select(n => n.Name).ToList();
            var moved = new Dictionary<string, VT_Items_Values<int, List<string>>>(StringComparer.Ordinal);
            var found = new List<string>();
            foreach (var byForm in copies.GroupBy(c => c.Form))
            {
                var items = new List<XElement>();
                var values = new List<string>();
                var keyName = byForm.First().Split.Key.SchemaPath.Split('/').Last();
                var itemName = byForm.First().ItemName;
                Func<XElement, bool> HasValues = null;
                HasValues = (XElement itemArg) =>
                {
                    return itemArg.Descendants().Any(e => !e.HasElements && e.Name.LocalName != keyName && e.Value.Trim().Length > 0);
                };
                var hadClones = false;
                foreach (var copy in byForm)
                {
                    foreach (var cloneElement in root.Elements(ns + copy.CloneName).ToList())
                    {
                        hadClones = true;
                        found.Add(copy.CloneName);
                        foreach (var item in cloneElement.Elements(ns + copy.ItemName))
                        {
                            if (HasValues(item))
                            {
                                items.Add(new XElement(item));
                                values.Add(copy.Value);
                            }
                        }

                        cloneElement.Remove();
                    }
                }

                if (!hadClones)
                {
                    continue;
                }

                // The first sheet is bound under the form's own name: its item stays only when it has values too.
                var form = root.Element(ns + byForm.Key);
                var firstItems = new List<string>();
                if (form != null)
                {
                    foreach (var item in form.Elements(ns + itemName).ToList())
                    {
                        if (HasValues(item))
                        {
                            firstItems.Add(item.Element(ns + keyName)?.Value.Trim() ?? "");
                        }
                        else
                        {
                            item.Remove();
                        }
                    }

                    if (firstItems.Count == 0 && !form.HasElements)
                    {
                        form.Remove();
                        form = null;
                    }
                }

                if (items.Count == 0)
                {
                    if (form != null)
                    {
                        moved[byForm.Key] = new VT_Items_Values<int, List<string>>(firstItems.Count, firstItems);
                    }

                    continue;
                }

                if (form == null)
                {
                    form = new XElement(ns + byForm.Key);
                    var index = formOrder.IndexOf(byForm.Key);
                    var after = root.Elements().FirstOrDefault(e => formOrder.IndexOf(e.Name.LocalName) > index);
                    if (after == null)
                    {
                        root.Add(form);
                    }
                    else
                    {
                        after.AddBeforeSelf(form);
                    }
                }

                form.Add(items);
                moved[byForm.Key] = new VT_Items_Values<int, List<string>>(firstItems.Count + items.Count, firstItems.Concat(values).ToList());
            }

            if (found.Count == 0)
            {
                return null;
            }

            // Blank cells: Excel may write empty elements. A list row left blank is not an item, and an empty optional
            // element is left out, as in the app's own XML (a blank required field stays, so the XSD check reports it).
            foreach (var formName in moved.Keys)
            {
                var form = root.Element(ns + formName);
                var formPath = $"/{project.RootElement}/{formName}";
                Func<XElement, string> PathOf = null;
                PathOf = (XElement elementArg) =>
                {
                    return formPath + "/" + string.Join("/", elementArg.AncestorsAndSelf().TakeWhile(e => e != form).Reverse().Select(e => e.Name.LocalName));
                };
                foreach (var item in form.Elements().ToList())
                {
                    foreach (var row in item.Descendants().Where(e => { SchemaNodeDto n; return nodesByPath.TryGetValue(PathOf(e), out n) && n.IsRepeating; }).ToList())
                    {
                        if (row.Parent != null && row.Descendants().All(e => e.HasElements || e.Value.Trim().Length == 0))
                        {
                            row.Remove();
                        }
                    }
                }

                foreach (var element in form.Descendants().Reverse().ToList())
                {
                    SchemaNodeDto node;
                    if (!element.HasElements && element.Value.Trim().Length == 0 && nodesByPath.TryGetValue(PathOf(element), out node) && !node.IsRequired)
                    {
                        element.Remove();
                    }
                }
            }

            using (var output = new MemoryStream())
            {
            using (var writer = System.Xml.XmlWriter.Create(output, new System.Xml.XmlWriterSettings { Encoding = new UTF8Encoding(false), Indent = true }))
            {
                document.Save(writer);
            }

            var note = "This XML was exported by Excel from sheet copies (" + string.Join(", ", found.Distinct().Take(4))
                + (found.Distinct().Count() > 4 ? ", …" : "") + "); the app merged them into the XSD's structure: "
                + string.Join("; ", moved.Select(m => $"{m.Key} with {m.Value.Items} item(s) ({string.Join(", ", m.Value.Values)})"))
                + (moved.Count == 0 ? "no copy had values" : "") + ". Sheets with only their key value were left out.";
            return new VT_Xml_Note<byte[], string>(output.ToArray(), note);
            }
        }

        private static System.Text.RegularExpressions.Regex NameChars() { return NameCharsInstance; }

        private static readonly System.Text.RegularExpressions.Regex NameCharsInstance = new System.Text.RegularExpressions.Regex(@"[^A-Za-z0-9_.\-]", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

}
