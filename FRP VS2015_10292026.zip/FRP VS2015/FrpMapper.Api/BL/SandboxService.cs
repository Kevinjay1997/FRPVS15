using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Contracts.Integration;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;
namespace FrpMapper.Api.BL
{
    /// <summary>
    /// BSP submission: sends a report to a BSP Report API environment (Sandbox, Production, … approved on the Settings tab)
    /// with the bank's own client certificate, checks its status and downloads BSP's results. A Production environment needs
    /// submission.production, and its submissions the environment's key typed as confirmation. The certificate is either the bank profile's stored one (uploaded once and
    /// approved on Bank profiles, kept encrypted) or a PFX uploaded with the request; either way it is opened for one
    /// request only, and the PFX and its password are never logged or sent to a page. The undertaking code comes from the chosen bank
    /// profile on the server (Maker / Checker approved), never from the page.
    /// </summary>
    public sealed class SandboxService : ISandboxService
    {
        internal const int MaxCertificateBytes = 2 * 1024 * 1024;
        private const int MaxXmlBytes = 20 * 1024 * 1024;
        private static readonly Regex UndertakingCode = new Regex(@"\A[0-9]{1,20}\z", RegexOptions.CultureInvariant);
        private static readonly Regex ReportCode = new Regex(@"\A[A-Za-z0-9_]{1,40}\z", RegexOptions.CultureInvariant);
        private static readonly Regex PeriodFormat = new Regex(@"\A[0-9]{4}-(?:[1-9]|0[1-9]|1[0-2])\z", RegexOptions.CultureInvariant);

        // A user key set first (IIS Express, an app pool with its user profile loaded), then the machine key set (an app
        // pool without a loaded profile, where a user key set cannot be created). Keys are never persisted or exportable.
        private static readonly X509KeyStorageFlags[] KeyStores = { X509KeyStorageFlags.UserKeySet, X509KeyStorageFlags.MachineKeySet };

        private readonly IBspSandboxClient client;
        private readonly IReferenceDataRepository references;
        private readonly IBankCertificateRepository certificates;
        private readonly CertificateProtector protector;
        private readonly ICurrentUser user;
        private readonly IAuditLog audit;
        private readonly ILogger<SandboxService> logger;
        private readonly ISubmissionEnvironmentRepository environments;
        private readonly BspOptions options;
        private readonly IValidationXmlSource xmlSource;
        private static readonly Regex Guid36 = new Regex(@"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}", RegexOptions.CultureInvariant);
        public SandboxService(IBspSandboxClient client, IReferenceDataRepository references, IBankCertificateRepository certificates, CertificateProtector protector,
            ICurrentUser user, IAuditLog audit, ILogger<SandboxService> logger, ISubmissionEnvironmentRepository environments, IOptions<BspOptions> options,
            IValidationXmlSource xmlSource)
        {
            this.client = client; this.references = references; this.certificates = certificates; this.protector = protector;
            this.user = user; this.audit = audit; this.logger = logger; this.environments = environments; this.options = options.Value;
            this.xmlSource = xmlSource;
        }
        private void Authorize()
        {
            if (!user.IsAuthenticated || !user.HasPermission(Permissions.SubmissionPrepare))
                throw new WorkflowException(WorkflowErrorKind.Forbidden, "Your role cannot use BSP submission.");
        }
        private static WorkflowException Invalid(string message) { return new WorkflowException(WorkflowErrorKind.Invalid, message); }

        private static bool IsPeriod(string value)
        {
            DateTime period;
            return PeriodFormat.IsMatch(value ?? "")
                && DateTime.TryParseExact(value, new[] { "yyyy-M", "yyyy-MM" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out period);
        }

        private bool CanUse(SubmissionEnvironmentDto environment)
        {
            return environment.Kind != SubmissionEnvironmentKind.Production || user.HasPermission(Permissions.SubmissionProduction);
        }

        /// <summary>The approved environment a request is for; a Production one only with submission.production.</summary>
        private async Task<SubmissionEnvironmentDto> EnvironmentAsync(string key, CancellationToken cancellation)
        {
            key = (key ?? "").Trim();
            if (key.Length == 0) throw Invalid("Choose the BSP environment (for example Sandbox).");
            var environment = await environments.GetActiveAsync(key, cancellation);
            if (environment == null)
                throw Invalid("The BSP environment " + key + " is not approved or was removed. Reload the page and choose another one.");
            if (!CanUse(environment))
                throw new WorkflowException(WorkflowErrorKind.Forbidden, "Your role cannot use the Production environment " + environment.Name
                    + ". It needs the permission submission.production.");
            return environment;
        }

        /// <summary>The approved environments, for the submission form.</summary>
        public async Task<IReadOnlyList<SandboxEnvironmentDto>> EnvironmentsAsync(CancellationToken cancellation)
        {
            Authorize();
            var list = await environments.ListAsync(cancellation);
            return list.Where(e => e.Status == SubmissionEnvironmentStatus.Active)
                .Where(e => BspEndpointRules.IsAllowedHost(new Uri(e.BaseUrl).Host, options.AllowedHosts))
                .OrderBy(e => e.SortOrder).ThenBy(e => e.Key, StringComparer.Ordinal)
                .Select(e => new SandboxEnvironmentDto { Key = e.Key, Name = e.Name, Kind = e.Kind,
                    SubmitUrl = e.BaseUrl + e.SubmitPath, StatusUrl = e.BaseUrl + e.StatusPath, CanUse = CanUse(e) })
                .ToList();
        }

        /// <summary>A property's value when it is JSON text ("…"); null when it is missing or another kind of value.</summary>
        private static string Text(Dictionary<string, object> json, string name)
        {
            object value;
            return json.TryGetValue(name, out value) ? value as string : null;
        }

        /// <summary>
        /// Checks only that an edited reportInfo is a JSON object, then returns it unchanged.
        /// BSP decides which properties and values are valid for the particular report.
        /// </summary>
        internal static string CheckReportInfo(string written, out string reportCode, out string period)
        {
            var text = written ?? "";
            object parsed;
            try { parsed = JsonSerializer.Parse(text); }
            catch (JsonException ex) { throw Invalid("reportInfo is not valid JSON: " + ex.Message); }
            var root = parsed as Dictionary<string, object>;
            if (root == null) throw Invalid("reportInfo must be a JSON object { … }.");

            reportCode = Text(root, "reportCode");
            period = Text(root, "period");
            return text;
        }
        internal static async Task<byte[]> ReadAsync(IFormFile file, string[] extensions, string kind, int maximum, CancellationToken cancellation)
        {
            if (file == null || file.Length == 0 || file.Length > maximum
                || !extensions.Any(e => string.Equals(Path.GetExtension(file.FileName ?? ""), e, StringComparison.OrdinalIgnoreCase)))
                throw Invalid("Choose a " + kind + " (" + string.Join(" or ", extensions) + ") of up to " + (maximum / 1024 / 1024) + " MB.");
            using (var stream = file.OpenReadStream())
            using (var memory = new MemoryStream())
            {
                var buffer = new byte[81920]; int count;
                while ((count = await stream.ReadAsync(buffer, 0, buffer.Length, cancellation)) > 0)
                {
                    if (memory.Length + count > maximum) throw Invalid("The uploaded " + kind + " is too large.");
                    memory.Write(buffer, 0, count);
                }
                return memory.ToArray();
            }
        }

        /// <summary>
        /// The certificate for this request: the chosen bank's stored (approved) certificate, or the PFX uploaded with the
        /// request. Either way it is opened for this request only and released afterwards.
        /// </summary>
        private async Task<X509Certificate2> CertificateAsync(SandboxRequest request, CancellationToken cancellation, Action<int> otherCertificates)
        {
            byte[] bytes;
            string password;
            if (request.UseStoredCertificate)
            {
                if (string.IsNullOrEmpty(request.BankKey)) throw Invalid("Choose the bank whose stored certificate to use.");
                var stored = await certificates.GetActiveAsync(request.BankKey, cancellation);
                if (stored == null)
                    throw Invalid("Bank " + request.BankKey + " has no approved certificate. Upload one for this request, or ask a bank profile Maker to add it on Bank profiles.");
                bytes = protector.Unprotect(stored.Protected, stored.CertificateId, stored.BankKey, out password);
            }
            else
            {
                if (request.Certificate == null) throw Invalid("Choose the bank's PFX certificate first.");
                bytes = await ReadAsync(request.Certificate, new[] { ".pfx", ".p12" }, "PFX certificate", MaxCertificateBytes, cancellation);
                password = request.Password;
            }
            try
            {
                int others;
                var certificate = OpenOrThrow(bytes, password, out others);
                otherCertificates(others);
                return certificate;
            }
            finally { Array.Clear(bytes, 0, bytes.Length); }
        }

        /// <summary>
        /// Opens a PFX as banks export them: with or without a password, with or without the issuer chain. The one
        /// certificate holding a private key is returned; every other certificate is disposed.
        /// </summary>
        internal static X509Certificate2 OpenOrThrow(byte[] bytes, string password, out int others)
        {
            others = 0;
            if (bytes == null) throw Invalid("Choose the bank's PFX certificate first.");
            var collection = Import(bytes, password);
            if (collection == null)
                throw Invalid("Cannot open this PFX. Check the password, and that the file is the bank's PFX (PKCS #12) certificate exported with its private key."
                    + " A PFX exported with AES-256 encryption cannot be opened on older Windows servers: export it again with TripleDES-SHA1 encryption.");
            X509Certificate2 chosen = null;
            try
            {
                var now = DateTime.UtcNow;
                Func<X509Certificate2, bool> current = c => now >= c.NotBefore.ToUniversalTime() && now <= c.NotAfter.ToUniversalTime();
                var withKey = collection.Cast<X509Certificate2>().Where(c => c.HasPrivateKey).ToList();
                if (withKey.Count == 0)
                    throw Invalid("This PFX has no private key. Export the bank's certificate again with its private key.");
                var candidates = withKey.Count == 1 ? withKey : withKey.Where(current).ToList();
                if (candidates.Count != 1)
                    throw Invalid("This PFX holds " + withKey.Count + " certificates with private keys. Export only the bank's certificate issued for BSP.");
                if (!current(candidates[0]))
                    throw Invalid("The certificate is expired or not yet valid (valid " + candidates[0].NotBefore.ToUniversalTime().ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)
                        + " to " + candidates[0].NotAfter.ToUniversalTime().ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) + " UTC). Choose a current PFX.");
                chosen = candidates[0];
                others = collection.Count - 1;
                return chosen;
            }
            finally
            {
                foreach (X509Certificate2 certificate in collection)
                    if (!ReferenceEquals(certificate, chosen)) certificate.Reset();
            }
        }

        /// <summary>The PFX's certificates, or null when it cannot be opened with this password in any key store.</summary>
        private static X509Certificate2Collection Import(byte[] bytes, string password)
        {
            // A PFX exported without a password may have been protected with an empty password or with none at all.
            var passwords = string.IsNullOrEmpty(password) ? new[] { "", null } : new[] { password };
            foreach (var store in KeyStores)
                foreach (var attempt in passwords)
                {
                    var collection = new X509Certificate2Collection();
                    try
                    {
                        collection.Import(bytes, attempt, store);
                        if (collection.Count > 0) return collection;
                    }
                    catch (CryptographicException) { }
                    foreach (X509Certificate2 certificate in collection) certificate.Reset();
                }
            return null;
        }

        /// <summary>
        /// Releases a certificate opened from a PFX, and its temporary private key, when the request is done.
        /// .NET Framework 4.5.2's X509Certificate2 is not IDisposable (4.6 added it); Reset() releases the same resources.
        /// </summary>
        private sealed class CertificateLease : IDisposable
        {
            public CertificateLease(X509Certificate2 certificate) { Certificate = certificate; }

            public X509Certificate2 Certificate { get; private set; }

            public void Dispose() { if (Certificate != null) Certificate.Reset(); }
        }

        private static SandboxCertificateInfo Describe(X509Certificate2 cert, int others)
        {
            return new SandboxCertificateInfo { Name = cert.GetNameInfo(X509NameType.SimpleName, false), Subject = cert.Subject, Issuer = cert.Issuer,
                Thumbprint = cert.Thumbprint, ValidFrom = cert.NotBefore.ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture),
                ValidUntil = cert.NotAfter.ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture), OtherCertificates = others };
        }

        private static SandboxBankDto ToBank(BankProfileDto bank)
        {
            return new SandboxBankDto { Key = bank.Key, Name = bank.Name, ProviderCode = bank.ProviderCode, UndertakingCode = bank.BspUndertakingCode };
        }

        public async Task<IReadOnlyList<SandboxBankDto>> BanksAsync(CancellationToken cancellation)
        {
            Authorize();
            var data = await references.ReadAsync(cancellation);
            var active = (await certificates.ListAsync(cancellation)).Where(c => c.Status == BankCertificateStatus.Active).ToList();
            return data.Banks.OrderBy(b => b.Key, StringComparer.Ordinal).Select(b =>
            {
                var bank = ToBank(b);
                var stored = active.FirstOrDefault(c => c.BankKey == b.Key);
                if (stored != null)
                    bank.StoredCertificate = new SandboxStoredCertificateDto { Subject = stored.Subject, Thumbprint = stored.Thumbprint,
                        ValidUntil = stored.ValidUntil.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture) };
                return bank;
            }).ToList();
        }

        public async Task<SandboxCertificateInfo> InspectAsync(SandboxRequest request, CancellationToken cancellation)
        {
            Authorize();
            var others = 0;
            using (var lease = new CertificateLease(await CertificateAsync(request, cancellation, count => others = count)))
                return Describe(lease.Certificate, others);
        }

        public async Task<SandboxResponse> ExecuteAsync(SandboxRequest request, CancellationToken cancellation)
        {
            Authorize();
            if (!BspEndpointRules.Operations.Contains(request.Operation ?? "")) throw Invalid("Unknown BSP operation.");
            // suffix: null for a submission, otherwise the follow-up operation.
            var suffix = request.Operation == "submit" ? null : request.Operation;
            Guid id;
            string submissionId = null;
            if (suffix != null)
            {
                if (!Guid.TryParseExact((request.SubmissionId ?? "").Trim(), "D", out id)) throw Invalid("Enter the submission ID returned by BSP (a GUID such as 7735089b-81d6-405e-8e67-255338dbce9a).");
                submissionId = id.ToString("D");
            }

            var environment = await EnvironmentAsync(request.Environment, cancellation);
            var production = environment.Kind == SubmissionEnvironmentKind.Production;
            if (production && suffix == null && !string.Equals((request.ConfirmEnvironment ?? "").Trim(), environment.Key, StringComparison.Ordinal))
                throw Invalid("This is a real submission to " + environment.Name + ". Type " + environment.Key + " to confirm it.");
            var url = BspEndpointRules.Url(environment, request.Operation, submissionId, options.AllowedHosts);
            var where = "Environment " + environment.Key + " (" + environment.Kind + "), " + url.AbsoluteUri + ". ";
            var actionPrefix = production ? "production." : "sandbox.";

            // Everything about the report is checked before the certificate is opened and before anything is sent.
            BankProfileDto bank = null;
            byte[] xml = null;
            string filename = null, undertaking = null, reportCode = null, period = null, reportInfoText = null;
            // An edited reportInfo replaces the generated one; any report code and period in it are for audit display only.
            var reportInfoEdited = suffix == null && request.ReportInfo != null;
            if (suffix == null)
            {
                if (!reportInfoEdited)
                {
                    reportCode = request.ReportCode; period = request.Period;
                    if (!ReportCode.IsMatch(reportCode ?? "")) throw Invalid("Enter the BSP report code (letters, digits or underscores), e.g. the code BSP gave for this report.");
                    if (!IsPeriod(period)) throw Invalid("Enter the reporting period as YYYY-M or YYYY-MM.");
                }
                var data = await references.ReadAsync(cancellation);
                bank = data.Banks.SingleOrDefault(b => b.Key == request.BankKey);
                if (bank == null) throw Invalid("Choose the bank profile (for example UNI or RB) the report is for.");
                undertaking = bank.BspUndertakingCode;
                if (string.IsNullOrEmpty(undertaking) || !UndertakingCode.IsMatch(undertaking))
                    throw Invalid("Bank profile " + bank.Key + " has no BSP API undertaking code yet. A bank profile Maker adds it on Bank profiles and a Checker approves it.");
                xml = await ReadAsync(request.Xml, new[] { ".xml" }, "report XML", MaxXmlBytes, cancellation);
                filename = Path.GetFileName(request.Xml.FileName);
                if (!Regex.IsMatch(filename, @"\A[A-Za-z0-9_. -]{1,180}\.xml\z", RegexOptions.IgnoreCase)) throw Invalid("Use a simple XML filename containing letters, numbers, spaces, dots, underscores or hyphens.");
                XDocument document;
                using (var stream = new MemoryStream(xml)) document = SafeXml.Load(stream);
                var header = BankReferenceContext.Header(document.Root, "Undertaking").Trim();
                if (header.Length > 0 && BankReferenceContext.Code(header) != BankReferenceContext.Code(bank.ProviderCode))
                    throw Invalid("This XML's Header/Undertaking is " + header + ", but bank profile " + bank.Key + " has provider code " + bank.ProviderCode
                        + ". Choose the bank profile, and that bank's certificate, that match the report.");
                if (reportInfoEdited)
                    reportInfoText = CheckReportInfo(request.ReportInfo, out reportCode, out period);
                else
                    // BSP finds the main report by its file name: mainFile.filename must equal the uploaded part's filename.
                    // ("@file" in the Xml Report Manager is a placeholder that tool replaces with the chosen file's name.)
                    reportInfoText = JsonSerializer.Serialize(new { reportCode = reportCode, undertakingCode = undertaking, period = period, mainFile = new { filename = filename } },
                        new JsonSerializerOptions(JsonSerializerDefaults.Web));
            }

            using (var lease = new CertificateLease(await CertificateAsync(request, cancellation, count => { })))
            // An unquoted boundary and plain part headers, as Postman and the Xml Report Manager send them.
            using (var form = new MultipartFormDataContent("FrpMapper" + Guid.NewGuid().ToString("N")))
            {
                var cert = lease.Certificate;
                string details;
                if (suffix == null)
                {
                    // A plain text field, as Postman and the Xml Report Manager send it (no part content type). An edited
                    // reportInfo was checked above and is sent exactly as written.
                    var reportInfo = new ByteArrayContent(Encoding.UTF8.GetBytes(reportInfoText));
                    reportInfo.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data") { Name = "\"reportInfo\"" };
                    form.Add(reportInfo);
                    // The filename was checked above: letters, digits, spaces, dots, underscores and hyphens only.
                    var file = new ByteArrayContent(xml);
                    file.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data") { Name = "\"file\"", FileName = "\"" + filename + "\"" };
                    file.Headers.ContentType = new MediaTypeHeaderValue("application/xml");
                    form.Add(file);
                    string sha256;
                    using (var hash = SHA256.Create()) sha256 = string.Concat(hash.ComputeHash(xml).Select(b => b.ToString("x2", CultureInfo.InvariantCulture)));
                    details = where + "Bank " + bank.Key + " (provider code " + bank.ProviderCode + ", undertaking code " + undertaking + "); report code " + (reportCode ?? "(not supplied)")
                        + ", period " + (period ?? "(not supplied)") + "; file " + filename + " (" + xml.Length + " bytes, SHA-256 " + sha256 + "); certificate " + cert.Thumbprint
                        + (request.UseStoredCertificate ? " (stored for bank " + request.BankKey + ")" : " (uploaded with the request)") + "."
                        + (reportInfoEdited ? " reportInfo edited on the page, sent as: " + reportInfoText : "")
                        + (request.Origin != null ? " " + request.Origin : "");
                }
                else details = where + "Submission " + submissionId + "; certificate " + cert.Thumbprint
                    + (request.UseStoredCertificate ? " (stored for bank " + request.BankKey + ")" : " (uploaded with the request)") + ".";

                // Recorded before anything is sent. Never the certificate's bytes, its password or the report's content.
                await audit.AppendAsync(new AuditEntryDto { Id = Guid.NewGuid().ToString("N"), At = DateTimeOffset.UtcNow, User = user.Name,
                    Action = actionPrefix + request.Operation, Details = "BSP request sent. " + details }, cancellation);
                SandboxResponse result;
                var download = suffix != null && suffix != "status";
                try { result = await client.SendAsync(cert, url, suffix == null ? form : null, download, cancellation); }
                catch (HttpRequestException ex)
                {
                    // The full technical reason (inner exceptions: DNS, socket, TLS) goes to the API log; never the certificate or the report.
                    logger.LogWarning(ex, "BSP {Operation} by {User} failed: {Reason} {Details}", request.Operation, user.Name, ex.Message, details);
                    await Outcome(actionPrefix + request.Operation, "BSP could not be reached, or the certificate was refused: " + ex.Message + " " + details);
                    throw Invalid("BSP could not be reached or certificate authentication failed: " + ex.Message
                        + (suffix == null ? " The submission's outcome is unknown: check its status with BSP before sending it again." : ""));
                }
                catch (OperationCanceledException)
                {
                    await Outcome(actionPrefix + request.Operation, "The request was interrupted or timed out. " + details);
                    throw Invalid("The BSP request was interrupted or timed out." + (suffix == null ? " BSP may already have received the report: check its status before sending it again." : ""));
                }
                await Outcome(actionPrefix + request.Operation, "BSP answered HTTP " + result.StatusCode + (result.FileBytes != null ? " with a " + result.FileBytes.Length + "-byte file" : "") + ". " + details);
                if (result.FileBytes != null)
                {
                    var extension = request.Operation == "excel" ? "xlsx" : request.Operation == "xml" ? "xml" : "pdf";
                    result.FileName = "BSP-" + environment.Key.ToLowerInvariant() + "-" + submissionId + "-" + request.Operation + "." + extension;
                    result.ContentType = extension == "xlsx" ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : extension == "xml" ? "application/xml" : "application/pdf";
                }
                return result;
            }
        }

        /// <summary>
        /// Validate page: the XML it checked (built on the server, or the uploaded file) is submitted to a BSP test
        /// environment with the bank's certificate, so BSP's own validation can be shown with the app's. The report code,
        /// period and bank come from the XML's Header when they are not given; Production is refused here.
        /// </summary>
        public async Task<SandboxValidationDto> ValidateAsync(SandboxRequest request, CancellationToken cancellation)
        {
            Authorize();
            if (!user.HasPermission(Permissions.ProjectRead))
                throw new WorkflowException(WorkflowErrorKind.Forbidden, "Your role cannot validate projects.");
            var environment = await EnvironmentAsync(request.Environment, cancellation);
            if (environment.Kind != SubmissionEnvironmentKind.Test)
                throw Invalid(environment.Name + " is a Production environment. Validate sends only to BSP test environments; real submissions are made on BSP submission.");
            var built = await BuildAsync(request, cancellation);
            var bytes = built.Value.Bytes;
            var name = built.Value.FileName;
            var read = BspXmlParameters.Read(Load(bytes).Root, (await references.ReadAsync(cancellation)).Banks);
            var reportCode = (request.ReportCode ?? "").Trim();
            if (reportCode.Length == 0) reportCode = read.ReportCode;
            var period = (request.Period ?? "").Trim();
            if (period.Length == 0) period = read.Period;
            var bankKey = (request.BankKey ?? "").Trim();
            if (bankKey.Length == 0)
            {
                if (read.BankKey == null)
                    throw Invalid("Choose the bank profile the report is for" + (read.Undertaking.Length > 0 ? " (no single bank profile has provider code " + read.Undertaking + ")." : "."));
                bankKey = read.BankKey;
            }

            var useStored = request.Certificate == null
                && (await certificates.ListAsync(cancellation)).Any(c => c.BankKey == bankKey && c.Status == BankCertificateStatus.Active);
            if (request.Certificate == null && !useStored)
                throw Invalid("Bank " + bankKey + " has no approved certificate. Upload its PFX here, or ask a bank profile Maker to store one on Bank profiles.");
            var submit = new SandboxRequest
            {
                Operation = "submit", Environment = environment.Key, BankKey = bankKey, ReportCode = reportCode, Period = period,
                Xml = new MemoryFormFile("file", name, bytes, "application/xml"), UseStoredCertificate = useStored,
                Certificate = useStored ? null : request.Certificate, Password = useStored ? null : request.Password,
                Origin = "Sent from the Validate page: project " + request.ProjectId + ", " + (request.Source == "generated" ? "the XML built from the project's values"
                    : request.Source == "workbook" ? "the XML built from the filled template " + Path.GetFileName(request.Workbook.FileName) : "the uploaded XML") + "."
            };
            var result = await ExecuteAsync(submit, cancellation);
            var id = Guid36.Match(result.Body ?? "");
            var success = result.StatusCode >= 200 && result.StatusCode < 300;
            return new SandboxValidationDto
            {
                Environment = environment.Key, EnvironmentName = environment.Name, BankKey = bankKey, FileName = name, ReportCode = reportCode, Period = period,
                StatusCode = result.StatusCode, Body = Limit(result.Body), SubmissionId = success && id.Success ? id.Value.ToLowerInvariant() : null
            };
        }

        /// <summary>The XML the Validate page checked, built on the server, with a file name BSP accepts.</summary>
        private async Task<VT_FileName_Bytes<string, byte[]>?> BuildAsync(SandboxRequest request, CancellationToken cancellation)
        {
            var source = request.Source == "workbook" ? request.Workbook : request.Xml;
            var built = await xmlSource.XmlForSandboxAsync(request.ProjectId, request.Source, source, cancellation);
            if (built == null) throw Invalid("The project was not found, or you cannot see it.");
            var name = Regex.Replace(Path.GetFileNameWithoutExtension(built.Value.FileName ?? "report"), @"[^A-Za-z0-9_. -]", "_");
            name = (name.Length == 0 ? "report" : name.Length > 120 ? name.Substring(0, 120) : name) + ".xml";
            return new VT_FileName_Bytes<string, byte[]>(name, built.Value.Bytes);
        }

        private static XDocument Load(byte[] bytes)
        {
            using (var stream = new MemoryStream(bytes)) return SafeXml.Load(stream);
        }

        /// <summary>
        /// Validate page: the parameters the XML gives (report code, period, bank) before anything is sent, so the panel
        /// shows them filled in. Nothing is sent to BSP and nothing is recorded.
        /// </summary>
        public async Task<SandboxParametersDto> ParametersAsync(SandboxRequest request, CancellationToken cancellation)
        {
            Authorize();
            if (!user.HasPermission(Permissions.ProjectRead))
                throw new WorkflowException(WorkflowErrorKind.Forbidden, "Your role cannot validate projects.");
            var built = await BuildAsync(request, cancellation);
            var read = BspXmlParameters.Read(Load(built.Value.Bytes).Root, (await references.ReadAsync(cancellation)).Banks);
            read.FileName = built.Value.FileName;
            if (read.BankKey != null)
                read.HasStoredCertificate = (await certificates.ListAsync(cancellation)).Any(c => c.BankKey == read.BankKey && c.Status == BankCertificateStatus.Active);
            return read;
        }

        public async Task<SandboxFindingsDto> FindingsAsync(SandboxRequest request, CancellationToken cancellation)
        {
            Authorize();
            request.Operation = "xml";
            var result = await ExecuteAsync(request, cancellation);
            var findings = new SandboxFindingsDto { StatusCode = result.StatusCode, SubmissionId = (request.SubmissionId ?? "").Trim().ToLowerInvariant() };
            if (result.FileBytes == null)
            {
                findings.Body = Limit(result.Body);
                return findings;
            }

            var read = BspResultReader.Read(result.FileBytes);
            findings.Ready = true;
            findings.Format = read.Format;
            findings.Findings = read.Findings;
            return findings;
        }

        private static string Limit(string text)
        {
            text = text ?? "";
            return text.Length <= 4000 ? text : text.Substring(0, 4000) + "…";
        }

        /// <summary>
        /// Records what BSP answered. The request has already reached (or tried to reach) BSP, so a failure to record
        /// is logged rather than hiding BSP's answer (for a submission, the ID needed to follow it up).
        /// </summary>
        private async Task Outcome(string action, string details)
        {
            try
            {
                await audit.AppendAsync(new AuditEntryDto { Id = Guid.NewGuid().ToString("N"), At = DateTimeOffset.UtcNow, User = user.Name,
                    Action = action + ".result", Details = details }, CancellationToken.None);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "The outcome of BSP {Action} by {User} could not be added to the audit trail: {Details}", action, user.Name, details);
            }
        }
    }
}
