﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    public sealed class XsdSchemaParser
    {
        private static readonly XNamespace Xs = "http://www.w3.org/2001/XMLSchema";

        public VT_TargetNamespace_RootElement_Nodes<string, string, IReadOnlyList<SchemaNodeDto>> Parse(string path)
        {
            var document = SafeXml.Load(path, LoadOptions.PreserveWhitespace | LoadOptions.SetLineInfo);
            var schema = document.Root ?? CompatThrow.As<XElement>(new InvalidOperationException("The XSD file does not contain a schema root."));
            var targetNamespace = (string)schema.Attribute("targetNamespace");
            var simpleTypeElements = schema.Elements(Xs + "simpleType")
                .Where(e => e.Attribute("name") != null)
                .ToDictionary(e => (string)e.Attribute("name"), e => e);
            var simpleTypes = new Dictionary<string, SchemaTypeInfo>();
            var resolving = new HashSet<string>();
            Func<string, SchemaTypeInfo> ResolveNamed = null;
            ResolveNamed = (string nameArg) =>
            {
                SchemaTypeInfo cached;
                if (simpleTypes.TryGetValue(nameArg, out cached))
                    return cached;
                XElement element;
                if (!simpleTypeElements.TryGetValue(nameArg, out element))
                    return BuiltInType(nameArg);
                if (!resolving.Add(nameArg))
                    throw new InvalidDataException($"Circular XSD simple type: {nameArg}");
                var restriction = element.Element(Xs + "restriction");
                var parent = ResolveNamed(StripPrefix((string)restriction?.Attribute("base")) ?? "string");
                var result = FromRestriction(restriction, parent);
                resolving.Remove(nameArg);
                simpleTypes[nameArg] = result;
                return result;
            };
            foreach (var name in simpleTypeElements.Keys) ResolveNamed(name);
            var globalComplexTypes = schema.Elements(Xs + "complexType")
                .Where(e => e.Attribute("name") != null)
                .ToDictionary(e => (string)e.Attribute("name"), e => e);
            var globalElements = schema.Elements(Xs + "element")
                .Where(e => e.Attribute("name") != null)
                .GroupBy(e => (string)e.Attribute("name"))
                .ToDictionary(g => g.Key, g => g.First());

            var nodes = new List<SchemaNodeDto>();
            var usedAmounts = new HashSet<decimal>();
            var rootElement = schema.Elements(Xs + "element").FirstOrDefault(e => e.Attribute("name") != null);
            if (rootElement == null)
            {
                return new VT_TargetNamespace_RootElement_Nodes<string, string, IReadOnlyList<SchemaNodeDto>>(targetNamespace, null, nodes);
            }
            Action<XElement, string, string, int, ChildContext, bool> WalkElement = null;
            WalkElement = (XElement elementArg, string parentPath, string parentNodePath, int depth, ChildContext context, bool parentInRepeatingGroup) =>
            {
                if (depth > 40)
                {
                    return; // Guard against recursive type definitions.
                }
        
                var referenced = StripPrefix((string)elementArg.Attribute("ref"));
                XElement referencedElement;
                if (referenced != null && globalElements.TryGetValue(referenced, out referencedElement))
                {
                    // Occurrence constraints stay on the referencing element; the definition comes from the global element.
                    var merged = new XElement(referencedElement);
                    merged.SetAttributeValue("minOccurs", (string)elementArg.Attribute("minOccurs"));
                    merged.SetAttributeValue("maxOccurs", (string)elementArg.Attribute("maxOccurs"));
                    elementArg = merged;
                }
        
                var name = (string)elementArg.Attribute("name") ?? referenced ?? "Element";
                var path2 = string.IsNullOrWhiteSpace(parentPath) ? $"/{name}" : $"{parentPath}/{name}";
                var typeName = StripPrefix((string)elementArg.Attribute("type"));
                var minOccurs = (string)elementArg.Attribute("minOccurs");
                var maxOccurs = (string)elementArg.Attribute("maxOccurs");
                var childComplexType = elementArg.Element(Xs + "complexType");
                XElement globalType;
                if (childComplexType == null && typeName != null && globalComplexTypes.TryGetValue(typeName, out globalType))
                {
                    childComplexType = globalType;
                }
        
                var typeInfo = (childComplexType == null) ? ResolveTypeInfo(typeName, elementArg, simpleTypes) : SchemaTypeInfo.Complex;
                typeInfo = typeInfo.With(copy =>
                {
                    copy.Validation = typeInfo.Validation.With(inner =>
                    {
                        inner.FixedValue = (string)elementArg.Attribute("fixed");
                    });
                });
                int max;
                var isRepeating = context.Repeats || maxOccurs == "unbounded" || int.TryParse(maxOccurs, out max) && max > 1 || IsBspRepeatingItem(name, parentPath);
                var inRepeatingGroup = parentInRepeatingGroup || isRepeating;
                nodes.Add(new SchemaNodeDto { Path = path2, Name = name, DataType = typeInfo.DataType, Validation = typeInfo.Validation, TestValue = XsdTestValueGenerator.Generate(name, typeInfo.DataType, typeInfo.Validation, sampleKey: path2, usedAmounts: usedAmounts), IsRequired = (minOccurs == null || !(minOccurs == "0")) && !context.Optional, IsRepeating = isRepeating, IsInRepeatingGroup = inRepeatingGroup, ParentPath = parentNodePath, Depth = depth });
                if (childComplexType != null)
                {
                    foreach (var entry in GetChildren(childComplexType))
                    {
                        var child = entry.Element;
                        var childContext = entry.Context;
                        WalkElement(child, path2, path2, depth + 1, childContext, inRepeatingGroup);
                    }
                }
            };

            WalkElement(rootElement,"",null,0,new ChildContext(false, false),false);
            return new VT_TargetNamespace_RootElement_Nodes<string, string, IReadOnlyList<SchemaNodeDto>>(targetNamespace, (string)rootElement.Attribute("name"), nodes);
        }

        private static IEnumerable<VT_Element_Context<XElement, ChildContext>> GetChildren(XElement complexType)
        {
            var container = complexType.Element(Xs + "complexContent")?.Elements().FirstOrDefault() ?? complexType;
            foreach (var compositor in container.Elements().Where(IsCompositor))
            {
                foreach (var child in WalkCompositor(compositor, new ChildContext(false, false)))
                {
                    yield return child;
                }
            }
        }

        private static IEnumerable<VT_Element_Context<XElement, ChildContext>> WalkCompositor(XElement compositor, ChildContext inherited)
        {
            var maxOccurs = (string)compositor.Attribute("maxOccurs");
            int max;
            var context = new ChildContext(
                inherited.Repeats || maxOccurs == "unbounded" || int.TryParse(maxOccurs, out max) && max > 1,
                inherited.Optional || (string)compositor.Attribute("minOccurs") == "0" || compositor.Name == Xs + "choice");

            foreach (var item in compositor.Elements())
            {
                if (item.Name == Xs + "element")
                {
                    yield return new VT_Element_Context<XElement, ChildContext>(item, context);
                }
                else if (IsCompositor(item))
                {
                    foreach (var nested in WalkCompositor(item, context))
                    {
                        yield return nested;
                    }
                }
            }
        }

        private static bool IsCompositor(XElement element)
        {
            return element.Name == Xs + "sequence" || element.Name == Xs + "all" || element.Name == Xs + "choice";
        }

        /// <summary>Occurrence rules inherited from the xs:sequence / xs:choice / xs:all that contains an element.</summary>
        private struct ChildContext : IEquatable<ChildContext>
    {
        public bool Repeats { get; set; }

        public bool Optional { get; set; }

        public ChildContext(bool Repeats, bool Optional)
    {
    this.Repeats = Repeats;
    this.Optional = Optional;
    }

        public void Deconstruct(out bool Repeats, out bool Optional)
    {
    Repeats = this.Repeats;
    Optional = this.Optional;
    }

        public bool Equals(ChildContext other)
    {
    return EqualityComparer<bool>.Default.Equals(Repeats, other.Repeats) && EqualityComparer<bool>.Default.Equals(Optional, other.Optional);
    }

        public override bool Equals(object obj)
    {
    return obj is ChildContext && Equals((ChildContext)obj);
    }

        public static bool operator ==(ChildContext left, ChildContext right)
    {
    return left.Equals(right);
    }

        public static bool operator !=(ChildContext left, ChildContext right)
    {
    return !left.Equals(right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 66788;
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Repeats);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Optional);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ChildContext { " + "Repeats = " + Repeats + ", " + "Optional = " + Optional + " }";
    }

    }

        private static SchemaTypeInfo ResolveTypeInfo(string typeName, XElement element, IReadOnlyDictionary<string, SchemaTypeInfo> simpleTypes)
        {
            if (typeName == null)
            {
                var restriction = element.Descendants(Xs + "restriction").FirstOrDefault();
                var baseName = StripPrefix((string)restriction?.Attribute("base")) ?? "string";
                return FromRestriction(restriction, simpleTypes.GetValueOrDefault(baseName) ?? BuiltInType(baseName));
            }

            SchemaTypeInfo simpleType;
            return simpleTypes.TryGetValue(typeName, out simpleType) ? simpleType : BuiltInType(typeName);
        }

        private static SchemaTypeInfo FromRestriction(XElement restriction, SchemaTypeInfo parent)
        {
            if (restriction == null)
            {
                return parent;
            }

            var patterns = restriction.Elements(Xs + "pattern").Select(e => (string)e.Attribute("value")).OfType<string>().ToList();
            var enumerations = restriction.Elements(Xs + "enumeration").Select(e => (string)e.Attribute("value")).OfType<string>().ToList();
            Func<string, string> Facet = null;
            Facet = (string name) =>
            {
                return (string)restriction.Element(Xs + name)?.Attribute("value");
            };
            var inherited = parent.Validation;
            var validation = inherited.With(copy => { copy.Enumerations = enumerations.Count > 0 ? enumerations : inherited.Enumerations; copy.Pattern = patterns.FirstOrDefault() ?? inherited.Pattern; copy.PatternGroups = patterns.Count > 0 ? inherited.PatternGroups.Append((IReadOnlyList<string>)patterns).ToList() : inherited.PatternGroups; copy.WhiteSpace = Facet("whiteSpace") ?? inherited.WhiteSpace; copy.Length = ParseInt(Facet("length")) ?? inherited.Length; copy.MinInclusive = Facet("minInclusive") ?? inherited.MinInclusive; copy.MaxInclusive = Facet("maxInclusive") ?? inherited.MaxInclusive; copy.MinExclusive = Facet("minExclusive") ?? inherited.MinExclusive; copy.MaxExclusive = Facet("maxExclusive") ?? inherited.MaxExclusive; copy.TotalDigits = ParseInt(Facet("totalDigits")) ?? inherited.TotalDigits; copy.FractionDigits = ParseInt(Facet("fractionDigits")) ?? inherited.FractionDigits; copy.MinLength = ParseInt(Facet("minLength")) ?? inherited.MinLength; copy.MaxLength = ParseInt(Facet("maxLength")) ?? inherited.MaxLength; });

            return new SchemaTypeInfo(parent.DataType, validation);
        }

        private static SchemaTypeInfo BuiltInType(string name)
        {
            var type = NormalizeType(name);
            var bounds = name == "positiveInteger" ? new VT_Item1_Item2<string, string>("1", (string)null) : name == "nonNegativeInteger" ? ((VT_Item1_Item2<string, string>)new VT_Item1_Item2<string, string>("0", null)) : name == "negativeInteger" ? ((VT_Item1_Item2<string, string>)new VT_Item1_Item2<string, string>(null, "-1")) : name == "nonPositiveInteger" ? ((VT_Item1_Item2<string, string>)new VT_Item1_Item2<string, string>(null, "0")) : name == "byte" ? new VT_Item1_Item2<string, string>("-128", "127") : name == "unsignedByte" ? new VT_Item1_Item2<string, string>("0", "255") : name == "short" ? new VT_Item1_Item2<string, string>("-32768", "32767") : name == "unsignedShort" ? new VT_Item1_Item2<string, string>("0", "65535") : name == "int" ? new VT_Item1_Item2<string, string>("-2147483648", "2147483647") : name == "unsignedInt" ? new VT_Item1_Item2<string, string>("0", "4294967295") : name == "long" ? new VT_Item1_Item2<string, string>("-9223372036854775808", "9223372036854775807") : name == "unsignedLong" ? new VT_Item1_Item2<string, string>("0", "18446744073709551615") : new VT_Item1_Item2<string, string>((string)null, (string)null);
            return new SchemaTypeInfo(type, new SchemaValidationDto { MinInclusive = bounds.Item1, MaxInclusive = bounds.Item2,
                WhiteSpace = name == "string" ? "preserve" : name == "normalizedString" ? "replace" : "collapse" });
        }

        private static string NormalizeType(string typeName)
        {
            return CompatFn.Let<string, string>(typeName.ToLowerInvariant(), text => text == "date" ? "date" : text == "datetime" ? "dateTime" : text == "decimal" ? "decimal" : (text == "integer" || text == "int" || text == "long" || text == "short" || text == "byte" || text == "unsignedbyte" || text == "unsignedshort" || text == "unsignedint" || text == "unsignedlong" || text == "positiveinteger" || text == "nonnegativeinteger" || text == "negativeinteger" || text == "nonpositiveinteger") ? "integer" : text == "boolean" ? "boolean" : "string");
        }

        private static string StripPrefix(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            var index = value.IndexOf(':', StringComparison.Ordinal);
            return index >= 0 ? value.Substring(index + 1) : value;
        }

        private static int? ParseInt(string value)
        {
            int parsed;
            return int.TryParse(value, out parsed) ? (int?)parsed : (int?)null;
        }

        private static bool IsBspRepeatingItem(string name, string parentPath)
        {
            if (!name.EndsWith("_Item", StringComparison.OrdinalIgnoreCase))
            {
                return false;
            }

            var parentName = parentPath.Split('/', StringSplitOptions.RemoveEmptyEntries).LastOrDefault();
            return !string.IsNullOrWhiteSpace(parentName)
                && string.Equals(name.Substring(0, name.Length - 5), parentName, StringComparison.OrdinalIgnoreCase);
        }

        private sealed class SchemaTypeInfo : IRecord<SchemaTypeInfo>, IEquatable<SchemaTypeInfo>
    {
        public string DataType { get; set; }

        public SchemaValidationDto Validation { get; set; }

        public SchemaTypeInfo(string DataType, SchemaValidationDto Validation)
    {
    this.DataType = DataType;
    this.Validation = Validation;
    }

        public void Deconstruct(out string DataType, out SchemaValidationDto Validation)
    {
    DataType = this.DataType;
    Validation = this.Validation;
    }

            public static SchemaTypeInfo Complex { get; } = new SchemaTypeInfo("complex", new SchemaValidationDto());

        public bool Equals(SchemaTypeInfo other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(DataType, other.DataType)
    && EqualityComparer<SchemaValidationDto>.Default.Equals(Validation, other.Validation);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SchemaTypeInfo);
    }

        public static bool operator ==(SchemaTypeInfo left, SchemaTypeInfo right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SchemaTypeInfo left, SchemaTypeInfo right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 38202;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(DataType);
    hash = hash * -1521134295 + EqualityComparer<SchemaValidationDto>.Default.GetHashCode(Validation);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SchemaTypeInfo { " + "DataType = " + DataType + ", " + "Validation = " + Validation + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SchemaTypeInfo CloneRecord()
    {
    return (SchemaTypeInfo)MemberwiseClone();
    }

    }
    }

}
