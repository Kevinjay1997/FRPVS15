using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Reads the findings out of what a BSP Report API environment answers for a submission's validation result
    /// ({submissionId}/result/xml). BSP does not publish that format, so it is read by what every finding carries rather
    /// than by element names: a BSP rule code (ASSERTION-…, COND-…, DYN-…, or a field named code / rule / assertion), its
    /// message, a severity when one is given, and the field reference ([FORM][TABLE:row][Cxxxx]) when one is given.
    /// XML and JSON are read as records (an element's or object's own values); anything else, or a record format with no
    /// recognisable finding, is read as text the way the text export of BSP's processing result is (SandboxResultReader).
    /// </summary>
    public static class BspResultReader
    {
        public const int MaxFindings = 20000;
        private const int MaxMessageLength = 2000;

        private static readonly Regex CodePattern = new Regex(@"(?<![A-Za-z0-9_-])(?:ASSERTION-[A-Za-z0-9_.-]*[A-Za-z0-9]|COND-\d+|DYN-\d+)(?![A-Za-z0-9_-])",
            RegexOptions.CultureInvariant);
        private static readonly Regex Reference = new Regex(@"(?:\[[A-Za-z0-9_]+(?::\d+)?\]\s*){2,}", RegexOptions.CultureInvariant);
        private static readonly Regex Part = new Regex(@"\[(?<name>[A-Za-z0-9_]+)(?::(?<row>\d+))?\]", RegexOptions.CultureInvariant);
        private static readonly string[] CodeNames = { "code", "rule", "rulecode", "rulename", "assertion", "assertioncode", "assertionid", "errorcode", "check", "checkcode", "validationcode" };
        private static readonly string[] MessageNames = { "message", "msg", "description", "text", "detail", "details", "errormessage", "errortext", "reason", "explanation" };
        private static readonly string[] SeverityNames = { "severity", "level", "type", "errortype", "category", "status", "result", "outcome" };
        private static readonly string[] LocationNames = { "location", "field", "fields", "reference", "ref", "xpath", "path", "cell", "element", "datapoint", "position" };

        public static BspFindingsReadDto Read(byte[] bytes)
        {
            if (bytes == null || bytes.Length == 0)
                return new BspFindingsReadDto { Format = "empty" };
            if (bytes.Length > 4 && bytes[0] == '%' && bytes[1] == 'P' && bytes[2] == 'D' && bytes[3] == 'F')
                return new BspFindingsReadDto { Format = "pdf" };

            var text = Encoding.UTF8.GetString(bytes).TrimStart('﻿', ' ', '\t', '\r', '\n');
            var records = new List<Dictionary<string, string>>();
            string format;
            if (text.StartsWith("<", StringComparison.Ordinal))
            {
                format = "xml";
                XDocument document = null;
                try { using (var stream = new MemoryStream(bytes)) document = SafeXml.Load(stream); }
                catch (XmlException) { format = "text"; }
                catch (WorkflowException) { format = "text"; }
                if (document != null && document.Root != null)
                {
                    foreach (var element in document.Root.DescendantsAndSelf())
                    {
                        // A leaf is part of its parent's record; it is a record of its own only when it has attributes, is
                        // the root, or is one of several same-named leaves that each hold a code (a list of messages).
                        if (!element.HasElements && element.Parent != null && !element.Attributes().Any(a => !a.IsNamespaceDeclaration)
                            && !IsListedFinding(element))
                            continue;
                        var fields = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                        foreach (var attribute in element.Attributes().Where(a => !a.IsNamespaceDeclaration)) Add(fields, attribute.Name.LocalName, attribute.Value);
                        foreach (var child in element.Elements().Where(c => !c.HasElements && !c.Attributes().Any(a => !a.IsNamespaceDeclaration) && !IsListedFinding(c)))
                            Add(fields, child.Name.LocalName, child.Value);
                        if (!element.HasElements) Add(fields, "#text", element.Value);
                        records.Add(fields);
                    }

                    text = string.Join("\n", document.Root.DescendantsAndSelf().Where(e => !e.HasElements).Select(e => e.Value));
                }
            }
            else if (text.StartsWith("{", StringComparison.Ordinal) || text.StartsWith("[", StringComparison.Ordinal))
            {
                format = "json";
                object parsed = null;
                try { parsed = JsonSerializer.Parse(text); }
                catch (JsonException) { format = "text"; }
                if (parsed != null)
                {
                    var values = new List<string>();
                    Walk(parsed, records, values);
                    text = string.Join("\n", values);
                }
            }
            else format = "text";

            var findings = new List<BspFindingDto>();
            foreach (var record in records)
            {
                var finding = FromRecord(record);
                if (finding != null) findings.Add(finding);
                if (findings.Count >= MaxFindings) break;
            }

            // A record that only holds a code (e.g. <Code>ASSERTION-X</Code> inside <Error>) is read with its parent's values
            // by FromRecord already; nothing recognisable at all: read the text.
            if (findings.Count == 0) findings = FromText(text);
            return new BspFindingsReadDto { Format = format, Findings = findings };
        }

        private static bool IsListedFinding(XElement leaf)
        {
            return leaf.Parent != null && !leaf.HasElements && CodePattern.IsMatch(leaf.Value)
                && leaf.Parent.Elements(leaf.Name).Count(e => !e.HasElements && CodePattern.IsMatch(e.Value)) > 1;
        }

        private static void Add(Dictionary<string, string> fields, string name, string value)
        {
            value = (value ?? "").Trim();
            if (value.Length == 0) return;
            var key = name.Replace("_", "").Replace("-", "");
            string existing;
            fields[key] = fields.TryGetValue(key, out existing) ? existing + "; " + value : value;
        }

        private static void Walk(object node, List<Dictionary<string, string>> records, List<string> values)
        {
            var map = node as Dictionary<string, object>;
            if (map != null)
            {
                var fields = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (var pair in map)
                {
                    if (pair.Value is Dictionary<string, object> || pair.Value is List<object>) Walk(pair.Value, records, values);
                    else if (pair.Value != null)
                    {
                        var value = Convert.ToString(pair.Value, System.Globalization.CultureInfo.InvariantCulture);
                        Add(fields, pair.Key, value);
                        values.Add(value);
                    }
                }

                records.Add(fields);
                return;
            }

            var list = node as List<object>;
            if (list != null)
            {
                foreach (var item in list)
                {
                    if (item is Dictionary<string, object> || item is List<object>) Walk(item, records, values);
                    else if (item != null) values.Add(Convert.ToString(item, System.Globalization.CultureInfo.InvariantCulture));
                }
            }
        }

        private static string Named(Dictionary<string, string> fields, string[] names)
        {
            foreach (var name in names)
            {
                string value;
                if (fields.TryGetValue(name, out value)) return value;
            }

            return null;
        }

        /// <summary>One element's or object's own values as a finding, or null when they hold no BSP rule code.</summary>
        private static BspFindingDto FromRecord(Dictionary<string, string> fields)
        {
            if (fields.Count == 0) return null;
            var named = Named(fields, CodeNames);
            string code = null;
            if (named != null)
            {
                var match = CodePattern.Match(named);
                code = match.Success ? match.Value : Regex.IsMatch(named, @"\A[A-Za-z][A-Za-z0-9_.-]{1,79}\z") ? named : null;
            }

            if (code == null)
            {
                var withCode = fields.Values.Select(v => CodePattern.Match(v)).FirstOrDefault(m => m.Success);
                if (withCode == null) return null;
                code = withCode.Value;
            }

            var message = Named(fields, MessageNames)
                ?? fields.Where(f => !CodeNames.Contains(f.Key, StringComparer.OrdinalIgnoreCase) && !SeverityNames.Contains(f.Key, StringComparer.OrdinalIgnoreCase))
                    .Select(f => f.Value).OrderByDescending(v => v.Length).FirstOrDefault()
                ?? "";
            if (message.StartsWith(code, StringComparison.Ordinal)) message = message.Substring(code.Length).TrimStart(' ', ':', '-', '–');
            var location = Named(fields, LocationNames);
            var reference = Reference.Match((location ?? "") + " " + string.Join(" ", fields.Values));
            return Finding(code, Severity(Named(fields, SeverityNames) ?? message), message, reference.Success ? Regex.Replace(reference.Value, @"\s+", "") : location);
        }

        /// <summary>Text: one finding per BSP rule code, its message the text up to the next code.</summary>
        private static List<BspFindingDto> FromText(string text)
        {
            text = Regex.Replace(text ?? "", @"\s+", " ");
            var codes = CodePattern.Matches(text);
            var findings = new List<BspFindingDto>();
            for (var i = 0; i < codes.Count && findings.Count < MaxFindings; i++)
            {
                var start = codes[i].Index + codes[i].Length;
                var end = i + 1 < codes.Count ? codes[i + 1].Index : text.Length;
                var block = text.Substring(start, end - start).Trim(' ', ':', '-', '–');
                var reference = Reference.Match(block);
                findings.Add(Finding(codes[i].Value, Severity(block), block, reference.Success ? Regex.Replace(reference.Value, @"\s+", "") : null));
            }

            return findings;
        }

        private static string Severity(string text)
        {
            text = (text ?? "").ToLowerInvariant();
            if (Regex.IsMatch(text, @"\bwarn(ing)?s?\b")) return "Warning";
            if (Regex.IsMatch(text, @"\b(info|information|passed|ok|valid)\b") && !Regex.IsMatch(text, @"\b(error|fail|failed|invalid|not valid|should not)\b")) return "Info";
            return "Error";
        }

        private static BspFindingDto Finding(string code, string severity, string message, string location)
        {
            message = (message ?? "").Trim();
            if (message.Length > MaxMessageLength) message = message.Substring(0, MaxMessageLength) + "…";
            var finding = new BspFindingDto { Code = code, Severity = severity, Message = message, Location = location };
            if (location != null)
            {
                var parts = Part.Matches(location).Cast<Match>().ToList();
                if (parts.Count > 0) finding.Form = parts[0].Groups["name"].Value;
                var row = parts.FirstOrDefault(p => p.Groups["row"].Success);
                if (row != null)
                {
                    finding.Table = row.Groups["name"].Value;
                    finding.Row = int.Parse(row.Groups["row"].Value, System.Globalization.CultureInfo.InvariantCulture);
                }
            }

            return finding;
        }
    }
}
