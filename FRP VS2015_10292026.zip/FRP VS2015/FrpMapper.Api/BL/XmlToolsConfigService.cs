using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.BL.XmlTools;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// The XML tools' configuration is reference data, approved like the COCREE configuration (see
    /// <see cref="WorkbenchConfigWorkflow"/>): a Maker uploads the Workbench's merge.csv, cleanup.csv and reportperiod.csv
    /// with the _Item rows the normalizer keeps; a different Checker approves them.
    /// </summary>
    public sealed class XmlToolsConfigService : IXmlToolsConfigService
    {
        private readonly WorkbenchConfigWorkflow workflow;
        private readonly IOptionsMonitor<FileStorageOptions> storage;

        public XmlToolsConfigService(IWorkbenchConfigRepository versions, ICurrentUser user, IOptionsMonitor<FileStorageOptions> storage)
        {
            workflow = new WorkbenchConfigWorkflow(versions, user, WorkbenchConfigKind.XmlTools, "XML tools configuration");
            this.storage = storage;
        }

        public Task<WorkbenchSettingsDto> ListAsync(CancellationToken cancellation)
        {
            return workflow.ListAsync(cancellation);
        }

        public async Task<WorkbenchConfigVersionDto> UploadAsync(XmlToolsConfigUpload upload, CancellationToken cancellation)
        {
            var note = workflow.BeginUpload(upload.Note);
            if (upload.MergeCsv == null || upload.CleanupCsv == null || upload.ReportPeriodCsv == null)
                throw WorkbenchConfigWorkflow.Invalid("Choose the three files: merge.csv, cleanup.csv and reportperiod.csv.");
            var merge = Read(upload.MergeCsv, "merge file");
            var cleanup = Read(upload.CleanupCsv, "cleanup file");
            var periods = Read(upload.ReportPeriodCsv, "report period file");
            var kept = (upload.NonRemovableItems ?? "").Trim();
            if (kept.Length > 2000 || kept.Any(ch => char.IsControl(ch) && ch != '\n' && ch != '\r'))
                throw WorkbenchConfigWorkflow.Invalid("The kept _Item rows must be at most 2,000 characters, separated by commas.");

            var content = XmlToolsConfiguration.FromFiles(merge, cleanup, periods, kept);
            var problems = new List<string>();
            var configuration = XmlToolsConfiguration.Load(content, problems);
            if (configuration == null)
                throw WorkbenchConfigWorkflow.Invalid("The configuration cannot be used: " + string.Join(" ", problems.Take(25)));

            var files = new[] { upload.MergeCsv, upload.CleanupCsv, upload.ReportPeriodCsv }.Select(f => Path.GetFileName(f.FileName));
            return await workflow.RequestAsync(string.Join(", ", files), note, configuration.Summary(), JsonSerializer.Serialize(content),
                active => XmlToolsConfiguration.Differences(JsonSerializer.Deserialize<XmlToolsConfigDto>(active), content), cancellation);
        }

        public Task<bool> DecideAsync(string configId, string decision, AccessDecisionRequest body, CancellationToken cancellation)
        {
            return workflow.DecideAsync(configId, decision, body, cancellation);
        }

        public async Task<ToolDownload> DownloadAsync(string configId, string file, CancellationToken cancellation)
        {
            if (file != "merge" && file != "cleanup" && file != "reportperiod") return null;
            var stored = await workflow.GetForDownloadAsync(configId, cancellation);
            if (stored == null) return null;
            var content = JsonSerializer.Deserialize<XmlToolsConfigDto>(stored.Content);
            var table = file == "merge" ? content.Merge : file == "cleanup" ? content.Cleanup : content.ReportPeriods;
            var name = file + "_" + stored.Version.Status.ToLowerInvariant() + "_" + stored.Version.RequestedAt.ToString("yyyyMMdd", CultureInfo.InvariantCulture) + ".csv";
            return new ToolDownload(new MemoryStream(XmlToolsConfiguration.ToCsv(table), false), name, "text/csv");
        }

        private byte[] Read(IFormFile file, string description)
        {
            if (!string.Equals(Path.GetExtension(file.FileName), ".csv", StringComparison.OrdinalIgnoreCase))
                throw WorkbenchConfigWorkflow.Invalid("The " + description + " must be a .csv file.");
            if (file.Length > storage.CurrentValue.MaxUploadBytes)
                throw WorkbenchConfigWorkflow.Invalid("The " + description + " is larger than " + storage.CurrentValue.MaxUploadMegabytes + " MB.");
            using (var stream = file.OpenReadStream())
            using (var copy = new MemoryStream())
            {
                stream.CopyTo(copy);
                return copy.ToArray();
            }
        }
    }
}
