﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>Checks uploads against FileStorage (appsettings.json): allowed extensions per kind and the size limit.</summary>
    public sealed class UploadRules
    {
        private readonly IOptionsMonitor<FileStorageOptions> options;
        private readonly IProjectFileStore fileStore;

        public UploadRules(IOptionsMonitor<FileStorageOptions> options, IProjectFileStore fileStore)
    {
        this.options = options;
        this.fileStore = fileStore;
    }
        /// <summary>True when a file with this content (SHA-256) and extension is already stored, so uploading it again reuses it.</summary>
        public bool IsAlreadyStored(string sha256, string fileName) =>
            fileStore.IsUploadStored(sha256.Trim().ToLowerInvariant(), Path.GetExtension(fileName));

        public FileSettingsDto Settings
        {
            get
            {
                var current = options.CurrentValue;
                return new FileSettingsDto
                {
                    MaxUploadBytes = current.MaxUploadBytes,
                    MaxReferenceFileBytes = current.EffectiveMaxReferenceFileBytes,
                    AllowedExtensions = UploadKinds.All.ToDictionary(kind => kind, kind => current.ExtensionsFor(kind), StringComparer.OrdinalIgnoreCase)
                };
            }
        }

        /// <summary>Rejects a file with an extension not allowed for <paramref name="kind"/> or larger than the limit (400).</summary>
        public void Require(IFormFile file, string kind, string description)
        {
            var current = options.CurrentValue;
            var extensions = current.ExtensionsFor(kind);
            if (!extensions.Contains(Path.GetExtension(file.FileName), StringComparer.OrdinalIgnoreCase))
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"The {description} must be a {string.Join(" or ", extensions)} file.");
            }

            if (file.Length > current.MaxUploadBytes)
            {
                throw new WorkflowException(WorkflowErrorKind.Invalid, $"The {description} is larger than {current.MaxUploadMegabytes} MB.");
            }
        }
    }

}
