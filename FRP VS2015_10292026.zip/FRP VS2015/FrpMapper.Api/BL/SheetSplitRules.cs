﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;
using FrpMapper.Shared.Validation;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Forms whose repeating item fills a whole sheet (e.g. CAR_Part_IV_4c: one item per Currency, laid out as a form),
    /// and how a Maker splits them into one copy of the sheet per key value ("CAR_Part_IV_4c (PHP)", "(USD)", ...).
    /// Excel's XML map cannot bind such an item to form cells (and never a list inside it), so the app reads these
    /// sheets itself: every sheet is one item, and every list inside it is read row by row from its first mapped row
    /// down to the last input row the template's layout leaves for it.
    /// </summary>
    public static partial class SheetSplitRules
    {
        public const int MaxValues = 100;
        public const int MaxValueLength = 20;
        /// <summary>At most this many rows are read for one list inside a form.</summary>
        private const int MaxListRows = 500;

        /// <summary>A form-like repeating item: all its mapped fields are on one sheet that holds nothing else.</summary>
        /// <param name="Fields">The item's own fields (not those of a list inside it).</param>
        /// <param name="Keys">The item's direct fields that can tell the sheet copies apart (e.g. Currency).</param>
        public sealed class FormLayout : IRecord<FormLayout>, IEquatable<FormLayout>
    {
        public string GroupPath { get; set; }

        public string SheetName { get; set; }

        public IReadOnlyList<MappingEntryDto> Fields { get; set; }

        public IReadOnlyList<MappingEntryDto> Keys { get; set; }

        public IReadOnlyList<NestedList> NestedLists { get; set; }

        public FormLayout(string GroupPath, string SheetName, IReadOnlyList<MappingEntryDto> Fields, IReadOnlyList<MappingEntryDto> Keys, IReadOnlyList<NestedList> NestedLists)
    {
    this.GroupPath = GroupPath;
    this.SheetName = SheetName;
    this.Fields = Fields;
    this.Keys = Keys;
    this.NestedLists = NestedLists;
    }

        public void Deconstruct(out string GroupPath, out string SheetName, out IReadOnlyList<MappingEntryDto> Fields, out IReadOnlyList<MappingEntryDto> Keys, out IReadOnlyList<NestedList> NestedLists)
    {
    GroupPath = this.GroupPath;
    SheetName = this.SheetName;
    Fields = this.Fields;
    Keys = this.Keys;
    NestedLists = this.NestedLists;
    }

        public bool Equals(FormLayout other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(GroupPath, other.GroupPath)
    && EqualityComparer<string>.Default.Equals(SheetName, other.SheetName)
    && EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.Equals(Fields, other.Fields)
    && EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.Equals(Keys, other.Keys)
    && EqualityComparer<IReadOnlyList<NestedList>>.Default.Equals(NestedLists, other.NestedLists);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as FormLayout);
    }

        public static bool operator ==(FormLayout left, FormLayout right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(FormLayout left, FormLayout right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 20159;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(GroupPath);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SheetName);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.GetHashCode(Fields);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.GetHashCode(Keys);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<NestedList>>.Default.GetHashCode(NestedLists);
    return hash;
    }
    }

        public override string ToString()
    {
    return "FormLayout { " + "GroupPath = " + GroupPath + ", " + "SheetName = " + SheetName + ", " + "Fields = " + Fields + ", " + "Keys = " + Keys + ", " + "NestedLists = " + NestedLists + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public FormLayout CloneRecord()
    {
    return (FormLayout)MemberwiseClone();
    }

    }

        /// <summary>A list inside a form. Its fields share one row; rows <see cref="FirstRow"/>..<see cref="LastRow"/> are its items.</summary>
        /// <param name="FirstRow">0 when the list's fields are not on one row: then only the mapped cells are read.</param>
        public sealed class NestedList : IRecord<NestedList>, IEquatable<NestedList>
    {
        public string ItemPath { get; set; }

        public IReadOnlyList<MappingEntryDto> Fields { get; set; }

        public int FirstRow { get; set; }

        public int LastRow { get; set; }

        public NestedList(string ItemPath, IReadOnlyList<MappingEntryDto> Fields, int FirstRow, int LastRow)
    {
    this.ItemPath = ItemPath;
    this.Fields = Fields;
    this.FirstRow = FirstRow;
    this.LastRow = LastRow;
    }

        public void Deconstruct(out string ItemPath, out IReadOnlyList<MappingEntryDto> Fields, out int FirstRow, out int LastRow)
    {
    ItemPath = this.ItemPath;
    Fields = this.Fields;
    FirstRow = this.FirstRow;
    LastRow = this.LastRow;
    }

        public bool Equals(NestedList other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(ItemPath, other.ItemPath)
    && EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.Equals(Fields, other.Fields)
    && EqualityComparer<int>.Default.Equals(FirstRow, other.FirstRow)
    && EqualityComparer<int>.Default.Equals(LastRow, other.LastRow);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as NestedList);
    }

        public static bool operator ==(NestedList left, NestedList right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(NestedList left, NestedList right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 41990;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ItemPath);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<MappingEntryDto>>.Default.GetHashCode(Fields);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(FirstRow);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(LastRow);
    return hash;
    }
    }

        public override string ToString()
    {
    return "NestedList { " + "ItemPath = " + ItemPath + ", " + "Fields = " + Fields + ", " + "FirstRow = " + FirstRow + ", " + "LastRow = " + LastRow + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public NestedList CloneRecord()
    {
    return (NestedList)MemberwiseClone();
    }

    }

        /// <summary>A valid split of the project: the form, its key field, and each value's sheet.</summary>
        public sealed class ResolvedSplit : IRecord<ResolvedSplit>, IEquatable<ResolvedSplit>
    {
        public SheetSplitDto Split { get; set; }

        public FormLayout Form { get; set; }

        public MappingEntryDto Key { get; set; }

        public IReadOnlyList<VT_Value_SheetName<string, string>> Sheets { get; set; }

        public ResolvedSplit(SheetSplitDto Split, FormLayout Form, MappingEntryDto Key, IReadOnlyList<VT_Value_SheetName<string, string>> Sheets)
    {
    this.Split = Split;
    this.Form = Form;
    this.Key = Key;
    this.Sheets = Sheets;
    }

        public void Deconstruct(out SheetSplitDto Split, out FormLayout Form, out MappingEntryDto Key, out IReadOnlyList<VT_Value_SheetName<string, string>> Sheets)
    {
    Split = this.Split;
    Form = this.Form;
    Key = this.Key;
    Sheets = this.Sheets;
    }

        public bool Equals(ResolvedSplit other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<SheetSplitDto>.Default.Equals(Split, other.Split)
    && EqualityComparer<FormLayout>.Default.Equals(Form, other.Form)
    && EqualityComparer<MappingEntryDto>.Default.Equals(Key, other.Key)
    && EqualityComparer<IReadOnlyList<VT_Value_SheetName<string, string>>>.Default.Equals(Sheets, other.Sheets);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ResolvedSplit);
    }

        public static bool operator ==(ResolvedSplit left, ResolvedSplit right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ResolvedSplit left, ResolvedSplit right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 14545;
    hash = hash * -1521134295 + EqualityComparer<SheetSplitDto>.Default.GetHashCode(Split);
    hash = hash * -1521134295 + EqualityComparer<FormLayout>.Default.GetHashCode(Form);
    hash = hash * -1521134295 + EqualityComparer<MappingEntryDto>.Default.GetHashCode(Key);
    hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<VT_Value_SheetName<string, string>>>.Default.GetHashCode(Sheets);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ResolvedSplit { " + "Split = " + Split + ", " + "Form = " + Form + ", " + "Key = " + Key + ", " + "Sheets = " + Sheets + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ResolvedSplit CloneRecord()
    {
    return (ResolvedSplit)MemberwiseClone();
    }

    }

        // ---------- forms ----------

        /// <summary>
        /// Every form-like repeating item (see <see cref="FormLayout"/>). The item's own fields must span more than one row
        /// (a form, not one row of a table: a table is an XML list table with a row per item).
        /// </summary>
        public static IReadOnlyList<FormLayout> FormLayouts(FrpProjectDto project)
        {
            var nodesByPath = NodesByPath(project);
            var repeating = project.SchemaNodes.Where(n => n.IsRepeating).Select(n => n.Path).ToList();
            var mappings = project.Mappings
                .Where(m => { int unusedColumn; int unusedRow; SchemaNodeDto node; return !string.IsNullOrWhiteSpace(m.SheetName) && TryCell(m.CellAddress, out unusedColumn, out unusedRow)
                    && nodesByPath.TryGetValue(m.SchemaPath, out node) && node.DataType != "complex"; })
                .ToList();
            var bySheet = mappings.GroupBy(m => m.SheetName, StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.ToList(), StringComparer.OrdinalIgnoreCase);
            var result = new List<FormLayout>();

            foreach (var groupPath in repeating.Where(p => !repeating.Any(o => p.StartsWith(o + "/", StringComparison.Ordinal))))
            {
                var inGroup = mappings.Where(m => m.SchemaPath.StartsWith(groupPath + "/", StringComparison.Ordinal)).ToList();
                var sheets = inGroup.Select(m => m.SheetName).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                if (inGroup.Count == 0 || sheets.Count != 1
                    || string.Equals(sheets[0], MappingSuggestionEngine.UnplacedSheetName, StringComparison.OrdinalIgnoreCase)
                    || bySheet[sheets[0]].Count != inGroup.Count
                    || inGroup.GroupBy(m => m.SchemaPath, StringComparer.Ordinal).Any(g => g.Count() > 1))
                {
                    continue;
                }

                var own = inGroup.Where(m => NearestRepeating(nodesByPath[m.SchemaPath], nodesByPath)?.Path == groupPath).ToList();
                if (own.Select(m => Row(m.CellAddress)).Distinct().Count() < 2)
                {
                    continue;
                }

                var nested = new List<NestedList>();
                var nestedPaths = repeating
                    .Where(p => p.StartsWith(groupPath + "/", StringComparison.Ordinal)
                        && NearestRepeating(nodesByPath[nodesByPath[p].ParentPath], nodesByPath)?.Path == groupPath)
                    .ToList();
                var fields = new List<MappingEntryDto>(own);
                foreach (var itemPath in nestedPaths)
                {
                    var listFields = inGroup.Where(m => m.SchemaPath.StartsWith(itemPath + "/", StringComparison.Ordinal)).ToList();
                    var direct = listFields.Where(m => NearestRepeating(nodesByPath[m.SchemaPath], nodesByPath)?.Path == itemPath).ToList();
                    if (direct.Count == 0)
                    {
                        continue;
                    }

                    // Deeper lists (a list inside this list) are read from their mapped cells only.
                    fields.AddRange(listFields.Except(direct));
                    var rows = direct.Select(m => Row(m.CellAddress)).Distinct().ToList();
                    var oneRow = rows.Count == 1 && direct.Select(m => Column(m.CellAddress)).Distinct().Count() == direct.Count;
                    nested.Add(new NestedList(itemPath, direct, oneRow ? rows[0] : 0, oneRow ? rows[0] : 0));
                }

                var keys = own
                    .Where(m => string.Equals(nodesByPath[m.SchemaPath].ParentPath, groupPath, StringComparison.Ordinal))
                    .OrderByDescending(m => nodesByPath[m.SchemaPath].IsRequired)
                    .ToList();
                result.Add(new FormLayout(groupPath, sheets[0], fields, keys, nested));
            }

            return result;
        }

        /// <summary>
        /// The forms the app reads itself from their sheets: every split form, and every form-like item that holds a list
        /// (a list inside a list, which Excel cannot bind). Their lists get their row ranges from the project's template.
        /// </summary>
        public static IReadOnlyList<FormLayout> AppReadForms(FrpProjectDto project)
        {
            var split = Resolve(project).Select(s => s.Form.GroupPath).ToHashSet(StringComparer.Ordinal);
            return FormLayouts(project)
                .Where(f => split.Contains(f.GroupPath) || f.NestedLists.Count > 0)
                .Select(f => WithListRows(project, f))
                .ToList();
        }

        /// <summary>
        /// Repeating items Excel's XML map does not bind: lists inside lists (Excel cannot) and split forms (one sheet per
        /// key value; the app reads each sheet). Excel's own XML export leaves them out; the app's XML includes them.
        /// </summary>
        /// A form bound with one item (<see cref="ExcelItemForms"/>) is bound.
        public static IReadOnlyList<string> NotBoundInExcel(FrpProjectDto project)
        {
            var bound = ExcelItemForms(project).Select(f => f.GroupPath).ToHashSet(StringComparer.Ordinal);
            Func<string, bool> BoundByCopies = null;
            BoundByCopies = (string pathArg) =>
            {
                return bound.Any(g => pathArg == g || pathArg.StartsWith(g + "/", StringComparison.Ordinal));
            };
            return OpenXmlMappedTemplateWriter.UnmappableListGroups(project)
                .Concat(Resolve(project).Select(s => s.Form.GroupPath))
                .Where(path => !BoundByCopies(path))
                .Distinct(StringComparer.Ordinal)
                .ToList();
        }

        /// <summary>
        /// The forms the app reads itself that Excel's XML map binds with one item, under the XSD's own names: the item sits
        /// directly in a form under the root (/Root/Form/Form_Item). Excel's export then has that one item (for a split form,
        /// its first sheet; the other sheets are bound to clone elements, see <see cref="SheetCopyMap"/>).
        /// </summary>
        public static IReadOnlyList<FormLayout> ExcelItemForms(FrpProjectDto project) =>
            AppReadForms(project).Where(f => f.GroupPath.Count(c => c == '/') == 3).ToList();

        public static IReadOnlyList<SheetSplitOptionDto> Options(FrpProjectDto project)
        {
            var nodesByPath = NodesByPath(project);
            return FormLayouts(project)
                .Where(f => f.Keys.Count > 0)
                .Select(f => new SheetSplitOptionDto
                {
                    GroupPath = f.GroupPath,
                    Form = FormName(f.GroupPath),
                    SheetName = f.SheetName,
                    FieldCount = f.Fields.Count + f.NestedLists.Sum(l => l.Fields.Count),
                    HasNestedLists = f.NestedLists.Count > 0,
                    KeyFields = f.Keys.Select(k =>
                    {
                        var node = nodesByPath[k.SchemaPath];
                        return new SheetSplitKeyDto
                        {
                            Path = node.Path,
                            Name = node.Name,
                            DataType = node.DataType,
                            IsRequired = node.IsRequired,
                            AllowedValues = node.Validation.Enumerations,
                            CellAddress = k.CellAddress.ToUpperInvariant()
                        };
                    }).ToList()
                })
                .ToList();
        }

        // ---------- splits ----------

        /// <summary>The project's splits that still match its mappings (a split whose form changed is ignored and reported).</summary>
        public static IReadOnlyList<ResolvedSplit> Resolve(FrpProjectDto project, List<string> problems = null)
        {
            if (project.SheetSplits.Count == 0)
            {
                return new List<ResolvedSplit>();
            }

            var forms = FormLayouts(project).ToDictionary(f => f.GroupPath, StringComparer.Ordinal);
            var result = new List<ResolvedSplit>();
            foreach (var split in project.SheetSplits)
            {
                FormLayout form;
                if (!forms.TryGetValue(split.GroupPath, out form))
                {
                    problems?.Add($"The sheet copies of {FormName(split.GroupPath)} are not used: its fields are no longer all mapped to one sheet of their own.");
                    continue;
                }

                var key = form.Keys.FirstOrDefault(k => string.Equals(k.SchemaPath, split.KeyPath, StringComparison.Ordinal));
                if (key == null || split.Values.Count == 0)
                {
                    problems?.Add($"The sheet copies of {FormName(split.GroupPath)} are not used: {LastToken(split.KeyPath)} is no longer mapped on {form.SheetName}.");
                    continue;
                }

                result.Add(new ResolvedSplit(split, form, key, split.Values.Select(v => new VT_Value_SheetName<string, string>(v, SheetSplitNames.For(form.SheetName, v))).ToList()));
            }

            return result;
        }

        /// <summary>
        /// Checks and normalises a Maker's splits: known forms and key fields, 1..<see cref="MaxValues"/> distinct values that
        /// are valid for the key field (an XSD code list's own spelling is used), and sheet names that are unique in the workbook.
        /// </summary>
        public static IReadOnlyList<SheetSplitDto> Normalize(FrpProjectDto project, IReadOnlyList<SheetSplitDto> requested)
        {
            var options = Options(project).ToDictionary(o => o.GroupPath, StringComparer.Ordinal);
            var nodesByPath = NodesByPath(project);
            var result = new List<SheetSplitDto>();
            var seenForms = new HashSet<string>(StringComparer.Ordinal);
            foreach (var split in requested ?? new List<SheetSplitDto>())
            {
                SheetSplitOptionDto option;
                if (split == null || !options.TryGetValue(split.GroupPath ?? "", out option))
                {
                    throw Invalid("A form in the request cannot be split into sheet copies: its fields must all be mapped to one sheet of their own.");
                }

                if (!seenForms.Add(option.GroupPath))
                {
                    throw Invalid($"{option.Form} is listed more than once.");
                }

                var keyField = option.KeyFields.FirstOrDefault(k => string.Equals(k.Path, split.KeyPath, StringComparison.Ordinal))
                    ?? CompatThrow.As<SheetSplitKeyDto>(Invalid($"{option.Form}: choose one of its fields {string.Join(", ", option.KeyFields.Select(k => k.Name))} to tell the sheets apart."));
                var keyNode = nodesByPath[keyField.Path];
                var values = new List<string>();
                foreach (var raw in split.Values ?? new List<string>())
                {
                    var value = (raw ?? "").Trim();
                    if (value.Length == 0)
                    {
                        continue;
                    }

                    if (value.Length > MaxValueLength || !SafeValue().IsMatch(value))
                    {
                        throw Invalid($"{option.Form}: \"{Shorten(value)}\" cannot name a sheet. Use letters, digits, spaces, '.', '-' or '_' (at most {MaxValueLength} characters).");
                    }

                    if (keyField.AllowedValues.Count > 0)
                    {
                        value = keyField.AllowedValues.FirstOrDefault(a => string.Equals(a, value, StringComparison.OrdinalIgnoreCase))
                            ?? CompatThrow.As<string>(Invalid($"{option.Form}: {value} is not an allowed {keyField.Name} in the XSD."));
                    }

                    var errors = XsdValueValidator.Validate(value, keyNode);
                    if (errors.Count > 0)
                    {
                        throw Invalid($"{option.Form}: {value} is not a valid {keyField.Name}: {errors[0]}");
                    }

                    if (values.Contains(value, StringComparer.OrdinalIgnoreCase))
                    {
                        throw Invalid($"{option.Form}: {value} is listed more than once.");
                    }

                    values.Add(value);
                }

                if (values.Count == 0)
                {
                    throw Invalid($"{option.Form}: add at least one {keyField.Name}, or turn the sheet copies off.");
                }

                if (values.Count > MaxValues)
                {
                    throw Invalid($"{option.Form}: at most {MaxValues} sheet copies.");
                }

                result.Add(new SheetSplitDto { GroupPath = option.GroupPath, KeyPath = keyField.Path, Values = values });
            }

            // Sheet names must be unique (Excel compares them without case): against each other and the other sheets.
            var baseSheets = result.Select(s => options[s.GroupPath].SheetName).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var sheet in (project.Workbook?.Sheets.Select(s => s.Name) ?? new List<string>()).Concat(project.Mappings.Select(m => m.SheetName)))
            {
                if (!string.IsNullOrWhiteSpace(sheet) && !baseSheets.Contains(sheet))
                {
                    names.Add(sheet);
                }
            }

            foreach (var split in result)
            {
                foreach (var value in split.Values)
                {
                    var name = SheetSplitNames.For(options[split.GroupPath].SheetName, value);
                    if (!names.Add(name))
                    {
                        throw Invalid($"The sheet name \"{name}\" would be used twice. Choose other values.");
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// The project with each split form's key value on the sheet that holds the project's (or sample) values: when that
        /// value is not one of the split's values, the first value is used, so the exported XML matches the template's
        /// first sheet.
        /// </summary>
        public static FrpProjectDto WithAlignedKeys(FrpProjectDto project)
        {
            var splits = Resolve(project);
            if (splits.Count == 0)
            {
                return project;
            }

            var replace = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var split in splits)
            {
                // The values always go on the first sheet: it is the one Excel's XML map binds under the XSD's names (see OpenXmlMappedTemplateWriter).
                var current = XmlSubmissionWriter.ResolveExportValue(project, split.Key);
                if (!string.Equals(current, split.Split.Values[0], StringComparison.OrdinalIgnoreCase))
                {
                    replace[split.Key.SchemaPath] = split.Split.Values[0];
                }
            }

            return replace.Count == 0 ? project : project.With(copy => { copy.Mappings = project.Mappings.Select(m => { string value; return replace.TryGetValue(m.SchemaPath, out value) ? m.With(inner => { inner.DefaultValue = value; }) : m; }).ToList(); copy.SchemaNodes = project.SchemaNodes.Select(n => { string value; return replace.TryGetValue(n.Path, out value) ? n.With(inner => { inner.TestValue = value; }) : n; }).ToList(); });
        }

        /// <summary>The index of the sheet that holds the project's (or sample) values: the one whose value is the key's value.</summary>
        public static int ValuesSheet(FrpProjectDto project, ResolvedSplit split)
        {
            var current = XmlSubmissionWriter.ResolveExportValue(project, split.Key);
            var index = split.Split.Values.ToList().FindIndex(v => string.Equals(v, current, StringComparison.OrdinalIgnoreCase));
            return Math.Max(index, 0);
        }

        // ---------- list rows from the template's layout ----------

        /// <summary>
        /// Each list's last input row: the rows below its first row stay part of the list while the template has an empty,
        /// formatted cell in each of the list's columns there (BSP's bordered input rows; a spacer row or the next block's
        /// captions and code headers end it) and no other field is mapped there.
        /// Without an uploaded template (a generated one), a list has its mapped row only.
        /// </summary>
        private static FormLayout WithListRows(FrpProjectDto project, FormLayout form)
        {
            if (form.NestedLists.All(l => l.FirstRow == 0) || project.TemplateFile == null || !File.Exists(project.TemplateFile.StoredPath))
            {
                return form;
            }

            var layout = TemplateLayout(project.TemplateFile.StoredPath, form.SheetName);
            if (layout == null)
            {
                return form;
            }

            var mappedCells = form.Fields.Concat(form.NestedLists.SelectMany(l => l.Fields))
                .Select(m => new VT_Column_Row<int, int>(Column(m.CellAddress), Row(m.CellAddress)))
                .ToHashSet();
            var lists = form.NestedLists.Select(list =>
            {
                if (list.FirstRow == 0)
                {
                    return list;
                }

                var columns = list.Fields.Select(m => Column(m.CellAddress)).ToList();
                var last = list.FirstRow;
                for (var row = list.FirstRow + 1; row <= Math.Min(layout.MaxRow, list.FirstRow + MaxListRows - 1); row++)
                {
                    // An input row of the list: every column has a (formatted) empty cell there, and no field is mapped to it.
                    if (columns.Any(c => !layout.Present.Contains(new VT_Column_Row<int, int>(c, row)) || layout.Filled.Contains(new VT_Column_Row<int, int>(c, row)) || mappedCells.Contains(new VT_Column_Row<int, int>(c, row))))
                    {
                        break;
                    }

                    last = row;
                }

                return list.With(copy => { copy.LastRow = last; });
            }).ToList();
            return form.With(copy => { copy.NestedLists = lists; });
        }

        /// <param name="Present">Cells the sheet has (formatted, or with content).</param>
        /// <param name="Filled">Cells with a value or formula.</param>
        private sealed class SheetLayout : IRecord<SheetLayout>, IEquatable<SheetLayout>
    {
        public HashSet<VT_Column_Row<int, int>> Present { get; set; }

        public HashSet<VT_Column_Row<int, int>> Filled { get; set; }

        public int MaxRow { get; set; }

        public SheetLayout(HashSet<VT_Column_Row<int, int>> Present, HashSet<VT_Column_Row<int, int>> Filled, int MaxRow)
    {
    this.Present = Present;
    this.Filled = Filled;
    this.MaxRow = MaxRow;
    }

        public void Deconstruct(out HashSet<VT_Column_Row<int, int>> Present, out HashSet<VT_Column_Row<int, int>> Filled, out int MaxRow)
    {
    Present = this.Present;
    Filled = this.Filled;
    MaxRow = this.MaxRow;
    }

        public bool Equals(SheetLayout other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<HashSet<VT_Column_Row<int, int>>>.Default.Equals(Present, other.Present)
    && EqualityComparer<HashSet<VT_Column_Row<int, int>>>.Default.Equals(Filled, other.Filled)
    && EqualityComparer<int>.Default.Equals(MaxRow, other.MaxRow);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as SheetLayout);
    }

        public static bool operator ==(SheetLayout left, SheetLayout right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(SheetLayout left, SheetLayout right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 97848;
    hash = hash * -1521134295 + EqualityComparer<HashSet<VT_Column_Row<int, int>>>.Default.GetHashCode(Present);
    hash = hash * -1521134295 + EqualityComparer<HashSet<VT_Column_Row<int, int>>>.Default.GetHashCode(Filled);
    hash = hash * -1521134295 + EqualityComparer<int>.Default.GetHashCode(MaxRow);
    return hash;
    }
    }

        public override string ToString()
    {
    return "SheetLayout { " + "Present = " + Present + ", " + "Filled = " + Filled + ", " + "MaxRow = " + MaxRow + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public SheetLayout CloneRecord()
    {
    return (SheetLayout)MemberwiseClone();
    }

    }

        private static readonly ConcurrentDictionary<string, SheetLayout> Layouts = new ConcurrentDictionary<string, SheetLayout>(StringComparer.Ordinal);

        /// <summary>The template sheet's non-empty cells (values or formulas) and last row. Uploaded templates never change (they are stored by SHA-256).</summary>
        private static SheetLayout TemplateLayout(string templatePath, string sheetName)
        {
            if (Layouts.Count > 256)
            {
                Layouts.Clear();
            }

            return Layouts.GetOrAdd($"{templatePath}\u001f{sheetName.ToUpperInvariant()}", _ =>
            {
                try
                {
                    using (var archive = ZipFile.OpenRead(templatePath))
                    {
                    var worksheetPath = TemplateCoverageChecker.Sheets(archive)
                        .FirstOrDefault(s => string.Equals(s.Name, sheetName, StringComparison.OrdinalIgnoreCase)).WorksheetPath;
                    var entry = (worksheetPath == null) ? null : archive.GetEntry(worksheetPath);
                    if (entry == null)
                    {
                        return null;
                    }

                    // Shared strings that show something (an index to an empty or blank string does not fill a cell).
                    var sharedFilled = new List<bool>();
                    ZipArchiveEntry sharedEntry;
                    if (CompatPattern.Is(archive.GetEntry("xl/sharedStrings.xml"), out sharedEntry))
                    {
                        using (var sharedStream = sharedEntry.Open())
                        {
                        var shared = SafeXml.Load(sharedStream).Root;
                        System.Xml.Linq.XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
                        sharedFilled.AddRange(shared?.Elements(ns + "si")
                            .Select(si => string.Concat(si.Descendants(ns + "t").Select(t => t.Value)).Trim().Length > 0) ?? new List<bool>());
                        }
                    }

                    var present = new HashSet<VT_Column_Row<int, int>>();
                    var filled = new HashSet<VT_Column_Row<int, int>>();
                    var maxRow = 0;
                    using (var stream = entry.Open())
                    {
                    using (var reader = XmlReader.Create(stream, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null }))
                    {
                    string cell = null;
                    string cellType = null;
                    while (reader.Read())
                    {
                        if (reader.NodeType != XmlNodeType.Element)
                        {
                            continue;
                        }

                        var name = reader.LocalName;
                        int rowNumber;
                        if (name == "row" && int.TryParse(reader.GetAttribute("r"), out rowNumber))
                        {
                            maxRow = Math.Max(maxRow, rowNumber);
                        }
                        else if (name == "c")
                        {
                            cell = reader.GetAttribute("r");
                            cellType = reader.GetAttribute("t");
                            int presentColumn;
                            int presentRow;
                            if (TryCell(cell, out presentColumn, out presentRow))
                            {
                                present.Add(new VT_Column_Row<int, int>(presentColumn, presentRow));
                            }
                        }
                        else 
                        {
                            int column;
                            int row;
    if ((name == "f" || name == "v" || name == "t") && cell != null && TryCell(cell, out column, out row))
                        {
                            // A formula, or a value / inline text that shows something. (Reading the text moves the reader to the
                            // node after this element: at most the cell's <v> or its end, never the start of another cell.)
                            var text = reader.IsEmptyElement ? "" : reader.ReadInnerXml();
                            int index;
                            var shows = name == "f"
                                || (name == "v" && cellType == "s"
                                    ? int.TryParse(text, out index) && index >= 0 && index < sharedFilled.Count && sharedFilled[index]
                                    : text.Trim().Length > 0);
                            if (shows)
                            {
                                filled.Add(new VT_Column_Row<int, int>(column, row));
                            }
                        }
                        }
                    }

                    return new SheetLayout(present, filled, maxRow);
                    }
                    }
                    }
                }
                catch (Exception ex) when ((ex is IOException || ex is InvalidDataException || ex is XmlException || ex is UnauthorizedAccessException))
                {
                    return null;
                }
            });
        }

        // ---------- helpers ----------

        internal static string FormName(string groupPath)  {
        string[] tokens;
        return (CompatPattern.Is(groupPath.Split('/', StringSplitOptions.RemoveEmptyEntries), out tokens) && tokens.Length >= 2) ? tokens[1] : groupPath;
    }

        private static string LastToken(string path) => path.Split('/', StringSplitOptions.RemoveEmptyEntries).LastOrDefault() ?? path;

        private static Dictionary<string, SchemaNodeDto> NodesByPath(FrpProjectDto project) => project.SchemaNodes
            .GroupBy(n => n.Path, StringComparer.Ordinal)
            .ToDictionary(g => g.Key, g => g.First(), StringComparer.Ordinal);

        internal static SchemaNodeDto NearestRepeating(SchemaNodeDto node, IReadOnlyDictionary<string, SchemaNodeDto> nodesByPath)
        {
            for (var current = node; (current != null); current = (current.ParentPath == null) ? null : nodesByPath.GetValueOrDefault(current.ParentPath))
            {
                if (current.IsRepeating)
                {
                    return current;
                }
            }

            return null;
        }

        internal static bool TryCell(string address, out int column, out int row)
        {
            column = 0;
            row = 0;
            if (string.IsNullOrEmpty(address))
            {
                return false;
            }

            var i = 0;
            while (i < address.Length && CompatChar.IsAsciiLetter(address[i]))
            {
                column = column * 26 + (char.ToUpperInvariant(address[i]) - 'A' + 1);
                i++;
            }

            return i > 0 && i <= 3 && i < address.Length
                && int.TryParse(address.Substring(i), System.Globalization.NumberStyles.None, System.Globalization.CultureInfo.InvariantCulture, out row) && row > 0;
        }

        internal static int Row(string address)  {
        int unusedColumn;
        int row;
        return TryCell(address, out unusedColumn, out row) ? row : 0;
    }

        internal static int Column(string address)  {
        int column;
        int unusedRow;
        return TryCell(address, out column, out unusedRow) ? column : 0;
    }

        internal static string ColumnLetters(int column)
        {
            var name = "";
            while (column > 0)
            {
                var remainder = (column - 1) % 26;
                name = (char)('A' + remainder) + name;
                column = (column - 1) / 26;
            }

            return name;
        }

        private static WorkflowException Invalid(string message) => new WorkflowException(WorkflowErrorKind.Invalid, message);

        private static string Shorten(string value) => value.Length <= 30 ? value : value.Substring(0, 30) + "…";

        private static System.Text.RegularExpressions.Regex SafeValue() { return SafeValueInstance; }

        private static readonly System.Text.RegularExpressions.Regex SafeValueInstance = new System.Text.RegularExpressions.Regex(@"^[A-Za-z0-9](?:[A-Za-z0-9 ._-]*[A-Za-z0-9._-])?$", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

}
