﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;
using FrpMapper.Shared.Validation;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// Makes the generated sample values consistent with the BSP specification rules, so the "XSD sample values"
    /// XML and templates pass validation:
    /// 1. fields used in schedule conditions (e.g. ISANYOF([Header][Period]; 3; 6; 9; 12), [CAR_Info][MarketRiskApproach]="1")
    ///    get the value under which the sample, which fills every schedule, breaks the fewest rules (a quarter-end month for FRP);
    /// 2. rules with a single field on one side (totals, "must be 0 for a solo report", upper/lower bounds,
    ///    "PHP must be submitted") set that field from the other side, and "one row per code" rules add sample rows,
    ///    repeated until nothing changes.
    /// Values always stay within the XSD facets. Rules that need BSP reference data (LOOKUP) are left alone.
    /// </summary>
    public sealed partial class BspSampleValueSolver
    {
        private readonly BspAssertionEvaluator evaluator;
        private readonly XmlSubmissionWriter xmlWriter;
        private readonly BspDerivedValues derivedValues;

        public BspSampleValueSolver(BspAssertionEvaluator evaluator, XmlSubmissionWriter xmlWriter, BspDerivedValues derivedValues)
    {
        this.evaluator = evaluator;
        this.xmlWriter = xmlWriter;
        this.derivedValues = derivedValues;
    }
        /// <param name="progress">Reports the passes over the rules while sample values are fixed (optional).</param>
        public SolvedSamples Apply(IReadOnlyList<SchemaNodeDto> nodes, string rootElement, string targetNamespace, BspSpecification specification, BankReferenceContext reference = null,
            ValidationStep progress = null)
        {
            if (specification.Assertions.Count == 0 || string.IsNullOrWhiteSpace(rootElement))
            {
                return new SolvedSamples(nodes, new List<SampleRowDto>(), new List<string>());
            }

            var draft = new FrpProjectDto { RootElement = rootElement, TargetNamespace = targetNamespace, SchemaNodes = nodes };
            var document = xmlWriter.BuildDocument(draft);
            if (reference != null)
            {
                document.Root.AddAnnotation(reference);
                BankProfileDto bank;
                if (CompatPattern.Is(reference.SampleBank, out bank))
                {
                    var undertaking = document.Root.Elements().FirstOrDefault(e => e.Name.LocalName == "Header")?.Elements().FirstOrDefault(e => e.Name.LocalName == "Undertaking");
                    if (undertaking != null) undertaking.Value = bank.ProviderCode;
                    SeedBranches(document, bank);
                }
            }
            var nodesByPath = nodes
                .Where(n => n.DataType != "complex")
                .GroupBy(n => n.Path, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            var submitted = BspSpecificationValidator.SubmittedFields(nodes);

            // Header fields and the fields chosen for schedule conditions are fixed once chosen,
            // so fixing a total never changes the reporting period or approach the schedules depend on.
            var locked = new HashSet<XElement>();
            Func<XElement, decimal?, string, string> Propose = null;
            Propose = (XElement elementArg, decimal? number, string text) => {
        SchemaNodeDto node;
        return !locked.Contains(elementArg) && nodesByPath.TryGetValue(PathOf(elementArg), out node) ? Format(node, number, text) : null;
    };
            Func<XElement, IEnumerable<string>> Alternatives = null;
            Alternatives = (XElement elementArg) => {
        SchemaNodeDto node;
        return !locked.Contains(elementArg) && nodesByPath.TryGetValue(PathOf(elementArg), out node) ? node.Validation.Enumerations : new List<string>();
    };

            // A value BSP computes (a total, a location summary) is changed through one of the submitted values it adds up.
            Func<XElement, decimal?, string, string> ProposeAny = (XElement elementArg, decimal? number, string text) =>
                elementArg.Annotation<BspComputed>() != null ? BspComputed.SetThroughParts(elementArg, number, Propose) : Propose(elementArg, number, text);
            Func<XElement, IEnumerable<string>> AlternativesAny = (XElement elementArg) =>
                elementArg.Annotation<BspComputed>() != null ? new List<string>() : Alternatives(elementArg);
            var proposer = new DelegateProposer(ProposeAny, AlternativesAny);
            // The rules see the values BSP computes, worked out again as the sample values change (as the validation does).
            var computing = reference ?? new BankReferenceContext();
            if (computing.RegionCodes == null || computing.RegionCodes.Count == 0)
            {
                computing.RegionCodes = derivedValues.RegionCodes(specification);
            }

            Func<IEnumerable<string>> refresh = () =>
            {
                ISet<string> moved;
                derivedValues.Refresh(specification, document, submitted, computing, out moved);
                return moved;
            };
            if ((reference?.SampleBank) != null)
                locked.UnionWith(document.Descendants().Where(e => e.Name.LocalName == "C0030" && e.Ancestors().Any(a => a.Name.LocalName.StartsWith("BRIS_"))));
            var conditionFields = ChooseConditionValues(document, specification.Assertions, submitted, Propose, periodFixed: (reference?.SamplePeriod) != null);
            locked.UnionWith(conditionFields);
            locked.UnionWith(document.Root.Elements().Where(e => e.Name.LocalName == "Header").SelectMany(h => h.Descendants()).Where(e => !e.HasElements));
            var formsBefore = document.Root.Elements().Select(e => e.Name.LocalName).ToList();
            // The first pass checks every rule; later passes only the rules affected by the previous one (much quicker).
            evaluator.Solve(specification.Assertions, document, submitted, proposer, onRule: (progress == null) ? (Action<int, int, int>)null : (Action<int, int, int>)((pass, index, count) =>
            {
                if (index % 50 == 0)
                {
                    progress.Report(pass == 0 ? index : count, count, pass == 0
                        ? $"Rule {index + 1:N0} of {count:N0}"
                        : $"Pass {pass + 1}: rechecking rules affected by the values just set");
                }
            }), refresh: refresh);

            // Forms the rules say are not submitted with these Header/approach values have no sample values.
            var formsAfter = document.Root.Elements().Select(e => e.Name.LocalName).ToHashSet(StringComparer.Ordinal);
            var omittedForms = formsBefore.Where(f => !formsAfter.Contains(f)).ToList();

            // Read the solved values back: the first row of every repeating item gives the test values,
            // further rows (added for "one row per code" rules) become sample rows.
            var solved = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var sampleRows = new List<SampleRowDto>();
            foreach (var element in document.Descendants())
            {
                if (!element.HasElements)
                {
                    if (!element.Ancestors().Any(IsAddedRow))
                    {
                        solved.TryAdd(PathOf(element), element.Value);
                    }

                    continue;
                }

                if (IsAddedRow(element) && !element.Ancestors().Any(IsAddedRow))
                {
                    var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    foreach (var leaf in element.Descendants().Where(e => !e.HasElements))
                    {
                        values.TryAdd(PathOf(leaf), leaf.Value);
                    }

                    sampleRows.Add(new SampleRowDto { ItemPath = PathOf(element), Values = values });
                }
            }

            var omitted = omittedForms.ToHashSet(StringComparer.Ordinal);
            var solvedNodes = nodes
                .Select(node =>
                {
                    if (node.DataType == "complex")
                    {
                        return node;
                    }

                    if (omitted.Contains(FormOf(node.Path)))
                    {
                        // Kept: the XML writer leaves the form out, but Excel exports every mapped cell,
                        // so the Excel sample template still needs valid values there.
                        return node;
                    }

                    string value;
                    return solved.TryGetValue(node.Path, out value)
                        && !string.Equals(value, node.TestValue, StringComparison.Ordinal)
                        && XsdValueValidator.IsValid(value, node)
                            ? node.With(copy => { copy.TestValue = value; })
                            : node;
                })
                .ToList();
            return new SolvedSamples(solvedNodes, sampleRows, omittedForms);
        }

        private static void SeedBranches(XDocument document, BankProfileDto bank)
        {
            if (!bank.BranchRegisterComplete) return;
            foreach (var table in document.Root.Elements().Where(e => e.Name.LocalName.StartsWith("BRIS_"))
                .SelectMany(e => e.Descendants()).Where(e => e.Elements().Any(c => c.Name.LocalName.EndsWith("_Item") && c.Elements().Any(f => f.Name.LocalName == "C0030"))).ToList())
            {
                var rows = table.Elements().Where(e => e.Name.LocalName.EndsWith("_Item")).ToList();
                var prototype = rows.First();
                foreach (var branch in bank.Branches)
                {
                    var copy = new XElement(prototype);
                    copy.Elements().First(e => e.Name.LocalName == "C0030").Value = branch.Code;
                    table.Add(copy);
                }
                rows.ForEach(r => r.Remove());
            }
        }

        /// <summary>A repeating item that is not the first of its kind under its parent.</summary>
        private static bool IsAddedRow(XElement element) =>
            element.Name.LocalName.EndsWith("_Item", StringComparison.OrdinalIgnoreCase)
            && element.ElementsBeforeSelf(element.Name).Any();

        /// <summary>
        /// Fields that decide which schedules apply (ISANYOF([Header][Period]; 3; 6; 9; 12), [CAR_Info][MarketRiskApproach]="1"):
        /// each value the rules list is tried and the one with the fewest failed rules is kept (Header fields first).
        /// </summary>
        private List<XElement> ChooseConditionValues(XDocument document, IReadOnlyList<BspAssertion> assertions, ISet<string> submitted,
            Func<XElement, decimal?, string, string> propose, bool periodFixed = false)
        {
            var chosen = new List<XElement>();
            var root = document.Root;
            if (root == null)
            {
                return chosen;
            }

            var candidates = new Dictionary<VT_Form_Field<string, string>, List<string>>();
            Action<string, string, string> AddCandidate = null;
            AddCandidate = (string formArg, string fieldArg, string valueArg) => {
        // The provider code is the bank's; the period is the one BSP's imported result is for.
        if (formArg == "Header" && (fieldArg == "Undertaking" || periodFixed && (fieldArg == "Year" || fieldArg == "Period")))
            return;
        var key = new VT_Form_Field<string, string>(formArg, fieldArg);
        List<string> list;
        if (!candidates.TryGetValue(key, out list))
        {
            list = new List<string>();
            candidates[key] = list;
        }

        var clean = valueArg.Trim().Trim('"');
        if (clean.Length > 0 && !list.Contains(clean))
        {
            list.Add(clean);
        }
    };

            foreach (var assertion in assertions)
            {
                foreach (var text in new[] { assertion.Left, assertion.Right, assertion.Precondition })
                {
                    foreach (Match match in IsAnyOfFieldRegex().Matches(text ?? ""))
                    {
                        foreach (var value in match.Groups["values"].Value.Split(';', StringSplitOptions.RemoveEmptyEntries))
                        {
                            AddCandidate(match.Groups["form"].Value, match.Groups["field"].Value, value);
                        }
                    }

                    foreach (Match match in EqualsFieldRegex().Matches(text ?? ""))
                    {
                        AddCandidate(match.Groups["form"].Value, match.Groups["field"].Value, match.Groups["value"].Value);
                    }
                }
            }

            foreach (var candidate in candidates
                .OrderBy(c => string.Equals(c.Key.Form, "Header", StringComparison.OrdinalIgnoreCase) ? 0 : 1)
                .ThenBy(c => c.Key.Form, StringComparer.Ordinal)
                .ThenBy(c => c.Key.Field, StringComparer.Ordinal))
            {
                var form = candidate.Key.Form;
                var field = candidate.Key.Field;
                var values = candidate.Value;
                var element = root.Elements().FirstOrDefault(e => e.Name.LocalName == form)?
                    .Elements().FirstOrDefault(e => e.Name.LocalName == field && !e.HasElements);
                if (element == null)
                {
                    continue;
                }

                var reference = $"[{form}][{field}]";
                var rules = assertions
                    .Where(a => $"{a.Left} {a.Right} {a.Precondition}".Contains(reference, StringComparison.OrdinalIgnoreCase))
                    .ToList();
                var current = element.Value;
                var best = current;
                var bestScore = Score(rules, document, submitted);
                foreach (var value in values)
                {
                    decimal number;
                    var formatted = decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out number)
                        ? propose(element, number, value)
                        : propose(element, null, value);
                    if (formatted == null || formatted == current)
                    {
                        continue;
                    }

                    element.Value = formatted;
                    var score = Score(rules, document, submitted);
                    if (score.Failed < bestScore.Failed || score.Failed == bestScore.Failed && score.Passed > bestScore.Passed)
                    {
                        best = formatted;
                        bestScore = score;
                    }
                }

                element.Value = best;
                chosen.Add(element);
            }

            return chosen;
        }

        private VT_Failed_Passed<int, int> Score(IReadOnlyList<BspAssertion> rules, XDocument document, ISet<string> submitted)
        {
            var status = evaluator.Evaluate(rules, document, submitted).RuleStatus.Values.ToList();
            return new VT_Failed_Passed<int, int>(status.Count(s => s == BspRuleStatus.Failed), status.Count(s => s == BspRuleStatus.Passed));
        }

        /// <summary>Formats a proposed value like the XSD expects; null when the element's type or facets reject it.</summary>
        private static string Format(SchemaNodeDto node, decimal? number, string text)
        {
            string value;
            switch (node.DataType)
            {
                case "integer":
                    decimal whole;
                    value = CompatPattern.Is(number, out whole) && whole == decimal.Truncate(whole)
                        ? whole.ToString("0", CultureInfo.InvariantCulture)
                        : null;
                    break;
                case "decimal":
                    decimal amount;
                    if (!CompatPattern.Is(number, out amount))
                    {
                        return null;
                    }

                    int digits;
                    value = CompatPattern.Is(node.Validation.FractionDigits, out digits)
                        ? decimal.Round(amount, CompatMath.Clamp(digits, 0, 20), MidpointRounding.AwayFromZero).ToString($"F{CompatMath.Clamp(digits, 0, 20)}", CultureInfo.InvariantCulture)
                        : amount.ToString("0.############################", CultureInfo.InvariantCulture);
                    break;
                case "boolean":
                case "date":
                case "dateTime":
                    value = text;
                    break;
                default:
                    value = text ?? number?.ToString("0.############################", CultureInfo.InvariantCulture);
                    break;
            }

            return value != null && XsdValueValidator.IsValid(value, node) ? value : null;
        }

        private static string FormOf(string path)
        {
            var tokens = path.Split('/', StringSplitOptions.RemoveEmptyEntries);
            return tokens.Length > 1 ? tokens[1] : "";
        }

        private static string PathOf(XElement element) =>
            "/" + string.Join("/", element.AncestorsAndSelf().Reverse().Select(e => e.Name.LocalName));

        private static System.Text.RegularExpressions.Regex IsAnyOfFieldRegex() { return IsAnyOfFieldRegexInstance; }

        private static System.Text.RegularExpressions.Regex EqualsFieldRegex() { return EqualsFieldRegexInstance; }

        private static readonly System.Text.RegularExpressions.Regex IsAnyOfFieldRegexInstance = new System.Text.RegularExpressions.Regex(@"(?<![\]\w$])ISANYOF\(\s*\[(?<form>[A-Za-z0-9_]+)\]\[(?<field>[A-Za-z0-9_]+)\]\s*;(?<values>[^()]*)\)", RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Compiled);

        private static readonly System.Text.RegularExpressions.Regex EqualsFieldRegexInstance = new System.Text.RegularExpressions.Regex(@"(?<![\]\w$])\[(?<form>[A-Za-z0-9_]+)\]\[(?<field>[A-Za-z0-9_]+)\]\s*=\s*(?<value>""[^""]*""|-?[0-9]+(\.[0-9]+)?)", System.Text.RegularExpressions.RegexOptions.None | System.Text.RegularExpressions.RegexOptions.Compiled);
    }

    /// <param name="OmittedForms">Forms left out of the sample because the specification says they are not submitted with the sample's Header values.</param>
    public sealed class SolvedSamples : IRecord<SolvedSamples>, IEquatable<SolvedSamples>
    {
        public IReadOnlyList<SchemaNodeDto> Nodes { get; set; }

        public IReadOnlyList<SampleRowDto> SampleRows { get; set; }

        public IReadOnlyList<string> OmittedForms { get; set; }

        public SolvedSamples(IReadOnlyList<SchemaNodeDto> Nodes, IReadOnlyList<SampleRowDto> SampleRows, IReadOnlyList<string> OmittedForms) { this.Nodes = Nodes; this.SampleRows = SampleRows; this.OmittedForms = OmittedForms; }

        public void Deconstruct(out IReadOnlyList<SchemaNodeDto> Nodes, out IReadOnlyList<SampleRowDto> SampleRows, out IReadOnlyList<string> OmittedForms) { Nodes = this.Nodes; SampleRows = this.SampleRows; OmittedForms = this.OmittedForms; }

        public bool Equals(SolvedSamples other) { if (ReferenceEquals(this, other)) { return true; } if (ReferenceEquals(other, null) || other.GetType() != GetType()) { return false; } return EqualityComparer<IReadOnlyList<SchemaNodeDto>>.Default.Equals(Nodes, other.Nodes) && EqualityComparer<IReadOnlyList<SampleRowDto>>.Default.Equals(SampleRows, other.SampleRows) && EqualityComparer<IReadOnlyList<string>>.Default.Equals(OmittedForms, other.OmittedForms); }

        public override bool Equals(object obj) { return Equals(obj as SolvedSamples); }

        public static bool operator ==(SolvedSamples left, SolvedSamples right) { return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right); }

        public static bool operator !=(SolvedSamples left, SolvedSamples right) { return !(left == right); }

        public override int GetHashCode() { unchecked { var hash = 34256; hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SchemaNodeDto>>.Default.GetHashCode(Nodes); hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<SampleRowDto>>.Default.GetHashCode(SampleRows); hash = hash * -1521134295 + EqualityComparer<IReadOnlyList<string>>.Default.GetHashCode(OmittedForms); return hash; } }

        public override string ToString() { return "SolvedSamples { " + "Nodes = " + Nodes + ", " + "SampleRows = " + SampleRows + ", " + "OmittedForms = " + OmittedForms + " }"; }

        public SolvedSamples CloneRecord() { return (SolvedSamples)MemberwiseClone(); }

    }

    public sealed class DelegateProposer: ISampleValueProposer
    {
        private readonly Func<XElement, decimal?, string, string> propose;
        private readonly Func<XElement, IEnumerable<string>> alternatives;

        public DelegateProposer(Func<XElement, decimal?, string, string> propose, Func<XElement, IEnumerable<string>> alternatives)
    {
        this.propose = propose;
        this.alternatives = alternatives;
    }
        public string Propose(XElement element, decimal? number, string text) => propose(element, number, text);

        public IEnumerable<string> Alternatives(XElement element) => alternatives(element);
    }

}
