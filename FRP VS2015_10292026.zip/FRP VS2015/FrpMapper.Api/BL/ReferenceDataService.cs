﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    public sealed class ReferenceDataService: IReferenceDataService
    {
        private readonly IReferenceDataRepository repository;
        private readonly ProjectAccess projects;
        private readonly ICurrentUser user;
        private readonly SandboxResultReader reader;
        private readonly BspSpecificationReader specifications;
        private readonly OpenXmlWorkbookInspector workbooks;
        private readonly IOptionsMonitor<FileStorageOptions> settings;

        public ReferenceDataService(IReferenceDataRepository repository, ProjectAccess projects, ICurrentUser user, SandboxResultReader reader, BspSpecificationReader specifications, OpenXmlWorkbookInspector workbooks, IOptionsMonitor<FileStorageOptions> settings)
    {
        this.repository = repository;
        this.projects = projects;
        this.user = user;
        this.reader = reader;
        this.specifications = specifications;
        this.workbooks = workbooks;
        this.settings = settings;
    }
        /// <summary>Bank profiles and imports for everyone who reads projects; the change requests only for the Makers and Checkers of bank profiles.</summary>
        public async Task<ReferenceDataDto> ReadAsync(CancellationToken ct)
        {
            var data = await repository.ReadAsync(ct);
            return user.HasPermission(Permissions.ReferenceManage) || user.HasPermission(Permissions.ReferenceApprove) ? data : data.With(copy => { copy.Requests = new List<BankProfileRequestDto>(); });
        }

        /// <summary>
        /// Maker: a change to one bank profile (a new bank, its details or its branch register). It is applied only when a
        /// Checker (reference.approve) who is not the requester approves it. <paramref name="bank"/>.Version is the version
        /// the change was made from (0 for a new bank).
        /// </summary>
        public async Task<BankProfileRequestDto> RequestBankChangeAsync(BankProfileDto bank, CancellationToken ct)
        {
            Demand();
            // An empty BSP API undertaking code is stored as none; digits are kept exactly (leading zeros matter).
            bank = bank.With(copy => { copy.BspUndertakingCode = string.IsNullOrWhiteSpace(bank.BspUndertakingCode) ? null : bank.BspUndertakingCode.Trim(); });
            var data = await repository.ReadAsync(ct);
            var current = data.Banks.SingleOrDefault(b => b.Key == bank.Key);
            Validate(bank, current, data);
            var proposed = bank.With(copy => { copy.Version = (current?.Version ?? 0) + 1; copy.Branches = bank.Branches.Select(b => b.With(inner => { inner.Code = b.Code.Trim(); inner.Region = b.Region.Trim(); inner.Name = BankBranchNames.Short(b.Name, bank.Name); })).ToList(); });
            var changes = BankProfileChanges.Compare(current, proposed);
            if (current != null && changes.Count == 0) throw Invalid("Nothing changes: the bank profile is already exactly like this.");
            var summary = (current == null)
                ? $"New bank {bank.Key} ({bank.Name}), provider code {bank.ProviderCode}, {bank.Branches.Count} branches."
                : string.Join("; ", changes.Select(c => $"{c.Field}: {c.Before} → {c.After}")) + ".";
            var request = new BankProfileRequestDto
            {
                Id = Guid.NewGuid().ToString("N"), BankKey = bank.Key, BaseVersion = current?.Version ?? 0, Proposed = proposed, Before = current,
                Summary = summary.Length > 2000 ? summary.Substring(0, 1997) + "…" : summary, RequestedBy = user.Name, RequestedAt = DateTimeOffset.UtcNow
            };
            try
            {
                return await repository.CreateBankRequestAsync(request, ct);
            }
            catch (AccessRequestOpenException)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, "This bank already has a change waiting for approval. Approve, reject or cancel it first.");
            }
            catch (ConcurrencyConflictException)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, "This bank was changed by someone else. Reload before requesting a change.");
            }
        }

        /// <summary>Checker: approve (apply) or reject a bank profile change (a rejection needs a reason); the requester may cancel it.</summary>
        public async Task<bool> DecideBankChangeAsync(string requestId, string decision, AccessDecisionRequest body, CancellationToken ct)
        {
            if (!(decision == AccessRequestStatus.Approved || decision == AccessRequestStatus.Rejected || decision == AccessRequestStatus.Cancelled))
                throw Invalid("Unknown decision.");
            var data = await repository.ReadAsync(ct);
            var request = data.Requests.FirstOrDefault(r => r.Id == requestId && r.Status == AccessRequestStatus.Pending);
            if (request == null) return false;
            var mine = string.Equals(request.RequestedBy, user.Name, StringComparison.OrdinalIgnoreCase);
            var comment = body.Comment?.Trim();
            if (comment != null && comment.Length > 1000 || (comment?.Any(ch => char.IsControl(ch) && !(ch == '\n') && !(ch == '\r')) ?? false))
                throw Invalid("The comment must be at most 1,000 characters.");
            if (decision == AccessRequestStatus.Cancelled)
            {
                if (!mine || !user.HasPermission(Permissions.ReferenceManage))
                    throw new WorkflowException(WorkflowErrorKind.Forbidden, "Only the person who requested a change can cancel it.");
            }
            else
            {
                if (!user.HasPermission(Permissions.ReferenceApprove))
                    throw new WorkflowException(WorkflowErrorKind.Forbidden, "Only a Checker of bank profiles can approve or reject this change.");
                if (mine)
                    throw new WorkflowException(WorkflowErrorKind.Forbidden, "A Checker other than you must approve or reject your change.");
                if (decision == AccessRequestStatus.Rejected && string.IsNullOrEmpty(comment))
                    throw Invalid("Say why the change is rejected.");
                if (decision == AccessRequestStatus.Approved)
                {
                    try
                    {
                        Validate(request.Proposed, data.Banks.SingleOrDefault(b => b.Key == request.BankKey), data, request.BaseVersion);
                    }
                    catch (WorkflowException ex) when (ex.Kind == WorkflowErrorKind.Invalid)
                    {
                        throw new WorkflowException(WorkflowErrorKind.Conflict, $"This change can no longer be approved: {ex.Message} Reject it instead.");
                    }
                }
            }

            byte[] version;
            try { version = Convert.FromBase64String(body.Version ?? ""); }
            catch (FormatException) { throw Invalid("Reload the page and try again."); }
            if (version.Length != 8) throw Invalid("Reload the page and try again.");
            try
            {
                return await repository.DecideBankRequestAsync(requestId, version, decision, user.Name, DateTimeOffset.UtcNow, string.IsNullOrEmpty(comment) ? null : comment, ct);
            }
            catch (ConcurrencyConflictException)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, "This change or the bank profile was changed by someone else. Reload and try again.");
            }
            catch (AccessDecisionRefusedException ex)
            {
                throw new WorkflowException(WorkflowErrorKind.Forbidden, ex.Message);
            }
        }

        /// <summary>The profile's values, its branches, and that its provider code is not another bank's. <paramref name="baseVersion"/>: the version it must be based on.</summary>
        private static void Validate(BankProfileDto bank, BankProfileDto current, ReferenceDataDto data, long? baseVersion = null)
        {
            if (!Regex.IsMatch(bank.Key ?? "", @"^[A-Z0-9_-]{1,32}$") || !Regex.IsMatch(bank.ProviderCode ?? "", @"^[0-9]{10}$") || string.IsNullOrWhiteSpace(bank.Name) || bank.Name.Length > 200
                || bank.Name.Any(char.IsControl))
                throw Invalid("Use a bank key of up to 32 capital letters/digits, a name and a 10-digit provider code.");
            if (bank.Version < 0 || bank.SubsidiaryCount < 0 || bank.BankGroup?.Length > 32 || bank.ParentBankGroup?.Length > 32) throw Invalid("Invalid bank profile values.");
            ValidateBranches(bank.Branches ?? new List<BankBranchDto>());
            if (data.Banks.Any(b => b.Key != bank.Key && b.ProviderCode == bank.ProviderCode)) throw Invalid("Another bank already uses this provider code.");
            if (bank.BspUndertakingCode != null && !Regex.IsMatch(bank.BspUndertakingCode, @"\A[0-9]{1,20}\z"))
                throw Invalid("Enter the BSP API undertaking code with digits only (up to 20), exactly as BSP issued it, or leave it empty.");
            if (bank.BspUndertakingCode != null && data.Banks.Any(b => b.Key != bank.Key && b.BspUndertakingCode == bank.BspUndertakingCode))
                throw Invalid("Another bank already uses this BSP API undertaking code.");
            var expected = baseVersion ?? bank.Version;
            if ((current?.Version ?? 0) != expected)
                throw new WorkflowException(WorkflowErrorKind.Conflict, "This bank was changed by someone else. Reload before requesting a change.");
        }
        public async Task<IReadOnlyList<BankBranchDto>> ReadBranchesAsync(IFormFile file, CancellationToken ct)
        {
            Demand(); var bytes = await ReadFile(file, new string[] { ".xlsx", ".csv" }, ct);
            var branches = new List<BankBranchDto>();
            if (Path.GetExtension(file.FileName).Equals(".xlsx", StringComparison.OrdinalIgnoreCase))
            {
                var path = Path.Combine(Path.GetTempPath(), Guid.NewGuid()+".xlsx");
                try
                {
                    await CompatFile.WriteAllBytesAsync(path, bytes, ct);
                    var sheet = workbooks.Inspect(path).Sheets.FirstOrDefault() ?? CompatThrow.As<WorkbookSheetDto>(Invalid("The branch workbook is empty."));
                    foreach (var row in sheet.Cells.GroupBy(c => OpenXmlWorkbookInspector.RowNumber(c.Address)).OrderBy(g => g.Key).Skip(1))
                    {
                        Func<int, string> Cell = null;
                        Cell = (int column) =>
                        {
                            return row.FirstOrDefault(c => OpenXmlWorkbookInspector.ColumnIndex(c.Address) == column)?.DisplayValue.Trim() ?? "";
                        };
                        branches.Add(new BankBranchDto() { Code = Cell(1), Region = Cell(2), IsDomestic = Domestic(Cell(3)), Name = Cell(4) });
                    }
                }
                finally { File.Delete(path); }
            }
            else
            {
                foreach (var line in System.Text.Encoding.UTF8.GetString(bytes).Split('\n').Skip(1).Where(l => !string.IsNullOrWhiteSpace(l)))
                {
                    var cells = line.Trim().Split(',');
                    if (cells.Length < 2) throw Invalid("CSV columns must be Code,Region,IsDomestic,Name (IsDomestic true/false and Name are optional).");
                    // The name is the last column and may itself contain commas.
                    branches.Add(new BankBranchDto() { Code = cells[0].Trim(), Region = cells[1].Trim(), IsDomestic = Domestic(cells.Length >= 3 ? cells[2].Trim() : ""),
                        Name = cells.Length >= 4 ? string.Join(",", cells.Skip(3)).Trim().Trim('"').Trim() : "" });
                }
            }
            if (branches.Count == 0) throw Invalid("No branches found. First row must be Code, Region, IsDomestic, Name; values start on row 2.");
            // A file listing a branch more than once (e.g. one row per account) keeps one row per branch; a code listed
            // with different details is refused, naming the code.
            var conflicting = branches.GroupBy(b => BankReferenceContext.Code(b.Code), StringComparer.OrdinalIgnoreCase)
                .Where(g => g.Select(b => $"{b.Region}|{b.IsDomestic}|{System.Text.RegularExpressions.Regex.Replace(b.Name ?? "", @"\s+", " ").Trim()}").Distinct(StringComparer.OrdinalIgnoreCase).Count() > 1)
                .Select(g => g.First().Code).Take(10).ToList();
            if (conflicting.Count > 0) throw Invalid($"These branch codes are listed more than once with different details: {string.Join(", ", conflicting)}.");
            branches = branches.GroupBy(b => BankReferenceContext.Code(b.Code), StringComparer.OrdinalIgnoreCase).Select(g => g.First()).ToList();
            ValidateBranches(branches); return branches;
        }
        public async Task<SandboxImportDto> ImportAsync(string bankKey, string projectId, IFormFile report, IFormFile xml, bool save, CancellationToken ct)
        {
            Demand();
            var data = await repository.ReadAsync(ct);
            var bank = data.Banks.SingleOrDefault(b => b.Key == bankKey) ?? CompatThrow.As<BankProfileDto>(Invalid("Choose a bank profile first."));
            var project = await projects.GetAsync(projectId, ct) ?? CompatThrow.As<FrpProjectDto>(Invalid("Project not found."));
            if (project.SpecificationFile == null) throw Invalid("The project needs its BSP specification to match historical rules.");
            var reportBytes = await ReadFile(report, new string[] { ".txt" }, ct);
            var xmlBytes = await ReadFile(xml, new string[] { ".xml" }, ct);
            SandboxImportDto import;
            try { import = reader.Read(reportBytes, report.FileName, xmlBytes, bank, project, specifications.Read(project.SpecificationFile.StoredPath)); }
            catch (Exception ex) when (!(ex is WorkflowException) && !(ex is OperationCanceledException))
            { throw Invalid("The report or source XML could not be read. Use the text export (.txt) of BSP's sandbox processing result and the XML that was submitted."); }
            if (save) await repository.SaveImportAsync(import, user.Name, ct);
            return import;
        }
        private async Task<byte[]> ReadFile(IFormFile file, string[] extensions, CancellationToken ct)
        {
            var maxBytes = settings.CurrentValue.EffectiveMaxReferenceFileBytes;
            if (file.Length == 0 || file.Length > maxBytes || !extensions.Contains(Path.GetExtension(file.FileName), StringComparer.OrdinalIgnoreCase))
                throw Invalid($"Choose a nonempty {string.Join(" or ", extensions)} file within the configured upload limit (at most {maxBytes / 1000000} MB).");
            using (var output = new MemoryStream())
            {
    await file.CopyToAsync(output, ct); return output.ToArray();
            }
        }
        private static bool Domestic(string value) => CompatFn.Let<string, bool>(value.ToLowerInvariant(), text => (text == "" || text == "true" || text == "yes" || text == "1") ? true : (text == "false" || text == "no" || text == "0") ? false : CompatThrow.As<bool>(Invalid("IsDomestic must be true or false.")));
        private static void ValidateBranches(List<BankBranchDto> branches)
        {
            if (branches.Count > 10000 || branches.Any(b => !Regex.IsMatch(b.Code, @"^[A-Za-z0-9_-]{1,32}$") || !Regex.IsMatch(b.Region, @"^[A-Za-z0-9_-]{1,32}$"))) throw Invalid("Each branch needs a code and region (up to 32 letters/digits); maximum 10,000 branches.");
            if (branches.Select(b => BankReferenceContext.Code(b.Code)).Distinct(StringComparer.OrdinalIgnoreCase).Count() != branches.Count) throw Invalid("Branch codes must be unique.");
            if (branches.Any(b => (b.Name ?? "").Length > 120 || (b.Name ?? "").Any(char.IsControl))) throw Invalid("A branch name can have at most 120 characters, without line breaks.");
        }
        private void Demand() { if (!user.HasPermission(Permissions.ReferenceManage)) throw new WorkflowException(WorkflowErrorKind.Forbidden, "Only a Maker of bank profiles can request bank reference changes or import sandbox results."); }
        private static WorkflowException Invalid(string message) => new WorkflowException(WorkflowErrorKind.Invalid, message);
    }

}
