﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Schema;
using FrpMapper.Api.BL.Cocree;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// COCREE v2.0 for the people who prepare submissions (submission.prepare):
    /// <list type="bullet">
    /// <item>Generate: the BU's input workbooks → CSDF XML files, with the approved configuration (see <see cref="CocreeExporter"/>);</item>
    /// <item>Validate: CSDF files → BSP's Stage 1, preliminary and rule checks and the XSD, with the Workbench's reports
    /// (see <see cref="CocreeValidator"/>);</item>
    /// <item>Header totals: the files of one submission → their record totals written into every file's Header (the
    /// Workbench's Update Header).</item>
    /// </list>
    /// The files are kept a day for the person who made them. Every run is written to the audit trail, with the input
    /// files' names and SHA-256, never their content.
    /// </summary>
    public sealed class CocreeService : ICocreeService
    {
        private const int MaxInputFiles = 50;
        private const int MaxCsdfFiles = CocreeRules.MaxFileNumber * (CocreeRules.MaxProvisionNumber + 1);
        private static readonly object CacheLock = new object();
        private static string cachedHash;
        private static CocreeConfiguration cachedConfiguration;
        private static XmlSchemaSet cachedSchemas;

        private readonly IWorkbenchConfigRepository versions;
        private readonly IReferenceDataRepository references;
        private readonly ICocreeOutputStore outputs;
        private readonly ICurrentUser user;
        private readonly IAuditLog audit;
        private readonly IOptionsMonitor<FileStorageOptions> storage;

        public CocreeService(IWorkbenchConfigRepository versions, IReferenceDataRepository references, ICocreeOutputStore outputs, ICurrentUser user, IAuditLog audit,
            IOptionsMonitor<FileStorageOptions> storage)
        {
            this.versions = versions;
            this.references = references;
            this.outputs = outputs;
            this.user = user;
            this.audit = audit;
            this.storage = storage;
        }

        private static WorkflowException Invalid(string message) { return new WorkflowException(WorkflowErrorKind.Invalid, message); }

        private void Authorize()
        {
            if (!user.IsAuthenticated || !user.HasPermission(Permissions.SubmissionPrepare))
                throw new WorkflowException(WorkflowErrorKind.Forbidden, "Your role cannot generate COCREE files.");
        }

        // ---------- setup ----------

        public async Task<CocreeSetupDto> SetupAsync(CancellationToken cancellation)
        {
            Authorize();
            var setup = new CocreeSetupDto
            {
                Providers = await ProvidersAsync(cancellation),
                SubmissionTypes = CocreeRules.SubmissionTypes.ToList(),
                BspRecordsPerFile = CocreeRules.BspRecordsPerFile,
                MaxRecordsPerFile = CocreeRules.MaxRecordsPerFile,
                MaxUploadBytes = storage.CurrentValue.MaxUploadBytes
            };

            var active = await versions.GetActiveAsync(WorkbenchConfigKind.Cocree, cancellation);
            if (active == null)
            {
                return setup;
            }

            var configuration = Configuration(active);
            setup.Configured = true;
            setup.Configuration = active.Version;
            setup.ValidationRules = configuration.ValidationRules.Count;
            setup.XsdFileName = configuration.XsdFileName;
            setup.InputFiles = configuration.InputFiles.Select(f => new CocreeInputFileDto
            {
                Name = f.Name,
                SubjectHierarchy = f.SubjectHierarchy,
                Sheets = configuration.Sheets.Where(s => s.FileId == f.Id).Select(s => s.Name).ToList()
            }).ToList();
            return setup;
        }

        /// <summary>The provider codes of the approved bank profiles (the Workbench had UNI's and RB's written in its code).</summary>
        private async Task<List<CocreeProviderDto>> ProvidersAsync(CancellationToken cancellation)
        {
            var banks = (await references.ReadAsync(cancellation)).Banks;
            return banks.Where(b => Regex.IsMatch(b.ProviderCode ?? "", @"\A\d{10}\z"))
                .Select(b => new CocreeProviderDto { Code = b.ProviderCode, BankKey = b.Key, BankName = b.Name })
                .OrderBy(p => p.BankKey, StringComparer.OrdinalIgnoreCase).ToList();
        }

        /// <summary>The configuration of a stored version, read once per content (it is large and changes rarely).</summary>
        private static CocreeConfiguration Configuration(StoredWorkbenchConfig stored)
        {
            lock (CacheLock)
            {
                if (cachedHash == stored.Version.ContentHash && cachedConfiguration != null)
                {
                    return cachedConfiguration;
                }
            }

            var problems = new List<string>();
            var configuration = CocreeConfiguration.Load(JsonSerializer.Deserialize<CocreeConfigDto>(stored.Content), problems, new List<string>());
            if (configuration == null)
            {
                // Checked on upload, so this means the rules of this version of FRP Mapper are stricter than the old one's.
                throw new WorkflowException(WorkflowErrorKind.Conflict, "The approved COCREE configuration cannot be used: " + string.Join(" ", problems.Take(5))
                    + " Ask a Maker to upload a corrected one.");
            }

            lock (CacheLock)
            {
                cachedHash = stored.Version.ContentHash;
                cachedConfiguration = configuration;
                cachedSchemas = configuration.Xsd.Length > 0 ? XmlSchemaChecker.Load(configuration.Xsd) : null;
            }

            return configuration;
        }

        /// <summary>The compiled XSD of the configuration last read (null when it has none).</summary>
        private static XmlSchemaSet Schemas(StoredWorkbenchConfig stored)
        {
            Configuration(stored);
            lock (CacheLock)
            {
                return cachedSchemas;
            }
        }

        // ---------- generate XML ----------

        public async Task<CocreeExportResultDto> ExportAsync(CocreeExportRequest request, CancellationToken cancellation, IProgress<ValidationProgressDto> progress = null)
        {
            Authorize();
            var providers = await ProvidersAsync(cancellation);
            var parameters = Parameters(request, providers);
            var files = request.Files ?? new List<IFormFile>();
            if (files.Count == 0) throw Invalid("Choose the COCREE input workbooks.");
            if (files.Count > MaxInputFiles) throw Invalid("Choose at most " + MaxInputFiles + " input workbooks at a time.");
            foreach (var file in files)
            {
                if (!string.Equals(Path.GetExtension(file.FileName), ".xlsx", StringComparison.OrdinalIgnoreCase))
                    throw Invalid(file.FileName + " is not an Excel .xlsx workbook (a .xlsb or .xls must be saved as .xlsx first).");
                if (file.Length > storage.CurrentValue.MaxUploadBytes)
                    throw Invalid(file.FileName + " is larger than " + storage.CurrentValue.MaxUploadMegabytes + " MB.");
            }

            var active = await versions.GetActiveAsync(WorkbenchConfigKind.Cocree, cancellation);
            if (active == null)
                throw new WorkflowException(WorkflowErrorKind.Conflict, "No COCREE configuration has been approved yet. A Maker uploads it on the Settings tab and a Checker approves it.");
            var configuration = Configuration(active);

            var run = outputs.CreateRun(user.Name);
            var inputs = files.Select(f => new CocreeInput(f.FileName, f.OpenReadStream)).ToList();
            Action<string, int> report = (stage, percent) =>
            {
                if (progress != null) progress.Report(new ValidationProgressDto { Percent = percent, Stage = stage });
            };
            var result = await Task.Run(() => new CocreeExporter(configuration, parameters, report).Run(inputs, run), cancellation);
            result.ConfigurationId = active.Version.Id;
            result.OutputId = result.Files.Count > 0 || result.ErrorReport != null ? run.Id : "";

            await audit.AppendAsync(new AuditEntryDto
            {
                Id = Guid.NewGuid().ToString("N"), At = DateTimeOffset.UtcNow, User = user.Name,
                Action = result.Succeeded ? "COCREE XML generated" : "COCREE XML not generated",
                Details = "Provider " + parameters.ProviderCode + ", reference date " + parameters.ReferenceDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)
                    + ", submission type " + parameters.SubmissionType + ", configuration " + active.Version.Id + ". Input: "
                    + string.Join("; ", files.Select(f => f.FileName + " (SHA-256 " + Sha256(f) + ")")) + ". "
                    + (result.Succeeded
                        ? "Files: " + string.Join(", ", result.Files.Select(f => f.Name)) + "; " + result.Subjects + " subjects, " + result.Contracts + " contracts, "
                            + result.NegativeEvents + " negative events."
                        : result.Issues.Count(i => i.Severity == CocreeRules.Error) + " errors" + (result.ErrorReport != null ? "; error report " + result.ErrorReport : "") + ".")
            }, cancellation);
            return result;
        }

        /// <summary>Checks what the person chose and turns it into the export's parameters.</summary>
        private static CocreeExportParameters Parameters(CocreeExportRequest request, List<CocreeProviderDto> providers)
        {
            var provider = (request.ProviderCode ?? "").Trim();
            if (!providers.Any(p => p.Code == provider))
                throw Invalid("Choose the provider code of an approved bank profile.");

            DateTime date;
            if (!DateTime.TryParseExact((request.ReferenceDate ?? "").Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                throw Invalid("Choose the file reference date.");
            if (date.Date > DateTime.Today)
                throw Invalid("30-007: the file reference date cannot be in the future.");

            var type = (request.SubmissionType ?? "").Trim();
            if (!CocreeRules.SubmissionTypes.Contains(type))
                throw Invalid("Choose the submission type (" + string.Join(" or ", CocreeRules.SubmissionTypes) + ").");

            var version = (request.Version ?? "").Trim();
            if (version.Length == 0 || version.Length > 10 || !Regex.IsMatch(version, @"\A[0-9A-Za-z.]+\z"))
                throw Invalid("Enter the version, e.g. 1.0.");

            var comments = (request.ProviderComments ?? "").Trim();
            if (comments.Length > 500 || !CocreeRules.IsXmlText(comments))
                throw Invalid("The provider comments must be at most 500 characters.");

            int max;
            if (!int.TryParse((request.MaxRecordsPerFile ?? "").Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out max) || max < 1 || max > CocreeRules.MaxRecordsPerFile)
                throw Invalid("Records per file must be a whole number from 1 to " + CocreeRules.MaxRecordsPerFile.ToString("N0", CultureInfo.InvariantCulture) + ".");

            return new CocreeExportParameters
            {
                ProviderCode = provider, ReferenceDate = date, SubmissionType = type, Version = version, ProviderComments = comments, MaxRecordsPerFile = max
            };
        }

        // ---------- validate ----------

        public async Task<CocreeValidationResultDto> ValidateAsync(CocreeValidateRequest request, CancellationToken cancellation, IProgress<ValidationProgressDto> progress = null)
        {
            Authorize();
            var active = await versions.GetActiveAsync(WorkbenchConfigKind.Cocree, cancellation);
            if (active == null)
                throw new WorkflowException(WorkflowErrorKind.Conflict, "No COCREE configuration has been approved yet. A Maker uploads it on the Settings tab and a Checker approves it.");
            var configuration = Configuration(active);
            if (configuration.ValidationRules.Count == 0)
                throw new WorkflowException(WorkflowErrorKind.Conflict, "The approved COCREE configuration has no validation rules. A Maker uploads it again with cocree_validations.xlsx.");

            // The files: uploaded, or the XML files of one of the person's Generate runs.
            var files = new List<KeyValuePair<string, Func<byte[]>>>();
            if (!string.IsNullOrEmpty(request.RunId))
            {
                foreach (var name in outputs.Files(request.RunId, user.Name).Where(n => n.EndsWith(".xml", StringComparison.OrdinalIgnoreCase) && n.Contains("_CSDF_")))
                {
                    var file = name;
                    files.Add(new KeyValuePair<string, Func<byte[]>>(file, () => ReadAll(outputs.Open(request.RunId, file, user.Name))));
                }

                if (files.Count == 0) throw Invalid("The generated files are no longer available (they are kept a day). Generate them again or upload them.");
            }
            else
            {
                var uploads = request.Files ?? new List<IFormFile>();
                if (uploads.Count == 0) throw Invalid("Choose the CSDF XML files to validate.");
                if (uploads.Count > MaxCsdfFiles) throw Invalid("Choose at most " + MaxCsdfFiles + " files.");
                if (uploads.Select(f => f.FileName).Distinct(StringComparer.OrdinalIgnoreCase).Count() != uploads.Count) throw Invalid("Two of the files have the same name.");
                foreach (var upload in uploads)
                {
                    if (!string.Equals(Path.GetExtension(upload.FileName), ".xml", StringComparison.OrdinalIgnoreCase))
                        throw Invalid(upload.FileName + " is not an XML file.");
                    if (upload.Length > storage.CurrentValue.MaxUploadBytes)
                        throw Invalid(upload.FileName + " is larger than " + storage.CurrentValue.MaxUploadMegabytes + " MB.");
                    var file = upload;
                    files.Add(new KeyValuePair<string, Func<byte[]>>(Path.GetFileName(file.FileName), () => ReadAll(file.OpenReadStream())));
                }
            }

            var providers = (await ProvidersAsync(cancellation)).Select(p => p.Code).ToList();
            var schemas = Schemas(active);
            var run = outputs.CreateRun(user.Name);
            var result = new CocreeValidationResultDto { ConfigurationId = active.Version.Id, XsdChecked = schemas != null, OutputId = run.Id };
            var hashes = new List<string>();
            await Task.Run(() =>
            {
                var validator = new CocreeValidator(configuration, schemas, providers, DateTime.Today);
                for (var i = 0; i < files.Count; i++)
                {
                    cancellation.ThrowIfCancellationRequested();
                    var index = i;
                    var content = files[i].Value();
                    hashes.Add(files[i].Key + " (SHA-256 " + WorkbenchConfigWorkflow.Sha256(content) + ")");
                    Action<string> stage = text =>
                    {
                        if (progress != null) progress.Report(new ValidationProgressDto { Percent = 100 * index / files.Count, Stage = text, Detail = "File " + (index + 1) + " of " + files.Count });
                    };
                    result.Files.Add(validator.Validate(files[i].Key, content, (name, write) =>
                    {
                        using (var stream = run.Create(name))
                        {
                            write(stream);
                        }
                    }, stage));
                }
            }, cancellation);

            result.Succeeded = result.Files.All(f => f.Outcome == "Passed");
            await audit.AppendAsync(new AuditEntryDto
            {
                Id = Guid.NewGuid().ToString("N"), At = DateTimeOffset.UtcNow, User = user.Name, Action = "COCREE XML validated",
                Details = "Configuration " + active.Version.Id + (schemas != null ? " with XSD " + configuration.XsdFileName : " (no XSD)") + ". "
                    + string.Join("; ", result.Files.Select((f, i) => hashes[i] + ": " + f.Outcome + (f.Stage.Length > 0 ? " at " + f.Stage : "")
                        + (f.RecordErrors > 0 ? ", " + f.RecordErrors + " rule errors" : "") + (f.XsdValid == false ? ", XSD errors" : ""))) + "."
            }, cancellation);
            return result;
        }

        private static byte[] ReadAll(Stream stream)
        {
            using (stream)
            using (var copy = new MemoryStream())
            {
                stream.CopyTo(copy);
                return copy.ToArray();
            }
        }

        // ---------- header totals ----------

        public async Task<CocreeHeaderTotalsResultDto> HeaderTotalsAsync(List<IFormFile> files, string referenceDate, bool apply, CancellationToken cancellation)
        {
            Authorize();
            files = files ?? new List<IFormFile>();
            if (files.Count == 0) throw Invalid("Choose the CSDF XML files of the submission.");
            if (files.Count > MaxCsdfFiles) throw Invalid("Choose at most " + MaxCsdfFiles + " files.");
            DateTime date;
            if (!DateTime.TryParseExact((referenceDate ?? "").Trim(), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                throw Invalid("Choose the file reference date.");
            foreach (var file in files)
            {
                if (!string.Equals(Path.GetExtension(file.FileName), ".xml", StringComparison.OrdinalIgnoreCase))
                    throw Invalid(file.FileName + " is not an XML file.");
                if (file.Length > storage.CurrentValue.MaxUploadBytes)
                    throw Invalid(file.FileName + " is larger than " + storage.CurrentValue.MaxUploadMegabytes + " MB.");
            }

            if (files.Select(f => f.FileName).Distinct(StringComparer.OrdinalIgnoreCase).Count() != files.Count)
                throw Invalid("Two of the files have the same name.");

            var providers = (await ProvidersAsync(cancellation)).Select(p => p.Code).ToList();
            var result = new CocreeHeaderTotalsResultDto();
            var read = new List<CocreeRules.CsdfFile>();
            await Task.Run(() =>
            {
                foreach (var file in files.OrderBy(f => f.FileName, StringComparer.Ordinal))
                {
                    byte[] content;
                    using (var stream = file.OpenReadStream())
                    using (var copy = new MemoryStream())
                    {
                        stream.CopyTo(copy);
                        content = copy.ToArray();
                    }

                    var csdf = CocreeRules.ReadCsdf(file.FileName, content, date);
                    csdf.Issues.AddRange(CocreeRules.CheckFileName(file.FileName, providers, DateTime.Today));
                    read.Add(csdf);
                    result.Issues.AddRange(csdf.Issues);
                    result.Files.Add(new CocreeOutputFileDto
                    {
                        Name = file.FileName, Size = content.Length, Subjects = csdf.Subjects, Contracts = csdf.Contracts, NegativeEvents = csdf.NegativeEvents,
                        Records = csdf.Subjects + csdf.Contracts + csdf.NegativeEvents, Elements = csdf.Elements
                    });
                }
            }, cancellation);

            result.Subjects = read.Sum(f => f.Subjects);
            result.Contracts = read.Sum(f => f.Contracts);
            result.NegativeEvents = read.Sum(f => f.NegativeEvents);
            result.Succeeded = result.Issues.All(i => i.Severity != CocreeRules.Error);
            if (!apply || !result.Succeeded)
            {
                return result;
            }

            // Every file's Header gets the submission's totals (the files are otherwise unchanged).
            var run = outputs.CreateRun(user.Name);
            foreach (var csdf in read)
            {
                using (var output = run.Create(csdf.Name))
                {
                    CocreeRules.WriteTotals(csdf.Document, result.Subjects, result.Contracts, result.NegativeEvents, output);
                }
            }

            result.OutputId = run.Id;
            await audit.AppendAsync(new AuditEntryDto
            {
                Id = Guid.NewGuid().ToString("N"), At = DateTimeOffset.UtcNow, User = user.Name, Action = "COCREE header totals written",
                Details = "Reference date " + date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) + "; " + result.Subjects + " subjects, " + result.Contracts
                    + " contracts, " + result.NegativeEvents + " negative events written into the Header of: "
                    + string.Join(", ", files.Select(f => f.FileName + " (SHA-256 " + Sha256(f) + ")")) + "."
            }, cancellation);
            return result;
        }

        // ---------- downloads ----------

        public ToolDownload Download(string runId, string fileName)
        {
            Authorize();
            if (fileName == "all.zip")
            {
                // Every file of the run (a Validate run's reports are all of it; a Generate run's error report is left out).
                var names = outputs.Files(runId, user.Name).ToList();
                if (names.Any(n => n.Contains("_CSDF_") && !n.Contains("_Validation_Result_")))
                {
                    names = names.Where(n => !n.StartsWith("Export_to_XML_Result_", StringComparison.Ordinal)).ToList();
                }

                if (names.Count == 0) return null;
                var zip = new MemoryStream();
                using (var archive = new ZipArchive(zip, ZipArchiveMode.Create, true))
                {
                    foreach (var name in names)
                    {
                        using (var source = outputs.Open(runId, name, user.Name))
                        using (var target = archive.CreateEntry(name, CompressionLevel.Optimal).Open())
                        {
                            source.CopyTo(target);
                        }
                    }
                }

                zip.Position = 0;
                return new ToolDownload(zip, "COCREE_" + names[0].Split('_')[0] + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture) + ".zip",
                    "application/zip");
            }

            var stream = outputs.Open(runId, fileName, user.Name);
            var type = fileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase) ? "text/csv" : "application/xml";
            return stream == null ? null : new ToolDownload(stream, fileName, type);
        }

        private static string Sha256(IFormFile file)
        {
            using (var stream = file.OpenReadStream())
            using (var sha = SHA256.Create())
            {
                return string.Concat(sha.ComputeHash(stream).Select(b => b.ToString("x2")));
            }
        }
    }
}
