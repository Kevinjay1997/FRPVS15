using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    /// <summary>
    /// BSP environments follow Maker / Checker like bank profiles and their certificates: a Maker (reference.manage) proposes
    /// an environment or a change as Pending; a Checker (reference.approve) who is not the Maker approves it, which makes it
    /// the Active version used by BSP submission. The proposer may cancel it; a Checker may reject it or remove the Active one.
    /// Hosts come from the API's Bsp:AllowedHosts only. Every step is written to the audit trail by the stored procedures.
    /// </summary>
    public sealed class SubmissionEnvironmentService : ISubmissionEnvironmentService
    {
        private readonly ISubmissionEnvironmentRepository environments;
        private readonly ICurrentUser user;
        private readonly BspOptions options;

        public SubmissionEnvironmentService(ISubmissionEnvironmentRepository environments, ICurrentUser user, IOptions<BspOptions> options)
        {
            this.environments = environments;
            this.user = user;
            this.options = options.Value;
        }

        private static WorkflowException Invalid(string message) { return new WorkflowException(WorkflowErrorKind.Invalid, message); }

        private static WorkflowException Forbidden(string message) { return new WorkflowException(WorkflowErrorKind.Forbidden, message); }

        public async Task<SubmissionSettingsDto> ListAsync(CancellationToken cancellation)
        {
            if (!user.IsAuthenticated || (!user.HasPermission(Permissions.ReferenceManage) && !user.HasPermission(Permissions.ReferenceApprove)))
                throw Forbidden("Only the Makers and Checkers of bank profiles can see the BSP environment settings.");
            return new SubmissionSettingsDto
            {
                Environments = (await environments.ListAsync(cancellation)).ToList(),
                AllowedHosts = options.AllowedHosts.ToList()
            };
        }

        public async Task<SubmissionEnvironmentDto> RequestAsync(SubmissionEnvironmentRequest request, CancellationToken cancellation)
        {
            if (!user.IsAuthenticated || !user.HasPermission(Permissions.ReferenceManage))
                throw Forbidden("Only a Maker of bank profiles can propose a BSP environment.");
            var environment = BspEndpointRules.Normalize(request, options.AllowedHosts);
            var current = (await environments.ListAsync(cancellation)).ToList();
            var active = current.FirstOrDefault(e => e.Key == environment.Key && e.Status == SubmissionEnvironmentStatus.Active);
            if (active != null && SameSettings(active, environment))
                throw Invalid("Nothing changed: " + environment.Key + " already has these settings.");
            if (current.Any(e => e.Status == SubmissionEnvironmentStatus.Active && e.Key != environment.Key
                    && string.Equals(e.Name, environment.Name, StringComparison.OrdinalIgnoreCase)))
                throw Invalid("Another environment is already called " + environment.Name + ". Choose another name.");

            environment.Id = Guid.NewGuid().ToString("N");
            environment.RequestedBy = user.Name;
            environment.RequestedAt = DateTimeOffset.UtcNow;
            try
            {
                return await environments.RequestAsync(environment, cancellation);
            }
            catch (AccessRequestOpenException)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, environment.Key + " already has a change waiting for approval. Approve, reject or cancel it first.");
            }
        }

        public async Task<bool> DecideAsync(string environmentId, string decision, AccessDecisionRequest body, CancellationToken cancellation)
        {
            string status;
            switch (decision)
            {
                case "approve": status = "Approved"; break;
                case "reject": status = "Rejected"; break;
                case "cancel": status = "Cancelled"; break;
                case "remove": status = "Removed"; break;
                default: throw Invalid("Unknown decision.");
            }

            if (!Regex.IsMatch(environmentId ?? "", @"\A[0-9a-f]{32}\z")) return false;
            body = body ?? new AccessDecisionRequest();
            var comment = body.Comment == null ? null : body.Comment.Trim();
            if (comment != null && (comment.Length > 1000 || comment.Any(ch => char.IsControl(ch) && ch != '\n' && ch != '\r')))
                throw Invalid("The comment must be at most 1,000 characters.");
            if (comment == "") comment = null;

            var environment = (await environments.ListAsync(cancellation)).FirstOrDefault(e => e.Id == environmentId);
            if (environment == null) return false;
            var mine = string.Equals(environment.RequestedBy, user.Name, StringComparison.OrdinalIgnoreCase);
            if (status == "Cancelled")
            {
                if (!mine || !user.HasPermission(Permissions.ReferenceManage))
                    throw Forbidden("Only the person who proposed a change can cancel it.");
            }
            else
            {
                if (!user.HasPermission(Permissions.ReferenceApprove))
                    throw Forbidden("Only a Checker of bank profiles can approve, reject or remove a BSP environment.");
                if (status != "Removed" && mine)
                    throw Forbidden("A Checker other than you must approve or reject the change you proposed.");
                if ((status == "Rejected" || status == "Removed") && comment == null)
                    throw Invalid(status == "Rejected" ? "Say why the change is rejected." : "Say why the environment is removed.");
                if (status == "Approved")
                {
                    // Checked again: the server's allowed hosts may have changed since it was proposed.
                    try { BspEndpointRules.NormalizeBaseUrl(environment.BaseUrl, options.AllowedHosts); }
                    catch (WorkflowException ex) { throw new WorkflowException(WorkflowErrorKind.Conflict, ex.Message + " Reject this change instead."); }
                }
            }

            byte[] version;
            try { version = Convert.FromBase64String(body.Version ?? ""); }
            catch (FormatException) { throw Invalid("Reload the page and try again."); }
            if (version.Length != 8) throw Invalid("Reload the page and try again.");
            try
            {
                return await environments.DecideAsync(environmentId, version, status, user.Name, DateTimeOffset.UtcNow, comment, cancellation);
            }
            catch (ConcurrencyConflictException)
            {
                throw new WorkflowException(WorkflowErrorKind.Conflict, "This environment was decided or changed by someone else. Reload and try again.");
            }
            catch (AccessDecisionRefusedException ex)
            {
                throw Forbidden(ex.Message);
            }
        }

        private static bool SameSettings(SubmissionEnvironmentDto a, SubmissionEnvironmentDto b)
        {
            return a.Name == b.Name && a.Kind == b.Kind && a.BaseUrl == b.BaseUrl && a.SubmitPath == b.SubmitPath && a.StatusPath == b.StatusPath
                && a.ResultPdfPath == b.ResultPdfPath && a.ResultXmlPath == b.ResultXmlPath && a.ResultExcelPath == b.ResultExcelPath
                && a.ReceiptPath == b.ReceiptPath && a.SortOrder == b.SortOrder;
        }
    }
}
