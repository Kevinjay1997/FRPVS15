﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.BL
{
    public sealed partial class OpenXmlMappedTemplateWriter
    {
        /// <summary>
        /// Removes every XML map binding of the given forms (the template's own and none added by the export):
        /// single-cell bindings are dropped (an emptied single-cells part is removed) and XML list tables become
        /// plain Excel tables. Excel's XML export then leaves these forms out, which it otherwise cannot do,
        /// because it writes an element for every mapped cell, even a blank one.
        /// </summary>
        private static void UnbindForms(ZipArchive archive, FrpProjectDto project, IReadOnlyCollection<string> forms)
        {
            UnbindPaths(archive, forms.Select(f => $"/{project.RootElement}/{f}/").ToList());
        }

        /// <summary>Removes every XML map binding of the elements under <paramref name="prefixes"/> (paths ending with "/"), as <see cref="UnbindForms"/>.</summary>
        private static void UnbindPaths(ZipArchive archive, IReadOnlyList<string> prefixes)
        {
            if (prefixes.Count == 0)
            {
                return;
            }
            Func<string, bool> InForm = null;
            InForm = (string xpath) =>
            {
                string path;
                return CompatPattern.Is(SchemaPathOf(xpath), out path) && prefixes.Any(p => path.StartsWith(p, StringComparison.Ordinal));
            };

            foreach (var sheet in ReadSheets(archive))
            {
                var directory = Path.GetDirectoryName(sheet.WorksheetPath)?.Replace('\\', '/') ?? "xl/worksheets";
                var relsPath = $"{directory}/_rels/{Path.GetFileName(sheet.WorksheetPath)}.rels";
                var rels = ReadXml(archive, relsPath);
                var relsChanged = false;
                foreach (var relationship in rels?.Root?.Elements(PackageRel + "Relationship").ToList() ?? new List<XElement>())
                {
                    var type = (string)relationship.Attribute("Type") ?? "";
                    var target = (string)relationship.Attribute("Target");
                    if (target == null)
                    {
                        continue;
                    }

                    var partPath = NormalizePartPath(directory, target);
                    if (type.EndsWith("/tableSingleCells", StringComparison.OrdinalIgnoreCase))
                    {
                        var part = ReadXml(archive, partPath);
                        var cells = part?.Root?.Elements(Main + "singleXmlCell").ToList() ?? new List<XElement>();
                        var removed = cells.Where(c => InForm((string)c.Descendants(Main + "xmlPr").FirstOrDefault()?.Attribute("xpath"))).ToList();
                        if (removed.Count == 0)
                        {
                            continue;
                        }

                        if (removed.Count == cells.Count)
                        {
                            // singleXmlCells needs at least one cell: drop the part and its relationship.
                            archive.GetEntry(partPath)?.Delete();
                            RemoveContentTypeOverride(archive, "/" + partPath);
                            relationship.Remove();
                            relsChanged = true;
                        }
                        else
                        {
                            removed.ForEach(c => c.Remove());
                            UpsertEntry(archive, partPath, part.ToString(SaveOptions.DisableFormatting));
                        }
                    }
                    else if (type.EndsWith("/table", StringComparison.OrdinalIgnoreCase))
                    {
                        var table = ReadXml(archive, partPath);
                        var root = table?.Root;
                        var columns = root?.Descendants(Main + "xmlColumnPr").ToList() ?? new List<XElement>();
                        if (root == null || (string)root.Attribute("tableType") != "xml" || columns.Count == 0
                            || !columns.All(c => InForm((string)c.Attribute("xpath"))))
                        {
                            continue;
                        }

                        root.Attribute("tableType")?.Remove();
                        columns.ForEach(c => c.Remove());
                        UpsertEntry(archive, partPath, table.ToString(SaveOptions.DisableFormatting));
                    }
                }

                if (relsChanged)
                {
                    UpsertEntry(archive, relsPath, rels.ToString(SaveOptions.DisableFormatting));
                }
            }
        }

        private static void RemoveContentTypeOverride(ZipArchive archive, string partName)
        {
            const string path = "[Content_Types].xml";
            var document = ReadXml(archive, path);
            var overrides = document?.Root?.Elements(ContentTypes + "Override")
                .Where(e => string.Equals((string)e.Attribute("PartName"), partName, StringComparison.OrdinalIgnoreCase))
                .ToList() ?? new List<XElement>();
            if (overrides.Count > 0)
            {
                overrides.ForEach(e => e.Remove());
                UpsertEntry(archive, path, document.ToString(SaveOptions.DisableFormatting));
            }
        }
    }

}
