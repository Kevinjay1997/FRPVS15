﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL.Sql;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.DAL
{
    /// <summary>Projects in SQL Server through the frp.usp_Project_* stored procedures (Dapper).</summary>
    public sealed class SqlProjectRepository: IProjectRepository
    {
        private readonly ISqlConnectionFactory connections;
        private readonly IProjectFileStore files;

        public SqlProjectRepository(ISqlConnectionFactory connections, IProjectFileStore files)
    {
        this.connections = connections;
        this.files = files;
    }
        private const string FileRoleXsd = "Xsd";
        private const string FileRoleTemplate = "Template";
        private const string FileRoleSpecification = "Specification";
        private const string WorkbookRoleTemplate = "Template";
        private const string WorkbookRoleSpecification = "Specification";
        private const string IssueSetProject = "Project";
        private const string IssueSetValidation = "Validation";

        private static readonly ConcurrentDictionary<string, SemaphoreSlim> Locks = new ConcurrentDictionary<string, SemaphoreSlim>(StringComparer.Ordinal);

        public async Task<FrpProjectDto> CreateAsync(FrpProjectDto project, CancellationToken cancellationToken)
        {
            RequireValidId(project.Id);
            var workflow = project.Workflow;
            var parameters = new DynamicParameters();
            parameters.Add("@ProjectId", project.Id, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@Name", project.Name);
            parameters.Add("@CreatedAt", project.CreatedAt);
            parameters.Add("@UpdatedAt", project.UpdatedAt);
            parameters.Add("@TemplateGenerated", project.TemplateGenerated);
            parameters.Add("@TargetNamespace", project.TargetNamespace);
            parameters.Add("@RootElement", project.RootElement);
            AddWorkflow(parameters, workflow);
            parameters.Add("@Files", FilesTable(project).AsTableValuedParameter("frp.ProjectFileTableType"));
            parameters.Add("@Submission", SubmissionTable(workflow.Submission).AsTableValuedParameter("frp.ProjectSubmissionTableType"));
            parameters.Add("@Contributors", ContributorsTable(workflow.Contributors).AsTableValuedParameter("frp.ContributorTableType"));
            parameters.Add("@Validation", ValidationTable(project.Validation).AsTableValuedParameter("frp.ProjectValidationTableType"));
            parameters.Add("@Issues", IssuesTable(project).AsTableValuedParameter("frp.ProjectIssueTableType"));
            parameters.Add("@SchemaNodes", SchemaNodesTable(project.SchemaNodes).AsTableValuedParameter("frp.SchemaNodeTableType"));
            parameters.Add("@SchemaNodeEnumerations", EnumerationsTable(project.SchemaNodes).AsTableValuedParameter("frp.SchemaNodeEnumerationTableType"));
            var workbooks = Workbooks(project);
            parameters.Add("@Workbooks", WorkbooksTable(workbooks).AsTableValuedParameter("frp.WorkbookTableType"));
            parameters.Add("@WorkbookSheets", SheetsTable(workbooks).AsTableValuedParameter("frp.WorkbookSheetTableType"));
            parameters.Add("@WorkbookCells", CellsTable(workbooks).AsTableValuedParameter("frp.WorkbookCellTableType"));
            parameters.Add("@WorkbookXmlMappings", XmlMappingsTable(workbooks).AsTableValuedParameter("frp.WorkbookXmlMappingTableType"));
            parameters.Add("@Mappings", MappingsTable(project.Mappings).AsTableValuedParameter("frp.MappingTableType"));
            parameters.Add("@SampleRows", SampleRowsTable(project.SampleRows).AsTableValuedParameter("frp.SampleRowTableType"));
            parameters.Add("@SampleRowValues", SampleRowValuesTable(project.SampleRows).AsTableValuedParameter("frp.SampleRowValueTableType"));
            parameters.Add("@SampleOmittedForms", OmittedFormsTable(project.SampleOmittedForms).AsTableValuedParameter("frp.SampleOmittedFormTableType"));

            var version = await ExecuteForVersionAsync("frp.usp_Project_Create", parameters, cancellationToken);
            return project.With(copy => { copy.Version = version; });
        }

        public Task<FrpProjectDto> SaveWorkflowAsync(FrpProjectDto project, CancellationToken cancellationToken) =>
            UpdateAsync(project, false, cancellationToken);

        public Task<FrpProjectDto> SaveMappingsAsync(FrpProjectDto project, CancellationToken cancellationToken) =>
            UpdateAsync(project, true, cancellationToken);

        public Task<FrpProjectDto> SaveSampleValuesAsync(FrpProjectDto project, CancellationToken cancellationToken) =>
            UpdateAsync(project, true, cancellationToken, saveSampleValues: true);

        public Task<FrpProjectDto> SaveSheetSplitsAsync(FrpProjectDto project, CancellationToken cancellationToken) =>
            UpdateAsync(project, true, cancellationToken, saveSheetSplits: true);

        private async Task<FrpProjectDto> UpdateAsync(FrpProjectDto project, bool replaceMappingsAndValidation, CancellationToken cancellationToken,
            bool saveSampleValues = false, bool saveSheetSplits = false)
        {
            RequireValidId(project.Id);
            if (!(project.Version != null && object.Equals(project.Version.Length, 8)))
            {
                throw new InvalidOperationException("The project has no database version; read it from the repository before saving it.");
            }

            var workflow = project.Workflow;
            var parameters = new DynamicParameters();
            parameters.Add("@ProjectId", project.Id, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@ExpectedRowVersion", project.Version, DbType.Binary, size: 8);
            parameters.Add("@UpdatedAt", project.UpdatedAt);
            AddWorkflow(parameters, workflow);
            parameters.Add("@Submission", SubmissionTable(workflow.Submission).AsTableValuedParameter("frp.ProjectSubmissionTableType"));
            parameters.Add("@Contributors", ContributorsTable(workflow.Contributors).AsTableValuedParameter("frp.ContributorTableType"));
            parameters.Add("@ReplaceMappingsAndValidation", replaceMappingsAndValidation);
            parameters.Add("@Mappings", MappingsTable(replaceMappingsAndValidation ? project.Mappings : new List<MappingEntryDto>()).AsTableValuedParameter("frp.MappingTableType"));
            parameters.Add("@Validation", ValidationTable(replaceMappingsAndValidation ? project.Validation : null).AsTableValuedParameter("frp.ProjectValidationTableType"));
            parameters.Add("@Issues", (replaceMappingsAndValidation ? IssuesTable(project) : EmptyIssuesTable()).AsTableValuedParameter("frp.ProjectIssueTableType"));
            parameters.Add("@SampleValues", SampleValuesTable(saveSampleValues ? project.SchemaNodes : new List<SchemaNodeDto>()).AsTableValuedParameter("frp.SchemaNodeSampleValueTableType"));
            parameters.Add("@ReplaceSheetSplits", saveSheetSplits);
            parameters.Add("@SheetSplits", SheetSplitsTable(saveSheetSplits ? project.SheetSplits : new List<SheetSplitDto>()).AsTableValuedParameter("frp.SheetSplitTableType"));
            parameters.Add("@SheetSplitValues", SheetSplitValuesTable(saveSheetSplits ? project.SheetSplits : new List<SheetSplitDto>()).AsTableValuedParameter("frp.SheetSplitValueTableType"));

            var version = await ExecuteForVersionAsync("frp.usp_Project_Update", parameters, cancellationToken);
            return project.With(copy => { copy.Version = version; });
        }

        public async Task<FrpProjectDto> RenameAsync(FrpProjectDto project, CancellationToken cancellationToken)
        {
            RequireValidId(project.Id);
            RequireVersion(project);
            var parameters = new DynamicParameters();
            parameters.Add("@ProjectId", project.Id, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@ExpectedRowVersion", project.Version, DbType.Binary, size: 8);
            parameters.Add("@Name", project.Name, DbType.String, size: 200);
            parameters.Add("@UpdatedAt", project.UpdatedAt);
            parameters.Add("@LastModifiedBy", project.Workflow.LastModifiedBy);
            parameters.Add("@LastModifiedAt", project.Workflow.LastModifiedAt);
            var version = await ExecuteForVersionAsync("frp.usp_Project_Rename", parameters, cancellationToken);
            return project.With(copy => { copy.Version = version; });
        }

        public async Task<FrpProjectDto> ReplaceSourcesAsync(FrpProjectDto project, CancellationToken cancellationToken)
        {
            RequireValidId(project.Id);
            RequireVersion(project);
            var workflow = project.Workflow;
            var parameters = new DynamicParameters();
            parameters.Add("@ProjectId", project.Id, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@ExpectedRowVersion", project.Version, DbType.Binary, size: 8);
            parameters.Add("@Name", project.Name, DbType.String, size: 200);
            parameters.Add("@UpdatedAt", project.UpdatedAt);
            parameters.Add("@TemplateGenerated", project.TemplateGenerated);
            parameters.Add("@TargetNamespace", project.TargetNamespace);
            parameters.Add("@RootElement", project.RootElement);
            parameters.Add("@LastModifiedBy", workflow.LastModifiedBy);
            parameters.Add("@LastModifiedAt", workflow.LastModifiedAt);
            parameters.Add("@Files", FilesTable(project).AsTableValuedParameter("frp.ProjectFileTableType"));
            parameters.Add("@Submission", SubmissionTable(workflow.Submission).AsTableValuedParameter("frp.ProjectSubmissionTableType"));
            parameters.Add("@Contributors", ContributorsTable(workflow.Contributors).AsTableValuedParameter("frp.ContributorTableType"));
            parameters.Add("@Validation", ValidationTable(project.Validation).AsTableValuedParameter("frp.ProjectValidationTableType"));
            parameters.Add("@Issues", IssuesTable(project).AsTableValuedParameter("frp.ProjectIssueTableType"));
            parameters.Add("@SchemaNodes", SchemaNodesTable(project.SchemaNodes).AsTableValuedParameter("frp.SchemaNodeTableType"));
            parameters.Add("@SchemaNodeEnumerations", EnumerationsTable(project.SchemaNodes).AsTableValuedParameter("frp.SchemaNodeEnumerationTableType"));
            var workbooks = Workbooks(project);
            parameters.Add("@Workbooks", WorkbooksTable(workbooks).AsTableValuedParameter("frp.WorkbookTableType"));
            parameters.Add("@WorkbookSheets", SheetsTable(workbooks).AsTableValuedParameter("frp.WorkbookSheetTableType"));
            parameters.Add("@WorkbookCells", CellsTable(workbooks).AsTableValuedParameter("frp.WorkbookCellTableType"));
            parameters.Add("@WorkbookXmlMappings", XmlMappingsTable(workbooks).AsTableValuedParameter("frp.WorkbookXmlMappingTableType"));
            parameters.Add("@Mappings", MappingsTable(project.Mappings).AsTableValuedParameter("frp.MappingTableType"));
            parameters.Add("@SampleRows", SampleRowsTable(project.SampleRows).AsTableValuedParameter("frp.SampleRowTableType"));
            parameters.Add("@SampleRowValues", SampleRowValuesTable(project.SampleRows).AsTableValuedParameter("frp.SampleRowValueTableType"));
            parameters.Add("@SampleOmittedForms", OmittedFormsTable(project.SampleOmittedForms).AsTableValuedParameter("frp.SampleOmittedFormTableType"));
            parameters.Add("@SheetSplits", SheetSplitsTable(project.SheetSplits).AsTableValuedParameter("frp.SheetSplitTableType"));
            parameters.Add("@SheetSplitValues", SheetSplitValuesTable(project.SheetSplits).AsTableValuedParameter("frp.SheetSplitValueTableType"));
            var version = await ExecuteForVersionAsync("frp.usp_Project_ReplaceSources", parameters, cancellationToken);
            return project.With(copy => { copy.Version = version; });
        }

        private static void RequireVersion(FrpProjectDto project)
        {
            if (!(project.Version != null && object.Equals(project.Version.Length, 8)))
            {
                throw new InvalidOperationException("The project has no database version; read it from the repository before saving it.");
            }
        }

        public async Task<FrpProjectDto> GetAsync(string projectId, CancellationToken cancellationToken)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                return null;
            }

            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            using (var reader = await connection.QueryMultipleAsync(new CommandDefinition(
                "frp.usp_Project_Get",
                new { ProjectId = new DbString { Value = projectId, IsAnsi = true, IsFixedLength = true, Length = 32 } },
                commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds,
                cancellationToken: cancellationToken)))
            {

            // Every result set is read (in order) even when the project does not exist.
            var header = (await reader.ReadAsync<ProjectRow>()).SingleOrDefault();
            var fileRows = (await reader.ReadAsync<ProjectFileRow>()).ToList();
            var submissionRow = (await reader.ReadAsync<SubmissionRow>()).SingleOrDefault();
            var contributors = (await reader.ReadAsync<string>()).ToList();
            var validationRow = (await reader.ReadAsync<ValidationRow>()).SingleOrDefault();
            var issueRows = (await reader.ReadAsync<IssueRow>()).ToList();
            var nodeRows = (await reader.ReadAsync<SchemaNodeRow>()).ToList();
            var enumerationRows = (await reader.ReadAsync<EnumerationRow>()).ToList();
            var workbookRows = (await reader.ReadAsync<WorkbookRow>()).ToList();
            var sheetRows = (await reader.ReadAsync<SheetRow>()).ToList();
            var cellRows = (await reader.ReadAsync<CellRow>()).ToList();
            var xmlMappingRows = (await reader.ReadAsync<XmlMappingRow>()).ToList();
            var mappingRows = (await reader.ReadAsync<MappingRow>()).ToList();
            var sampleRowRows = (await reader.ReadAsync<SampleRowRow>()).ToList();
            var sampleValueRows = (await reader.ReadAsync<SampleValueRow>()).ToList();
            var omittedForms = (await reader.ReadAsync<string>()).ToList();
            var splitRows = (await reader.ReadAsync<SheetSplitRow>()).ToList();
            var splitValueRows = (await reader.ReadAsync<SheetSplitValueRow>()).ToList();

            if (header == null)
            {
                return null;
            }

            var enumerations = enumerationRows.GroupBy(e => e.NodeOrder).ToDictionary(g => g.Key, g => (IReadOnlyList<string>)g.Select(e => e.Value).ToList());
            var valuesByRow = sampleValueRows.GroupBy(v => v.RowOrder).ToDictionary(g => g.Key, g => g.ToList());
            var projectIssues = issueRows.Where(i => i.IssueSet == IssueSetProject).Select(ToIssue).ToList();
            var validationIssues = issueRows.Where(i => i.IssueSet == IssueSetValidation).Select(ToIssue).ToList();

            return new FrpProjectDto
            {
                Id = header.ProjectId,
                Name = header.Name,
                CreatedAt = header.CreatedAt,
                UpdatedAt = header.UpdatedAt,
                XsdFile = ToUploadedFile(fileRows, FileRoleXsd),
                TemplateFile = ToUploadedFile(fileRows, FileRoleTemplate),
                SpecificationFile = ToUploadedFile(fileRows, FileRoleSpecification),
                TemplateGenerated = header.TemplateGenerated,
                TargetNamespace = header.TargetNamespace,
                RootElement = header.RootElement,
                SchemaNodes = nodeRows.Select(n => { IReadOnlyList<string> values; return new SchemaNodeDto
                {
                    Path = n.Path,
                    Name = n.Name,
                    DataType = n.DataType,
                    TestValue = n.TestValue,
                    Validation = new SchemaValidationDto
                    {
                        Enumerations = enumerations.TryGetValue(n.NodeOrder, out values) ? values : new List<string>(),
                        Pattern = n.Pattern,
                        MinInclusive = n.MinInclusive,
                        MaxInclusive = n.MaxInclusive,
                        TotalDigits = n.TotalDigits,
                        FractionDigits = n.FractionDigits,
                        MinLength = n.MinLength,
                        MaxLength = n.MaxLength
                    },
                    IsRequired = n.IsRequired,
                    IsRepeating = n.IsRepeating,
                    IsInRepeatingGroup = n.IsInRepeatingGroup,
                    ParentPath = n.ParentPath,
                    Depth = n.Depth
                }; }).ToList(),
                Workbook = ToWorkbook(WorkbookRoleTemplate, workbookRows, sheetRows, cellRows, xmlMappingRows),
                SpecificationWorkbook = ToWorkbook(WorkbookRoleSpecification, workbookRows, sheetRows, cellRows, xmlMappingRows),
                Mappings = mappingRows.Select(m => new MappingEntryDto
                {
                    Id = m.MappingKey,
                    SheetName = m.SheetName,
                    CellAddress = m.CellAddress,
                    SchemaPath = m.SchemaPath,
                    DataType = m.DataType,
                    Required = m.IsRequired,
                    DefaultValue = m.DefaultValue,
                    Source = m.Source
                }).ToList(),
                SampleRows = sampleRowRows.Select(r => { List<SampleValueRow> rowValues; return new SampleRowDto
                {
                    ItemPath = r.ItemPath,
                    Values = (valuesByRow.TryGetValue(r.RowOrder, out rowValues) ? rowValues : new List<SampleValueRow>())
                        .ToDictionary(v => v.SchemaPath, v => v.Value)
                }; }).ToList(),
                SampleOmittedForms = omittedForms,
                SheetSplits = splitRows.Select(split => new SheetSplitDto
                {
                    GroupPath = split.GroupPath,
                    KeyPath = split.KeyPath,
                    Values = splitValueRows.Where(v => v.SplitOrder == split.SplitOrder).OrderBy(v => v.ValueOrder).Select(v => v.Value).ToList()
                }).ToList(),
                Issues = projectIssues,
                Validation = (validationRow == null) ? null : new ProjectValidationResultDto
                {
                    IsValid = validationRow.IsValid,
                    ErrorCount = validationRow.ErrorCount,
                    WarningCount = validationRow.WarningCount,
                    CheckedValues = validationRow.CheckedValues,
                    MappedSheets = validationRow.MappedSheets,
                    TotalSheets = validationRow.TotalSheets,
                    SpecificationChecked = validationRow.SpecificationChecked,
                    SpecInputFieldsConfirmed = validationRow.SpecInputFieldsConfirmed,
                    SpecRulesPassed = validationRow.SpecRulesPassed,
                    SpecRulesFailed = validationRow.SpecRulesFailed,
                    SpecRulesNotApplicable = validationRow.SpecRulesNotApplicable,
                    SpecRulesNotEvaluated = validationRow.SpecRulesNotEvaluated,
                    Issues = validationIssues
                },
                Workflow = new ProjectWorkflowDto
                {
                    Status = CompatEnum.Parse<ProjectStatus>(header.StatusKey, ignoreCase: false),
                    CreatedBy = header.CreatedBy,
                    CreatedAt = header.WorkflowCreatedAt,
                    LastModifiedBy = header.LastModifiedBy,
                    LastModifiedAt = header.LastModifiedAt,
                    Contributors = contributors,
                    Submission = (submissionRow == null) ? null : new SubmissionFileDto
                    {
                        FileName = submissionRow.FileName,
                        StoredPath = files.ToFullPath(submissionRow.StoredPath),
                        Size = submissionRow.SizeBytes,
                        Sha256 = submissionRow.Sha256,
                        Source = submissionRow.SourceKey,
                        AttachedBy = submissionRow.AttachedBy,
                        AttachedAt = submissionRow.AttachedAt,
                        XsdValid = submissionRow.XsdValid,
                        XsdErrors = submissionRow.XsdErrors,
                        SpecificationChecked = submissionRow.SpecificationChecked,
                        SpecRulesPassed = submissionRow.SpecRulesPassed,
                        SpecRulesFailed = submissionRow.SpecRulesFailed
                    },
                    SubmittedBy = header.SubmittedBy,
                    SubmittedAt = header.SubmittedAt,
                    SubmissionComment = header.SubmissionComment,
                    ReviewedBy = header.ReviewedBy,
                    ReviewedAt = header.ReviewedAt,
                    ReviewComment = header.ReviewComment
                },
                Version = header.RowVersion
            };
            }
            }
        }

        public async Task<IReadOnlyList<ProjectSummaryDto>> ListAsync(CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            using (var reader = await connection.QueryMultipleAsync(new CommandDefinition(
                "frp.usp_Project_List",
                commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds,
                cancellationToken: cancellationToken)))
            {
            var rows = (await reader.ReadAsync<SummaryRow>()).ToList();
            var contributors = (await reader.ReadAsync<ContributorRow>())
                .GroupBy(c => c.ProjectId)
                .ToDictionary(g => g.Key, g => (IReadOnlyList<string>)g.Select(c => c.UserName).ToList());

            return rows.Select(r => { IReadOnlyList<string> names; return new ProjectSummaryDto
            {
                Id = r.ProjectId,
                Name = r.Name,
                RootElement = r.RootElement,
                Status = CompatEnum.Parse<ProjectStatus>(r.StatusKey, ignoreCase: false),
                CreatedBy = string.IsNullOrEmpty(r.CreatedBy) ? "(before sign-in)" : r.CreatedBy,
                CreatedAt = r.CreatedAt,
                UpdatedAt = r.UpdatedAt,
                LastModifiedBy = r.LastModifiedBy,
                SubmittedBy = r.SubmittedBy,
                ReviewedBy = r.ReviewedBy,
                Contributors = contributors.TryGetValue(r.ProjectId, out names) ? names : new List<string>(),
                TemplateGenerated = r.TemplateGenerated,
                HasSpecification = r.HasSpecification,
                MappingCount = r.MappingCount,
                LastValidationValid = r.LastValidationValid,
                LastValidationErrors = r.LastValidationErrors
            }; }).ToList();
            }
            }
        }

        public async Task<ProjectUploads> GetUploadsAsync(string projectId, CancellationToken cancellationToken)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                return null;
            }

            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var parameters = new DynamicParameters();
            parameters.Add("@ProjectId", projectId, DbType.AnsiStringFixedLength, size: 32);
            using (var reader = await connection.QueryMultipleAsync(new CommandDefinition(
                "frp.usp_ProjectFile_List",
                parameters,
                commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds,
                cancellationToken: cancellationToken)))
            {
            var header = (await reader.ReadAsync<UploadsHeaderRow>()).SingleOrDefault();
            var fileRows = (await reader.ReadAsync<ProjectFileRow>()).ToList();
            if (header == null)
            {
                return null;
            }

            return new ProjectUploads
            {
                ProjectId = header.ProjectId,
                ProjectName = header.Name,
                TemplateGenerated = header.TemplateGenerated,
                Xsd = ToUploadedFile(fileRows, FileRoleXsd),
                Template = header.TemplateGenerated ? null : ToUploadedFile(fileRows, FileRoleTemplate),
                Specification = ToUploadedFile(fileRows, FileRoleSpecification)
            };
            }
            }
        }

        public async Task<IReadOnlyList<ProjectSummaryDto>> FindByFilesAsync(string createdBy, string xsdSha256, string templateKey, string specificationKey, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var parameters = new DynamicParameters();
            parameters.Add("@CreatedBy", createdBy, DbType.String, size: 256);
            parameters.Add("@XsdSha256", xsdSha256, DbType.AnsiStringFixedLength, size: 64);
            parameters.Add("@TemplateKey", templateKey, DbType.AnsiString, size: 64);
            parameters.Add("@SpecificationKey", specificationKey, DbType.AnsiString, size: 64);
            var rows = await connection.QueryAsync<SummaryRow>(new CommandDefinition(
                "frp.usp_Project_FindByFiles",
                parameters,
                commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds,
                cancellationToken: cancellationToken));
            return rows.Select(r => new ProjectSummaryDto
            {
                Id = r.ProjectId,
                Name = r.Name,
                RootElement = r.RootElement,
                Status = CompatEnum.Parse<ProjectStatus>(r.StatusKey, ignoreCase: false),
                CreatedBy = string.IsNullOrEmpty(r.CreatedBy) ? "(before sign-in)" : r.CreatedBy,
                CreatedAt = r.CreatedAt,
                UpdatedAt = r.UpdatedAt
            }).ToList();
            }
        }

        public async Task<bool> DeleteAsync(string projectId, byte[] expectedVersion, string deletedBy, DateTimeOffset deletedAt, CancellationToken cancellationToken)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                return false;
            }

            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var parameters = new DynamicParameters();
            parameters.Add("@ProjectId", projectId, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@ExpectedRowVersion", expectedVersion, DbType.Binary, size: 8);
            parameters.Add("@DeletedBy", deletedBy, DbType.String, size: 256);
            parameters.Add("@DeletedAt", deletedAt);
            try
            {
                await connection.ExecuteAsync(new CommandDefinition(
                    "frp.usp_Project_Delete",
                    parameters,
                    commandType: CommandType.StoredProcedure,
                    commandTimeout: connections.CommandTimeoutSeconds,
                    cancellationToken: cancellationToken));
                return true;
            }
            catch (SqlException ex) when (ex.Errors.Cast<SqlError>().Any(e => e.Number == DatabaseErrors.NotFound))
            {
                return false;
            }
            catch (SqlException ex) when (ex.Errors.Cast<SqlError>().Any(e => e.Number == DatabaseErrors.ConcurrencyConflict))
            {
                throw new ConcurrencyConflictException(ex.Message);
            }
            catch (SqlException ex) when (ex.Errors.Cast<SqlError>().Any(e => e.Number == DatabaseErrors.NotDeletable))
            {
                throw new ProjectNotDeletableException(ex.Message);
            }
            }
        }

        public async Task<IDisposable> LockAsync(string projectId, CancellationToken cancellationToken)
        {
            var gate = Locks.GetOrAdd(projectId, _ => new SemaphoreSlim(1, 1));
            await gate.WaitAsync(cancellationToken);
            return new Releaser(gate);
        }

        // ------------------------------------------------------------------ execution

        private async Task<byte[]> ExecuteForVersionAsync(string procedure, DynamicParameters parameters, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            try
            {
                var version = await connection.ExecuteScalarAsync<byte[]>(new CommandDefinition(
                    procedure,
                    parameters,
                    commandType: CommandType.StoredProcedure,
                    commandTimeout: connections.CommandTimeoutSeconds,
                    cancellationToken: cancellationToken));
                return (version != null && object.Equals(version.Length, 8)) ? version : CompatThrow.As<byte[]>(new InvalidOperationException($"{procedure} did not return the project's row version."));
            }
            catch (SqlException ex) when (ex.Errors.Cast<SqlError>().Any(e => e.Number == DatabaseErrors.ConcurrencyConflict))
            {
                throw new ConcurrencyConflictException(ex.Message);
            }
            catch (SqlException ex) when (ex.Errors.Cast<SqlError>().Any(e => e.Number == DatabaseErrors.DuplicateProjectFiles))
            {
                throw new DuplicateProjectFilesException(ex.Message);
            }
            catch (SqlException ex) when (ex.Errors.Cast<SqlError>().Any(e => e.Number == DatabaseErrors.NotEditable))
            {
                throw new ProjectNotEditableException(ex.Message);
            }
            }
        }

        private static void AddWorkflow(DynamicParameters parameters, ProjectWorkflowDto workflow)
        {
            parameters.Add("@StatusKey", workflow.Status.ToString(), DbType.AnsiString, size: 20);
            parameters.Add("@CreatedBy", workflow.CreatedBy);
            parameters.Add("@WorkflowCreatedAt", workflow.CreatedAt);
            parameters.Add("@LastModifiedBy", workflow.LastModifiedBy);
            parameters.Add("@LastModifiedAt", workflow.LastModifiedAt);
            parameters.Add("@SubmittedBy", workflow.SubmittedBy);
            parameters.Add("@SubmittedAt", workflow.SubmittedAt);
            parameters.Add("@SubmissionComment", workflow.SubmissionComment);
            parameters.Add("@ReviewedBy", workflow.ReviewedBy);
            parameters.Add("@ReviewedAt", workflow.ReviewedAt);
            parameters.Add("@ReviewComment", workflow.ReviewComment);
        }

        private static void RequireValidId(string projectId)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                throw new ArgumentException("Invalid project id.", nameof(projectId));
            }
        }

        // ------------------------------------------------------------------ table-valued parameters
        // Column order must match the frp.*TableType definitions exactly (table-valued parameters bind by position).

        private DataTable FilesTable(FrpProjectDto project)
        {
            var table = NewTable(new VT_Name_Type<string, Type>("FileRoleKey", typeof(string)), new VT_Name_Type<string, Type>("OriginalName", typeof(string)), new VT_Name_Type<string, Type>("StoredPath", typeof(string)), new VT_Name_Type<string, Type>("SizeBytes", typeof(long)), new VT_Name_Type<string, Type>("Sha256", typeof(string)));
            foreach (var entry in new[] { new VT_Item1_Item2<string, UploadedFileDto>(FileRoleXsd, project.XsdFile), new VT_Item1_Item2<string, UploadedFileDto>(FileRoleTemplate, project.TemplateFile), new VT_Item1_Item2<string, UploadedFileDto>(FileRoleSpecification, project.SpecificationFile) })
            {
                var role = entry.Item1;
                var file = entry.Item2;
                if (file != null)
                {
                    table.Rows.Add(role, file.OriginalName, files.ToStoredPath(file.StoredPath), file.Size, Db(file.Sha256));
                }
            }

            return table;
        }

        private DataTable SubmissionTable(SubmissionFileDto submission)
        {
            var table = NewTable(
                new VT_Name_Type<string, Type>("FileName", typeof(string)), new VT_Name_Type<string, Type>("StoredPath", typeof(string)), new VT_Name_Type<string, Type>("SizeBytes", typeof(long)), new VT_Name_Type<string, Type>("Sha256", typeof(string)),
                new VT_Name_Type<string, Type>("SourceKey", typeof(string)), new VT_Name_Type<string, Type>("AttachedBy", typeof(string)), new VT_Name_Type<string, Type>("AttachedAt", typeof(DateTimeOffset)), new VT_Name_Type<string, Type>("XsdValid", typeof(bool)),
                new VT_Name_Type<string, Type>("XsdErrors", typeof(int)), new VT_Name_Type<string, Type>("SpecificationChecked", typeof(bool)), new VT_Name_Type<string, Type>("SpecRulesPassed", typeof(int)), new VT_Name_Type<string, Type>("SpecRulesFailed", typeof(int)));
            if (submission != null)
            {
                table.Rows.Add(submission.FileName, files.ToStoredPath(submission.StoredPath), submission.Size, submission.Sha256,
                    submission.Source, submission.AttachedBy, submission.AttachedAt, submission.XsdValid,
                    submission.XsdErrors, submission.SpecificationChecked, submission.SpecRulesPassed, submission.SpecRulesFailed);
            }

            return table;
        }

        private static DataTable ContributorsTable(IReadOnlyList<string> contributors)
        {
            var table = NewTable(new VT_Name_Type<string, Type>("ContributorOrder", typeof(int)), new VT_Name_Type<string, Type>("UserName", typeof(string)));
            for (var i = 0; i < contributors.Count; i++)
            {
                table.Rows.Add(i, contributors[i]);
            }

            return table;
        }

        private static DataTable ValidationTable(ProjectValidationResultDto validation)
        {
            var table = NewTable(
                new VT_Name_Type<string, Type>("IsValid", typeof(bool)), new VT_Name_Type<string, Type>("ErrorCount", typeof(int)), new VT_Name_Type<string, Type>("WarningCount", typeof(int)), new VT_Name_Type<string, Type>("CheckedValues", typeof(int)),
                new VT_Name_Type<string, Type>("MappedSheets", typeof(int)), new VT_Name_Type<string, Type>("TotalSheets", typeof(int)), new VT_Name_Type<string, Type>("SpecificationChecked", typeof(bool)), new VT_Name_Type<string, Type>("SpecInputFieldsConfirmed", typeof(int)),
                new VT_Name_Type<string, Type>("SpecRulesPassed", typeof(int)), new VT_Name_Type<string, Type>("SpecRulesFailed", typeof(int)), new VT_Name_Type<string, Type>("SpecRulesNotApplicable", typeof(int)), new VT_Name_Type<string, Type>("SpecRulesNotEvaluated", typeof(int)));
            if (validation != null)
            {
                table.Rows.Add(validation.IsValid, validation.ErrorCount, validation.WarningCount, validation.CheckedValues,
                    validation.MappedSheets, validation.TotalSheets, validation.SpecificationChecked, validation.SpecInputFieldsConfirmed,
                    validation.SpecRulesPassed, validation.SpecRulesFailed, validation.SpecRulesNotApplicable, validation.SpecRulesNotEvaluated);
            }

            return table;
        }

        private static DataTable EmptyIssuesTable() => NewTable(
            new VT_Name_Type<string, Type>("IssueSet", typeof(string)), new VT_Name_Type<string, Type>("IssueOrder", typeof(int)), new VT_Name_Type<string, Type>("Severity", typeof(string)), new VT_Name_Type<string, Type>("Message", typeof(string)),
            new VT_Name_Type<string, Type>("SchemaPath", typeof(string)), new VT_Name_Type<string, Type>("SheetName", typeof(string)), new VT_Name_Type<string, Type>("CellAddress", typeof(string)), new VT_Name_Type<string, Type>("Category", typeof(string)));

        private static DataTable IssuesTable(FrpProjectDto project)
        {
            var table = EmptyIssuesTable();
            AddIssues(table, IssueSetProject, project.Issues);
            if (project.Validation != null)
            {
                AddIssues(table, IssueSetValidation, project.Validation.Issues);
            }

            return table;
        }

        /// <summary>NodeOrder is the node's position, as when the project was created (and read back in that order).</summary>
        private static DataTable SampleValuesTable(IReadOnlyList<SchemaNodeDto> nodes)
        {
            var table = NewTable(new VT_Name_Type<string, Type>("NodeOrder", typeof(int)), new VT_Name_Type<string, Type>("TestValue", typeof(string)));
            for (var i = 0; i < nodes.Count; i++)
            {
                table.Rows.Add(i, Db(nodes[i].TestValue));
            }

            return table;
        }

        private static DataTable SchemaNodesTable(IReadOnlyList<SchemaNodeDto> nodes)
        {
            var table = NewTable(
                new VT_Name_Type<string, Type>("NodeOrder", typeof(int)), new VT_Name_Type<string, Type>("Path", typeof(string)), new VT_Name_Type<string, Type>("Name", typeof(string)), new VT_Name_Type<string, Type>("DataType", typeof(string)),
                new VT_Name_Type<string, Type>("TestValue", typeof(string)), new VT_Name_Type<string, Type>("IsRequired", typeof(bool)), new VT_Name_Type<string, Type>("IsRepeating", typeof(bool)), new VT_Name_Type<string, Type>("IsInRepeatingGroup", typeof(bool)),
                new VT_Name_Type<string, Type>("ParentPath", typeof(string)), new VT_Name_Type<string, Type>("Depth", typeof(int)), new VT_Name_Type<string, Type>("Pattern", typeof(string)), new VT_Name_Type<string, Type>("MinInclusive", typeof(string)),
                new VT_Name_Type<string, Type>("MaxInclusive", typeof(string)), new VT_Name_Type<string, Type>("TotalDigits", typeof(int)), new VT_Name_Type<string, Type>("FractionDigits", typeof(int)), new VT_Name_Type<string, Type>("MinLength", typeof(int)),
                new VT_Name_Type<string, Type>("MaxLength", typeof(int)));
            for (var i = 0; i < nodes.Count; i++)
            {
                var node = nodes[i];
                var validation = node.Validation;
                table.Rows.Add(i, node.Path, node.Name, node.DataType, Db(node.TestValue), node.IsRequired, node.IsRepeating, node.IsInRepeatingGroup,
                    Db(node.ParentPath), node.Depth, Db(validation.Pattern), Db(validation.MinInclusive), Db(validation.MaxInclusive),
                    Db(validation.TotalDigits), Db(validation.FractionDigits), Db(validation.MinLength), Db(validation.MaxLength));
            }

            return table;
        }

        private static DataTable EnumerationsTable(IReadOnlyList<SchemaNodeDto> nodes)
        {
            var table = NewTable(new VT_Name_Type<string, Type>("NodeOrder", typeof(int)), new VT_Name_Type<string, Type>("EnumerationOrder", typeof(int)), new VT_Name_Type<string, Type>("Value", typeof(string)));
            for (var i = 0; i < nodes.Count; i++)
            {
                var values = nodes[i].Validation.Enumerations;
                for (var j = 0; j < values.Count; j++)
                {
                    table.Rows.Add(i, j, values[j]);
                }
            }

            return table;
        }

        private static List<VT_Role_Workbook<string, WorkbookSummaryDto>> Workbooks(FrpProjectDto project)
        {
            var list = new List<VT_Role_Workbook<string, WorkbookSummaryDto>>();
            if (project.Workbook != null)
            {
                list.Add(new VT_Role_Workbook<string, WorkbookSummaryDto>(WorkbookRoleTemplate, project.Workbook));
            }

            if (project.SpecificationWorkbook != null)
            {
                list.Add(new VT_Role_Workbook<string, WorkbookSummaryDto>(WorkbookRoleSpecification, project.SpecificationWorkbook));
            }

            return list;
        }

        private static DataTable WorkbooksTable(List<VT_Role_Workbook<string, WorkbookSummaryDto>> workbooks)
        {
            var table = NewTable(new VT_Name_Type<string, Type>("WorkbookRoleKey", typeof(string)), new VT_Name_Type<string, Type>("FileName", typeof(string)), new VT_Name_Type<string, Type>("ExistingMappingCount", typeof(int)));
            foreach (var workbook2 in workbooks)
            {
                var role = workbook2.Role;
                var workbook = workbook2.Workbook;
                table.Rows.Add(role, workbook.FileName, workbook.ExistingMappingCount);
            }

            return table;
        }

        private static DataTable SheetsTable(List<VT_Role_Workbook<string, WorkbookSummaryDto>> workbooks)
        {
            var table = NewTable(
                new VT_Name_Type<string, Type>("WorkbookRoleKey", typeof(string)), new VT_Name_Type<string, Type>("SheetOrder", typeof(int)), new VT_Name_Type<string, Type>("Name", typeof(string)), new VT_Name_Type<string, Type>("RelationshipId", typeof(string)),
                new VT_Name_Type<string, Type>("WorksheetPath", typeof(string)), new VT_Name_Type<string, Type>("TotalStoredCellCount", typeof(int)));
            foreach (var workbook2 in workbooks)
            {
                var role = workbook2.Role;
                var workbook = workbook2.Workbook;
                for (var i = 0; i < workbook.Sheets.Count; i++)
                {
                    var sheet = workbook.Sheets[i];
                    table.Rows.Add(role, i, sheet.Name, sheet.RelationshipId, sheet.WorksheetPath, sheet.TotalStoredCellCount);
                }
            }

            return table;
        }

        private static DataTable CellsTable(List<VT_Role_Workbook<string, WorkbookSummaryDto>> workbooks)
        {
            var table = NewTable(
                new VT_Name_Type<string, Type>("WorkbookRoleKey", typeof(string)), new VT_Name_Type<string, Type>("SheetOrder", typeof(int)), new VT_Name_Type<string, Type>("CellOrder", typeof(int)), new VT_Name_Type<string, Type>("Address", typeof(string)),
                new VT_Name_Type<string, Type>("DisplayValue", typeof(string)), new VT_Name_Type<string, Type>("Style", typeof(string)));
            foreach (var workbook2 in workbooks)
            {
                var role = workbook2.Role;
                var workbook = workbook2.Workbook;
                for (var i = 0; i < workbook.Sheets.Count; i++)
                {
                    var cells = workbook.Sheets[i].Cells;
                    for (var j = 0; j < cells.Count; j++)
                    {
                        table.Rows.Add(role, i, j, cells[j].Address, cells[j].DisplayValue, Db(cells[j].Style));
                    }
                }
            }

            return table;
        }

        private static DataTable XmlMappingsTable(List<VT_Role_Workbook<string, WorkbookSummaryDto>> workbooks)
        {
            var table = NewTable(
                new VT_Name_Type<string, Type>("WorkbookRoleKey", typeof(string)), new VT_Name_Type<string, Type>("MappingOrder", typeof(int)), new VT_Name_Type<string, Type>("SheetName", typeof(string)), new VT_Name_Type<string, Type>("CellAddress", typeof(string)),
                new VT_Name_Type<string, Type>("XPath", typeof(string)), new VT_Name_Type<string, Type>("DataType", typeof(string)), new VT_Name_Type<string, Type>("ElementName", typeof(string)), new VT_Name_Type<string, Type>("IsListColumn", typeof(bool)));
            foreach (var workbook2 in workbooks)
            {
                var role = workbook2.Role;
                var workbook = workbook2.Workbook;
                for (var i = 0; i < workbook.ExistingMappings.Count; i++)
                {
                    var mapping = workbook.ExistingMappings[i];
                    table.Rows.Add(role, i, mapping.SheetName, mapping.CellAddress, mapping.XPath, mapping.DataType, Db(mapping.ElementName), mapping.IsListColumn);
                }
            }

            return table;
        }

        private static DataTable MappingsTable(IReadOnlyList<MappingEntryDto> mappings)
        {
            var table = NewTable(
                new VT_Name_Type<string, Type>("MappingOrder", typeof(int)), new VT_Name_Type<string, Type>("MappingKey", typeof(string)), new VT_Name_Type<string, Type>("SheetName", typeof(string)), new VT_Name_Type<string, Type>("CellAddress", typeof(string)),
                new VT_Name_Type<string, Type>("SchemaPath", typeof(string)), new VT_Name_Type<string, Type>("DataType", typeof(string)), new VT_Name_Type<string, Type>("IsRequired", typeof(bool)), new VT_Name_Type<string, Type>("DefaultValue", typeof(string)),
                new VT_Name_Type<string, Type>("Source", typeof(string)));
            for (var i = 0; i < mappings.Count; i++)
            {
                var mapping = mappings[i];
                table.Rows.Add(i, mapping.Id, mapping.SheetName, mapping.CellAddress, mapping.SchemaPath, mapping.DataType, mapping.Required,
                    Db(mapping.DefaultValue), mapping.Source);
            }

            return table;
        }

        private static DataTable SampleRowsTable(IReadOnlyList<SampleRowDto> rows)
        {
            var table = NewTable(new VT_Name_Type<string, Type>("RowOrder", typeof(int)), new VT_Name_Type<string, Type>("ItemPath", typeof(string)));
            for (var i = 0; i < rows.Count; i++)
            {
                table.Rows.Add(i, rows[i].ItemPath);
            }

            return table;
        }

        private static DataTable SampleRowValuesTable(IReadOnlyList<SampleRowDto> rows)
        {
            var table = NewTable(new VT_Name_Type<string, Type>("RowOrder", typeof(int)), new VT_Name_Type<string, Type>("ValueOrder", typeof(int)), new VT_Name_Type<string, Type>("SchemaPath", typeof(string)), new VT_Name_Type<string, Type>("Value", typeof(string)));
            for (var i = 0; i < rows.Count; i++)
            {
                var j = 0;
                foreach (var row in rows[i].Values)
                {
                    var path = row.Key;
                    var value = row.Value;
                    table.Rows.Add(i, j++, path, value);
                }
            }

            return table;
        }

        private static DataTable OmittedFormsTable(IReadOnlyList<string> forms)
        {
            var table = NewTable(new VT_Name_Type<string, Type>("FormOrder", typeof(int)), new VT_Name_Type<string, Type>("FormName", typeof(string)));
            for (var i = 0; i < forms.Count; i++)
            {
                table.Rows.Add(i, forms[i]);
            }

            return table;
        }

        private static DataTable SheetSplitsTable(IReadOnlyList<SheetSplitDto> splits)
        {
            var table = NewTable(new VT_Name_Type<string, Type>("SplitOrder", typeof(int)), new VT_Name_Type<string, Type>("GroupPath", typeof(string)), new VT_Name_Type<string, Type>("KeyPath", typeof(string)));
            for (var i = 0; i < splits.Count; i++)
            {
                table.Rows.Add(i, splits[i].GroupPath, splits[i].KeyPath);
            }

            return table;
        }

        private static DataTable SheetSplitValuesTable(IReadOnlyList<SheetSplitDto> splits)
        {
            var table = NewTable(new VT_Name_Type<string, Type>("SplitOrder", typeof(int)), new VT_Name_Type<string, Type>("ValueOrder", typeof(int)), new VT_Name_Type<string, Type>("Value", typeof(string)));
            for (var i = 0; i < splits.Count; i++)
            {
                for (var j = 0; j < splits[i].Values.Count; j++)
                {
                    table.Rows.Add(i, j, splits[i].Values[j]);
                }
            }

            return table;
        }

        private static DataTable NewTable(params VT_Name_Type<string, Type>[] columns)
        {
            var table = new DataTable();
            foreach (var column in columns)
            {
                var name = column.Name;
                var type = column.Type;
                table.Columns.Add(name, type);
            }

            return table;
        }

        private static object Db(object value) => value ?? DBNull.Value;

        // ------------------------------------------------------------------ reading

        private UploadedFileDto ToUploadedFile(List<ProjectFileRow> rows, string role)  {
        ProjectFileRow row;
        return CompatPattern.Is(rows.FirstOrDefault(r => r.FileRoleKey == role), out row) ? new UploadedFileDto
        {
            OriginalName = row.OriginalName,
            StoredPath = files.ToFullPath(row.StoredPath),
            Size = row.SizeBytes,
            Sha256 = row.Sha256
        }

        : null;
    }

        private static WorkbookSummaryDto ToWorkbook(string role, List<WorkbookRow> workbooks, List<SheetRow> sheets, List<CellRow> cells, List<XmlMappingRow> xmlMappings)
        {
            var workbook = workbooks.FirstOrDefault(w => w.WorkbookRoleKey == role);
            if (workbook == null)
            {
                return null;
            }

            var cellsBySheet = cells.Where(c => c.WorkbookRoleKey == role).GroupBy(c => c.SheetOrder).ToDictionary(g => g.Key, g => g.ToList());
            return new WorkbookSummaryDto
            {
                FileName = workbook.FileName,
                Sheets = sheets.Where(s => s.WorkbookRoleKey == role).Select(s => { List<CellRow> sheetCells; return new WorkbookSheetDto
                {
                    Name = s.Name,
                    RelationshipId = s.RelationshipId,
                    WorksheetPath = s.WorksheetPath,
                    TotalStoredCellCount = s.TotalStoredCellCount,
                    Cells = (cellsBySheet.TryGetValue(s.SheetOrder, out sheetCells) ? sheetCells : new List<CellRow>())
                        .Select(c => new WorkbookCellDto { Address = c.Address, DisplayValue = c.DisplayValue, Style = c.Style })
                        .ToList()
                }; }).ToList(),
                ExistingMappings = xmlMappings.Where(m => m.WorkbookRoleKey == role).Select(m => new ExistingXmlMappingDto
                {
                    SheetName = m.SheetName,
                    CellAddress = m.CellAddress,
                    XPath = m.XPath,
                    DataType = m.DataType,
                    ElementName = m.ElementName,
                    IsListColumn = m.IsListColumn
                }).ToList(),
                ExistingMappingCount = workbook.ExistingMappingCount
            };
        }

        private static ValidationIssueDto ToIssue(IssueRow row) => new ValidationIssueDto() {
            Severity = row.Severity,
            Message = row.Message,
            SchemaPath = row.SchemaPath,
            SheetName = row.SheetName,
            CellAddress = row.CellAddress,
            Category = row.Category
        };

        // Result-set rows: property names match the stored procedures' column names.
        private sealed class ProjectRow
        {
            public string ProjectId { get; set; } = "";
            public string Name { get; set; } = "";
            public DateTimeOffset CreatedAt { get; set; }
            public DateTimeOffset UpdatedAt { get; set; }
            public bool TemplateGenerated { get; set; }
            public string TargetNamespace { get; set; }
            public string RootElement { get; set; }
            public string StatusKey { get; set; } = "";
            public string CreatedBy { get; set; } = "";
            public DateTimeOffset? WorkflowCreatedAt { get; set; }
            public string LastModifiedBy { get; set; }
            public DateTimeOffset? LastModifiedAt { get; set; }
            public string SubmittedBy { get; set; }
            public DateTimeOffset? SubmittedAt { get; set; }
            public string SubmissionComment { get; set; }
            public string ReviewedBy { get; set; }
            public DateTimeOffset? ReviewedAt { get; set; }
            public string ReviewComment { get; set; }
            public byte[] RowVersion { get; set; } = new byte[0];
        }

        private sealed class UploadsHeaderRow
        {
            public string ProjectId { get; set; } = "";
            public string Name { get; set; } = "";
            public bool TemplateGenerated { get; set; }
        }

        private sealed class ProjectFileRow
        {
            public string FileRoleKey { get; set; } = "";
            public string OriginalName { get; set; } = "";
            public string StoredPath { get; set; } = "";
            public long SizeBytes { get; set; }
            public string Sha256 { get; set; }
        }

        private sealed class SubmissionRow
        {
            public string FileName { get; set; } = "";
            public string StoredPath { get; set; } = "";
            public long SizeBytes { get; set; }
            public string Sha256 { get; set; } = "";
            public string SourceKey { get; set; } = "";
            public string AttachedBy { get; set; } = "";
            public DateTimeOffset AttachedAt { get; set; }
            public bool XsdValid { get; set; }
            public int XsdErrors { get; set; }
            public bool SpecificationChecked { get; set; }
            public int SpecRulesPassed { get; set; }
            public int SpecRulesFailed { get; set; }
        }

        private sealed class ValidationRow
        {
            public bool IsValid { get; set; }
            public int ErrorCount { get; set; }
            public int WarningCount { get; set; }
            public int CheckedValues { get; set; }
            public int MappedSheets { get; set; }
            public int TotalSheets { get; set; }
            public bool SpecificationChecked { get; set; }
            public int SpecInputFieldsConfirmed { get; set; }
            public int SpecRulesPassed { get; set; }
            public int SpecRulesFailed { get; set; }
            public int SpecRulesNotApplicable { get; set; }
            public int SpecRulesNotEvaluated { get; set; }
        }

        private sealed class IssueRow
        {
            public string IssueSet { get; set; } = "";
            public string Severity { get; set; } = "";
            public string Message { get; set; } = "";
            public string SchemaPath { get; set; }
            public string SheetName { get; set; }
            public string CellAddress { get; set; }
            public string Category { get; set; } = "";
        }

        private sealed class SchemaNodeRow
        {
            public int NodeOrder { get; set; }
            public string Path { get; set; } = "";
            public string Name { get; set; } = "";
            public string DataType { get; set; } = "";
            public string TestValue { get; set; }
            public bool IsRequired { get; set; }
            public bool IsRepeating { get; set; }
            public bool IsInRepeatingGroup { get; set; }
            public string ParentPath { get; set; }
            public int Depth { get; set; }
            public string Pattern { get; set; }
            public string MinInclusive { get; set; }
            public string MaxInclusive { get; set; }
            public int? TotalDigits { get; set; }
            public int? FractionDigits { get; set; }
            public int? MinLength { get; set; }
            public int? MaxLength { get; set; }
        }

        private sealed class EnumerationRow
        {
            public int NodeOrder { get; set; }
            public string Value { get; set; } = "";
        }

        private sealed class WorkbookRow
        {
            public string WorkbookRoleKey { get; set; } = "";
            public string FileName { get; set; } = "";
            public int ExistingMappingCount { get; set; }
        }

        private sealed class SheetRow
        {
            public string WorkbookRoleKey { get; set; } = "";
            public int SheetOrder { get; set; }
            public string Name { get; set; } = "";
            public string RelationshipId { get; set; } = "";
            public string WorksheetPath { get; set; } = "";
            public int TotalStoredCellCount { get; set; }
        }

        private sealed class CellRow
        {
            public string WorkbookRoleKey { get; set; } = "";
            public int SheetOrder { get; set; }
            public string Address { get; set; } = "";
            public string DisplayValue { get; set; } = "";
            public string Style { get; set; }
        }

        private sealed class XmlMappingRow
        {
            public string WorkbookRoleKey { get; set; } = "";
            public string SheetName { get; set; } = "";
            public string CellAddress { get; set; } = "";
            public string XPath { get; set; } = "";
            public string DataType { get; set; } = "";
            public string ElementName { get; set; }
            public bool IsListColumn { get; set; }
        }

        private sealed class MappingRow
        {
            public string MappingKey { get; set; } = "";
            public string SheetName { get; set; } = "";
            public string CellAddress { get; set; } = "";
            public string SchemaPath { get; set; } = "";
            public string DataType { get; set; } = "";
            public bool IsRequired { get; set; }
            public string DefaultValue { get; set; }
            public string Source { get; set; } = "";
        }

        private sealed class SampleRowRow
        {
            public int RowOrder { get; set; }
            public string ItemPath { get; set; } = "";
        }

        private sealed class SheetSplitRow
        {
            public int SplitOrder { get; set; }
            public string GroupPath { get; set; } = "";
            public string KeyPath { get; set; } = "";
        }

        private sealed class SheetSplitValueRow
        {
            public int SplitOrder { get; set; }
            public int ValueOrder { get; set; }
            public string Value { get; set; } = "";
        }

        private sealed class SampleValueRow
        {
            public int RowOrder { get; set; }
            public string SchemaPath { get; set; } = "";
            public string Value { get; set; } = "";
        }

        private sealed class SummaryRow
        {
            public string ProjectId { get; set; } = "";
            public string Name { get; set; } = "";
            public string RootElement { get; set; }
            public string StatusKey { get; set; } = "";
            public string CreatedBy { get; set; } = "";
            public DateTimeOffset CreatedAt { get; set; }
            public DateTimeOffset UpdatedAt { get; set; }
            public string LastModifiedBy { get; set; }
            public string SubmittedBy { get; set; }
            public string ReviewedBy { get; set; }
            public bool TemplateGenerated { get; set; }
            public bool HasSpecification { get; set; }
            public int MappingCount { get; set; }
            public bool? LastValidationValid { get; set; }
            public int LastValidationErrors { get; set; }
        }

        private sealed class ContributorRow
        {
            public string ProjectId { get; set; } = "";
            public string UserName { get; set; } = "";
        }

        private sealed class Releaser: IDisposable
        {
        private readonly SemaphoreSlim gate;

        public Releaser(SemaphoreSlim gate)
    {
        this.gate = gate;
    }
            private int _released;

            public void Dispose()
            {
                if (Interlocked.Exchange(ref _released, 1) == 0)
                {
                    gate.Release();
                }
            }
        }

            private static void AddIssues(DataTable table, string set, IReadOnlyList<ValidationIssueDto> issues)
    {
        for (var i = 0; i < issues.Count; i++)
        {
            var issue = issues[i];
            table.Rows.Add(set, i, issue.Severity, issue.Message, Db(issue.SchemaPath), Db(issue.SheetName), Db(issue.CellAddress), issue.Category);
        }
    }
    }

    /// <summary>Error numbers the stored procedures raise (see 003_procedures.sql).</summary>
    internal static class DatabaseErrors
    {
        public const int ConcurrencyConflict = 51001;
        public const int NotFound = 51002;
        public const int NotEditable = 51006;
        public const int DuplicateProjectFiles = 51007;
        public const int NotDeletable = 51008;
        public const int AccessRequestOpen = 51009;
        public const int AccessDecisionRefused = 51010;
    }

}
