using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace FrpMapper.Api.DAL.Sql
{
    // The .NET 9 version used Dapper. This is the part of Dapper's API the DAL uses, written for .NET Framework 4.5.2
    // without a NuGet package: stored procedure calls with typed parameters, table-valued parameters, and result-set
    // rows mapped to classes by column name. No SQL text is built from values: every value is a parameter.

    /// <summary>A command to run: the stored procedure, its parameters, timeout and cancellation.</summary>
    public struct CommandDefinition
    {
        public CommandDefinition(string commandText, object parameters = null, IDbTransaction transaction = null, int? commandTimeout = null,
            CommandType? commandType = null, int flags = 0, CancellationToken cancellationToken = default(CancellationToken))
        {
            CommandText = commandText;
            Parameters = parameters;
            Transaction = transaction;
            CommandTimeout = commandTimeout;
            CommandType = commandType;
            CancellationToken = cancellationToken;
        }

        public string CommandText { get; }

        public object Parameters { get; }

        public IDbTransaction Transaction { get; }

        public int? CommandTimeout { get; }

        public CommandType? CommandType { get; }

        public CancellationToken CancellationToken { get; }
    }

    /// <summary>A string parameter with an explicit SQL type (varchar / char and length).</summary>
    public sealed class DbString
    {
        public const int DefaultLength = 4000;

        public DbString()
        {
            Length = -1;
        }

        public string Value { get; set; }

        public bool IsAnsi { get; set; }

        public bool IsFixedLength { get; set; }

        public int Length { get; set; }
    }

    /// <summary>Parameters added one by one, with an optional type, direction and size.</summary>
    public sealed class DynamicParameters
    {
        private readonly List<ParameterInfo> parameters = new List<ParameterInfo>();

        public void Add(string name, object value = null, DbType? dbType = null, ParameterDirection? direction = null, int? size = null)
        {
            var clean = Clean(name);
            parameters.RemoveAll(p => string.Equals(p.Name, clean, StringComparison.OrdinalIgnoreCase));
            parameters.Add(new ParameterInfo { Name = clean, Value = value, DbType = dbType, Direction = direction ?? ParameterDirection.Input, Size = size });
        }

        public T Get<T>(string name)
        {
            var info = parameters.First(p => string.Equals(p.Name, Clean(name), StringComparison.OrdinalIgnoreCase));
            var value = info.Attached == null ? info.Value : info.Attached.Value;
            return value == null || value is DBNull ? default(T) : (T)value;
        }

        internal void AddTo(SqlCommand command)
        {
            foreach (var p in parameters)
            {
                var parameter = SqlMapper.CreateParameter(command, p.Name, p.Value, p.DbType, p.Size);
                parameter.Direction = p.Direction;
                p.Attached = parameter;
                command.Parameters.Add(parameter);
            }
        }

        private static string Clean(string name)
        {
            return name.StartsWith("@", StringComparison.Ordinal) ? name.Substring(1) : name;
        }

        private sealed class ParameterInfo
        {
            public string Name;
            public object Value;
            public DbType? DbType;
            public ParameterDirection Direction;
            public int? Size;
            public SqlParameter Attached;
        }
    }

    /// <summary>A DataTable sent as a table-valued parameter of the named SQL type.</summary>
    public sealed class TableValuedParameter
    {
        public TableValuedParameter(DataTable table, string typeName)
        {
            Table = table;
            TypeName = typeName;
        }

        public DataTable Table { get; }

        public string TypeName { get; }
    }

    public static class SqlMapper
    {
        private static readonly ConcurrentDictionary<Type, PropertyInfo[]> ParameterProperties = new ConcurrentDictionary<Type, PropertyInfo[]>();
        private static readonly ConcurrentDictionary<Type, Dictionary<string, PropertyInfo>> RowProperties = new ConcurrentDictionary<Type, Dictionary<string, PropertyInfo>>();

        public static TableValuedParameter AsTableValuedParameter(this DataTable table, string typeName)
        {
            return new TableValuedParameter(table, typeName);
        }

        public static async Task<int> ExecuteAsync(this SqlConnection connection, CommandDefinition command)
        {
            using (var sql = Create(connection, command))
            {
                return await sql.ExecuteNonQueryAsync(command.CancellationToken).ConfigureAwait(false);
            }
        }

        public static async Task<T> ExecuteScalarAsync<T>(this SqlConnection connection, CommandDefinition command)
        {
            using (var sql = Create(connection, command))
            {
                var value = await sql.ExecuteScalarAsync(command.CancellationToken).ConfigureAwait(false);
                return (T)ConvertValue(value, typeof(T));
            }
        }

        public static async Task<IEnumerable<T>> QueryAsync<T>(this SqlConnection connection, CommandDefinition command)
        {
            using (var sql = Create(connection, command))
            using (var reader = await sql.ExecuteReaderAsync(command.CancellationToken).ConfigureAwait(false))
            {
                return await ReadRowsAsync<T>(reader, command.CancellationToken).ConfigureAwait(false);
            }
        }

        public static async Task<T> QuerySingleAsync<T>(this SqlConnection connection, CommandDefinition command)
        {
            var rows = (await QueryAsync<T>(connection, command).ConfigureAwait(false)).ToList();
            if (rows.Count != 1)
            {
                throw new InvalidOperationException(rows.Count == 0 ? "The procedure returned no row." : "The procedure returned more than one row.");
            }

            return rows[0];
        }

        public static async Task<T> QuerySingleOrDefaultAsync<T>(this SqlConnection connection, CommandDefinition command)
        {
            var rows = (await QueryAsync<T>(connection, command).ConfigureAwait(false)).ToList();
            if (rows.Count > 1)
            {
                throw new InvalidOperationException("The procedure returned more than one row.");
            }

            return rows.Count == 0 ? default(T) : rows[0];
        }

        public static async Task<GridReader> QueryMultipleAsync(this SqlConnection connection, CommandDefinition command)
        {
            var sql = Create(connection, command);
            try
            {
                var reader = await sql.ExecuteReaderAsync(command.CancellationToken).ConfigureAwait(false);
                return new GridReader(sql, reader, command.CancellationToken);
            }
            catch
            {
                sql.Dispose();
                throw;
            }
        }

        private static SqlCommand Create(SqlConnection connection, CommandDefinition definition)
        {
            var command = connection.CreateCommand();
            command.CommandText = definition.CommandText;
            command.CommandType = definition.CommandType ?? CommandType.Text;
            if (definition.CommandTimeout.HasValue)
            {
                command.CommandTimeout = definition.CommandTimeout.Value;
            }

            if (definition.Transaction != null)
            {
                command.Transaction = (SqlTransaction)definition.Transaction;
            }

            AddParameters(command, definition.Parameters);
            return command;
        }

        private static void AddParameters(SqlCommand command, object parameters)
        {
            if (parameters == null)
            {
                return;
            }

            var dynamicParameters = parameters as DynamicParameters;
            if (dynamicParameters != null)
            {
                dynamicParameters.AddTo(command);
                return;
            }

            // an anonymous object: each property is a parameter of the same name
            var properties = ParameterProperties.GetOrAdd(parameters.GetType(), t => t.GetProperties(BindingFlags.Public | BindingFlags.Instance));
            foreach (var property in properties)
            {
                command.Parameters.Add(CreateParameter(command, property.Name, property.GetValue(parameters, null), null, null));
            }
        }

        internal static SqlParameter CreateParameter(SqlCommand command, string name, object value, DbType? dbType, int? size)
        {
            var parameter = command.CreateParameter();
            parameter.ParameterName = "@" + name;
            var tvp = value as TableValuedParameter;
            if (tvp != null)
            {
                parameter.SqlDbType = SqlDbType.Structured;
                parameter.TypeName = tvp.TypeName;
                parameter.Value = tvp.Table;
                return parameter;
            }

            var dbString = value as DbString;
            if (dbString != null)
            {
                parameter.DbType = dbString.IsAnsi
                    ? (dbString.IsFixedLength ? DbType.AnsiStringFixedLength : DbType.AnsiString)
                    : (dbString.IsFixedLength ? DbType.StringFixedLength : DbType.String);
                parameter.Size = dbString.Length > 0 ? dbString.Length : StringSize(dbString.Value);
                parameter.Value = (object)dbString.Value ?? DBNull.Value;
                return parameter;
            }

            if (dbType.HasValue)
            {
                parameter.DbType = dbType.Value;
            }
            else if (value != null)
            {
                var inferred = Infer(value.GetType());
                if (inferred.HasValue)
                {
                    parameter.DbType = inferred.Value;
                }
            }
            else
            {
                // null without a type: sent as NULL (nvarchar, as Dapper does)
                parameter.DbType = DbType.String;
            }

            if (size.HasValue)
            {
                parameter.Size = size.Value;
            }
            else if (value is string)
            {
                parameter.Size = StringSize((string)value);
            }

            parameter.Value = value == null ? DBNull.Value : value.GetType().IsEnum ? Convert.ChangeType(value, Enum.GetUnderlyingType(value.GetType()), CultureInfo.InvariantCulture) : value;
            return parameter;
        }

        /// <summary>Strings up to 4000 characters are sent as nvarchar(4000), longer ones as nvarchar(max) (as Dapper does).</summary>
        private static int StringSize(string value)
        {
            return value != null && value.Length > DbString.DefaultLength ? -1 : DbString.DefaultLength;
        }

        private static DbType? Infer(Type type)
        {
            type = Nullable.GetUnderlyingType(type) ?? type;
            if (type.IsEnum)
            {
                type = Enum.GetUnderlyingType(type);
            }

            if (type == typeof(string)) return DbType.String;
            if (type == typeof(int)) return DbType.Int32;
            if (type == typeof(long)) return DbType.Int64;
            if (type == typeof(short)) return DbType.Int16;
            if (type == typeof(byte)) return DbType.Byte;
            if (type == typeof(bool)) return DbType.Boolean;
            if (type == typeof(decimal)) return DbType.Decimal;
            if (type == typeof(double)) return DbType.Double;
            if (type == typeof(float)) return DbType.Single;
            if (type == typeof(DateTime)) return DbType.DateTime2;
            if (type == typeof(DateTimeOffset)) return DbType.DateTimeOffset;
            if (type == typeof(Guid)) return DbType.Guid;
            if (type == typeof(byte[])) return DbType.Binary;
            if (type == typeof(TimeSpan)) return DbType.Time;
            return null;
        }

        internal static async Task<IEnumerable<T>> ReadRowsAsync<T>(DbDataReader reader, CancellationToken cancellationToken)
        {
            var rows = new List<T>();
            var type = typeof(T);
            var scalar = IsScalar(type);
            Dictionary<string, PropertyInfo> properties = null;
            PropertyInfo[] columns = null;
            if (!scalar)
            {
                properties = RowProperties.GetOrAdd(type, t => t.GetProperties(BindingFlags.Public | BindingFlags.Instance)
                    .Where(p => p.CanWrite && p.GetIndexParameters().Length == 0)
                    .GroupBy(p => p.Name, StringComparer.OrdinalIgnoreCase)
                    .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase));
                columns = new PropertyInfo[reader.FieldCount];
                for (var i = 0; i < reader.FieldCount; i++)
                {
                    PropertyInfo property;
                    var name = reader.GetName(i);
                    if (properties.TryGetValue(name, out property) || properties.TryGetValue(name.Replace("_", ""), out property))
                    {
                        columns[i] = property;
                    }
                }
            }

            while (await reader.ReadAsync(cancellationToken).ConfigureAwait(false))
            {
                if (scalar)
                {
                    rows.Add((T)ConvertValue(reader.GetValue(0), type));
                    continue;
                }

                var row = Activator.CreateInstance<T>();
                for (var i = 0; i < columns.Length; i++)
                {
                    var property = columns[i];
                    if (property != null)
                    {
                        property.SetValue(row, ConvertValue(reader.GetValue(i), property.PropertyType), null);
                    }
                }

                rows.Add(row);
            }

            return rows;
        }

        private static bool IsScalar(Type type)
        {
            type = Nullable.GetUnderlyingType(type) ?? type;
            return type.IsPrimitive || type.IsEnum || type == typeof(string) || type == typeof(decimal) || type == typeof(DateTime)
                || type == typeof(DateTimeOffset) || type == typeof(Guid) || type == typeof(byte[]) || type == typeof(TimeSpan);
        }

        /// <summary>A database value as the property's type (DBNull as null / default).</summary>
        internal static object ConvertValue(object value, Type type)
        {
            var underlying = Nullable.GetUnderlyingType(type);
            if (value == null || value is DBNull)
            {
                return type.IsValueType && underlying == null ? Activator.CreateInstance(type) : null;
            }

            var target = underlying ?? type;
            if (target.IsInstanceOfType(value))
            {
                return value;
            }

            if (target.IsEnum)
            {
                return value is string ? Enum.Parse(target, (string)value, true) : Enum.ToObject(target, value);
            }

            if (target == typeof(DateTimeOffset) && value is DateTime)
            {
                return new DateTimeOffset(DateTime.SpecifyKind((DateTime)value, DateTimeKind.Utc));
            }

            if (target == typeof(DateTime) && value is DateTimeOffset)
            {
                return ((DateTimeOffset)value).UtcDateTime;
            }

            if (target == typeof(Guid) && value is string)
            {
                return Guid.Parse((string)value);
            }

            if (target == typeof(string))
            {
                return Convert.ToString(value, CultureInfo.InvariantCulture);
            }

            return Convert.ChangeType(value, target, CultureInfo.InvariantCulture);
        }
    }

    /// <summary>The result sets of one procedure call, read in order.</summary>
    public sealed class GridReader : IDisposable
    {
        private readonly SqlCommand command;
        private readonly DbDataReader reader;
        private readonly CancellationToken cancellationToken;
        private bool first = true;

        internal GridReader(SqlCommand command, DbDataReader reader, CancellationToken cancellationToken)
        {
            this.command = command;
            this.reader = reader;
            this.cancellationToken = cancellationToken;
        }

        public async Task<IEnumerable<T>> ReadAsync<T>()
        {
            if (!first && !await reader.NextResultAsync(cancellationToken).ConfigureAwait(false))
            {
                throw new InvalidOperationException("The procedure returned fewer result sets than expected.");
            }

            first = false;
            return await SqlMapper.ReadRowsAsync<T>(reader, cancellationToken).ConfigureAwait(false);
        }

        public void Dispose()
        {
            reader.Dispose();
            command.Dispose();
        }
    }
}
