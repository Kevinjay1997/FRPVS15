using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using FrpMapper.Api.Contracts.DAL;

namespace FrpMapper.Api.DAL
{
    /// <summary>
    /// The API's log files: the dated files the logger writes next to Logging:FilePath ("App_Data\logs\api.log" gives
    /// api-20261028.log, …). Only those names can be opened, so no other file of the server can be read through it.
    /// </summary>
    public sealed class LogFileStore : ILogFileStore
    {
        private readonly string folder;
        private readonly Regex names;

        /// <param name="logFilePath">Logging:FilePath made absolute; null or empty when the API does not log to a file.</param>
        public LogFileStore(string logFilePath)
        {
            if (string.IsNullOrWhiteSpace(logFilePath))
            {
                return;
            }

            folder = Path.GetDirectoryName(logFilePath);
            var prefix = Regex.Escape(Path.GetFileNameWithoutExtension(logFilePath));
            var extension = Regex.Escape(Path.GetExtension(logFilePath));
            names = new Regex(@"\A" + prefix + @"-\d{8}" + extension + @"\z", RegexOptions.IgnoreCase);
        }

        public IReadOnlyList<LogFileInfo> List()
        {
            if (folder == null || !Directory.Exists(folder))
            {
                return new LogFileInfo[0];
            }

            return new DirectoryInfo(folder).GetFiles()
                .Where(f => names.IsMatch(f.Name))
                .OrderByDescending(f => f.Name, StringComparer.OrdinalIgnoreCase)
                .Select(f => new LogFileInfo { Name = f.Name, Size = f.Length, LastWritten = new DateTimeOffset(f.LastWriteTimeUtc) })
                .ToList();
        }

        public Stream Open(string name)
        {
            if (folder == null || name == null || !names.IsMatch(name))
            {
                return null;
            }

            var path = Path.Combine(folder, name);
            return File.Exists(path) ? new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete) : null;
        }
    }
}
