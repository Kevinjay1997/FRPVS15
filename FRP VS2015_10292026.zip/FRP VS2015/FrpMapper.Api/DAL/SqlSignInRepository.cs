﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL.Sql;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.DAL
{
    /// <summary>frp.usp_SignIn_Check / _Failed / _Succeeded / _Session / _End. The procedures also write the audit trail entries.</summary>
    public sealed class SqlSignInRepository: ISignInRepository
    {
        private readonly ISqlConnectionFactory connections;
        private readonly IAuditContext audit;

        public SqlSignInRepository(ISqlConnectionFactory connections, IAuditContext audit)
    {
        this.connections = connections;
        this.audit = audit;
    }
        public async Task<DateTimeOffset?> GetDelayedUntilAsync(string userName, DateTimeOffset at, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            return await connection.QuerySingleOrDefaultAsync<DateTimeOffset?>(new CommandDefinition(
                "frp.usp_SignIn_Check", new { UserName = userName, OccurredAt = at }, commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
            }
        }

        public async Task<string> RecordFailureAsync(string userName, DateTimeOffset at, string detail, bool countsTowardLockout, int maxFailures, int delayMinutes,
            CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var parameters = new DynamicParameters();
            parameters.Add("@UserName", userName, DbType.String, size: 256);
            parameters.Add("@OccurredAt", at);
            parameters.Add("@Details", detail, DbType.String, size: 500);
            parameters.Add("@MaxFailures", maxFailures);
            parameters.Add("@DelayMinutes", delayMinutes);
            parameters.Add("@CountTowardLockout", countsTowardLockout, DbType.Boolean);
            parameters.Add("@ClientAddress", audit.ClientAddress, DbType.AnsiString, size: 45);
            return await connection.QuerySingleAsync<string>(new CommandDefinition(
                "frp.usp_SignIn_Failed", parameters, commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
            }
        }

        public async Task<SignInResultDto> RecordSuccessAsync(string userName, DateTimeOffset at, string detail, bool isAdministrator, string roles, string sessionId,
            int inactiveDays, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var parameters = new DynamicParameters();
            parameters.Add("@UserName", userName, DbType.String, size: 256);
            parameters.Add("@OccurredAt", at);
            parameters.Add("@Details", detail, DbType.String, size: 500);
            parameters.Add("@IsAdministrator", isAdministrator, DbType.Boolean);
            parameters.Add("@Roles", roles, DbType.String, size: 1000);
            parameters.Add("@SessionId", sessionId, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@InactiveDays", inactiveDays);
            parameters.Add("@Today", DateTime.Now.Date, DbType.Date);
            parameters.Add("@ClientAddress", audit.ClientAddress, DbType.AnsiString, size: 45);
            var row = await connection.QuerySingleAsync<ResultRow>(new CommandDefinition(
                "frp.usp_SignIn_Succeeded", parameters, commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
            return new SignInResultDto { Outcome = row.Outcome, PreviousSignInAt = row.PreviousSignInAt, FailedSinceLast = row.FailedSinceLast, InactiveDays = inactiveDays };
            }
        }

        public async Task<string> GetSessionAsync(string userName, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            return (await connection.QuerySingleOrDefaultAsync<string>(new CommandDefinition(
                "frp.usp_SignIn_Session", new { UserName = userName }, commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken)))?.Trim();
            }
        }

        public async Task<bool> EndSessionAsync(string userName, string sessionId, DateTimeOffset at, string detail, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var parameters = new DynamicParameters();
            parameters.Add("@UserName", userName, DbType.String, size: 256);
            parameters.Add("@SessionId", sessionId, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@OccurredAt", at);
            parameters.Add("@Details", detail, DbType.String, size: 500);
            parameters.Add("@ClientAddress", audit.ClientAddress, DbType.AnsiString, size: 45);
            return await connection.QuerySingleAsync<bool>(new CommandDefinition(
                "frp.usp_SignIn_End", parameters, commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
            }
        }

        private sealed class ResultRow
        {
            public string Outcome { get; set; } = "";
            public DateTimeOffset? PreviousSignInAt { get; set; }
            public int FailedSinceLast { get; set; }
        }
    }

}
