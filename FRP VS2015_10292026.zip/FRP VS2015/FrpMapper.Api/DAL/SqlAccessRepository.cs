﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL.Sql;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.DAL
{
    /// <summary>Roles, permissions, grants, Active Directory groups and Development users from the database.</summary>
    public sealed class SqlAccessRepository: IAccessRepository
    {
        private readonly ISqlConnectionFactory connections;

        public SqlAccessRepository(ISqlConnectionFactory connections)
    {
        this.connections = connections;
    }
        public async Task<AccessCatalogDto> GetCatalogAsync(CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            using (var reader = await connection.QueryMultipleAsync(new CommandDefinition(
                "frp.usp_AccessCatalog_Get",
                commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds,
                cancellationToken: cancellationToken)))
            {
            var roles = (await reader.ReadAsync<RoleRow>()).ToList();
            var permissions = (await reader.ReadAsync<PermissionRow>()).ToList();
            var grants = (await reader.ReadAsync<GrantRow>()).ToList();
            var groups = (await reader.ReadAsync<GroupRow>())
                .GroupBy(g => g.RoleKey, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => (IReadOnlyList<string>)g.Select(x => x.GroupName).ToList(), StringComparer.OrdinalIgnoreCase);
            var users = (await reader.ReadAsync<UserRow>()).ToList();
            var userRoles = (await reader.ReadAsync<UserRoleRow>())
                .GroupBy(r => r.UserName, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => (IReadOnlyList<string>)g.Select(x => x.RoleKey).ToList(), StringComparer.OrdinalIgnoreCase);

            return new AccessCatalogDto
            {
                Roles = roles.Select(r => { IReadOnlyList<string> names; return new AppRoleDto
                {
                    Key = r.RoleKey,
                    DisplayName = r.DisplayName,
                    Description = r.Description,
                    DirectoryGroups = groups.TryGetValue(r.RoleKey, out names) ? names : new List<string>()
                }; }).ToList(),
                Permissions = permissions.Select(p => new AppPermissionDto { Key = p.PermissionKey, DisplayName = p.DisplayName }).ToList(),
                Grants = grants.Select(g => new RolePermissionDto { RoleKey = g.RoleKey, PermissionKey = g.PermissionKey }).ToList(),
                Users = users.Select(u => { IReadOnlyList<string> keys; DateTime until; return new AppUserDto
                {
                    UserName = u.UserName,
                    DisplayName = u.DisplayName,
                    IsActive = u.IsActive,
                    Roles = userRoles.TryGetValue(u.UserName, out keys) ? keys : new List<string>(),
                    AccessUntil = CompatPattern.Is(u.AccessUntil, out until) ? (DateOnly?)DateOnly.FromDateTime(until) : (DateOnly?)null
                }; }).ToList()
            };
            }
            }
        }

        public async Task<IReadOnlyList<DevelopmentUserDto>> GetDevelopmentUsersAsync(CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            using (var reader = await connection.QueryMultipleAsync(new CommandDefinition(
                "frp.usp_DevelopmentUser_List",
                commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds,
                cancellationToken: cancellationToken)))
            {
            var users = (await reader.ReadAsync<DevelopmentUserRow>()).ToList();
            var roles = (await reader.ReadAsync<DevelopmentUserRoleRow>())
                .GroupBy(r => r.DevelopmentUserId)
                .ToDictionary(g => g.Key, g => (IReadOnlyList<string>)g.Select(r => r.RoleKey).ToList());

            return users.Select(u => { IReadOnlyList<string> keys; return new DevelopmentUserDto
            {
                Name = u.UserName,
                Roles = roles.TryGetValue(u.DevelopmentUserId, out keys) ? keys : new List<string>()
            }; }).ToList();
            }
            }
        }

        private sealed class RoleRow
        {
            public string RoleKey { get; set; } = "";
            public string DisplayName { get; set; } = "";
            public string Description { get; set; }
            public int SortOrder { get; set; }
        }

        private sealed class PermissionRow
        {
            public string PermissionKey { get; set; } = "";
            public string DisplayName { get; set; } = "";
            public int SortOrder { get; set; }
        }

        private sealed class GrantRow
        {
            public string RoleKey { get; set; } = "";
            public string PermissionKey { get; set; } = "";
        }

        private sealed class GroupRow
        {
            public string RoleKey { get; set; } = "";
            public string GroupName { get; set; } = "";
        }

        private sealed class UserRow
        {
            public string UserName { get; set; } = "";
            public string DisplayName { get; set; }
            public bool IsActive { get; set; }
            public DateTime? AccessUntil { get; set; }
        }

        private sealed class UserRoleRow
        {
            public string UserName { get; set; } = "";
            public string RoleKey { get; set; } = "";
        }

        private sealed class DevelopmentUserRow
        {
            public int DevelopmentUserId { get; set; }
            public string UserName { get; set; } = "";
        }

        private sealed class DevelopmentUserRoleRow
        {
            public int DevelopmentUserId { get; set; }
            public string RoleKey { get; set; } = "";
        }
    }

}
