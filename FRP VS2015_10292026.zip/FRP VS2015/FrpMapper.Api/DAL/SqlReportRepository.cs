﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL.Sql;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.DAL
{
    /// <summary>frp.usp_Report_AccessChanges / _BankChanges / _Users / _SignIns (read only).</summary>
    public sealed class SqlReportRepository: IReportRepository
    {
        private readonly ISqlConnectionFactory connections;

        public SqlReportRepository(ISqlConnectionFactory connections)
    {
        this.connections = connections;
    }
        public async Task<AccessChangeHistory> GetAccessChangesAsync(DateTimeOffset to, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            using (var reader = await connection.QueryMultipleAsync(new CommandDefinition("frp.usp_Report_AccessChanges", new { To = to },
                commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken)))
            {
            var requests = (await reader.ReadAsync<SqlAccessAdminRepository.RequestRow>()).Select(SqlAccessAdminRepository.ToDto).ToList();
            var users = (await reader.ReadAsync<TargetRow>()).Select(r => new ReportTarget(r.UserName, r.DisplayName, r.CreatedAtUtc, r.UpdatedAtUtc)).ToList();
            var roles = (await reader.ReadAsync<TargetRow>()).Select(r => new ReportTarget(r.RoleKey, r.DisplayName, r.CreatedAtUtc, null)).ToList();
            return new AccessChangeHistory(requests, users, roles);
            }
            }
        }

        public async Task<BankChangeHistory> GetBankChangesAsync(DateTimeOffset to, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            using (var reader = await connection.QueryMultipleAsync(new CommandDefinition("frp.usp_Report_BankChanges", new { To = to },
                commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken)))
            {
            var requests = (await reader.ReadAsync<SqlReferenceDataRepository.RequestRow>()).Select(SqlReferenceDataRepository.ToDto).ToList();
            var banks = (await reader.ReadAsync<TargetRow>()).Select(r => new ReportTarget(r.BankKey, null, r.CreatedAtUtc, r.UpdatedAtUtc)).ToList();
            return new BankChangeHistory(requests, banks);
            }
            }
        }

        public async Task<UserReportData> GetUsersAsync(CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            using (var reader = await connection.QueryMultipleAsync(new CommandDefinition("frp.usp_Report_Users",
                commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken)))
            {
            var users = (await reader.ReadAsync<UserRow>()).ToList();
            var roles = (await reader.ReadAsync<VT_Owner_Value<string, string>>())
                .GroupBy(r => r.Owner, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => (IReadOnlyList<string>)g.Select(r => r.Value).ToList(), StringComparer.OrdinalIgnoreCase);
            var signIns = (await reader.ReadAsync<SignInRow>()).Select(r => new ReportSignIn(r.UserName, r.LastSignInAt, r.LastRoles)).ToList();
            return new UserReportData(
                users.Select(u => { DateTime until; IReadOnlyList<string> keys; return new ReportUser(u.UserName, u.DisplayName, u.Department, CompatPattern.Is(u.AccessUntil, out until) ? (DateOnly?)DateOnly.FromDateTime(until) : (DateOnly?)null, u.IsActive,
                    u.DisabledReasonKey, u.IsDeleted, u.DeletedAtUtc, u.CreatedAtUtc, u.UpdatedAtUtc, roles.TryGetValue(u.UserName, out keys) ? keys : new List<string>()); }).ToList(),
                signIns);
            }
            }
        }

        public async Task<IReadOnlyList<AuditEntryDto>> GetSignInsAsync(DateTimeOffset from, DateTimeOffset to, string userName, int take, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var parameters = new DynamicParameters();
            parameters.Add("@From", from);
            parameters.Add("@To", to);
            parameters.Add("@UserName", userName, DbType.String, size: 256);
            parameters.Add("@Take", take);
            var rows = await connection.QueryAsync<AuditRow>(new CommandDefinition("frp.usp_Report_SignIns", parameters,
                commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
            return rows.Select(r => new AuditEntryDto
            {
                Id = r.EntryKey, At = r.OccurredAt, User = r.UserName, Action = r.Action, ProjectId = r.ProjectId, ProjectName = r.ProjectName, Details = r.Details, Address = r.ClientAddress
            }).ToList();
            }
        }

        private sealed class TargetRow
        {
            public string UserName { get; set; }
            public string RoleKey { get; set; }
            public string BankKey { get; set; }
            public string DisplayName { get; set; }
            public DateTime CreatedAtUtc { get; set; }
            public DateTime? UpdatedAtUtc { get; set; }
        }

        private sealed class UserRow
        {
            public string UserName { get; set; } = "";
            public string DisplayName { get; set; }
            public string Department { get; set; }
            public DateTime? AccessUntil { get; set; }
            public bool IsActive { get; set; }
            public string DisabledReasonKey { get; set; }
            public bool IsDeleted { get; set; }
            public DateTime? DeletedAtUtc { get; set; }
            public DateTime CreatedAtUtc { get; set; }
            public DateTime UpdatedAtUtc { get; set; }
        }

        private sealed class SignInRow
        {
            public string UserName { get; set; } = "";
            public DateTimeOffset? LastSignInAt { get; set; }
            public string LastRoles { get; set; }
        }

        private sealed class AuditRow
        {
            public string EntryKey { get; set; } = "";
            public DateTimeOffset OccurredAt { get; set; }
            public string UserName { get; set; } = "";
            public string Action { get; set; } = "";
            public string ProjectId { get; set; }
            public string ProjectName { get; set; }
            public string Details { get; set; }
            public string ClientAddress { get; set; }
        }
    }

}
