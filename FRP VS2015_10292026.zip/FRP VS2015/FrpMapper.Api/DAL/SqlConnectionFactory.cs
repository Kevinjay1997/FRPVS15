using System;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Models;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Api.DAL
{
    /// <summary>Opens connections to the FRP Mapper database. Only the DAL uses it.</summary>
    public interface ISqlConnectionFactory
    {
        Task<SqlConnection> OpenAsync(CancellationToken cancellationToken);

        int CommandTimeoutSeconds { get; }
    }

    public sealed class SqlConnectionFactory : ISqlConnectionFactory
    {
        private readonly string connectionString;

        public SqlConnectionFactory(IConfiguration configuration, IOptions<DatabaseOptions> options)
        {
            var settings = options.Value;
            if (string.IsNullOrWhiteSpace(settings.ConnectionStringName))
            {
                throw new InvalidOperationException("Database:ConnectionStringName is not set in web.config.");
            }

            var value = configuration.GetConnectionString(settings.ConnectionStringName);
            if (string.IsNullOrEmpty(value))
            {
                throw new InvalidOperationException(
                    "The connection string ConnectionStrings:" + settings.ConnectionStringName + " is not configured. Set it in the environment variable ConnectionStrings__"
                    + settings.ConnectionStringName + " or in the <connectionStrings> section of FrpMapper.Api's Web.config (name \"" + settings.ConnectionStringName + "\").");
            }

            connectionString = value;
            if (settings.CommandTimeoutSeconds <= 0)
            {
                throw new InvalidOperationException("Database:CommandTimeoutSeconds must be greater than 0.");
            }

            CommandTimeoutSeconds = settings.CommandTimeoutSeconds;
        }

        public int CommandTimeoutSeconds { get; private set; }

        public async Task<SqlConnection> OpenAsync(CancellationToken cancellationToken)
        {
            var connection = new SqlConnection(connectionString);
            try
            {
                await connection.OpenAsync(cancellationToken);
                return connection;
            }
            catch
            {
                connection.Dispose();
                throw;
            }
        }
    }
}
