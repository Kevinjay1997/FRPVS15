﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL.Sql;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.DAL
{
    /// <summary>frp.WorkbenchConfig through its stored procedures (011_workbench_tools.sql).</summary>
    public sealed class SqlWorkbenchConfigRepository : IWorkbenchConfigRepository
    {
        private readonly ISqlConnectionFactory connections;
        private readonly IAuditContext audit;

        public SqlWorkbenchConfigRepository(ISqlConnectionFactory connections, IAuditContext audit)
        {
            this.connections = connections;
            this.audit = audit;
        }

        public async Task<IReadOnlyList<WorkbenchConfigVersionDto>> ListAsync(string kind, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@ConfigKind", kind, DbType.AnsiString, size: 20);
                var rows = await connection.QueryAsync<Row>(new CommandDefinition("frp.usp_WorkbenchConfig_List", parameters, commandType: CommandType.StoredProcedure,
                    commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                return rows.Select(ToDto).ToList();
            }
        }

        public Task<StoredWorkbenchConfig> GetAsync(string configId, CancellationToken cancellationToken)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@ConfigId", configId, DbType.AnsiStringFixedLength, size: 32);
            return ReadOneAsync("frp.usp_WorkbenchConfig_Get", parameters, cancellationToken);
        }

        public Task<StoredWorkbenchConfig> GetActiveAsync(string kind, CancellationToken cancellationToken)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@ConfigKind", kind, DbType.AnsiString, size: 20);
            return ReadOneAsync("frp.usp_WorkbenchConfig_GetActive", parameters, cancellationToken);
        }

        private async Task<StoredWorkbenchConfig> ReadOneAsync(string procedure, DynamicParameters parameters, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
                var row = await connection.QuerySingleOrDefaultAsync<Row>(new CommandDefinition(procedure, parameters, commandType: CommandType.StoredProcedure,
                    commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                return row == null ? null : new StoredWorkbenchConfig { Version = ToDto(row), Content = row.Content ?? "" };
            }
        }

        public async Task<WorkbenchConfigVersionDto> RequestAsync(StoredWorkbenchConfig config, CancellationToken cancellationToken)
        {
            var version = config.Version;
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@ConfigId", version.Id, DbType.AnsiStringFixedLength, size: 32);
                parameters.Add("@ConfigKind", version.Kind, DbType.AnsiString, size: 20);
                parameters.Add("@SourceFiles", version.SourceFiles, DbType.String, size: 400);
                parameters.Add("@Note", version.Note, DbType.String, size: 1000);
                parameters.Add("@Summary", JsonSerializer.Serialize(version.Summary), DbType.String, size: -1);
                parameters.Add("@Content", config.Content, DbType.String, size: -1);
                parameters.Add("@ContentHash", version.ContentHash, DbType.AnsiStringFixedLength, size: 64);
                parameters.Add("@RequestedBy", version.RequestedBy, DbType.String, size: 256);
                parameters.Add("@RequestedAt", version.RequestedAt);
                parameters.Add("@ClientAddress", audit.ClientAddress, DbType.AnsiString, size: 45);
                try
                {
                    var rowVersion = await connection.ExecuteScalarAsync<byte[]>(new CommandDefinition("frp.usp_WorkbenchConfig_Request", parameters,
                        commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                    version.Version = Convert.ToBase64String(rowVersion ?? new byte[0]);
                    version.Status = WorkbenchConfigStatus.Pending;
                    return version;
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.AccessRequestOpen))
                {
                    throw new AccessRequestOpenException(ex.Message);
                }
            }
        }

        public async Task<bool> DecideAsync(string configId, byte[] expectedVersion, string decision, string decidedBy, DateTimeOffset decidedAt, string comment,
            CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@ConfigId", configId, DbType.AnsiStringFixedLength, size: 32);
                parameters.Add("@ExpectedRowVersion", expectedVersion, DbType.Binary, size: 8);
                parameters.Add("@Decision", decision, DbType.AnsiString, size: 10);
                parameters.Add("@DecidedBy", decidedBy, DbType.String, size: 256);
                parameters.Add("@DecidedAt", decidedAt);
                parameters.Add("@Comment", comment, DbType.String, size: 1000);
                parameters.Add("@ClientAddress", audit.ClientAddress, DbType.AnsiString, size: 45);
                try
                {
                    await connection.ExecuteAsync(new CommandDefinition("frp.usp_WorkbenchConfig_Decide", parameters,
                        commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                    return true;
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.NotFound))
                {
                    return false;
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.ConcurrencyConflict))
                {
                    throw new ConcurrencyConflictException(ex.Message);
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.AccessDecisionRefused))
                {
                    throw new AccessDecisionRefusedException(ex.Message);
                }
            }
        }

        private static WorkbenchConfigVersionDto ToDto(Row r)
        {
            return new WorkbenchConfigVersionDto
            {
                Id = r.ConfigId, Kind = r.ConfigKind, Status = r.StatusKey, SourceFiles = r.SourceFiles, Note = r.Note,
                Summary = string.IsNullOrEmpty(r.Summary) ? new WorkbenchConfigSummaryDto() : JsonSerializer.Deserialize<WorkbenchConfigSummaryDto>(r.Summary),
                ContentHash = r.ContentHash, RequestedBy = r.RequestedBy, RequestedAt = r.RequestedAt, DecidedBy = r.DecidedBy, DecidedAt = r.DecidedAt,
                DecisionComment = r.DecisionComment, Version = Convert.ToBase64String(r.RowVersion ?? new byte[0])
            };
        }

        private static bool Has(System.Data.SqlClient.SqlException ex, int number)
        {
            return ex.Errors.Cast<System.Data.SqlClient.SqlError>().Any(e => e.Number == number);
        }

        internal sealed class Row
        {
            public string ConfigId { get; set; } = "";
            public string ConfigKind { get; set; } = "";
            public string StatusKey { get; set; } = "";
            public string SourceFiles { get; set; } = "";
            public string Note { get; set; }
            public string Summary { get; set; } = "";
            public string Content { get; set; }
            public string ContentHash { get; set; } = "";
            public string RequestedBy { get; set; } = "";
            public DateTimeOffset RequestedAt { get; set; }
            public string DecidedBy { get; set; }
            public DateTimeOffset? DecidedAt { get; set; }
            public string DecisionComment { get; set; }
            public byte[] RowVersion { get; set; } = new byte[0];
        }
    }
}
