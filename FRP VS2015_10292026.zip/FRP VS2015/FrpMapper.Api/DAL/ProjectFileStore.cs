﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Api.DAL
{
    /// <summary>Project files on disk under FileStorage:RootPath; see <see cref="IProjectFileStore"/>.</summary>
    public sealed class ProjectFileStore: IProjectFileStore
    {
        private readonly IOptionsMonitor<FileStorageOptions> options;
        private readonly IWebHostEnvironment environment;

        public ProjectFileStore(IOptionsMonitor<FileStorageOptions> options, IWebHostEnvironment environment)
    {
        this.options = options;
        this.environment = environment;
    }
        private static readonly StringComparison PathComparison = CompatOs.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;

        private string Root
        {
            get
            {
                var configured = options.CurrentValue.RootPath;
                var root = Path.IsPathRooted(configured) ? configured : Path.Combine(environment.ContentRootPath, configured);
                return TrimEndingDirectorySeparator(Path.GetFullPath(root));
            }
        }

        /// <summary>The path without a trailing separator, except for a root such as C:\ (Path.TrimEndingDirectorySeparator).</summary>
        private static string TrimEndingDirectorySeparator(string path)
        {
            if (path.Length > 1 && (path.EndsWith(Path.DirectorySeparatorChar) || path.EndsWith(Path.AltDirectorySeparatorChar))
                && Path.GetPathRoot(path) != path)
            {
                return path.Substring(0, path.Length - 1);
            }

            return path;
        }

        public string GetProjectDirectory(string projectId)
        {
            if (!ProjectIds.IsValid(projectId))
            {
                throw new ArgumentException("Invalid project id.", nameof(projectId));
            }

            return Path.Combine(Root, projectId);
        }

        public async Task<StoredUpload> StoreUploadAsync(IFormFile file, CancellationToken cancellationToken)
        {
            var folder = Path.Combine(Root, options.CurrentValue.SharedUploadsFolder);
            Directory.CreateDirectory(folder);
            var extension = SafeExtension(file.FileName);

            // Copy to a temporary file while hashing, so the content is read once.
            var temporary = Path.Combine(folder, $".upload-{Guid.NewGuid():N}.tmp");
            string sha256;
            try
            {
                using (var hash = SHA256.Create())
                {
                    using (var source = file.OpenReadStream())
                    {
                    using (var target = File.Create(temporary))
                    {
                    var buffer = new byte[81920];
                    int read;
                    while ((read = await source.ReadAsync(buffer, cancellationToken)) > 0)
                    {
                        hash.TransformBlock(buffer, 0, read, null, 0);
                        await target.WriteAsync(buffer, 0, read, cancellationToken);
                    }

                    hash.TransformFinalBlock(new byte[0], 0, 0);
                    sha256 = CompatHex.ToHexString(hash.Hash).ToLowerInvariant();
                    }
                    }
                }

                var fullPath = UploadPath(sha256, extension);
                if (await HasContentAsync(fullPath, sha256, new FileInfo(temporary).Length, cancellationToken))
                {
                    return new StoredUpload(fullPath, sha256, Reused: true);
                }

                // New content (or a stored copy that no longer matches its hash): keep this upload under its hash.
                Directory.CreateDirectory(Path.GetDirectoryName(fullPath));
                // File.Move cannot overwrite in .NET Framework: a damaged stored copy is replaced.
                if (File.Exists(fullPath))
                {
                    File.Delete(fullPath);
                }

                File.Move(temporary, fullPath);
                return new StoredUpload(fullPath, sha256, Reused: false);
            }
            finally
            {
                if (File.Exists(temporary))
                {
                    File.Delete(temporary);
                }
            }
        }

        public bool IsUploadStored(string sha256, string extension)
        {
            if (sha256.Length != 64 || sha256.Any(ch => !CompatChar.IsAsciiHexDigitLower(ch)))
            {
                return false;
            }

            var safe = extension.ToLowerInvariant();
            return options.CurrentValue.AllowedExtensions.Values.SelectMany(list => list).Contains(safe, StringComparer.OrdinalIgnoreCase)
                   && File.Exists(UploadPath(sha256, safe));
        }

        private string UploadPath(string sha256, string extension) =>
            Path.Combine(Root, options.CurrentValue.SharedUploadsFolder, sha256.Substring(0, 2), sha256 + extension);

        /// <summary>True when the stored file exists with this size and SHA-256 (a damaged or changed copy is not reused).</summary>
        private static async Task<bool> HasContentAsync(string path, string sha256, long size, CancellationToken cancellationToken)
        {
            var info = new FileInfo(path);
            if (!info.Exists || info.Length != size)
            {
                return false;
            }

            using (var stream = File.OpenRead(path))
            {
            var actual = CompatHex.ToHexString(await CompatHash.Sha256Async(stream, cancellationToken)).ToLowerInvariant();
            return actual == sha256;
            }
        }

        public async Task<string> SaveFileAsync(string projectId, string fileName, byte[] content, CancellationToken cancellationToken)
        {
            var directory = GetProjectDirectory(projectId);
            Directory.CreateDirectory(directory);
            var safeName = string.Concat(Path.GetFileName(fileName).Where(ch => char.IsLetterOrDigit(ch) || ch == '.' || ch == '_' || ch == '-')).TrimStart('.');
            var fullPath = Path.Combine(directory, string.IsNullOrWhiteSpace(safeName) ? "file.bin" : safeName);
            await CompatFile.WriteAllBytesAsync(fullPath, content, cancellationToken);
            return fullPath;
        }

        public string ToStoredPath(string fullPath)
        {
            var root = Root + Path.DirectorySeparatorChar;
            var full = Path.GetFullPath(fullPath);
            if (!full.StartsWith(root, PathComparison))
            {
                throw new InvalidOperationException("A project file is outside the file storage folder (FileStorage:RootPath).");
            }

            return full.Substring(root.Length).Replace(Path.DirectorySeparatorChar, '/');
        }

        public string ToFullPath(string storedPath)
        {
            if (string.IsNullOrWhiteSpace(storedPath) || Path.IsPathRooted(storedPath)
                || storedPath.Split('/', '\\').Any(segment => segment == "" || segment == "." || segment == ".."))
            {
                throw new InvalidOperationException("The database holds an invalid project file path.");
            }

            var root = Root;
            var full = Path.GetFullPath(Path.Combine(root, storedPath.Replace('/', Path.DirectorySeparatorChar)));
            if (!full.StartsWith(root + Path.DirectorySeparatorChar, PathComparison))
            {
                throw new InvalidOperationException("The database holds an invalid project file path.");
            }

            return full;
        }

        /// <summary>The upload's extension when it is one of the configured upload extensions; otherwise ".bin".</summary>
        private string SafeExtension(string fileName)
        {
            var extension = Path.GetExtension(fileName).ToLowerInvariant();
            var allowed = options.CurrentValue.AllowedExtensions.Values.SelectMany(list => list);
            return allowed.Contains(extension, StringComparer.OrdinalIgnoreCase) ? extension : ".bin";
        }
    }

}
