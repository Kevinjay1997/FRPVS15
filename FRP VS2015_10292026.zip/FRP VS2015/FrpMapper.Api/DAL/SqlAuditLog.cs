﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL.Sql;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.DAL
{
    /// <summary>
    /// The audit trail in frp.AuditEntry (frp.usp_AuditEntry_Insert / frp.usp_AuditEntry_List). The table only accepts
    /// inserts: a trigger rejects every UPDATE and DELETE.
    /// </summary>
    public sealed class SqlAuditLog: IAuditLog
    {
        private readonly ISqlConnectionFactory connections;
        private readonly IAuditContext audit;

        public SqlAuditLog(ISqlConnectionFactory connections, IAuditContext audit)
    {
        this.connections = connections;
        this.audit = audit;
    }
        public async Task AppendAsync(AuditEntryDto entry, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            // DynamicParameters (not DbString) so a null ProjectId is sent as SQL NULL.
            var parameters = new DynamicParameters();
            parameters.Add("@EntryKey", entry.Id, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@OccurredAt", entry.At);
            parameters.Add("@UserName", entry.User);
            parameters.Add("@Action", entry.Action);
            parameters.Add("@ProjectId", entry.ProjectId, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@ProjectName", entry.ProjectName);
            parameters.Add("@Details", entry.Details);
            // The address the person works from: given with the entry, or that of the current request.
            parameters.Add("@ClientAddress", entry.Address ?? audit.ClientAddress, DbType.AnsiString, size: 45);
            await connection.ExecuteAsync(new CommandDefinition(
                "frp.usp_AuditEntry_Insert",
                parameters,
                commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds,
                cancellationToken: cancellationToken));
            }
        }

        public Task<IReadOnlyList<AuditEntryDto>> QueryAsync(string projectId, int take, CancellationToken cancellationToken) =>
            ListAsync(projectId, null, take, cancellationToken);

        public Task<IReadOnlyList<AuditEntryDto>> QueryByUserAsync(string userName, int take, CancellationToken cancellationToken) =>
            ListAsync(null, userName, take, cancellationToken);

        public async Task<AuditPageDto> QueryPageAsync(string projectId, string search, string action, int skip, int take, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var parameters = new DynamicParameters();
            parameters.Add("@ProjectId", projectId, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@Search", search, DbType.String, size: 200);
            parameters.Add("@Action", action, DbType.String, size: 200);
            parameters.Add("@Skip", skip);
            parameters.Add("@Take", take);
            using (var reader = await connection.QueryMultipleAsync(new CommandDefinition(
                "frp.usp_AuditEntry_Page",
                parameters,
                commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds,
                cancellationToken: cancellationToken)))
            {
            var total = (await reader.ReadAsync<TotalRow>()).Select(r => r.Total).FirstOrDefault();
            var entries = (await reader.ReadAsync<AuditRow>()).Select(ToEntry).ToList();
            var actions = (await reader.ReadAsync<ActionRow>()).Select(r => r.Action).ToList();
            return new AuditPageDto { Entries = entries, Total = total, Actions = actions };
            }
            }
        }

        private static AuditEntryDto ToEntry(AuditRow r)
        {
            return new AuditEntryDto
            {
                Id = r.EntryKey,
                At = r.OccurredAt,
                User = r.UserName,
                Action = r.Action,
                ProjectId = r.ProjectId,
                ProjectName = r.ProjectName,
                Details = r.Details,
                Address = r.ClientAddress
            };
        }

        private async Task<IReadOnlyList<AuditEntryDto>> ListAsync(string projectId, string userName, int take, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var parameters = new DynamicParameters();
            parameters.Add("@ProjectId", projectId, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@Take", take);
            parameters.Add("@UserName", userName, DbType.String, size: 256);
            var rows = await connection.QueryAsync<AuditRow>(new CommandDefinition(
                "frp.usp_AuditEntry_List",
                parameters,
                commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds,
                cancellationToken: cancellationToken));

            return rows.Select(ToEntry).ToList();
            }
        }

        private sealed class TotalRow
        {
            public int Total { get; set; }
        }

        private sealed class ActionRow
        {
            public string Action { get; set; } = "";
        }

        private sealed class AuditRow
        {
            public string EntryKey { get; set; } = "";
            public DateTimeOffset OccurredAt { get; set; }
            public string UserName { get; set; } = "";
            public string Action { get; set; } = "";
            public string ProjectId { get; set; }
            public string ProjectName { get; set; }
            public string Details { get; set; }
            public string ClientAddress { get; set; }
        }
    }

}
