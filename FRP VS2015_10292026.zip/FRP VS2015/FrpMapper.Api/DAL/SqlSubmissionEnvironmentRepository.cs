using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL.Sql;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.DAL
{
    /// <summary>frp.SubmissionEnvironment through its stored procedures (010_submission_environments.sql).</summary>
    public sealed class SqlSubmissionEnvironmentRepository : ISubmissionEnvironmentRepository
    {
        private readonly ISqlConnectionFactory connections;
        private readonly IAuditContext audit;

        public SqlSubmissionEnvironmentRepository(ISqlConnectionFactory connections, IAuditContext audit)
        {
            this.connections = connections;
            this.audit = audit;
        }

        public async Task<IReadOnlyList<SubmissionEnvironmentDto>> ListAsync(CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
                var rows = await connection.QueryAsync<Row>(new CommandDefinition("frp.usp_SubmissionEnvironment_List", commandType: CommandType.StoredProcedure,
                    commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                return rows.Select(ToDto).ToList();
            }
        }

        public async Task<SubmissionEnvironmentDto> RequestAsync(SubmissionEnvironmentDto environment, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@EnvironmentId", environment.Id, DbType.AnsiStringFixedLength, size: 32);
                parameters.Add("@EnvironmentKey", environment.Key, DbType.AnsiString, size: 32);
                parameters.Add("@DisplayName", environment.Name, DbType.String, size: 100);
                parameters.Add("@KindKey", environment.Kind, DbType.AnsiString, size: 10);
                parameters.Add("@BaseUrl", environment.BaseUrl, DbType.String, size: 300);
                parameters.Add("@SubmitPath", environment.SubmitPath, DbType.String, size: 200);
                parameters.Add("@StatusPath", environment.StatusPath, DbType.String, size: 200);
                parameters.Add("@ResultPdfPath", environment.ResultPdfPath, DbType.String, size: 200);
                parameters.Add("@ResultXmlPath", environment.ResultXmlPath, DbType.String, size: 200);
                parameters.Add("@ResultExcelPath", environment.ResultExcelPath, DbType.String, size: 200);
                parameters.Add("@ReceiptPath", environment.ReceiptPath, DbType.String, size: 200);
                parameters.Add("@SortOrder", environment.SortOrder, DbType.Int32);
                parameters.Add("@RequestedBy", environment.RequestedBy, DbType.String, size: 256);
                parameters.Add("@RequestedAt", environment.RequestedAt);
                parameters.Add("@ClientAddress", audit.ClientAddress, DbType.AnsiString, size: 45);
                try
                {
                    var version = await connection.ExecuteScalarAsync<byte[]>(new CommandDefinition("frp.usp_SubmissionEnvironment_Request", parameters,
                        commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                    environment.Version = Convert.ToBase64String(version ?? new byte[0]);
                    environment.Status = SubmissionEnvironmentStatus.Pending;
                    return environment;
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.AccessRequestOpen))
                {
                    throw new AccessRequestOpenException(ex.Message);
                }
            }
        }

        public async Task<bool> DecideAsync(string environmentId, byte[] expectedVersion, string decision, string decidedBy, DateTimeOffset decidedAt, string comment,
            CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@EnvironmentId", environmentId, DbType.AnsiStringFixedLength, size: 32);
                parameters.Add("@ExpectedRowVersion", expectedVersion, DbType.Binary, size: 8);
                parameters.Add("@Decision", decision, DbType.AnsiString, size: 10);
                parameters.Add("@DecidedBy", decidedBy, DbType.String, size: 256);
                parameters.Add("@DecidedAt", decidedAt);
                parameters.Add("@Comment", comment, DbType.String, size: 1000);
                parameters.Add("@ClientAddress", audit.ClientAddress, DbType.AnsiString, size: 45);
                try
                {
                    await connection.ExecuteAsync(new CommandDefinition("frp.usp_SubmissionEnvironment_Decide", parameters,
                        commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                    return true;
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.NotFound))
                {
                    return false;
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.ConcurrencyConflict))
                {
                    throw new ConcurrencyConflictException(ex.Message);
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.AccessDecisionRefused))
                {
                    throw new AccessDecisionRefusedException(ex.Message);
                }
            }
        }

        public async Task<SubmissionEnvironmentDto> GetActiveAsync(string key, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@EnvironmentKey", key, DbType.AnsiString, size: 32);
                var row = await connection.QuerySingleOrDefaultAsync<Row>(new CommandDefinition("frp.usp_SubmissionEnvironment_GetActive", parameters,
                    commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                return row == null ? null : ToDto(row);
            }
        }

        private static SubmissionEnvironmentDto ToDto(Row r)
        {
            return new SubmissionEnvironmentDto
            {
                Id = r.EnvironmentId, Key = r.EnvironmentKey, Name = r.DisplayName, Kind = r.KindKey, BaseUrl = r.BaseUrl,
                SubmitPath = r.SubmitPath, StatusPath = r.StatusPath, ResultPdfPath = r.ResultPdfPath, ResultXmlPath = r.ResultXmlPath,
                ResultExcelPath = r.ResultExcelPath, ReceiptPath = r.ReceiptPath, SortOrder = r.SortOrder, Status = r.StatusKey,
                RequestedBy = r.RequestedBy, RequestedAt = r.RequestedAt, DecidedBy = r.DecidedBy, DecidedAt = r.DecidedAt,
                DecisionComment = r.DecisionComment, Version = Convert.ToBase64String(r.RowVersion ?? new byte[0])
            };
        }

        private static bool Has(System.Data.SqlClient.SqlException ex, int number)
        {
            return ex.Errors.Cast<System.Data.SqlClient.SqlError>().Any(e => e.Number == number);
        }

        internal sealed class Row
        {
            public string EnvironmentId { get; set; } = "";
            public string EnvironmentKey { get; set; } = "";
            public string DisplayName { get; set; } = "";
            public string KindKey { get; set; } = "";
            public string BaseUrl { get; set; } = "";
            public string SubmitPath { get; set; } = "";
            public string StatusPath { get; set; } = "";
            public string ResultPdfPath { get; set; } = "";
            public string ResultXmlPath { get; set; } = "";
            public string ResultExcelPath { get; set; } = "";
            public string ReceiptPath { get; set; } = "";
            public int SortOrder { get; set; }
            public string StatusKey { get; set; } = "";
            public string RequestedBy { get; set; } = "";
            public DateTimeOffset RequestedAt { get; set; }
            public string DecidedBy { get; set; }
            public DateTimeOffset? DecidedAt { get; set; }
            public string DecisionComment { get; set; }
            public byte[] RowVersion { get; set; } = new byte[0];
        }
    }
}
