using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL.Sql;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.DAL
{
    /// <summary>frp.BankCertificate through its stored procedures (007_bank_certificates.sql).</summary>
    public sealed class SqlBankCertificateRepository : IBankCertificateRepository
    {
        private readonly ISqlConnectionFactory connections;
        private readonly IAuditContext audit;

        public SqlBankCertificateRepository(ISqlConnectionFactory connections, IAuditContext audit)
        {
            this.connections = connections;
            this.audit = audit;
        }

        public async Task<IReadOnlyList<BankCertificateDto>> ListAsync(CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
                var rows = await connection.QueryAsync<Row>(new CommandDefinition("frp.usp_BankCertificate_List", commandType: CommandType.StoredProcedure,
                    commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                return rows.Select(ToDto).ToList();
            }
        }

        public async Task<BankCertificateDto> RequestAsync(BankCertificateDto certificate, byte[] protectedPfx, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@CertificateId", certificate.Id, DbType.AnsiStringFixedLength, size: 32);
                parameters.Add("@BankKey", certificate.BankKey, DbType.AnsiString, size: 32);
                parameters.Add("@Protected", protectedPfx, DbType.Binary, size: -1);
                parameters.Add("@FileName", certificate.FileName, DbType.String, size: 260);
                parameters.Add("@Subject", certificate.Subject, DbType.String, size: 1000);
                parameters.Add("@Issuer", certificate.Issuer, DbType.String, size: 1000);
                parameters.Add("@Thumbprint", certificate.Thumbprint, DbType.AnsiStringFixedLength, size: 40);
                parameters.Add("@ValidFrom", certificate.ValidFrom, DbType.DateTime2);
                parameters.Add("@ValidUntil", certificate.ValidUntil, DbType.DateTime2);
                parameters.Add("@RequestedBy", certificate.RequestedBy, DbType.String, size: 256);
                parameters.Add("@RequestedAt", certificate.RequestedAt);
                parameters.Add("@ClientAddress", audit.ClientAddress, DbType.AnsiString, size: 45);
                try
                {
                    var version = await connection.ExecuteScalarAsync<byte[]>(new CommandDefinition("frp.usp_BankCertificate_Request", parameters,
                        commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                    certificate.Version = Convert.ToBase64String(version ?? new byte[0]);
                    certificate.Status = BankCertificateStatus.Pending;
                    return certificate;
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.AccessRequestOpen))
                {
                    throw new AccessRequestOpenException(ex.Message);
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.NotFound))
                {
                    throw new BL.WorkflowException(BL.WorkflowErrorKind.Invalid, "This bank profile does not exist. Approve the bank profile first.");
                }
            }
        }

        public async Task<bool> DecideAsync(string certificateId, byte[] expectedVersion, string decision, string decidedBy, DateTimeOffset decidedAt, string comment,
            CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@CertificateId", certificateId, DbType.AnsiStringFixedLength, size: 32);
                parameters.Add("@ExpectedRowVersion", expectedVersion, DbType.Binary, size: 8);
                parameters.Add("@Decision", decision, DbType.AnsiString, size: 10);
                parameters.Add("@DecidedBy", decidedBy, DbType.String, size: 256);
                parameters.Add("@DecidedAt", decidedAt);
                parameters.Add("@Comment", comment, DbType.String, size: 1000);
                parameters.Add("@ClientAddress", audit.ClientAddress, DbType.AnsiString, size: 45);
                try
                {
                    await connection.ExecuteAsync(new CommandDefinition("frp.usp_BankCertificate_Decide", parameters,
                        commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                    return true;
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.NotFound))
                {
                    return false;
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.ConcurrencyConflict))
                {
                    throw new ConcurrencyConflictException(ex.Message);
                }
                catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.AccessDecisionRefused))
                {
                    throw new AccessDecisionRefusedException(ex.Message);
                }
            }
        }

        public async Task<StoredBankCertificate> GetActiveAsync(string bankKey, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
                var parameters = new DynamicParameters();
                parameters.Add("@BankKey", bankKey, DbType.AnsiString, size: 32);
                return await connection.QuerySingleOrDefaultAsync<StoredBankCertificate>(new CommandDefinition("frp.usp_BankCertificate_GetActive", parameters,
                    commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
            }
        }

        private static BankCertificateDto ToDto(Row r)
        {
            return new BankCertificateDto
            {
                Id = r.CertificateId, BankKey = r.BankKey, Status = r.StatusKey, FileName = r.FileName, Subject = r.Subject, Issuer = r.Issuer,
                Thumbprint = r.Thumbprint, ValidFrom = DateTime.SpecifyKind(r.ValidFrom, DateTimeKind.Utc), ValidUntil = DateTime.SpecifyKind(r.ValidUntil, DateTimeKind.Utc),
                RequestedBy = r.RequestedBy, RequestedAt = r.RequestedAt, DecidedBy = r.DecidedBy, DecidedAt = r.DecidedAt,
                DecisionComment = r.DecisionComment, Version = Convert.ToBase64String(r.RowVersion ?? new byte[0])
            };
        }

        private static bool Has(System.Data.SqlClient.SqlException ex, int number)
        {
            return ex.Errors.Cast<System.Data.SqlClient.SqlError>().Any(e => e.Number == number);
        }

        internal sealed class Row
        {
            public string CertificateId { get; set; } = "";
            public string BankKey { get; set; } = "";
            public string StatusKey { get; set; } = "";
            public string FileName { get; set; } = "";
            public string Subject { get; set; } = "";
            public string Issuer { get; set; } = "";
            public string Thumbprint { get; set; } = "";
            public DateTime ValidFrom { get; set; }
            public DateTime ValidUntil { get; set; }
            public string RequestedBy { get; set; } = "";
            public DateTimeOffset RequestedAt { get; set; }
            public string DecidedBy { get; set; }
            public DateTimeOffset? DecidedAt { get; set; }
            public string DecisionComment { get; set; }
            public byte[] RowVersion { get; set; } = new byte[0];
        }
    }
}
