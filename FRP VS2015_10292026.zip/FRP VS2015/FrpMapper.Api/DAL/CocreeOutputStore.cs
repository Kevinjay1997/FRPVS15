using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Api.DAL
{
    /// <summary>
    /// COCREE run folders under FileStorage:RootPath\cocree-outputs\{run id}. A run's owner is written in its owner.txt;
    /// only that person can list or read its files. Runs are removed a day after they were created.
    /// </summary>
    public sealed class CocreeOutputStore : ICocreeOutputStore
    {
        private static readonly TimeSpan KeepFor = TimeSpan.FromDays(1);
        private const string OwnerFile = "owner.txt";
        private readonly IOptionsMonitor<FileStorageOptions> options;
        private readonly IWebHostEnvironment environment;

        public CocreeOutputStore(IOptionsMonitor<FileStorageOptions> options, IWebHostEnvironment environment)
        {
            this.options = options;
            this.environment = environment;
        }

        private string Root
        {
            get
            {
                var configured = options.CurrentValue.RootPath;
                var root = Path.IsPathRooted(configured) ? configured : Path.Combine(environment.ContentRootPath, configured);
                return Path.Combine(Path.GetFullPath(root), "cocree-outputs");
            }
        }

        public CocreeOutputRun CreateRun(string owner)
        {
            RemoveOldRuns();
            var id = Guid.NewGuid().ToString("N");
            var folder = Path.Combine(Root, id);
            Directory.CreateDirectory(folder);
            File.WriteAllText(Path.Combine(folder, OwnerFile), owner ?? "", new UTF8Encoding(false));
            return new CocreeOutputRun(id, folder);
        }

        public IReadOnlyList<string> Files(string runId, string owner)
        {
            var folder = OwnedFolder(runId, owner);
            if (folder == null)
            {
                return new List<string>();
            }

            return Directory.GetFiles(folder).Select(Path.GetFileName).Where(CocreeOutputNames.IsValid).OrderBy(n => n, StringComparer.Ordinal).ToList();
        }

        public Stream Open(string runId, string fileName, string owner)
        {
            var folder = OwnedFolder(runId, owner);
            if (folder == null || !CocreeOutputNames.IsValid(fileName))
            {
                return null;
            }

            var path = Path.Combine(folder, fileName);
            return File.Exists(path) ? new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 81920) : null;
        }

        /// <summary>The run's folder when it exists and belongs to <paramref name="owner"/>, else null.</summary>
        private string OwnedFolder(string runId, string owner)
        {
            if (!Regex.IsMatch(runId ?? "", @"\A[0-9a-f]{32}\z"))
            {
                return null;
            }

            var folder = Path.Combine(Root, runId);
            var ownerPath = Path.Combine(folder, OwnerFile);
            if (!File.Exists(ownerPath))
            {
                return null;
            }

            var recorded = File.ReadAllText(ownerPath, Encoding.UTF8).Trim();
            return string.Equals(recorded, (owner ?? "").Trim(), StringComparison.OrdinalIgnoreCase) ? folder : null;
        }

        private void RemoveOldRuns()
        {
            if (!Directory.Exists(Root))
            {
                return;
            }

            foreach (var folder in Directory.GetDirectories(Root))
            {
                try
                {
                    if (DateTime.UtcNow - Directory.GetCreationTimeUtc(folder) > KeepFor)
                    {
                        Directory.Delete(folder, true);
                    }
                }
                catch (IOException)
                {
                    // In use (being downloaded): removed next time.
                }
                catch (UnauthorizedAccessException)
                {
                }
            }
        }
    }
}
