﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL.Sql;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.DAL
{
    public sealed class SqlReferenceDataRepository: IReferenceDataRepository
    {
        private readonly ISqlConnectionFactory connections;
        private readonly IAuditContext audit;

        public SqlReferenceDataRepository(ISqlConnectionFactory connections, IAuditContext audit)
    {
        this.connections = connections;
        this.audit = audit;
    }
        public async Task<ReferenceDataDto> ReadAsync(CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            using (var result = await connection.QueryMultipleAsync(new CommandDefinition("frp.usp_ReferenceData_Read", commandType: CommandType.StoredProcedure,
                commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken)))
            {
            var banks = (await result.ReadAsync<string>()).Select(x => JsonSerializer.Deserialize<BankProfileDto>(x)).ToList();
            var imports = (await result.ReadAsync<string>()).Select(x => JsonSerializer.Deserialize<SandboxImportDto>(x)).ToList();
            var requests = (await result.ReadAsync<RequestRow>()).Select(ToDto).ToList();
            return new ReferenceDataDto() { Banks = banks, Imports = imports, Requests = requests };
            }
            }
        }

        internal static BankProfileRequestDto ToDto(RequestRow r) => new BankProfileRequestDto() {
            Id = r.RequestId,
            BankKey = r.BankKey,
            BaseVersion = r.BaseVersion,
            Proposed = JsonSerializer.Deserialize<BankProfileDto>(r.Payload),
            Before = (r.BeforePayload == null) ? null : JsonSerializer.Deserialize<BankProfileDto>(r.BeforePayload),
            Summary = r.Summary,
            Status = r.StatusKey,
            RequestedBy = r.RequestedBy,
            RequestedAt = r.RequestedAt,
            DecidedBy = r.DecidedBy,
            DecidedAt = r.DecidedAt,
            DecisionComment = r.DecisionComment,
            Version = Convert.ToBase64String(r.RowVersion)
        };

        public async Task<BankProfileRequestDto> CreateBankRequestAsync(BankProfileRequestDto request, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var parameters = new DynamicParameters();
            parameters.Add("@RequestId", request.Id, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@BankKey", request.BankKey, DbType.AnsiString, size: 32);
            parameters.Add("@ProviderCode", request.Proposed.ProviderCode, DbType.AnsiString, size: 10);
            parameters.Add("@BaseVersion", request.BaseVersion);
            parameters.Add("@Payload", JsonSerializer.Serialize(request.Proposed), DbType.String, size: -1);
            parameters.Add("@BeforePayload", (request.Before == null) ? null : JsonSerializer.Serialize(request.Before), DbType.String, size: -1);
            parameters.Add("@Summary", request.Summary, DbType.String, size: 2000);
            parameters.Add("@RequestedBy", request.RequestedBy, DbType.String, size: 256);
            parameters.Add("@RequestedAt", request.RequestedAt);
            parameters.Add("@ClientAddress", audit.ClientAddress, DbType.AnsiString, size: 45);
            try
            {
                var version = await connection.ExecuteScalarAsync<byte[]>(new CommandDefinition("frp.usp_BankProfileRequest_Create", parameters,
                    commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                return request.With(copy => { copy.Version = Convert.ToBase64String(version ?? new byte[0]); });
            }
            catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.AccessRequestOpen))
            {
                throw new AccessRequestOpenException(ex.Message);
            }
            catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.ConcurrencyConflict))
            {
                throw new ConcurrencyConflictException(ex.Message);
            }
            }
        }

        public async Task<bool> DecideBankRequestAsync(string requestId, byte[] expectedVersion, string decision, string decidedBy, DateTimeOffset decidedAt, string comment,
            CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            var parameters = new DynamicParameters();
            parameters.Add("@RequestId", requestId, DbType.AnsiStringFixedLength, size: 32);
            parameters.Add("@ExpectedRowVersion", expectedVersion, DbType.Binary, size: 8);
            parameters.Add("@Decision", decision, DbType.AnsiString, size: 10);
            parameters.Add("@DecidedBy", decidedBy, DbType.String, size: 256);
            parameters.Add("@DecidedAt", decidedAt);
            parameters.Add("@Comment", comment, DbType.String, size: 1000);
            parameters.Add("@ClientAddress", audit.ClientAddress, DbType.AnsiString, size: 45);
            try
            {
                await connection.ExecuteAsync(new CommandDefinition("frp.usp_BankProfileRequest_Decide", parameters,
                    commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
                return true;
            }
            catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.NotFound))
            {
                return false;
            }
            catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.ConcurrencyConflict))
            {
                throw new ConcurrencyConflictException(ex.Message);
            }
            catch (System.Data.SqlClient.SqlException ex) when (Has(ex, DatabaseErrors.AccessDecisionRefused))
            {
                throw new AccessDecisionRefusedException(ex.Message);
            }
            }
        }

        private static bool Has(System.Data.SqlClient.SqlException ex, int number) =>
            ex.Errors.Cast<System.Data.SqlClient.SqlError>().Any(e => e.Number == number);

        internal sealed class RequestRow
        {
            public string RequestId { get; set; } = "";
            public string BankKey { get; set; } = "";
            public long BaseVersion { get; set; }
            public string Payload { get; set; } = "";
            public string BeforePayload { get; set; }
            public string Summary { get; set; } = "";
            public string StatusKey { get; set; } = "";
            public string RequestedBy { get; set; } = "";
            public DateTimeOffset RequestedAt { get; set; }
            public string DecidedBy { get; set; }
            public DateTimeOffset? DecidedAt { get; set; }
            public string DecisionComment { get; set; }
            public byte[] RowVersion { get; set; } = new byte[0];
        }
        public async Task SaveImportAsync(SandboxImportDto import, string user, CancellationToken cancellationToken)
        {
            using (var connection = await connections.OpenAsync(cancellationToken))
            {
            try
            {
                await connection.ExecuteAsync(new CommandDefinition("frp.usp_SandboxImport_Save",
                    new { ImportId = import.Id, import.BankKey, import.ProviderCode, import.ProjectId, import.Sha256, Payload = JsonSerializer.Serialize(import), UserName = user,
                        ClientAddress = new DbString { Value = audit.ClientAddress, IsAnsi = true, IsFixedLength = false, Length = 45 } },
                    commandType: CommandType.StoredProcedure, commandTimeout: connections.CommandTimeoutSeconds, cancellationToken: cancellationToken));
            }
            catch (System.Data.SqlClient.SqlException ex) when (ex.Errors.Cast<System.Data.SqlClient.SqlError>().Any(e => e.Number == DatabaseErrors.ConcurrencyConflict))
            { throw new BL.WorkflowException(BL.WorkflowErrorKind.Conflict, "The bank profile or its provider code changed. Read the report again before saving."); }
            }
        }
    }

}
