using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;

namespace FrpMapper.Api.Hosting
{
    /// <summary>One API request as the endpoints see it: route values, query, body, files, the caller and the services.</summary>
    public sealed class ApiRequest
    {
        private static readonly JsonSerializerOptions Json = new JsonSerializerOptions(JsonSerializerDefaults.Web);
        private readonly IDictionary<string, string> routeValues;

        public ApiRequest(HttpContextBase context, IDictionary<string, string> routeValues, ServiceProvider services, ClaimsPrincipal user, CancellationToken cancellationToken)
        {
            Context = context;
            this.routeValues = routeValues;
            Services = services;
            User = user;
            CancellationToken = cancellationToken;
        }

        public HttpContextBase Context { get; private set; }

        public ServiceProvider Services { get; private set; }

        public ClaimsPrincipal User { get; private set; }

        /// <summary>Ends when the client disconnects.</summary>
        public CancellationToken CancellationToken { get; private set; }

        public string Path
        {
            get { return Context.Request.Path; }
        }

        public T Service<T>()
        {
            return Services.GetRequiredService<T>();
        }

        public string Route(string name)
        {
            string value;
            return routeValues.TryGetValue(name, out value) ? value : null;
        }

        /// <summary>A query string value (not validated by ASP.NET's request validation; the endpoints check what they use).</summary>
        public string Query(string name)
        {
            return Context.Request.Unvalidated.QueryString[name];
        }

        public bool HasFormContentType
        {
            get
            {
                var type = Context.Request.ContentType ?? "";
                return type.StartsWith("multipart/form-data", StringComparison.OrdinalIgnoreCase)
                    || type.StartsWith("application/x-www-form-urlencoded", StringComparison.OrdinalIgnoreCase);
            }
        }

        public NameValueCollection Form
        {
            get { return Context.Request.Unvalidated.Form; }
        }

        /// <summary>A posted file, or null.</summary>
        public IFormFile File(string name)
        {
            var file = Context.Request.Files[name];
            return file == null ? null : new PostedFormFile(name, file);
        }

        /// <summary>Every file posted under <paramref name="name"/> (a multiple-file upload), in the order sent.</summary>
        public System.Collections.Generic.List<IFormFile> Files(string name)
        {
            var posted = Context.Request.Files;
            var files = new System.Collections.Generic.List<IFormFile>();
            for (var i = 0; i < posted.Count; i++)
            {
                if (string.Equals(posted.AllKeys[i], name, StringComparison.Ordinal) && posted[i] != null)
                {
                    files.Add(new PostedFormFile(name, posted[i]));
                }
            }

            return files;
        }

        /// <summary>
        /// The JSON body as <typeparamref name="T"/> (System.Text.Json's web defaults). An empty body gives null when
        /// <paramref name="optional"/>; otherwise it is a bad request.
        /// </summary>
        public async Task<T> ReadJsonAsync<T>(bool optional = false) where T : class
        {
            var request = Context.Request;
            string text;
            request.InputStream.Position = 0;
            using (var reader = new StreamReader(request.InputStream, Encoding.UTF8, true, 4096, true))
            {
                text = await reader.ReadToEndAsync();
            }

            if (string.IsNullOrWhiteSpace(text))
            {
                if (optional)
                {
                    return null;
                }

                throw new BadHttpRequestException("The request has no body.");
            }

            var contentType = request.ContentType ?? "";
            if (!contentType.StartsWith("application/json", StringComparison.OrdinalIgnoreCase))
            {
                throw new BadHttpRequestException("The request body must be JSON.", 415);
            }

            try
            {
                var value = JsonSerializer.Deserialize<T>(text, Json);
                if (value == null && !optional)
                {
                    throw new BadHttpRequestException("The request has no body.");
                }

                return value;
            }
            catch (JsonException)
            {
                throw new BadHttpRequestException("The request body is not valid JSON for this request.");
            }
        }

        public ILogger Logger(string category)
        {
            return Service<ILoggerFactory>().CreateLogger(category);
        }
    }

    /// <summary>What an endpoint answers.</summary>
    public abstract class ApiResult
    {
        public abstract Task WriteAsync(HttpContextBase context);
    }

    public static class Results
    {
        private static readonly JsonSerializerOptions WebJson = new JsonSerializerOptions(JsonSerializerDefaults.Web);

        public static ApiResult Ok(object value)
        {
            return new JsonResult(200, value);
        }

        public static ApiResult Json(int status, object value)
        {
            return new JsonResult(status, value);
        }

        /// <summary>
        /// 200 with <paramref name="value"/> as JSON, written once per object and reused while the object lives: for large
        /// results that are cached and answered again unchanged (a project for the project page, about 30 MB for FRP).
        /// </summary>
        public static ApiResult OkReused(object value)
        {
            return new ReusedJsonResult(Written.GetValue(value, v => System.Text.Encoding.UTF8.GetBytes(JsonSerializer.Serialize(v, v.GetType(), WebJson))));
        }

        private static readonly System.Runtime.CompilerServices.ConditionalWeakTable<object, byte[]> Written = new System.Runtime.CompilerServices.ConditionalWeakTable<object, byte[]>();

        private sealed class ReusedJsonResult : ApiResult
        {
            private readonly byte[] utf8;

            public ReusedJsonResult(byte[] utf8)
            {
                this.utf8 = utf8;
            }

            public override Task WriteAsync(HttpContextBase context)
            {
                context.Response.StatusCode = 200;
                context.Response.ContentType = "application/json";
                context.Response.Charset = "utf-8";
                return context.Response.OutputStream.WriteAsync(utf8, 0, utf8.Length);
            }
        }

        public static ApiResult BadRequest(object value)
        {
            return new JsonResult(400, value);
        }

        public static ApiResult NotFound()
        {
            return new StatusResult(404);
        }

        public static ApiResult NoContent()
        {
            return new StatusResult(204);
        }

        /// <summary>The response was already written (a streamed validation).</summary>
        public static ApiResult Empty()
        {
            return new EmptyResult();
        }

        public static ApiResult Content(string text, string contentType)
        {
            return new ContentResult(text, contentType);
        }

        public static ApiResult File(byte[] bytes, string contentType, string fileName)
        {
            return new FileResult(bytes, contentType, fileName);
        }

        /// <summary>A file sent as it is read (large files are not held in memory). The stream is closed afterwards.</summary>
        public static ApiResult Stream(System.IO.Stream stream, string contentType, string fileName)
        {
            return new StreamResult(stream, contentType, fileName);
        }

        private sealed class JsonResult : ApiResult
        {
            private readonly int status;
            private readonly object value;

            public JsonResult(int status, object value)
            {
                this.status = status;
                this.value = value;
            }

            public override Task WriteAsync(HttpContextBase context)
            {
                var text = JsonSerializer.Serialize(value, value == null ? typeof(object) : value.GetType(), WebJson);
                context.Response.StatusCode = status;
                context.Response.ContentType = "application/json";
                context.Response.Charset = "utf-8";
                context.Response.Write(text);
                return Task.FromResult(0);
            }
        }

        private sealed class StatusResult : ApiResult
        {
            private readonly int status;

            public StatusResult(int status)
            {
                this.status = status;
            }

            public override Task WriteAsync(HttpContextBase context)
            {
                context.Response.StatusCode = status;
                return Task.FromResult(0);
            }
        }

        private sealed class EmptyResult : ApiResult
        {
            public override Task WriteAsync(HttpContextBase context)
            {
                return Task.FromResult(0);
            }
        }

        private sealed class ContentResult : ApiResult
        {
            private readonly string text;
            private readonly string contentType;

            public ContentResult(string text, string contentType)
            {
                this.text = text;
                this.contentType = contentType;
            }

            public override Task WriteAsync(HttpContextBase context)
            {
                context.Response.StatusCode = 200;
                context.Response.ContentType = contentType;
                context.Response.Charset = "utf-8";
                context.Response.Write(text);
                return Task.FromResult(0);
            }
        }

        private sealed class FileResult : ApiResult
        {
            private readonly byte[] bytes;
            private readonly string contentType;
            private readonly string fileName;

            public FileResult(byte[] bytes, string contentType, string fileName)
            {
                this.bytes = bytes;
                this.contentType = contentType;
                this.fileName = fileName;
            }

            public override async Task WriteAsync(HttpContextBase context)
            {
                var response = context.Response;
                response.StatusCode = 200;
                response.ContentType = contentType;
                response.AddHeader("Content-Disposition", ContentDisposition(fileName));
                response.AddHeader("Content-Length", bytes.Length.ToString(System.Globalization.CultureInfo.InvariantCulture));
                await response.OutputStream.WriteAsync(bytes, 0, bytes.Length);
            }
        }

        private sealed class StreamResult : ApiResult
        {
            private readonly System.IO.Stream stream;
            private readonly string contentType;
            private readonly string fileName;

            public StreamResult(System.IO.Stream stream, string contentType, string fileName)
            {
                this.stream = stream;
                this.contentType = contentType;
                this.fileName = fileName;
            }

            public override async Task WriteAsync(HttpContextBase context)
            {
                using (stream)
                {
                    var response = context.Response;
                    response.BufferOutput = false;
                    response.StatusCode = 200;
                    response.ContentType = contentType;
                    response.AddHeader("Content-Disposition", ContentDisposition(fileName));
                    if (stream.CanSeek)
                    {
                        response.AddHeader("Content-Length", stream.Length.ToString(System.Globalization.CultureInfo.InvariantCulture));
                    }

                    await stream.CopyToAsync(response.OutputStream, 81920);
                }
            }
        }

        /// <summary>As ASP.NET Core writes it: attachment; filename=...; filename*=UTF-8''...</summary>
        public static string ContentDisposition(string fileName)
        {
            var ascii = new string(fileName.Select(ch => ch < 0x20 || ch > 0x7e || ch == '"' || ch == '\\' || ch == ';' ? '_' : ch).ToArray());
            var plain = ascii.IndexOfAny(new[] { ' ', ',', '(', ')' }) >= 0 ? "\"" + ascii + "\"" : ascii;
            return "attachment; filename=" + plain + "; filename*=UTF-8''" + Uri.EscapeDataString(fileName);
        }
    }
}
