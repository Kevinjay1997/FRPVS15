using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Hosting
{
    /// <summary>
    /// The API's routes (the .NET 9 version's app.MapGet / MapPost / …): method, path template with {name} segments,
    /// the authorization policies the caller must all satisfy, and the handler.
    /// </summary>
    public sealed class RouteTable
    {
        private readonly List<Endpoint> endpoints = new List<Endpoint>();

        public IReadOnlyList<Endpoint> Endpoints
        {
            get { return endpoints; }
        }

        public Endpoint MapGet(string template, Func<ApiRequest, Task<ApiResult>> handler)
        {
            return Map("GET", template, handler);
        }

        public Endpoint MapPost(string template, Func<ApiRequest, Task<ApiResult>> handler)
        {
            return Map("POST", template, handler);
        }

        public Endpoint MapPut(string template, Func<ApiRequest, Task<ApiResult>> handler)
        {
            return Map("PUT", template, handler);
        }

        public Endpoint MapDelete(string template, Func<ApiRequest, Task<ApiResult>> handler)
        {
            return Map("DELETE", template, handler);
        }

        private Endpoint Map(string method, string template, Func<ApiRequest, Task<ApiResult>> handler)
        {
            var endpoint = new Endpoint(method, template, handler);
            endpoints.Add(endpoint);
            return endpoint;
        }

        /// <summary>The endpoint for the method and path; null when none. <paramref name="pathExists"/> tells a 405 from a 404.</summary>
        public Endpoint Match(string method, string path, out IDictionary<string, string> values, out bool pathExists)
        {
            values = null;
            pathExists = false;
            var segments = Split(path);
            // A literal segment wins over a {parameter} (as ASP.NET Core routing ranks them).
            foreach (var endpoint in endpoints.OrderBy(e => e.ParameterCount))
            {
                IDictionary<string, string> found;
                if (!endpoint.TryMatch(segments, out found))
                {
                    continue;
                }

                pathExists = true;
                if (string.Equals(endpoint.Method, method, StringComparison.OrdinalIgnoreCase))
                {
                    values = found;
                    return endpoint;
                }
            }

            return null;
        }

        /// <summary>The methods mapped for a path (the Allow header of a 405).</summary>
        public IEnumerable<string> MethodsFor(string path)
        {
            var segments = Split(path);
            IDictionary<string, string> ignored;
            return endpoints.Where(e => e.TryMatch(segments, out ignored)).Select(e => e.Method).Distinct();
        }

        internal static string[] Split(string path)
        {
            return (path ?? "").Trim('/').Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
        }
    }

    public sealed class Endpoint
    {
        private readonly string[] segments;
        private readonly List<string> policies = new List<string>();

        public Endpoint(string method, string template, Func<ApiRequest, Task<ApiResult>> handler)
        {
            Method = method;
            Template = template;
            Handler = handler;
            segments = RouteTable.Split(template);
        }

        public string Method { get; private set; }

        public string Template { get; private set; }

        public Func<ApiRequest, Task<ApiResult>> Handler { get; private set; }

        public bool Anonymous { get; private set; }

        public int ParameterCount
        {
            get { return segments.Count(s => s.StartsWith("{", StringComparison.Ordinal)); }
        }

        public IReadOnlyList<string> Policies
        {
            get { return policies; }
        }

        /// <summary>The caller must satisfy every one of these policies (a permission key, SignedInUser or PlatformClient).</summary>
        public Endpoint RequireAuthorization(params string[] names)
        {
            policies.AddRange(names);
            return this;
        }

        public Endpoint AllowAnonymous()
        {
            Anonymous = true;
            return this;
        }

        internal bool TryMatch(string[] path, out IDictionary<string, string> values)
        {
            values = null;
            if (path.Length != segments.Length)
            {
                return false;
            }

            var found = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < segments.Length; i++)
            {
                var segment = segments[i];
                if (segment.StartsWith("{", StringComparison.Ordinal) && segment.EndsWith("}", StringComparison.Ordinal))
                {
                    found[segment.Substring(1, segment.Length - 2)] = Uri.UnescapeDataString(path[i]);
                }
                else if (!string.Equals(segment, path[i], StringComparison.OrdinalIgnoreCase))
                {
                    return false;
                }
            }

            values = found;
            return true;
        }
    }

    /// <summary>The authorization policies (ASP.NET Core's AddAuthorization in the .NET 9 version).</summary>
    public static class Authorization
    {
        public static bool IsAuthenticated(ClaimsPrincipal user)
        {
            return user != null && user.Identity != null && user.Identity.IsAuthenticated;
        }

        /// <summary>True when the caller satisfies the policy.</summary>
        public static bool Satisfies(ClaimsPrincipal user, string policy)
        {
            if (!IsAuthenticated(user))
            {
                return false;
            }

            switch (policy)
            {
                case FrpMapper.Api.Security.Policies.SignedInUser:
                    return user.HasClaim(c => c.Type == ClaimTypes.Name);
                case FrpMapper.Api.Security.Policies.PlatformClient:
                    return user.HasClaim(c => c.Type == PlatformTrustAuthentication.ClientClaim);
                case FrpMapper.Api.Security.Policies.Default:
                    // anything not explicitly marked: a signed-in person holding at least one permission
                    return user.HasClaim(c => c.Type == ClaimTypes.Name) && user.HasClaim(c => c.Type == AppClaimTypes.Permission);
                default:
                    return user.HasClaim(AppClaimTypes.Permission, policy);
            }
        }
    }
}
