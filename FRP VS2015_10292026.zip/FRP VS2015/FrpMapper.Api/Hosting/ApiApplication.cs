﻿using System;
using System.IO;
using System.Web.Hosting;
using FrpMapper.Api.BL;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Api.Hosting
{
    /// <summary>
    /// The API's composition root (the services part of the .NET 9 version's Program.cs): settings, logging, and every
    /// service with its lifetime. Started once from Global.asax; fails at start, not on the first request, when a
    /// secret or setting is missing.
    /// </summary>
    public static class ApiApplication
    {
        private static readonly object Gate = new object();

        public static ServiceProvider Services { get; private set; }

        public static RouteTable Routes { get; private set; }

        public static IHostEnvironment Environment { get; private set; }

        public static ILogger Logger { get; private set; }

        /// <param name="customize">Changes to the registrations before they are built (tests replace the data layer).</param>
        public static void Start(Action<ServiceCollection> customize = null)
        {
            lock (Gate)
            {
                if (Services != null)
                {
                    return;
                }

                var configuration = new AppConfiguration();
                var root = HostingEnvironment.ApplicationPhysicalPath ?? AppDomain.CurrentDomain.BaseDirectory;
                var environment = new HostEnvironment(configuration["Environment"], root);
                var logFile = configuration["Logging:FilePath"];
                if (!string.IsNullOrWhiteSpace(logFile) && !Path.IsPathRooted(logFile))
                {
                    logFile = Path.Combine(root, logFile);
                }

                var loggerFactory = new LoggerFactory(Settings.LogLevel(configuration), logFile);
                var services = new ServiceCollection();

                // Settings from web.config (appSettings). Secrets (the connection string and the internal API key) come from
                // environment variables or the secrets file named in web.config, never from web.config itself.
                services.AddSingleton<IConfiguration>(configuration);
                services.AddSingleton<IHostEnvironment>(environment);
                services.AddSingleton<IWebHostEnvironment>(environment);
                services.AddSingleton<ILoggerFactory>(loggerFactory);
                var fileStorage = new FixedOptions<FileStorageOptions>(Settings.FileStorage(configuration), new FileStorageOptionsValidator());
                services.AddSingleton<IOptions<FileStorageOptions>>(fileStorage);
                services.AddSingleton<IOptionsMonitor<FileStorageOptions>>(fileStorage);
                services.AddSingleton<IOptions<BspOptions>>(new FixedOptions<BspOptions>(Settings.Bsp(configuration)));
                services.AddSingleton<IOptions<DatabaseOptions>>(new FixedOptions<DatabaseOptions>(Settings.Database(configuration)));
                services.AddSingleton<IOptions<SignInOptions>>(new FixedOptions<SignInOptions>(Settings.SignIn(configuration), new SignInOptionsValidator(environment)));
                services.AddSingleton(TimeProvider.System);
                services.AddSingleton<IMemoryCache, MemoryCache>();

                // Only FrpMapper.Platform calls this API; it signs users in and forwards the user with the shared internal key.
                services.AddSingleton<InternalApiKey>();
                services.AddSingleton<PlatformTrustAuthentication>();
                services.AddScoped<ICurrentUser, HttpCurrentUser>();
                services.AddSingleton<IAuditContext, HttpAuditContext>();

                // Data access: SQL Server through stored procedures; project files on disk under FileStorage:RootPath.
                services.AddSingleton<ISqlConnectionFactory, SqlConnectionFactory>();
                services.AddSingleton<IProjectFileStore, ProjectFileStore>();
                services.AddSingleton<IProjectRepository, SqlProjectRepository>();
                services.AddSingleton<IAuditLog, SqlAuditLog>();
                services.AddSingleton<IAccessRepository, SqlAccessRepository>();
                services.AddSingleton<IAccessService, AccessService>();
                services.AddSingleton<IAccessAdminRepository, SqlAccessAdminRepository>();
                services.AddScoped<IAccessAdminService, AccessAdminService>();
                services.AddSingleton<ISignInRepository, SqlSignInRepository>();
                services.AddSingleton<ISignInService, SignInService>();
                services.AddSingleton<IReportRepository, SqlReportRepository>();
                services.AddScoped<IReportService, ReportService>();
                services.AddSingleton<UploadRules>();
                services.AddScoped<IProjectWorkflowService, ProjectWorkflowService>();
                services.AddSingleton<XsdSchemaParser>();
                services.AddSingleton<OpenXmlWorkbookInspector>();
                services.AddSingleton<MappingSuggestionEngine>();
                services.AddSingleton<XmlSubmissionWriter>();
                services.AddSingleton<OpenXmlMappedTemplateWriter>();
                services.AddSingleton<XsdValidationService>();
                services.AddScoped<XsdProjectValidator>();
                services.AddSingleton<BspSpecificationReader>();
                services.AddSingleton<BspAssertionEvaluator>();
                services.AddSingleton<BspDerivedValues>();
                services.AddSingleton<ProjectReadCache>();
                services.AddScoped<BspSpecificationValidator>();
                services.AddSingleton<TemplateCoverageChecker>();
                services.AddSingleton<FilledTemplateReader>();
                services.AddSingleton<TemplateAccountCodeReader>();
                services.AddSingleton<XsdInputTemplateGenerator>();
                services.AddSingleton<BspSampleValueSolver>();
                services.AddSingleton<SampleValueRefill>();
                services.AddScoped<ProjectAccess>();
                services.AddScoped<IFrpMappingService, FrpMappingService>();
                services.AddSingleton<TemplateGridReader>();
                services.AddScoped<ITemplateGridService, TemplateGridService>();

                services.AddSingleton<IReferenceDataRepository, SqlReferenceDataRepository>();
                services.AddScoped<IReferenceDataService, ReferenceDataService>();
                services.AddScoped<BankReferenceContext>();
                services.AddSingleton<SandboxResultReader>();
                services.AddSingleton<FrpMapper.Api.Contracts.Integration.IBspSandboxClient, FrpMapper.Api.Integration.BspSandboxClient>();
                services.AddScoped<IValidationXmlSource, FrpMappingService>();
                services.AddScoped<ISandboxService, SandboxService>();
                services.AddSingleton<IBankCertificateRepository, SqlBankCertificateRepository>();
                services.AddSingleton<CertificateProtector>();
                services.AddScoped<IBankCertificateService, BankCertificateService>();
                services.AddSingleton<ISubmissionEnvironmentRepository, SqlSubmissionEnvironmentRepository>();
                services.AddScoped<ISubmissionEnvironmentService, SubmissionEnvironmentService>();
                services.AddSingleton<IWorkbenchConfigRepository, SqlWorkbenchConfigRepository>();
                services.AddSingleton<ICocreeOutputStore, CocreeOutputStore>();
                services.AddScoped<ICocreeConfigService, CocreeConfigService>();
                services.AddScoped<ICocreeService, CocreeService>();
                services.AddScoped<IXmlToolsConfigService, XmlToolsConfigService>();
                services.AddScoped<IXmlToolsService, XmlToolsService>();
                services.AddSingleton<ILogFileStore>(new LogFileStore(logFile));
                services.AddScoped<ILogService, LogService>();
                System.Net.ServicePointManager.SecurityProtocol |= System.Net.SecurityProtocolType.Tls12;

                if (customize != null)
                {
                    customize(services);
                }

                var built = services.Build();
                // Fail at start, not on the first request, when a secret or setting is missing.
                built.GetRequiredService<InternalApiKey>();
                built.GetRequiredService<ISqlConnectionFactory>();
                built.GetRequiredService<IOptions<SignInOptions>>();

                Routes = Endpoints.Map(new RouteTable());
                Environment = environment;
                Logger = loggerFactory.CreateLogger("FrpMapper.Api");
                Services = built;
                Logger.LogInformation("FRP Mapper API started ({Environment}).", environment.EnvironmentName);
            }
        }
    }
}
