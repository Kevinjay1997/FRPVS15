using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using FrpMapper.Api.Models;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Hosting
{
    /// <summary>
    /// Reads the settings sections from the configuration (web.config appSettings, environment variables), as
    /// .NET Core's options binding did with appsettings.json. Keys are "Section:Name"; a list is written with ";"
    /// between the values (FileStorage:AllowedExtensions:Template = ".xlsx;.xlsm").
    /// </summary>
    public static class Settings
    {
        public static FileStorageOptions FileStorage(IConfiguration configuration)
        {
            var options = new FileStorageOptions
            {
                RootPath = configuration[FileStorageOptions.SectionName + ":RootPath"] ?? "",
                SharedUploadsFolder = configuration[FileStorageOptions.SectionName + ":SharedUploadsFolder"] ?? "",
                MaxUploadMegabytes = Int(configuration, FileStorageOptions.SectionName + ":MaxUploadMegabytes", 0),
                MaxReferenceFileBytes = Int(configuration, FileStorageOptions.SectionName + ":MaxReferenceFileBytes", FileStorageOptions.DefaultMaxReferenceFileBytes)
            };
            foreach (var kind in UploadKinds.All)
            {
                var list = configuration[FileStorageOptions.SectionName + ":AllowedExtensions:" + kind];
                options.AllowedExtensions[kind] = (list ?? "").Split(';', ',')
                    .Select(e => e.Trim())
                    .Where(e => e.Length > 0)
                    .ToList();
            }

            return options;
        }

        public static DatabaseOptions Database(IConfiguration configuration)
        {
            return new DatabaseOptions
            {
                ConnectionStringName = configuration[DatabaseOptions.SectionName + ":ConnectionStringName"] ?? "",
                CommandTimeoutSeconds = Int(configuration, DatabaseOptions.SectionName + ":CommandTimeoutSeconds", 0),
                AccessCacheSeconds = Int(configuration, DatabaseOptions.SectionName + ":AccessCacheSeconds", 0)
            };
        }

        public static SignInOptions SignIn(IConfiguration configuration)
        {
            var defaults = new SignInOptions();
            return new SignInOptions
            {
                MaxFailedAttempts = Int(configuration, SignInOptions.SectionName + ":MaxFailedAttempts", defaults.MaxFailedAttempts),
                AdministratorDelayMinutes = Int(configuration, SignInOptions.SectionName + ":AdministratorDelayMinutes", defaults.AdministratorDelayMinutes),
                InactiveDays = Int(configuration, SignInOptions.SectionName + ":InactiveDays", defaults.InactiveDays)
            };
        }

        /// <summary>
        /// Bsp:AllowedHosts (environment variable Bsp__AllowedHosts wins). Not set: BSP's Report API host only. A value that
        /// is not a plain host name stops the API at start, so a typo cannot silently allow or block a host.
        /// </summary>
        public static BspOptions Bsp(IConfiguration configuration)
        {
            var text = configuration[BspOptions.SectionName + ":AllowedHosts"];
            if (string.IsNullOrWhiteSpace(text))
            {
                return new BspOptions();
            }

            var hosts = text.Split(';', ',').Select(h => h.Trim().ToLowerInvariant()).Where(h => h.Length > 0).Distinct().ToList();
            foreach (var host in hosts)
            {
                if (!BL.BspEndpointRules.IsHostName(host))
                {
                    throw new InvalidOperationException("The setting Bsp:AllowedHosts must list host names only (for example rapi.bsp.gov.ph), separated by ';'.");
                }
            }

            return new BspOptions { AllowedHosts = hosts };
        }

        public static LogLevel LogLevel(IConfiguration configuration)
        {
            var text = configuration["Logging:LogLevel:Default"];
            LogLevel level;
            return Enum.TryParse(text, true, out level) ? level : Shared.Hosting.LogLevel.Information;
        }

        private static int Int(IConfiguration configuration, string key, int fallback)
        {
            var text = configuration[key];
            if (string.IsNullOrWhiteSpace(text))
            {
                return fallback;
            }

            int value;
            if (!int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out value))
            {
                throw new InvalidOperationException("The setting " + key + " must be a whole number.");
            }

            return value;
        }
    }
}
