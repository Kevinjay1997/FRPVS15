using System;
using System.Web;
using FrpMapper.Api.Hosting;

namespace FrpMapper.Api
{
    /// <summary>Starts the API (services, settings, routes) and removes headers that name the server software.</summary>
    public class Global : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            ApiApplication.Start();
        }

        protected void Application_PreSendRequestHeaders(object sender, EventArgs e)
        {
            // The response does not name the web server software (Application Security Checklist: server configuration).
            var response = HttpContext.Current == null ? null : HttpContext.Current.Response;
            if (response != null)
            {
                response.Headers.Remove("Server");
                response.Headers.Remove("X-AspNet-Version");
                response.Headers.Remove("X-Powered-By");
            }
        }
    }
}
