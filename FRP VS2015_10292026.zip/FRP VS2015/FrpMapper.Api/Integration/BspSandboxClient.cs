using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.BL;
using FrpMapper.Api.Contracts.Integration;
using FrpMapper.Api.Models;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;
namespace FrpMapper.Api.Integration
{
    // HttpWebRequest provides client certificates on .NET Framework 4.5.2, unlike HttpClientHandler.
    public sealed class BspSandboxClient : IBspSandboxClient
    {
        private readonly BspOptions options;

        public BspSandboxClient(IOptions<BspOptions> options)
        {
            this.options = options.Value;
        }

        /// <summary>
        /// The request's content type. .NET always quotes a multipart boundary; it is sent unquoted, as Postman and the
        /// Xml Report Manager send it (the boundary is a plain token, so both forms are valid).
        /// </summary>
        public static string ContentTypeOf(HttpContent content)
        {
            var type = content.Headers.ContentType;
            var boundary = type.Parameters.FirstOrDefault(p => string.Equals(p.Name, "boundary", StringComparison.OrdinalIgnoreCase));
            var token = boundary == null ? null : boundary.Value.Trim('"');
            return token != null && Regex.IsMatch(token, @"\A[A-Za-z0-9]{1,70}\z") ? type.MediaType + "; boundary=" + token : type.ToString();
        }

        /// <summary>
        /// Why a connection to BSP failed, in plain words (shown to the person and written to the audit trail). The
        /// technical detail (the exception and its inner exceptions) goes to the API log only.
        /// </summary>
        public static string Reason(WebExceptionStatus status)
        {
            switch (status)
            {
                case WebExceptionStatus.NameResolutionFailure:
                    return "the app server could not look up BSP's host (DNS). It may need the bank's proxy to reach the internet.";
                case WebExceptionStatus.ProxyNameResolutionFailure:
                    return "the proxy configured for the app server could not be found.";
                case WebExceptionStatus.ConnectFailure:
                    return "the app server could not connect to BSP's host on port 443: a firewall blocks it, or it must go through the bank's proxy.";
                case WebExceptionStatus.TrustFailure:
                    return "the app server does not trust BSP's TLS certificate (a proxy that inspects HTTPS, or a missing root certificate on the server).";
                case WebExceptionStatus.SecureChannelFailure:
                    return "the secure (TLS) connection could not be set up: BSP refused the client certificate, or the API's application pool cannot use the certificate's private key.";
                case WebExceptionStatus.Timeout:
                    return "BSP did not answer in time.";
                case WebExceptionStatus.ConnectionClosed:
                case WebExceptionStatus.ReceiveFailure:
                case WebExceptionStatus.SendFailure:
                case WebExceptionStatus.KeepAliveFailure:
                    return "the connection to BSP was closed before BSP answered (often a refused client certificate, or a proxy or firewall closing it).";
                case WebExceptionStatus.RequestCanceled:
                    return "the request was cancelled.";
                default:
                    return "the connection to BSP failed (" + status + ").";
            }
        }

        public async Task<SandboxResponse> SendAsync(X509Certificate2 certificate, Uri url, HttpContent content, bool download, CancellationToken cancellation)
        {
            // Checked again here, whatever the caller did: the bank's client certificate is only ever presented over HTTPS on
            // port 443 to a host the API's Bsp:AllowedHosts lists.
            if (url == null || !url.IsAbsoluteUri || url.Scheme != Uri.UriSchemeHttps || !url.IsDefaultPort || url.UserInfo.Length > 0
                || url.Query.Length > 0 || url.Fragment.Length > 0 || !BspEndpointRules.IsAllowedHost(url.Host, options.AllowedHosts))
                throw new InvalidOperationException("Invalid BSP endpoint.");
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = content == null ? "GET" : "POST";
            request.AllowAutoRedirect = false;
            request.ClientCertificates.Add(certificate);
            request.ConnectionGroupName = Guid.NewGuid().ToString("N");
            request.KeepAlive = false;
            request.AllowWriteStreamBuffering = false;
            using (var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellation))
            {
                timeout.CancelAfter(TimeSpan.FromSeconds(120));
                using (timeout.Token.Register(request.Abort))
                try
                {
                    if (content != null)
                    {
                        // Buffer bounded multipart content once so Framework can send Content-Length, without redirects/retries.
                        var bytes = await content.ReadAsByteArrayAsync();
                        request.ContentType = ContentTypeOf(content);
                        request.ContentLength = bytes.Length;
                        using (var destination = await request.GetRequestStreamAsync())
                            await destination.WriteAsync(bytes, 0, bytes.Length, timeout.Token);
                    }
                    HttpWebResponse response;
                    try { response = (HttpWebResponse)await request.GetResponseAsync(); }
                    catch (WebException ex)
                    {
                        response = ex.Response as HttpWebResponse;
                        if (response == null) throw;
                    }
                    using (response)
                    using (var stream = response.GetResponseStream())
                    using (var output = new MemoryStream())
                    {
                        var buffer = new byte[81920]; int count;
                        while ((count = await stream.ReadAsync(buffer, 0, buffer.Length, timeout.Token)) > 0)
                        {
                            if (output.Length + count > 32 * 1024 * 1024) throw new HttpRequestException("BSP response exceeds the download limit.");
                            output.Write(buffer, 0, count);
                        }
                        var bytes = output.ToArray();
                        var success = (int)response.StatusCode >= 200 && (int)response.StatusCode < 300;
                        return new SandboxResponse { StatusCode = (int)response.StatusCode,
                            Body = download && success ? null : Encoding.UTF8.GetString(bytes),
                            FileBytes = download && success ? bytes : null };
                    }
                }
                catch (WebException ex) { throw new HttpRequestException(Reason(ex.Status), ex); }
                finally { request.ServicePoint.CloseConnectionGroup(request.ConnectionGroupName); }
            }
        }
    }
}
