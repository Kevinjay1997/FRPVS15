using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Http
{
    /// <summary>
    /// Validation endpoints answer with plain JSON, or, when the client accepts application/x-ndjson, stream one JSON
    /// line per progress update (percent done and what is being checked) followed by the result or an error.
    /// </summary>
    public static class ValidationStream
    {
        public const string MediaType = "application/x-ndjson";
        private static readonly JsonSerializerOptions Json = new JsonSerializerOptions(JsonSerializerDefaults.Web);

        public static bool IsRequested(HttpRequestBase request)
        {
            var accept = request.Headers["Accept"];
            return accept != null && accept.IndexOf(MediaType, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        /// <summary>Runs <paramref name="validate"/> and streams its progress, then its result (a null result is a 404).</summary>
        public static Task WriteAsync(HttpContextBase context, Func<IProgress<ValidationProgressDto>, Task<XsdValidationResultDto>> validate, ILogger logger,
            CancellationToken cancellationToken)
        {
            return WriteAsync(context, validate, result => new ValidationStreamEventDto { Result = result }, logger, cancellationToken);
        }

        /// <summary>
        /// Runs <paramref name="work"/> and streams its progress, then the event <paramref name="toResult"/> makes of its
        /// result (a null result is a 404).
        /// </summary>
        public static async Task WriteAsync<T>(HttpContextBase context, Func<IProgress<ValidationProgressDto>, Task<T>> work,
            Func<T, ValidationStreamEventDto> toResult, ILogger logger, CancellationToken cancellationToken) where T : class
        {
            var queue = new EventQueue();
            var progress = new ThrottledProgress(queue);
            var response = context.Response;
            response.BufferOutput = false;
            response.StatusCode = StatusCodes.Status200OK;
            response.ContentType = MediaType;
            response.Charset = "utf-8";
            response.Headers["Cache-Control"] = "no-store";
            var path = context.Request.Path;

            // The work runs beside the writer, so progress lines go out while the (CPU-bound) checks run.
            var running = Task.Run(async () =>
            {
                try
                {
                    var result = await work(progress);
                    if (result == null)
                    {
                        queue.Add(new ValidationStreamEventDto { Type = ValidationStreamEventDto.ErrorType, Status = StatusCodes.Status404NotFound, Message = "The project was not found." });
                    }
                    else
                    {
                        var final = toResult(result);
                        final.Type = ValidationStreamEventDto.ResultType;
                        final.Progress = new ValidationProgressDto { Percent = 100, Stage = "Finished" };
                        queue.Add(final);
                    }
                }
                catch (Exception ex)
                {
                    var error = ApiErrors.Map(ex);
                    if (error.Status == StatusCodes.Status500InternalServerError)
                    {
                        logger.LogError(ex, "Request failed for {Path}", path);
                    }

                    queue.Add(new ValidationStreamEventDto { Type = ValidationStreamEventDto.ErrorType, Status = error.Status, Message = error.Message });
                }
                finally
                {
                    queue.Complete();
                }
            });

            try
            {
                while (true)
                {
                    var item = await queue.TakeAsync(cancellationToken);
                    if (item == null)
                    {
                        break;
                    }

                    response.Write(JsonSerializer.Serialize(item, Json) + "\n");
                    response.Flush();
                }
            }
            catch (OperationCanceledException)
            {
                // The browser left; the work finishes on its own and its result is dropped.
            }
            catch (HttpException)
            {
                // The connection closed while writing.
            }

            await running;
        }

        /// <summary>Events waiting to be written, in order; null from <see cref="TakeAsync"/> means the work is done.</summary>
        private sealed class EventQueue
        {
            private readonly ConcurrentQueue<ValidationStreamEventDto> items = new ConcurrentQueue<ValidationStreamEventDto>();
            private readonly SemaphoreSlim available = new SemaphoreSlim(0);
            private volatile bool completed;

            public void Add(ValidationStreamEventDto item)
            {
                items.Enqueue(item);
                available.Release();
            }

            public void Complete()
            {
                completed = true;
                available.Release();
            }

            public async Task<ValidationStreamEventDto> TakeAsync(CancellationToken cancellationToken)
            {
                while (true)
                {
                    ValidationStreamEventDto item;
                    if (items.TryDequeue(out item))
                    {
                        return item;
                    }

                    if (completed)
                    {
                        return null;
                    }

                    await available.WaitAsync(cancellationToken);
                }
            }
        }

        /// <summary>Passes on a progress update when the percent or step changes, or at most every 150 ms.</summary>
        private sealed class ThrottledProgress : IProgress<ValidationProgressDto>
        {
            private readonly EventQueue queue;
            private readonly Stopwatch clock = Stopwatch.StartNew();
            private readonly object gate = new object();
            private ValidationProgressDto last;
            private long lastAt = -1000;

            public ThrottledProgress(EventQueue queue)
            {
                this.queue = queue;
            }

            public void Report(ValidationProgressDto value)
            {
                lock (gate)
                {
                    var now = clock.ElapsedMilliseconds;
                    if (last != null && value.Percent == last.Percent && value.Stage == last.Stage && now - lastAt < 150)
                    {
                        return;
                    }

                    // Progress never goes backwards on screen.
                    if (last != null && value.Percent < last.Percent)
                    {
                        value = new ValidationProgressDto { Percent = last.Percent, Stage = value.Stage, Detail = value.Detail };
                    }

                    last = value;
                    lastAt = now;
                    queue.Add(new ValidationStreamEventDto { Type = ValidationStreamEventDto.ProgressType, Progress = value });
                }
            }
        }
    }
}
