﻿using System;
using FrpMapper.Api.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Api.Http
{
    /// <summary>
    /// The HTTP status and client message for an exception: workflow rules become 403 / 409 / 400 with their message;
    /// anything else is a generic 500 message (no stack traces, file paths or XML/SQL details reach the client).
    /// </summary>
    public static class ApiErrors
    {
        public static VT_Status_Message<int, string> Map(Exception error)
        {
            var aggregate = error as AggregateException;
            if (aggregate != null && aggregate.InnerExceptions.Count == 1)
            {
                error = aggregate.InnerExceptions[0];
            }

            var workflow = error as WorkflowException;
            if (workflow != null)
            {
                var status = workflow.Kind == WorkflowErrorKind.Forbidden ? StatusCodes.Status403Forbidden
                    : workflow.Kind == WorkflowErrorKind.Conflict ? StatusCodes.Status409Conflict
                    : StatusCodes.Status400BadRequest;
                return Result(status, workflow.Message);
            }

            if (error is DuplicateProjectFilesException)
            {
                return Result(StatusCodes.Status409Conflict,
                    "You already have a project with the same XSD, template and specification. Open that project instead of creating another.");
            }

            if (error is ProjectNotDeletableException)
            {
                return Result(StatusCodes.Status409Conflict,
                    "Only a draft or returned project can be deleted. Reload the project list to see its current status.");
            }

            if (error is ProjectNotEditableException)
            {
                return Result(StatusCodes.Status409Conflict,
                    "Only a draft or returned project can be changed. Reload the project to see its current status.");
            }

            if (error is ConcurrencyConflictException)
            {
                return Result(StatusCodes.Status409Conflict,
                    "The project was changed by someone else after it was opened. Reload it and try again.");
            }

            var invalid = error as InvalidOperationException;
            if (invalid != null && invalid.Message.StartsWith("Upload", StringComparison.Ordinal))
            {
                return Result(StatusCodes.Status400BadRequest, invalid.Message);
            }

            // Uploaded XSD / Excel parts are read without DTDs (SafeXml): a DOCTYPE, or XML that is not well-formed, is refused.
            if (error is System.Xml.XmlException)
            {
                return Result(StatusCodes.Status400BadRequest,
                    "An uploaded file could not be read: its XML is not well-formed or contains a DOCTYPE (DTD), which is not accepted.");
            }

            var bad = error as BadHttpRequestException;
            if (bad != null)
            {
                return Result(bad.StatusCode, "The request could not be read (it may be too large).");
            }

            if (error is FrpMapper.Shared.Json.JsonException)
            {
                return Result(StatusCodes.Status400BadRequest, "The request could not be read (it may be too large).");
            }

            // A stored procedure or table the feature needs is not in the database (2812, 208): the database scripts of
            // this version have not been run. Said plainly, so the person knows it is not their input.
            var sql = error as System.Data.SqlClient.SqlException;
            if (sql != null && (sql.Number == 2812 || sql.Number == 208))
            {
                return Result(StatusCodes.Status503ServiceUnavailable,
                    "The database is not up to date: something this page needs is missing from it. An administrator runs the database scripts of this version (FrpDatabaseTool) and then it works.");
            }

            var http = error as System.Web.HttpException;
            if (http != null && http.WebEventCode == System.Web.Management.WebEventCodes.RuntimeErrorPostTooLarge)
            {
                return Result(StatusCodes.Status413PayloadTooLarge, "The request could not be read (it may be too large).");
            }

            return Result(StatusCodes.Status500InternalServerError, "The request failed. The error was logged; see the API log for details.");
        }

        private static VT_Status_Message<int, string> Result(int status, string message)
        {
            return new VT_Status_Message<int, string>(status, message);
        }
    }
}
