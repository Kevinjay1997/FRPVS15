﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("FrpMapper.Api")]
[assembly: AssemblyDescription("FRP Mapper API: projects, mappings, validation, workflow and access, over SQL Server stored procedures.")]
[assembly: AssemblyProduct("FRP Mapper")]
[assembly: AssemblyCopyright("")]
[assembly: ComVisible(false)]
[assembly: Guid("7e4dda3c-4a54-46ce-87cb-0bc6555b1082")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
