using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using FrpMapper.Api.BL;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Api.Security
{
    /// <summary>
    /// Encrypts a bank's PFX and its password before they are stored, and decrypts them for one request to BSP.
    ///
    /// AES-256-CBC, then HMAC-SHA256 over everything (encrypt-then-MAC), with separate keys derived from the setting
    /// Certificates:ProtectionKey (the API's Web.config or the environment variable Certificates__ProtectionKey; at least
    /// 32 random characters). The tag also covers the certificate's id and bank, so a stored certificate cannot be
    /// moved to another row or bank. Without the same key, stored certificates cannot be opened: keep it with the
    /// database backups' restore instructions, not in the backup itself.
    ///
    /// Layout: version (1 byte) | IV (16) | ciphertext | tag (32). Plaintext: password length (4 bytes, little-endian) |
    /// password (UTF-8) | PFX bytes.
    /// </summary>
    public sealed class CertificateProtector
    {
        private const byte FormatVersion = 1;
        private const int IvLength = 16;
        private const int TagLength = 32;
        private readonly IConfiguration configuration;

        public CertificateProtector(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public byte[] Protect(byte[] pfx, string password, string certificateId, string bankKey)
        {
            byte[] encryptionKey, macKey;
            Keys(out encryptionKey, out macKey);
            var passwordBytes = Encoding.UTF8.GetBytes(password ?? "");
            var plain = new byte[4 + passwordBytes.Length + pfx.Length];
            try
            {
                BitConverter.GetBytes(passwordBytes.Length).CopyTo(plain, 0);
                if (!BitConverter.IsLittleEndian) Array.Reverse(plain, 0, 4);
                passwordBytes.CopyTo(plain, 4);
                pfx.CopyTo(plain, 4 + passwordBytes.Length);
                using (var aes = Aes.Create())
                {
                    aes.KeySize = 256; aes.Mode = CipherMode.CBC; aes.Padding = PaddingMode.PKCS7;
                    aes.Key = encryptionKey;
                    aes.GenerateIV();
                    byte[] cipher;
                    using (var encryptor = aes.CreateEncryptor())
                        cipher = encryptor.TransformFinalBlock(plain, 0, plain.Length);
                    var output = new byte[1 + IvLength + cipher.Length + TagLength];
                    output[0] = FormatVersion;
                    aes.IV.CopyTo(output, 1);
                    cipher.CopyTo(output, 1 + IvLength);
                    Tag(macKey, output, output.Length - TagLength, certificateId, bankKey).CopyTo(output, output.Length - TagLength);
                    return output;
                }
            }
            finally
            {
                Array.Clear(plain, 0, plain.Length);
                Array.Clear(passwordBytes, 0, passwordBytes.Length);
                Array.Clear(encryptionKey, 0, encryptionKey.Length);
                Array.Clear(macKey, 0, macKey.Length);
            }
        }

        /// <summary>The PFX bytes and password; throws when the data was changed, belongs to another row, or the key differs.</summary>
        public byte[] Unprotect(byte[] stored, string certificateId, string bankKey, out string password)
        {
            password = null;
            if (stored == null || stored.Length < 1 + IvLength + 16 + TagLength || stored[0] != FormatVersion)
                throw Unreadable();
            byte[] encryptionKey, macKey;
            Keys(out encryptionKey, out macKey);
            byte[] plain = null;
            try
            {
                var expected = Tag(macKey, stored, stored.Length - TagLength, certificateId, bankKey);
                var difference = 0;
                for (var i = 0; i < TagLength; i++) difference |= expected[i] ^ stored[stored.Length - TagLength + i];
                if (difference != 0) throw Unreadable();
                using (var aes = Aes.Create())
                {
                    aes.KeySize = 256; aes.Mode = CipherMode.CBC; aes.Padding = PaddingMode.PKCS7;
                    aes.Key = encryptionKey;
                    var iv = new byte[IvLength];
                    Array.Copy(stored, 1, iv, 0, IvLength);
                    aes.IV = iv;
                    using (var decryptor = aes.CreateDecryptor())
                        plain = decryptor.TransformFinalBlock(stored, 1 + IvLength, stored.Length - 1 - IvLength - TagLength);
                }
                var lengthBytes = new byte[4];
                Array.Copy(plain, 0, lengthBytes, 0, 4);
                if (!BitConverter.IsLittleEndian) Array.Reverse(lengthBytes);
                var passwordLength = BitConverter.ToInt32(lengthBytes, 0);
                if (passwordLength < 0 || 4 + passwordLength > plain.Length) throw Unreadable();
                password = Encoding.UTF8.GetString(plain, 4, passwordLength);
                var pfx = new byte[plain.Length - 4 - passwordLength];
                Array.Copy(plain, 4 + passwordLength, pfx, 0, pfx.Length);
                return pfx;
            }
            catch (CryptographicException) { throw Unreadable(); }
            finally
            {
                if (plain != null) Array.Clear(plain, 0, plain.Length);
                Array.Clear(encryptionKey, 0, encryptionKey.Length);
                Array.Clear(macKey, 0, macKey.Length);
            }
        }

        private static WorkflowException Unreadable()
        {
            return new WorkflowException(WorkflowErrorKind.Conflict,
                "The bank's stored certificate cannot be opened (the protection key changed, or the data was altered). Upload the certificate again on Bank profiles.");
        }

        private void Keys(out byte[] encryptionKey, out byte[] macKey)
        {
            var secret = configuration["Certificates:ProtectionKey"];
            if (string.IsNullOrWhiteSpace(secret) || secret.Length < 32)
                throw new WorkflowException(WorkflowErrorKind.Invalid,
                    "Stored certificates are not set up on this server: Certificates:ProtectionKey (at least 32 random characters) is missing in FrpMapper.Api's Web.config. You can still upload a certificate for each request on BSP submission.");
            using (var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(secret)))
            {
                encryptionKey = hmac.ComputeHash(Encoding.ASCII.GetBytes("FrpMapper.BankCertificate.Encryption.v1"));
                macKey = hmac.ComputeHash(Encoding.ASCII.GetBytes("FrpMapper.BankCertificate.Authentication.v1"));
            }
        }

        private static byte[] Tag(byte[] macKey, byte[] data, int length, string certificateId, string bankKey)
        {
            using (var hmac = new HMACSHA256(macKey))
            using (var stream = new MemoryStream())
            {
                stream.Write(data, 0, length);
                var context = Encoding.UTF8.GetBytes("|" + certificateId + "|" + bankKey);
                stream.Write(context, 0, context.Length);
                return hmac.ComputeHash(stream.ToArray());
            }
        }
    }
}
