using FrpMapper.Api.Contracts.DAL;

namespace FrpMapper.Api.Security
{
    /// <summary>
    /// The client address of the current request: the address claim the <see cref="PlatformTrustAuthentication"/>
    /// adds from the Platform's X-Frp-Client-Address header after validating it (an IP address, at most 45 characters).
    /// </summary>
    public sealed class HttpAuditContext : IAuditContext
    {
        public string ClientAddress
        {
            get
            {
                var principal = RequestPrincipal.Current;
                var claim = principal == null ? null : principal.FindFirst(PlatformTrustAuthentication.AddressClaim);
                return claim == null ? null : claim.Value;
            }
        }
    }
}
