using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Security.Claims;
using System.Threading;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Security
{
    /// <summary>The signed-in user of the current request, for business rules and the audit trail.</summary>
    public interface ICurrentUser
    {
        string Name { get; }

        /// <summary>True for a signed-in person (not for the Platform's own service calls).</summary>
        bool IsAuthenticated { get; }

        bool HasPermission(string permission);

        IReadOnlyList<string> Roles { get; }

        IReadOnlyList<string> Permissions { get; }
    }

    /// <summary>
    /// The principal of the request being handled. It flows with the request's work (awaits and Task.Run), as
    /// IHttpContextAccessor did in ASP.NET Core, so singletons such as the audit log can read it.
    /// </summary>
    public static class RequestPrincipal
    {
        // .NET Framework 4.5.2 has no AsyncLocal<T> (4.6). Its logical call context flows the same way: into awaits and
        // Task.Run, copy-on-write, so a value set for one request never reaches another.
        private const string Slot = "FrpMapper.Api.RequestPrincipal";

        public static ClaimsPrincipal Current
        {
            get { return CallContext.LogicalGetData(Slot) as ClaimsPrincipal; }
            set { CallContext.LogicalSetData(Slot, value); }
        }
    }

    public sealed class HttpCurrentUser : ICurrentUser
    {
        private static ClaimsPrincipal Principal
        {
            get { return RequestPrincipal.Current; }
        }

        public bool IsAuthenticated
        {
            get
            {
                var principal = Principal;
                return principal != null && principal.Identity != null && principal.Identity.IsAuthenticated && !string.IsNullOrEmpty(principal.Identity.Name);
            }
        }

        public string Name
        {
            get { return IsAuthenticated ? Principal.Identity.Name : ""; }
        }

        public bool HasPermission(string permission)
        {
            return IsAuthenticated && Principal.HasClaim(AppClaimTypes.Permission, permission);
        }

        public IReadOnlyList<string> Roles
        {
            get { return IsAuthenticated ? Principal.FindAll(ClaimTypes.Role).Select(c => c.Value).ToList() : new List<string>(); }
        }

        public IReadOnlyList<string> Permissions
        {
            get { return IsAuthenticated ? Principal.FindAll(AppClaimTypes.Permission).Select(c => c.Value).ToList() : new List<string>(); }
        }
    }

    public static class Policies
    {
        /// <summary>A signed-in person, whatever their roles.</summary>
        public const string SignedInUser = "SignedInUser";

        /// <summary>Any caller with the internal API key: the Platform itself or a signed-in person.</summary>
        public const string PlatformClient = "PlatformClient";

        /// <summary>Anyone, without the internal API key (the health check and the start page only).</summary>
        public const string Anonymous = "Anonymous";

        /// <summary>
        /// Endpoints not marked otherwise: a signed-in person holding at least one permission (as the .NET 9
        /// version's fallback policy).
        /// </summary>
        public const string Default = "Default";
        // Every permission key (FrpMapper.Shared.Models.Permissions) is also a policy name.
    }
}
