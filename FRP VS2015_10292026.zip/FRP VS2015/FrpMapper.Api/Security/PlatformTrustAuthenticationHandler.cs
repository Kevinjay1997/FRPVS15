using System;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Security
{
    /// <summary>The outcome of reading the caller: a principal, nobody (no key), or a refused key or user.</summary>
    public sealed class AuthenticationOutcome
    {
        public ClaimsPrincipal Principal { get; set; }

        public bool Failed { get; set; }

        public string FailureMessage { get; set; }

        public static AuthenticationOutcome NoResult()
        {
            return new AuthenticationOutcome();
        }

        public static AuthenticationOutcome Fail(string message)
        {
            return new AuthenticationOutcome { Failed = true, FailureMessage = message };
        }

        public static AuthenticationOutcome Success(ClaimsPrincipal principal)
        {
            return new AuthenticationOutcome { Principal = principal };
        }
    }

    /// <summary>
    /// The API is called only by FrpMapper.Platform, which signs users in (Windows / Active Directory) and forwards
    /// the signed-in user and their application roles. A request is trusted only when it carries the shared internal
    /// API key (compared in constant time); otherwise it is anonymous and every protected endpoint returns 401.
    /// Roles are checked against the roles in the database, and the permissions those roles hold (also in the
    /// database) are added as claims. A request with the key but without a user is the Platform itself (e.g. reading
    /// the roles and groups to sign a user in); it gets no permissions.
    /// Keep the API bound to localhost / an internal network so only the Platform can reach it.
    /// </summary>
    public sealed class PlatformTrustAuthentication
    {
        public const string SchemeName = "PlatformTrust";
        public const string KeyHeader = "X-Frp-Api-Key";
        public const string UserHeader = "X-Frp-User";
        public const string RolesHeader = "X-Frp-Roles";

        /// <summary>Marks the Platform's own calls (no user).</summary>
        public const string ClientClaim = "frp:client";

        /// <summary>The person's network address as the Platform saw it, for the audit trail.</summary>
        public const string AddressHeader = "X-Frp-Client-Address";
        public const string AddressClaim = "frp:address";

        /// <summary>Longest textual IP address, the size of frp.AuditEntry.ClientAddress.</summary>
        public const int MaxAddressLength = 45;

        private readonly InternalApiKey apiKey;
        private readonly IAccessService access;

        public PlatformTrustAuthentication(InternalApiKey apiKey, IAccessService access)
        {
            this.apiKey = apiKey;
            this.access = access;
        }

        public async Task<AuthenticationOutcome> AuthenticateAsync(NameValueCollection headers, CancellationToken cancellationToken)
        {
            var presented = headers.GetValues(KeyHeader);
            if (presented == null || presented.Length != 1)
            {
                return AuthenticationOutcome.NoResult();
            }

            if (!apiKey.Matches(presented[0]))
            {
                return AuthenticationOutcome.Fail("Invalid internal API key.");
            }

            var identity = new ClaimsIdentity(SchemeName, ClaimTypes.Name, ClaimTypes.Role);
            identity.AddClaim(new Claim(ClientClaim, "platform"));
            // Only an IP address in its standard form (as the Platform sends it) is kept; anything else (including the
            // short forms IPAddress.TryParse also accepts, such as "1" for 0.0.0.1) is ignored, never stored.
            var addresses = headers.GetValues(AddressHeader);
            IPAddress parsed;
            if (addresses != null && addresses.Length == 1 && addresses[0].Length > 0 && addresses[0].Length <= MaxAddressLength
                && IPAddress.TryParse(addresses[0], out parsed) && string.Equals(parsed.ToString(), addresses[0], StringComparison.OrdinalIgnoreCase))
            {
                identity.AddClaim(new Claim(AddressClaim, parsed.ToString()));
            }

            var userHeader = headers.GetValues(UserHeader);
            if (userHeader == null)
            {
                return AuthenticationOutcome.Success(new ClaimsPrincipal(identity));
            }

            var user = string.Join(",", userHeader).Trim();
            if (user.Length == 0 || user.Length > 256 || user.Any(char.IsControl))
            {
                return AuthenticationOutcome.Fail("Missing or invalid user.");
            }

            var catalog = await access.GetCatalogAsync(cancellationToken);
            // The same rules as the Platform: a person SRAU disabled has no role; roles that together break the
            // segregation of duties give nothing; roles SRAU gave the person in the app count too.
            var requestedRoles = (headers[RolesHeader] ?? "").Split(',')
                .Select(r => r.Trim())
                .Where(r => r.Length > 0)
                .ToList();
            string conflict;
            bool disabled;
            var roles = AccessRules.Resolve(catalog, user, requestedRoles, out conflict, out disabled);

            identity.AddClaim(new Claim(ClaimTypes.Name, user));
            identity.AddClaims(roles.Select(role => new Claim(ClaimTypes.Role, role)));
            identity.AddClaims(catalog.PermissionsOf(roles).Select(permission => new Claim(AppClaimTypes.Permission, permission)));
            return AuthenticationOutcome.Success(new ClaimsPrincipal(identity));
        }
    }

    /// <summary>
    /// The shared key between FrpMapper.Platform and FrpMapper.Api (setting "InternalApi:Key", at least 32
    /// characters). It is a secret: set it in the environment variable InternalApi__Key or in each project's Web.config
    /// appSettings, with the same value for both applications.
    /// </summary>
    public sealed class InternalApiKey
    {
        private readonly byte[] key;

        public InternalApiKey(IConfiguration configuration)
        {
            var configured = configuration["InternalApi:Key"];
            if (string.IsNullOrWhiteSpace(configured))
            {
                throw new InvalidOperationException(
                    "InternalApi:Key is not configured. Set the same secret for FrpMapper.Api and FrpMapper.Platform "
                    + "(the environment variable InternalApi__Key, or InternalApi:Key in each project's Web.config appSettings).");
            }

            if (configured.Length < 32)
            {
                throw new InvalidOperationException("InternalApi:Key must be at least 32 characters.");
            }

            key = Encoding.UTF8.GetBytes(configured);
        }

        public bool Matches(string presented)
        {
            if (string.IsNullOrEmpty(presented))
            {
                return false;
            }

            var bytes = Encoding.UTF8.GetBytes(presented);
            return bytes.Length == key.Length && CompatCrypto.FixedTimeEquals(bytes, key);
        }
    }
}
