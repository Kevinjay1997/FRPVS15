﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Models
{
    /// <summary>
    /// "FileStorage" in appsettings.json: where project files are kept and what may be uploaded. The settings are read
    /// again whenever the file changes, so a new limit or folder applies without restarting the API. After changing
    /// RootPath, move the existing project folders to the new location (the database stores paths relative to it).
    /// </summary>
    public sealed class FileStorageOptions
    {
        public const string SectionName = "FileStorage";

        /// <summary>Folder for project files; a relative path is resolved against the API's content root.</summary>
        public string RootPath { get; set; } = "";

        /// <summary>
        /// Sub-folder of RootPath for uploaded XSDs, templates and specifications. Each is stored once by content (SHA-256),
        /// so uploading the same file again reuses it.
        /// </summary>
        public string SharedUploadsFolder { get; set; } = "";

        /// <summary>Largest single upload, in megabytes.</summary>
        public int MaxUploadMegabytes { get; set; }

        /// <summary>Allowed extensions per upload kind (see <see cref="UploadKinds"/>), e.g. "Template": [".xlsx", ".xlsm"].</summary>
        public Dictionary<string, List<string>> AllowedExtensions { get; set; } = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Largest bank reference file (branch register, sandbox report, source XML), in bytes; these are read into memory,
        /// so the limit is lower than <see cref="MaxUploadMegabytes"/>. The smaller of the two applies.
        /// </summary>
        public int MaxReferenceFileBytes { get; set; } = DefaultMaxReferenceFileBytes;

        public const int DefaultMaxReferenceFileBytes = 40000000;

        public long MaxUploadBytes => MaxUploadMegabytes * 1024L * 1024L;

        /// <summary>The reference file limit that applies: <see cref="MaxReferenceFileBytes"/>, but never more than <see cref="MaxUploadBytes"/>.</summary>
        public long EffectiveMaxReferenceFileBytes => Math.Min(MaxUploadBytes, MaxReferenceFileBytes);

        public IReadOnlyList<string> ExtensionsFor(string kind)  {
        List<string> extensions;
        return AllowedExtensions.TryGetValue(kind, out extensions) ? extensions : new List<string>();
    }
    }

    public sealed class FileStorageOptionsValidator : IValidateOptions<FileStorageOptions>
    {
        public ValidateOptionsResult Validate(string name, FileStorageOptions options)
        {
            var errors = new List<string>();
            if (string.IsNullOrWhiteSpace(options.RootPath))
            {
                errors.Add("FileStorage:RootPath is required.");
            }

            if (string.IsNullOrWhiteSpace(options.SharedUploadsFolder)
                || options.SharedUploadsFolder.Any(ch => !(char.IsLetterOrDigit(ch) || ch == '-' || ch == '_')))
            {
                errors.Add("FileStorage:SharedUploadsFolder must be a folder name (letters, digits, - or _), e.g. \"uploads\".");
            }

            if (options.MaxUploadMegabytes < 1 || options.MaxUploadMegabytes > 2048)
            {
                errors.Add("FileStorage:MaxUploadMegabytes must be between 1 and 2048.");
            }

            if (options.MaxReferenceFileBytes < 1)
            {
                errors.Add("FileStorage:MaxReferenceFileBytes must be a positive number of bytes.");
            }

            foreach (var kind in UploadKinds.All)
            {
                var extensions = options.ExtensionsFor(kind);
                if (extensions.Count == 0)
                {
                    errors.Add($"FileStorage:AllowedExtensions:{kind} needs at least one extension.");
                }

                foreach (var extension in extensions)
                {
                    if (extension.Length < 2 || extension[0] != '.' || extension.Skip(1).Any(ch => !char.IsLetterOrDigit(ch)))
                    {
                        errors.Add($"FileStorage:AllowedExtensions:{kind} contains '{extension}'; use values like \".xlsx\".");
                    }
                }
            }

            return errors.Count == 0 ? ValidateOptionsResult.Success : ValidateOptionsResult.Fail(errors);
        }
    }

}
