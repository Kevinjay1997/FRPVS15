using FrpMapper.Api.Hosting;

namespace FrpMapper.Api.Models
{
    /// <summary>
    /// What a Maker changes on a project's files (POST /api/projects/{id}/files): any of a new XSD, template and
    /// specification, or generate the template from the XSD, or remove the specification; optionally a new name.
    /// </summary>
    public sealed class ProjectFilesEdit
    {
        /// <summary>A new name, or null to keep it.</summary>
        public string Name { get; set; }

        public IFormFile XsdFile { get; set; }

        public IFormFile TemplateFile { get; set; }

        public IFormFile SpecificationFile { get; set; }

        /// <summary>Use an input template generated from the XSD instead of the uploaded one.</summary>
        public bool GenerateTemplate { get; set; }

        /// <summary>The project no longer uses a BSP specification.</summary>
        public bool RemoveSpecification { get; set; }

        /// <summary>
        /// With a new template: keep the person's mapped cells where the sheet still exists, instead of the new template's
        /// cells (the default, as BSP templates carry their own mapping).
        /// </summary>
        public bool KeepCells { get; set; }
    }
}
