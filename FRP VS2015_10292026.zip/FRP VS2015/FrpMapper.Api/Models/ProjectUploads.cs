﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Api.Models
{
    /// <summary>
    /// A project's uploaded files as stored (frp.usp_ProjectFile_List). <see cref="UploadedFileDto.StoredPath"/> is the
    /// full path on disk, so this stays inside the API; clients get <see cref="ReusableProjectFilesDto"/>.
    /// </summary>
    public sealed class ProjectUploads : IRecord<ProjectUploads>, IEquatable<ProjectUploads>
    {
        public string ProjectId { get; set; } = "";

        public string ProjectName { get; set; } = "";

        public bool TemplateGenerated { get; set; }

        public UploadedFileDto Xsd { get; set; }

        /// <summary>The BSP template the Maker uploaded; null when the project's template was generated from the XSD.</summary>
        public UploadedFileDto Template { get; set; }

        public UploadedFileDto Specification { get; set; }

        public bool Equals(ProjectUploads other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(ProjectId, other.ProjectId)
    && EqualityComparer<string>.Default.Equals(ProjectName, other.ProjectName)
    && EqualityComparer<bool>.Default.Equals(TemplateGenerated, other.TemplateGenerated)
    && EqualityComparer<UploadedFileDto>.Default.Equals(Xsd, other.Xsd)
    && EqualityComparer<UploadedFileDto>.Default.Equals(Template, other.Template)
    && EqualityComparer<UploadedFileDto>.Default.Equals(Specification, other.Specification);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ProjectUploads);
    }

        public static bool operator ==(ProjectUploads left, ProjectUploads right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ProjectUploads left, ProjectUploads right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 29206;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ProjectId);
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(ProjectName);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(TemplateGenerated);
    hash = hash * -1521134295 + EqualityComparer<UploadedFileDto>.Default.GetHashCode(Xsd);
    hash = hash * -1521134295 + EqualityComparer<UploadedFileDto>.Default.GetHashCode(Template);
    hash = hash * -1521134295 + EqualityComparer<UploadedFileDto>.Default.GetHashCode(Specification);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ProjectUploads { " + "ProjectId = " + ProjectId + ", " + "ProjectName = " + ProjectName + ", " + "TemplateGenerated = " + TemplateGenerated + ", " + "Xsd = " + Xsd + ", " + "Template = " + Template + ", " + "Specification = " + Specification + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ProjectUploads CloneRecord()
    {
    return (ProjectUploads)MemberwiseClone();
    }

    }

    /// <summary>Which files of an existing project a new project takes instead of new uploads.</summary>
    public sealed class ProjectFileReuse : IRecord<ProjectFileReuse>, IEquatable<ProjectFileReuse>
    {
        public string SourceProjectId { get; set; } = "";

        public bool Xsd { get; set; }

        public bool Template { get; set; }

        public bool Specification { get; set; }


        public bool Any => Xsd || Template || Specification;

        public bool Equals(ProjectFileReuse other)
    {
    if (ReferenceEquals(this, other))
    {
    return true;
    }

    if (ReferenceEquals(other, null) || other.GetType() != GetType())
    {
    return false;
    }

    return EqualityComparer<string>.Default.Equals(SourceProjectId, other.SourceProjectId)
    && EqualityComparer<bool>.Default.Equals(Xsd, other.Xsd)
    && EqualityComparer<bool>.Default.Equals(Template, other.Template)
    && EqualityComparer<bool>.Default.Equals(Specification, other.Specification);
    }

        public override bool Equals(object obj)
    {
    return Equals(obj as ProjectFileReuse);
    }

        public static bool operator ==(ProjectFileReuse left, ProjectFileReuse right)
    {
    return ReferenceEquals(left, right) || !ReferenceEquals(left, null) && left.Equals(right);
    }

        public static bool operator !=(ProjectFileReuse left, ProjectFileReuse right)
    {
    return !(left == right);
    }

        public override int GetHashCode()
    {
    unchecked
    {
    var hash = 44208;
    hash = hash * -1521134295 + EqualityComparer<string>.Default.GetHashCode(SourceProjectId);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Xsd);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Template);
    hash = hash * -1521134295 + EqualityComparer<bool>.Default.GetHashCode(Specification);
    return hash;
    }
    }

        public override string ToString()
    {
    return "ProjectFileReuse { " + "SourceProjectId = " + SourceProjectId + ", " + "Xsd = " + Xsd + ", " + "Template = " + Template + ", " + "Specification = " + Specification + ", " + "Any = " + Any + " }";
    }

        /// <summary>A shallow copy (what "with" starts from).</summary>
    public ProjectFileReuse CloneRecord()
    {
    return (ProjectFileReuse)MemberwiseClone();
    }

    }

}
