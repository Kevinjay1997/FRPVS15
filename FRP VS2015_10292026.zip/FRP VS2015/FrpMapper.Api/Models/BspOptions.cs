using System.Collections.Generic;

namespace FrpMapper.Api.Models
{
    /// <summary>
    /// "Bsp" in the API's configuration. Which hosts a BSP environment (Settings tab of BSP submission) may use is decided
    /// here by IT, not in the app: an environment whose host is not listed cannot be approved or used, so the bank's client
    /// certificate is never presented to another server.
    /// </summary>
    public sealed class BspOptions
    {
        public const string SectionName = "Bsp";

        /// <summary>Used when Bsp:AllowedHosts is not set: BSP's Report API host.</summary>
        public const string DefaultAllowedHost = "rapi.bsp.gov.ph";

        /// <summary>Bsp:AllowedHosts, lower case (";" or "," between hosts). HTTPS on port 443 only.</summary>
        public IReadOnlyList<string> AllowedHosts { get; set; } = new List<string> { DefaultAllowedHost };
    }
}
