﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.Hosting;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Api.Models
{
    /// <summary>
    /// "Database" in appsettings.json. The connection string itself is a secret and is not in appsettings.json:
    /// set ConnectionStrings:FrpDb with .NET user-secrets (development) or the environment variable
    /// ConnectionStrings__FrpDb (servers).
    /// </summary>
    public sealed class DatabaseOptions
    {
        public const string SectionName = "Database";

        /// <summary>Name of the connection string under ConnectionStrings.</summary>
        public string ConnectionStringName { get; set; } = "";

        /// <summary>Command timeout for stored procedures, in seconds (saving a large report writes about 100,000 rows).</summary>
        public int CommandTimeoutSeconds { get; set; }

        /// <summary>How long the roles, permissions and Active Directory groups are cached before they are read again.</summary>
        public int AccessCacheSeconds { get; set; }
    }

}
