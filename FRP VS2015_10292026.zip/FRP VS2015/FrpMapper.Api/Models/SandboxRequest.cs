using FrpMapper.Api.Hosting;
namespace FrpMapper.Api.Models
{
    public sealed class SandboxRequest
    {
        public string Operation { get; set; }
        /// <summary>True: use the bank's stored, approved certificate (BankKey); false: the PFX uploaded with this request.</summary>
        public bool UseStoredCertificate { get; set; }
        public IFormFile Certificate { get; set; }
        public string Password { get; set; }
        /// <summary>The bank profile (UNI, RB, ...) the report is submitted for. Its undertaking code is read on the server, never taken from the page.</summary>
        public string BankKey { get; set; }
        public IFormFile Xml { get; set; }
        public string ReportCode { get; set; }
        public string Period { get; set; }
        /// <summary>The key of the approved BSP environment (Settings tab), e.g. SANDBOX. Required for every BSP request.</summary>
        public string Environment { get; set; }
        /// <summary>A submission to a Production environment: the environment's key, typed by the person as confirmation.</summary>
        public string ConfirmEnvironment { get; set; }
        /// <summary>
        /// Optional: the reportInfo JSON as edited on the page. Absent: the server builds it from ReportCode and Period.
        /// When given it is sent as written after the server checks only that it is a JSON object.
        /// </summary>
        public string ReportInfo { get; set; }
        public string SubmissionId { get; set; }
        /// <summary>Validate page ("validate"): the project whose XML is sent, and which XML (generated, workbook or file).</summary>
        public string ProjectId { get; set; }
        public string Source { get; set; }
        /// <summary>Validate page, source "workbook": the filled Excel template the XML is built from.</summary>
        public IFormFile Workbook { get; set; }
        /// <summary>Set by the server only: where the request came from, for the audit trail.</summary>
        internal string Origin { get; set; }
    }
}
