# Deploying FRP Mapper to IIS (with the database)

```
Browser ──https──► IIS site "FrpMapper" (FrpMapper.Platform, port 443)
                         │ http://localhost:5088 (same server only)
                         ▼
                   IIS site "FrpMapperApi" (FrpMapper.Api, bound to 127.0.0.1)
                         │ stored procedures only (role frp_app)
                         ▼
                   SQL Server database (scripts in FRP Database/Scripts)
```

People reach only the Platform. The API listens on 127.0.0.1, so only the Platform on the same server can call it.
If you put the API on another server, give it an https binding and set the Platform's `ApiBaseUrl` to that https
address. The Platform refuses plain http to another machine.

Order: **1. server → 2. database → 3. publish → 4. IIS sites → 5. secrets → 6. first administrators → 7. check.**
The commands run in an elevated PowerShell on the server unless the step says otherwise.

## 1. Prepare the server

Windows Server 2016 or later (or Windows 10/11 for a test server), with .NET Framework 4.5.2 or later. Server 2016
ships with 4.6.2.

```powershell
# Windows Server
Install-WindowsFeature Web-Server, Web-Static-Content, Web-Http-Errors, Web-Filtering, Web-Asp-Net45, Web-Windows-Auth, Web-Mgmt-Console
# Windows 10/11 instead
Enable-WindowsOptionalFeature -Online -All -FeatureName IIS-WebServerRole, IIS-ASPNET45, IIS-WindowsAuthentication, IIS-ManagementConsole
```

- `Web-Windows-Auth` is needed only for `Authentication:Mode=Windows`. Leave **WebDAV Publishing** uninstalled; the
  API's web.config also switches its module off.
- You need an https certificate for the Platform's host name, in *Local Computer → Personal*.
- You need SQL Server 2016 SP1 or later on this server or another one.

## 2. Database

Do this from your development PC (where `FRP Database` is) or from any machine that has it. Use a SQL account that
may create databases, such as a DBA's.

1. **Decide the API's database login.** Prefer a Windows login, so there is no password to keep:
   - SQL Server on the same server as IIS: the application pool identity, `IIS APPPOOL\FrpMapperApi`.
   - SQL Server on another server: run the API's application pool as a domain service account (for example
     `CORP\svc-frpmapper`) and use that account.
   - Otherwise, a SQL login with a strong password.
2. **Build the tool.** Open `FRP Database\FrpDatabaseTool.VS2015\FrpDatabaseTool.sln`, choose Release, then Build.
3. **Deploy the scripts.** In a command prompt, set the connection strings for this window only. Environment variables
   win over the API's `Web.config`, so your development settings are not touched:
   ```bat
   cd "FRP Database\FrpDatabaseTool.VS2015\bin\Release"
   set "ConnectionStrings__FrpDbAdmin=Server=SQLHOST;Database=FrpMapper;Integrated Security=True;Encrypt=True"
   set "ConnectionStrings__FrpDb=Server=SQLHOST;Database=FrpMapper;Integrated Security=True;Encrypt=True"
   FrpDatabaseTool.exe --create-database
   ```
   - The command creates the database if it is missing and applies every script in one transaction (all or
     nothing). That includes `006_least_privilege.sql`, which creates role `frp_app`.
   - It then tests the data layer. The tests are rolled back and leave no data. The results go to
     `FRP Database\report.txt`.
   - The scripts can be run again safely: nothing is dropped, and data you changed is not overwritten.
   - Add `TrustServerCertificate=True` only if the SQL Server uses a self-signed certificate.
4. **Give the API its login.** Run this as the DBA, in the new database:
   ```sql
   CREATE LOGIN [IIS APPPOOL\FrpMapperApi] FROM WINDOWS;                -- or your service account / SQL login
   USE FrpMapper;
   CREATE USER [IIS APPPOOL\FrpMapperApi] FOR LOGIN [IIS APPPOOL\FrpMapperApi];
   ```
   Then run `FrpDatabaseTool.exe grant-app-user "IIS APPPOOL\FrpMapperApi"`. This adds the user to `frp_app` only,
   which allows running the procedures and nothing else.
5. **Check.** Run `FrpDatabaseTool.exe test`. `report.txt` should show no FAIL lines. When `FrpDb` uses Integrated
   Security, the tool checks it as *your* Windows account, so a WARN about a privileged login refers to you, not to
   the application pool.

## 3. Publish from Visual Studio 2015

For each of **FrpMapper.Api** and **FrpMapper.Platform**: right-click the project, choose **Publish…**, then
**Custom** and **File System**.

| | API | Platform |
|---|---|---|
| Target location | `C:\inetpub\FrpMapper\Api` | `C:\inetpub\FrpMapper\Platform` |
| Configuration | Release | Release |

- Under *File Publish Options*, leave **"Delete all existing files prior to publish"** off. That keeps each site's
  `App_Data` across updates.
- **Publishing copies `Web.config`, including your development key and connection string.** Set the server's own
  secrets as described in step 5, after every publish.
- The Release build applies `Web.Release.config`:
  - `Environment=Production`: no test users, https only, HSTS.
  - Compilation without debug and custom errors on.
  - On the Platform, `Authentication:Mode=ActiveDirectory` as well.
- Copy the published folders to the server if you published elsewhere.

## 4. Create the IIS sites

```powershell
Import-Module WebAdministration
foreach ($pool in 'FrpMapperApi', 'FrpMapperPlatform') {
    New-WebAppPool $pool
    Set-ItemProperty "IIS:\AppPools\$pool" managedRuntimeVersion v4.0          # Integrated pipeline (the default)
    Set-ItemProperty "IIS:\AppPools\$pool" processModel.idleTimeout ([TimeSpan]::Zero)
}

# API: this server only.
New-Website -Name FrpMapperApi -PhysicalPath C:\inetpub\FrpMapper\Api -ApplicationPool FrpMapperApi -IPAddress 127.0.0.1 -Port 5088

# Platform: https (plus http, which the Platform redirects to https).
New-Website -Name FrpMapper -PhysicalPath C:\inetpub\FrpMapper\Platform -ApplicationPool FrpMapperPlatform -Port 443 -Ssl -HostHeader frpmapper.corp.local
New-WebBinding -Name FrpMapper -Protocol http -Port 80 -HostHeader frpmapper.corp.local
$thumb = (Get-ChildItem Cert:\LocalMachine\My | Where-Object Subject -like '*frpmapper.corp.local*').Thumbprint
(Get-WebBinding -Name FrpMapper -Protocol https).AddSslCertificate($thumb, 'My')

# Writable folders: uploaded/generated files and logs.
New-Item -ItemType Directory -Force C:\inetpub\FrpMapper\Api\App_Data, C:\inetpub\FrpMapper\Platform\App_Data | Out-Null
icacls C:\inetpub\FrpMapper\Api\App_Data      /grant "IIS AppPool\FrpMapperApi:(OI)(CI)M"
icacls C:\inetpub\FrpMapper\Platform\App_Data /grant "IIS AppPool\FrpMapperPlatform:(OI)(CI)M"
```

Replace `frpmapper.corp.local` with your host name. For a domain service account, set it on the API pool:
*Advanced Settings → Identity*.

- **Sessions are kept in the Platform's memory.** Keep *Maximum Worker Processes* at 1 (no web garden) and don't
  load-balance the Platform without sticky sessions. An application pool recycle signs everyone out, so move the
  daily recycle to a quiet hour: *Recycling → Specific time*.
- **Project files** go to `App_Data\files` by default. For backups and upgrades, a folder outside the site is better.
  Set `FileStorage:RootPath` in the API's web.config (for example `D:\FrpMapperData\files`) and give
  `IIS AppPool\FrpMapperApi` Modify on that folder. The database stores paths relative to it, so back up the folder
  together with the database.

### Sign-in mode (Platform)

- **ActiveDirectory** (the Release default): the sign-in page checks user names and passwords with Windows. The
  server must be joined to the domain. Set `Authentication:DefaultDomain` to the NetBIOS domain, so people can type
  just their user name. Leave Anonymous Authentication on for the Platform site (the page itself must be reachable).
- **Windows** (no sign-in page, like MPVR): people are signed in as the Windows account they use on their PC. The
  sign-in rules still apply (locked, deactivated after 30 days without use, expired and disabled accounts are refused)
  and every sign-in is in the audit trail. Set `Authentication:Mode` to `Windows`, then turn on Windows
  Authentication and turn off Anonymous Authentication for the Platform site:
  ```powershell
  Set-WebConfigurationProperty -PSPath IIS:\ -Location FrpMapper -Filter /system.webServer/security/authentication/windowsAuthentication -Name enabled -Value True
  Set-WebConfigurationProperty -PSPath IIS:\ -Location FrpMapper -Filter /system.webServer/security/authentication/anonymousAuthentication -Name enabled -Value False
  ```
- Leave the API site on Anonymous authentication. It accepts only calls that carry the internal key, from the
  Platform.

## 5. Secrets on the server

Generate a new key for the server; don't reuse the development one:

```powershell
$bytes = New-Object byte[] 32; [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
[BitConverter]::ToString($bytes).Replace('-', '')        # 64 hex characters
```

The secrets are read from environment variables first, then from each site's `Web.config`. Publishing overwrites
`Web.config` with the development values, so the environment variables are the safer choice on a server: they
survive every publish. Set them on the application pools (IIS Manager → Configuration Editor →
`system.applicationHost/applicationPools` → the pool → `environmentVariables`):

| Pool | Variable | Value |
|---|---|---|
| FrpMapperApi | `InternalApi__Key` | the key |
| FrpMapperApi | `ConnectionStrings__FrpDb` | `Server=SQLHOST;Database=FrpMapper;Integrated Security=True;Encrypt=True` |
| FrpMapperPlatform | `InternalApi__Key` | the same key |
| FrpMapperApi | `Certificates__ProtectionKey` | another new random key (encrypts the banks' stored BSP certificates) |
| FrpMapperApi | `Bsp__AllowedHosts` | optional: the BSP hosts environments may use, e.g. `rapi.bsp.gov.ph` (the default when not set). Not a secret, but kept here so a publish cannot change it |

If you put them in the sites' `Web.config` instead (`InternalApi:Key` in `<appSettings>`, `FrpDb` in
`<connectionStrings>`), do it again after every publish, and allow only the application pool and administrators to
read the files. IIS never serves `Web.config`.

```powershell
icacls C:\inetpub\FrpMapper\Api\Web.config      /inheritance:r /grant:r "IIS AppPool\FrpMapperApi:R" "Administrators:F"
icacls C:\inetpub\FrpMapper\Platform\Web.config /inheritance:r /grant:r "IIS AppPool\FrpMapperPlatform:R" "Administrators:F"
```

`FrpDbAdmin` is never put on the server. It stays with the DBA, for the database tool.

`Certificates__ProtectionKey` must stay the same for the life of the server's database: the banks' BSP certificates
stored on Bank profiles are encrypted with it. Set it as an environment variable, not only in `Web.config`, because a
publish replaces `Web.config` with the development key. Keep it with the restore instructions, never inside a
database backup. If it is lost or changed, a bank profile Maker uploads each bank's certificate again and a Checker
approves it.

## 6. First administrators

In Production there are no test users, and nobody has a role until someone is given one. A DBA does this once, in
one of two ways. SRAU manages people and their roles; PARAM manages roles and permissions. Each team needs a Maker and
a Checker who are different people, because every change is approved by another person.

- **By person** (simplest): set the Windows accounts in `FRP Database\Setup\first_administrators_windows.sql` and run
  it. It gives `SRAU-Maker` and `SRAU-Checker` (and optionally `PARAM-Maker` / `PARAM-Checker`) to two different people.
- **By AD group**:

```sql
INSERT INTO frp.RoleDirectoryGroup (RoleKey, GroupName) VALUES
    ('SRAU-Maker',    N'CORP\FRP-SRAU-Maker'),
    ('SRAU-Checker',  N'CORP\FRP-SRAU-Checker'),
    ('PARAM-Maker',   N'CORP\FRP-PARAM-Maker'),
    ('PARAM-Checker', N'CORP\FRP-PARAM-Checker');
```

Use your real group names. From then on, SRAU members map the Maker, Checker and Administrator groups on the
**Access administration** screen. The application refuses combinations such as an administrator team member who is
also a Maker or Checker.

## 7. Check

On the server:

```powershell
Invoke-RestMethod http://localhost:5088/api/health     # status: Healthy
```

Then browse to `https://frpmapper.corp.local/`. You should see the sign-in page; sign in as a member of an SRAU
group. Both sites write their logs to `App_Data\logs`.

| Symptom | Cause |
|---|---|
| HTTP 500.19 | ASP.NET 4.x is not installed in IIS (step 1), or the pool is not v4.0 / Integrated |
| "InternalApi:Key is not configured" | The key is missing in the pool's environment variables and in `Web.config`, or the keys differ |
| "The FRP Mapper API cannot be reached" | The FrpMapperApi site is stopped, or `ApiBaseUrl` is wrong |
| "The connection string ... is not configured" | `ConnectionStrings__FrpDb` / `FrpDb` in the API's `Web.config` is missing |
| Login failed for `IIS APPPOOL\FrpMapperApi` | Step 2.4 was not done on that SQL Server, or SQL Server is on another machine (use a domain account) |
| Signed in, but "You don't have access yet" | The person's AD groups are not mapped to a role (step 6) |
| Uploads fail / no logs | The pool has no Modify permission on `App_Data` (or on `FileStorage:RootPath`) |

## Updating

1. Database: rerun `FrpDatabaseTool.exe` (step 2.3). It is safe to rerun and runs in one transaction.
2. Application: publish again (step 3). `App_Data` is kept; `Web.config` is replaced (step 5). To show a maintenance page while
   copying, put an `app_offline.htm` in the site folder and remove it afterwards.
3. Back up the database and the project files folder together.
