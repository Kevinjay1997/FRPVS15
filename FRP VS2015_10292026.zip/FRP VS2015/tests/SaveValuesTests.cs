// Tests of FrpMappingService.SaveValuesAsync (values typed on the Sheet view): checked against the XSD rules before
// anything is saved; only a Maker on an editable project; a hidden project reads as not found.
// Arguments: <BSP template .xlsx> <its XSD>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Models;

class ValuesUser : ICurrentUser
{
    public string Name { get; set; }
    public string[] Granted { get; set; }
    public bool IsAuthenticated => true;
    public bool HasPermission(string p) => Granted.Contains(p);
    public IReadOnlyList<string> Roles => new string[0];
    public IReadOnlyList<string> Permissions => Granted;
}

class ValuesRepo : IProjectRepository
{
    public FrpProjectDto Project;
    public int Saves;
    public Task<FrpProjectDto> GetAsync(string id, CancellationToken c) => Task.FromResult(Project.Id == id ? Project : null);
    public Task<IReadOnlyList<ProjectSummaryDto>> ListAsync(CancellationToken c) => Task.FromResult<IReadOnlyList<ProjectSummaryDto>>(new[] { new ProjectSummaryDto { Id = Project.Id, UpdatedAt = Project.UpdatedAt, CreatedBy = "maker1" } });
    public Task<FrpProjectDto> SaveMappingsAsync(FrpProjectDto p, CancellationToken c) { Saves++; Project = p; return Task.FromResult(p); }
    public Task<IDisposable> LockAsync(string id, CancellationToken c) => Task.FromResult<IDisposable>(new Gate());
    public Task<FrpProjectDto> CreateAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> SaveWorkflowAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> SaveSampleValuesAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> SaveSheetSplitsAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpMapper.Api.Models.ProjectUploads> GetUploadsAsync(string id, CancellationToken c) { throw new NotImplementedException(); }
    public Task<IReadOnlyList<ProjectSummaryDto>> FindByFilesAsync(string a, string b, string d, string e, CancellationToken c) { throw new NotImplementedException(); }
    public Task<bool> DeleteAsync(string id, byte[] v, string by, DateTimeOffset at, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> RenameAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> ReplaceSourcesAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
    sealed class Gate : IDisposable { public void Dispose() { } }
}

class Audit : IAuditLog
{
    public List<AuditEntryDto> Entries = new List<AuditEntryDto>();
    public Task AppendAsync(AuditEntryDto entry, CancellationToken c) { Entries.Add(entry); return Task.FromResult(0); }
    public Task<IReadOnlyList<AuditEntryDto>> QueryAsync(string projectId, int take, CancellationToken c) { throw new NotImplementedException(); }
    public Task<IReadOnlyList<AuditEntryDto>> QueryByUserAsync(string userName, int take, CancellationToken c) { throw new NotImplementedException(); }
    public Task<AuditPageDto> QueryPageAsync(string projectId, string search, string action, int skip, int take, CancellationToken c) { throw new NotImplementedException(); }
}

static class SaveValuesTests
{
    static int checks;
    static void Check(bool ok, string what) { if (!ok) throw new Exception("FAILED: " + what); checks++; Console.WriteLine("ok: " + what); }

    static T Throws<T>(Func<object> action) where T : Exception
    {
        try { action(); }
        catch (AggregateException ex) when (ex.InnerException is T) { return (T)ex.InnerException; }
        catch (T ex) { return ex; }
        throw new Exception("FAILED: expected " + typeof(T).Name);
    }

    static int Main(string[] args)
    {
        var inspector = new OpenXmlWorkbookInspector();
        var parsed = new XsdSchemaParser().Parse(args[1]);
        var plan = new MappingSuggestionEngine().CreateInitialMappings(parsed.Nodes, inspector.Inspect(args[0]));
        var repo = new ValuesRepo
        {
            Project = new FrpProjectDto
            {
                Id = new string('e', 32), Name = "Values", RootElement = parsed.RootElement, TargetNamespace = parsed.TargetNamespace,
                SchemaNodes = parsed.Nodes, Mappings = plan.Mappings, UpdatedAt = DateTimeOffset.UtcNow, XsdFile = new UploadedFileDto { StoredPath = args[1] },
                Workflow = new ProjectWorkflowDto { Status = ProjectStatus.Draft, CreatedBy = "maker1" }
            }
        };
        var audit = new Audit();
        Func<ValuesUser, FrpMappingService> service = user => new FrpMappingService(repo, new ProjectAccess(repo, user), null, null, null, null, null, null, null,
            new XsdProjectValidator(new XmlSubmissionWriter(), new BspSpecificationValidator(new BspSpecificationReader(inspector), new BspAssertionEvaluator(), new BankReferenceContext(), new BspDerivedValues())), null, null, null, null, null, null, user, audit, null, null, null, null, null, new ProjectReadCache());
        var maker = new ValuesUser { Name = "maker1", Granted = new[] { Permissions.ProjectRead, Permissions.ProjectEdit } };
        var checker = new ValuesUser { Name = "checker1", Granted = new[] { Permissions.ProjectRead, Permissions.ProjectReadAll, Permissions.SubmissionReview } };
        var stranger = new ValuesUser { Name = "maker2", Granted = new[] { Permissions.ProjectRead, Permissions.ProjectEdit } };
        var nodes = parsed.Nodes.ToDictionary(n => n.Path, StringComparer.OrdinalIgnoreCase);
        var number = plan.Mappings.First(m => nodes[m.SchemaPath].DataType == "decimal" && nodes[m.SchemaPath].Validation.FractionDigits == 2);
        var code = plan.Mappings.First(m => nodes[m.SchemaPath].Validation.Enumerations.Count > 0);
        // One field is left unmapped (the app maps every field of this XSD somewhere).
        var unmapped = nodes[plan.Mappings.Last(m => m.SchemaPath != number.SchemaPath && m.SchemaPath != code.SchemaPath).SchemaPath];
        repo.Project = repo.Project.With(p => { p.Mappings = plan.Mappings.Where(m => m.SchemaPath != unmapped.Path).ToList(); });
        var id = repo.Project.Id;
        Func<CellValueDto[], SaveValuesResultDto> save = values => service(maker).SaveValuesAsync(id, values, CancellationToken.None).Result;

        // A valid number and a valid code are saved; the mappings stay as they were.
        var before = repo.Project.Mappings.Select(m => m.SheetName + "!" + m.CellAddress + "=" + m.SchemaPath).ToList();
        var ok = save(new[] { new CellValueDto { SchemaPath = number.SchemaPath, Value = "1234.5" }, new CellValueDto { SchemaPath = code.SchemaPath, Value = nodes[code.SchemaPath].Validation.Enumerations[0] } });
        Check(ok.Errors.Count == 0 && ok.Project != null && repo.Saves == 1, "valid values are saved");
        Check(repo.Project.Mappings.First(m => m.SchemaPath == number.SchemaPath).DefaultValue == "1234.5", "the typed number is the field's value");
        Check(repo.Project.Mappings.Select(m => m.SheetName + "!" + m.CellAddress + "=" + m.SchemaPath).SequenceEqual(before), "no mapping moved");
        Check(audit.Entries.Last().Action == "Values saved", "the save is audited");

        // One bad value: nothing is saved, and every refused value is named with its XSD error.
        var bad = save(new[] { new CellValueDto { SchemaPath = number.SchemaPath, Value = "12.345" }, new CellValueDto { SchemaPath = code.SchemaPath, Value = "NOT-A-CODE" } });
        Check(bad.Project == null && bad.Errors.Count == 2 && repo.Saves == 1, "invalid values: nothing saved (" + string.Join(" | ", bad.Errors.Select(e => e.Errors[0])) + ")");
        Check(repo.Project.Mappings.First(m => m.SchemaPath == number.SchemaPath).DefaultValue == "1234.5", "the earlier value is kept");
        var mixed = save(new[] { new CellValueDto { SchemaPath = number.SchemaPath, Value = "99" }, new CellValueDto { SchemaPath = code.SchemaPath, Value = "NOT-A-CODE" } });
        Check(mixed.Errors.Count == 1 && repo.Saves == 1 && repo.Project.Mappings.First(m => m.SchemaPath == number.SchemaPath).DefaultValue == "1234.5", "a valid value sent with an invalid one is not saved either");
        Check(save(new[] { new CellValueDto { SchemaPath = number.SchemaPath, Value = "abc" } }).Errors.Count == 1, "text in a number field is refused");
        Check(save(new[] { new CellValueDto { SchemaPath = unmapped.Path, Value = "1" } }).Errors[0].Errors[0].Contains("not mapped"), "a field that is not mapped is refused");
        Check(save(new[] { new CellValueDto { SchemaPath = "/NO/SUCH/FIELD", Value = "1" } }).Errors[0].Errors[0].Contains("does not contain"), "a path not in the XSD is refused");
        Check(save(new[] { new CellValueDto { SchemaPath = number.SchemaPath, Value = "1\u0000" } }).Errors.Count == 1, "control characters are refused");

        // A blank value empties the cell (no sample value); null puts the sample value back.
        Func<string, string> stored = path => repo.Project.Mappings.First(m => m.SchemaPath == path).DefaultValue;
        var blank = save(new[] { new CellValueDto { SchemaPath = number.SchemaPath, Value = "  " } });
        Check(blank.Errors.Count == 0 && stored(number.SchemaPath) == "", "a blank value empties the cell (stored as an empty text)");
        var requiredField = plan.Mappings.First(m => nodes[m.SchemaPath].IsRequired && nodes[m.SchemaPath].DataType == "decimal" && m.SchemaPath != number.SchemaPath && m.SchemaPath != unmapped.Path);
        Check(save(new[] { new CellValueDto { SchemaPath = requiredField.SchemaPath, Value = "" } }).Errors.Count == 0, "a required field can be emptied too (validation reports it)");
        Check(repo.Project.Issues.Any(i => i.SchemaPath == requiredField.SchemaPath && i.Message.Contains("no value yet")), "validation reports the empty required field");
        var xml = new XmlSubmissionWriter().BuildDocument(repo.Project);
        var leaf = xml.Descendants().FirstOrDefault(e => e.Name.LocalName == nodes[requiredField.SchemaPath].Name && !e.HasElements);
        Check(leaf != null && leaf.Value == "", "the XML has the required element empty, not the sample value");
        Check(!xml.Descendants().Any(e => e.Name.LocalName == nodes[number.SchemaPath].Name && e.Value == nodes[number.SchemaPath].TestValue), "the emptied field's sample value is not in the XML");
        var back = save(new[] { new CellValueDto { SchemaPath = number.SchemaPath, Value = null } });
        Check(back.Errors.Count == 0 && stored(number.SchemaPath) == nodes[number.SchemaPath].TestValue, "null puts the sample value back");

        // Remove / restore the sample values of a sheet or the whole project; entered values are kept.
        save(new[] { new CellValueDto { SchemaPath = number.SchemaPath, Value = "777" } });
        var sheet = number.SheetName;
        var onSheet = repo.Project.Mappings.Count(m => m.SheetName == sheet);
        var emptyBefore = repo.Project.Mappings.Count(m => m.SheetName == sheet && m.DefaultValue == "");
        var removed = service(maker).ChangeSampleValuesAsync(id, "remove", sheet, CancellationToken.None).Result;
        Check(removed.Changed == onSheet - 1 - emptyBefore, "remove on " + sheet + ": " + removed.Changed + " of " + onSheet + " fields emptied (the entered one kept, " + emptyBefore + " already empty)");
        Check(stored(number.SchemaPath) == "777", "the entered value is kept");
        Check(repo.Project.Mappings.Where(m => m.SheetName == sheet && m.SchemaPath != number.SchemaPath).All(m => m.DefaultValue == ""), "every other field of the sheet is empty");
        Check(repo.Project.Mappings.Where(m => m.SheetName != sheet).All(m => m.DefaultValue != ""), "other sheets keep their sample values");
        Check(audit.Entries.Last().Action == "Sample values removed", "removing is audited");
        var again = service(maker).ChangeSampleValuesAsync(id, "remove", sheet, CancellationToken.None).Result;
        Check(again.Changed == 0, "removing again changes nothing");
        var restored = service(maker).ChangeSampleValuesAsync(id, "restore", sheet, CancellationToken.None).Result;
        Check(restored.Changed == onSheet - 1 && repo.Project.Mappings.Where(m => m.SheetName == sheet && m.SchemaPath != number.SchemaPath).All(m => m.DefaultValue == nodes[m.SchemaPath].TestValue), "restore gives the emptied fields their sample values back");
        Check(stored(number.SchemaPath) == "777", "and keeps the entered value");
        var all = service(maker).ChangeSampleValuesAsync(id, "remove", null, CancellationToken.None).Result;
        Check(all.Changed == repo.Project.Mappings.Count - 1, "remove on the whole project empties every sample value (" + all.Changed + ")");
        var view = service(maker).GetAsync(id, CancellationToken.None).Result;
        Check(view.Mappings.Where(m => m.SchemaPath != number.SchemaPath).All(m => m.DefaultValue == "") && view.Mappings.First(m => m.SchemaPath == number.SchemaPath).DefaultValue == "777",
            "opening the project keeps the emptied cells empty (no sample values put back)");
        Check(Throws<WorkflowException>(() => service(maker).ChangeSampleValuesAsync(id, "delete", null, CancellationToken.None).Result).Kind == WorkflowErrorKind.Invalid, "an unknown action is refused");
        Check(Throws<WorkflowException>(() => service(checker).ChangeSampleValuesAsync(id, "restore", null, CancellationToken.None).Result).Kind == WorkflowErrorKind.Forbidden, "a Checker cannot change sample values");
        Check(service(stranger).ChangeSampleValuesAsync(id, "restore", null, CancellationToken.None).Result == null, "another Maker's project reads as not found");
        service(maker).ChangeSampleValuesAsync(id, "restore", null, CancellationToken.None).Wait();

        // Limits and rules.
        Check(Throws<WorkflowException>(() => save(new CellValueDto[0])).Kind == WorkflowErrorKind.Invalid, "an empty request is refused");
        Check(Throws<WorkflowException>(() => save(Enumerable.Range(0, FrpMappingService.MaxValuesPerSave + 1).Select(i => new CellValueDto { SchemaPath = number.SchemaPath, Value = "1" }).ToArray())).Kind == WorkflowErrorKind.Invalid, "too many values are refused");
        Check(Throws<WorkflowException>(() => service(checker).SaveValuesAsync(id, new[] { new CellValueDto { SchemaPath = number.SchemaPath, Value = "1" } }, CancellationToken.None).Result).Kind == WorkflowErrorKind.Forbidden, "a Checker cannot type values");
        Check(service(stranger).SaveValuesAsync(id, new[] { new CellValueDto { SchemaPath = number.SchemaPath, Value = "1" } }, CancellationToken.None).Result == null, "another Maker's project reads as not found");
        Check(service(maker).SaveValuesAsync("not-an-id", new[] { new CellValueDto { SchemaPath = number.SchemaPath, Value = "1" } }, CancellationToken.None).Result == null, "a bad project id is not found");
        repo.Project = repo.Project.With(p => { p.Workflow = p.Workflow.With(w => { w.Status = ProjectStatus.InReview; }); });
        Check(Throws<WorkflowException>(() => save(new[] { new CellValueDto { SchemaPath = number.SchemaPath, Value = "1" } })).Kind == WorkflowErrorKind.Conflict, "a project in review cannot be changed (409)");
        // The XML the Validate page sends to a BSP test environment is built on the server, as validation builds it.
        Func<ValuesUser, FrpMappingService> sandboxSource = user => new FrpMappingService(repo, new ProjectAccess(repo, user), null, null, null, null, new XmlSubmissionWriter(), null, null,
            null, null, null, null, null, null, null, user, audit, null, null, null, null, null, new ProjectReadCache());
        var built = sandboxSource(maker).XmlForSandboxAsync(id, "generated", null, CancellationToken.None).Result;
        Check(built != null && built.Value.Bytes.SequenceEqual(new XmlSubmissionWriter().Write(repo.Project)) && built.Value.FileName == "Values.xml",
            "sandbox: the XML built from the project's values, as validated");
        Check(sandboxSource(stranger).XmlForSandboxAsync(id, "generated", null, CancellationToken.None).Result == null, "sandbox: another Maker's project reads as not found");
        Check(sandboxSource(maker).XmlForSandboxAsync("not-an-id", "generated", null, CancellationToken.None).Result == null, "sandbox: a bad project id is not found");
        Check(Throws<WorkflowException>(() => sandboxSource(maker).XmlForSandboxAsync(id, "approved", null, CancellationToken.None).Result).Kind == WorkflowErrorKind.Invalid,
            "sandbox: an unknown source is refused");

        Console.WriteLine("SaveValuesTests: " + checks + " checks passed");
        return 0;
    }
}
