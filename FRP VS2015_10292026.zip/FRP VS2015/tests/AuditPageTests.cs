// Tests of ProjectWorkflowService.AuditPageAsync (the Audit trail and History pages, one page at a time): who may read
// which trail, the page / page size / search / action checks, and what is passed to the data layer.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Models;

class PageUser : ICurrentUser
{
    public string Name { get; set; }
    public string[] Granted { get; set; }
    public bool IsAuthenticated => true;
    public bool HasPermission(string p) => Granted.Contains(p);
    public IReadOnlyList<string> Roles => new string[0];
    public IReadOnlyList<string> Permissions => Granted;
}

class PageRepo : IProjectRepository
{
    public FrpProjectDto Project;
    public Task<FrpProjectDto> GetAsync(string id, CancellationToken c) => Task.FromResult(Project.Id == id ? Project : null);
    public Task<IReadOnlyList<ProjectSummaryDto>> ListAsync(CancellationToken c) => Task.FromResult<IReadOnlyList<ProjectSummaryDto>>(new[] { new ProjectSummaryDto { Id = Project.Id, UpdatedAt = Project.UpdatedAt, CreatedBy = "maker1" } });
    public Task<FrpProjectDto> SaveMappingsAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
    public Task<IDisposable> LockAsync(string id, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> CreateAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> SaveWorkflowAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> SaveSampleValuesAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> SaveSheetSplitsAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpMapper.Api.Models.ProjectUploads> GetUploadsAsync(string id, CancellationToken c) { throw new NotImplementedException(); }
    public Task<IReadOnlyList<ProjectSummaryDto>> FindByFilesAsync(string a, string b, string d, string e, CancellationToken c) { throw new NotImplementedException(); }
    public Task<bool> DeleteAsync(string id, byte[] v, string by, DateTimeOffset at, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> RenameAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> ReplaceSourcesAsync(FrpProjectDto p, CancellationToken c) { throw new NotImplementedException(); }
}

/// <summary>An in-memory trail with the same paging as frp.usp_AuditEntry_Page.</summary>
class PagedAudit : IAuditLog
{
    public List<AuditEntryDto> Entries = new List<AuditEntryDto>();
    public List<string> Calls = new List<string>();
    public Task AppendAsync(AuditEntryDto entry, CancellationToken c) { Entries.Add(entry); return Task.FromResult(0); }
    public Task<IReadOnlyList<AuditEntryDto>> QueryAsync(string projectId, int take, CancellationToken c) { throw new NotImplementedException(); }
    public Task<IReadOnlyList<AuditEntryDto>> QueryByUserAsync(string userName, int take, CancellationToken c) { throw new NotImplementedException(); }
    public Task<AuditPageDto> QueryPageAsync(string projectId, string search, string action, int skip, int take, CancellationToken c)
    {
        Calls.Add((projectId ?? "*") + "|" + (search ?? "-") + "|" + (action ?? "-") + "|" + skip + "|" + take);
        Func<string, bool> has = v => v != null && v.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0;
        var matching = Enumerable.Reverse(Entries)
            .Where(e => projectId == null || e.ProjectId == projectId)
            .Where(e => action == null || e.Action == action)
            .Where(e => search == null || has(e.User) || has(e.Address) || has(e.Action) || has(e.ProjectName) || has(e.Details))
            .ToList();
        var actions = Entries.Where(e => projectId == null || e.ProjectId == projectId).Select(e => e.Action).Distinct().OrderBy(a => a, StringComparer.Ordinal).ToList();
        return Task.FromResult(new AuditPageDto { Entries = matching.Skip(skip).Take(take).ToList(), Total = matching.Count, Actions = actions });
    }
}

static class AuditPageTests
{
    static int checks;
    static void Check(bool ok, string what) { if (!ok) throw new Exception("FAILED: " + what); checks++; Console.WriteLine("ok: " + what); }

    static T Throws<T>(Func<object> action) where T : Exception
    {
        try { action(); }
        catch (AggregateException ex) when (ex.InnerException is T) { return (T)ex.InnerException; }
        catch (T ex) { return ex; }
        throw new Exception("FAILED: expected " + typeof(T).Name);
    }

    static int Main()
    {
        var id = new string('d', 32);
        var other = new string('f', 32);
        var repo = new PageRepo { Project = new FrpProjectDto { Id = id, Name = "Paged", UpdatedAt = DateTimeOffset.UtcNow, Workflow = new ProjectWorkflowDto { Status = ProjectStatus.Draft, CreatedBy = "maker1" } } };
        var audit = new PagedAudit();
        var start = DateTimeOffset.UtcNow.AddDays(-1);
        for (var i = 1; i <= 120; i++)
        {
            audit.Entries.Add(new AuditEntryDto
            {
                Id = Guid.NewGuid().ToString("N"), At = start.AddMinutes(i), User = i % 3 == 0 ? "checker1" : "maker1",
                Action = i % 10 == 0 ? "Approved" : "Mappings saved", ProjectId = i % 4 == 0 ? other : id, ProjectName = i % 4 == 0 ? "Other" : "Paged",
                Details = "entry " + i + (i == 77 ? " 100%_done [x]" : ""), Address = "10.0.0." + (i % 5)
            });
        }

        Func<PageUser, ProjectWorkflowService> service = user => new ProjectWorkflowService(repo, new ProjectAccess(repo, user), null, null, audit, user, null);
        var admin = new PageUser { Name = "admin", Granted = new[] { Permissions.AuditReadAll, Permissions.ProjectRead, Permissions.ProjectReadAll } };
        var maker = new PageUser { Name = "maker1", Granted = new[] { Permissions.ProjectRead, Permissions.ProjectEdit } };
        var stranger = new PageUser { Name = "maker2", Granted = new[] { Permissions.ProjectRead, Permissions.ProjectEdit } };
        var nobody = new PageUser { Name = "guest", Granted = new string[0] };
        Func<PageUser, string, int, int, string, string, AuditPageDto> page = (u, p, n, size, search, action) =>
            service(u).AuditPageAsync(p, n, size, search, action, CancellationToken.None).Result;

        // The whole trail, newest first, in pages.
        var first = page(admin, null, 1, 25, null, null);
        Check(first.Total == 120 && first.Entries.Count == 25 && first.Page == 1 && first.PageSize == 25, "page 1 of the trail: 25 of 120");
        Check(first.Entries[0].Details == "entry 120" && first.Entries[24].Details == "entry 96", "newest first");
        var last = page(admin, null, 5, 25, null, null);
        Check(last.Entries.Count == 20 && last.Entries.Last().Details == "entry 1", "the last page has the remaining 20, down to the oldest");
        Check(audit.Calls.Last() == "*|-|-|100|25", "page 5 of 25 skips 100 (" + audit.Calls.Last() + ")");
        Check(page(admin, null, 9, 25, null, null).Entries.Count == 0, "a page past the end is empty (not an error)");
        Check(first.Actions.SequenceEqual(new[] { "Approved", "Mappings saved" }), "the actions are listed for the filter");

        // Filters.
        var approved = page(admin, null, 1, 10, null, "Approved");
        Check(approved.Total == 12 && approved.Entries.All(e => e.Action == "Approved"), "action filter: 12 Approved entries");
        var checkerOnly = page(admin, null, 1, 100, "  checker1 ", null);
        Check(checkerOnly.Total == 40 && audit.Calls.Last().StartsWith("*|checker1|"), "search is trimmed and finds the person (40 entries)");
        Check(page(admin, null, 1, 10, "100%_done [x]", null).Total == 1, "search text with % _ [ is plain text");
        Check(page(admin, null, 1, 10, "   ", "  ").Total == 120 && audit.Calls.Last() == "*|-|-|0|10", "blank search and action mean no filter");

        // A project's history.
        var history = page(maker, id, 1, 50, null, null);
        Check(history.Total == 90 && history.Entries.All(e => e.ProjectId == id), "a project's history holds only its entries (90)");
        Check(page(stranger, id, 1, 10, null, null) == null, "a project the person may not see reads as not found");
        Check(page(maker, "not-an-id", 1, 10, null, null) == null && page(maker, new string('9', 32), 1, 10, null, null) == null, "a bad or unknown project id reads as not found");

        // Permissions.
        var denied = Throws<WorkflowException>(() => page(maker, null, 1, 25, null, null));
        Check(denied.Kind == WorkflowErrorKind.Forbidden, "the whole trail needs audit.read-all (" + denied.Message + ")");
        Check(Throws<WorkflowException>(() => page(nobody, id, 1, 25, null, null)).Kind == WorkflowErrorKind.Forbidden, "a project's history needs project.read");

        // Arguments.
        var callsBefore = audit.Calls.Count;
        Check(Throws<WorkflowException>(() => page(admin, null, 0, 25, null, null)).Kind == WorkflowErrorKind.Invalid, "page 0 is refused");
        Check(Throws<WorkflowException>(() => page(admin, null, 1000001, 25, null, null)).Kind == WorkflowErrorKind.Invalid, "an absurd page is refused (no overflow)");
        Check(Throws<WorkflowException>(() => page(admin, null, 1, 7, null, null)).Kind == WorkflowErrorKind.Invalid, "a page size other than 10, 25, 50, 100 is refused");
        Check(Throws<WorkflowException>(() => page(admin, null, 1, 5000, null, null)).Kind == WorkflowErrorKind.Invalid, "a huge page size is refused");
        Check(Throws<WorkflowException>(() => page(admin, null, 1, 25, new string('a', 201), null)).Kind == WorkflowErrorKind.Invalid, "a search over 200 characters is refused");
        Check(Throws<WorkflowException>(() => page(admin, null, 1, 25, "a\u0000b", null)).Kind == WorkflowErrorKind.Invalid, "control characters are refused");
        Check(Throws<WorkflowException>(() => page(admin, null, 1, 25, null, "x\nDROP")).Kind == WorkflowErrorKind.Invalid, "an action with control characters is refused");
        Check(audit.Calls.Count == callsBefore, "refused requests never reach the database");

        Console.WriteLine(checks + " checks passed");
        return 0;
    }
}
