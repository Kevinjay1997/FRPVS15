// Tests of the XML tools (the Workbench's merge, cleanup, report period, normalizer and XSD check), their Maker / Checker
// configuration service, the logs (LogService, LogFileStore) and the error shown when the database scripts were not run.
// Arguments: <Workbench Config folder> <fixtures folder> <temporary folder>
// The fixtures folder holds report XML files and what the Workbench's own code made of them (*.expected.*).
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using FrpMapper.Api.BL;
using FrpMapper.Api.BL.XmlTools;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

static class XmlToolsTests
{
    static int checks;
    static void Check(bool ok, string name) { if (!ok) throw new Exception("FAILED: " + name); checks++; Console.WriteLine("ok: " + name); }

    static async Task RefusedAsync(Func<Task> action, string name, WorkflowErrorKind kind = WorkflowErrorKind.Invalid)
    {
        try { await action(); }
        catch (WorkflowException e) { Check(e.Kind == kind, name + " (" + kind + ": " + e.Message + ")"); return; }
        throw new Exception("FAILED: accepted " + name);
    }

    static string configDir, fixtures, tempDir;
    static XmlToolsConfiguration configuration;

    // ---------- fakes ----------

    class User : ICurrentUser
    {
        public string UserName; public HashSet<string> Granted = new HashSet<string>();
        public string Name { get { return UserName; } }
        public bool IsAuthenticated { get { return true; } }
        public bool HasPermission(string p) { return Granted.Contains(p); }
        public IReadOnlyList<string> Roles { get { return new string[0]; } }
        public IReadOnlyList<string> Permissions { get { return Granted.ToList(); } }
    }

    class Versions : IWorkbenchConfigRepository
    {
        public List<StoredWorkbenchConfig> Rows = new List<StoredWorkbenchConfig>();
        long next = 1;
        string NextVersion() { return Convert.ToBase64String(BitConverter.GetBytes(next++)); }
        public Task<IReadOnlyList<WorkbenchConfigVersionDto>> ListAsync(string kind, CancellationToken c) { return Task.FromResult((IReadOnlyList<WorkbenchConfigVersionDto>)Rows.Where(r => r.Version.Kind == kind).Select(r => r.Version).ToList()); }
        public Task<StoredWorkbenchConfig> GetAsync(string id, CancellationToken c) { return Task.FromResult(Rows.FirstOrDefault(r => r.Version.Id == id)); }
        public Task<StoredWorkbenchConfig> GetActiveAsync(string kind, CancellationToken c) { return Task.FromResult(Rows.FirstOrDefault(r => r.Version.Kind == kind && r.Version.Status == "Active")); }
        public Task<WorkbenchConfigVersionDto> RequestAsync(StoredWorkbenchConfig config, CancellationToken c)
        {
            if (Rows.Any(r => r.Version.Kind == config.Version.Kind && r.Version.Status == "Pending")) throw new AccessRequestOpenException("open");
            config.Version.Status = "Pending"; config.Version.Version = NextVersion(); Rows.Add(config); return Task.FromResult(config.Version);
        }
        public Task<bool> DecideAsync(string id, byte[] expected, string decision, string by, DateTimeOffset at, string comment, CancellationToken c)
        {
            var row = Rows.FirstOrDefault(r => r.Version.Id == id);
            if (row == null) return Task.FromResult(false);
            var v = row.Version;
            if (!Convert.FromBase64String(v.Version).SequenceEqual(expected) || v.Status != "Pending") throw new ConcurrencyConflictException("changed");
            if ((decision == "Approved" || decision == "Rejected") && v.RequestedBy == by) throw new AccessDecisionRefusedException("self");
            if (decision == "Approved") foreach (var a in Rows.Where(r => r.Version.Kind == v.Kind && r.Version.Status == "Active")) a.Version.Status = "Replaced";
            v.Status = decision == "Approved" ? "Active" : decision; v.DecidedBy = by; v.DecidedAt = at; v.Version = NextVersion();
            return Task.FromResult(true);
        }
    }

    class Audit : IAuditLog
    {
        public List<AuditEntryDto> Entries = new List<AuditEntryDto>();
        public Task AppendAsync(AuditEntryDto e, CancellationToken c) { Entries.Add(e); return Task.FromResult(0); }
        public Task<IReadOnlyList<AuditEntryDto>> QueryAsync(string s, int n, CancellationToken c) { throw new NotImplementedException(); }
        public Task<IReadOnlyList<AuditEntryDto>> QueryByUserAsync(string s, int n, CancellationToken c) { throw new NotImplementedException(); }
        public Task<AuditPageDto> QueryPageAsync(string p, string s, string a, int k, int n, CancellationToken c) { throw new NotImplementedException(); }
    }

    static IFormFile Upload(string path, string name = null)
    {
        return new MemoryFormFile("file", name ?? Path.GetFileName(path), File.ReadAllBytes(path));
    }

    static int Main(string[] args)
    {
        configDir = args[0]; fixtures = args[1]; tempDir = args[2];
        Directory.CreateDirectory(tempDir);
        Configuration();
        Merge();
        Normalize();
        SchemaCheck();
        Services().Wait();
        Logs();
        Console.WriteLine("XmlToolsTests: " + checks + " checks passed");
        return 0;
    }

    // ---------- the configuration ----------

    static void Configuration()
    {
        var content = XmlToolsConfiguration.FromFiles(File.ReadAllBytes(Path.Combine(configDir, "merge.csv")), File.ReadAllBytes(Path.Combine(configDir, "cleanup.csv")),
            File.ReadAllBytes(Path.Combine(configDir, "reportperiod.csv")), "MAIN_Y1_Item, main_y1_item");
        var problems = new List<string>();
        configuration = XmlToolsConfiguration.Load(content, problems);
        Check(configuration != null && problems.Count == 0, "the Workbench's merge.csv, cleanup.csv and reportperiod.csv load");
        Check(configuration.Merge.Any(m => m.Key == "FRP_9A2" && m.Value == "FRP_9A234") && configuration.Cleanup.SequenceEqual(new[] { "RCBP", "FRPTI_D2", "MRA", "INTRA" }),
            "merge rules and the elements cleaned");
        Check(configuration.ReportsByPeriod["Monthly"].Contains("FRP_1") && !configuration.ReportsByPeriod["Monthly"].Contains("FRP_3A"), "reports per period");
        Check(configuration.NonRemovableItems.SequenceEqual(new[] { "MAIN_Y1_Item" }), "the kept _Item rows, once each");
        Check(Encoding.UTF8.GetString(XmlToolsConfiguration.ToCsv(content.Merge)).StartsWith("From,To\r\nLCR_III_CO_SNGL,LCR_III_CO\r\n"), "downloaded as the CSV it was");

        problems.Clear();
        var broken = XmlToolsConfiguration.FromFiles(Encoding.UTF8.GetBytes("Source,Target\r\nA,B\r\n"), Encoding.UTF8.GetBytes("Clean\r\n"), Encoding.UTF8.GetBytes("Report,Daily\r\n"), "");
        Check(XmlToolsConfiguration.Load(broken, problems) == null && problems.Any(p => p.Contains("merge.csv has no column From, To")) && problems.Any(p => p.Contains("reportperiod.csv has no column Weekly")),
            "files without the Workbench's columns are refused");
    }

    // ---------- merge, compared with what the Workbench's MergeXml made ----------

    static XDocument Load(string path)
    {
        using (var stream = File.OpenRead(path)) return SafeXml.Load(stream, LoadOptions.PreserveWhitespace);
    }

    static byte[] Save(XDocument document)
    {
        using (var stream = new MemoryStream()) { document.Save(stream); return stream.ToArray(); }
    }

    static void Merge()
    {
        var result = new XmlMergeResultDto();
        var merged = new XmlMerger(configuration).Merge(Load(Path.Combine(fixtures, "FRP_split.xml")), "", result);
        Check(Save(merged).SequenceEqual(File.ReadAllBytes(Path.Combine(fixtures, "FRP_split.expected.xml"))), "the merged file is the Workbench's, byte for byte");
        Check(result.Merged.Count == 9 && result.Merged[0] == "FRP_9A2 → FRP_9A234" && result.RemovedEmpty.SequenceEqual(new[] { "INTRA" }), "what was merged and left out");
        Check(merged.Root.Elements().Any(e => e.Name.LocalName == "MRA" && e.Elements().First().Name.LocalName == "MRA"), "the _EWB_RECURSIVE_ELEMENT_ suffix is removed");

        var monthly = new XmlMergeResultDto();
        var period = new XmlMerger(configuration).Merge(Load(Path.Combine(fixtures, "FRP_split.xml")), "Monthly", monthly);
        Check(Save(period).SequenceEqual(File.ReadAllBytes(Path.Combine(fixtures, "FRP_split.Monthly.expected.xml"))), "kept to the Monthly reports: the Workbench's file");
        Check(monthly.OutsidePeriod.Count == 173 && period.Root.Elements().First().Name.LocalName == "Header", "173 reports left out; the Header always stays");

        // The Workbench added a merged element's last row once per row: rows 2 and 3 of FRP_9A3 became row 4 twice.
        var multi = new XmlMerger(configuration).Merge(Load(Path.Combine(fixtures, "FRP_split_multi.xml")), "", new XmlMergeResultDto());
        var bookcodes = multi.Root.Elements().First(e => e.Name.LocalName == "FRP_9A234").Elements().Select(i => i.Elements().First(e => e.Name.LocalName == "Bookcode").Value).ToList();
        Check(bookcodes.SequenceEqual(new[] { "1", "2", "3", "4" }), "every row of a merged element is kept, once (" + string.Join(",", bookcodes) + ")");

        var nowhere = XDocument.Parse("<FRP><Header/><X/><FRP_9A2><FRP_9A234_Item><A>1</A></FRP_9A234_Item></FRP_9A2><FRP_9A3><FRP_9A234_Item><A>2</A></FRP_9A234_Item></FRP_9A3></FRP>");
        var ok = new XmlMerger(configuration).Merge(nowhere, "", new XmlMergeResultDto());
        Check(ok.Root.Elements().First(e => e.Name.LocalName == "FRP_9A234").Elements().Count() == 2, "a merged element's rows join the first");
        var bad = XDocument.Parse("<FRP><Header/><X/><FRP_9A2><Note>x</Note><FRP_9A234_Item><A>1</A></FRP_9A234_Item></FRP_9A2><FRP_9A3><FRP_9A234_Item><A>2</A></FRP_9A234_Item></FRP_9A3></FRP>");
        try { new XmlMerger(configuration).Merge(bad, "", new XmlMergeResultDto()); Check(false, "refused"); }
        catch (XmlToolsException e) { Check(e.Message.Contains("Note"), "nowhere to add the rows: refused with the element named (" + e.Message + ")"); }
    }

    static void Normalize()
    {
        var schemas = XmlSchemaChecker.Load(File.ReadAllText(Path.Combine(fixtures, "frp.xsd")));
        var merged = new XmlMerger(configuration).Merge(Load(Path.Combine(fixtures, "FRP_zero.xml")), "", new XmlMergeResultDto());
        var bytes = Save(merged);
        Check(bytes.SequenceEqual(File.ReadAllBytes(Path.Combine(fixtures, "FRP_zero.expected.xml"))), "merged with zero rows and empty codes: the Workbench's file");
        XDocument document;
        using (var stream = new MemoryStream(bytes)) document = SafeXml.Load(stream, LoadOptions.PreserveWhitespace);
        var normalizer = new XmlNormalizer(schemas, configuration.NonRemovableItems);
        var log = new List<string>();
        normalizer.Normalize(document, log);
        Check(Save(document).SequenceEqual(File.ReadAllBytes(Path.Combine(fixtures, "FRP_zero.normalized.expected.xml"))), "the normalized file is the Workbench's, byte for byte");
        Check(normalizer.ItemsRemoved == 18 && normalizer.SectionsRemoved == 21, "18 rows and 21 sections removed");
        Check(log.SequenceEqual(File.ReadAllLines(Path.Combine(fixtures, "FRP_zero.normalizer.expected.log"))), "the normalizer's log has the Workbench's lines");
    }

    static void SchemaCheck()
    {
        var schemas = XmlSchemaChecker.Load(File.ReadAllText(Path.Combine(fixtures, "frp.xsd")));
        var issues = XmlSchemaChecker.Check(File.OpenRead(Path.Combine(fixtures, "FRP_zero.expected.xml")), schemas);
        var lines = issues.Select(i => i.Line + "|" + i.Severity + "|" + i.Message + "|" + i.Path).ToList();
        Check(lines.SequenceEqual(File.ReadAllLines(Path.Combine(fixtures, "FRP_zero.xsd.expected.txt"))), "the XSD messages are the Workbench's: " + lines.Count + " with line and node path");
        var unreadable = XmlSchemaChecker.Check(new MemoryStream(Encoding.UTF8.GetBytes("<FRP><Header>")), schemas);
        Check(unreadable.Count >= 1 && unreadable.Last().Severity == "Error", "a file that is not well-formed is an error, not a crash");
        var dtd = XmlSchemaChecker.Check(new MemoryStream(Encoding.UTF8.GetBytes("<!DOCTYPE FRP [<!ENTITY e SYSTEM \"file:///etc/passwd\">]><FRP>&e;</FRP>")), schemas);
        Check(dtd.Any(i => i.Message.Contains("DTD")), "a file with a DTD is refused, its entities are not read");
    }

    // ---------- the services ----------

    static async Task Services()
    {
        var versions = new Versions();
        var audit = new Audit();
        var storage = new FixedOptions<FileStorageOptions>(new FileStorageOptions { RootPath = tempDir, MaxUploadMegabytes = 50 });
        var outputs = new CocreeOutputStore(storage, new HostEnvironment("Development", tempDir));
        var maker = new User { UserName = "CORP\\maker", Granted = { FrpMapper.Shared.Models.Permissions.ReferenceManage } };
        var checker = new User { UserName = "CORP\\checker", Granted = { FrpMapper.Shared.Models.Permissions.ReferenceApprove } };
        var preparer = new User { UserName = "CORP\\preparer", Granted = { FrpMapper.Shared.Models.Permissions.SubmissionPrepare } };
        var nobody = new User { UserName = "CORP\\nobody" };
        Func<User, XmlToolsConfigService> settings = u => new XmlToolsConfigService(versions, u, storage);
        Func<XmlToolsConfigUpload> upload = () => new XmlToolsConfigUpload
        {
            MergeCsv = Upload(Path.Combine(configDir, "merge.csv")), CleanupCsv = Upload(Path.Combine(configDir, "cleanup.csv")),
            ReportPeriodCsv = Upload(Path.Combine(configDir, "reportperiod.csv")), NonRemovableItems = "MAIN_Y1_Item", Note = "From the Workbench"
        };

        await RefusedAsync(() => settings(preparer).UploadAsync(upload(), CancellationToken.None), "only a Maker uploads the XML tools configuration", WorkflowErrorKind.Forbidden);
        var bad = upload(); bad.MergeCsv = new MemoryFormFile("f", "merge.xlsx", new byte[3]);
        await RefusedAsync(() => settings(maker).UploadAsync(bad, CancellationToken.None), "the files must be .csv");
        var first = await settings(maker).UploadAsync(upload(), CancellationToken.None);
        Check(first.Kind == WorkbenchConfigKind.XmlTools && first.Status == "Pending" && first.Summary.Facts.Any(f => f.Label == "merge rules" && f.Count > 0), "uploaded as Pending");
        await RefusedAsync(() => settings(maker).DecideAsync(first.Id, "approve", new AccessDecisionRequest { Version = first.Version }, CancellationToken.None), "the Maker cannot approve", WorkflowErrorKind.Forbidden);

        var service = new XmlToolsService(versions, outputs, preparer, audit, storage);
        Func<string, IFormFile> fixture = name => Upload(Path.Combine(fixtures, name));
        Check(!(await service.SetupAsync(CancellationToken.None)).Configured, "nothing to merge with before the first approval");
        await RefusedAsync(() => service.MergeAsync(new XmlMergeRequest { Xml = fixture("FRP_split.xml") }, CancellationToken.None), "merging waits for an approved configuration", WorkflowErrorKind.Conflict);
        Check(await settings(checker).DecideAsync(first.Id, "approve", new AccessDecisionRequest { Version = first.Version }, CancellationToken.None), "another Checker approves");
        var setup = await service.SetupAsync(CancellationToken.None);
        Check(setup.Configured && setup.ReportPeriods.Count == 6 && setup.CleanupElements.Contains("INTRA"), "setup: the periods and the configuration in use");

        var merged = await service.MergeAsync(new XmlMergeRequest { Xml = fixture("FRP_zero.xml"), Xsd = fixture("frp.xsd"), Normalize = true }, CancellationToken.None);
        Check(merged.OutputFile.StartsWith("FRP_zero_EXPORTED_ON_") && merged.NormalizedFile.EndsWith("_NORMALIZED.xml") && merged.NormalizerItemsRemoved == 18 && merged.Schema != null,
            "merge, normalize and check in one go");
        using (var normalized = service.Download(merged.OutputId, merged.NormalizedFile).Content)
        using (var copy = new MemoryStream())
        {
            normalized.CopyTo(copy);
            Check(copy.ToArray().SequenceEqual(File.ReadAllBytes(Path.Combine(fixtures, "FRP_zero.normalized.expected.xml"))), "the downloaded normalized file is the Workbench's");
        }

        Check(service.Download(merged.OutputId, merged.NormalizerLog) != null && merged.Schema.Report != null && service.Download(merged.OutputId, merged.Schema.Report).ContentType == "text/csv",
            "the normalizer's log and the XSD messages can be downloaded");
        Check(audit.Entries.Last().Action == "XML merged" && audit.Entries.Last().Details.Contains("SHA-256"), "merging is in the audit trail");
        var other = new XmlToolsService(versions, outputs, new User { UserName = "CORP\\other", Granted = { FrpMapper.Shared.Models.Permissions.SubmissionPrepare } }, audit, storage);
        Check(other.Download(merged.OutputId, merged.OutputFile) == null, "someone else cannot download it");
        await RefusedAsync(() => service.MergeAsync(new XmlMergeRequest { Xml = fixture("FRP_split.xml"), ReportPeriod = "Hourly" }, CancellationToken.None), "an unknown period");
        await RefusedAsync(() => service.MergeAsync(new XmlMergeRequest { Xml = new MemoryFormFile("f", "x.xml", Encoding.UTF8.GetBytes("<a><b></a>")) }, CancellationToken.None), "XML that is not well-formed");
        await RefusedAsync(() => new XmlToolsService(versions, outputs, nobody, audit, storage).MergeAsync(new XmlMergeRequest { Xml = fixture("FRP_split.xml") }, CancellationToken.None),
            "the XML tools need submission.prepare", WorkflowErrorKind.Forbidden);

        var check = await service.ValidateAsync(fixture("FRP_zero.expected.xml"), fixture("frp.xsd"), CancellationToken.None);
        Check(!check.Schema.Valid && check.Schema.IssueCount == 30 && check.Schema.Issues[0].Path.StartsWith("<FRP>") && audit.Entries.Last().Action == "XML checked against XSD",
            "any XML against any XSD, in the audit trail");
        await RefusedAsync(() => service.ValidateAsync(fixture("FRP_split.xml"), new MemoryFormFile("f", "bad.xsd", Encoding.UTF8.GetBytes("<nope/>")), CancellationToken.None),
            "an XSD that is not a schema");

        var download = await settings(preparer).DownloadAsync(first.Id, "reportperiod", CancellationToken.None);
        Check(download != null && download.FileName.StartsWith("reportperiod_active_") && download.ContentType == "text/csv", "the configuration in use can be downloaded as CSV");
    }

    // ---------- logs ----------

    static void Logs()
    {
        var folder = Path.Combine(tempDir, "logs");
        Directory.CreateDirectory(folder);
        File.WriteAllLines(Path.Combine(folder, "api-20261028.log"), new[]
        {
            "2026-10-28 22:39:23.889 Error       FrpMapper.Api: Unhandled error for /api/cocree/config",
            "System.Data.SqlClient.SqlException (0x80131904): Could not find stored procedure 'frp.usp_CocreeConfig_List'. Server=db1;User ID=frp_app;Password=Secret123;",
            "2026-10-28 22:40:00.000 Warning     FrpMapper.Api: Authorization: Bearer abc.def.ghi and X-Api-Key: k3y",
            "2026-10-28 22:41:00.000 Information FrpMapper.Api: ok"
        });
        File.WriteAllText(Path.Combine(folder, "secrets.json"), "{}");
        var store = new LogFileStore(Path.Combine(folder, "api.log"));
        var auditor = new User { UserName = "CORP\\auditor", Granted = { FrpMapper.Shared.Models.Permissions.AuditReadAll } };
        var logs = new LogService(store, auditor);
        var list = logs.List();
        Check(list.Files.Count == 1 && list.Files[0].Name == "api-20261028.log", "only the API's dated log files are listed");
        var content = logs.Read("api-20261028.log", 500);
        var text = string.Join("\n", content.Lines);
        Check(content.Errors == 1 && content.Warnings == 1 && content.Lines.Count == 4, "errors and warnings are counted");
        Check(!text.Contains("Secret123") && !text.Contains("frp_app") && !text.Contains("abc.def.ghi") && !text.Contains("k3y") && text.Contains("Password=***"), "secrets are masked");
        Check(logs.Read("secrets.json", 10) == null && logs.Read("../api-20261028.log", 10) == null && logs.Download("api-99999999.log") == null, "nothing else can be read");
        var tail = logs.Read("api-20261028.log", 2);
        Check(tail.Truncated && tail.Lines.Count == 2 && tail.Lines[1].EndsWith("ok"), "the last lines of a file");
        try { new LogService(store, new User { UserName = "CORP\\x", Granted = { FrpMapper.Shared.Models.Permissions.SubmissionPrepare } }).List(); Check(false, "refused"); }
        catch (WorkflowException e) { Check(e.Kind == WorkflowErrorKind.Forbidden, "the logs need audit.read-all"); }
        Check(new LogFileStore(null).List().Count == 0, "no log file configured: nothing listed");
    }
}
