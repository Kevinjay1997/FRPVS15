"""Check XLSX local ZIP headers, including data-descriptor flags that unzip -t misses.

Usage: python3 tests/check_xlsx_zip_headers.py exported-template.xlsx
"""
import struct
import sys
import zipfile


def check(path):
    with zipfile.ZipFile(path) as archive, open(path, "rb") as stream:
        assert archive.testzip() is None, "ZIP CRC check failed"
        for entry in archive.infolist():
            stream.seek(entry.header_offset)
            header = stream.read(30)
            signature, _, flags, _, _, _, crc, compressed, size, name_length, extra_length = struct.unpack(
                "<IHHHHHIIIHH", header
            )
            assert signature == 0x04034B50, f"Missing local header: {entry.filename}"
            assert flags == entry.flag_bits, f"ZIP flags disagree: {entry.filename}"
            if flags & 8:
                stream.seek(entry.header_offset + 30 + name_length + extra_length + entry.compress_size)
                descriptor = stream.read(16)
                if descriptor[:4] == b"PK\x07\x08":
                    descriptor = descriptor[4:]
                assert len(descriptor) >= 12, f"Missing data descriptor: {entry.filename}"
                crc, compressed, size = struct.unpack("<III", descriptor[:12])
            assert (crc, compressed, size) == (entry.CRC, entry.compress_size, entry.file_size), (
                f"Local ZIP metadata disagrees: {entry.filename}"
            )
        print(f"ZIP headers valid: {len(archive.infolist())} parts")


if __name__ == "__main__":
    check(sys.argv[1])
