// Tests of the sheet view of the Mappings tab: TemplateGridReader (a template sheet laid out as Excel shows it) and
// TemplateGridService (permission, project visibility, sheet-name checks, and the app's own mappings).
// Arguments: <BSP template .xlsx> <its XSD> [<other template .xlsx>...]
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.BL;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

class GridUser : ICurrentUser
{
    public string Name { get; set; }
    public bool CanRead { get; set; }
    public bool IsAuthenticated => true;
    public bool HasPermission(string p) => CanRead && p == FrpMapper.Shared.Models.Permissions.ProjectRead;
    public IReadOnlyList<string> Roles => new string[0];
    public IReadOnlyList<string> Permissions => new string[0];
}

/// <summary>Only GetAsync is used by TemplateGridService (it is how project visibility is applied).</summary>
class Projects : IFrpMappingService
{
    public FrpProjectDto Project;
    public int Reads;
    public Task<FrpProjectDto> GetAsync(string id, CancellationToken c) { Reads++; return Task.FromResult(Project != null && Project.Id == id ? Project : null); }
    public Task<FrpProjectDto> AnalyzeAsync(string a, FrpMapper.Api.Hosting.IFormFile b, FrpMapper.Api.Hosting.IFormFile c, FrpMapper.Api.Hosting.IFormFile d, FrpMapper.Api.Models.ProjectFileReuse e, CancellationToken f, IProgress<ValidationProgressDto> g = null) { throw new NotImplementedException(); }
    public Task<ReusableProjectFilesDto> GetReusableFilesAsync(string a, CancellationToken b) { throw new NotImplementedException(); }
    public Task<TemplateAccountCodesDto> GetAccountCodesAsync(string a, CancellationToken b) { throw new NotImplementedException(); }
    public Task<IReadOnlyList<ProjectSummaryDto>> FindProjectsWithFilesAsync(ProjectFilesCheckRequest a, CancellationToken b) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> UpdateMappingsAsync(string a, IReadOnlyList<MappingEntryDto> b, CancellationToken c) { throw new NotImplementedException(); }
    public Task<SaveValuesResultDto> SaveValuesAsync(string a, IReadOnlyList<CellValueDto> b, CancellationToken c) { throw new NotImplementedException(); }
    public Task<SampleValuesResultDto> ChangeSampleValuesAsync(string a, string b, string d, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> RenameAsync(string a, string b, CancellationToken c) { throw new NotImplementedException(); }
    public Task<ProjectEditResultDto> ReplaceFilesAsync(string a, FrpMapper.Api.Models.ProjectFilesEdit b, CancellationToken c, IProgress<ValidationProgressDto> p = null) { throw new NotImplementedException(); }
    public Task<SampleRefillDto> RefillSampleValuesAsync(string a, CancellationToken b) { throw new NotImplementedException(); }
    public Task<FrpMapper.Shared.Compat.VT_FileName_Bytes<string, byte[]>?> MergeSheetCopiesXmlAsync(string a, FrpMapper.Api.Hosting.IFormFile b, CancellationToken c) { throw new NotImplementedException(); }
    public Task<SheetSplitSettingsDto> GetSheetSplitsAsync(string a, CancellationToken b) { throw new NotImplementedException(); }
    public Task<FrpProjectDto> SaveSheetSplitsAsync(string a, IReadOnlyList<SheetSplitDto> b, CancellationToken c) { throw new NotImplementedException(); }
    public Task<ProjectValidationResultDto> ValidateAsync(string a, IReadOnlyList<MappingEntryDto> b, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpMapper.Shared.Compat.VT_FileName_ContentType_Bytes<string, string, byte[]>?> ExportXmlAsync(string a, ExportValues b, CancellationToken c) { throw new NotImplementedException(); }
    public Task<FrpMapper.Shared.Compat.VT_FileName_ContentType_Bytes<string, string, byte[]>?> ExportMappedTemplateAsync(string a, ExportValues b, CancellationToken c) { throw new NotImplementedException(); }
    public Task<TemplateCoverageDto> CheckExportedTemplateAsync(string a, ExportValues b, CancellationToken c) { throw new NotImplementedException(); }
    public Task<TemplateCoverageDto> CheckUploadedTemplateAsync(string a, FrpMapper.Api.Hosting.IFormFile b, CancellationToken c) { throw new NotImplementedException(); }
    public Task<XsdValidationResultDto> ValidateGeneratedXmlAsync(string a, CancellationToken b, IProgress<ValidationProgressDto> c = null) { throw new NotImplementedException(); }
    public Task<XsdValidationResultDto> ValidateUploadedXmlAsync(string a, FrpMapper.Api.Hosting.IFormFile b, CancellationToken c, IProgress<ValidationProgressDto> d = null) { throw new NotImplementedException(); }
    public Task<XsdValidationResultDto> ValidateFilledTemplateAsync(string a, FrpMapper.Api.Hosting.IFormFile b, CancellationToken c, IProgress<ValidationProgressDto> d = null) { throw new NotImplementedException(); }
    public FilledTemplateXml BuildFromFilledTemplate(FrpProjectDto a, byte[] b, string c, IProgress<ValidationProgressDto> d = null) { throw new NotImplementedException(); }
    public XsdValidationResultDto ValidateXml(FrpProjectDto a, byte[] b, string c) { throw new NotImplementedException(); }
    public byte[] GenerateSubmissionXml(FrpProjectDto a) { throw new NotImplementedException(); }
    public Task<IReadOnlyList<ProjectSummaryDto>> ListAsync(CancellationToken a) { throw new NotImplementedException(); }
}

static class TemplateGridTests
{
    static int checks;
    static int Row(string a) { int r; return int.TryParse(new string(a.SkipWhile(char.IsLetter).ToArray()), out r) ? r : 0; }
    static int Col(string a) { return a.TakeWhile(char.IsLetter).Aggregate(0, (n, ch) => n * 26 + char.ToUpperInvariant(ch) - 'A' + 1); }
    static void Check(bool ok, string what) { if (!ok) throw new Exception("FAILED: " + what); checks++; }

    static T Throws<T>(Func<object> action) where T : Exception
    {
        try { action(); }
        catch (AggregateException ex) when (ex.InnerException is T) { return (T)ex.InnerException; }
        catch (T ex) { return ex; }
        throw new Exception("FAILED: expected " + typeof(T).Name);
    }

    static int Main(string[] args)
    {
        var template = args[0];
        var xsd = args[1];
        var cache = new MemoryCache();
        var reader = new TemplateGridReader(cache);
        var inspector = new OpenXmlWorkbookInspector();
        var workbook = inspector.Inspect(template);

        // 1. Every sheet of every template given is read; text cells match what the workbook inspector reads.
        foreach (var path in args.Where(a => a.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase)))
        {
            var book = inspector.Inspect(path);
            var sw = Stopwatch.StartNew();
            var largest = "";
            var largestCells = 0;
            foreach (var sheet in book.Sheets)
            {
                var grid = reader.Read(path, sheet.Name);
                Check(grid != null, "sheet " + sheet.Name + " is read");
                Check(grid.SheetName == sheet.Name, "the sheet's own name is returned");
                Check(!grid.Truncated, sheet.Name + " fits the grid limits");
                var texts = new HashSet<string>(grid.Cells.Where(c => c.Text.Trim().Length > 0).Select(c => c.Address));
                var missing = sheet.Cells.Where(c => !texts.Contains(c.Address.ToUpperInvariant())).ToList();
                Check(missing.Count == 0, sheet.Name + ": every text cell the inspector reads is in the grid (missing " + string.Join(", ", missing.Take(5).Select(c => c.Address)) + ")");
                Check(grid.Cells.All(c => Row(c.Address) <= grid.MaxRow && Col(c.Address) <= grid.MaxColumn), sheet.Name + ": cells inside MaxRow/MaxColumn");
                Check(grid.Cells.All(c => c.Fill == null || System.Text.RegularExpressions.Regex.IsMatch(c.Fill, "^#[0-9A-F]{6}$")), sheet.Name + ": fills are #RRGGBB");
                Check(grid.Merges.All(m => System.Text.RegularExpressions.Regex.IsMatch(m, "^[A-Z]+[0-9]+:[A-Z]+[0-9]+$")), sheet.Name + ": merges are A1:B2 ranges");
                if (grid.Cells.Count > largestCells) { largestCells = grid.Cells.Count; largest = sheet.Name + " (" + grid.MaxRow + " rows x " + grid.MaxColumn + " columns, " + grid.Merges.Count + " merges)"; }
            }
            Console.WriteLine($"{Path.GetFileName(path)}: {book.Sheets.Count} sheets read in {sw.ElapsedMilliseconds} ms; largest {largest}, {largestCells} cells");
        }

        // 2. Read once per file: the same object comes from the cache; the name is matched ignoring case.
        var first = reader.Read(template, workbook.Sheets[0].Name);
        Check(ReferenceEquals(first, reader.Read(template, workbook.Sheets[0].Name)), "a sheet is read once (cache)");
        Check(reader.Read(template, workbook.Sheets[0].Name.ToLowerInvariant())?.SheetName == workbook.Sheets[0].Name, "sheet names match ignoring case");
        Check(reader.Read(template, "No such sheet") == null, "an unknown sheet is null");
        Check(reader.Read(template + ".missing", workbook.Sheets[0].Name) == null, "a missing file is null");

        // 3. The service: permission, visibility, sheet-name checks and the app's mappings.
        var parsed = new XsdSchemaParser().Parse(xsd);
        var project = new FrpProjectDto
        {
            Id = new string('b', 32), Name = "Grid", RootElement = parsed.RootElement, TargetNamespace = parsed.TargetNamespace,
            SchemaNodes = parsed.Nodes, TemplateFile = new UploadedFileDto { StoredPath = template }, XsdFile = new UploadedFileDto { StoredPath = xsd }, UpdatedAt = DateTimeOffset.UtcNow
        };
        var engine = new MappingSuggestionEngine();
        var plan = engine.CreateInitialMappings(parsed.Nodes, workbook);
        project.Mappings = plan.Mappings;
        var projects = new Projects { Project = project };
        var reader2 = new TemplateGridReader(new MemoryCache());
        Func<GridUser, TemplateGridService> service = user => new TemplateGridService(projects, reader2, inspector, engine, new XsdInputTemplateGenerator(),
            new BspSpecificationReader(inspector), user, new MemoryCache(), new OpenXmlMappedTemplateWriter());
        var maker = new GridUser { Name = "maker1", CanRead = true };
        var noRead = new GridUser { Name = "nobody", CanRead = false };

        var denied = Throws<WorkflowException>(() => service(noRead).GetSheetAsync(project.Id, workbook.Sheets[0].Name, CancellationToken.None).Result);
        Check(denied.Kind == WorkflowErrorKind.Forbidden, "no project.read: forbidden (sheet)");
        denied = Throws<WorkflowException>(() => service(noRead).GetSuggestedMappingsAsync(project.Id, CancellationToken.None).Result);
        Check(denied.Kind == WorkflowErrorKind.Forbidden, "no project.read: forbidden (suggested)");
        Check(service(maker).GetSheetAsync(new string('c', 32), workbook.Sheets[0].Name, CancellationToken.None).Result == null, "another (or hidden) project reads as not found");
        Check(service(maker).GetSuggestedMappingsAsync(new string('c', 32), CancellationToken.None).Result == null, "another (or hidden) project: no suggestions");
        foreach (var bad in new[] { "", "   ", new string('x', 32), "Sheet\u0001" })
        {
            var invalid = Throws<WorkflowException>(() => service(maker).GetSheetAsync(project.Id, bad, CancellationToken.None).Result);
            Check(invalid.Kind == WorkflowErrorKind.Invalid, "a bad sheet name is refused: '" + bad + "'");
        }

        var sheetGrid = service(maker).GetSheetAsync(project.Id, workbook.Sheets[0].Name, CancellationToken.None).Result;
        Check(sheetGrid != null && sheetGrid.Cells.Count > 0, "the service returns the template's sheet");
        Check(service(maker).GetSheetAsync(project.Id, "No such sheet", CancellationToken.None).Result == null, "the service: unknown sheet is not found");

        // A list the downloaded template enters as item rows (one table row per currency) is shown as the template lays it
        // out, each table cell linked to the form cell the field is mapped to.
        var gridService = service(maker);
        var itemRows = gridService.GetSheetAsync(project.Id, "CAR_Part_IV_1d", CancellationToken.None).Result;
        Func<string, string> formCellOf = path => project.Mappings.First(m => m.SchemaPath == path).CellAddress;
        var firstLink = itemRows.Links.FirstOrDefault(l => l.SchemaPath.EndsWith("/MAIN/R0010C0010"));
        Check(itemRows.Links.Count == 68 && firstLink != null && firstLink.TemplateCell == "D15" && firstLink.FormCell == formCellOf(firstLink.SchemaPath)
            && itemRows.Links.All(l => l.FormCell == formCellOf(l.SchemaPath) && l.TemplateCell.EndsWith("15")),
            "CAR_Part_IV_1d: the 68 fields are linked from the template's table row (D15 = R0010C0010) to their form cells (" + (firstLink == null ? "-" : firstLink.FormCell) + ")");
        Check(itemRows.ItemTables.Count == 1 && itemRows.ItemTables[0].Range == "A3:BR15" && itemRows.ItemTables[0].DataRow == 15
            && itemRows.ItemTables[0].ItemPath == "/CAR_M/CAR_Part_IV_1d/CAR_Part_IV_1d_Item",
            "CAR_Part_IV_1d: the item table's area (" + string.Join(", ", itemRows.ItemTables.Select(t => t.Range)) + ")");
        Check(itemRows.Cells.Any(c => c.Address == "A4" && c.Text.StartsWith("Each row of the table below is one CAR_Part_IV_1d_Item"))
            && itemRows.Cells.Any(c => c.Address == "D14" && c.Text == "R0010C0010") && !itemRows.Cells.Any(c => c.Text == "R0160"),
            "CAR_Part_IV_1d: the grid is the downloaded template's (note, headings, element names), not the BSP form");
        Check(ReferenceEquals(itemRows, gridService.GetSheetAsync(project.Id, "CAR_Part_IV_1d", CancellationToken.None).Result), "the template's sheet is made once while the mappings stay the same");
        var plain = gridService.GetSheetAsync(project.Id, "CAR_Part_II", CancellationToken.None).Result;
        Check(plain.Links.Count == 0 && plain.ItemTables.Count == 0 && ReferenceEquals(plain, reader2.Read(template, "CAR_Part_II")),
            "CAR_Part_II (lists on their own row): the uploaded template's sheet, no links");
        var noTemplate = project.With(copy => { copy.TemplateFile = null; });
        Check(new TemplateGridService(new Projects { Project = noTemplate }, reader2, inspector, engine, new XsdInputTemplateGenerator(), new BspSpecificationReader(inspector), maker, new MemoryCache(), new OpenXmlMappedTemplateWriter())
            .GetSheetAsync(project.Id, workbook.Sheets[0].Name, CancellationToken.None).Result == null, "a project without a template has no sheet");

        var sw2 = Stopwatch.StartNew();
        var suggested = service(maker).GetSuggestedMappingsAsync(project.Id, CancellationToken.None).Result;
        var firstMs = sw2.ElapsedMilliseconds;
        Check(suggested.Mappings.Count == plan.Mappings.Count, "the app's mappings are what the project was created with (count)");
        Check(suggested.Mappings.Zip(plan.Mappings, (a, b) => a.SchemaPath == b.SchemaPath && a.SheetName == b.SheetName && a.CellAddress == b.CellAddress && a.Source == b.Source).All(x => x),
            "the app's mappings are what the project was created with (paths, cells, sources)");

        // The mapped cells are inside the grid of their sheet (or just beyond its text, which the page extends to).
        var outside = 0;
        foreach (var bySheet in suggested.Mappings.GroupBy(m => m.SheetName))
        {
            var grid = reader.Read(template, bySheet.Key);
            if (grid == null) { continue; }
            outside += bySheet.Count(m => Row(m.CellAddress) > TemplateGridReader.MaxRows || Col(m.CellAddress) > TemplateGridReader.MaxColumns);
        }
        Check(outside == 0, "every mapped cell is within the grid limits");
        var onUnknownSheets = suggested.Mappings.Count(m => !workbook.Sheets.Any(s => string.Equals(s.Name, m.SheetName, StringComparison.OrdinalIgnoreCase)));

        // A generated template (no BSP template uploaded): the generator's mappings.
        var generated = new XsdInputTemplateGenerator().Generate(new FrpProjectDto { RootElement = parsed.RootElement, TargetNamespace = parsed.TargetNamespace, SchemaNodes = parsed.Nodes }, null);
        var generatedPath = Path.Combine(Path.GetTempPath(), "grid-generated-" + Guid.NewGuid().ToString("N") + ".xlsx");
        File.WriteAllBytes(generatedPath, generated.Bytes);
        try
        {
            var genProject = project.With(copy => { copy.Id = new string('d', 32); copy.TemplateGenerated = true; copy.TemplateFile = new UploadedFileDto { StoredPath = generatedPath }; });
            var genService = new TemplateGridService(new Projects { Project = genProject }, reader2, inspector, engine, new XsdInputTemplateGenerator(), new BspSpecificationReader(inspector), maker, new MemoryCache(), new OpenXmlMappedTemplateWriter());
            var genSuggested = genService.GetSuggestedMappingsAsync(genProject.Id, CancellationToken.None).Result;
            Check(genSuggested.Mappings.Count == generated.Mappings.Count && genSuggested.Mappings.Zip(generated.Mappings, (a, b) => a.SchemaPath == b.SchemaPath && a.CellAddress == b.CellAddress && a.SheetName == b.SheetName).All(x => x),
                "generated template: the generator's mappings");
            var genSheet = genService.GetSheetAsync(genProject.Id, generated.Mappings[0].SheetName, CancellationToken.None).Result;
            Check(genSheet != null && genSheet.Cells.Count > 0, "generated template: its sheet is shown");
        }
        finally { File.Delete(generatedPath); }

        // The JSON the page receives.
        var json = FrpMapper.Shared.Json.JsonSerializer.Serialize(sheetGrid, new FrpMapper.Shared.Json.JsonSerializerOptions(FrpMapper.Shared.Json.JsonSerializerDefaults.Web));
        Check(json.Contains("\"sheetName\":") && json.Contains("\"cells\":[{\"address\":") && json.Contains("\"maxRow\":"), "camelCase JSON");

        Console.WriteLine($"{Path.GetFileName(xsd)}: {parsed.Nodes.Count} XSD nodes; the app's mappings: {suggested.Mappings.Count} ({firstMs} ms the first time), {onUnknownSheets} on sheets the template does not have; first sheet JSON {json.Length / 1024} KB");
        Console.WriteLine("TemplateGridTests: " + checks + " checks passed");
        return 0;
    }
}
