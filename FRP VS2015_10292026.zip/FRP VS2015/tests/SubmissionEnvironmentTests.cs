// Tests of the BSP environments (BSP submission, Settings tab): the URL rules (BspEndpointRules), the Maker / Checker
// service (SubmissionEnvironmentService) over an in-memory repository that behaves like 010_submission_environments.sql,
// the server's host allowlist (Bsp:AllowedHosts), the HTTP client's own guard and the Platform proxy allowlist.
// No arguments.
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Integration;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Platform.Services;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

static class SubmissionEnvironmentTests
{
    static int checks;
    static void Check(bool ok, string name) { if (!ok) throw new Exception("FAILED: " + name); checks++; Console.WriteLine("ok: " + name); }
    static string Refused(Action action, string name, WorkflowErrorKind kind = WorkflowErrorKind.Invalid)
    {
        try { action(); }
        catch (WorkflowException e) { Check(e.Kind == kind, name + " (" + kind + ")"); return e.Message; }
        throw new Exception("FAILED: accepted " + name);
    }
    static async Task<string> RefusedAsync(Func<Task> action, string name, WorkflowErrorKind kind = WorkflowErrorKind.Invalid)
    {
        try { await action(); }
        catch (WorkflowException e) { Check(e.Kind == kind, name + " (" + kind + ")"); return e.Message; }
        throw new Exception("FAILED: accepted " + name);
    }

    class User : ICurrentUser
    {
        public string UserName = "CORP\\maker";
        public HashSet<string> Granted = new HashSet<string>();
        public string Name { get { return UserName; } }
        public bool IsAuthenticated { get { return true; } }
        public bool HasPermission(string p) { return Granted.Contains(p); }
        public IReadOnlyList<string> Roles { get { return new string[0]; } }
        public IReadOnlyList<string> Permissions { get { return Granted.ToList(); } }
    }

    /// <summary>Behaves like the stored procedures of 010: one Pending and one Active per key, row versions, self-approval refused.</summary>
    class Repository : ISubmissionEnvironmentRepository
    {
        public List<SubmissionEnvironmentDto> Rows = new List<SubmissionEnvironmentDto>();
        long version = 1;
        string NextVersion() { return Convert.ToBase64String(BitConverter.GetBytes(version++)); }
        public Task<IReadOnlyList<SubmissionEnvironmentDto>> ListAsync(CancellationToken c) { return Task.FromResult((IReadOnlyList<SubmissionEnvironmentDto>)Rows.ToList()); }
        public Task<SubmissionEnvironmentDto> RequestAsync(SubmissionEnvironmentDto e, CancellationToken c)
        {
            if (Rows.Any(r => r.Key == e.Key && r.Status == "Pending")) throw new AccessRequestOpenException("open");
            e.Status = "Pending"; e.Version = NextVersion(); Rows.Add(e); return Task.FromResult(e);
        }
        public Task<bool> DecideAsync(string id, byte[] expected, string decision, string by, DateTimeOffset at, string comment, CancellationToken c)
        {
            var row = Rows.FirstOrDefault(r => r.Id == id);
            if (row == null) return Task.FromResult(false);
            if (!Convert.FromBase64String(row.Version).SequenceEqual(expected) || (decision == "Removed" ? row.Status != "Active" : row.Status != "Pending"))
                throw new ConcurrencyConflictException("changed");
            if ((decision == "Approved" || decision == "Rejected") && row.RequestedBy == by) throw new AccessDecisionRefusedException("self");
            if (decision == "Cancelled" && row.RequestedBy != by) throw new AccessDecisionRefusedException("not yours");
            if (decision == "Approved")
                foreach (var a in Rows.Where(r => r.Key == row.Key && r.Status == "Active")) { a.Status = "Replaced"; a.Version = NextVersion(); }
            row.Status = decision == "Approved" ? "Active" : decision; row.DecidedBy = by; row.DecidedAt = at; row.DecisionComment = comment; row.Version = NextVersion();
            return Task.FromResult(true);
        }
        public Task<SubmissionEnvironmentDto> GetActiveAsync(string key, CancellationToken c) { return Task.FromResult(Rows.FirstOrDefault(r => r.Key == key && r.Status == "Active")); }
    }

    static readonly IReadOnlyList<string> Bsp = new[] { "rapi.bsp.gov.ph" };

    static SubmissionEnvironmentRequest Proposal(Action<SubmissionEnvironmentRequest> change = null)
    {
        var request = new SubmissionEnvironmentRequest
        {
            Key = "production", Name = " BSP production ", Kind = "Production", SortOrder = 20, BaseUrl = " https://RAPI.bsp.gov.ph/api/production/submission ",
            SubmitPath = "/submitReport", StatusPath = "{submissionId}/status", ResultPdfPath = "{submissionId}/result/pdf",
            ResultXmlPath = "{submissionId}/result/xml", ResultExcelPath = "{submissionId}/result/excel", ReceiptPath = "{submissionId}/confirmation/pdf"
        };
        if (change != null) change(request);
        return request;
    }

    static int Main()
    {
        Run().GetAwaiter().GetResult();
        Console.WriteLine("SubmissionEnvironmentTests: " + checks + " checks passed");
        return 0;
    }

    static async Task Run()
    {
        var c = CancellationToken.None;

        // ---------- the URL rules ----------
        var normal = BspEndpointRules.Normalize(Proposal(), Bsp);
        Check(normal.Key == "PRODUCTION" && normal.Name == "BSP production" && normal.Kind == "Production" && normal.SortOrder == 20, "key upper case, name trimmed");
        Check(normal.BaseUrl == "https://rapi.bsp.gov.ph/api/production/submission/" && normal.SubmitPath == "submitReport", "host lower case, base URL ends with '/', leading '/' dropped");
        Check(BspEndpointRules.NormalizeBaseUrl("https://rapi.bsp.gov.ph", Bsp) == "https://rapi.bsp.gov.ph/", "a host alone is a base URL");
        foreach (var bad in new[] { "http://rapi.bsp.gov.ph/api/", "https://rapi.bsp.gov.ph:8443/api/", "https://user@rapi.bsp.gov.ph/api/", "https://rapi.bsp.gov.ph/api/?x=1",
            "https://rapi.bsp.gov.ph/api/#x", "https://rapi.bsp.gov.ph/api/../production/", "https://rapi.bsp.gov.ph/api/./", "https://rapi.bsp.gov.ph/a%2e%2e/",
            "https://rapi.bsp.gov.ph\\api", "https://rapi.bsp.gov.ph//api/", "https://rapi.bsp.gov.ph/api /", "//rapi.bsp.gov.ph/api/", "", null,
            "https://" + new string('a', 300) + ".bsp.gov.ph/" })
            Refused(() => BspEndpointRules.NormalizeBaseUrl(bad, Bsp), "base URL refused: " + (bad == null ? "null" : bad.Length > 60 ? bad.Substring(0, 60) : bad));
        var other = Refused(() => BspEndpointRules.NormalizeBaseUrl("https://example.com/api/", Bsp), "host not in Bsp:AllowedHosts");
        Check(other.Contains("example.com") && other.Contains("rapi.bsp.gov.ph") && other.Contains("Bsp:AllowedHosts"), "the allowed hosts and the setting are named");
        Refused(() => BspEndpointRules.NormalizeBaseUrl("https://rapi.bsp.gov.ph.example.com/", Bsp), "a host that only starts with the allowed one");
        Refused(() => BspEndpointRules.NormalizeBaseUrl("https://evil-rapi.bsp.gov.ph/", Bsp), "a sibling host");
        foreach (var bad in new[] { "../submitReport", "a/../b", "./x", "a//b", "a b", "a?b", "a#b", "a%2fb", "a\\b", ".hidden", "" })
            Refused(() => BspEndpointRules.NormalizePath(bad, "Submit", false), "submit path refused: '" + bad + "'");
        Refused(() => BspEndpointRules.NormalizePath("{submissionId}/x", "Submit", false), "submit path with the submission ID");
        Refused(() => BspEndpointRules.NormalizePath("status", "Status", true), "follow-up path without the submission ID");
        Refused(() => BspEndpointRules.NormalizePath("{submissionId}/{submissionId}", "Status", true), "submission ID twice");
        Refused(() => BspEndpointRules.NormalizePath("{submissionid}/status", "Status", true), "the token is case sensitive");
        Check(BspEndpointRules.NormalizePath("v1/{submissionId}/status.json", "Status", true) == "v1/{submissionId}/status.json", "a token anywhere, dots inside a part");
        Refused(() => BspEndpointRules.Normalize(Proposal(r => r.Key = "1PROD"), Bsp), "key starting with a digit");
        Refused(() => BspEndpointRules.Normalize(Proposal(r => r.Key = "P"), Bsp), "key of one character");
        Refused(() => BspEndpointRules.Normalize(Proposal(r => r.Key = "PROD-1"), Bsp), "key with a hyphen");
        Refused(() => BspEndpointRules.Normalize(Proposal(r => r.Kind = "Live"), Bsp), "unknown kind");
        Refused(() => BspEndpointRules.Normalize(Proposal(r => r.Name = "  "), Bsp), "empty name");
        Refused(() => BspEndpointRules.Normalize(Proposal(r => r.Name = "a\u0007b"), Bsp), "control character in the name");
        Refused(() => BspEndpointRules.Normalize(Proposal(r => r.SortOrder = 1000), Bsp), "order above 999");
        Refused(() => BspEndpointRules.Normalize(Proposal(r => r.ResultXmlPath = r.ResultPdfPath), Bsp), "two operations on one path");
        Refused(() => BspEndpointRules.Normalize(null, Bsp), "no proposal");

        var url = BspEndpointRules.Url(normal, "excel", "7735089B-81D6-405E-8E67-255338DBCE9A", Bsp);
        Check(url.AbsoluteUri == "https://rapi.bsp.gov.ph/api/production/submission/7735089b-81d6-405e-8e67-255338dbce9a/result/excel", "follow-up URL with the lower-case submission ID");
        Check(BspEndpointRules.Url(normal, "submit", null, Bsp).AbsoluteUri == "https://rapi.bsp.gov.ph/api/production/submission/submitReport", "submit URL");
        Refused(() => BspEndpointRules.Url(normal, "status", "../../x", Bsp), "submission ID that is not a GUID");
        Refused(() => BspEndpointRules.Url(normal, "delete", null, Bsp), "unknown operation");
        Refused(() => BspEndpointRules.Url(normal, "submit", null, new[] { "other.bsp.gov.ph" }), "an approved environment whose host is no longer allowed");

        // ---------- the server's allowed hosts ----------
        Check(Settings.Bsp(new AppConfiguration(new NameValueCollection(), null)).AllowedHosts.SequenceEqual(new[] { "rapi.bsp.gov.ph" }), "not set: BSP's Report API host only");
        var configured = Settings.Bsp(new AppConfiguration(new NameValueCollection { { "Bsp:AllowedHosts", " RAPI.bsp.gov.ph ; rapi2.bsp.gov.ph,rapi.bsp.gov.ph" } }, null));
        Check(configured.AllowedHosts.SequenceEqual(new[] { "rapi.bsp.gov.ph", "rapi2.bsp.gov.ph" }), "a list, lower case, without repeats");
        foreach (var bad in new[] { "https://rapi.bsp.gov.ph", "rapi.bsp.gov.ph:443", "rapi.bsp.gov.ph/api", "*.bsp.gov.ph", "-x.ph" })
        {
            try { Settings.Bsp(new AppConfiguration(new NameValueCollection { { "Bsp:AllowedHosts", bad } }, null)); throw new Exception("FAILED: setting accepted " + bad); }
            catch (InvalidOperationException) { Check(true, "setting refused at start: " + bad); }
        }

        // ---------- Maker / Checker ----------
        var repository = new Repository();
        var maker = new User { UserName = "CORP\\maker" }; maker.Granted.Add(Permissions.ReferenceManage);
        var checker = new User { UserName = "CORP\\checker" }; checker.Granted.Add(Permissions.ReferenceApprove);
        var outsider = new User { UserName = "CORP\\someone" }; outsider.Granted.Add(Permissions.SubmissionPrepare);
        var options = new FixedOptions<BspOptions>(new BspOptions());
        var makerService = new SubmissionEnvironmentService(repository, maker, options);
        var checkerService = new SubmissionEnvironmentService(repository, checker, options);
        var outsiderService = new SubmissionEnvironmentService(repository, outsider, options);

        await RefusedAsync(() => outsiderService.ListAsync(c), "the settings need reference.manage or reference.approve", WorkflowErrorKind.Forbidden);
        await RefusedAsync(() => outsiderService.RequestAsync(Proposal(), c), "someone else proposes", WorkflowErrorKind.Forbidden);
        await RefusedAsync(() => checkerService.RequestAsync(Proposal(), c), "a Checker proposes", WorkflowErrorKind.Forbidden);
        var settings = await checkerService.ListAsync(c);
        Check(settings.AllowedHosts.SequenceEqual(new[] { "rapi.bsp.gov.ph" }) && settings.Environments.Count == 0, "the settings show the allowed hosts");

        var proposed = await makerService.RequestAsync(Proposal(), c);
        Check(proposed.Status == "Pending" && proposed.Id.Length == 32 && proposed.RequestedBy == "CORP\\maker" && proposed.Key == "PRODUCTION", "the Maker's proposal waits for approval, normalized");
        Check(await repository.GetActiveAsync("PRODUCTION", c) == null, "nothing is used before approval");
        await RefusedAsync(() => makerService.RequestAsync(Proposal(r => r.SubmitPath = "other"), c), "a second change for the same key", WorkflowErrorKind.Conflict);
        var both = new User { UserName = "CORP\\maker" }; both.Granted.Add(Permissions.ReferenceApprove);
        await RefusedAsync(() => new SubmissionEnvironmentService(repository, both, options).DecideAsync(proposed.Id, "approve", new AccessDecisionRequest { Version = proposed.Version }, c),
            "the proposer approves their own change", WorkflowErrorKind.Forbidden);
        await RefusedAsync(() => makerService.DecideAsync(proposed.Id, "approve", new AccessDecisionRequest { Version = proposed.Version }, c), "a Maker approves", WorkflowErrorKind.Forbidden);
        await RefusedAsync(() => checkerService.DecideAsync(proposed.Id, "cancel", new AccessDecisionRequest { Version = proposed.Version }, c), "a Checker cancels someone's change", WorkflowErrorKind.Forbidden);
        await RefusedAsync(() => checkerService.DecideAsync(proposed.Id, "reject", new AccessDecisionRequest { Version = proposed.Version }, c), "reject without a reason");
        await RefusedAsync(() => checkerService.DecideAsync(proposed.Id, "approve", new AccessDecisionRequest { Version = "AAAAAAAAAAA=" }, c), "approve an old version", WorkflowErrorKind.Conflict);
        await RefusedAsync(() => checkerService.DecideAsync(proposed.Id, "publish", new AccessDecisionRequest { Version = proposed.Version }, c), "unknown decision");
        Check(!await checkerService.DecideAsync("ffffffffffffffffffffffffffffffff", "approve", new AccessDecisionRequest { Version = proposed.Version }, c), "unknown environment");
        Check(!await checkerService.DecideAsync("../x", "approve", new AccessDecisionRequest { Version = proposed.Version }, c), "an id that is not one");

        // The server no longer allows the host: the change cannot be approved, only rejected.
        var narrowed = new SubmissionEnvironmentService(repository, checker, new FixedOptions<BspOptions>(new BspOptions { AllowedHosts = new[] { "other.bsp.gov.ph" } }));
        var gone = await RefusedAsync(() => narrowed.DecideAsync(proposed.Id, "approve", new AccessDecisionRequest { Version = proposed.Version }, c), "approve a host no longer allowed", WorkflowErrorKind.Conflict);
        Check(gone.Contains("Reject"), "told to reject it instead");

        Check(await checkerService.DecideAsync(proposed.Id, "approve", new AccessDecisionRequest { Version = proposed.Version }, c), "another person approves");
        var active = await repository.GetActiveAsync("PRODUCTION", c);
        Check(active != null && active.Id == proposed.Id && active.DecidedBy == "CORP\\checker", "the approved version is used");
        await RefusedAsync(() => makerService.RequestAsync(Proposal(), c), "a proposal that changes nothing");
        await RefusedAsync(() => makerService.RequestAsync(Proposal(r => { r.Key = "PROD2"; r.Name = "bsp PRODUCTION"; }), c), "another environment with the same name");

        // A change replaces the previous version once approved; the proposer may cancel a change.
        var change = await makerService.RequestAsync(Proposal(r => r.SubmitPath = "v2/submitReport"), c);
        Check((await repository.GetActiveAsync("PRODUCTION", c)).SubmitPath == "submitReport", "the old version stays in use while the change waits");
        Check(await makerService.DecideAsync(change.Id, "cancel", new AccessDecisionRequest { Version = change.Version }, c)
            && repository.Rows.Single(r => r.Id == change.Id).Status == "Cancelled", "the proposer cancels the change");
        change = await makerService.RequestAsync(Proposal(r => r.SubmitPath = "v2/submitReport"), c);
        Check(await checkerService.DecideAsync(change.Id, "approve", new AccessDecisionRequest { Version = change.Version }, c), "the change is approved");
        Check(repository.Rows.Single(r => r.Id == proposed.Id).Status == "Replaced" && (await repository.GetActiveAsync("PRODUCTION", c)).SubmitPath == "v2/submitReport", "the previous version is replaced");

        // Removal: by a Checker, with a reason.
        active = await repository.GetActiveAsync("PRODUCTION", c);
        await RefusedAsync(() => checkerService.DecideAsync(active.Id, "remove", new AccessDecisionRequest { Version = active.Version }, c), "remove without a reason");
        await RefusedAsync(() => makerService.DecideAsync(active.Id, "remove", new AccessDecisionRequest { Version = active.Version, Comment = "x" }, c), "a Maker removes", WorkflowErrorKind.Forbidden);
        await RefusedAsync(() => checkerService.DecideAsync(active.Id, "remove", new AccessDecisionRequest { Version = active.Version, Comment = new string('x', 1001) }, c), "a comment over 1,000 characters");
        Check(await checkerService.DecideAsync(active.Id, "remove", new AccessDecisionRequest { Version = active.Version, Comment = "BSP retired this URL" }, c)
            && await repository.GetActiveAsync("PRODUCTION", c) == null, "removed: no longer used");

        // ---------- the HTTP client's own guard (nothing is sent; these throw before connecting) ----------
        var client = new BspSandboxClient(options);
        foreach (var bad in new[] { "http://rapi.bsp.gov.ph/api/x", "https://example.com/api/x", "https://rapi.bsp.gov.ph:8443/api/x", "https://u:p@rapi.bsp.gov.ph/api/x",
            "https://rapi.bsp.gov.ph/api/x?y=1", "https://rapi.bsp.gov.ph/api/x#y" })
        {
            try { await client.SendAsync(new X509Certificate2(), new Uri(bad), null, false, c); throw new Exception("FAILED: client sent to " + bad); }
            catch (InvalidOperationException) { Check(true, "client refuses " + bad); }
        }

        // ---------- the Platform's proxy ----------
        Check(ApiProxy.IsAllowed("GET", "/api/reference/bsp-environments") && ApiProxy.IsAllowed("POST", "/api/reference/bsp-environments"), "proxy: list and propose");
        foreach (var decision in new[] { "approve", "reject", "cancel", "remove" })
            Check(ApiProxy.IsAllowed("POST", "/api/reference/bsp-environments/" + proposed.Id + "/" + decision), "proxy: " + decision);
        Check(!ApiProxy.IsAllowed("POST", "/api/reference/bsp-environments/" + proposed.Id + "/publish") && !ApiProxy.IsAllowed("GET", "/api/reference/bsp-environments/" + proposed.Id)
            && !ApiProxy.IsAllowed("POST", "/api/reference/bsp-environments/../x/approve") && !ApiProxy.IsAllowed("DELETE", "/api/reference/bsp-environments"), "proxy: nothing else");
    }
}
