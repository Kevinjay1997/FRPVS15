"""Synthetic COCREE input workbooks built from the Workbench's real configuration (for comparing outputs)."""
import openpyxl, sys, os, random
cfg_dir, out_dir, scenario = sys.argv[1], sys.argv[2], sys.argv[3]
random.seed(7)
wb = openpyxl.load_workbook(os.path.join(cfg_dir, "cocree_config.xlsx"), read_only=True, data_only=True)
T = {ws.title: [r for r in ws.iter_rows(values_only=True)] for ws in wb.worksheets}
dd = openpyxl.load_workbook(os.path.join(cfg_dir, "cocree_dropdown_options.xlsx"), read_only=True, data_only=True)
codes = {}
for ws in dd.worksheets:
    rows = [r for r in ws.iter_rows(values_only=True)]
    h = [str(c) if c is not None else "" for c in rows[0]]
    if "input_template" in h and "xml_code" in h:
        codes[ws.title.upper()] = [r[h.index("input_template")] for r in rows[1:] if r[h.index("input_template")] not in (None, "")]
def rows(name): 
    h = T[name][0]; return [dict(zip(h, r)) for r in T[name][1:] if any(c is not None for c in r)]
files = {r["filename"]: r for r in rows("input_files")}
sheets = rows("input_file_sheets"); cols = rows("input_file_sheet_columns"); ents = {r["attribute_id"]: r for r in rows("xml_entities")}
maps = {r["column_id"]: r for r in rows("xml_mapping") if r["attribute_id"] not in (None, "")}
rtypes = rows("source_record_type")
MONTH = "September"; YEAR = 2026

def value(ent, n, subj, contract, bad=False, fid=0):
    a = ent["attribute"]; dt = (ent["data_type"] or "").upper(); dl = (ent["dropdown"] or "").upper()
    if a == "ProviderSubjectNumber" or a in ("ProviderSubjectNo",): return subj
    if a == "ProviderContractNo": return contract
    if a in ("ParentProviderSubjectNo",): return subj
    if a in ("ChildProviderSubjectNo",): return "S%05d" % (int(subj[1:]) + 1)
    if a == "ProviderCode": return "0000000135"
    if dl and dl in codes:
        if bad and n % 7 == 3: return "Nonexistent wording"
        return codes[dl][n % len(codes[dl])]
    if dt == "MONEY": return [1234.5, "12,500.75", 0, 99999999.99, 15.1][n % 5]
    if dt == "DATE": return "202610%02d" % (1 + n % 28)
    if dt == "INTEGER": return n % 9 + 1
    return "%s %s-%d" % (a[:10], fid, n)

def make(fname, nsubj, start, contracts_per, bad=False, name=None):
    f = files[fname]; fid = f["source_filename_id"]
    out = openpyxl.Workbook(); out.remove(out.active)
    for sh in [s for s in sheets if s["source_filename_id"] == fid]:
        ws = out.create_sheet(sh["sheet_name"])
        sc = [c for c in cols if c["source_file_sheet_id"] == sh["source_file_sheet_id"]]
        ws.append([c["column_name"] for c in sc])
        if sh["sheet_name"] == "File Info":
            ws.append([fname, MONTH, YEAR]); continue
        types = [r for r in rtypes if r["source_file_sheet_id"] == sh["source_file_sheet_id"]]
        n = 0
        for i in range(nsubj):
            subj = "S%05d" % (start + i)
            for rt in types:
                kind = sh["sheet_name"].upper()
                reps = contracts_per if kind in ("EXPOSURE",) else 1
                both = len([t for t in types if t["element"] in ("Individuals", "Companies")]) == 2
                if both and rt["element"] == "Companies" and i % 3: continue
                if both and rt["element"] == "Individuals" and not i % 3: continue
                for k in range(reps):
                    n += 1
                    row = []
                    for c in sc:
                        if c["column_name"] == "Record Type": row.append(rt["record_type"]); continue
                        m = maps.get(c["column_id"])
                        row.append(value(ents[m["attribute_id"]], n, subj, "C%s-%05d-%d" % (fid, start + i, k), bad, fid) if m else None)
                    ws.append(row)
        ws.append([None] * len(sc))  # a blank row, as BU files often end with
    out.save(os.path.join(out_dir, (name or fname) + ".xlsx"))

os.makedirs(out_dir, exist_ok=True)
if scenario == "basic":
    make("1. OLR - Installments", 40, 1, 2, bad=True)
    make("11. OLR - Non-Installments", 30, 20, 1)          # subjects 20..49 overlap file 1 (hierarchy 1 wins over 2)
    make("12. Subject Links", 5, 1, 1)
    make("13. Negative Records", 6, 1, 1)
if scenario == "batch":
    make("1. OLR - Installments", 130, 1, 2)                     # 130 subjects × 3 records → 130 files of 3 at max 3
    make("8. Personal Loans", 20, 200, 1)
if scenario == "errors":
    make("1. OLR - Installments", 12, 1, 1)
    make("7. Credit Cards", 4, 500, 1)
    # the same Credit Cards file again: every credit card contract twice (duplicate exposures)
    make("7. Credit Cards", 4, 500, 1, name="7. Credit Cards (again)")
    make("13. Negative Records", 3, 900, 1)                        # negative events for subjects nobody sent
if scenario == "hierarchy":
    # Company S00001 is in both files: "9. Contingent Accounts" (subject_hierarchy 4) and "3. Financial Asset - Bank" (10).
    make("3. Financial Asset - Bank", 3, 1, 1)
    make("9. Contingent Accounts", 3, 1, 1)
