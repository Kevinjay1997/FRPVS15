// Tests of every file the app exports, for each BSP report given: the Excel templates (blank, project values, XSD sample
// values, and the sample for a chosen bank), the sample XML, and the in-review / approved submission XML, made exactly as
// the download buttons make them (FrpMappingService, ProjectWorkflowService). Each template must open in Excel without a
// repair (well-formed parts, a content type for every part, no dangling relationships, unique sheet, table and defined
// names, unique XML map names and cell ids, every binding on the workbook's map, each XSD element bound once, no table over
// another table or a merged cell) and bind the XSD; every XML must pass the XSD; the approved file downloads byte for byte
// as attached, and a changed stored file is refused. The files are written to <output folder>: check their ZIP headers
// with check_xlsx_zip_headers.py and open them in Excel. (CarMappedTemplateTests checks that the supplied cells are kept.)
// Arguments: <output folder> then, per report, <XSD> <template .xlsx or -> <specification .xlsx or -> ...
// It uses the in-memory project store of ProjectEditTests.cs: compile both, with this one as the entry point.
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using System.Xml;
using System.Xml.Linq;
using FrpMapper.Api.BL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

static class ExportTests
{
    static int checks;
    static void Check(bool ok, string what) { if (!ok) throw new Exception("FAILED: " + what); checks++; Console.WriteLine("ok: " + what); }
    static IFormFile Upload(string path) { var bytes = File.ReadAllBytes(path); return new FormFile(new MemoryStream(bytes), 0, bytes.Length, "file", Path.GetFileName(path)); }
    static readonly XNamespace Sml = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

    static int Main(string[] args)
    {
        var output = args[0];
        Directory.CreateDirectory(output);
        for (var i = 1; i + 2 < args.Length; i += 3)
            Report(output, args[i], args[i + 1] == "-" ? null : args[i + 1], args[i + 2] == "-" ? null : args[i + 2]);
        Console.WriteLine("ExportTests: " + checks + " checks passed");
        return 0;
    }

    static void Report(string output, string xsd, string template, string specification)
    {
        var repo = new EditRepo(); var files = new EditFiles(); var audit = new EditAudit();
        var inspector = new OpenXmlWorkbookInspector(); var writer = new XmlSubmissionWriter();
        var specReader = new BspSpecificationReader(inspector);
        var solver = new BspSampleValueSolver(new BspAssertionEvaluator(), writer, new BspDerivedValues());
        var options = new FixedOptions<FileStorageOptions>(new FileStorageOptions { MaxUploadMegabytes = 50,
            AllowedExtensions = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
            { { UploadKinds.Xsd, new List<string> { ".xsd" } }, { UploadKinds.Template, new List<string> { ".xlsx", ".xlsm" } }, { UploadKinds.Specification, new List<string> { ".xlsx" } } } });
        var specValidator = new BspSpecificationValidator(specReader, new BspAssertionEvaluator(), new BankReferenceContext(), new BspDerivedValues());
        var maker = new EditUser { Name = "maker1", Granted = new[] { Permissions.ProjectRead, Permissions.ProjectCreate, Permissions.ProjectEdit } };
        var service = new FrpMappingService(repo, new ProjectAccess(repo, maker), new BankReferenceContext(), new XsdSchemaParser(), inspector,
            new MappingSuggestionEngine(), writer, new OpenXmlMappedTemplateWriter(), new XsdValidationService(),
            new XsdProjectValidator(writer, specValidator), specReader, specValidator, new TemplateCoverageChecker(), new XsdInputTemplateGenerator(), solver,
            new SampleValueRefill(specReader, solver), maker, audit, files, new UploadRules(options, files), null, null, new NoLog<FrpMappingService>(), new ProjectReadCache());
        var project = service.AnalyzeAsync("Export check", Upload(xsd), template == null ? null : Upload(template), specification == null ? null : Upload(specification),
            null, CancellationToken.None).Result;
        var name = project.RootElement + (template == null ? "_generated" : "");
        Check(project.Mappings.Count > 0, name + ": project analysed (" + project.Mappings.Count + " mappings" + (specification != null ? ", with specification" : "") + ")");

        foreach (var values in new[] { ExportValues.Blank, ExportValues.Mapped, ExportValues.Sample })
        {
            var label = name + " " + values;
            var export = service.ExportMappedTemplateAsync(project.Id, values, CancellationToken.None).Result.Value;
            File.WriteAllBytes(Path.Combine(output, name + "_" + values.ToString().ToLowerInvariant() + ".xlsx"), export.Bytes);
            Check(export.FileName.EndsWith(".xlsx") && export.ContentType.Contains("spreadsheetml"), label + ": named and typed as an Excel workbook (" + export.FileName + ")");
            using (var zip = new ZipArchive(new MemoryStream(export.Bytes), ZipArchiveMode.Read))
            {
                Func<string, XDocument> read = part => { using (var s = zip.GetEntry(part).Open()) return XDocument.Load(s); };
                var broken = zip.Entries.Where(e => e.FullName.EndsWith(".xml") || e.FullName.EndsWith(".rels")).Where(e =>
                {
                    try { using (var s = e.Open()) XDocument.Load(s); return false; } catch (XmlException) { return true; }
                }).Select(e => e.FullName).ToList();
                Check(broken.Count == 0, label + ": every part is well-formed XML" + (broken.Count > 0 ? " (" + string.Join(", ", broken) + ")" : ""));
                var types = read("[Content_Types].xml").Root;
                var declared = types.Elements().Where(e => e.Name.LocalName == "Override").Select(e => ((string)e.Attribute("PartName")).TrimStart('/')).ToList();
                var defaults = types.Elements().Where(e => e.Name.LocalName == "Default").Select(e => (string)e.Attribute("Extension")).ToList();
                var missingType = zip.Entries.Where(e => e.Length > 0 && !declared.Contains(e.FullName)
                    && !defaults.Contains(Path.GetExtension(e.FullName).TrimStart('.'), StringComparer.OrdinalIgnoreCase)).Select(e => e.FullName).ToList();
                Check(missingType.Count == 0, label + ": every part has a content type" + (missingType.Count > 0 ? " (" + string.Join(", ", missingType.Take(5)) + ")" : ""));
                Check(declared.All(p => zip.GetEntry(p) != null), label + ": every declared part exists");
                foreach (var rels in zip.Entries.Where(e => e.FullName.EndsWith(".rels")).ToList())
                {
                    var folder = rels.FullName.Replace("_rels/", "").Replace(".rels", "");
                    folder = folder.Contains("/") ? folder.Substring(0, folder.LastIndexOf('/') + 1) : "";
                    var dangling = read(rels.FullName).Root.Elements().Where(r => (string)r.Attribute("TargetMode") != "External")
                        .Select(r => (string)r.Attribute("Target")).Where(t => Resolve(folder, t) != null && zip.GetEntry(Resolve(folder, t)) == null).ToList();
                    Check(dangling.Count == 0, label + ": " + rels.FullName + " points only to parts that exist" + (dangling.Count > 0 ? " (" + string.Join(", ", dangling.Take(3)) + ")" : ""));
                }

                var sheetNames = read("xl/workbook.xml").Root.Descendants(Sml + "sheet").Select(s => (string)s.Attribute("name")).ToList();
                Check(sheetNames.Count == sheetNames.Distinct(StringComparer.OrdinalIgnoreCase).Count() && sheetNames.All(n => n.Length > 0 && n.Length <= 31),
                    label + ": " + sheetNames.Count + " sheets, names unique and at most 31 characters");
                var definedNames = read("xl/workbook.xml").Root.Descendants(Sml + "definedName")
                    .Select(d => (string)d.Attribute("name") + "|" + (string)d.Attribute("localSheetId")).ToList();
                Check(definedNames.Count == definedNames.Distinct(StringComparer.OrdinalIgnoreCase).Count(), label + ": defined names unique");

                var mapIds = read("xl/xmlMaps.xml").Root.Elements(Sml + "Map").Select(m => (string)m.Attribute("ID")).ToList();
                var parts = zip.Entries.Where(e => e.FullName.StartsWith("xl/tables/") && e.FullName.EndsWith(".xml")).Select(e => read(e.FullName)).ToList();
                var singles = parts.Where(p => p.Root.Name == Sml + "singleXmlCells").ToList();
                var tables = parts.Where(p => p.Root.Name == Sml + "table").ToList();
                Check(mapIds.Count == 1 && singles.Count + tables.Count > 0, label + ": one XML map with its bindings");
                Check(singles.All(p => p.Root.Descendants(Sml + "xmlCellPr").Select(c => (string)c.Attribute("uniqueName"))
                    .GroupBy(n => n, StringComparer.OrdinalIgnoreCase).All(g => g.Count() == 1)), label + ": single-cell uniqueNames are different within each sheet");
                Check(tables.All(t => t.Root.Descendants(Sml + "tableColumn").Select(c => (string)c.Attribute("uniqueName"))
                    .GroupBy(n => n, StringComparer.OrdinalIgnoreCase).All(g => g.Count() == 1)), label + ": table column uniqueNames are different");
                var tableNames = tables.Select(t => (string)t.Root.Attribute("name")).Concat(tables.Select(t => (string)t.Root.Attribute("displayName"))).ToList();
                Check(tables.Select(t => (string)t.Root.Attribute("displayName")).GroupBy(n => n, StringComparer.OrdinalIgnoreCase).All(g => g.Count() == 1)
                    && tables.Select(t => (string)t.Root.Attribute("id")).Distinct().Count() == tables.Count, label + ": table names and ids are unique");
                var cellIds = singles.SelectMany(p => p.Root.Elements(Sml + "singleXmlCell").Select(c => (string)c.Attribute("id"))).ToList();
                Check(cellIds.Count == cellIds.Distinct().Count(), label + ": single-cell ids are unique");
                var bindings = singles.SelectMany(p => p.Root.Descendants(Sml + "xmlPr")).Concat(tables.SelectMany(t => t.Root.Descendants(Sml + "xmlColumnPr"))).ToList();
                Check(bindings.All(b => mapIds.Contains((string)b.Attribute("mapId"))), label + ": every binding names the XML map");
                var xpaths = bindings.Select(b => (string)b.Attribute("xpath")).ToList();
                Check(xpaths.Count == xpaths.Distinct().Count(), label + ": every XML element is bound once (" + xpaths.Count + " bindings)");
                Check(TablesDoNotOverlap(zip, read), label + ": no two tables overlap and no table covers a merged cell");
            }

            var coverage = service.CheckExportedTemplateAsync(project.Id, values, CancellationToken.None).Result;
            Check(coverage.Problems.Count == 0 && (values == ExportValues.Sample || coverage.Unbound == 0),
                label + ": the XML map covers the XSD (" + coverage.Unbound + " unbound" + (values == ExportValues.Sample ? ", " + coverage.LeftOutBySpecification + " left out for the sample in " + string.Join("+", coverage.LeftOutForms) + "; omitted " + string.Join("+", project.SampleOmittedForms) : "")
                + (coverage.Problems.Count > 0 ? "; " + string.Join("; ", coverage.Problems.Take(3)) : "") + ")");
        }

        // With a bank chosen on the project page (?bank=UNI): the sample is that bank's (its provider code in the Header).
        var reference = new BankReferenceContext { SampleBankKey = "UNI", Data = new ReferenceDataDto { Banks = new List<BankProfileDto> {
            new BankProfileDto { Key = "UNI", Name = "EAST WEST BANKING CORP", ProviderCode = "0000000135", BspUndertakingCode = "135", Version = 1 } } } };
        var bankService = new FrpMappingService(repo, new ProjectAccess(repo, maker), reference, new XsdSchemaParser(), inspector,
            new MappingSuggestionEngine(), writer, new OpenXmlMappedTemplateWriter(), new XsdValidationService(),
            new XsdProjectValidator(writer, specValidator), specReader, specValidator, new TemplateCoverageChecker(), new XsdInputTemplateGenerator(), solver,
            new SampleValueRefill(specReader, solver), maker, audit, files, new UploadRules(options, files), null, null, new NoLog<FrpMappingService>(), new ProjectReadCache());
        var bankTemplate = bankService.ExportMappedTemplateAsync(project.Id, ExportValues.Sample, CancellationToken.None).Result.Value;
        File.WriteAllBytes(Path.Combine(output, name + "_sample_UNI.xlsx"), bankTemplate.Bytes);
        using (var zip = new ZipArchive(new MemoryStream(bankTemplate.Bytes), ZipArchiveMode.Read))
            Check(zip.Entries.Count > 0 && zip.Entries.All(e => !e.FullName.EndsWith(".xml") || Readable(e)), name + " Sample for UNI: a readable workbook");
        var bankXml = bankService.ExportXmlAsync(project.Id, ExportValues.Sample, CancellationToken.None).Result.Value;
        File.WriteAllBytes(Path.Combine(output, name + "_sample_UNI.xml"), bankXml.Bytes);
        var bankRoot = XDocument.Load(new MemoryStream(bankXml.Bytes)).Root;
        Check(BankReferenceContext.Header(bankRoot, "Undertaking") == "0000000135", name + " Sample for UNI: the Header carries UNI's provider code");
        Check(new XsdValidationService().ValidateBytes(bankXml.Bytes, project.XsdFile.StoredPath, "sample UNI", null).IsValid, name + " Sample for UNI: the XML passes the XSD");

        var xml = service.ExportXmlAsync(project.Id, ExportValues.Sample, CancellationToken.None).Result.Value;
        File.WriteAllBytes(Path.Combine(output, name + "_sample.xml"), xml.Bytes);
        var check = new XsdValidationService().ValidateBytes(xml.Bytes, project.XsdFile.StoredPath, "sample", null);
        Check(check.IsValid, name + ": sample XML passes the XSD (" + xml.FileName + ")");
        Check(Throws(() => service.ExportXmlAsync(project.Id, ExportValues.Mapped, CancellationToken.None).Wait()),
            name + ": the project-values XML is not exported before a Checker's approval");

        // The approved submission XML: attached, submitted, approved by another person, then downloaded unchanged.
        var preparer = new EditUser { Name = "maker1", Granted = new[] { Permissions.ProjectRead, Permissions.ProjectEdit, Permissions.SubmissionPrepare } };
        var checker = new EditUser { Name = "checker1", Granted = new[] { Permissions.ProjectRead, Permissions.ProjectReadAll, Permissions.SubmissionReview,
            Permissions.SubmissionDownloadInReview, Permissions.SubmissionDownloadApproved } };
        Func<EditUser, ProjectWorkflowService> workflow = user => new ProjectWorkflowService(repo, new ProjectAccess(repo, user), files, service, audit, user, new UploadRules(options, files));
        workflow(preparer).UseGeneratedSubmissionAsync(project.Id, CancellationToken.None).Wait();
        var expected = File.ReadAllBytes(repo.Projects[project.Id].Workflow.Submission.StoredPath);
        Check(expected.SequenceEqual(writer.Write(repo.Projects[project.Id])), name + ": the attached file is the XML built from the project");
        workflow(preparer).SubmitAsync(project.Id, "Export check", CancellationToken.None).Wait();
        var inReview = workflow(checker).DownloadSubmissionAsync(project.Id, CancellationToken.None).Result.Value;
        Check(inReview.FileName.EndsWith("_IN_REVIEW.xml") && inReview.Bytes.SequenceEqual(expected), name + ": the file in review downloads as attached");
        // The in-memory store saves only Draft / Returned projects (the stored procedure approves from InReview), so the
        // approval is recorded directly: what is tested here is the download.
        repo.Projects[project.Id] = repo.Projects[project.Id].With(p => { p.Workflow = p.Workflow.With(w => { w.Status = ProjectStatus.Approved; w.ReviewedBy = "checker1"; }); });
        var approved = workflow(checker).DownloadSubmissionAsync(project.Id, CancellationToken.None).Result.Value;
        File.WriteAllBytes(Path.Combine(output, name + "_APPROVED.xml"), approved.Bytes);
        Check(approved.FileName.EndsWith("_APPROVED.xml") && approved.Bytes.SequenceEqual(expected), name + ": the approved XML downloads byte for byte as attached (" + approved.FileName + ")");
        Check(new XsdValidationService().ValidateBytes(approved.Bytes, project.XsdFile.StoredPath, "approved", null).IsValid, name + ": the approved XML passes the XSD");
        var stored = repo.Projects[project.Id].Workflow.Submission.StoredPath;
        File.AppendAllText(stored, " ");
        Check(Throws(() => workflow(checker).DownloadSubmissionAsync(project.Id, CancellationToken.None).Wait()), name + ": a changed stored file is refused, not downloaded");
        File.WriteAllBytes(stored, expected);
    }

    static bool Readable(ZipArchiveEntry entry)
    {
        try { using (var s = entry.Open()) XDocument.Load(s); return true; } catch (XmlException) { return false; }
    }

    static bool Throws(Action action)
    {
        try { action(); return false; } catch (AggregateException ex) when (ex.InnerException is WorkflowException) { return true; } catch (WorkflowException) { return true; }
    }

    static string Resolve(string folder, string target)
    {
        if (string.IsNullOrEmpty(target)) return null;
        var path = target.StartsWith("/") ? target.TrimStart('/') : folder + target;
        var parts = new List<string>();
        foreach (var part in path.Split('/'))
        {
            if (part == "..") { if (parts.Count > 0) parts.RemoveAt(parts.Count - 1); }
            else if (part != "." && part.Length > 0) parts.Add(part);
        }

        return string.Join("/", parts);
    }

    /// <summary>Excel repairs a workbook whose tables overlap each other or a merged range.</summary>
    static bool TablesDoNotOverlap(ZipArchive zip, Func<string, XDocument> read)
    {
        foreach (var sheet in zip.Entries.Where(e => e.FullName.StartsWith("xl/worksheets/sheet") && e.FullName.EndsWith(".xml")).ToList())
        {
            var relsPath = "xl/worksheets/_rels/" + Path.GetFileName(sheet.FullName) + ".rels";
            if (zip.GetEntry(relsPath) == null) continue;
            var tables = read(relsPath).Root.Elements().Where(r => ((string)r.Attribute("Type")).EndsWith("/table"))
                .Select(r => read(Resolve("xl/worksheets/", (string)r.Attribute("Target")))).Select(t => Range((string)t.Root.Attribute("ref"))).ToList();
            var merges = read(sheet.FullName).Root.Descendants(Sml + "mergeCell").Select(m => Range((string)m.Attribute("ref"))).ToList();
            for (var i = 0; i < tables.Count; i++)
            {
                for (var j = i + 1; j < tables.Count; j++) if (Overlap(tables[i], tables[j])) return false;
                if (merges.Any(m => Overlap(tables[i], m))) return false;
            }
        }

        return true;
    }

    static int[] Range(string reference)
    {
        var ends = reference.Split(':');
        var a = Cell(ends[0]); var b = ends.Length > 1 ? Cell(ends[1]) : a;
        return new[] { a[0], a[1], b[0], b[1] };
    }

    static int[] Cell(string cell)
    {
        var column = 0; var i = 0;
        for (; i < cell.Length && char.IsLetter(cell[i]); i++) column = column * 26 + (char.ToUpperInvariant(cell[i]) - 'A' + 1);
        return new[] { int.Parse(cell.Substring(i)), column };
    }

    static bool Overlap(int[] a, int[] b)
    {
        return a[0] <= b[2] && b[0] <= a[2] && a[1] <= b[3] && b[1] <= a[3];
    }
}
