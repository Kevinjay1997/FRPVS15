// Regression for BSP CAR_M v1.0: preserve the supplied workbook (lists use the form's own rows) while mapping all three CAR Part IV 5 forms.
// Arguments: <CAR_M XSD> <CAR_M input XLSX> <CAR_M specification XLSX>.
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Xml.Linq;
using FrpMapper.Api.BL;
using FrpMapper.Shared.Models;

static class CarMappedTemplateTests
{
    static readonly XNamespace Sml = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    static int checks;
    static void Check(bool condition, string name) { if (!condition) throw new Exception("FAILED: " + name); checks++; }
    static XDocument Read(ZipArchive archive, string path)
    {
        using (var stream = archive.GetEntry(path).Open()) return XDocument.Load(stream);
    }
    static IReadOnlyList<string> Merges(ZipArchive archive, string path)
    {
        return Read(archive, path).Descendants(Sml + "mergeCell").Select(e => (string)e.Attribute("ref")).ToList();
    }
    static List<string> TableRefs(ZipArchive archive, string sheetPath)
    {
        var rels = archive.GetEntry("xl/worksheets/_rels/" + Path.GetFileName(sheetPath) + ".rels");
        if (rels == null) return new List<string>();
        XDocument relsDoc;
        using (var stream = rels.Open()) relsDoc = XDocument.Load(stream);
        return relsDoc.Root.Elements().Where(r => ((string)r.Attribute("Type")).EndsWith("/table"))
            .Select(r => (string)Read(archive, "xl/tables/" + Path.GetFileName((string)r.Attribute("Target"))).Root.Attribute("ref")).ToList();
    }
    static int[] Area(string range)
    {
        Func<string, int[]> cell = a => {
            var letters = new string(a.TakeWhile(char.IsLetter).ToArray());
            return new[] { int.Parse(a.Substring(letters.Length)), letters.Aggregate(0, (n, ch) => n * 26 + char.ToUpperInvariant(ch) - 'A' + 1) };
        };
        var parts = range.Split(':');
        var first = cell(parts[0]); var last = cell(parts[parts.Length - 1]);
        return new[] { first[0], last[0], first[1], last[1] };
    }
    static bool Inside(int[] inner, int[] outer)
    {
        return inner[0] >= outer[0] && inner[1] <= outer[1] && inner[2] >= outer[2] && inner[3] <= outer[3];
    }
    static int RowOf(string address)
    {
        return int.Parse(new string(address.SkipWhile(char.IsLetter).ToArray()));
    }
    static string Text(XElement cell)
    {
        return cell == null ? null : string.Concat(cell.Descendants(Sml + "t").Select(t => t.Value)) + (cell.Element(Sml + "v")?.Value ?? "");
    }
    static XElement Cell(XDocument sheet, string address)
    {
        return sheet.Descendants(Sml + "c").FirstOrDefault(c => (string)c.Attribute("r") == address);
    }

    /// <summary>CAR_Part_IV_1d as item rows: its headings, element names, account codes and XSD validations.</summary>
    static void CheckItemRows(ZipArchive result, FrpProjectDto project)
    {
        var sheet = Read(result, "xl/worksheets/sheet25.xml");
        var tables = TableRefs(result, "xl/worksheets/sheet25.xml");
        Check(tables.SequenceEqual(new[] { "C14:BR15" }), "CAR_Part_IV_1d: one table, C14:BR15 (" + string.Join(", ", tables) + ")");
        Check(!sheet.Descendants(Sml + "f").Any(), "CAR_Part_IV_1d: no helper formulas (values are typed in the table)");
        Check(Cell(sheet, "A1") != null && Cell(sheet, "A2") != null && Text(Cell(sheet, "A4")).StartsWith("Each row of the table below is one CAR_Part_IV_1d_Item (one Currency)"),
            "CAR_Part_IV_1d: title rows kept, then the note on adding rows");

        var group = "/CAR_M/CAR_Part_IV_1d/CAR_Part_IV_1d_Item";
        var mapped = new HashSet<string>(project.Mappings.Select(m => m.SchemaPath));
        var leaves = project.SchemaNodes.Where(n => n.Path.StartsWith(group + "/") && mapped.Contains(n.Path)).ToList();
        var names = OpenXmlMappedTemplateWriter.ListColumnNames(group, leaves);
        Check(leaves.Count == 68 && leaves.Select((n, i) => Text(Cell(sheet, ColumnLetters(3 + i) + "14")) == names[n.Path]).All(x => x),
            "CAR_Part_IV_1d: the header row holds the element names in XSD order (Currency, R0010C0010.., ADD1_R0010C0010..)");

        Func<string, int> column = name => 3 + leaves.FindIndex(n => names[n.Path] == name);
        Func<string, string, string> heading = (caption, name) => {
            var row = sheet.Descendants(Sml + "row").First(r => r.Elements(Sml + "c").Any(c => (string)c.Attribute("r") == "A" + r.Attribute("r").Value && Text(c) == caption));
            var letters = ColumnLetters(column(name));
            // A merged label is in its first cell.
            var merge = Merges(result, "xl/worksheets/sheet25.xml").Select(m => m.Split(':')).FirstOrDefault(m => m.Length == 2
                && RowOf(m[0]) == int.Parse(row.Attribute("r").Value) && Area(m[0] + ":" + m[1])[2] <= column(name) && Area(m[0] + ":" + m[1])[3] >= column(name));
            return Text(Cell(sheet, merge != null ? merge[0] : letters + row.Attribute("r").Value));
        };
        Check(heading("Account Code", "R0010C0010") == "100220500505730020" && heading("Account Code", "R0020C0030") == "100220500510730020"
            && heading("Account Code", "R0150C0040") == "100220500575730020" && heading("Account Code", "ADD1_R0010C0010") == "990220500500821120",
            "CAR_Part_IV_1d: each column's account code is its form row's (1 month or less = ...505730020, ADD1 = ...821120)");
        Check(heading("Times Bands – Coupon 3% or more", "R0020C0010") == "Over 1 months to 3 months"
            && heading("Times Bands – Coupon less than 3%", "R0090C0040") == "Over 4.3 years to 5.7 years"
            && heading("Zone", "R0050C0010") == "2" && heading("Block", "ADD1_R0010C0010") == "ADD1" && heading("Block", "R0150C0040") == "MAIN",
            "CAR_Part_IV_1d: each column's time band, zone and block are its form row's");
        Check(Text(Cell(sheet, "D8")) == "Long" && Text(Cell(sheet, "E8")) == "Short" && Text(Cell(sheet, "F7")) == "Interest Rate Derivatives"
            && Text(Cell(sheet, "BL8")) == "Vertical disallowance2/" && Text(Cell(sheet, "BP8")) == "Zones 1 & 2",
            "CAR_Part_IV_1d: each column's form headings (Long / Short, Interest Rate Derivatives, Vertical disallowance, Zones 1 & 2)");

        var validations = sheet.Descendants(Sml + "dataValidation").ToList();
        Check(validations.Count == 68 && validations.All(v => ((string)v.Attribute("sqref")).EndsWith("514") && ((string)v.Attribute("sqref")).Contains("15:")),
            "CAR_Part_IV_1d: one XSD validation per column over the data row and the rows a person adds (15:514), nothing left on the old form cells");
        var currency = validations.First(v => (string)v.Attribute("sqref") == "C15:C514");
        Check((string)currency.Attribute("type") == "list", "CAR_Part_IV_1d: Currency is a list of the XSD's currency codes");
        var amount = validations.First(v => (string)v.Attribute("sqref") == "D15:D514");
        Check((string)amount.Attribute("type") == "custom" && amount.Element(Sml + "formula1").Value.Contains("D15"), "CAR_Part_IV_1d: amounts are checked as XSD decimals from the data row down");
        Check(sheet.Descendants(Sml + "mergeCell").All(m => Area((string)m.Attribute("ref"))[1] < 14), "CAR_Part_IV_1d: no merged cell in or below the table");
        var duplicates = sheet.Descendants(Sml + "conditionalFormatting").Where(f => f.Elements(Sml + "cfRule").Any(r => (string)r.Attribute("type") == "duplicateValues")).ToList();
        Check(duplicates.Count == 1 && (string)duplicates[0].Attribute("sqref") == "C15:C514" && Text(Cell(sheet, "A4")).Contains("Each Currency only once"),
            "CAR_Part_IV_1d: the XSD's unique Currency (xs:unique) is marked when repeated, and the note says so");
        var v2abc = Read(result, "xl/worksheets/sheet39.xml").Descendants(Sml + "conditionalFormatting").Select(f => (string)f.Attribute("sqref")).ToList();
        Check(v2abc.Contains("C12:C511"), "CAR_Part_V_2abc: a repeated Year is marked (xs:unique)");
        Check(!Read(result, "xl/worksheets/sheet26.xml").Descendants(Sml + "cfRule").Any(r => (string)r.Attribute("type") == "duplicateValues"),
            "CAR_Part_IV_2: COUNTRY has no xs:unique in the XSD, so nothing is marked");
        // The original form (its grid, labels, R-codes and input cells) and the old helper table are gone: what is left
        // below the title is the note, the heading rows and the new table.
        Check(sheet.Descendants(Sml + "row").All(r => int.Parse(r.Attribute("r").Value) <= 15)
            && !sheet.Descendants(Sml + "c").Any(c => Text(c).StartsWith("XML list ") || System.Text.RegularExpressions.Regex.IsMatch(Text(c), "^R0[0-9]{3}$")),
            "CAR_Part_IV_1d: the original form and its helper table are removed (nothing below row 15, no R-code labels)");
        foreach (var path in new[] { "sheet26", "sheet39", "sheet52", "sheet53" }.Select(n => "xl/worksheets/" + n + ".xml"))
            Check(!Read(result, path).Descendants(Sml + "c").Any(c => Text(c).StartsWith("XML list ")) && TableRefs(result, path).Count == 1,
                path + ": one table (the new one), no helper table");
    }

    static string ColumnLetters(int column)
    {
        var name = "";
        for (; column > 0; column = (column - 1) / 26) name = (char)('A' + (column - 1) % 26) + name;
        return name;
    }

    /// <summary>The sample template read back, then with a second currency typed in the row below CAR_Part_IV_1d's table.</summary>
    static void CheckItemRowsReadBack(FrpProjectDto project, byte[] workbook)
    {
        var read = new FilledTemplateReader().Read(project, workbook);
        XNamespace ns = project.TargetNamespace;
        var items = read.Document.Descendants(ns + "CAR_Part_IV_1d_Item").ToList();
        Check(items.Count == 1 && items[0].Element(ns + "Currency").Value == "PHP" && items[0].Element(ns + "MAIN").Elements().Count() == 60
            && items[0].Element(ns + "ADD1").Elements().Count() == 7, "read back: CAR_Part_IV_1d has its one item (PHP, 60 MAIN and 7 ADD1 values)");
        // CAR_Part_V_2abc is one of the forms BSP's specification leaves out of the sample: it has the same item-rows layout,
        // but its table is a plain Excel table (no XML binding) with an empty data row, so it is not in the XML.
        using (var sample = new ZipArchive(new MemoryStream(workbook), ZipArchiveMode.Read))
        {
            var tables = TableRefs(sample, "xl/worksheets/sheet39.xml");
            var tablePath = sample.Entries.Select(e => e.FullName).First(n => n.StartsWith("xl/tables/") && (string)Read(sample, n).Root.Attribute("ref") == "C11:BO12");
            var table = Read(sample, tablePath).Root;
            var sheet = Read(sample, "xl/worksheets/sheet39.xml");
            Check(tables.SequenceEqual(new[] { "C11:BO12" }) && table.Attribute("tableType") == null && !table.Descendants(Sml + "xmlColumnPr").Any()
                && sheet.Descendants(Sml + "c").Where(c => RowOf((string)c.Attribute("r")) == 12).All(c => c.Element(Sml + "v") == null && c.Element(Sml + "is") == null)
                && sheet.Descendants(Sml + "dataValidation").Count() == 65,
                "sample: CAR_Part_V_2abc (left out by BSP) has the item-rows layout with an unbound, empty table and its validations");
            Check(read.Document.Descendants(ns + "CAR_Part_V_2abc").Count() == 0, "sample: CAR_Part_V_2abc is not in the XML");
        }
        foreach (var form in new[] { "MAIN_X1_Item", "CAR15_IRX_GMR_Item", "MAIN_X_Item" })
            Check(read.Document.Descendants(ns + form).Count() == 1, "read back: " + form + " has its item");

        using (var stream = new MemoryStream())
        {
            stream.Write(workbook, 0, workbook.Length);
            using (var archive = new ZipArchive(stream, ZipArchiveMode.Update, true))
            {
                var sheetEntry = archive.GetEntry("xl/worksheets/sheet25.xml");
                XDocument sheet;
                using (var s = sheetEntry.Open()) sheet = XDocument.Load(s);
                var dataRow = sheet.Descendants(Sml + "row").First(r => r.Attribute("r").Value == "15");
                var added = new XElement(dataRow);
                added.SetAttributeValue("r", "16");
                foreach (var cell in added.Elements(Sml + "c"))
                {
                    var address = (string)cell.Attribute("r");
                    cell.SetAttributeValue("r", address.Replace("15", "16"));
                    cell.Elements().Remove();
                    cell.Attribute("t")?.Remove();
                    if (address == "C15") { cell.SetAttributeValue("t", "inlineStr"); cell.Add(new XElement(Sml + "is", new XElement(Sml + "t", "USD"))); }
                    else if (address == "D15" || address == "BR15") cell.Add(new XElement(Sml + "v", "1234.5"));
                }
                dataRow.AddAfterSelf(added);
                sheetEntry.Delete();
                using (var s = archive.CreateEntry("xl/worksheets/sheet25.xml").Open()) sheet.Save(s);

                var tablePath = archive.Entries.Select(e => e.FullName).First(n => n.StartsWith("xl/tables/") && (string)Read(archive, n).Root.Attribute("ref") == "C14:BR15");
                var table = Read(archive, tablePath);
                table.Root.SetAttributeValue("ref", "C14:BR16");
                table.Root.Element(Sml + "autoFilter")?.SetAttributeValue("ref", "C14:BR16");
                archive.GetEntry(tablePath).Delete();
                using (var s = archive.CreateEntry(tablePath).Open()) table.Save(s);
            }

            var twice = new FilledTemplateReader().Read(project, stream.ToArray());
            var both = twice.Document.Descendants(ns + "CAR_Part_IV_1d_Item").ToList();
            Check(both.Count == 2 && both[1].Element(ns + "Currency").Value == "USD"
                && both[1].Element(ns + "MAIN").Element(ns + "R0010C0010").Value == "1234.5"
                && both[1].Element(ns + "ADD1").Element(ns + "R0010C0070").Value == "1234.5",
                "read back: a row typed below the table is a second CAR_Part_IV_1d item (USD, its MAIN and ADD1 values)");
            Check(both[0].Element(ns + "Currency").Value == "PHP", "read back: the first item is unchanged");
        }
    }

    /// <summary>
    /// CAR_Part_IV_4c (a list inside each currency's item, read by the app from its sheet): the sheet says how to add a
    /// currency, and a copy of the sheet made as Excel does ("CAR_Part_IV_4c (2)") with another Currency is a second item.
    /// </summary>
    static void CheckSheetCopyItems(FrpProjectDto project, byte[] workbook)
    {
        XNamespace ns = project.TargetNamespace;
        XNamespace rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        XNamespace pkg = "http://schemas.openxmlformats.org/package/2006/relationships";
        XNamespace types = "http://schemas.openxmlformats.org/package/2006/content-types";
        var key = project.Mappings.First(m => m.SchemaPath == "/CAR_M/CAR_Part_IV_4c/CAR_Part_IV_4c_Item/Currency");
        var before = new FilledTemplateReader().Read(project, workbook).Document.Descendants(ns + "CAR_Part_IV_4c_Item").ToList();
        using (var stream = new MemoryStream())
        {
            stream.Write(workbook, 0, workbook.Length);
            using (var archive = new ZipArchive(stream, ZipArchiveMode.Update, true))
            {
                var book = Read(archive, "xl/workbook.xml");
                var rels = Read(archive, "xl/_rels/workbook.xml.rels");
                var sheetElement = book.Descendants(Sml + "sheet").First(e => (string)e.Attribute("name") == "CAR_Part_IV_4c");
                var target = (string)rels.Root.Elements().First(r => (string)r.Attribute("Id") == (string)sheetElement.Attribute(rel + "id")).Attribute("Target");
                var sheet = Read(archive, "xl/" + target);
                Check(sheet.Descendants(Sml + "c").Any(c => Text(c).StartsWith("Each copy of this sheet is one CAR_Part_IV_4c item. To add another Currency, copy the sheet")),
                    "CAR_Part_IV_4c: the sheet says how to add a currency (copy the sheet)");

                // The copy, as Excel makes it: same cells, no table or drawing parts of its own; another Currency and values.
                foreach (var name in new[] { "tableParts", "drawing", "legacyDrawing" }) sheet.Root.Elements(Sml + name).Remove();
                var keyCell = sheet.Descendants(Sml + "c").First(c => (string)c.Attribute("r") == key.CellAddress.ToUpperInvariant());
                keyCell.Elements().Remove(); keyCell.SetAttributeValue("t", "inlineStr"); keyCell.Add(new XElement(Sml + "is", new XElement(Sml + "t", "USD")));
                using (var s = archive.CreateEntry("xl/worksheets/copyTest.xml").Open()) sheet.Save(s);
                rels.Root.Add(new XElement(pkg + "Relationship", new XAttribute("Id", "rIdCopyTest"),
                    new XAttribute("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"), new XAttribute("Target", "worksheets/copyTest.xml")));
                sheetElement.AddAfterSelf(new XElement(Sml + "sheet", new XAttribute("name", "CAR_Part_IV_4c (2)"), new XAttribute("sheetId", "9999"), new XAttribute(rel + "id", "rIdCopyTest")));
                var contentTypes = Read(archive, "[Content_Types].xml");
                contentTypes.Root.Add(new XElement(types + "Override", new XAttribute("PartName", "/xl/worksheets/copyTest.xml"),
                    new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml")));
                foreach (var part in new[] { new { Path = "xl/workbook.xml", Doc = book }, new { Path = "xl/_rels/workbook.xml.rels", Doc = rels }, new { Path = "[Content_Types].xml", Doc = contentTypes } })
                {
                    archive.GetEntry(part.Path).Delete();
                    using (var s = archive.CreateEntry(part.Path).Open()) part.Doc.Save(s);
                }
            }

            var read = new FilledTemplateReader().Read(project, stream.ToArray());
            var items = read.Document.Descendants(ns + "CAR_Part_IV_4c_Item").ToList();
            Check(before.Count == 1 && items.Count == 2 && items.Select(i => i.Element(ns + "Currency").Value).OrderBy(v => v).SequenceEqual(new[] { before[0].Element(ns + "Currency").Value, "USD" }.OrderBy(v => v))
                && items.All(i => i.Elements().Count() == before[0].Elements().Count()),
                "CAR_Part_IV_4c: a copy of its sheet with Currency USD is a second item, with its lists (" + string.Join(", ", items.Select(i => i.Element(ns + "Currency").Value)) + ")");
        }
    }

    static int Main(string[] args)
    {
        var parsed = new XsdSchemaParser().Parse(args[0]);
        var inspector = new OpenXmlWorkbookInspector();
        var workbook = inspector.Inspect(args[1]);
        var plan = new MappingSuggestionEngine().CreateInitialMappings(parsed.Nodes, workbook);
        var specification = new BspSpecificationReader(inspector).Read(args[2]);
        var solved = new BspSampleValueSolver(new BspAssertionEvaluator(), new XmlSubmissionWriter(), new BspDerivedValues())
            .Apply(parsed.Nodes, parsed.RootElement, parsed.TargetNamespace, specification);
        var forms = new[] { "CAR_Part_IV_5a", "CAR_Part_IV_5b", "CAR_Part_IV_5c" };
        Check(forms.All(solved.OmittedForms.Contains), "sample excludes these forms by BSP rule");
        var project = new FrpProjectDto {
            RootElement = parsed.RootElement, TargetNamespace = parsed.TargetNamespace, SchemaNodes = parsed.Nodes,
            Workbook = workbook, Mappings = plan.Mappings,
            XsdFile = new UploadedFileDto { StoredPath = args[0] }, TemplateFile = new UploadedFileDto { StoredPath = args[1] }
        };
        var output = new OpenXmlMappedTemplateWriter().Write(project, writeValues: false);
        var coverage = new TemplateCoverageChecker().Check(project, output, "CAR_M.xlsx");
        Check(coverage.IsComplete && coverage.Unbound == 0, "all fields bound in full export");
        var sampleOutput = new OpenXmlMappedTemplateWriter().Write(project, writeValues: true, unboundForms: solved.OmittedForms);
        if (args.Length > 3) File.WriteAllBytes(args[3], output);
        if (args.Length > 4) File.WriteAllBytes(args[4], sampleOutput);
        using (var sample = new ZipArchive(new MemoryStream(sampleOutput), ZipArchiveMode.Read))
        {
            var samplePaths = sample.Entries.Where(e => e.FullName.StartsWith("xl/tables/") && e.FullName.EndsWith(".xml"))
                .Select(e => Read(sample, e.FullName))
                .SelectMany(document => document.Descendants(Sml + "xmlPr")
                    .Concat(document.Descendants(Sml + "xmlColumnPr")))
                .Select(e => (string)e.Attribute("xpath")).ToList();
            Check(forms.All(form => samplePaths.All(path => !path.Contains("/ns1:" + form + "/"))),
                "sample export alone omits the three specification-excluded forms");
        }
        using (var source = ZipFile.OpenRead(args[1]))
        using (var result = new ZipArchive(new MemoryStream(output), ZipArchiveMode.Read))
        {
            foreach (var path in new[] { "xl/worksheets/sheet35.xml", "xl/worksheets/sheet36.xml", "xl/worksheets/sheet37.xml" })
                Check(Merges(source, path).Where(m => m.Contains(":")).SequenceEqual(Merges(result, path).Where(m => m.Contains(":"))),
                    path + " multi-cell merge layout preserved");
            var itemRowSheets = new List<string>();
            foreach (var entry in source.Entries.Where(e => e.FullName.StartsWith("xl/worksheets/sheet") && e.FullName.EndsWith(".xml")))
            {
                var original = Read(source, entry.FullName);
                var exported = Read(result, entry.FullName);
                // A form entered as item rows (one table row per item) is replaced from the row before its note down:
                // everything above it (the title, other forms) is kept as supplied.
                var note = exported.Descendants(Sml + "c").FirstOrDefault(c => c.Value.StartsWith("Each row of the table below is one ", StringComparison.Ordinal));
                var formStart = note == null ? int.MaxValue : RowOf((string)note.Attribute("r")) - 1;
                if (note != null) itemRowSheets.Add(entry.FullName);
                var exportedCells = exported.Descendants(Sml + "c")
                    .Where(c => c.Attribute("r") != null)
                    .ToDictionary(c => (string)c.Attribute("r"), StringComparer.OrdinalIgnoreCase);
                Check(original.Descendants(Sml + "c").Where(cell => RowOf((string)cell.Attribute("r")) < formStart).All(cell => {
                    XElement actual;
                    return exportedCells.TryGetValue((string)cell.Attribute("r"), out actual)
                        && XNode.DeepEquals(cell, actual);
                }), entry.FullName + " original cells preserved");
                // Only 1x1 merge entries (which merge nothing) may be dropped, and only inside an in-place XML table.
                var tableAreas = TableRefs(result, entry.FullName).Select(Area).ToList();
                var kept = Merges(result, entry.FullName).Where(m => Area(m)[0] < formStart).ToList();
                var sourceMerges = Merges(source, entry.FullName).Where(m => Area(m)[1] < formStart).ToList();
                var dropped = sourceMerges.Where(m => !kept.Contains(m)).ToList();
                Check(sourceMerges.Where(m => !dropped.Contains(m)).SequenceEqual(kept), entry.FullName + " merges kept in order");
                Check(dropped.All(m => !m.Contains(":") && tableAreas.Any(a => Inside(Area(m), a))),
                    entry.FullName + " only 1x1 merges inside a list table removed");
            }

            // Forms that spread over several rows per item (a grid per currency, a column per country) are entered as
            // item rows: heading rows from the form, then a table with one row per item.
            Check(new[] { "sheet25", "sheet26", "sheet39", "sheet52", "sheet53" }.All(s => itemRowSheets.Contains("xl/worksheets/" + s + ".xml")) && itemRowSheets.Count == 5,
                "the five grid-per-item forms are item rows (" + string.Join(", ", itemRowSheets) + ")");
            CheckItemRows(result, project);
            // A list whose rows already exist on the form becomes a table on those rows, not a new table below the form.
            var partTwo = TableRefs(result, "xl/worksheets/sheet3.xml");
            Check(partTwo.Contains("F116:I117") && partTwo.Contains("F152:I153") && partTwo.Count == 2,
                "CAR_Part_II lists use the form's own rows (" + string.Join(", ", partTwo) + ")");
            var formRows = Read(source, "xl/worksheets/sheet3.xml").Descendants(Sml + "row").Max(r => (int)r.Attribute("r"));
            Check(Read(result, "xl/worksheets/sheet3.xml").Descendants(Sml + "row").Max(r => (int)r.Attribute("r")) == formRows,
                "CAR_Part_II has no helper table below the form");
            var bindings = result.Entries.Where(e => e.FullName.StartsWith("xl/tables/") && e.FullName.EndsWith(".xml"))
                .Select(e => Read(result, e.FullName)).ToList();
            var paths = bindings.SelectMany(d => d.Descendants(Sml + "xmlPr").Concat(d.Descendants(Sml + "xmlColumnPr")))
                .Select(e => (string)e.Attribute("xpath")).ToList();
            foreach (var form in forms)
            {
                var expected = plan.Mappings.Count(m => m.SchemaPath.StartsWith("/CAR_M/" + form + "/", StringComparison.Ordinal));
                Check(expected > 0 && paths.Count(p => p.Contains("/ns1:" + form + "/")) == expected, form + " bindings retained");
            }
            var sheet = Read(result, "xl/worksheets/sheet36.xml");
            Check(TableRefs(result, "xl/worksheets/sheet36.xml").SequenceEqual(new[] { "E6:G7" }) && !sheet.Descendants(Sml + "f").Any(),
                "5b list is a table on the form's own input row (E7, G7), with no helper formulas");
        }

        // The sample template read back: each item-rows table gives its item, and a row added below a table is one more item.
        CheckItemRowsReadBack(project, sampleOutput);
        CheckSheetCopyItems(project, sampleOutput);
        Console.WriteLine("CarMappedTemplateTests: " + checks + " checks passed");
        return 0;
    }
}
