﻿// Tests of COCREE v2.0: the configuration (CocreeConfiguration, CocreeWorkbookWriter), the XML export (CocreeExporter),
// the validation (CocreeValidator), the CSDF file checks and header totals (CocreeRules), the Maker / Checker
// configuration service and the COCREE service over in-memory repositories, and the Platform proxy rules.
// Arguments: <Workbench Config folder> <basic input workbooks folder> <hierarchy input workbooks folder> <temporary folder>
//            [<validation folder>]
// The input folders are made by tests/cocree_inputs.py from the Workbench's own configuration. The validation folder holds
// pairs <name>.xml (a CSDF file) and <name>.expected.xml (the report the Workbench's own validation code wrote for it).
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Schema;
using FrpMapper.Api.BL;
using FrpMapper.Api.BL.Cocree;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Platform.Services;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;

static class CocreeTests
{
    static int checks;
    static void Check(bool ok, string name) { if (!ok) throw new Exception("FAILED: " + name); checks++; Console.WriteLine("ok: " + name); }

    static async Task<string> RefusedAsync(Func<Task> action, string name, WorkflowErrorKind kind = WorkflowErrorKind.Invalid)
    {
        try { await action(); }
        catch (WorkflowException e) { Check(e.Kind == kind, name + " (" + kind + ": " + e.Message + ")"); return e.Message; }
        throw new Exception("FAILED: accepted " + name);
    }

    // ---------- fakes ----------

    class User : ICurrentUser
    {
        public string UserName = "CORP\\maker";
        public HashSet<string> Granted = new HashSet<string>();
        public string Name { get { return UserName; } }
        public bool IsAuthenticated { get { return true; } }
        public bool HasPermission(string p) { return Granted.Contains(p); }
        public IReadOnlyList<string> Roles { get { return new string[0]; } }
        public IReadOnlyList<string> Permissions { get { return Granted.ToList(); } }
    }

    /// <summary>Behaves like the stored procedures of 011: one Pending and one Active, row versions, self-approval refused.</summary>
    class Versions : IWorkbenchConfigRepository
    {
        public List<StoredWorkbenchConfig> Rows = new List<StoredWorkbenchConfig>();
        long version = 1;
        string NextVersion() { return Convert.ToBase64String(BitConverter.GetBytes(version++)); }
        public Task<IReadOnlyList<WorkbenchConfigVersionDto>> ListAsync(string kind, CancellationToken c) { return Task.FromResult((IReadOnlyList<WorkbenchConfigVersionDto>)Rows.Where(r => r.Version.Kind == kind).Select(r => r.Version).ToList()); }
        public Task<StoredWorkbenchConfig> GetAsync(string id, CancellationToken c) { return Task.FromResult(Rows.FirstOrDefault(r => r.Version.Id == id)); }
        public Task<StoredWorkbenchConfig> GetActiveAsync(string kind, CancellationToken c) { return Task.FromResult(Rows.FirstOrDefault(r => r.Version.Kind == kind && r.Version.Status == "Active")); }
        public Task<WorkbenchConfigVersionDto> RequestAsync(StoredWorkbenchConfig config, CancellationToken c)
        {
            if (Rows.Any(r => r.Version.Kind == config.Version.Kind && r.Version.Status == "Pending")) throw new AccessRequestOpenException("open");
            config.Version.Status = "Pending"; config.Version.Version = NextVersion(); Rows.Add(config); return Task.FromResult(config.Version);
        }
        public Task<bool> DecideAsync(string id, byte[] expected, string decision, string by, DateTimeOffset at, string comment, CancellationToken c)
        {
            var row = Rows.FirstOrDefault(r => r.Version.Id == id);
            if (row == null) return Task.FromResult(false);
            var v = row.Version;
            if (!Convert.FromBase64String(v.Version).SequenceEqual(expected) || v.Status != "Pending") throw new ConcurrencyConflictException("changed");
            if ((decision == "Approved" || decision == "Rejected") && v.RequestedBy == by) throw new AccessDecisionRefusedException("self");
            if (decision == "Cancelled" && v.RequestedBy != by) throw new AccessDecisionRefusedException("not yours");
            if (decision == "Approved")
                foreach (var a in Rows.Where(r => r.Version.Kind == v.Kind && r.Version.Status == "Active")) { a.Version.Status = "Replaced"; a.Version.Version = NextVersion(); }
            v.Status = decision == "Approved" ? "Active" : decision; v.DecidedBy = by; v.DecidedAt = at; v.DecisionComment = comment; v.Version = NextVersion();
            return Task.FromResult(true);
        }
    }

    class Audit : IAuditLog
    {
        public List<AuditEntryDto> Entries = new List<AuditEntryDto>();
        public Task AppendAsync(AuditEntryDto e, CancellationToken c) { Entries.Add(e); return Task.FromResult(0); }
        public Task<IReadOnlyList<AuditEntryDto>> QueryAsync(string s, int n, CancellationToken c) { throw new NotImplementedException(); }
        public Task<IReadOnlyList<AuditEntryDto>> QueryByUserAsync(string s, int n, CancellationToken c) { throw new NotImplementedException(); }
        public Task<AuditPageDto> QueryPageAsync(string p, string s, string a, int k, int n, CancellationToken c) { throw new NotImplementedException(); }
    }

    class References : IReferenceDataRepository
    {
        public ReferenceDataDto Data = new ReferenceDataDto { Banks = new List<BankProfileDto> {
            new BankProfileDto { Key = "UNI", Name = "EAST WEST BANKING CORP", ProviderCode = "0000000135", Version = 1 },
            new BankProfileDto { Key = "RB", Name = "RB", ProviderCode = "0004000476", Version = 1 },
            new BankProfileDto { Key = "X", Name = "No code", ProviderCode = "", Version = 1 } } };
        public Task<ReferenceDataDto> ReadAsync(CancellationToken c) { return Task.FromResult(Data); }
        public Task<BankProfileRequestDto> CreateBankRequestAsync(BankProfileRequestDto r, CancellationToken c) { throw new NotImplementedException(); }
        public Task<bool> DecideBankRequestAsync(string a, byte[] b, string d, string e, DateTimeOffset f, string g, CancellationToken c) { throw new NotImplementedException(); }
        public Task SaveImportAsync(SandboxImportDto i, string u, CancellationToken c) { throw new NotImplementedException(); }
    }

    /// <summary>Generated files kept in memory.</summary>
    class Memory : ICocreeOutput
    {
        public Dictionary<string, byte[]> Files = new Dictionary<string, byte[]>();
        public Stream Create(string name) { return new Saving(this, name); }
        class Saving : MemoryStream
        {
            readonly Memory owner; readonly string name;
            public Saving(Memory owner, string name) { this.owner = owner; this.name = name; }
            protected override void Dispose(bool disposing) { if (disposing) owner.Files[name] = ToArray(); base.Dispose(disposing); }
        }
    }

    // ---------- helpers ----------

    static string configDir, basicDir, hierarchyDir, tempDir, validationDir;
    static CocreeConfiguration configuration;

    static List<CocreeInput> Inputs(string folder, Func<string, byte[], byte[]> change = null)
    {
        return Directory.GetFiles(folder, "*.xlsx").OrderBy(f => int.Parse(Path.GetFileName(f).Split('.')[0])).Select(path =>
        {
            var bytes = File.ReadAllBytes(path);
            if (change != null) bytes = change(Path.GetFileName(path), bytes);
            return new CocreeInput(Path.GetFileName(path), () => new MemoryStream(bytes, false));
        }).ToList();
    }

    /// <summary>A copy of a workbook with its sheets changed (read, changed, written back).</summary>
    static byte[] Changed(byte[] workbook, Action<List<WorkbenchTableDto>> change)
    {
        var tables = CocreeWorkbookReader.Read(new MemoryStream(workbook)).Select(s => new WorkbenchTableDto
        {
            Name = s.Name, Columns = s.Columns.ToList(), Rows = s.Rows.Select(r => r.Select(c => c.Value).ToList()).ToList()
        }).ToList();
        change(tables);
        return CocreeWorkbookWriter.Write(tables);
    }

    static CocreeExportParameters Parameters(int max = 300000)
    {
        return new CocreeExportParameters { ProviderCode = "0000000135", ReferenceDate = new DateTime(2026, 9, 30), MaxRecordsPerFile = max };
    }

    static CocreeExportResultDto Export(List<CocreeInput> inputs, Memory output, int max = 300000)
    {
        return new CocreeExporter(configuration, Parameters(max)).Run(inputs, output);
    }

    static bool Has(CocreeExportResultDto result, string severity, string text)
    {
        return result.Issues.Any(i => i.Severity == severity && i.Message.Contains(text));
    }

    static int Fact(WorkbenchConfigSummaryDto summary, string label)
    {
        var found = summary.Facts.FirstOrDefault(f => f.Label.StartsWith(label, StringComparison.Ordinal));
        return found == null ? -1 : found.Count;
    }

    static IFormFile Upload(string path, string name = null)
    {
        return new MemoryFormFile("file", name ?? Path.GetFileName(path), File.ReadAllBytes(path));
    }

    static int Main(string[] args)
    {
        configDir = args[0]; basicDir = args[1]; hierarchyDir = args[2]; tempDir = args[3]; validationDir = args.Length > 4 ? args[4] : null;
        Directory.CreateDirectory(tempDir);
        Configuration();
        ExportBasic();
        ExportProblems();
        Rules();
        Validation();
        Services().Wait();
        Proxy();
        Console.WriteLine("CocreeTests: " + checks + " checks passed");
        return 0;
    }

    // ---------- the configuration ----------

    static void Configuration()
    {
        var configPath = Path.Combine(configDir, "cocree_config.xlsx");
        var codesPath = Path.Combine(configDir, "cocree_dropdown_options.xlsx");
        var rulesPath = Path.Combine(configDir, "cocree_validations.xlsx");
        CocreeConfigDto content;
        using (var config = File.OpenRead(configPath))
        using (var codes = File.OpenRead(codesPath))
        using (var rules = File.OpenRead(rulesPath))
        {
            content = CocreeConfiguration.FromFiles(config, codes, rules, null, null);
        }

        var problems = new List<string>(); var notes = new List<string>();
        configuration = CocreeConfiguration.Load(content, problems, notes);
        Check(configuration != null && problems.Count == 0, "the Workbench's configuration loads without problems");
        var summary = configuration.Summary();
        Check(Fact(summary, "input files") == 15 && Fact(summary, "sheets") == 41 && Fact(summary, "record types") == 30, "15 input files, 41 sheets, 30 record types");
        Check(Fact(summary, "XML attributes") == 690 && Fact(summary, "code lists") >= 50, "690 XML attributes and the code lists");
        Check(Fact(summary, "validation rules") == 1147 && configuration.ValidationRules.Count == 1147, "1,147 validation rules (rows with both formulas)");
        Check(notes.Any(n => n.StartsWith("Validations: 223 rows")), "rule rows without formulas are noted");
        Check(notes.Any(n => n.StartsWith("xml_mapping:")), "mappings to nothing are noted, not refused (the Workbench ignored them)");
        Check(configuration.CodeLists["YES_NO"]["YES"] == "1" && configuration.CodeLists["TITLE"]["MR"] == "10", "code lists: wording → BSP code");

        // Written to .xlsx and read back: the same content.
        var again = CocreeConfiguration.FromFiles(new MemoryStream(CocreeWorkbookWriter.Write(content.Tables)), new MemoryStream(CocreeWorkbookWriter.Write(content.CodeLists)),
            new MemoryStream(CocreeWorkbookWriter.Write(content.Validations)), null, null);
        Check(JsonSerializer.Serialize(again) == JsonSerializer.Serialize(content), "downloaded workbooks read back exactly as stored");

        // Problems that make a configuration unusable.
        var broken = JsonSerializer.Deserialize<CocreeConfigDto>(JsonSerializer.Serialize(content));
        broken.Tables.RemoveAll(t => t.Name == "source_record_type");
        problems.Clear();
        Check(CocreeConfiguration.Load(broken, problems, new List<string>()) == null && problems.Any(p => p.Contains("source_record_type")), "a missing sheet is refused");

        broken = JsonSerializer.Deserialize<CocreeConfigDto>(JsonSerializer.Serialize(content));
        var entities = broken.Tables.First(t => t.Name == "xml_entities");
        var dropdown = entities.Columns.IndexOf("dropdown");
        entities.Rows.First(r => r[dropdown] == "yes_no")[dropdown] = "no_such_list";
        problems.Clear();
        Check(CocreeConfiguration.Load(broken, problems, new List<string>()) == null && problems.Any(p => p.Contains("no_such_list")), "an unknown code list is refused");

        broken = JsonSerializer.Deserialize<CocreeConfigDto>(JsonSerializer.Serialize(content));
        broken.Tables.First(t => t.Name == "xml_entities").Rows[1][0] = broken.Tables.First(t => t.Name == "xml_entities").Rows[0][0];
        problems.Clear();
        Check(CocreeConfiguration.Load(broken, problems, new List<string>()) == null && problems.Any(p => p.Contains("used twice")), "a repeated attribute_id is refused");

        // What a new version changes.
        var changed = JsonSerializer.Deserialize<CocreeConfigDto>(JsonSerializer.Serialize(content));
        var mapping = changed.Tables.First(t => t.Name == "xml_mapping");
        mapping.Rows[0][mapping.Columns.IndexOf("column_name")] = "Renamed column";
        var lines = CocreeConfiguration.Differences(content, changed);
        Check(lines.Count == 1 && lines[0] == "xml_mapping: 1 row added, 1 row removed.", "differences: " + string.Join(" | ", lines));
        Check(CocreeConfiguration.Differences(content, content).Count == 0, "no differences between a configuration and itself");
    }

    // ---------- the export ----------

    static void ExportBasic()
    {
        var output = new Memory();
        var result = Export(Inputs(basicDir), output);
        Check(result.Succeeded && result.Files.Count == 1 && output.Files.Count == 1, "four input workbooks → one CSDF file");
        Check(result.Subjects == 54 && result.Contracts == 110 && result.NegativeEvents == 6, "54 subjects, 110 contracts, 6 negative events");
        var name = result.Files[0].Name;
        Check(name == "0000000135_CSDF_20260930000001.xml", "file name <provider>_CSDF_<date>00<provision><file>.xml: " + name);
        var bytes = output.Files[name];
        Check(!CocreeRules.HasByteOrderMark(bytes.Take(3).ToArray()) && Encoding.UTF8.GetString(bytes).StartsWith("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<CRIMS_Submission_Input>\n\t<Header "),
            "UTF-8 without BOM, tab-indented, LF line ends");
        var document = XDocument.Load(new MemoryStream(bytes));
        var header = document.Root.Element("Header");
        Check((string)header.Attribute("TotalSubjectRecords") == "54" && (string)header.Attribute("TotalContractRecords") == "110"
            && (string)header.Attribute("TotalNegativeEventRecords") == "6" && (string)header.Attribute("FileReferenceDate") == "20260930", "Header totals and reference date");
        Check((string)document.Root.Element("Footer").Attribute("NumberOfRecords") == "170", "Footer NumberOfRecords = 170");
        var order = document.Root.Element("Body").Elements().Select(e => e.Name.LocalName).Distinct().ToList();
        Check(order.SequenceEqual(new[] { "Individuals", "Companies", "CompanyLinks", "Installments", "NonInstallments", "SubjectNegativeEvents" }), "Body in BSP's element order: " + string.Join(",", order));
        Check(document.Descendants("Installments").Any(e => (string)e.Attribute("OutstandingBalance") == "12500.75" || e.Attributes().Any(a => a.Value == "12500.75")),
            "an amount typed as text with a thousands separator becomes 12500.75");
        Check(document.Descendants().Attributes().Any(a => a.Value == "**^ Unrecognized Value: Nonexistent wording ^**"), "unknown wording is marked for BSP's validation");
        var unknown = result.Issues.Where(i => i.Message.Contains("is not in the code list")).ToList();
        var markedCells = document.Descendants().Attributes().Count(a => a.Value.StartsWith("**^ Unrecognized Value:"));
        Check(unknown.Count > 0 && unknown.Count < markedCells && unknown.All(i => i.Severity == "Warning"),
            "unknown wording: one warning per attribute and value (" + unknown.Count + "), not one per cell (" + markedCells + ")");
        Check(Has(result, "Info", "repeat a subject"), "subjects sent in two files are kept once");
        Check(result.Log.Any(l => l.StartsWith("Export to XML successful: " + name)), "the log names the file");

        // Many files: a subject always travels with its exposures; file numbers 01–59, then the next provision.
        output = new Memory();
        result = Export(Inputs(basicDir), output, 5);
        var names = result.Files.Select(f => f.Name).ToList();
        Check(result.Succeeded && names.Count > 30 && result.Files.All(f => f.Records <= 5), "at most 5 records per file: " + names.Count + " files");
        Check(names[0].EndsWith("000001.xml") && names[1].EndsWith("000002.xml"), "files numbered 01, 02, …");
        Check(result.Files.Sum(f => f.Subjects) == 54 && result.Files.Sum(f => f.Records) == 170, "every record is in exactly one file");

        // A company in two files is taken from the file highest in the hierarchy (4 before 10, compared as numbers).
        output = new Memory();
        result = Export(Inputs(hierarchyDir), output);
        var company = XDocument.Load(new MemoryStream(output.Files.Values.First())).Descendants("Companies").First(e => (string)e.Attribute("ProviderSubjectNumber") == "S00001");
        Check((string)company.Attribute("BranchCode") == "BranchCode 9-1", "subject_hierarchy compared as numbers: file 9 (4) wins over file 3 (10)");
    }

    static void ExportProblems()
    {
        const string Installments = "1. OLR - Installments.xlsx";
        Func<Action<List<WorkbenchTableDto>>, CocreeExportResultDto> run = change =>
            Export(Inputs(basicDir, (name, bytes) => name == Installments ? Changed(bytes, change) : bytes), new Memory());

        var result = run(t => t.Reverse());
        Check(!result.Succeeded && Has(result, "Error", "The first sheet must be 'File Info'."), "File Info must be the first sheet");

        result = run(t => t[0].Rows[0][0] = "99. Unknown file");
        Check(Has(result, "Error", "File type not found"), "an input file the configuration does not know is refused");

        result = run(t => t[0].Rows[0][1] = "August");
        Check(Has(result, "Error", "not equal with the Month and Year"), "a workbook for another month is refused");

        result = run(t => t[0].Rows[0][1] = "9");
        Check(result.Succeeded, "the month may be written as a number");

        result = run(t => t.Add(new WorkbenchTableDto { Name = "Notes", Columns = new List<string> { "A" } }));
        Check(Has(result, "Error", "Notes is an invalid sheet"), "a sheet the configuration does not list is refused");

        result = run(t => t[1].Columns[3] = "Something else");
        Check(Has(result, "Error", "The column sequence between the config and the file do not match"), "a renamed column is refused");

        result = run(t => { t[1].Columns.RemoveAt(t[1].Columns.Count - 1); foreach (var r in t[1].Rows) r.RemoveAt(r.Count - 1); });
        Check(Has(result, "Error", "ends before the column"), "a missing last column is refused");

        var amountColumn = configuration.Mappings.Where(m => configuration.Attributes.First(a => a.Id == m.AttributeId).IsMoney)
            .Select(m => configuration.Columns.First(c => c.Id == m.ColumnId)).First(c => configuration.Sheets.First(s => s.Id == c.SheetId).Name == "Exposure"
                && configuration.Sheets.First(s => s.Id == c.SheetId).FileId == "1").Name;
        result = run(t => { var sheet = t.First(x => x.Name == "Exposure"); sheet.Rows[2][sheet.Columns.IndexOf(amountColumn)] = "12 thousand"; });
        Check(!result.Succeeded && result.Issues.Any(i => i.Severity == "Error" && i.Message.Contains("is not an amount") && i.Row == 4 && i.Column == amountColumn),
            "a text that is not an amount is refused with its row and column (" + amountColumn + ")");

        result = run(t => { var sheet = t.First(x => x.Name == "Exposure"); sheet.Rows[0][0] = "XX"; });
        Check(Has(result, "Warning", "the Record Type 'XX'") && !Has(result, "Error", "Record Type"), "a row of an unknown record type is reported (the Workbench skipped it silently)");

        result = Export(Inputs(basicDir, (name, bytes) => name == "11. OLR - Non-Installments.xlsx" ? Changed(bytes, t => t.RemoveAll(x => x.Name == "Exposure")) : bytes), new Memory());
        Check(Has(result, "Warning", "is not in the workbook") && Has(result, "Error", "Subject record with no corresponding exposure data.") && result.ErrorReport != null,
            "a missing Exposure sheet: subjects without exposure stop the export, with the Workbench's error report");

        var memory = new Memory();
        result = Export(Inputs(basicDir, (name, bytes) => name == Installments ? Changed(bytes, t =>
        {
            var sheet = t.First(x => x.Name == "Exposure");
            sheet.Rows.Add(sheet.Rows[0].ToList()); // the same contract twice
        }) : bytes), memory);
        var report = XDocument.Load(new MemoryStream(memory.Files[result.ErrorReport]));
        Check(report.Root.Name == "Export_to_XML_Errors" && report.Root.Element("DuplicateExposureNumber") != null && report.Root.Element("DuplicateExposure") != null
            && (string)report.Root.Element("DuplicateExposureNumber").Attribute("TotalFound") == "1", "a contract sent twice: DuplicateExposureNumber and DuplicateExposure in the report");
        Check(memory.Files.Keys.All(k => k.StartsWith("Export_to_XML_Result_")), "no CSDF file is written when the checks fail");

        result = Export(new List<CocreeInput> { new CocreeInput("broken.xlsx", () => new MemoryStream(Encoding.UTF8.GetBytes("not a workbook"))) }, new Memory());
        Check(Has(result, "Error", "not an Excel .xlsx workbook"), "a file that is not a workbook is reported");
    }

    // ---------- CSDF file checks and header totals ----------

    static void Rules()
    {
        var providers = new[] { "0000000135", "0004000476" };
        var today = new DateTime(2026, 11, 2);
        Check(CocreeRules.CheckFileName("0000000135_CSDF_20261031000001.xml", providers, today).Count == 0, "a correct file name passes");
        Func<string, string, bool> refused = (name, text) => CocreeRules.CheckFileName(name, providers, today).Any(i => i.Message.Contains(text) || i.Code == text);
        Check(refused("0000000999_CSDF_20261031000001.xml", "is not the provider code"), "an unknown provider code is refused");
        Check(refused("0000000135_CSDF_20261031240001.xml", "SUBMISSION ATTEMPTS"), "attempt 24 is refused");
        Check(refused("0000000135_CSDF_20261031006001.xml", "PROVISION"), "provision 60 is refused");
        Check(refused("0000000135_CSDF_20261031000000.xml", "FILE NUMBER"), "file number 00 is refused");
        Check(refused("0000000135_CSDF_20261231000001.xml", "30-007"), "a future reference date is refused (30-007)");
        Check(refused("report.xml", "Invalid filename format"), "another name is refused");

        var output = new Memory();
        Export(Inputs(basicDir), output, 60);
        var files = output.Files.OrderBy(f => f.Key).ToList();
        var csdf = CocreeRules.ReadCsdf(files[0].Key, files[0].Value, new DateTime(2026, 9, 30));
        Check(csdf.Issues.Count == 0 && csdf.Subjects > 0 && csdf.Subjects + csdf.Contracts + csdf.NegativeEvents <= 60, "a generated file reads without problems");

        var withBom = new byte[] { 0xEF, 0xBB, 0xBF }.Concat(files[0].Value).ToArray();
        Check(CocreeRules.ReadCsdf(files[0].Key, withBom, new DateTime(2026, 9, 30)).Issues.Any(i => i.Code == "30-017"), "a byte order mark is refused (30-017)");
        Func<string, string> issues = xml => string.Join(" ", CocreeRules.ReadCsdf("x.xml", Encoding.UTF8.GetBytes(xml), new DateTime(2026, 10, 31)).Issues.Select(i => i.Code + " " + i.Message));
        Check(issues("<CRIMS_Submission_Input><Body><Individuals/></Body><Footer/></CRIMS_Submission_Input>").Contains("30-013"), "no Header (30-013)");
        Check(issues("<CRIMS_Submission_Input><Header FileReferenceDate=\"20261031\"/><Body/><Footer/></CRIMS_Submission_Input>").Contains("30-016"), "an empty Body (30-016)");
        Check(issues("<CRIMS_Submission_Input><Header FileReferenceDate=\"20261031\"/><Body><Cars/></Body><Footer/></CRIMS_Submission_Input>").Contains("30-009"), "an unknown element (30-009)");
        Check(issues("<CRIMS_Submission_Input><Header FileReferenceDate=\"20260930\"/><Body><Individuals/></Body><Footer/></CRIMS_Submission_Input>").Contains("reference dates don't match"), "another reference date");
        Check(issues("<CRIMS_Submission_Input><Header FileReferenceDate=\"20261031\"/><Header/><Body><Individuals/></Body><Footer/></CRIMS_Submission_Input>").Contains("MORE THAN 1 OCCURENCE OF 'HEADER'"), "two Headers");

        var updated = new MemoryStream();
        CocreeRules.WriteTotals(csdf.Document, 7, 8, 9, updated);
        var bytes = updated.ToArray();
        var header = XDocument.Load(new MemoryStream(bytes)).Root.Element("Header");
        Check((string)header.Attribute("TotalSubjectRecords") == "7" && (string)header.Attribute("TotalContractRecords") == "8"
            && (string)header.Attribute("TotalNegativeEventRecords") == "9" && !CocreeRules.HasByteOrderMark(bytes.Take(3).ToArray()), "totals written into the Header, still without BOM");

        Check(CocreeRules.IsSameMonth("October", "2026", new DateTime(2026, 10, 31)) && CocreeRules.IsSameMonth("oct", "2026", new DateTime(2026, 10, 1))
            && !CocreeRules.IsSameMonth("October", "2025", new DateTime(2026, 10, 31)), "month names, abbreviations and numbers");
        string money;
        Check(CocreeRules.TryMoney(new CocreeCell(CocreeCellKind.Number, "1E+15", 1e15), out money) && money == "1000000000000000", "a large amount is written without an exponent");
        Check(new CocreeCell(CocreeCellKind.Date, "46326", 46326).Value == "20261031", "an Excel date cell is written as yyyyMMdd");
        Check(!CocreeRules.IsXmlText("a\u0001b") && CocreeRules.IsXmlText("a\tb"), "control characters are not XML text");
    }

    // ---------- validation (the Workbench's steps 2 and 3) ----------

    static CocreeFileValidationDto Validate(string name, byte[] content, Dictionary<string, byte[]> reports, XmlSchemaSet schemas = null)
    {
        var validator = new CocreeValidator(configuration, schemas, new[] { "0000000135", "0004000476" }, new DateTime(2026, 10, 28));
        return validator.Validate(name, content, (file, write) =>
        {
            using (var stream = new MemoryStream())
            {
                write(stream);
                reports[file] = stream.ToArray();
            }
        });
    }

    /// <summary>A report without the parts that depend on when and where it was made (File, ValidationCompletedOn).</summary>
    static string Comparable(byte[] report)
    {
        var text = new UTF8Encoding(false).GetString(report);
        return System.Text.RegularExpressions.Regex.Replace(text, " (File|ValidationCompletedOn)=\"[^\"]*\"", "");
    }

    static void Validation()
    {
        // Against the reports the Workbench's own validation code wrote for the same files.
        var compared = 0;
        if (validationDir != null && Directory.Exists(validationDir))
        {
            foreach (var folder in Directory.GetDirectories(validationDir).OrderBy(f => f))
            {
                var csdf = Directory.GetFiles(folder, "*_CSDF_*.xml").Single();
                var written = new Dictionary<string, byte[]>();
                var result = Validate(Path.GetFileName(csdf), File.ReadAllBytes(csdf), written);
                var expected = File.ReadAllBytes(Path.Combine(folder, "expected.xml"));
                Check(result.Report != null && Comparable(written[result.Report]) == Comparable(expected),
                    Path.GetFileName(folder) + ": the report is the Workbench's, byte for byte (" + result.Stage + ", " + result.Records + " records, " + result.RecordErrors + " wrong)");
                compared++;
            }
        }

        Console.WriteLine("compared with the Workbench: " + compared + " files");

        // A clean generated file: its values made to fit their data types, so the rules are applied.
        var clean = File.ReadAllText(Path.Combine(validationDir ?? "", "rules", "0000000135_CSDF_20260930000001.xml"));
        Func<string, byte[]> bytes = text => new UTF8Encoding(false).GetBytes(text);
        var all = new Dictionary<string, byte[]>();
        var passed = Validate("0000000135_CSDF_20260930000001.xml", bytes(clean), all);
        Check(passed.Stage == "Rules" && passed.RulesApplied == 721 && passed.Rules.Count > 0 && passed.Rules[0].Examples.Count > 0, "the rules are applied: " + passed.RulesApplied + " of them on this file");
        Check(!passed.Rules.Any(r => r.Element == "Header" || r.Element == "Footer"), "the Header and Footer rules pass on a generated file (the Footer gets the Header's values)");

        var firstIndividual = System.Text.RegularExpressions.Regex.Match(clean, "\t\t<Individuals [^>]*/>\n").Value;
        var firstInstallment = System.Text.RegularExpressions.Regex.Match(clean, "\t\t<Installments [^>]*/>\n").Value;
        var firstEvent = System.Text.RegularExpressions.Regex.Match(clean, "\t\t<SubjectNegativeEvents [^>]*/>\n").Value;

        var bom = Validate("0000000135_CSDF_20260930000001.xml", new byte[] { 0xEF, 0xBB, 0xBF }.Concat(bytes(clean)).ToArray(), new Dictionary<string, byte[]>());
        Check(bom.Outcome == "Stopped" && bom.Issues.Any(i => i.Code == "30-017") && bom.Report == null, "Stage 1: a file with a BOM is not checked further (30-017)");
        var future = Validate("0000000135_CSDF_20991231000001.xml", bytes(clean), new Dictionary<string, byte[]>());
        Check(future.Outcome == "Stopped" && future.Issues.Any(i => i.Code == "30-007"), "Stage 1: a file name dated in the future (30-007)");
        var unknown = Validate("0000000135_CSDF_20260930000001.xml", bytes(clean.Replace("</Body>", "<Mortgages ProviderSubjectNo=\"X\" />\n\t</Body>")), new Dictionary<string, byte[]>());
        Check(unknown.Outcome == "Stopped" && unknown.Issues.Any(i => i.Code == "30-009" && i.Message.Contains("Mortgages")), "an unknown record type (30-009)");

        var reports = new Dictionary<string, byte[]>();
        var duplicates = Validate("0000000135_CSDF_20260930000001.xml", bytes(clean.Replace(firstIndividual, firstIndividual + firstIndividual).Replace(firstInstallment, firstInstallment + firstInstallment)), reports);
        Check(duplicates.Stage == "Preliminary" && duplicates.Issues.Any(i => i.Code == "10-090") && duplicates.Issues.Any(i => i.Code == "20-310") && duplicates.RulesApplied == 0,
            "duplicate subjects (10-090) and contracts (20-310): the preliminary report, no rules (as the Workbench)");
        Check(new UTF8Encoding(false).GetString(reports[duplicates.Report]).Contains("<Preliminary_Validation_Error_List>"), "the preliminary report is written");

        var ghost = System.Text.RegularExpressions.Regex.Replace(firstEvent, "ProviderSubjectNo=\"[^\"]*\"", "ProviderSubjectNo=\"GHOST\"");
        var orphan = Validate("0000000135_CSDF_20260930000001.xml", bytes(clean.Replace(firstEvent, firstEvent + ghost)), new Dictionary<string, byte[]>());
        Check(orphan.Issues.Any(i => i.Message.StartsWith("SUBJECT NEGATIVE EVENTS: ProviderSubjectNo NOT FOUND") && i.ProviderSubjectNo == "GHOST"),
            "a negative event whose subject is not in the file (the Workbench compared the events with themselves)");

        var zero = System.Text.RegularExpressions.Regex.Replace(firstInstallment, " OutstandingBalance=\"[^\"]*\"", " OutstandingBalance=\"0.00\"");
        var zeros = Validate("0000000135_CSDF_20260930000001.xml", bytes(clean.Replace(firstInstallment, zero)), new Dictionary<string, byte[]>());
        Check(zeros.Stage == "Rules", "an amount of 0.00 is an amount");
        var wrongDecimals = System.Text.RegularExpressions.Regex.Replace(firstInstallment, " NominalInterestRate=\"[^\"]*\"", " NominalInterestRate=\"1.23456\"");
        var rates = Validate("0000000135_CSDF_20260930000001.xml", bytes(clean.Replace(firstInstallment, wrongDecimals)), new Dictionary<string, byte[]>());
        Check(rates.Stage == "Preliminary" && rates.Issues.Any(i => i.Message == "Invalid decimal value: NominalInterestRate"), "a rate has at most 4 decimals");
        var missing = Validate("0000000135_CSDF_20260930000001.xml", bytes(clean.Replace(firstInstallment, System.Text.RegularExpressions.Regex.Replace(firstInstallment, " BookCode=\"[^\"]*\"", ""))),
            new Dictionary<string, byte[]>());
        Check(missing.Issues.Any(i => i.Message.Contains("BookCode is missing on 1 records")), "a record without a checked attribute: the element is not checked, and why");

        var otherProvider = Validate("0004000476_CSDF_20260930000001.xml", bytes(clean), new Dictionary<string, byte[]>());
        Check(otherProvider.Stage == "Rules" && otherProvider.Rules.Any(r => r.Element == "Header" && r.Code == "30-006"),
            "the Header's rules are reported: the provider code differs from the file name's (30-006)");

        // A company with a GSIS number (type 12): the rule 20-052 of the Workbench's file cannot be evaluated on it.
        var company = System.Text.RegularExpressions.Regex.Match(clean, "\t\t<Companies [^>]*/>\n").Value;
        var gsis = System.Text.RegularExpressions.Regex.Replace(System.Text.RegularExpressions.Regex.Replace(company, "IdentificationType2=\"[^\"]*\"", "IdentificationType2=\"12\""),
            "IdentificationNumber2=\"[^\"]*\"", "IdentificationNumber2=\"12345678901\"");
        reports.Clear();
        var formula = Validate("0000000135_CSDF_20260930000001.xml", bytes(clean.Replace(company, gsis)), reports);
        Check(formula.Stage == "Preliminary" && formula.Issues.Any(i => i.Code == "20-052" && i.Message.StartsWith("The rule could not be evaluated")),
            "a rule that cannot be evaluated on a record is a preliminary finding, with the record");

        // Step 3: the XSD (here a small one that wants a 10-digit ProviderCode).
        var xsd = "<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"><xs:element name=\"CRIMS_Submission_Input\"><xs:complexType><xs:sequence>"
            + "<xs:element name=\"Header\"><xs:complexType><xs:attribute name=\"ProviderCode\" use=\"required\"><xs:simpleType><xs:restriction base=\"xs:string\"><xs:pattern value=\"\\d{10}\"/></xs:restriction></xs:simpleType></xs:attribute>"
            + "<xs:anyAttribute processContents=\"skip\"/></xs:complexType></xs:element>"
            + "<xs:element name=\"Body\"><xs:complexType><xs:sequence><xs:any processContents=\"skip\" minOccurs=\"0\" maxOccurs=\"unbounded\"/></xs:sequence></xs:complexType></xs:element>"
            + "<xs:element name=\"Footer\"><xs:complexType><xs:anyAttribute processContents=\"skip\"/></xs:complexType></xs:element>"
            + "</xs:sequence></xs:complexType></xs:element></xs:schema>";
        var schemas = XmlSchemaChecker.Load(xsd);
        var good = Validate("0000000135_CSDF_20260930000001.xml", bytes(clean), new Dictionary<string, byte[]>(), schemas);
        Check(good.XsdValid == true && good.XsdIssueCount == 0 && good.XsdReport == null, "the XSD check passes");
        reports.Clear();
        var badHeader = System.Text.RegularExpressions.Regex.Replace(clean, "(<Header [^>]*ProviderCode=\")[^\"]*\"", "$1ABC\"");
        var bad = Validate("0000000135_CSDF_20260930000001.xml", bytes(badHeader), reports, schemas);
        Check(bad.XsdValid == false && bad.XsdIssues[0].Path == "<CRIMS_Submission_Input>" && bad.XsdIssues[0].Line > 0 && bad.Outcome == "Failed",
            "the XSD check fails with its line and the elements open there");
        Check(new UTF8Encoding(true).GetString(reports[bad.XsdReport]).Contains("\"Line\",") == false && new UTF8Encoding(true).GetString(reports[bad.XsdReport]).StartsWith("\uFEFFLine,Position,Severity"),
            "the XSD messages as a .csv for Excel");
        Check(XmlSchemaChecker.SchemaProblem("<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"><xs:element name=\"a\" type=\"nope\"/></xs:schema>") != null,
            "an XSD that does not compile is refused");
        Check(XmlSchemaChecker.SchemaProblem("<!DOCTYPE x [<!ENTITY e SYSTEM \"file:///etc/passwd\">]><xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"/>") != null,
            "an XSD with a DTD is refused");
    }

    // ---------- the services ----------

    static async Task Services()
    {
        var versions = new Versions();
        var audit = new Audit();
        var storage = new FixedOptions<FileStorageOptions>(new FileStorageOptions { RootPath = tempDir, MaxUploadMegabytes = 50 });
        var maker = new User { UserName = "CORP\\maker", Granted = { FrpMapper.Shared.Models.Permissions.ReferenceManage } };
        var checker = new User { UserName = "CORP\\checker", Granted = { FrpMapper.Shared.Models.Permissions.ReferenceApprove } };
        var preparer = new User { UserName = "CORP\\preparer", Granted = { FrpMapper.Shared.Models.Permissions.SubmissionPrepare } };
        var nobody = new User { UserName = "CORP\\nobody" };
        Func<User, CocreeConfigService> settings = u => new CocreeConfigService(versions, u, storage);
        var configFile = Upload(Path.Combine(configDir, "cocree_config.xlsx"));
        var codesFile = Upload(Path.Combine(configDir, "cocree_dropdown_options.xlsx"));
        var rulesFile = Upload(Path.Combine(configDir, "cocree_validations.xlsx"));
        Func<IFormFile, IFormFile, string, CocreeConfigUpload> files = (config, codes, note) =>
            new CocreeConfigUpload { ConfigWorkbook = config, CodeListWorkbook = codes, ValidationWorkbook = rulesFile, Note = note };

        await RefusedAsync(() => settings(nobody).UploadAsync(files(configFile, codesFile, null), CancellationToken.None), "only a Maker uploads a configuration", WorkflowErrorKind.Forbidden);
        await RefusedAsync(() => settings(maker).UploadAsync(files(configFile, new MemoryFormFile("f", "codes.csv", new byte[1]), null), CancellationToken.None), "the code lists must be .xlsx");
        await RefusedAsync(() => settings(maker).UploadAsync(new CocreeConfigUpload { ConfigWorkbook = configFile, CodeListWorkbook = codesFile }, CancellationToken.None),
            "the validation rules workbook is required");
        var first = await settings(maker).UploadAsync(files(configFile, codesFile, "From the Workbench 3.1.0.1"), CancellationToken.None);
        Check(first.Status == "Pending" && first.Kind == WorkbenchConfigKind.Cocree && Fact(first.Summary, "input files") == 15 && first.ContentHash.Length == 64
            && first.Note == "From the Workbench 3.1.0.1", "uploaded as Pending with its summary");
        await RefusedAsync(() => settings(maker).UploadAsync(files(configFile, codesFile, null), CancellationToken.None), "a second upload waits for the first", WorkflowErrorKind.Conflict);
        await RefusedAsync(() => settings(maker).DecideAsync(first.Id, "approve", new AccessDecisionRequest { Version = first.Version }, CancellationToken.None),
            "the Maker cannot approve", WorkflowErrorKind.Forbidden);
        var withApprove = new User { UserName = "CORP\\maker", Granted = { FrpMapper.Shared.Models.Permissions.ReferenceManage, FrpMapper.Shared.Models.Permissions.ReferenceApprove } };
        await RefusedAsync(() => settings(withApprove).DecideAsync(first.Id, "approve", new AccessDecisionRequest { Version = first.Version }, CancellationToken.None),
            "not even with the Checker's permission: never your own upload", WorkflowErrorKind.Forbidden);
        await RefusedAsync(() => settings(checker).DecideAsync(first.Id, "reject", new AccessDecisionRequest { Version = first.Version }, CancellationToken.None), "a rejection needs a reason");

        // Generating before any approval is refused.
        var service = new CocreeService(versions, new References(), new CocreeOutputStore(storage, new HostEnvironment("Development", tempDir)), preparer, audit, storage);
        Check(!(await service.SetupAsync(CancellationToken.None)).Configured, "nothing to generate with before the first approval");

        Check(await settings(checker).DecideAsync(first.Id, "approve", new AccessDecisionRequest { Version = first.Version }, CancellationToken.None), "another Checker approves");
        Check((await versions.GetActiveAsync(WorkbenchConfigKind.Cocree, CancellationToken.None)).Version.Id == first.Id, "the approved version is in use");
        await RefusedAsync(() => settings(maker).UploadAsync(files(configFile, codesFile, null), CancellationToken.None), "the same workbooks again: nothing changed");

        var changedConfig = new MemoryFormFile("f", "cocree_config.xlsx", Changed(File.ReadAllBytes(Path.Combine(configDir, "cocree_config.xlsx")), t =>
        {
            var mapping = t.First(x => x.Name == "xml_mapping");
            mapping.Rows.Add(mapping.Rows[0].ToList());
        }));
        var second = await settings(maker).UploadAsync(files(changedConfig, codesFile, null), CancellationToken.None);
        Check(second.Summary.Changes.SequenceEqual(new[] { "xml_mapping: 1 row added." }), "the Checker sees what changes: " + string.Join(" | ", second.Summary.Changes));
        await RefusedAsync(() => settings(checker).DecideAsync(second.Id, "cancel", new AccessDecisionRequest { Version = second.Version }, CancellationToken.None),
            "only the uploader cancels", WorkflowErrorKind.Forbidden);
        var pendingVersion = (await versions.GetAsync(second.Id, CancellationToken.None)).Version.Version;
        Check(await settings(maker).DecideAsync(second.Id, "cancel", new AccessDecisionRequest { Version = pendingVersion }, CancellationToken.None), "the uploader cancels");
        Check((await settings(checker).ListAsync(CancellationToken.None)).Versions.Count == 2, "the Checker sees the versions");
        await RefusedAsync(() => settings(preparer).ListAsync(CancellationToken.None), "people who only generate do not see the versions", WorkflowErrorKind.Forbidden);

        var download = await settings(preparer).DownloadAsync(first.Id, "code-lists", CancellationToken.None);
        Check(download != null && download.FileName.StartsWith("cocree_dropdown_options_active_"), "the configuration in use can be downloaded");
        Check(await settings(preparer).DownloadAsync(second.Id, "config", CancellationToken.None) == null, "a version not in use is only for its Makers and Checkers");
        var rulesDownload = await settings(checker).DownloadAsync(first.Id, "validations", CancellationToken.None);
        Check(rulesDownload != null && rulesDownload.FileName.StartsWith("cocree_validations_active_"), "the validation rules workbook can be downloaded");
        Check(await settings(checker).DownloadAsync(first.Id, "xsd", CancellationToken.None) == null, "no XSD in this version: nothing to download");

        // Generating XML.
        var setup = await service.SetupAsync(CancellationToken.None);
        Check(setup.Configured && setup.InputFiles.Count == 15 && setup.Providers.Select(p => p.Code).SequenceEqual(new[] { "0004000476", "0000000135" }),
            "setup: the configuration's input files and the 10-digit provider codes of the bank profiles");
        Func<CocreeExportRequest> request = () => new CocreeExportRequest
        {
            Files = Directory.GetFiles(basicDir, "*.xlsx").OrderBy(f => f).Select(f => Upload(f)).ToList(),
            ProviderCode = "0000000135", ReferenceDate = "2026-09-30", SubmissionType = "0", Version = "1.0", ProviderComments = "", MaxRecordsPerFile = "300000"
        };
        var r = request(); r.ProviderCode = "1234567890";
        await RefusedAsync(() => service.ExportAsync(r, CancellationToken.None), "a provider code that is not a bank profile's");
        r = request(); r.ReferenceDate = DateTime.Today.AddDays(1).ToString("yyyy-MM-dd");
        await RefusedAsync(() => service.ExportAsync(r, CancellationToken.None), "a future reference date");
        r = request(); r.MaxRecordsPerFile = "0";
        await RefusedAsync(() => service.ExportAsync(r, CancellationToken.None), "0 records per file");
        r = request(); r.Files.Add(new MemoryFormFile("files", "input.xlsb", new byte[10]));
        await RefusedAsync(() => service.ExportAsync(r, CancellationToken.None), "a .xlsb workbook");
        var stranger = new CocreeService(versions, new References(), new CocreeOutputStore(storage, new HostEnvironment("Development", tempDir)), nobody, audit, storage);
        await RefusedAsync(() => stranger.ExportAsync(request(), CancellationToken.None), "generating needs submission.prepare", WorkflowErrorKind.Forbidden);

        var updates = new List<ValidationProgressDto>();
        var exported = await service.ExportAsync(request(), CancellationToken.None, new Progress(updates));
        Check(exported.Succeeded && exported.OutputId.Length == 32 && exported.ConfigurationId == first.Id && updates.Count > 0, "generated with the approved configuration, with progress");
        var entry = audit.Entries.Last();
        Check(entry.Action == "COCREE XML generated" && entry.Details.Contains("SHA-256") && entry.Details.Contains(exported.Files[0].Name), "the run is in the audit trail");
        var file = service.Download(exported.OutputId, exported.Files[0].Name);
        Check(file != null && file.ContentType == "application/xml", "the person who generated it downloads the file");
        file.Content.Dispose();

        var otherPreparer = new User { UserName = "CORP\\other", Granted = { FrpMapper.Shared.Models.Permissions.SubmissionPrepare } };
        var other = new CocreeService(versions, new References(), new CocreeOutputStore(storage, new HostEnvironment("Development", tempDir)), otherPreparer, audit, storage);
        Check(other.Download(exported.OutputId, exported.Files[0].Name) == null, "someone else cannot download it");
        Check(service.Download(exported.OutputId, "../owner.txt") == null && service.Download("../" + exported.OutputId, "x.xml") == null, "no way out of the run's folder");

        // Validating: the files of the run just generated, and uploaded files.
        var checkedRun = await service.ValidateAsync(new CocreeValidateRequest { RunId = exported.OutputId }, CancellationToken.None, new Progress(updates));
        Check(checkedRun.Files.Count == exported.Files.Count && checkedRun.Files.All(f => f.Report != null) && checkedRun.OutputId.Length == 32 && !checkedRun.XsdChecked,
            "the generated files are validated where they are, each with its report");
        Check(audit.Entries.Last().Action == "COCREE XML validated" && audit.Entries.Last().Details.Contains("SHA-256"), "validating is in the audit trail");
        var report = service.Download(checkedRun.OutputId, checkedRun.Files[0].Report);
        Check(report != null && report.ContentType == "application/xml", "the report can be downloaded");
        report.Content.Dispose();
        Check(other.Download(checkedRun.OutputId, checkedRun.Files[0].Report) == null, "by its owner only");
        await RefusedAsync(() => other.ValidateAsync(new CocreeValidateRequest { RunId = exported.OutputId }, CancellationToken.None), "someone else's run is not there to validate");
        await RefusedAsync(() => stranger.ValidateAsync(new CocreeValidateRequest { RunId = exported.OutputId }, CancellationToken.None), "validating needs submission.prepare", WorkflowErrorKind.Forbidden);
        await RefusedAsync(() => service.ValidateAsync(new CocreeValidateRequest { Files = new List<IFormFile> { new MemoryFormFile("files", "a.txt", new byte[1]) } }, CancellationToken.None),
            "only XML files are validated");
        await RefusedAsync(() => service.ValidateAsync(new CocreeValidateRequest(), CancellationToken.None), "no file, nothing to validate");
        var uploaded = await service.ValidateAsync(new CocreeValidateRequest { Files = new List<IFormFile> { new MemoryFormFile("files", "my file.xml", new UTF8Encoding(false).GetBytes("<x/>")) } },
            CancellationToken.None);
        Check(uploaded.Files[0].Outcome == "Stopped" && !uploaded.Succeeded, "an uploaded file that is not a CSDF file stops at Stage 1");

        // Header totals of a submission split into files.
        r = request(); r.MaxRecordsPerFile = "60";
        var split = await service.ExportAsync(r, CancellationToken.None);
        var parts = split.Files.Select(f =>
        {
            using (var stream = service.Download(split.OutputId, f.Name).Content)
            using (var copy = new MemoryStream()) { stream.CopyTo(copy); return (IFormFile)new MemoryFormFile("files", f.Name, copy.ToArray()); }
        }).ToList();
        var totals = await service.HeaderTotalsAsync(parts, "2026-09-30", false, CancellationToken.None);
        Check(totals.Succeeded && totals.Files.Count == split.Files.Count && totals.Subjects == 54 && totals.Contracts == 110 && totals.NegativeEvents == 6 && totals.OutputId == "",
            "the files are read and added up (" + totals.Files.Count + " files)");
        var applied = await service.HeaderTotalsAsync(parts, "2026-09-30", true, CancellationToken.None);
        using (var zipped = service.Download(applied.OutputId, "all.zip").Content)
        using (var archive = new ZipArchive(zipped))
        {
            Check(archive.Entries.Count == parts.Count && archive.Entries.All(e =>
            {
                var header = XDocument.Load(e.Open()).Root.Element("Header");
                return (string)header.Attribute("TotalSubjectRecords") == "54" && (string)header.Attribute("TotalContractRecords") == "110";
            }), "every file's Header carries the submission's totals (downloaded as one .zip)");
        }

        Check(audit.Entries.Last().Action == "COCREE header totals written", "writing the totals is in the audit trail");
        var bad = await service.HeaderTotalsAsync(parts.Take(1).ToList(), "2026-08-31", true, CancellationToken.None);
        Check(!bad.Succeeded && bad.OutputId == "", "files of another reference date: nothing is written");
    }

    class Progress : IProgress<ValidationProgressDto>
    {
        readonly List<ValidationProgressDto> updates;
        public Progress(List<ValidationProgressDto> updates) { this.updates = updates; }
        public void Report(ValidationProgressDto value) { lock (updates) updates.Add(value); }
    }

    // ---------- the Platform's proxy ----------

    static void Proxy()
    {
        var id = new string('a', 32);
        Check(ApiProxy.IsAllowed("GET", "/api/cocree/setup") && ApiProxy.IsAllowed("POST", "/api/cocree/export") && ApiProxy.IsAllowed("POST", "/api/cocree/header-totals"),
            "the proxy forwards the COCREE calls");
        Check(ApiProxy.IsAllowed("GET", "/api/cocree/outputs/" + id + "/0000000135_CSDF_20261031000001.xml") && ApiProxy.IsAllowed("GET", "/api/cocree/outputs/" + id + "/all.zip"),
            "downloads of generated files");
        Check(!ApiProxy.IsAllowed("GET", "/api/cocree/outputs/" + id + "/../owner.txt") && !ApiProxy.IsAllowed("GET", "/api/cocree/outputs/" + id + "/owner.txt"),
            "nothing else of a run's folder");
        Check(ApiProxy.IsAllowed("POST", "/api/cocree/config/" + id + "/approve") && !ApiProxy.IsAllowed("POST", "/api/cocree/config/" + id + "/remove")
            && ApiProxy.IsAllowed("GET", "/api/cocree/config/" + id + "/code-lists"), "configuration decisions and downloads");
        Check(ApiProxy.IsAllowed("POST", "/api/cocree/validate") && ApiProxy.IsAllowed("GET", "/api/cocree/config/" + id + "/validations") && ApiProxy.IsAllowed("GET", "/api/cocree/config/" + id + "/xsd")
            && ApiProxy.IsAllowed("GET", "/api/cocree/outputs/" + id + "/a_XSD_Validation_Result_20261028_120000.csv"), "validation, its reports and the new configuration files");
        Check(ApiProxy.IsAllowed("GET", "/api/xml-tools/setup") && ApiProxy.IsAllowed("POST", "/api/xml-tools/merge") && ApiProxy.IsAllowed("POST", "/api/xml-tools/validate")
            && ApiProxy.IsAllowed("GET", "/api/xml-tools/outputs/" + id + "/FRP_EXPORTED_ON_20261028_NORMALIZATION_LOG_20261028_120000.log")
            && ApiProxy.IsAllowed("GET", "/api/xml-tools/config/" + id + "/reportperiod") && !ApiProxy.IsAllowed("GET", "/api/xml-tools/config/" + id + "/other"), "the XML tools");
        Check(ApiProxy.IsAllowed("GET", "/api/logs") && ApiProxy.IsAllowed("GET", "/api/logs/api-20261028.log") && ApiProxy.IsAllowed("GET", "/api/logs/api-20261028.log/download")
            && !ApiProxy.IsAllowed("GET", "/api/logs/..%2Fweb.config") && !ApiProxy.IsAllowed("GET", "/api/logs/web.config"), "the logs, and only log file names");
    }
}
