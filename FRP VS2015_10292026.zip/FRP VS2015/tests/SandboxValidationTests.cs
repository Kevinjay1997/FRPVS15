// Tests of validating in the BSP sandbox from the Validate page: BspResultReader (BSP's validation result read into
// findings, whatever its format: XML elements or attributes, JSON, text, PDF) and SandboxService.ValidateAsync /
// FindingsAsync (the XML sent to a test environment only, defaults from the XML's Header, BSP's result read back).
// Arguments: uni-chain.pfx (password "test-password"), as for SandboxTests.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.BL;
using FrpMapper.Api.Contracts.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Contracts.Integration;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Platform.Services;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

static class SandboxValidationTests
{
    static int checks;
    static void Check(bool ok, string name) { if (!ok) throw new Exception("FAILED: " + name); checks++; Console.WriteLine("ok: " + name); }
    static async Task<string> Refused(Func<Task> action, string name, WorkflowErrorKind kind = WorkflowErrorKind.Invalid)
    {
        try { await action(); }
        catch (WorkflowException e) { Check(e.Kind == kind, name + " (" + kind + ")"); return e.Message; }
        throw new Exception("FAILED: accepted " + name);
    }
    static List<BspFindingDto> Read(string text) { return BspResultReader.Read(Encoding.UTF8.GetBytes(text)).Findings; }

    class User : ICurrentUser
    {
        public HashSet<string> Granted = new HashSet<string> { FrpMapper.Shared.Models.Permissions.SubmissionPrepare, FrpMapper.Shared.Models.Permissions.ProjectRead };
        public string Name { get { return "CORP\\maker"; } }
        public bool IsAuthenticated { get { return true; } }
        public bool HasPermission(string p) { return Granted.Contains(p); }
        public IReadOnlyList<string> Roles { get { return new string[0]; } }
        public IReadOnlyList<string> Permissions { get { return Granted.ToList(); } }
    }
    class Audit : IAuditLog
    {
        public List<AuditEntryDto> Entries = new List<AuditEntryDto>();
        public Task AppendAsync(AuditEntryDto e, CancellationToken c) { Entries.Add(e); return Task.FromResult(0); }
        public Task<IReadOnlyList<AuditEntryDto>> QueryAsync(string s, int n, CancellationToken c) { throw new NotImplementedException(); }
        public Task<IReadOnlyList<AuditEntryDto>> QueryByUserAsync(string s, int n, CancellationToken c) { throw new NotImplementedException(); }
        public Task<AuditPageDto> QueryPageAsync(string p, string s, string a, int k, int n, CancellationToken c) { throw new NotImplementedException(); }
    }
    class TestLog : ILogger<SandboxService>
    {
        public bool IsEnabled(LogLevel level) { return true; }
        public void Log(LogLevel level, Exception exception, string message) { }
    }
    class References : IReferenceDataRepository
    {
        public ReferenceDataDto Data = new ReferenceDataDto { Banks = new List<BankProfileDto> {
            new BankProfileDto { Key = "UNI", Name = "EAST WEST BANKING CORP", ProviderCode = "0000000135", BspUndertakingCode = "00000135", Version = 1 },
            new BankProfileDto { Key = "RB", Name = "RB", ProviderCode = "0004000476", BspUndertakingCode = "04000476", Version = 1 } } };
        public Task<ReferenceDataDto> ReadAsync(CancellationToken c) { return Task.FromResult(Data); }
        public Task<BankProfileRequestDto> CreateBankRequestAsync(BankProfileRequestDto r, CancellationToken c) { throw new NotImplementedException(); }
        public Task<bool> DecideBankRequestAsync(string a, byte[] b, string d, string e, DateTimeOffset f, string g, CancellationToken c) { throw new NotImplementedException(); }
        public Task SaveImportAsync(SandboxImportDto i, string u, CancellationToken c) { throw new NotImplementedException(); }
    }
    class Certificates : IBankCertificateRepository
    {
        public List<BankCertificateDto> Rows = new List<BankCertificateDto>();
        public Dictionary<string, byte[]> Blobs = new Dictionary<string, byte[]>();
        public Task<IReadOnlyList<BankCertificateDto>> ListAsync(CancellationToken c) { return Task.FromResult((IReadOnlyList<BankCertificateDto>)Rows.ToList()); }
        public Task<BankCertificateDto> RequestAsync(BankCertificateDto d, byte[] p, CancellationToken c) { throw new NotImplementedException(); }
        public Task<bool> DecideAsync(string id, byte[] v, string decision, string by, DateTimeOffset at, string comment, CancellationToken c) { throw new NotImplementedException(); }
        public Task<StoredBankCertificate> GetActiveAsync(string bank, CancellationToken c)
        {
            var row = Rows.FirstOrDefault(r => r.BankKey == bank && r.Status == "Active");
            return Task.FromResult(row == null ? null : new StoredBankCertificate { CertificateId = row.Id, BankKey = row.BankKey, Protected = Blobs[row.Id], Thumbprint = row.Thumbprint });
        }
    }
    class Environments : ISubmissionEnvironmentRepository
    {
        public List<SubmissionEnvironmentDto> Rows = new List<SubmissionEnvironmentDto>();
        public void Add(string key, string kind, string baseUrl)
        {
            Rows.Add(new SubmissionEnvironmentDto { Id = Guid.NewGuid().ToString("N"), Key = key, Name = key == "SANDBOX" ? "BSP sandbox" : key, Kind = kind, BaseUrl = baseUrl,
                SubmitPath = "submitReport", StatusPath = "{submissionId}/status", ResultPdfPath = "{submissionId}/result/pdf", ResultXmlPath = "{submissionId}/result/xml",
                ResultExcelPath = "{submissionId}/result/excel", ReceiptPath = "{submissionId}/confirmation/pdf", Status = "Active" });
        }
        public Task<IReadOnlyList<SubmissionEnvironmentDto>> ListAsync(CancellationToken c) { return Task.FromResult((IReadOnlyList<SubmissionEnvironmentDto>)Rows.ToList()); }
        public Task<SubmissionEnvironmentDto> RequestAsync(SubmissionEnvironmentDto e, CancellationToken c) { throw new NotImplementedException(); }
        public Task<bool> DecideAsync(string a, byte[] b, string d, string e, DateTimeOffset f, string g, CancellationToken c) { throw new NotImplementedException(); }
        public Task<SubmissionEnvironmentDto> GetActiveAsync(string key, CancellationToken c) { return Task.FromResult(Rows.FirstOrDefault(r => r.Key == key && r.Status == "Active")); }
    }
    /// <summary>The XML the Validate page checked: what FrpMappingService.XmlForSandboxAsync gives (tested with the project's XML in ProjectEditTests' store elsewhere).</summary>
    class Source : IValidationXmlSource
    {
        public string Xml = "<FRP_CONSO><Header><Undertaking>0000000135</Undertaking><Year>2026</Year><Period>9</Period></Header></FRP_CONSO>";
        public string FileName = "My report (final).xml";
        public string LastSource; public IFormFile LastFile;
        public Task<VT_FileName_Bytes<string, byte[]>?> XmlForSandboxAsync(string projectId, string source, IFormFile file, CancellationToken c)
        {
            LastSource = source; LastFile = file;
            if (projectId != "0123456789abcdef0123456789abcdef") return Task.FromResult((VT_FileName_Bytes<string, byte[]>?)null);
            return Task.FromResult((VT_FileName_Bytes<string, byte[]>?)new VT_FileName_Bytes<string, byte[]>(FileName, Encoding.UTF8.GetBytes(Xml)));
        }
    }
    class Client : IBspSandboxClient
    {
        public int Calls; public Uri Url; public string Body; public string Subject;
        public Func<Uri, SandboxResponse> Answer;
        public async Task<SandboxResponse> SendAsync(X509Certificate2 cert, Uri url, HttpContent content, bool download, CancellationToken c)
        {
            Calls++; Url = url; Subject = cert.Subject; Body = content == null ? null : await content.ReadAsStringAsync();
            return Answer(url);
        }
    }

    static int Main(string[] args)
    {
        Run(args).GetAwaiter().GetResult();
        Console.WriteLine("SandboxValidationTests: " + checks + " checks passed");
        return 0;
    }

    static async Task Run(string[] args)
    {
        // ---------- reading BSP's result ----------
        var elements = Read(@"<?xml version=""1.0""?><ValidationResult xmlns=""urn:bsp""><SubmissionId>7735089b-81d6-405e-8e67-255338dbce9a</SubmissionId><Status>Failed</Status>
            <Errors count=""2"">
              <Error><Code>ASSERTION-RIN-B1690</Code><Severity>Error</Severity><Message>Total loans must equal the sum of branches. Result: 51 = 57</Message><Field>[BRIS_DL][MAIN_Y1:233][C0010]</Field></Error>
              <Error><Code>COND-0001</Code><Severity>Warning</Severity><Message>Conditional field [FRP_1][MAIN][R0020C0010] should not be reported</Message></Error>
            </Errors></ValidationResult>");
        Check(elements.Count == 2, "XML elements: one finding per error, none for the header values");
        Check(elements[0].Code == "ASSERTION-RIN-B1690" && elements[0].Severity == "Error" && elements[0].Message.StartsWith("Total loans") && elements[0].Location == "[BRIS_DL][MAIN_Y1:233][C0010]"
            && elements[0].Form == "BRIS_DL" && elements[0].Table == "MAIN_Y1" && elements[0].Row == 233, "code, severity, message, field reference, form, table and row");
        Check(elements[1].Severity == "Warning" && elements[1].Location == "[FRP_1][MAIN][R0020C0010]" && elements[1].Row == null, "a warning; a reference found in the message");
        var attributes = Read("<result><finding rule='ASSERTION-X1' level='WARNING' description='Check this' xpath='[A][B:3][C]'/><finding rule='DYN-12' text='Invalid value for dynamic ENUM field ([BRIS_DL][MAIN:1][C0030])'/></result>");
        Check(attributes.Count == 2 && attributes[0].Code == "ASSERTION-X1" && attributes[0].Severity == "Warning" && attributes[0].Message == "Check this" && attributes[0].Row == 3
            && attributes[1].Code == "DYN-12" && attributes[1].Location == "[BRIS_DL][MAIN:1][C0030]", "XML attributes");
        var listed = Read("<messages><message>ASSERTION-A1: first problem</message><message>ASSERTION-B2: second problem [F][T:7][C1]</message></messages>");
        Check(listed.Count == 2 && listed[0].Code == "ASSERTION-A1" && listed[0].Message == "first problem" && listed[1].Row == 7, "a list of message elements: one finding each, no duplicate");
        var named = Read("<Errors><Error><RuleCode>RIN-B1690</RuleCode><ErrorMessage>Not equal</ErrorMessage></Error></Errors>");
        Check(named.Count == 1 && named[0].Code == "RIN-B1690" && named[0].Message == "Not equal", "a rule in a field named like a code, without the ASSERTION- prefix");
        var json = Read(@"{""submissionId"":""x"",""errors"":[{""code"":""ASSERTION-J1"",""message"":""json problem"",""severity"":""error"",""location"":""[F][T:2][C]""},{""ruleCode"":""COND-7"",""description"":""cond""}]}");
        Check(json.Count == 2 && json[0].Code == "ASSERTION-J1" && json[0].Row == 2 && json[1].Code == "COND-7" && json[1].Message == "cond", "JSON");
        var text = Read("SANDBOX processing result ASSERTION-T1 Rule one failed. Result: 1 = 2 [F][T:4][C9] COND-0003 Conditional field [F][X][C1] should not be reported");
        Check(text.Count == 2 && text[0].Code == "ASSERTION-T1" && text[0].Message.Contains("Result: 1 = 2") && text[0].Row == 4 && text[1].Code == "COND-0003", "plain text, split at each code");
        var unknownXml = Read("<report><line>ASSERTION-U1 something wrong</line><line>all else fine</line></report>");
        Check(unknownXml.Count == 1 && unknownXml[0].Code == "ASSERTION-U1", "an XML whose records hold no code field: read as text");
        Check(Read("<ValidationResult><Status>Passed</Status><Errors/></ValidationResult>").Count == 0, "a result with no findings");
        Check(BspResultReader.Read(Encoding.ASCII.GetBytes("%PDF-1.7 ...")).Format == "pdf" && BspResultReader.Read(new byte[0]).Format == "empty", "PDF and empty answers: no findings");
        Check(BspResultReader.Read(Encoding.UTF8.GetBytes("<!DOCTYPE x [<!ENTITY e SYSTEM 'file:///etc/passwd'>]><x>&e; ASSERTION-Q</x>")).Findings.All(f => !f.Message.Contains("root:")), "no external entities read");
        var many = "<r>" + string.Concat(Enumerable.Range(0, 25000).Select(i => "<e><code>ASSERTION-M" + i + "</code><message>m</message></e>")) + "</r>";
        Check(Read(many).Count == BspResultReader.MaxFindings, "at most 20,000 findings");
        var longMessage = Read("<e><code>ASSERTION-L</code><message>" + new string('x', 5000) + "</message></e>");
        Check(longMessage[0].Message.Length <= 2001, "long messages cut");

        // ---------- the parameters read from the XML ----------
        var banks = new References().Data.Banks;
        Func<string, SandboxParametersDto> Params = xml => BspXmlParameters.Read(System.Xml.Linq.XDocument.Parse(xml).Root, banks);
        var p1 = Params("<FRP_CONSO xmlns='urn:x'><Header><Undertaking>135</Undertaking><Year>2026</Year><Period>9</Period></Header></FRP_CONSO>");
        Check(p1.ReportCode == "FRP_CONSO" && p1.Period == "2026-09" && p1.Undertaking == "135" && p1.BankKey == "UNI" && p1.BankName == "EAST WEST BANKING CORP",
            "report code from the root, period from Year and Period, bank from Undertaking (leading zeros ignored), with a namespace");
        var p2 = Params("<CAR_M><Header><Undertaking>0004000476</Undertaking><Year>2025</Year><Period>12</Period></Header></CAR_M>");
        Check(p2.ReportCode == "CAR_M" && p2.Period == "2025-12" && p2.BankKey == "RB", "CAR_M for RB, December");
        var p3 = Params("<FRP><Header><Undertaking>999</Undertaking><Year>25</Year><Period>13</Period></Header></FRP>");
        Check(p3.ReportCode == "FRP" && p3.Period == "" && p3.BankKey == null && p3.Undertaking == "999", "no period from a bad year or month; no bank for an unknown provider");
        Check(Params("<FRP/>").Period == "" && Params("<FRP/>").BankKey == null && Params("<FRP/>").Undertaking == "", "no Header: only the report code");

        // ---------- sending the validated XML to a test environment ----------
        var c = CancellationToken.None;
        var user = new User(); var audit = new Audit(); var references = new References(); var certificates = new Certificates(); var source = new Source();
        var environments = new Environments();
        environments.Add("SANDBOX", "Test", "https://rapi.bsp.gov.ph/api/sandbox/submission/");
        environments.Add("PRODUCTION", "Production", "https://rapi.bsp.gov.ph/api/production/submission/");
        var protector = new CertificateProtector(new AppConfiguration(new System.Collections.Specialized.NameValueCollection { { "Certificates:ProtectionKey", "test-protection-key-0123456789abcdef-0123456789" } }, null));
        var pfx = File.ReadAllBytes(args[0]);
        var certificateId = Guid.NewGuid().ToString("N");
        certificates.Rows.Add(new BankCertificateDto { Id = certificateId, BankKey = "UNI", Status = "Active", Thumbprint = new string('A', 40) });
        certificates.Blobs[certificateId] = protector.Protect(pfx, "test-password", certificateId, "UNI");
        var client = new Client { Answer = url => new SandboxResponse { StatusCode = 200, Body = "{\"submissionId\":\"7735089B-81D6-405E-8E67-255338DBCE9A\",\"status\":\"RECEIVED\"}" } };
        var service = new SandboxService(client, references, certificates, protector, user, audit, new TestLog(), environments,
            new FixedOptions<BspOptions>(new BspOptions()), source);
        var project = "0123456789abcdef0123456789abcdef";

        var sent = await service.ValidateAsync(new SandboxRequest { Environment = "SANDBOX", ProjectId = project, Source = "generated" }, c);
        Check(source.LastSource == "generated", "the server builds the XML from the project");
        Check(sent.SubmissionId == "7735089b-81d6-405e-8e67-255338dbce9a" && sent.StatusCode == 200 && sent.EnvironmentName == "BSP sandbox", "submitted; BSP's submission ID read from its answer");
        Check(sent.BankKey == "UNI" && sent.ReportCode == "FRP_CONSO" && sent.Period == "2026-09", "bank, report code and period from the XML's Header");
        Check(sent.FileName == "My report _final_.xml" && client.Body.Contains("filename=\"My report _final_.xml\""), "a file name BSP accepts");
        Check(client.Url.AbsoluteUri == "https://rapi.bsp.gov.ph/api/sandbox/submission/submitReport" && client.Subject.Contains("SandboxTest UNI"), "sent to the sandbox with UNI's stored certificate");
        Check(client.Body.Contains("{\"reportCode\":\"FRP_CONSO\",\"undertakingCode\":\"00000135\",\"period\":\"2026-09\",\"mainFile\":{\"filename\":\"My report _final_.xml\"}}"), "reportInfo with the bank's undertaking code");
        var submitted = audit.Entries[audit.Entries.Count - 2];
        Check(submitted.Action == "sandbox.submit" && submitted.Details.Contains("Sent from the Validate page: project " + project) && submitted.Details.Contains("built from the project"),
            "audited as sent from the Validate page");

        sent = await service.ValidateAsync(new SandboxRequest { Environment = "SANDBOX", ProjectId = project, Source = "file", Xml = new MemoryFormFile("file", "x.xml", new byte[1]),
            ReportCode = "FRP_CONSO_Q", Period = "2026-06", BankKey = "UNI" }, c);
        Check(source.LastSource == "file" && source.LastFile.FileName == "x.xml" && sent.ReportCode == "FRP_CONSO_Q" && sent.Period == "2026-06", "the uploaded XML; report code and period as given");
        sent = await service.ValidateAsync(new SandboxRequest { Environment = "SANDBOX", ProjectId = project, Source = "workbook", Workbook = new MemoryFormFile("workbookFile", "filled.xlsx", new byte[1]) }, c);
        Check(source.LastSource == "workbook" && source.LastFile.FileName == "filled.xlsx" && audit.Entries[audit.Entries.Count - 2].Details.Contains("filled template filled.xlsx"), "the filled template");

        var calls = client.Calls;
        await Refused(() => service.ValidateAsync(new SandboxRequest { Environment = "PRODUCTION", ProjectId = project, Source = "generated" }, c), "Production without submission.production", WorkflowErrorKind.Forbidden);
        user.Granted.Add(Permissions.SubmissionProduction);
        var m = await Refused(() => service.ValidateAsync(new SandboxRequest { Environment = "PRODUCTION", ProjectId = project, Source = "generated" }, c), "Production even with submission.production");
        Check(m.Contains("test environments"), "Production refused on the Validate page, explained");
        user.Granted.Remove(Permissions.SubmissionProduction);
        await Refused(() => service.ValidateAsync(new SandboxRequest { Environment = "SANDBOX", ProjectId = "ffffffffffffffffffffffffffffffff", Source = "generated" }, c), "a project the person cannot see");
        source.Xml = "<FRP><Header><Undertaking>0000000999</Undertaking></Header></FRP>";
        m = await Refused(() => service.ValidateAsync(new SandboxRequest { Environment = "SANDBOX", ProjectId = project, Source = "generated" }, c), "no bank profile for the XML's provider code");
        Check(m.Contains("0000000999"), "the provider code named");
        source.Xml = "<FRP><Header><Undertaking>0004000476</Undertaking><Year>2026</Year><Period>3</Period></Header></FRP>";
        m = await Refused(() => service.ValidateAsync(new SandboxRequest { Environment = "SANDBOX", ProjectId = project, Source = "generated" }, c), "RB without a stored certificate");
        Check(m.Contains("RB") && m.Contains("certificate"), "missing certificate explained");
        sent = await service.ValidateAsync(new SandboxRequest { Environment = "SANDBOX", ProjectId = project, Source = "generated",
            Certificate = new MemoryFormFile("certificate", "uni.pfx", pfx), Password = "test-password" }, c);
        Check(sent.BankKey == "RB" && sent.Period == "2026-03" && client.Body.Contains("\"undertakingCode\":\"04000476\""), "RB with a PFX uploaded for the request");
        user.Granted.Remove(Permissions.ProjectRead);
        await Refused(() => service.ValidateAsync(new SandboxRequest { Environment = "SANDBOX", ProjectId = project, Source = "generated" }, c), "without project.read", WorkflowErrorKind.Forbidden);
        user.Granted.Add(Permissions.ProjectRead);
        Check(client.Calls == calls + 1, "nothing sent when refused");

        client.Answer = url => new SandboxResponse { StatusCode = 400, Body = "{\"message\":\"No main report file\"}" };
        source.Xml = "<FRP_CONSO><Header><Undertaking>0000000135</Undertaking><Year>2026</Year><Period>9</Period></Header></FRP_CONSO>";
        sent = await service.ValidateAsync(new SandboxRequest { Environment = "SANDBOX", ProjectId = project, Source = "generated" }, c);
        Check(sent.SubmissionId == null && sent.StatusCode == 400 && sent.Body.Contains("No main report file"), "BSP refused the submission: no submission ID, its answer kept");
        client.Answer = url => new SandboxResponse { StatusCode = 400, Body = "{\"submissionId\":\"7735089b-81d6-405e-8e67-255338dbce9a\",\"error\":\"bad\"}" };
        sent = await service.ValidateAsync(new SandboxRequest { Environment = "SANDBOX", ProjectId = project, Source = "generated" }, c);
        Check(sent.SubmissionId == null, "an ID in a refusal is not taken as accepted");

        // ---------- the parameters before sending: nothing sent, nothing recorded ----------
        calls = client.Calls; var audited = audit.Entries.Count;
        var parameters = await service.ParametersAsync(new SandboxRequest { ProjectId = project, Source = "generated" }, c);
        Check(parameters.ReportCode == "FRP_CONSO" && parameters.Period == "2026-09" && parameters.BankKey == "UNI" && parameters.HasStoredCertificate
            && parameters.FileName == "My report _final_.xml", "parameters read from the server-built XML, with the stored certificate");
        source.Xml = "<FRP><Header><Undertaking>0004000476</Undertaking><Year>2026</Year><Period>3</Period></Header></FRP>";
        parameters = await service.ParametersAsync(new SandboxRequest { ProjectId = project, Source = "generated" }, c);
        Check(parameters.BankKey == "RB" && !parameters.HasStoredCertificate, "a bank without a stored certificate");
        Check(client.Calls == calls && audit.Entries.Count == audited, "reading the parameters sends nothing to BSP");
        await Refused(() => service.ParametersAsync(new SandboxRequest { ProjectId = "ffffffffffffffffffffffffffffffff", Source = "generated" }, c), "parameters of a project the person cannot see");
        user.Granted.Remove(FrpMapper.Shared.Models.Permissions.ProjectRead);
        await Refused(() => service.ParametersAsync(new SandboxRequest { ProjectId = project, Source = "generated" }, c), "parameters without project.read", WorkflowErrorKind.Forbidden);
        user.Granted.Add(FrpMapper.Shared.Models.Permissions.ProjectRead);
        source.Xml = "<FRP_CONSO><Header><Undertaking>0000000135</Undertaking><Year>2026</Year><Period>9</Period></Header></FRP_CONSO>";

        // ---------- BSP's result read back ----------
        client.Answer = url => new SandboxResponse { StatusCode = 404, Body = "{\"message\":\"Result not yet available\"}" };
        var findings = await service.FindingsAsync(new SandboxRequest { Environment = "SANDBOX", BankKey = "UNI", UseStoredCertificate = true, SubmissionId = "7735089B-81D6-405E-8E67-255338DBCE9A" }, c);
        Check(!findings.Ready && findings.StatusCode == 404 && findings.Body.Contains("not yet") && findings.SubmissionId == "7735089b-81d6-405e-8e67-255338dbce9a", "not ready yet: BSP's answer");
        Check(client.Url.AbsoluteUri == "https://rapi.bsp.gov.ph/api/sandbox/submission/7735089b-81d6-405e-8e67-255338dbce9a/result/xml", "read from the environment's result XML URL");
        client.Answer = url => new SandboxResponse { StatusCode = 200, FileBytes = Encoding.UTF8.GetBytes("<r><Error><Code>ASSERTION-RIN-B1690</Code><Message>m</Message></Error></r>") };
        findings = await service.FindingsAsync(new SandboxRequest { Environment = "SANDBOX", BankKey = "UNI", UseStoredCertificate = true, SubmissionId = "7735089b-81d6-405e-8e67-255338dbce9a" }, c);
        Check(findings.Ready && findings.Format == "xml" && findings.Findings.Single().Code == "ASSERTION-RIN-B1690", "ready: the findings");
        Check(audit.Entries.Last().Action == "sandbox.xml.result", "reading the result is audited");
        await Refused(() => service.FindingsAsync(new SandboxRequest { Environment = "SANDBOX", BankKey = "UNI", UseStoredCertificate = true, SubmissionId = "../x" }, c), "a submission ID that is not one");

        // ---------- the Platform's proxy ----------
        Check(ApiProxy.IsAllowed("POST", "/api/sandbox/validate") && ApiProxy.IsAllowed("POST", "/api/sandbox/findings") && ApiProxy.IsAllowed("POST", "/api/sandbox/parameters") && !ApiProxy.IsAllowed("GET", "/api/sandbox/findings"), "proxy: validate and findings by POST");
    }
}
