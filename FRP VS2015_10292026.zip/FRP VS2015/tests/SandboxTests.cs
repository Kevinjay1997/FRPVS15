// BSP submission (sandbox) tests. Run with the built API/Shared/Platform assemblies and disposable test PFX files made for
// testing only (never a bank certificate): args = uni-chain.pfx (password "test-password", with its CA), rb-nopassword.pfx
// (no password), nokey.pfx (certificate without key), expired.pfx (password "test-password").
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Contracts.Integration;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Platform.Services;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;
class SandboxTests
{
    class User : ICurrentUser {
        public bool Allowed = true; public string Permission = FrpMapper.Shared.Models.Permissions.SubmissionPrepare;
        public string UserName = "test";
        public string Name { get { return UserName; } }
        public bool IsAuthenticated { get { return true; } }
        public HashSet<string> Extra = new HashSet<string>();
        public bool HasPermission(string p) { return Allowed && (p == Permission || Extra.Contains(p)); }
        public IReadOnlyList<string> Roles { get { return new string[0]; } }
        public IReadOnlyList<string> Permissions { get { return new string[0]; } }
    }
    class Audit : IAuditLog {
        public List<AuditEntryDto> Entries = new List<AuditEntryDto>(); public bool Fail;
        public Task AppendAsync(AuditEntryDto e, CancellationToken c) {
            Check(!e.Details.Contains("test-password"), "audit excludes password");
            if (Fail && e.Action.EndsWith(".result")) throw new InvalidOperationException("audit down");
            Entries.Add(e); return Task.FromResult(0);
        }
        public Task<IReadOnlyList<AuditEntryDto>> QueryAsync(string s,int n,CancellationToken c) { throw new NotImplementedException(); }
        public Task<IReadOnlyList<AuditEntryDto>> QueryByUserAsync(string s,int n,CancellationToken c) { throw new NotImplementedException(); }
        public Task<AuditPageDto> QueryPageAsync(string p,string s,string a,int k,int n,CancellationToken c) { throw new NotImplementedException(); }
    }
    class TestLog : ILogger<SandboxService> {
        public int Errors;
        public bool IsEnabled(LogLevel level) { return true; }
        public void Log(LogLevel level, Exception exception, string message) { if (level == LogLevel.Error) Errors++; }
    }
    class References : IReferenceDataRepository {
        public ReferenceDataDto Data = new ReferenceDataDto { Banks = new List<BankProfileDto> {
            new BankProfileDto { Key = "UNI", Name = "EAST WEST BANKING CORP", ProviderCode = "0000000135", BspUndertakingCode = "00000135", Version = 1 },
            new BankProfileDto { Key = "RB", Name = "RB", ProviderCode = "0004000476", BspUndertakingCode = "04000476", Version = 1 },
            new BankProfileDto { Key = "NEW", Name = "No code yet", ProviderCode = "0000000999", Version = 1 } } };
        public BankProfileRequestDto Created;
        public Task<ReferenceDataDto> ReadAsync(CancellationToken c) { return Task.FromResult(Data); }
        public Task<BankProfileRequestDto> CreateBankRequestAsync(BankProfileRequestDto r, CancellationToken c) { Created = r; return Task.FromResult(r); }
        public Task<bool> DecideBankRequestAsync(string a, byte[] b, string d, string e, DateTimeOffset f, string g, CancellationToken c) { throw new NotImplementedException(); }
        public Task SaveImportAsync(SandboxImportDto i, string u, CancellationToken c) { throw new NotImplementedException(); }
    }
    class Certificates : IBankCertificateRepository {
        public List<BankCertificateDto> Rows = new List<BankCertificateDto>();
        public Dictionary<string, byte[]> Blobs = new Dictionary<string, byte[]>();
        public Task<IReadOnlyList<BankCertificateDto>> ListAsync(CancellationToken c) { return Task.FromResult((IReadOnlyList<BankCertificateDto>)Rows.ToList()); }
        public Task<BankCertificateDto> RequestAsync(BankCertificateDto d, byte[] p, CancellationToken c) {
            if (Rows.Any(r => r.BankKey == d.BankKey && r.Status == "Pending")) throw new AccessRequestOpenException("open");
            d.Status = "Pending"; d.Version = Convert.ToBase64String(new byte[8]); Rows.Add(d); Blobs[d.Id] = p; return Task.FromResult(d);
        }
        public Task<bool> DecideAsync(string id, byte[] v, string decision, string by, DateTimeOffset at, string comment, CancellationToken c) {
            var row = Rows.FirstOrDefault(r => r.Id == id); if (row == null) return Task.FromResult(false);
            if ((decision == "Approved" || decision == "Rejected") && row.RequestedBy == by) throw new AccessDecisionRefusedException("self");
            if (decision == "Approved") foreach (var a in Rows.Where(r => r.BankKey == row.BankKey && r.Status == "Active")) a.Status = "Replaced";
            row.Status = decision == "Approved" ? "Active" : decision; row.DecidedBy = by; row.DecisionComment = comment; return Task.FromResult(true);
        }
        public Task<StoredBankCertificate> GetActiveAsync(string bank, CancellationToken c) {
            var row = Rows.FirstOrDefault(r => r.BankKey == bank && r.Status == "Active");
            return Task.FromResult(row == null ? null : new StoredBankCertificate { CertificateId = row.Id, BankKey = row.BankKey, Protected = Blobs[row.Id], Thumbprint = row.Thumbprint });
        }
    }
    static CertificateProtector Protector(string key) {
        var settings = new System.Collections.Specialized.NameValueCollection();
        if (key != null) settings["Certificates:ProtectionKey"] = key;
        return new CertificateProtector(new AppConfiguration(settings, null));
    }
    /// <summary>The approved BSP environments, as script 010 seeds the sandbox, plus test ones.</summary>
    class Environments : ISubmissionEnvironmentRepository {
        public List<SubmissionEnvironmentDto> Rows = new List<SubmissionEnvironmentDto>();
        public SubmissionEnvironmentDto Add(string key, string kind, string baseUrl, string submit) {
            var e = new SubmissionEnvironmentDto { Id = Guid.NewGuid().ToString("N"), Key = key, Name = key + " env", Kind = kind, BaseUrl = baseUrl, SubmitPath = submit,
                StatusPath = "{submissionId}/status", ResultPdfPath = "{submissionId}/result/pdf", ResultXmlPath = "{submissionId}/result/xml",
                ResultExcelPath = "{submissionId}/result/excel", ReceiptPath = "{submissionId}/confirmation/pdf", Status = "Active", SortOrder = Rows.Count };
            Rows.Add(e); return e;
        }
        public Task<IReadOnlyList<SubmissionEnvironmentDto>> ListAsync(CancellationToken c) { return Task.FromResult((IReadOnlyList<SubmissionEnvironmentDto>)Rows.ToList()); }
        public Task<SubmissionEnvironmentDto> RequestAsync(SubmissionEnvironmentDto e, CancellationToken c) { throw new NotImplementedException(); }
        public Task<bool> DecideAsync(string a, byte[] b, string d, string e, DateTimeOffset f, string g, CancellationToken c) { throw new NotImplementedException(); }
        public Task<SubmissionEnvironmentDto> GetActiveAsync(string key, CancellationToken c) { return Task.FromResult(Rows.FirstOrDefault(r => r.Key == key && r.Status == "Active")); }
    }
    const string SandboxBase = "https://rapi.bsp.gov.ph/api/sandbox/submission/";
    class Client : IBspSandboxClient {
        public int Calls; public string Path, Body, Subject; public Uri Url; public bool Download; public HttpContent Content; public int Status = 200; public Exception Throw;
        public async Task<SandboxResponse> SendAsync(X509Certificate2 cert,Uri url,HttpContent content,bool download,CancellationToken c) {
            // Path: the part after the sandbox's base URL (what these tests check), or the whole URL for another environment.
            Calls++; Url=url; Download=download; Path=url.AbsoluteUri.StartsWith(SandboxBase) ? url.AbsoluteUri.Substring(SandboxBase.Length) : url.AbsoluteUri;
            Subject=cert.Subject; Check(cert.HasPrivateKey, "client certificate has its key");
            Body=content==null ? null : await content.ReadAsStringAsync(); Content=content;
            if (Throw != null) throw Throw;
            return new SandboxResponse { StatusCode=Status, Body="{\"submissionId\":\"sample\"}", FileBytes=download ? new byte[]{1,2} : null };
        }
    }
    static int checks;
    static void Check(bool ok,string name) { if(!ok) throw new Exception("FAILED: " + name); checks++; }
    static async Task<string> Reject(Func<Task> f,string name) {
        try { await f(); } catch(WorkflowException e) { checks++; return e.Message; }
        throw new Exception("Accepted "+name);
    }
    static MemoryFormFile Pfx(string path, string name) { return new MemoryFormFile("certificate", name, File.ReadAllBytes(path)); }
    static MemoryFormFile Xml(string text) { return new MemoryFormFile("file", "report.xml", Encoding.UTF8.GetBytes(text)); }
    const string UniXml = "<FRP><Header><Undertaking>0000000135</Undertaking><Year>2026</Year><Period>9</Period></Header></FRP>";
    static void Main(string[] args) { Run(args).GetAwaiter().GetResult(); Console.WriteLine("PASS: " + checks + " sandbox assertions"); }
    static async Task Run(string[] args) {
        var client=new Client(); var user=new User(); var audit=new Audit(); var log=new TestLog(); var references=new References();
        var certificates=new Certificates(); var protector=Protector("test-protection-key-0123456789abcdef-0123456789");
        var environments=new Environments(); environments.Add("SANDBOX","Test",SandboxBase,"submitReport");
        var bspOptions=new FixedOptions<BspOptions>(new BspOptions());
        var service=new SandboxService(client,references,certificates,protector,user,audit,log,environments,bspOptions,null); var c=CancellationToken.None;

        // Bank profiles for the page: key, name, provider code and API undertaking code only.
        var banks=await service.BanksAsync(c);
        Check(banks.Count==3 && banks[0].Key=="NEW" && banks[2].Key=="UNI" && banks[2].UndertakingCode=="00000135" && banks[0].UndertakingCode==null,"bank list");

        // UNI: password-protected PFX that also carries its CA certificate.
        var r=new SandboxRequest { Operation="submit", Environment="SANDBOX", Certificate=Pfx(args[0],"uni.pfx"), Password="test-password", BankKey="UNI",
            ReportCode="FRP_CONSO", Period="2026-09", Xml=Xml(UniXml) };
        var info=await service.InspectAsync(r,c);
        // .NET Framework imports the CA certificate too; Mono (used only to run these tests off Windows) imports just the one with the key.
        var mono=Type.GetType("Mono.Runtime")!=null;
        Check(info.Subject.Contains("SandboxTest UNI") && info.Name=="SandboxTest UNI" && (info.OtherCertificates==1 || mono && info.OtherCertificates==0),"chain PFX: the certificate with the key is used, CA counted");
        Check(client.Calls==0,"inspect makes no network call");
        await service.ExecuteAsync(r,c);
        Check(client.Path=="submitReport","submit path");
        Check(client.Subject.Contains("SandboxTest UNI"),"UNI certificate sent");
        Check(client.Body.Contains("{\"reportCode\":\"FRP_CONSO\",\"undertakingCode\":\"00000135\",\"period\":\"2026-09\",\"mainFile\":{\"filename\":\"report.xml\"}}"),"reportInfo names the uploaded file");
        Check(client.Body.Contains("name=\"reportInfo\"") && client.Body.Contains("name=\"file\"; filename=\"report.xml\"") && !client.Body.Contains("filename*"),"multipart part headers");
        var sentType=FrpMapper.Api.Integration.BspSandboxClient.ContentTypeOf(client.Content);
        Check(sentType.StartsWith("multipart/form-data; boundary=FrpMapper") && !sentType.Contains("\"") && client.Body.Contains("--"+sentType.Substring(sentType.IndexOf('=')+1)+"\r\n"),"unquoted boundary that delimits the body");
        var sent=audit.Entries[audit.Entries.Count-2]; var outcome=audit.Entries[audit.Entries.Count-1];
        Check(sent.Action=="sandbox.submit" && sent.Details.Contains("Bank UNI") && sent.Details.Contains("SHA-256") && sent.Details.Contains("FRP_CONSO"),"audit before sending");
        Check(outcome.Action=="sandbox.submit.result" && outcome.Details.Contains("HTTP 200"),"audit of BSP's answer");
        Check(client.Url.AbsoluteUri==SandboxBase+"submitReport" && sent.Details.Contains("Environment SANDBOX (Test), "+SandboxBase+"submitReport"),"environment and URL in the audit trail");

        // Another approved Test environment: its own URLs are used.
        environments.Add("SANDBOX2","Test","https://rapi.bsp.gov.ph/api/sandbox2/submission/","v2/submitReportTest");
        r.Environment="SANDBOX2"; await service.ExecuteAsync(r,c);
        Check(client.Url.AbsoluteUri=="https://rapi.bsp.gov.ph/api/sandbox2/submission/v2/submitReportTest","another environment's submit URL reaches the client");
        Check(audit.Entries[audit.Entries.Count-2].Details.Contains("Environment SANDBOX2 (Test), https://rapi.bsp.gov.ph/api/sandbox2/submission/v2/submitReportTest"),"that environment recorded in the audit trail");
        // Nothing is sent without an approved environment, nor to one whose host the server does not allow.
        var envCalls=client.Calls;
        r.Environment=null; var m=await Reject(async()=>{await service.ExecuteAsync(r,c);},"no environment"); Check(m.Contains("environment"),"missing environment explained");
        r.Environment="NOPE"; m=await Reject(async()=>{await service.ExecuteAsync(r,c);},"unknown environment"); Check(m.Contains("NOPE"),"unknown environment named");
        environments.Rows.Last().Status="Removed"; r.Environment="SANDBOX2"; await Reject(async()=>{await service.ExecuteAsync(r,c);},"removed environment");
        environments.Add("ELSEWHERE","Test","https://example.com/api/","submitReport");
        r.Environment="ELSEWHERE"; m=await Reject(async()=>{await service.ExecuteAsync(r,c);},"host not allowed"); Check(m.Contains("example.com") && m.Contains("not allowed"),"disallowed host explained");
        Check(!(await service.EnvironmentsAsync(c)).Any(e=>e.Key=="ELSEWHERE"),"a disallowed host is not offered");
        Check(client.Calls==envCalls,"nothing sent without a usable environment");

        // Production: only with submission.production, and each submission confirmed by typing the key.
        environments.Add("PRODUCTION","Production","https://rapi.bsp.gov.ph/api/production/submission/","submitReport");
        var offered=await service.EnvironmentsAsync(c);
        Check(offered.Select(e=>e.Key).SequenceEqual(new[]{"SANDBOX","PRODUCTION"}) && offered[0].CanUse && !offered[1].CanUse && offered[1].SubmitUrl=="https://rapi.bsp.gov.ph/api/production/submission/submitReport"
            && offered[0].StatusUrl==SandboxBase+"{submissionId}/status","environments offered in order; Production not usable without the permission");
        r.Environment="PRODUCTION"; m=await Reject(async()=>{await service.ExecuteAsync(r,c);},"Production without submission.production"); Check(m.Contains("submission.production"),"Production permission explained");
        r.Operation="status"; r.SubmissionId="7735089b-81d6-405e-8e67-255338dbce9a"; await Reject(async()=>{await service.ExecuteAsync(r,c);},"Production status without the permission");
        r.Operation="submit"; user.Extra.Add(Permissions.SubmissionProduction);
        Check((await service.EnvironmentsAsync(c)).Single(e=>e.Key=="PRODUCTION").CanUse,"Production usable with the permission");
        m=await Reject(async()=>{await service.ExecuteAsync(r,c);},"Production submission without confirmation"); Check(m.Contains("Type PRODUCTION"),"confirmation asked");
        r.ConfirmEnvironment="production"; await Reject(async()=>{await service.ExecuteAsync(r,c);},"confirmation in other case");
        Check(client.Calls==envCalls,"nothing sent to Production before it is confirmed");
        r.ConfirmEnvironment="PRODUCTION"; await service.ExecuteAsync(r,c);
        Check(client.Url.AbsoluteUri=="https://rapi.bsp.gov.ph/api/production/submission/submitReport","Production submit URL");
        Check(audit.Entries[audit.Entries.Count-2].Action=="production.submit" && audit.Entries.Last().Action=="production.submit.result"
            && audit.Entries[audit.Entries.Count-2].Details.Contains("Environment PRODUCTION (Production)"),"Production requests audited as such");
        r.Operation="pdf"; var prodFile=await service.ExecuteAsync(r,c);
        Check(client.Url.AbsoluteUri=="https://rapi.bsp.gov.ph/api/production/submission/7735089b-81d6-405e-8e67-255338dbce9a/result/pdf" && client.Download
            && prodFile.FileName=="BSP-production-7735089b-81d6-405e-8e67-255338dbce9a-pdf.pdf","Production download: no confirmation needed, named after the environment");
        r.Operation="submit"; r.ConfirmEnvironment=null; r.Environment="SANDBOX"; r.SubmissionId=null; user.Extra.Clear();

        // The undertaking code always comes from the bank profile on the server.
        r.BankKey="RB"; r.Certificate=Pfx(args[1],"rb.pfx"); r.Password="";
        m=await Reject(async()=>{await service.ExecuteAsync(r,c);},"UNI XML with RB profile");
        Check(m.Contains("0000000135") && m.Contains("RB"),"header/bank mismatch explained");
        r.Xml=Xml(UniXml.Replace("0000000135","4000476"));   // leading zeros are not significant
        var calls=client.Calls; await service.ExecuteAsync(r,c);
        Check(client.Calls==calls+1 && client.Subject.Contains("SandboxTest RB") && client.Body.Contains("\"undertakingCode\":\"04000476\""),"RB: PFX without password, RB undertaking code");
        r.Xml=Xml("<FRP><Header><Year>2026</Year></Header></FRP>"); await service.ExecuteAsync(r,c); checks++;   // no Header/Undertaking: allowed
        r.BankKey="NEW"; m=await Reject(async()=>{await service.ExecuteAsync(r,c);},"bank without undertaking code"); Check(m.Contains("NEW"),"missing code names the bank");
        r.BankKey="XX"; await Reject(async()=>{await service.ExecuteAsync(r,c);},"unknown bank");
        r.BankKey=null; await Reject(async()=>{await service.ExecuteAsync(r,c);},"no bank");
        r.BankKey="UNI"; r.Certificate=Pfx(args[0],"uni.pfx"); r.Password="test-password"; r.Xml=Xml(UniXml);

        // Status and downloads: GUID only, same certificate, no body.
        r.SubmissionId=" 7735089B-81D6-405E-8E67-255338DBCE9A ";
        var ops=new[]{"status","pdf","xml","excel","receipt"}; var paths=new[]{"status","result/pdf","result/xml","result/excel","confirmation/pdf"};
        for(int i=0;i<ops.Length;i++) {
            r.Operation=ops[i]; var result=await service.ExecuteAsync(r,c);
            Check(client.Path=="7735089b-81d6-405e-8e67-255338dbce9a/"+paths[i],ops[i]+" path");
            Check(client.Body==null,"retrieval has no body");
            if(i>0) Check(result.FileName=="BSP-sandbox-7735089b-81d6-405e-8e67-255338dbce9a-"+ops[i]+"."+(ops[i]=="excel"?"xlsx":ops[i]=="xml"?"xml":"pdf"),"download name");
        }
        r.Operation="status"; r.SubmissionId="../../production"; await Reject(async()=>{await service.ExecuteAsync(r,c);},"invalid id");
        r.SubmissionId="7735089b-81d6-405e-8e67-255338dbce9a";

        // Report checks happen before the certificate is opened or anything is sent.
        r.Operation="submit"; calls=client.Calls;
        r.Period="2026-13"; await Reject(async()=>{await service.ExecuteAsync(r,c);},"bad month"); r.Period="2026-09";
        r.ReportCode="FRP CONSO"; await Reject(async()=>{await service.ExecuteAsync(r,c);},"bad report code"); r.ReportCode="FRP_CONSO";
        r.Xml=new MemoryFormFile("file","report.txt",Encoding.UTF8.GetBytes(UniXml)); await Reject(async()=>{await service.ExecuteAsync(r,c);},"not .xml");
        r.Xml=new MemoryFormFile("file","re'port.xml",Encoding.UTF8.GetBytes(UniXml)); await Reject(async()=>{await service.ExecuteAsync(r,c);},"unsafe filename");
        r.Xml=Xml(UniXml);
        Check(client.Calls==calls,"nothing sent for invalid input");

        // Edited reportInfo is sent exactly as written. Its contents are for BSP to evaluate.
        var edited="{\n  \"reportCode\": \"FRP\",\n  \"undertakingCode\": \"00000135\",\n  \"period\": \"2025-12\",\n  \"mainFile\": { \"filename\": \"report.xml\", \"note\": 1 },\n  \"remarks\": \"<b> & 'x' ünïcode\"\n}";
        r.ReportInfo="  \r\n"+edited+"\n "; r.ReportCode="FRP_CONSO"; r.Period="2026-09"; calls=client.Calls;
        await service.ExecuteAsync(r,c);
        Check(client.Calls==calls+1 && client.Body.Contains("name=\"reportInfo\"\r\n\r\n"+r.ReportInfo+"\r\n--"),"edited reportInfo sent exactly as written, including whitespace");
        Check(!client.Body.Contains("FRP_CONSO") && !client.Body.Contains("2026-09"),"form fields not used when reportInfo is edited");
        sent=audit.Entries[audit.Entries.Count-2];
        Check(sent.Details.Contains("report code FRP,") && sent.Details.Contains("period 2025-12") && sent.Details.Contains("reportInfo edited on the page, sent as: "+r.ReportInfo),"audit records the edited reportInfo");
        r.ReportInfo=edited.Replace("2025-12","2025-4"); await service.ExecuteAsync(r,c);
        Check(client.Body.Contains("\"period\": \"2025-4\"") && audit.Entries[audit.Entries.Count-2].Details.Contains("period 2025-4"),"one-digit month in edited reportInfo is sent unchanged");
        r.ReportInfo=null; await service.ExecuteAsync(r,c);
        Check(client.Body.Contains("{\"reportCode\":\"FRP_CONSO\",\"undertakingCode\":\"00000135\",\"period\":\"2026-09\",\"mainFile\":{\"filename\":\"report.xml\"}}"),"absent reportInfo: generated one sent");
        Check(!audit.Entries[audit.Entries.Count-2].Details.Contains("reportInfo edited"),"generated reportInfo not marked edited");
        r.Period="2025-4"; await service.ExecuteAsync(r,c);
        Check(client.Body.Contains("\"period\":\"2025-4\""),"one-digit month in a generated reportInfo is sent unchanged");
        r.Period="2026-09";

        // Field names and values in edited JSON are not constrained locally; only the JSON object structure is checked.
        Func<string,string> infoWith=(s)=>"{\"reportCode\":\"FRP\",\"undertakingCode\":\"00000135\",\"period\":\"2025-12\",\"mainFile\":{\"filename\":\"report.xml\"}"+s+"}";
        foreach (var body in new[] { "{}", infoWith("").Replace("00000135","04000476"),
            infoWith("").Replace("report.xml","other.xml"), infoWith("").Replace(",\"mainFile\":{\"filename\":\"report.xml\"}",""),
            infoWith("").Replace("\"FRP\"","\"FRP CONSO\""), infoWith("").Replace("2025-12","2025-13"),
            infoWith("").Replace("\"2025-12\"","202512"), infoWith(",\"pad\":\""+new string('x',16*1024)+"\""),
            infoWith(",\"undertakingCode\":\"04000476\""),
            infoWith("").Replace("{\"filename\":\"report.xml\"}","{\"filename\":\"report.xml\",\"filename\":\"other.xml\"}") }) {
            r.ReportInfo=body; await service.ExecuteAsync(r,c);
            Check(client.Body.Contains("name=\"reportInfo\"\r\n\r\n"+body+"\r\n--"),"edited JSON object sent unchanged");
        }
        calls=client.Calls;
        r.ReportInfo="{\"reportCode\":"; m=await Reject(async()=>{await service.ExecuteAsync(r,c);},"not JSON"); Check(m.Contains("not valid JSON"),"invalid JSON explained");
        r.ReportInfo="["+infoWith("")+"]"; await Reject(async()=>{await service.ExecuteAsync(r,c);},"array instead of object");
        r.ReportInfo="   "; await Reject(async()=>{await service.ExecuteAsync(r,c);},"blank reportInfo");
        Check(client.Calls==calls,"nothing sent for malformed reportInfo");
        r.ReportInfo=null;

        // The strict parse refuses repeated names; the ordinary parse keeps its old behaviour (last value wins).
        var plain=(Dictionary<string,object>)FrpMapper.Shared.Json.JsonSerializer.Parse("{\"a\":1,\"a\":2}");
        Check(plain["a"].Equals(2m),"Parse: last value wins");
        try { FrpMapper.Shared.Json.JsonSerializer.ParseStrict("{\"a\":{\"b\":1,\"b\":2}}"); throw new Exception("FAILED: ParseStrict accepted a repeated name"); }
        catch (FrpMapper.Shared.Json.JsonException) { checks++; }
        Check(((Dictionary<string,object>)FrpMapper.Shared.Json.JsonSerializer.ParseStrict("{\"a\":{\"b\":1},\"b\":{\"b\":2}}")).Count==2,"ParseStrict: same name in different objects is fine");

        // Certificates: wrong password, no key, expired, wrong file type, .p12 accepted.
        r.Password="wrong"; await Reject(async()=>{await service.InspectAsync(r,c);},"wrong password"); r.Password="test-password";
        r.Certificate=Pfx(args[2],"nokey.pfx"); m=await Reject(async()=>{await service.InspectAsync(r,c);},"PFX without private key"); Check(m.Contains("private key"),"no key explained");
        r.Certificate=Pfx(args[3],"expired.pfx"); m=await Reject(async()=>{await service.InspectAsync(r,c);},"expired"); Check(m.Contains("expired"),"expiry explained");
        r.Certificate=Pfx(args[0],"uni.cer"); await Reject(async()=>{await service.InspectAsync(r,c);},"not a PFX file name");
        r.Certificate=Pfx(args[0],"uni.p12"); Check((await service.InspectAsync(r,c)).Name=="SandboxTest UNI",".p12 accepted");
        r.Certificate=null; await Reject(async()=>{await service.InspectAsync(r,c);},"no certificate");
        r.Certificate=Pfx(args[0],"uni.pfx");

        // BSP unreachable: the person is told the outcome is unknown, and the attempt and its failure are audited.
        client.Throw=new HttpRequestException("down"); var before=audit.Entries.Count;
        m=await Reject(async()=>{await service.ExecuteAsync(r,c);},"BSP down"); Check(m.Contains("unknown"),"unknown outcome explained");
        Check(audit.Entries.Count==before+2 && audit.Entries.Last().Action=="sandbox.submit.result","failure audited");
        client.Throw=null;
        // The outcome cannot be audited: BSP's answer (the submission ID) is still returned, and the failure is logged.
        audit.Fail=true; var answer=await service.ExecuteAsync(r,c); Check(answer.Body.Contains("submissionId") && log.Errors==1,"answer kept when outcome audit fails"); audit.Fail=false;

        // Unknown operation, permissions, proxy allowlist.
        r.Operation="production"; await Reject(async()=>{await service.ExecuteAsync(r,c);},"unknown operation");
        user.Allowed=false;
        await Reject(async()=>{await service.InspectAsync(r,c);},"unauthorized certificate");
        await Reject(async()=>{await service.ExecuteAsync(r,c);},"unauthorized send");
        await Reject(async()=>{await service.BanksAsync(c);},"unauthorized bank list");
        Check(ApiProxy.IsAllowed("POST","/api/sandbox/submit"),"proxy permits sandbox");
        Check(ApiProxy.IsAllowed("GET","/api/sandbox/banks"),"proxy permits bank list");
        Check(ApiProxy.IsAllowed("GET","/api/sandbox/environments") && !ApiProxy.IsAllowed("POST","/api/sandbox/environments"),"proxy permits reading the environments only");
        Check(!ApiProxy.IsAllowed("GET","/api/sandbox/submit"),"proxy rejects GET");
        Check(!ApiProxy.IsAllowed("POST","/api/sandbox/banks"),"proxy rejects POST bank list");
        Check(!ApiProxy.IsAllowed("POST","/api/sandbox/production"),"proxy rejects production");
        user.Allowed=true; r.Operation="submit"; r.Xml=new MemoryFormFile("file","report.xml",Encoding.UTF8.GetBytes("<!DOCTYPE x [<!ENTITY e SYSTEM 'file:///etc/passwd'>]><x>&e;</x>"));
        try { await service.ExecuteAsync(r,c);throw new Exception("DTD accepted"); } catch(System.Xml.XmlException) { checks++; }

        // Bank profiles: the BSP API undertaking code is optional, digits only, unique, and part of the change summary.
        user.Permission=Permissions.ReferenceManage;
        var reference=new ReferenceDataService(references,null,user,null,null,null,null);
        var uni=references.Data.Banks[0];
        var changed=await reference.RequestBankChangeAsync(uni.With(x=>{x.BspUndertakingCode=" 00000136 ";}),c);
        Check(changed.Proposed.BspUndertakingCode=="00000136" && changed.Summary.Contains("BSP API undertaking code: 00000135 → 00000136"),"code trimmed and summarised");
        await Reject(async()=>{await reference.RequestBankChangeAsync(uni.With(x=>{x.BspUndertakingCode="12A45678";}),c);},"letters in code");
        await Reject(async()=>{await reference.RequestBankChangeAsync(uni.With(x=>{x.BspUndertakingCode="04000476";}),c);},"code of another bank");
        var cleared=await reference.RequestBankChangeAsync(uni.With(x=>{x.BspUndertakingCode="  ";}),c);
        Check(cleared.Proposed.BspUndertakingCode==null,"blank code stored as none");
        var json=FrpMapper.Shared.Json.JsonSerializer.Serialize(uni);
        Check(json.Contains("\"BspUndertakingCode\":\"00000135\"") && FrpMapper.Shared.Json.JsonSerializer.Deserialize<BankProfileDto>(json).BspUndertakingCode=="00000135","profile JSON round trip");
        Check(FrpMapper.Shared.Json.JsonSerializer.Deserialize<BankProfileDto>("{\"Key\":\"RB\",\"ProviderCode\":\"0004000476\"}").BspUndertakingCode==null,"stored profiles without the code still read");

        // ---------- stored certificates ----------
        // Encryption: round trip, a different row / bank / key cannot open it, any changed byte is detected, no key configured.
        var pfx=File.ReadAllBytes(args[0]); string pw;
        var sealedPfx=protector.Protect(pfx,"test-password","0123456789abcdef0123456789abcdef","UNI");
        Check(!ContainsBytes(sealedPfx, Encoding.UTF8.GetBytes("test-password")) && !ContainsBytes(sealedPfx, pfx.Take(64).ToArray()),"stored bytes hold neither the password nor the PFX");
        Check(protector.Unprotect(sealedPfx,"0123456789abcdef0123456789abcdef","UNI",out pw).SequenceEqual(pfx) && pw=="test-password","encryption round trip");
        await Reject(()=>{ protector.Unprotect(sealedPfx,"0123456789abcdef0123456789abcdef","RB",out pw); return Task.FromResult(0); },"moved to another bank");
        await Reject(()=>{ protector.Unprotect(sealedPfx,"ffffffffffffffffffffffffffffffff","UNI",out pw); return Task.FromResult(0); },"moved to another row");
        await Reject(()=>{ Protector("another-protection-key-0123456789abcdef-012345").Unprotect(sealedPfx,"0123456789abcdef0123456789abcdef","UNI",out pw); return Task.FromResult(0); },"another key");
        for (var i=0;i<sealedPfx.Length;i+=Math.Max(1,sealedPfx.Length/40)) { var bad=(byte[])sealedPfx.Clone(); bad[i]^=1;
            try { protector.Unprotect(bad,"0123456789abcdef0123456789abcdef","UNI",out pw); throw new Exception("tampered byte "+i+" accepted"); } catch(WorkflowException) { } }
        checks++;
        Check(!protector.Protect(pfx,"x","0123456789abcdef0123456789abcdef","UNI").Take(17).SequenceEqual(protector.Protect(pfx,"x","0123456789abcdef0123456789abcdef","UNI").Take(17)),"a new IV each time");
        var unset=await Reject(()=>{ Protector(null).Protect(pfx,"x","a","b"); return Task.FromResult(0); },"no protection key"); Check(unset.Contains("Certificates:ProtectionKey"),"missing key explained");

        // Maker uploads, a different Checker approves; only details are listed.
        var maker=new User { UserName="CORP\\maker", Permission=Permissions.ReferenceManage };
        var checker=new User { UserName="CORP\\checker", Permission=Permissions.ReferenceApprove };
        var makerService=new BankCertificateService(certificates,references,protector,maker);
        var checkerService=new BankCertificateService(certificates,references,protector,checker);
        await Reject(async()=>{await checkerService.UploadAsync("UNI",Pfx(args[0],"uni.pfx"),"test-password",c);},"Checker uploads");
        await Reject(async()=>{await makerService.UploadAsync("UNI",Pfx(args[0],"uni.pfx"),"wrong",c);},"upload with wrong password");
        await Reject(async()=>{await makerService.UploadAsync("UNI",Pfx(args[3],"expired.pfx"),"test-password",c);},"upload expired");
        await Reject(async()=>{await makerService.UploadAsync("UNI",Pfx(args[2],"nokey.pfx"),"test-password",c);},"upload without key");
        await Reject(async()=>{await makerService.UploadAsync("XX",Pfx(args[0],"uni.pfx"),"test-password",c);},"upload for unknown bank");
        var uploaded=await makerService.UploadAsync("UNI",Pfx(args[0],"uni.pfx"),"test-password",c);
        Check(uploaded.Status=="Pending" && uploaded.Subject.Contains("SandboxTest UNI") && uploaded.Thumbprint.Length==40 && uploaded.FileName=="uni.pfx" && uploaded.RequestedBy=="CORP\\maker","upload stored as Pending with its details");
        Check(protector.Unprotect(certificates.Blobs[uploaded.Id],uploaded.Id,"UNI",out pw).SequenceEqual(pfx) && pw=="test-password","stored encrypted, bound to its row and bank");
        await Reject(async()=>{await makerService.UploadAsync("UNI",Pfx(args[0],"uni.pfx"),"test-password",c);},"second upload while one waits");
        user.Allowed=true; user.Permission=Permissions.SubmissionPrepare;
        Check((await service.BanksAsync(c)).Single(x=>x.Key=="UNI").StoredCertificate==null,"not offered before approval");
        var decision=new AccessDecisionRequest { Version=uploaded.Version };
        await Reject(async()=>{await makerService.DecideAsync(uploaded.Id,"approve",decision,c);},"Maker approves");
        await Reject(async()=>{await checkerService.DecideAsync(uploaded.Id,"reject",decision,c);},"reject without reason");
        await Reject(async()=>{await checkerService.DecideAsync(uploaded.Id,"cancel",decision,c);},"Checker cancels someone else's upload");
        await Reject(async()=>{await checkerService.DecideAsync(uploaded.Id,"publish",decision,c);},"unknown decision");
        Check(!await checkerService.DecideAsync("ffffffffffffffffffffffffffffffff","approve",decision,c),"unknown certificate");
        var both=new User { UserName="CORP\\maker", Permission=Permissions.ReferenceApprove };
        await Reject(async()=>{await new BankCertificateService(certificates,references,protector,both).DecideAsync(uploaded.Id,"approve",decision,c);},"uploader approves own certificate");
        Check(await checkerService.DecideAsync(uploaded.Id,"approve",decision,c) && certificates.Rows.Single(x=>x.Id==uploaded.Id).Status=="Active","approved by another person");
        Check((await makerService.ListAsync(c)).Single().Thumbprint==uploaded.Thumbprint,"Makers see the details");
        await Reject(async()=>{await new BankCertificateService(certificates,references,protector,user).ListAsync(c);},"others cannot list");

        // BSP submission uses the stored certificate: no file, no password.
        var stored=(await service.BanksAsync(c)).Single(x=>x.Key=="UNI").StoredCertificate;
        Check(stored!=null && stored.Thumbprint==uploaded.Thumbprint && stored.ValidUntil.EndsWith("Z"),"offered to BSP submission");
        Check((await service.BanksAsync(c)).Single(x=>x.Key=="RB").StoredCertificate==null,"only for its own bank");
        var viaStored=new SandboxRequest { Operation="submit", Environment="SANDBOX", UseStoredCertificate=true, BankKey="UNI", ReportCode="FRP_CONSO", Period="2026-09", Xml=Xml(UniXml) };
        Check((await service.InspectAsync(viaStored,c)).Name=="SandboxTest UNI","stored certificate opens");
        before=audit.Entries.Count; await service.ExecuteAsync(viaStored,c);
        Check(client.Subject.Contains("SandboxTest UNI") && audit.Entries[before].Details.Contains("(stored for bank UNI)"),"submitted with the stored certificate, audited as such");
        viaStored.Operation="status"; viaStored.SubmissionId="7735089b-81d6-405e-8e67-255338dbce9a"; await service.ExecuteAsync(viaStored,c);
        Check(client.Path.EndsWith("/status") && client.Subject.Contains("SandboxTest UNI"),"status with the stored certificate");
        viaStored.BankKey="RB"; m=await Reject(async()=>{await service.ExecuteAsync(viaStored,c);},"bank without stored certificate"); Check(m.Contains("no approved certificate"),"missing stored certificate explained");
        viaStored.BankKey=null; await Reject(async()=>{await service.ExecuteAsync(viaStored,c);},"stored without bank");
        // A replacement, then removal.
        var second=await makerService.UploadAsync("UNI",Pfx(args[1],"rb.pfx"),"",c);
        await checkerService.DecideAsync(second.Id,"approve",new AccessDecisionRequest{Version=second.Version},c);
        Check(certificates.Rows.Single(x=>x.Id==uploaded.Id).Status=="Replaced" && certificates.Rows.Single(x=>x.Id==second.Id).Status=="Active","replacement replaces");
        await Reject(async()=>{await checkerService.DecideAsync(second.Id,"remove",new AccessDecisionRequest{Version=second.Version},c);},"remove without reason");
        Check(await checkerService.DecideAsync(second.Id,"remove",new AccessDecisionRequest{Version=second.Version,Comment="expired at BSP"},c) && (await service.BanksAsync(c)).Single(x=>x.Key=="UNI").StoredCertificate==null,"removed");
        Check(ApiProxy.IsAllowed("GET","/api/reference/certificates") && ApiProxy.IsAllowed("POST","/api/reference/certificates") && ApiProxy.IsAllowed("POST","/api/reference/certificates/"+second.Id+"/remove")
            && !ApiProxy.IsAllowed("GET","/api/reference/certificates/"+second.Id) && !ApiProxy.IsAllowed("POST","/api/reference/certificates/"+second.Id+"/download"),"proxy: certificate details and decisions only, never a download");
    }

    static bool ContainsBytes(byte[] haystack, byte[] needle) {
        for (var i=0;i+needle.Length<=haystack.Length;i++) { var j=0; while (j<needle.Length && haystack[i+j]==needle[j]) j++; if (j==needle.Length) return true; }
        return false;
    }
}
