// Tests of the mapped template export (OpenXmlMappedTemplateWriter through FrpMappingService.ExportMappedTemplateAsync):
// what Excel needs to open the workbook without repairing it. Every uniqueName in a singleXmlCells part and in an XML
// table is different, singleXmlCell ids are unique in the workbook, and every XML binding names the workbook's XML map.
// Arguments: <XSD> [<BSP specification .xlsx>]. The template is generated from the XSD, as for "Generate the template". Use an
// XSD whose forms repeat field names across their tables on one sheet (e.g. FRP v16.0: FRP_1 MAIN and ADD1 both have R0020C0010).
// It uses the in-memory project store of ProjectEditTests.cs: compile both, with this one as the entry point
// (csc /main:MappedTemplateTests MappedTemplateTests.cs ProjectEditTests.cs ...).
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading;
using System.Xml.Linq;
using FrpMapper.Api.BL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

static class MappedTemplateTests
{
    static int checks;
    static void Check(bool ok, string what) { if (!ok) throw new Exception("FAILED: " + what); checks++; Console.WriteLine("ok: " + what); }
    static IFormFile Upload(string path) { var bytes = File.ReadAllBytes(path); return new FormFile(new MemoryStream(bytes), 0, bytes.Length, "file", Path.GetFileName(path)); }
    static readonly XNamespace Sml = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

    static int Main(string[] args)
    {
        var repo = new EditRepo(); var files = new EditFiles(); var audit = new EditAudit();
        var inspector = new OpenXmlWorkbookInspector(); var writer = new XmlSubmissionWriter();
        var specReader = new BspSpecificationReader(inspector);
        var solver = new BspSampleValueSolver(new BspAssertionEvaluator(), writer, new BspDerivedValues());
        var options = new FixedOptions<FileStorageOptions>(new FileStorageOptions { MaxUploadMegabytes = 50,
            AllowedExtensions = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
            { { UploadKinds.Xsd, new List<string> { ".xsd" } }, { UploadKinds.Template, new List<string> { ".xlsx", ".xlsm" } }, { UploadKinds.Specification, new List<string> { ".xlsx" } } } });
        var specValidator = new BspSpecificationValidator(specReader, new BspAssertionEvaluator(), new BankReferenceContext(), new BspDerivedValues());
        var maker = new EditUser { Name = "maker1", Granted = new[] { Permissions.ProjectRead, Permissions.ProjectCreate, Permissions.ProjectEdit } };
        var service = new FrpMappingService(repo, new ProjectAccess(repo, maker), new BankReferenceContext(), new XsdSchemaParser(), inspector,
            new MappingSuggestionEngine(), writer, new OpenXmlMappedTemplateWriter(), new XsdValidationService(),
            new XsdProjectValidator(writer, specValidator), specReader, specValidator, null, new XsdInputTemplateGenerator(), solver, new SampleValueRefill(specReader, solver), maker, audit, files, new UploadRules(options, files),
            null, null, new NoLog<FrpMappingService>(), new ProjectReadCache());
        var project = service.AnalyzeAsync("Template export", Upload(args[0]), null, args.Length > 1 ? Upload(args[1]) : null, null, CancellationToken.None).Result;
        Check(project.TemplateGenerated && project.Mappings.Count > 0, "project with a generated template");

        foreach (var values in new[] { ExportValues.Blank, ExportValues.Mapped, ExportValues.Sample })
        {
            var export = service.ExportMappedTemplateAsync(project.Id, values, CancellationToken.None).Result.Value;
            using (var zip = new ZipArchive(new MemoryStream(export.Bytes), ZipArchiveMode.Read))
            {
                Func<string, XDocument> read = name => { using (var s = zip.GetEntry(name).Open()) return XDocument.Load(s); };
                var mapIds = read("xl/xmlMaps.xml").Root.Elements(Sml + "Map").Select(m => (string)m.Attribute("ID")).ToList();
                var parts = zip.Entries.Where(e => e.FullName.StartsWith("xl/tables/") && e.FullName.EndsWith(".xml")).Select(e => read(e.FullName)).ToList();
                var singles = parts.Where(p => p.Root.Name == Sml + "singleXmlCells").ToList();
                var tables = parts.Where(p => p.Root.Name == Sml + "table").ToList();
                Check(singles.Count > 0 && tables.Count > 0, values + ": single-cell bindings and XML tables written");

                var repeatedSingle = singles.SelectMany(p => p.Root.Descendants(Sml + "xmlCellPr").Select(c => (string)c.Attribute("uniqueName"))
                    .GroupBy(n => n, StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1).Select(g => g.Key)).FirstOrDefault();
                Check(repeatedSingle == null, values + ": every uniqueName in a singleXmlCells part is different" + (repeatedSingle == null ? "" : " (repeated: " + repeatedSingle + ")"));
                var repeatedColumn = tables.SelectMany(t => t.Root.Descendants(Sml + "tableColumn").Select(c => (string)c.Attribute("uniqueName"))
                    .GroupBy(n => n, StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1).Select(g => g.Key)).FirstOrDefault();
                Check(repeatedColumn == null, values + ": every uniqueName in an XML table is different");
                var cellIds = singles.SelectMany(p => p.Root.Elements(Sml + "singleXmlCell").Select(c => (string)c.Attribute("id"))).ToList();
                Check(cellIds.Count == cellIds.Distinct().Count(), values + ": singleXmlCell ids are unique in the workbook");
                var refs = singles.SelectMany(p => p.Root.Descendants(Sml + "xmlPr")).Concat(tables.SelectMany(t => t.Root.Descendants(Sml + "xmlColumnPr")))
                    .Select(x => (string)x.Attribute("mapId")).Distinct().ToList();
                Check(refs.All(mapIds.Contains), values + ": every binding names the workbook's XML map");
                var xpaths = singles.SelectMany(p => p.Root.Descendants(Sml + "xmlPr")).Concat(tables.SelectMany(t => t.Root.Descendants(Sml + "xmlColumnPr")))
                    .Select(x => (string)x.Attribute("xpath")).ToList();
                Check(xpaths.Count == xpaths.Distinct().Count(), values + ": every XML element is bound once");
            }
        }

        Console.WriteLine("MappedTemplateTests: " + checks + " checks passed");
        return 0;
    }
}
