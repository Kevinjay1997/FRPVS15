// Tests of editing a project (FrpMappingService.RenameAsync / ReplaceFilesAsync): rename; replace the XSD, the Excel
// template (its own cells or the person's), generate the template, add / remove the specification; what is carried over
// (mappings, entered and emptied values, sheet copies) and what is reported; who may do it, and when.
// Arguments: <CAR template .xlsx> <CAR XSD> <a different template .xlsx (used as a "specification" workbook)>
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Api.BL;
using FrpMapper.Api.Contracts.DAL;
using FrpMapper.Api.Hosting;
using FrpMapper.Api.Models;
using FrpMapper.Api.Security;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

class EditUser : ICurrentUser
{
    public string Name { get; set; }
    public string[] Granted { get; set; }
    public bool IsAuthenticated => true;
    public bool HasPermission(string p) => Granted.Contains(p);
    public IReadOnlyList<string> Roles => new string[0];
    public IReadOnlyList<string> Permissions => Granted;
}

/// <summary>Projects in memory, with versions (as the stored procedures check them).</summary>
class EditRepo : IProjectRepository
{
    public Dictionary<string, FrpProjectDto> Projects = new Dictionary<string, FrpProjectDto>();
    public int Replaced, Renamed;
    long version = 1;
    byte[] Next() => BitConverter.GetBytes(++version);
    void Check(FrpProjectDto p)
    {
        FrpProjectDto current;
        if (!Projects.TryGetValue(p.Id, out current)) throw new InvalidOperationException("no such project");
        if (!current.Version.SequenceEqual(p.Version)) throw new ConcurrencyConflictException("changed");
        if (current.Workflow.Status != ProjectStatus.Draft && current.Workflow.Status != ProjectStatus.Returned) throw new ProjectNotEditableException("not editable");
    }
    public FrpProjectDto Add(FrpProjectDto p) { p = p.With(c => { c.Version = Next(); }); Projects[p.Id] = p; return p; }
    public Task<FrpProjectDto> GetAsync(string id, CancellationToken c) { FrpProjectDto p; return Task.FromResult(Projects.TryGetValue(id, out p) ? p : null); }
    public Task<IReadOnlyList<ProjectSummaryDto>> ListAsync(CancellationToken c) => Task.FromResult<IReadOnlyList<ProjectSummaryDto>>(Projects.Values.Select(p => new ProjectSummaryDto { Id = p.Id, Name = p.Name, UpdatedAt = p.UpdatedAt, CreatedBy = p.Workflow.CreatedBy, Status = p.Workflow.Status }).ToList());
    public Task<FrpProjectDto> RenameAsync(FrpProjectDto p, CancellationToken c) { Check(p); Renamed++; var keep = Projects[p.Id]; p = keep.With(k => { k.Name = p.Name; k.UpdatedAt = p.UpdatedAt; k.Workflow = p.Workflow; k.Version = Next(); }); Projects[p.Id] = p; return Task.FromResult(p); }
    public Task<FrpProjectDto> ReplaceSourcesAsync(FrpProjectDto p, CancellationToken c) { Check(p); Replaced++; p = p.With(k => { k.Version = Next(); }); Projects[p.Id] = p; return Task.FromResult(p); }
    public Task<IReadOnlyList<ProjectSummaryDto>> FindByFilesAsync(string by, string xsd, string template, string spec, CancellationToken c) =>
        Task.FromResult<IReadOnlyList<ProjectSummaryDto>>(Projects.Values.Where(p => p.Workflow.CreatedBy == by && p.XsdFile.Sha256 == xsd
            && (p.TemplateGenerated || p.TemplateFile == null ? ProjectFileKeys.None : p.TemplateFile.Sha256) == template
            && (p.SpecificationFile == null ? ProjectFileKeys.None : p.SpecificationFile.Sha256) == spec)
            .Select(p => new ProjectSummaryDto { Id = p.Id, Name = p.Name, RootElement = p.RootElement, Status = p.Workflow.Status }).ToList());
    public Task<IDisposable> LockAsync(string id, CancellationToken c) => Task.FromResult<IDisposable>(new Gate());
    public Task<FrpProjectDto> CreateAsync(FrpProjectDto p, CancellationToken c) => Task.FromResult(Add(p));
    public Task<FrpProjectDto> SaveWorkflowAsync(FrpProjectDto p, CancellationToken c) { Check(p); p = p.With(k => { k.Version = Next(); }); Projects[p.Id] = p; return Task.FromResult(p); }
    public Task<FrpProjectDto> SaveMappingsAsync(FrpProjectDto p, CancellationToken c) => SaveWorkflowAsync(p, c);
    public Task<FrpProjectDto> SaveSampleValuesAsync(FrpProjectDto p, CancellationToken c) => SaveWorkflowAsync(p, c);
    public Task<FrpProjectDto> SaveSheetSplitsAsync(FrpProjectDto p, CancellationToken c) => SaveWorkflowAsync(p, c);
    public Task<ProjectUploads> GetUploadsAsync(string id, CancellationToken c) { throw new NotImplementedException(); }
    public Task<bool> DeleteAsync(string id, byte[] v, string by, DateTimeOffset at, CancellationToken c) { throw new NotImplementedException(); }
    sealed class Gate : IDisposable { public void Dispose() { } }
}

/// <summary>Uploads stored once by content in a temporary folder (as ProjectFileStore).</summary>
class EditFiles : IProjectFileStore
{
    public string Root = Path.Combine(Path.GetTempPath(), "frp-edit-" + Guid.NewGuid().ToString("N"));
    public async Task<StoredUpload> StoreUploadAsync(IFormFile file, CancellationToken c)
    {
        Directory.CreateDirectory(Root);
        var bytes = new MemoryStream(); using (var s = file.OpenReadStream()) await s.CopyToAsync(bytes);
        var sha = BitConverter.ToString(SHA256.Create().ComputeHash(bytes.ToArray())).Replace("-", "").ToLowerInvariant();
        var path = Path.Combine(Root, sha + Path.GetExtension(file.FileName));
        var reused = File.Exists(path); if (!reused) File.WriteAllBytes(path, bytes.ToArray());
        return new StoredUpload(path, sha, reused);
    }
    public bool IsUploadStored(string sha256, string extension) => false;
    public Task<string> SaveFileAsync(string projectId, string fileName, byte[] content, CancellationToken c) { var d = Path.Combine(Root, projectId); Directory.CreateDirectory(d); var p = Path.Combine(d, fileName); File.WriteAllBytes(p, content); return Task.FromResult(p); }
    public string ToStoredPath(string fullPath) => fullPath;
    public string ToFullPath(string storedPath) => storedPath;
    public string GetProjectDirectory(string projectId) => Path.Combine(Root, projectId);
}

class EditAudit : IAuditLog
{
    public List<AuditEntryDto> Entries = new List<AuditEntryDto>();
    public Task AppendAsync(AuditEntryDto entry, CancellationToken c) { Entries.Add(entry); return Task.FromResult(0); }
    public Task<IReadOnlyList<AuditEntryDto>> QueryAsync(string projectId, int take, CancellationToken c) { throw new NotImplementedException(); }
    public Task<IReadOnlyList<AuditEntryDto>> QueryByUserAsync(string userName, int take, CancellationToken c) { throw new NotImplementedException(); }
    public Task<AuditPageDto> QueryPageAsync(string projectId, string search, string action, int skip, int take, CancellationToken c) { throw new NotImplementedException(); }
}

class NoLog<T> : ILogger<T> { public bool IsEnabled(LogLevel level) => false; public void Log(LogLevel level, Exception exception, string message) { } }

static class ProjectEditTests
{
    static int checks;
    static void Check(bool ok, string what) { if (!ok) throw new Exception("FAILED: " + what); checks++; Console.WriteLine("ok: " + what); }
    static T Throws<T>(Func<object> action) where T : Exception
    {
        try { action(); }
        catch (AggregateException ex) when (ex.InnerException is T) { return (T)ex.InnerException; }
        catch (T ex) { return ex; }
        throw new Exception("FAILED: expected " + typeof(T).Name);
    }

    static IFormFile Upload(string path, string name) { var bytes = File.ReadAllBytes(path); return new FormFile(new MemoryStream(bytes), 0, bytes.Length, "file", name); }
    static IFormFile Upload(byte[] bytes, string name) => new FormFile(new MemoryStream(bytes), 0, bytes.Length, "file", name);

    static int Main(string[] args)
    {
        var templatePath = args[0]; var xsdPath = args[1]; var otherWorkbook = args[2];
        var repo = new EditRepo(); var files = new EditFiles(); var audit = new EditAudit();
        var inspector = new OpenXmlWorkbookInspector();
        var writer = new XmlSubmissionWriter();
        var specReader = new BspSpecificationReader(inspector);
        var solver = new BspSampleValueSolver(new BspAssertionEvaluator(), writer, new BspDerivedValues());
        var options = new FixedOptions<FileStorageOptions>(new FileStorageOptions
        {
            MaxUploadMegabytes = 50,
            AllowedExtensions = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
            { { UploadKinds.Xsd, new List<string> { ".xsd" } }, { UploadKinds.Template, new List<string> { ".xlsx", ".xlsm" } }, { UploadKinds.Specification, new List<string> { ".xlsx" } } }
        });
        var specValidator = new BspSpecificationValidator(specReader, new BspAssertionEvaluator(), new BankReferenceContext(), new BspDerivedValues());
        Func<EditUser, FrpMappingService> service = user => new FrpMappingService(repo, new ProjectAccess(repo, user), new BankReferenceContext(), new XsdSchemaParser(), inspector,
            new MappingSuggestionEngine(), writer, null, new XsdValidationService(),
            new XsdProjectValidator(writer, specValidator), specReader, specValidator, null, new XsdInputTemplateGenerator(), solver, new SampleValueRefill(specReader, solver), user, audit, files, new UploadRules(options, files),
            null, null, new NoLog<FrpMappingService>(), new ProjectReadCache());
        var maker = new EditUser { Name = "maker1", Granted = new[] { Permissions.ProjectRead, Permissions.ProjectCreate, Permissions.ProjectEdit } };
        var checker = new EditUser { Name = "checker1", Granted = new[] { Permissions.ProjectRead, Permissions.ProjectReadAll, Permissions.SubmissionReview } };
        var stranger = new EditUser { Name = "maker2", Granted = new[] { Permissions.ProjectRead, Permissions.ProjectEdit } };

        // A CAR project, as the Maker left it: values entered, one emptied, one field unmapped, one cell moved, a sheet copy, an attached XML.
        var created = service(maker).AnalyzeAsync("CAR April", Upload(xsdPath, "CAR.xsd"), Upload(templatePath, "CAR_template.xlsx"), null, null, CancellationToken.None).Result;
        var id = created.Id;
        var nodes = created.SchemaNodes.Where(n => n.DataType != "complex").ToDictionary(n => n.Path, StringComparer.OrdinalIgnoreCase);
        Func<string, MappingEntryDto> at = suffix => repo.Projects[id].Mappings.First(m => m.SchemaPath.EndsWith(suffix, StringComparison.OrdinalIgnoreCase));
        var typed = at("/CAR_Part_II/MAIN/R0040C0030"); var gone = at("/CAR_Part_II/MAIN/R0060C0030"); var emptied = at("/CAR_Part_II/MAIN/R0070C0030");
        var unmapped = repo.Projects[id].Mappings.First(m => m.SchemaPath != typed.SchemaPath && m.SchemaPath != gone.SchemaPath && m.SchemaPath != emptied.SchemaPath && m.SheetName == typed.SheetName);
        var moved = repo.Projects[id].Mappings.Last(m => m.SheetName == typed.SheetName && m.SchemaPath != unmapped.SchemaPath && m.SchemaPath != typed.SchemaPath && m.SchemaPath != gone.SchemaPath && m.SchemaPath != emptied.SchemaPath);
        var mine = repo.Projects[id].Mappings.Where(m => m.SchemaPath != unmapped.SchemaPath)
            .Select(m => m.SchemaPath == typed.SchemaPath ? m.With(c => { c.DefaultValue = "1234.5"; })
                : m.SchemaPath == gone.SchemaPath ? m.With(c => { c.DefaultValue = "99"; })
                : m.SchemaPath == emptied.SchemaPath ? m.With(c => { c.DefaultValue = ""; })
                : m.SchemaPath == moved.SchemaPath ? m.With(c => { c.CellAddress = "ZZ900"; c.Source = "Manual"; })
                : m).ToList();
        service(maker).UpdateMappingsAsync(id, mine, CancellationToken.None).Wait();
        var split = created.SchemaNodes.Where(n => n.IsRepeating).Select(g => new { g, key = created.SchemaNodes.FirstOrDefault(k => k.ParentPath == g.Path && k.DataType != "complex") }).First(x => x.key != null);
        repo.Projects[id] = repo.Projects[id].With(c =>
        {
            c.SheetSplits = new List<SheetSplitDto> { new SheetSplitDto { GroupPath = split.g.Path, KeyPath = split.key.Path, Values = new List<string> { "PHP", "USD" } } };
            c.Workflow = c.Workflow.With(w => { w.Submission = new SubmissionFileDto { FileName = "car.xml", Sha256 = new string('a', 64) }; });
        });
        var before = repo.Projects[id];
        Check(before.Mappings.Any(m => m.SchemaPath == typed.SchemaPath && m.DefaultValue == "1234.5"), "set up: a typed value, an emptied value, a moved cell, an unmapped field, a sheet copy, an attached XML");

        // ---------- rename ----------
        var renamed = service(maker).RenameAsync(id, "  CAR May  ", CancellationToken.None).Result;
        Check(renamed.Name == "CAR May" && repo.Renamed == 1 && audit.Entries.Last().Action == "Project renamed" && audit.Entries.Last().Details.Contains("\"CAR April\" renamed to \"CAR May\""), "rename: trimmed, saved and audited");
        Check(service(maker).RenameAsync(id, "CAR May", CancellationToken.None).Result.Name == "CAR May" && repo.Renamed == 1, "the same name again saves nothing");
        Check(Throws<WorkflowException>(() => service(maker).RenameAsync(id, "   ", CancellationToken.None).Result).Kind == WorkflowErrorKind.Invalid, "an empty name is refused");
        Check(Throws<WorkflowException>(() => service(maker).RenameAsync(id, new string('x', 201), CancellationToken.None).Result).Kind == WorkflowErrorKind.Invalid, "a name over 200 characters is refused");
        Check(Throws<WorkflowException>(() => service(maker).RenameAsync(id, "a\nb", CancellationToken.None).Result).Kind == WorkflowErrorKind.Invalid, "a name with a line break is refused");
        Check(Throws<WorkflowException>(() => service(checker).RenameAsync(id, "x", CancellationToken.None).Result).Kind == WorkflowErrorKind.Forbidden, "a Checker cannot rename");
        Check(service(stranger).RenameAsync(id, "x", CancellationToken.None).Result == null, "another Maker's draft reads as not found");
        Check(service(maker).RenameAsync("../x", "x", CancellationToken.None).Result == null, "a bad id reads as not found");

        // ---------- what cannot be asked ----------
        Func<ProjectFilesEdit, ProjectEditResultDto> replace = e => service(maker).ReplaceFilesAsync(id, e, CancellationToken.None).Result;
        var replacedBefore = repo.Replaced;
        Check(Throws<WorkflowException>(() => replace(new ProjectFilesEdit())).Message.Contains("Choose a file"), "nothing chosen is refused");
        Check(Throws<WorkflowException>(() => replace(new ProjectFilesEdit { GenerateTemplate = true, TemplateFile = Upload(templatePath, "t.xlsx") })).Kind == WorkflowErrorKind.Invalid, "a new template and a generated one together are refused");
        Check(Throws<WorkflowException>(() => replace(new ProjectFilesEdit { RemoveSpecification = true })).Message.Contains("no BSP specification"), "removing a specification the project does not have is refused");
        Check(Throws<WorkflowException>(() => replace(new ProjectFilesEdit { XsdFile = Upload(templatePath, "car.xlsx") })).Message.Contains(".xsd"), "an XSD that is not a .xsd file is refused");
        Check(Throws<WorkflowException>(() => replace(new ProjectFilesEdit { TemplateFile = Upload(templatePath, "same.xlsx") })).Message.Contains("already uses"), "the same template again changes nothing (refused)");
        Check(Throws<WorkflowException>(() => service(checker).ReplaceFilesAsync(id, new ProjectFilesEdit { GenerateTemplate = true }, CancellationToken.None).Result).Kind == WorkflowErrorKind.Forbidden, "a Checker cannot replace files");
        Check(service(stranger).ReplaceFilesAsync(id, new ProjectFilesEdit { GenerateTemplate = true }, CancellationToken.None).Result == null, "another Maker's draft reads as not found");
        Check(repo.Replaced == replacedBefore, "refused requests save nothing");

        // ---------- a new template: the template's own cells, entered values kept ----------
        var changedTemplate = TemplateCopy(templatePath);
        before = repo.Projects[id];
        var r1 = replace(new ProjectFilesEdit { TemplateFile = Upload(changedTemplate, "CAR_template_v2.xlsx") });
        var p1 = repo.Projects[id];
        Func<FrpProjectDto, string, MappingEntryDto> map = (p, path) => p.Mappings.FirstOrDefault(m => string.Equals(m.SchemaPath, path, StringComparison.OrdinalIgnoreCase));
        Check(r1.Summary.FilesReplaced.SequenceEqual(new[] { "Excel template" }) && p1.TemplateFile.OriginalName == "CAR_template_v2.xlsx" && p1.TemplateFile.Sha256 != before.TemplateFile.Sha256, "new template: stored and used (" + string.Join(", ", r1.Summary.FilesReplaced) + ")");
        Check(p1.Id == id && p1.Name == "CAR May" && p1.CreatedAt == before.CreatedAt && p1.Workflow.CreatedBy == "maker1", "the project keeps its id, name, creation and creator");
        Check(map(p1, typed.SchemaPath).DefaultValue == "1234.5" && map(p1, gone.SchemaPath).DefaultValue == "99", "entered values are kept");
        Check(map(p1, emptied.SchemaPath).DefaultValue == "", "an emptied value stays empty");
        Check(map(p1, moved.SchemaPath).CellAddress != "ZZ900", "the template's own cell is used for a moved field (" + map(p1, moved.SchemaPath).CellAddress + ")");
        Check(map(p1, unmapped.SchemaPath) != null, "with the template's cells, the field the person unmapped is mapped again");
        var sampleField = p1.Mappings.First(m => m.SchemaPath != typed.SchemaPath && m.SchemaPath != gone.SchemaPath && m.SchemaPath != emptied.SchemaPath);
        Check(sampleField.DefaultValue == p1.SchemaNodes.First(n => n.Path == sampleField.SchemaPath).TestValue, "other fields hold the new sample values");
        Check(r1.Summary.ValuesKept == 3 && r1.Summary.ValuesDropped == 0 && r1.Summary.MappingsFromTemplate > 0, $"summary: {r1.Summary.ValuesKept} values kept, {r1.Summary.MappingsFromTemplate} mappings from the template");
        Check(p1.Workflow.Submission == null && r1.Summary.SubmissionRemoved, "the XML attached for review is removed (made for the old files)");
        Check(p1.SheetSplits.Count == 1 && r1.Summary.SheetCopiesDropped == 0, "the sheet copy stays (its fields are still in the XSD)");
        Check(p1.Workflow.LastModifiedBy == "maker1" && p1.Validation != null, "touched by the Maker and validated again");
        var entry = audit.Entries.Last();
        Check(entry.Action == "Project files replaced" && entry.Details.Contains("template CAR_template.xlsx replaced by CAR_template_v2.xlsx") && entry.Details.Contains("3 entered value(s) kept"), "audited: " + entry.Details.Substring(0, Math.Min(140, entry.Details.Length)) + "…");

        // ---------- the same template again, keeping the person's cells ----------
        var mine2 = repo.Projects[id].Mappings.Select(m => m.SchemaPath == moved.SchemaPath ? m.With(c => { c.CellAddress = "ZZ901"; }) : m).ToList();
        service(maker).UpdateMappingsAsync(id, mine2, CancellationToken.None).Wait();
        var r2 = replace(new ProjectFilesEdit { TemplateFile = Upload(templatePath, "CAR_template.xlsx"), KeepCells = true });
        var p2 = repo.Projects[id];
        Check(map(p2, moved.SchemaPath).CellAddress == "ZZ901" && r2.Summary.MappingsKept == p2.Mappings.Count - r2.Summary.MappingsFromTemplate, "keep my cells: the moved cell stays (ZZ901)");
        Check(map(p2, typed.SchemaPath).DefaultValue == "1234.5", "and the values stay");

        // ---------- generate the template from the XSD ----------
        var r3 = replace(new ProjectFilesEdit { GenerateTemplate = true });
        var p3 = repo.Projects[id];
        Check(p3.TemplateGenerated && File.Exists(p3.TemplateFile.StoredPath) && r3.Summary.FilesReplaced.SequenceEqual(new[] { "Excel template generated from the XSD" }), "generate the template: made and stored (" + Path.GetFileName(p3.TemplateFile.StoredPath) + ")");
        Check(map(p3, typed.SchemaPath).DefaultValue == "1234.5" && map(p3, emptied.SchemaPath).DefaultValue == "", "values carried into the generated template");
        Check(p3.Mappings.All(m => p3.Workbook.Sheets.Any(s => s.Name == m.SheetName)), "every mapping is on a sheet of the generated template");

        // ---------- a new XSD version: one field renamed (removed + added) ----------
        var xsdText = File.ReadAllText(xsdPath);
        var i = xsdText.IndexOf("name=\"R0060C0030\"", StringComparison.Ordinal);
        var newXsd = System.Text.Encoding.UTF8.GetBytes(xsdText.Substring(0, i) + "name=\"R9990C0030\"" + xsdText.Substring(i + "name=\"R0060C0030\"".Length));
        var r4 = replace(new ProjectFilesEdit { XsdFile = Upload(newXsd, "CAR_v2.xsd") });
        var p4 = repo.Projects[id];
        Check(r4.Summary.FilesReplaced.Contains("XSD") && p4.XsdFile.OriginalName == "CAR_v2.xsd", "new XSD: used (" + string.Join(", ", r4.Summary.FilesReplaced) + ")");
        Check(!p4.SchemaNodes.Any(n => n.Path == gone.SchemaPath) && p4.SchemaNodes.Any(n => n.Path.EndsWith("/CAR_Part_II/MAIN/R9990C0030")), "the XSD's fields are read again");
        Check(map(p4, gone.SchemaPath) == null && r4.Summary.FieldsRemovedCount == 1 && r4.Summary.FieldsRemoved[0] == gone.SchemaPath, "the removed field's mapping is dropped and named: " + r4.Summary.FieldsRemoved[0]);
        Check(r4.Summary.ValuesDropped == 1 && r4.Summary.ValuesKept == 2, "its entered value is reported as dropped (2 kept, 1 dropped)");
        Check(r4.Summary.FieldsAdded == 1 && map(p4, gone.SchemaPath.Replace("R0060C0030", "R9990C0030")) != null, "the new field is counted and mapped (generated template)");
        Check(audit.Entries.Last().Details.Contains("no longer in the XSD: " + gone.SchemaPath), "the audit names the removed field");

        // ---------- add and remove a specification ----------
        var r5 = replace(new ProjectFilesEdit { SpecificationFile = Upload(otherWorkbook, "spec.xlsx") });
        Check(r5.Summary.FilesReplaced.Contains("BSP specification added") && repo.Projects[id].SpecificationFile.OriginalName == "spec.xlsx", "a specification is added");
        var r6 = replace(new ProjectFilesEdit { RemoveSpecification = true });
        Check(r6.Summary.FilesReplaced.Contains("BSP specification removed") && repo.Projects[id].SpecificationFile == null, "and removed again");
        Check(map(repo.Projects[id], typed.SchemaPath).DefaultValue == "1234.5", "entered values survive every change");

        // ---------- rules ----------
        // The same files as another of the creator's projects.
        var other = service(maker).AnalyzeAsync("CAR other", Upload(xsdPath, "CAR.xsd"), Upload(templatePath, "CAR_template.xlsx"), null, null, CancellationToken.None).Result;
        var dup = Throws<WorkflowException>(() => service(maker).ReplaceFilesAsync(id, new ProjectFilesEdit { XsdFile = Upload(xsdPath, "CAR.xsd"), TemplateFile = Upload(templatePath, "CAR_template.xlsx") }, CancellationToken.None).Result);
        Check(dup.Kind == WorkflowErrorKind.Conflict && dup.Message.Contains("CAR other"), "the same files as another of your projects are refused: " + dup.Message.Substring(0, 70) + "…");
        // A project in review cannot change.
        repo.Projects[other.Id] = repo.Projects[other.Id].With(c => { c.Workflow = c.Workflow.With(w => { w.Status = ProjectStatus.InReview; }); });
        var review = Throws<WorkflowException>(() => service(maker).ReplaceFilesAsync(other.Id, new ProjectFilesEdit { GenerateTemplate = true }, CancellationToken.None).Result);
        Check(review.Kind == WorkflowErrorKind.Conflict && review.Message.Contains("Withdraw"), "a project in review cannot change: " + review.Message);
        Check(Throws<WorkflowException>(() => service(maker).RenameAsync(other.Id, "x", CancellationToken.None).Result).Kind == WorkflowErrorKind.Conflict, "nor be renamed");
        // A stored file that changed on disk is not used.
        File.AppendAllText(repo.Projects[id].XsdFile.StoredPath, " ");
        var tampered = Throws<WorkflowException>(() => replace(new ProjectFilesEdit { SpecificationFile = Upload(otherWorkbook, "spec.xlsx") }));
        Check(tampered.Kind == WorkflowErrorKind.Conflict && tampered.Message.Contains("changed after it was uploaded"), "a stored XSD changed on disk is refused: " + tampered.Message);

        Directory.Delete(files.Root, true);
        Console.WriteLine("ProjectEditTests: " + checks + " checks passed");
        return 0;
    }

    /// <summary>The template with one more (ignored) part, so it is a different file with the same sheets and cells.</summary>
    static byte[] TemplateCopy(string path)
    {
        var bytes = File.ReadAllBytes(path);
        using (var memory = new MemoryStream())
        {
            memory.Write(bytes, 0, bytes.Length);
            using (var zip = new ZipArchive(memory, ZipArchiveMode.Update, true))
            using (var writer = new StreamWriter(zip.CreateEntry("docProps/frp-test.txt").Open()))
            {
                writer.Write("v2");
            }

            return memory.ToArray();
        }
    }
}
