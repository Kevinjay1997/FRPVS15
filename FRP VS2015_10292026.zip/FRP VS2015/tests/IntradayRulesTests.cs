// Tests of the INTRA (intraday liquidity) rules of the FRP v16.0 BSP specification, copied here as written there:
// the nested lists (INTRA_Item per currency, its LVPS / S1-S4 tables), ROW / FLOOR / COUNTIF / ISANYOF, and DAY / LASTDATE
// (the number of days in the reporting month). No arguments.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using FrpMapper.Api.BL;
using FrpMapper.Shared.Models;

static class IntradayRulesTests
{
    static int checks;
    static void Check(bool ok, string what) { if (!ok) throw new Exception("FAILED: " + what); checks++; Console.WriteLine("ok: " + what); }
    static readonly XNamespace Ns = "http://bsp.gov.ph/xml/FRP/16.0";
    static XElement E(string n, object v) => new XElement(Ns + n, v);

    static readonly BspAssertion[] Rules =
    {
        new BspAssertion("STG1-INTRA-S1-10AM", "", "$[R0100C0010]", "<=", "$[R0110C0010]", 0, "[INTRA][S1]", "", "Error"),
        new BspAssertion("STG1-INTRA-S1-6PM", "", "$[R0180C0010]", "<=", "1", 0, "[INTRA][S1]", "", "Error"),
        new BspAssertion("STG1-INTRA-S1-CALENDAR-DAYS", "", "$[R0030C0010]", "=",
            "IF(ISANYOF([Header][Period]; 4; 6; 9; 11)=FALSE;\nIF(ISANYOF([Header][Period]; 1; 3; 5; 7; 8; 10; 12)=FALSE;\nIF(ISANYOF([Header][Period]; 2) AND ISANYOF([Header][Year]; 2025; 2026; 2027; 2029; 2030; 2031; 2033; 2034; 2035; 2037; 2038; 2039; 2041; 2042; 2043; 2045; 2046; 2047; 2049; 2050; 2051; 2053; 2054);\nROW()-FLOOR((ROW()-1)/28)*28;\nROW()-FLOOR((ROW()-1)/29)*29);\nROW()-FLOOR((ROW()-1)/31)*31);\nROW()-FLOOR((ROW()-1)/30)*30)",
            0, "[INTRA][S1]", "", "Error"),
        new BspAssertion("STG1-INTRA-S1-TOTAL-DAYS", "", "$[R0030C0010]", "<=",
            "ROW()-FLOOR((ROW()-1)/\n(DAY(LASTDATE(\"M\";[Header][Year];[Header][Period]))))\n*\n(DAY(LASTDATE(\"M\";[Header][Year];[Header][Period])))", 0, "[INTRA][S1]", "", "Error"),
        new BspAssertion("STG1-INTRA-S2-CALENDAR-DAYS", "", "$[R0010C0010]", "=", "ROW()", 0, "[INTRA][S2]", "", "Error"),
        new BspAssertion("STG1-INTRA-S3-LVPS", "", "$[R0040C0010]", ">=", "$[R0050C0010]+\n$[R0060C0010]+\n$[R0070C0010]", 0, "[INTRA][S3]", "", "Error"),
        new BspAssertion("STG1-INTRA-LVPS-NAMES", "", "COUNTIF($0[LVPS]:$1; $1[R0010C0020]=$[R0010C0020])", "=", "1", 0, "[INTRA][LVPS]", "", "Error"),
        new BspAssertion("XREQ-INTRA-PHP", "", "COUNTIF([INTRA]:$1;($1[CURRENCY] = \"PHP\"))", ">", "0", 0, "[INTRA]", "", "Error"),
        new BspAssertion("XREQ-INTRA-PHP_LVPS", "", "COUNT($[LVPS])", "=", "1", 0, "[INTRA]", "$[CURRENCY]=\"PHP\"", "Error"),
    };

    static XDocument Report(int year, int month, int days, Action<XElement> change = null)
    {
        var item = new XElement(Ns + "INTRA_Item", E("CURRENCY", "PHP"),
            E("LVPS", E("LVPS_Item", E("R0010C0020", "PhilPaSS"))),
            E("S1", Enumerable.Range(1, days).Select(d => new XElement(Ns + "S1_Item", E("R0010C0010", 1), E("R0030C0010", d),
                Enumerable.Range(9, 10).Select(r => E("R" + (r * 10).ToString("0000") + "C0010", (0.1m * (r - 8)).ToString("0.0")))))),
            E("S2", Enumerable.Range(1, days).Select(d => new XElement(Ns + "S2_Item", E("R0010C0010", d)))),
            E("S3", Enumerable.Range(1, days).Select(d => new XElement(Ns + "S3_Item", E("R0010C0010", d), E("R0040C0010", 100), E("R0050C0010", 10), E("R0060C0010", 10), E("R0070C0010", 10)))));
        change?.Invoke(item);
        return new XDocument(new XElement(Ns + "FRP", new XElement(Ns + "Header", E("Undertaking", "1234567"), E("Year", year), E("Period", month)), new XElement(Ns + "INTRA", item)));
    }

    static Dictionary<string, string> Run(XDocument document)
    {
        var run = new BspAssertionEvaluator().Evaluate(Rules, document);
        return run.Outcomes.GroupBy(o => o.Assertion.Code).ToDictionary(g => g.Key, g =>
            g.Any(o => o.Status == BspRuleStatus.Failed) ? "Failed:" + g.Count(o => o.Status == BspRuleStatus.Failed)
            : g.Any(o => o.Status == BspRuleStatus.NotEvaluated) ? "NotEvaluated:" + g.First(o => o.Status == BspRuleStatus.NotEvaluated).Detail
            : g.Any(o => o.Status == BspRuleStatus.Passed) ? "Passed" : "NotApplicable");
    }

    static int Main()
    {
        // A correct December 2025 (31 days) and February 2025 (28) and 2024 (29, leap year).
        foreach (var month in new[] { new[] { 2025, 12, 31 }, new[] { 2025, 2, 28 }, new[] { 2024, 2, 29 }, new[] { 2025, 4, 30 } })
        {
            var result = Run(Report(month[0], month[1], month[2]));
            Check(result.Values.All(v => v == "Passed"), $"{month[0]}-{month[1]:00} ({month[2]} days): every INTRA rule is checked and passes [{string.Join(", ", result.Where(r => r.Value != "Passed").Select(r => r.Key + "=" + r.Value))}]");
        }

        // DAY / LASTDATE: a 31st day in a 30-day month fails the total-days rule (it used to be "not evaluated").
        var april = Run(Report(2025, 4, 30, item => item.Element(Ns + "S1").Elements().Last().Element(Ns + "R0030C0010").Value = "31"));
        Check(april["STG1-INTRA-S1-TOTAL-DAYS"] == "Failed:1", "day 31 in April fails STG1-INTRA-S1-TOTAL-DAYS (DAY(LASTDATE(\"M\"; 2025; 4)) = 30): " + april["STG1-INTRA-S1-TOTAL-DAYS"]);
        Check(april["STG1-INTRA-S1-CALENDAR-DAYS"] == "Failed:1", "and STG1-INTRA-S1-CALENDAR-DAYS");
        var feb = Run(Report(2024, 2, 29, item => item.Element(Ns + "S1").Elements().Last().Element(Ns + "R0030C0010").Value = "30"));
        Check(feb["STG1-INTRA-S1-TOTAL-DAYS"] == "Failed:1", "day 30 in February 2024 fails (29 days in a leap year)");

        // The other INTRA rules find errors inside the nested tables.
        var broken = Run(Report(2025, 12, 31, item =>
        {
            item.Element(Ns + "S1").Elements().ElementAt(4).Element(Ns + "R0100C0010").Value = "0.9";
            item.Element(Ns + "S1").Elements().ElementAt(5).Element(Ns + "R0180C0010").Value = "1.2";
            item.Element(Ns + "S2").Elements().ElementAt(6).Element(Ns + "R0010C0010").Value = "8";
            item.Element(Ns + "S3").Elements().ElementAt(2).Element(Ns + "R0050C0010").Value = "95";
            item.Element(Ns + "LVPS").Add(new XElement(Ns + "LVPS_Item", E("R0010C0020", "PhilPaSS")));
        }));
        Check(broken["STG1-INTRA-S1-10AM"] == "Failed:1", "S1: 10 AM above 11 AM on day 5 is found");
        Check(broken["STG1-INTRA-S1-6PM"] == "Failed:1", "S1: 6 PM throughput above 100% is found");
        Check(broken["STG1-INTRA-S2-CALENDAR-DAYS"] == "Failed:1", "S2: a wrong day number is found");
        Check(broken["STG1-INTRA-S3-LVPS"] == "Failed:1", "S3: parts above the total are found");
        Check(broken["STG1-INTRA-LVPS-NAMES"] == "Failed:2" && broken["XREQ-INTRA-PHP_LVPS"] == "Failed:1", "a repeated LVPS name and a second PHP LVPS are found");

        // No PHP currency.
        var usd = Run(Report(2025, 12, 31, item => item.Element(Ns + "CURRENCY").Value = "USD"));
        Check(usd["XREQ-INTRA-PHP"] == "Failed:1", "INTRA without PHP fails XREQ-INTRA-PHP");

        // LASTDATE kinds and bad input.
        var kinds = new BspAssertionEvaluator().Evaluate(new[]
        {
            new BspAssertion("Q", "", "DAY(LASTDATE(\"Q\"; 2025; 1))", "=", "31", 0, "", "", "Error"),
            new BspAssertion("Q-month", "", "DAY(LASTDATE(\"Q\"; 2025; 5))", "=", "30", 0, "", "", "Error"),
            new BspAssertion("Y", "", "DAY(LASTDATE(\"Y\"; 2025; 7))", "=", "31", 0, "", "", "Error"),
            new BspAssertion("bad-month", "", "DAY(LASTDATE(\"M\"; 2025; 13))", "=", "31", 0, "", "", "Error"),
            new BspAssertion("bad-date", "", "DAY(\"tomorrow\")", "=", "1", 0, "", "", "Error"),
        }, Report(2025, 12, 31));
        Func<string, BspRuleStatus> status = code => kinds.Outcomes.First(o => o.Assertion.Code == code).Status;
        Check(status("Q") == BspRuleStatus.Passed && status("Q-month") == BspRuleStatus.Passed && status("Y") == BspRuleStatus.Passed, "LASTDATE: quarter (Q1 ends 31 Mar; May's quarter ends 30 Jun) and year");
        Check(status("bad-month") == BspRuleStatus.NotEvaluated && status("bad-date") == BspRuleStatus.NotEvaluated, "a 13th month or a text that is not a date is reported as not evaluated, not as a failure");

        // The rules per form: INTRA shows up even when all its rules pass.
        var forms = BspSpecificationValidator.Forms(new BspAssertionEvaluator().Evaluate(Rules.Concat(new[]
        {
            new BspAssertion("HDR", "", "[Header][Year]", ">", "2000", 0, "", "", "Error"),
            new BspAssertion("RIN-INTRA-10", "", "DWHS(\"M-1\"; [FRP_BS][MAIN][R0040C0010])", "=", "VLOOKUP($0[S4]:$1;\n$1[R0020C0010]>0;\n$1[R0030C0010])", 10000, "[INTRA]", "($[CURRENCY]=\"PHP\")", "Error"),
            new BspAssertion("REQ-LEX_A-1", "", "ISNULL([LEX_A])", "=", "FALSE", 0, "", "", "Error"),
        }).ToList(), Report(2025, 12, 31)));
        var intra = forms.First(f => f.Form == "INTRA");
        Check(intra.Passed == 9 && intra.Failed == 0 && intra.NotEvaluated == 1, $"rules by form: INTRA {intra.Passed} passed, {intra.NotEvaluated} not evaluated (RIN-INTRA-10 counts under INTRA, its loop form, not FRP_BS)");
        Check(forms.Any(f => f.Form == "(report)" && f.Passed == 1) && forms.Last().Form == "(report)", "a Header-only rule counts under (report), listed last");
        Check(forms.Any(f => f.Form == "LEX_A" && f.Failed == 1), "a missing required form counts under that form");
        Check(BspSpecificationValidator.FormOf(new BspAssertion("x", "", "$1[R0010]", "=", "$[R0020]", 0, "", "", "Error")) == "(report)", "row variables ($1[..], $[..]) are not taken for forms");

        Console.WriteLine("IntradayRulesTests: " + checks + " checks passed");
        return 0;
    }
}
