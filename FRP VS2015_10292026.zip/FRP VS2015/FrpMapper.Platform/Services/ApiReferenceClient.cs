using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Platform.Hosting;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Platform.Services
{
    /// <summary>
    /// Reference data the Platform needs before or besides a person's own calls: roles, permissions and Active Directory
    /// groups (to sign people in), Development test users, and the upload limits. All of it comes from the API (the
    /// database and the API's settings) with the internal key only; roles and limits are cached for Access:CacheSeconds.
    /// </summary>
    public sealed class ApiReferenceClient
    {
        public const int SessionCheckSeconds = 20;

        private const string CatalogKey = "frp:platform:access-catalog";
        private const string FileSettingsKey = "frp:platform:file-settings";

        private readonly ApiConnection api;
        private readonly IMemoryCache cache;
        private readonly PlatformSettings settings;

        public ApiReferenceClient(ApiConnection api, IMemoryCache cache, PlatformSettings settings)
        {
            this.api = api;
            this.cache = cache;
            this.settings = settings;
        }

        public Task<AccessCatalogDto> GetCatalogAsync(CancellationToken cancellationToken)
        {
            return GetCachedAsync<AccessCatalogDto>(CatalogKey, "/api/access/catalog", cancellationToken);
        }

        public Task<FileSettingsDto> GetFileSettingsAsync(CancellationToken cancellationToken)
        {
            return GetCachedAsync<FileSettingsDto>(FileSettingsKey, "/api/files/settings", cancellationToken);
        }

        /// <summary>Test users for Development sign-in (never cached, so a change in the table shows at once).</summary>
        public Task<List<DevelopmentUserDto>> GetDevelopmentUsersAsync(CancellationToken cancellationToken)
        {
            return api.SendAsync<List<DevelopmentUserDto>>(api.ReferenceHttp, api.Create(HttpMethod.Get, "/api/access/development-users", null, null), cancellationToken);
        }

        /// <summary>Until when the account cannot sign in (an administrator delayed after failed sign-ins), or null.</summary>
        public async Task<DateTimeOffset?> GetSignInDelayAsync(string userName, string address, CancellationToken cancellationToken)
        {
            var result = await PostAsync<SignInCheckResultDto>("/api/access/sign-ins/check", new SignInCheckDto { UserName = userName }, address, cancellationToken);
            return result.DelayedUntil;
        }

        /// <summary>Records a failed sign-in (never the password); returns the outcome (failed, locked or delayed).</summary>
        public async Task<string> RecordSignInFailureAsync(SignInFailedDto failure, string address, CancellationToken cancellationToken)
        {
            return (await PostAsync<OutcomeResult>("/api/access/sign-ins/failed", failure, address, cancellationToken)).Outcome;
        }

        /// <summary>Records a sign-in refused before the password was checked (too many attempts).</summary>
        public Task RecordSignInBlockedAsync(SignInFailedDto blocked, string address, CancellationToken cancellationToken)
        {
            return PostAsync<object>("/api/access/sign-ins/blocked", blocked, address, cancellationToken);
        }

        /// <summary>A correct password: whether the person may sign in (locked, disabled, deactivated), and their previous sign-in.</summary>
        public Task<SignInResultDto> RecordSignInSuccessAsync(SignInSucceededDto success, string address, CancellationToken cancellationToken)
        {
            return PostAsync<SignInResultDto>("/api/access/sign-ins/succeeded", success, address, cancellationToken);
        }

        /// <summary>Whether this is still the account's newest session, checked at most every <see cref="SessionCheckSeconds"/> seconds.</summary>
        public async Task<bool> IsSessionCurrentAsync(string userName, string sessionId, CancellationToken cancellationToken)
        {
            var key = "frp:platform:session:" + userName + "|" + sessionId;
            bool current;
            if (cache.TryGetValue(key, out current))
            {
                return current;
            }

            current = (await PostAsync<SessionCheckResultDto>("/api/access/sign-ins/session", new SessionCheckDto { UserName = userName, SessionId = sessionId }, null, cancellationToken)).Current;
            cache.Set(key, current, TimeSpan.FromSeconds(SessionCheckSeconds));
            return current;
        }

        /// <summary>Sign-out: the API ends the session, so this cookie (or a copy of it) is refused from now on.</summary>
        public async Task EndSessionAsync(string userName, string sessionId, bool idle, string address, CancellationToken cancellationToken)
        {
            await PostAsync<object>("/api/access/sign-ins/ended", new SessionEndDto { UserName = userName, SessionId = sessionId, Idle = idle }, address, cancellationToken);
            cache.Remove("frp:platform:session:" + userName + "|" + sessionId);
        }

        private Task<T> PostAsync<T>(string path, object body, string address, CancellationToken cancellationToken)
        {
            var request = api.Create(HttpMethod.Post, path, null, address);
            request.Content = ApiConnection.JsonContent(body);
            return api.SendAsync<T>(api.ReferenceHttp, request, cancellationToken);
        }

        private async Task<T> GetCachedAsync<T>(string key, string path, CancellationToken cancellationToken) where T : class
        {
            T cached;
            if (cache.TryGetValue(key, out cached) && cached != null)
            {
                return cached;
            }

            var value = await api.SendAsync<T>(api.ReferenceHttp, api.Create(HttpMethod.Get, path, null, null), cancellationToken);
            if (settings.AccessCacheSeconds > 0)
            {
                cache.Set(key, value, TimeSpan.FromSeconds(settings.AccessCacheSeconds));
            }

            return value;
        }

        private sealed class OutcomeResult
        {
            public string Outcome { get; set; }
        }
    }
}
