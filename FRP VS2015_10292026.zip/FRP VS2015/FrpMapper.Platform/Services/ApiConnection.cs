using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Platform.Hosting;
using FrpMapper.Platform.Security;
using FrpMapper.Shared.Json;

namespace FrpMapper.Platform.Services
{
    /// <summary>Headers the API reads (see the API's PlatformTrustAuthentication).</summary>
    public static class ApiHeaders
    {
        public const string Key = "X-Frp-Api-Key";
        public const string User = "X-Frp-User";
        public const string Roles = "X-Frp-Roles";

        /// <summary>The person's network address, for the audit trail.</summary>
        public const string ClientAddress = "X-Frp-Client-Address";
    }

    /// <summary>An API error with the API's own message (e.g. a segregation-of-duties refusal).</summary>
    public sealed class ApiException : Exception
    {
        public ApiException(HttpStatusCode statusCode, string message) : base(message)
        {
            StatusCode = statusCode;
        }

        public HttpStatusCode StatusCode { get; private set; }
    }

    /// <summary>
    /// The connection to FrpMapper.Api. Every request carries the shared internal key; requests made for a person also
    /// carry their name, their application roles (from the database) and their address. The API enforces the roles and
    /// the segregation-of-duties rules itself.
    /// </summary>
    public sealed class ApiConnection : IDisposable
    {
        public static readonly JsonSerializerOptions Json = new JsonSerializerOptions(JsonSerializerDefaults.Web);

        private readonly PlatformSettings settings;

        public ApiConnection(PlatformSettings settings)
        {
            this.settings = settings;
            // Analyzing a large BSP report (FRP: ~50,000 fields, ~22,000 specification rules) can take longer than
            // HttpClient's default 100 seconds: ApiTimeoutMinutes. Reference calls (roles, sign-in) are quick.
            Http = new HttpClient(new HttpClientHandler { UseCookies = false, AllowAutoRedirect = false }) { BaseAddress = settings.ApiBaseUrl, Timeout = settings.ApiTimeout };
            ReferenceHttp = new HttpClient(new HttpClientHandler { UseCookies = false, AllowAutoRedirect = false }) { BaseAddress = settings.ApiBaseUrl, Timeout = TimeSpan.FromMinutes(1) };
        }

        public HttpClient Http { get; private set; }

        public HttpClient ReferenceHttp { get; private set; }

        public Uri BaseAddress
        {
            get { return settings.ApiBaseUrl; }
        }

        public TimeSpan Timeout
        {
            get { return settings.ApiTimeout; }
        }

        /// <summary>A request with the internal key; with <paramref name="user"/>, also the person, their roles and address.</summary>
        public HttpRequestMessage Create(HttpMethod method, string pathAndQuery, AppUser user, string address)
        {
            var request = new HttpRequestMessage(method, pathAndQuery);
            request.Headers.Add(ApiHeaders.Key, settings.InternalApiKey);
            if (user != null)
            {
                request.Headers.Add(ApiHeaders.User, user.Name);
                request.Headers.Add(ApiHeaders.Roles, string.Join(",", user.Roles));
            }

            if (address != null)
            {
                request.Headers.Add(ApiHeaders.ClientAddress, address);
            }

            return request;
        }

        public static StringContent JsonContent(object body)
        {
            var content = new StringContent(body == null ? "null" : JsonSerializer.Serialize(body, body.GetType(), Json), Encoding.UTF8);
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json") { CharSet = "utf-8" };
            return content;
        }

        /// <summary>The API's message for a failed request ({ "message": ... }), or a description of the status.</summary>
        public static async Task<string> ReadMessageAsync(HttpResponseMessage response)
        {
            string text = null;
            try
            {
                text = await response.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException)
            {
            }

            var message = MessageOf(text);
            if (message != null)
            {
                return message;
            }

            switch (response.StatusCode)
            {
                case HttpStatusCode.Unauthorized:
                    return "The API did not accept the sign-in. Check that InternalApi:Key is the same for the API and the Platform.";
                case HttpStatusCode.Forbidden:
                    return "Your roles do not allow this action.";
                case HttpStatusCode.NotFound:
                    return "The project was not found.";
                default:
                    return "The API returned " + (int)response.StatusCode + " " + response.ReasonPhrase + ".";
            }
        }

        /// <summary>The "message" of a JSON error body, or null.</summary>
        public static string MessageOf(string text)
        {
            if (string.IsNullOrWhiteSpace(text) || text.TrimStart()[0] != '{')
            {
                return null;
            }

            try
            {
                var error = JsonSerializer.Deserialize<ErrorBody>(text, Json);
                return error == null || string.IsNullOrEmpty(error.Message) ? null : error.Message;
            }
            catch (JsonException)
            {
                return null;
            }
        }

        public async Task<T> SendAsync<T>(HttpClient client, HttpRequestMessage request, CancellationToken cancellationToken)
        {
            using (request)
            using (var response = await client.SendAsync(request, cancellationToken))
            {
                if (!response.IsSuccessStatusCode)
                {
                    throw new ApiException(response.StatusCode, await ReadMessageAsync(response));
                }

                var text = await response.Content.ReadAsStringAsync();
                if (typeof(T) == typeof(object))
                {
                    return default(T);
                }

                var value = string.IsNullOrWhiteSpace(text) ? default(T) : JsonSerializer.Deserialize<T>(text, Json);
                if (value == null)
                {
                    throw new ApiException(response.StatusCode, "The API returned an empty response.");
                }

                return value;
            }
        }

        public void Dispose()
        {
            Http.Dispose();
            ReferenceHttp.Dispose();
        }

        private sealed class ErrorBody
        {
            public string Message { get; set; }
        }
    }
}
