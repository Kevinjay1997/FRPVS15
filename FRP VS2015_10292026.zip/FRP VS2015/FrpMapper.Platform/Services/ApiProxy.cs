﻿using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using FrpMapper.Platform.Hosting;
using FrpMapper.Platform.Security;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Platform.Services
{
    /// <summary>
    /// Forwards the page's data requests to FrpMapper.Api for the signed-in person. Only the API calls the screens make
    /// are forwarded (the list below, the same calls the Blazor version's FrpApiClient made); the API key, the person's
    /// name and roles are added here and never reach the browser. The API checks every permission and the segregation
    /// of duties itself.
    /// </summary>
    public sealed class ApiProxy
    {
        private const string Id = "[0-9a-f]{32}";
        private const string RequestId = "[A-Za-z0-9-]{1,64}";

        private static readonly Rule[] Rules =
        {
            new Rule("POST", "/api/sandbox/(certificate|submit|status|pdf|xml|excel|receipt|validate|findings|parameters)"),
            new Rule("GET", "/api/sandbox/banks"),
            new Rule("GET", "/api/sandbox/environments"),
            new Rule("GET", "/api/cocree/(setup|config)"),
            new Rule("POST", "/api/cocree/(export|validate|header-totals|config)"),
            new Rule("GET", "/api/cocree/outputs/" + Id + "/[A-Za-z0-9_][A-Za-z0-9_.-]{0,150}\\.(xml|csv|zip)"),
            new Rule("POST", "/api/cocree/config/" + Id + "/(approve|reject|cancel)"),
            new Rule("GET", "/api/cocree/config/" + Id + "/(config|code-lists|validations|xsd)"),
            new Rule("GET", "/api/xml-tools/(setup|config)"),
            new Rule("POST", "/api/xml-tools/(merge|validate|config)"),
            new Rule("GET", "/api/xml-tools/outputs/" + Id + "/[A-Za-z0-9_][A-Za-z0-9_.-]{0,150}\\.(xml|csv|log)"),
            new Rule("POST", "/api/xml-tools/config/" + Id + "/(approve|reject|cancel)"),
            new Rule("GET", "/api/xml-tools/config/" + Id + "/(merge|cleanup|reportperiod)"),
            new Rule("GET", "/api/logs"),
            new Rule("GET", "/api/logs/[A-Za-z0-9_-]{1,64}-[0-9]{8}\\.[A-Za-z]{1,8}(/download)?"),
            new Rule("GET", "/api/reference/bsp-environments"),
            new Rule("POST", "/api/reference/bsp-environments"),
            new Rule("POST", "/api/reference/bsp-environments/" + Id + "/(approve|reject|cancel|remove)"),
            new Rule("GET", "/api/reference"),
            new Rule("GET", "/api/reference/certificates"),
            new Rule("POST", "/api/reference/certificates"),
            new Rule("POST", "/api/reference/certificates/" + Id + "/(approve|reject|cancel|remove)"),
            new Rule("POST", "/api/reference/banks/requests"),
            new Rule("POST", "/api/reference/banks/requests/" + RequestId + "/(approve|reject|cancel)"),
            new Rule("POST", "/api/reference/branches"),
            new Rule("POST", "/api/reference/sandbox"),
            new Rule("GET", "/api/reports/(user-maintenance|parameter-maintenance|users|sign-ins)"),
            new Rule("GET", "/api/projects"),
            new Rule("POST", "/api/projects/analyze"),
            new Rule("POST", "/api/projects/matching-files"),
            new Rule("GET", "/api/files/stored"),
            new Rule("GET", "/api/projects/" + Id),
            new Rule("DELETE", "/api/projects/" + Id),
            new Rule("GET", "/api/projects/" + Id + "/(uploads|account-codes|sheet-splits|audit|audit/page|export/template/check|validate/generated-xml|template/sheet|mappings/suggested)"),
            new Rule("PUT", "/api/projects/" + Id + "/(mappings|sheet-splits|values|name)"),
            new Rule("POST", "/api/projects/" + Id + "/(files|mappings/sample-values|values/samples|validate|check-template|validate/xml|validate/workbook|xml/merge-sheet-copies)"),
            new Rule("POST", "/api/projects/" + Id + "/(submission|submission/workbook|submission/generate)"),
            new Rule("POST", "/api/projects/" + Id + "/(submit|withdraw|approve|return|reopen)"),
            new Rule("GET", "/api/audit"),
            new Rule("GET", "/api/audit/page"),
            new Rule("GET", "/api/admin/access"),
            new Rule("GET", "/api/admin/access/activity"),
            new Rule("POST", "/api/admin/access/(users|roles|groups)"),
            new Rule("POST", "/api/admin/access/requests/" + RequestId + "/(approve|reject|cancel)")
        };

        private readonly ApiConnection api;
        private readonly ILogger logger;

        public ApiProxy(ApiConnection api, ILogger<ApiProxy> logger)
        {
            this.api = api;
            this.logger = logger;
        }

        /// <summary>True when the screens make this API call.</summary>
        public static bool IsAllowed(string method, string apiPath)
        {
            return Rules.Any(rule => rule.Matches(method, apiPath));
        }

        /// <summary>Sends the request on to the API and copies the answer back (streamed progress stays streamed).</summary>
        public async Task ForwardAsync(HttpContextBase context, string method, string apiPath, AppUser user, string address, CancellationToken cancellationToken)
        {
            var source = context.Request;
            var query = source.Url.Query;
            using (var request = api.Create(new HttpMethod(method), apiPath + query, user, address))
            {
                var accept = source.Headers["Accept"] ?? "";
                var streamed = accept.IndexOf("application/x-ndjson", StringComparison.OrdinalIgnoreCase) >= 0;
                request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(streamed ? "application/x-ndjson" : "application/json"));
                if (method != "GET" && source.ContentLength > 0)
                {
                    // The body as the browser sent it (JSON, or the files as multipart/form-data with its boundary).
                    var body = new StreamContent(source.InputStream);
                    MediaTypeHeaderValue type;
                    if (MediaTypeHeaderValue.TryParse(source.ContentType ?? "", out type))
                    {
                        body.Headers.ContentType = type;
                    }

                    body.Headers.ContentLength = source.ContentLength;
                    request.Content = body;
                }

                HttpResponseMessage response;
                try
                {
                    response = await api.Http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
                }
                catch (HttpRequestException ex)
                {
                    logger.LogError(ex, "The FRP Mapper API at {Url} cannot be reached.", api.BaseAddress);
                    await Http.WriteJsonAsync(context, 502, new { message = "The FRP Mapper API cannot be reached.", unreachable = true });
                    return;
                }
                catch (TaskCanceledException) when (!cancellationToken.IsCancellationRequested)
                {
                    await Http.WriteJsonAsync(context, 504, new
                    {
                        message = "The API did not answer within " + api.Timeout.TotalMinutes.ToString("0") + " minutes. Raise ApiTimeoutMinutes in the Platform's web.config for very large files.",
                        timeout = true
                    });
                    return;
                }

                using (response)
                {
                    await CopyAsync(context, response, streamed, cancellationToken);
                }
            }
        }

        /// <summary>A file from the API for a download link (links cannot carry API headers, so they go through here).</summary>
        public async Task DownloadAsync(HttpContextBase context, string apiPathAndQuery, string projectId, AppUser user, string address, CancellationToken cancellationToken)
        {
            HttpResponseMessage response;
            try
            {
                response = await api.Http.SendAsync(api.Create(HttpMethod.Get, apiPathAndQuery, user, address), HttpCompletionOption.ResponseHeadersRead, cancellationToken);
            }
            catch (HttpRequestException ex)
            {
                logger.LogError(ex, "The FRP Mapper API at {Url} cannot be reached.", api.BaseAddress);
                await Http.WriteHtmlAsync(context, 502, Pages.DownloadUnavailable(context, "The FRP Mapper API cannot be reached. Try again in a moment.", projectId));
                return;
            }

            using (response)
            {
                if (!response.IsSuccessStatusCode)
                {
                    var message = await ApiConnection.ReadMessageAsync(response);
                    await Http.WriteHtmlAsync(context, (int)response.StatusCode, Pages.DownloadUnavailable(context, message, projectId));
                    return;
                }

                await CopyAsync(context, response, false, cancellationToken);
            }
        }

        private static async Task CopyAsync(HttpContextBase context, HttpResponseMessage response, bool streamed, CancellationToken cancellationToken)
        {
            var target = context.Response;
            target.StatusCode = (int)response.StatusCode;
            var contentType = response.Content.Headers.ContentType;
            if (contentType != null)
            {
                target.ContentType = contentType.ToString();
            }

            var disposition = response.Content.Headers.ContentDisposition;
            if (disposition != null)
            {
                target.AddHeader("Content-Disposition", disposition.ToString());
            }

            if (response.StatusCode == HttpStatusCode.NoContent || response.StatusCode == HttpStatusCode.NotModified)
            {
                return;
            }

            using (var source = await response.Content.ReadAsStreamAsync())
            {
                if (streamed)
                {
                    // Progress lines go to the browser as they come.
                    target.BufferOutput = false;
                    var buffer = new byte[16 * 1024];
                    int read;
                    while ((read = await source.ReadAsync(buffer, 0, buffer.Length, cancellationToken)) > 0)
                    {
                        await target.OutputStream.WriteAsync(buffer, 0, read, cancellationToken);
                        target.Flush();
                    }

                    return;
                }

                var isJson = contentType != null && contentType.MediaType == "application/json";
                var acceptsGzip = (context.Request.Headers["Accept-Encoding"] ?? "").IndexOf("gzip", StringComparison.OrdinalIgnoreCase) >= 0;
                if (isJson && acceptsGzip)
                {
                    // A project's data can be tens of megabytes of JSON; it compresses to a tenth.
                    target.AddHeader("Content-Encoding", "gzip");
                    target.AddHeader("Vary", "Accept-Encoding");
                    using (var gzip = new GZipStream(target.OutputStream, CompressionLevel.Fastest, true))
                    {
                        await source.CopyToAsync(gzip, 81920, cancellationToken);
                    }

                    return;
                }

                await source.CopyToAsync(target.OutputStream, 81920, cancellationToken);
            }
        }

        private sealed class Rule
        {
            private readonly string method;
            private readonly Regex path;

            public Rule(string method, string pattern)
            {
                this.method = method;
                path = new Regex("^" + pattern + "$", RegexOptions.CultureInvariant);
            }

            public bool Matches(string requestMethod, string requestPath)
            {
                return string.Equals(method, requestMethod, StringComparison.Ordinal) && path.IsMatch(requestPath);
            }
        }
    }
}
