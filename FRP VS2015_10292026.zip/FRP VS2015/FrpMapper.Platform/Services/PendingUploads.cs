using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using FrpMapper.Platform.Security;

namespace FrpMapper.Platform.Services
{
    /// <summary>
    /// Files a person uploaded for a preview, kept in memory for a short time so the same files can be saved after the
    /// preview without choosing them again (a form post cannot carry a file chosen in an earlier post). A file set belongs
    /// to the person who uploaded it: another person, or the same token after it expired, gets nothing. Nothing is
    /// written to disk; at most <see cref="MaxSets"/> sets are kept, the oldest are dropped first.
    /// </summary>
    public sealed class PendingUploads
    {
        public const int MaxSets = 50;

        private static readonly TimeSpan Lifetime = TimeSpan.FromMinutes(20);

        private readonly ConcurrentDictionary<string, Entry> entries = new ConcurrentDictionary<string, Entry>(StringComparer.Ordinal);

        /// <summary>Keeps the files for the person; returns the token that finds them again.</summary>
        public string Keep(string userName, IReadOnlyList<UploadedFile> files)
        {
            Prune();
            var token = SessionStore.NewToken();
            entries[token] = new Entry { UserName = userName, Files = files, ExpiresAt = DateTimeOffset.UtcNow + Lifetime };
            return token;
        }

        /// <summary>The person's files for the token, or null when they expired or belong to someone else.</summary>
        public IReadOnlyList<UploadedFile> Find(string token, string userName)
        {
            Entry entry;
            if (string.IsNullOrEmpty(token) || !entries.TryGetValue(token, out entry))
            {
                return null;
            }

            if (entry.ExpiresAt <= DateTimeOffset.UtcNow)
            {
                Forget(token);
                return null;
            }

            return string.Equals(entry.UserName, userName, StringComparison.OrdinalIgnoreCase) ? entry.Files : null;
        }

        public void Forget(string token)
        {
            Entry removed;
            if (!string.IsNullOrEmpty(token))
            {
                entries.TryRemove(token, out removed);
            }
        }

        private void Prune()
        {
            var now = DateTimeOffset.UtcNow;
            foreach (var pair in entries.ToList())
            {
                if (pair.Value.ExpiresAt <= now)
                {
                    Forget(pair.Key);
                }
            }

            foreach (var pair in entries.OrderBy(p => p.Value.ExpiresAt).Take(Math.Max(0, entries.Count - (MaxSets - 1))).ToList())
            {
                Forget(pair.Key);
            }
        }

        private sealed class Entry
        {
            public string UserName { get; set; }

            public IReadOnlyList<UploadedFile> Files { get; set; }

            public DateTimeOffset ExpiresAt { get; set; }
        }
    }
}
