using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Platform.Security;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;

namespace FrpMapper.Platform.Services
{
    /// <summary>A file the person uploaded on a page, passed on to the API.</summary>
    public sealed class UploadedFile
    {
        public UploadedFile(string fieldName, string fileName, byte[] content)
        {
            FieldName = fieldName;
            FileName = fileName;
            Content = content;
        }

        /// <summary>The form field the API reads it from ("certificate", "file", "report", "xml").</summary>
        public string FieldName { get; private set; }

        public string FileName { get; private set; }

        public byte[] Content { get; private set; }
    }

    /// <summary>
    /// The API calls the server-side pages (ASP.NET Web Forms) make for the signed-in person. Each request carries the
    /// internal key, the person's name, roles and address (<see cref="ApiConnection.Create"/>), exactly as the page's data
    /// requests forwarded by <see cref="ApiProxy"/> do; the API checks every permission and the segregation of duties itself.
    /// Throws <see cref="ApiException"/> with the API's message when the API refuses, and
    /// <see cref="ApiUnavailableException"/> when it cannot be reached or does not answer in time.
    /// </summary>
    public sealed class UserApiClient
    {
        private readonly ApiConnection api;
        private readonly ILogger logger;

        public UserApiClient(ApiConnection api, ILogger<UserApiClient> logger)
        {
            this.api = api;
            this.logger = logger;
        }

        public Task<T> GetAsync<T>(string path, SignedInPerson person, CancellationToken cancellationToken) where T : class
        {
            return SendAsync<T>(api.Create(HttpMethod.Get, path, person.User, person.Address), cancellationToken);
        }

        /// <summary>A JSON body; returns the API's JSON answer.</summary>
        public Task<T> PostJsonAsync<T>(string path, object body, SignedInPerson person, CancellationToken cancellationToken) where T : class
        {
            var request = api.Create(HttpMethod.Post, path, person.User, person.Address);
            request.Content = ApiConnection.JsonContent(body);
            return SendAsync<T>(request, cancellationToken);
        }

        /// <summary>A JSON body, for calls that answer 204 No Content. False when the API answers 404 (it no longer exists).</summary>
        public async Task<bool> PostJsonNoContentAsync(string path, object body, SignedInPerson person, CancellationToken cancellationToken)
        {
            var request = api.Create(HttpMethod.Post, path, person.User, person.Address);
            request.Content = ApiConnection.JsonContent(body);
            using (var response = await SendRawAsync(request, cancellationToken))
            {
                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    return false;
                }

                if (!response.IsSuccessStatusCode)
                {
                    throw new ApiException(response.StatusCode, await ApiConnection.ReadMessageAsync(response));
                }

                return true;
            }
        }

        /// <summary>A multipart/form-data body (fields and files), as the page's uploads send it; returns the API's JSON answer.</summary>
        public Task<T> PostFormAsync<T>(string path, IDictionary<string, string> fields, IEnumerable<UploadedFile> files, SignedInPerson person,
            CancellationToken cancellationToken) where T : class
        {
            var request = api.Create(HttpMethod.Post, path, person.User, person.Address);
            var form = new MultipartFormDataContent();
            if (fields != null)
            {
                foreach (var field in fields)
                {
                    form.Add(new StringContent(field.Value ?? ""), field.Key);
                }
            }

            if (files != null)
            {
                foreach (var file in files)
                {
                    var part = new ByteArrayContent(file.Content);
                    part.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                    form.Add(part, file.FieldName, file.FileName);
                }
            }

            request.Content = form;
            return SendAsync<T>(request, cancellationToken);
        }

        private async Task<T> SendAsync<T>(HttpRequestMessage request, CancellationToken cancellationToken) where T : class
        {
            using (var response = await SendRawAsync(request, cancellationToken))
            {
                if (!response.IsSuccessStatusCode)
                {
                    throw new ApiException(response.StatusCode, await ApiConnection.ReadMessageAsync(response));
                }

                var text = await response.Content.ReadAsStringAsync();
                var value = string.IsNullOrWhiteSpace(text) ? null : JsonSerializer.Deserialize<T>(text, ApiConnection.Json);
                if (value == null)
                {
                    throw new ApiException(response.StatusCode, "The API returned an empty response.");
                }

                return value;
            }
        }

        private async Task<HttpResponseMessage> SendRawAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            using (request)
            {
                try
                {
                    return await api.Http.SendAsync(request, cancellationToken);
                }
                catch (HttpRequestException ex)
                {
                    logger.LogError(ex, "The FRP Mapper API at {Url} cannot be reached.", api.BaseAddress);
                    throw new ApiUnavailableException("The FRP Mapper API cannot be reached. Try again in a moment.");
                }
                catch (TaskCanceledException) when (!cancellationToken.IsCancellationRequested)
                {
                    throw new ApiUnavailableException("The API did not answer within " + api.Timeout.TotalMinutes.ToString("0")
                        + " minutes. Raise ApiTimeoutMinutes in the Platform's web.config for very large files.");
                }
            }
        }
    }

    /// <summary>The API cannot be reached or did not answer in time; the message says so in plain words.</summary>
    public sealed class ApiUnavailableException : Exception
    {
        public ApiUnavailableException(string message) : base(message)
        {
        }
    }
}
