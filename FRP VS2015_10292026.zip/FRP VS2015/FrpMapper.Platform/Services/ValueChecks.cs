using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Platform.Security;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;
using FrpMapper.Shared.Validation;

namespace FrpMapper.Platform.Services
{
    /// <summary>The values the mappings tab asks about: the project, its version, and (XSD path, value) pairs.</summary>
    public sealed class ValueCheckRequest
    {
        public ValueCheckRequest()
        {
            Items = new List<List<string>>();
        }

        public string ProjectId { get; set; }

        /// <summary>The project's UpdatedAt: a saved change gives new XSD nodes (sample values).</summary>
        public string Version { get; set; }

        /// <summary>[path, value] pairs; at most <see cref="ValueChecks.MaxItems"/>.</summary>
        public List<List<string>> Items { get; set; }
    }

    /// <summary>
    /// Checks the values typed on the mappings tab against the XSD facets (the shared XsdValueValidator, the same check the
    /// API applies when it saves), so the page can mark each row as it is edited. The project's XSD nodes are read from the
    /// API for the signed-in person (the API decides whether they may see the project) and kept for a few minutes.
    /// </summary>
    public sealed class ValueChecks
    {
        public const int MaxItems = 100000;

        private readonly ApiConnection api;
        private readonly IMemoryCache cache;

        public ValueChecks(ApiConnection api, IMemoryCache cache)
        {
            this.api = api;
            this.cache = cache;
        }

        /// <summary>The errors of each invalid item, by its position in the request; valid items are left out.</summary>
        public async Task<Dictionary<string, IReadOnlyList<string>>> CheckAsync(ValueCheckRequest check, AppUser user, string address, CancellationToken cancellationToken)
        {
            var nodes = await NodesAsync(check.ProjectId, check.Version, user, address, cancellationToken);
            var errors = new Dictionary<string, IReadOnlyList<string>>(StringComparer.Ordinal);
            for (var i = 0; i < check.Items.Count; i++)
            {
                var item = check.Items[i];
                var path = item != null && item.Count > 0 ? item[0] : null;
                var value = item != null && item.Count > 1 ? item[1] : null;
                SchemaNodeDto node;
                // A blank value is an empty cell (its sample value removed): nothing to check yet.
                IReadOnlyList<string> found = path != null && nodes.TryGetValue(path, out node)
                    ? (string.IsNullOrWhiteSpace(value) ? new string[0] : XsdValueValidator.Validate(value, node))
                    : new[] { "The XSD does not contain this path." };
                if (found.Count > 0)
                {
                    errors[i.ToString(System.Globalization.CultureInfo.InvariantCulture)] = found;
                }
            }

            return errors;
        }

        private async Task<Dictionary<string, SchemaNodeDto>> NodesAsync(string projectId, string version, AppUser user, string address, CancellationToken cancellationToken)
        {
            // Per person: a person who may not see the project gets the API's refusal, never another person's copy.
            var key = "frp:platform:nodes:" + user.Name + "|" + projectId + "|" + version;
            Dictionary<string, SchemaNodeDto> nodes;
            if (cache.TryGetValue(key, out nodes))
            {
                return nodes;
            }

            var project = await api.SendAsync<NodesOnly>(api.Http, api.Create(HttpMethod.Get, "/api/projects/" + projectId, user, address), cancellationToken);
            nodes = new Dictionary<string, SchemaNodeDto>(StringComparer.OrdinalIgnoreCase);
            foreach (var node in project.SchemaNodes ?? new List<SchemaNodeDto>())
            {
                if (!nodes.ContainsKey(node.Path))
                {
                    nodes[node.Path] = node;
                }
            }

            cache.Set(key, nodes, TimeSpan.FromMinutes(10));
            return nodes;
        }

        /// <summary>Only the XSD nodes of a project (the rest of its data is skipped).</summary>
        private sealed class NodesOnly
        {
            public List<SchemaNodeDto> SchemaNodes { get; set; }
        }
    }
}
