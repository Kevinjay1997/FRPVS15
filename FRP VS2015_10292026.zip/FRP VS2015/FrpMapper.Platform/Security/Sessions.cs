using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using FrpMapper.Platform.Hosting;
using FrpMapper.Shared.Compat;

namespace FrpMapper.Platform.Security
{
    /// <summary>
    /// One signed-in browser session, kept in this server's memory. The browser only holds a random, unguessable token
    /// in an HttpOnly, SameSite=Strict cookie (secure outside Development); everything else (who, the roles' source, the
    /// session id the API checks, the anti-forgery token) stays on the server.
    /// </summary>
    public sealed class PlatformSession
    {
        public PlatformSession()
        {
            DirectoryGroups = new List<string>();
            DevelopmentRoles = new List<string>();
        }

        /// <summary>The cookie's value (256 random bits).</summary>
        public string Token { get; set; }

        /// <summary>The account (DOMAIN\name, or the Development test user).</summary>
        public string UserName { get; set; }

        public AuthenticationMode Mode { get; set; }

        /// <summary>The session id the API records at sign-in (only the account's newest session may be used).</summary>
        public string SessionId { get; set; }

        /// <summary>Active Directory sign-in: the groups of the account that grant an FRP Mapper role.</summary>
        public IReadOnlyList<string> DirectoryGroups { get; set; }

        /// <summary>Development sign-in: the test user's roles (only roles that exist in the database count).</summary>
        public IReadOnlyList<string> DevelopmentRoles { get; set; }

        /// <summary>The address the person signed in from.</summary>
        public string Address { get; set; }

        /// <summary>The account's previous successful sign-in, shown after signing in.</summary>
        public DateTimeOffset? PreviousSignInAt { get; set; }

        /// <summary>Failed sign-ins since the previous successful one; null for Windows sign-in (no sign-in page).</summary>
        public int? FailedSinceLast { get; set; }

        /// <summary>Sent with every change the page asks for (header X-Frp-Csrf); a request without it is refused.</summary>
        public string CsrfToken { get; set; }

        public DateTimeOffset CreatedAt { get; set; }

        /// <summary>The last request of this session (pages, data, the page's keep-alive while the person is active).</summary>
        public DateTimeOffset LastSeen { get; set; }
    }

    /// <summary>
    /// The signed-in sessions of this server. A session ends after Session:IdleMinutes without a request, at sign-out,
    /// or when the account signs in again elsewhere (checked with the API). Kept in memory: an application restart signs
    /// everyone out (like the Blazor Server version, a person's requests must reach the same server).
    /// </summary>
    public sealed class SessionStore
    {
        private readonly ConcurrentDictionary<string, PlatformSession> sessions = new ConcurrentDictionary<string, PlatformSession>(StringComparer.Ordinal);
        private readonly PlatformSettings settings;
        private readonly TimeProvider clock;
        private DateTimeOffset nextPrune = DateTimeOffset.MinValue;

        public SessionStore(PlatformSettings settings, TimeProvider clock)
        {
            this.settings = settings;
            this.clock = clock;
        }

        /// <summary>A new unpredictable id: 128 random bits as lowercase hex (the API's session id).</summary>
        public static string NewSessionId()
        {
            return CompatHex.ToHexString(CompatRandom.GetBytes(16)).ToLowerInvariant();
        }

        /// <summary>A new cookie or anti-forgery token: 256 random bits, URL-safe.</summary>
        public static string NewToken()
        {
            return Convert.ToBase64String(CompatRandom.GetBytes(32)).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        }

        public PlatformSession Create(PlatformSession session)
        {
            var now = clock.GetUtcNow();
            session.Token = NewToken();
            session.CsrfToken = NewToken();
            session.CreatedAt = now;
            session.LastSeen = now;
            sessions[session.Token] = session;
            Prune(now);
            return session;
        }

        /// <summary>The session of the cookie, or null when there is none or it was idle too long (it then ends).</summary>
        public PlatformSession Find(string token, out bool expired)
        {
            expired = false;
            PlatformSession session;
            if (string.IsNullOrEmpty(token) || token.Length > 100 || !sessions.TryGetValue(token, out session))
            {
                return null;
            }

            if (clock.GetUtcNow() - session.LastSeen > settings.IdleTimeout)
            {
                expired = true;
                Remove(token);
                return null;
            }

            return session;
        }

        /// <summary>Counts as activity for the idle timeout.</summary>
        public void Touch(PlatformSession session)
        {
            var now = clock.GetUtcNow();
            session.LastSeen = now;
            Prune(now);
        }

        public void Remove(string token)
        {
            PlatformSession removed;
            if (!string.IsNullOrEmpty(token))
            {
                sessions.TryRemove(token, out removed);
            }
        }

        private void Prune(DateTimeOffset now)
        {
            if (now < nextPrune)
            {
                return;
            }

            nextPrune = now.AddMinutes(1);
            foreach (var pair in sessions.ToList())
            {
                if (now - pair.Value.LastSeen > settings.IdleTimeout)
                {
                    Remove(pair.Key);
                }
            }
        }

        /// <summary>Compares two tokens in constant time.</summary>
        public static bool SameToken(string expected, string presented)
        {
            if (string.IsNullOrEmpty(expected) || string.IsNullOrEmpty(presented) || expected.Length != presented.Length)
            {
                return false;
            }

            var difference = 0;
            for (var i = 0; i < expected.Length; i++)
            {
                difference |= expected[i] ^ presented[i];
            }

            return difference == 0;
        }
    }
}
