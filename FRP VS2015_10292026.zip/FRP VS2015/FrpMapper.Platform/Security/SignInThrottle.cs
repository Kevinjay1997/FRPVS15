using System;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Platform.Security
{
    /// <summary>
    /// Slows down password guessing on the sign-in page, on top of the account lockout (frp.SignInState, which locks a
    /// known account after 3 failed sign-ins in a row) and the domain's own lockout policy: after
    /// <see cref="MaxFailuresPerAccount"/> failed attempts for one user name from one address, or
    /// <see cref="MaxFailuresPerAddress"/> from one address for any user names, sign-in from that address is refused for
    /// <see cref="Window"/>. Counts live in memory (they reset when the Platform restarts).
    /// </summary>
    public sealed class SignInThrottle
    {
        public const int MaxFailuresPerAccount = 3;
        public const int MaxFailuresPerAddress = 20;
        public static readonly TimeSpan Window = TimeSpan.FromMinutes(5);

        private readonly IMemoryCache cache;
        private readonly object gate = new object();

        public SignInThrottle(IMemoryCache cache)
        {
            this.cache = cache;
        }

        public bool IsBlocked(string userName, string address)
        {
            return Count(AccountKey(userName, address)) >= MaxFailuresPerAccount || Count(AddressKey(address)) >= MaxFailuresPerAddress;
        }

        public void RecordFailure(string userName, string address)
        {
            lock (gate)
            {
                Increment(AccountKey(userName, address));
                Increment(AddressKey(address));
            }
        }

        /// <summary>A successful sign-in clears the account's count (not the address's).</summary>
        public void RecordSuccess(string userName, string address)
        {
            cache.Remove(AccountKey(userName, address));
        }

        private int Count(string key)
        {
            int count;
            return cache.TryGetValue(key, out count) ? count : 0;
        }

        private void Increment(string key)
        {
            cache.Set(key, Count(key) + 1, new MemoryCacheEntryOptions { AbsoluteExpirationRelativeToNow = Window });
        }

        private static string AccountKey(string userName, string address)
        {
            return "signin:account:" + userName.Trim().ToUpperInvariant() + "|" + address;
        }

        private static string AddressKey(string address)
        {
            return "signin:address:" + address;
        }
    }
}
