using System.Net;
using System.Web;

namespace FrpMapper.Platform.Security
{
    /// <summary>
    /// The network address a person works from, recorded with every audit entry (Application Security Checklist: the
    /// client IP address in the audit trail). It is the address of the HTTP request; behind a proxy that is the proxy's
    /// address (forwarded headers are not trusted, so a client cannot write its own address into the audit trail).
    /// </summary>
    public static class ClientAddress
    {
        /// <summary>Longest textual IP address (IPv6 with an embedded IPv4 address), the audit column's size.</summary>
        public const int MaxLength = 45;

        /// <summary>The request's remote address as text (IPv4-mapped IPv6 shown as IPv4), or null when unknown.</summary>
        public static string Of(HttpContextBase context)
        {
            if (context == null)
            {
                return null;
            }

            string text;
            try
            {
                text = context.Request.UserHostAddress;
            }
            catch (HttpException)
            {
                return null;
            }

            IPAddress address;
            return IPAddress.TryParse(text ?? "", out address) ? Format(address) : null;
        }

        public static string Format(IPAddress address)
        {
            if (address == null)
            {
                return null;
            }

            if (address.IsIPv4MappedToIPv6)
            {
                address = address.MapToIPv4();
            }

            if (address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6 && address.ScopeId != 0)
            {
                // Without the zone (%eth0): a copy, so the original address object is not changed.
                address = new IPAddress(address.GetAddressBytes());
            }

            var text = address.ToString();
            return text.Length <= MaxLength ? text : null;
        }

        /// <summary>A stored address (from the session) when it is a valid IP address of at most <see cref="MaxLength"/> characters.</summary>
        public static string Checked(string stored)
        {
            IPAddress parsed;
            return !string.IsNullOrEmpty(stored) && stored.Length <= MaxLength && IPAddress.TryParse(stored, out parsed) ? stored : null;
        }
    }
}
