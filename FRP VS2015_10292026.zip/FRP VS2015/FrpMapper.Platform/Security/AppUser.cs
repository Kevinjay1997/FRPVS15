using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using FrpMapper.Platform.Hosting;
using FrpMapper.Platform.Services;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Platform.Security
{
    /// <summary>
    /// The signed-in person for one request: their name, their application roles and the permissions those roles hold
    /// (both from the database, read through the API), and why they have no role when they have none.
    /// </summary>
    public sealed class AppUser
    {
        public AppUser()
        {
            Roles = new List<string>();
            Permissions = new HashSet<string>(StringComparer.Ordinal);
        }

        public string Name { get; set; }

        public IReadOnlyList<string> Roles { get; set; }

        public ISet<string> Permissions { get; set; }

        /// <summary>The roles could not be read because the API was unreachable.</summary>
        public bool AccessUnavailable { get; set; }

        /// <summary>SRAU disabled the person (or their access ended): no role at all.</summary>
        public bool UserDisabled { get; set; }

        /// <summary>Why the person's roles were not given (they break the segregation of duties), or null.</summary>
        public string RoleConflict { get; set; }

        public bool Can(string permission)
        {
            return Permissions.Contains(permission);
        }
    }

    /// <summary>
    /// Gives a signed-in person their application roles, as the Blazor version's claims transformation did on every
    /// request: Development test users their test roles, Active Directory (sign-in page) users the roles of the groups
    /// recorded when they signed in, Windows users the roles of their Windows groups; plus the roles SRAU gave them in the
    /// app. None when SRAU disabled them, when the roles together break the segregation of duties, or when the API cannot
    /// be reached (the access page then says why).
    /// </summary>
    public sealed class AccessResolver
    {
        private readonly ApiReferenceClient reference;
        private readonly ILogger logger;

        public AccessResolver(ApiReferenceClient reference, ILogger<AccessResolver> logger)
        {
            this.reference = reference;
            this.logger = logger;
        }

        public async Task<AppUser> ResolveAsync(PlatformSession session, IPrincipal windowsUser, CancellationToken cancellationToken)
        {
            var user = new AppUser { Name = session.UserName };
            try
            {
                var catalog = await reference.GetCatalogAsync(cancellationToken);
                IEnumerable<string> otherRoles;
                switch (session.Mode)
                {
                    case AuthenticationMode.Development:
                        otherRoles = session.DevelopmentRoles;
                        break;
                    case AuthenticationMode.ActiveDirectory:
                        otherRoles = catalog.Roles
                            .Where(role => role.DirectoryGroups.Any(group => session.DirectoryGroups.Any(held => string.Equals(held, group.Trim(), StringComparison.OrdinalIgnoreCase))))
                            .Select(role => role.Key)
                            .ToList();
                        break;
                    default:
                        otherRoles = catalog.Roles
                            .Where(role => windowsUser != null && role.DirectoryGroups.Any(group => !string.IsNullOrWhiteSpace(group) && IsInRole(windowsUser, group.Trim())))
                            .Select(role => role.Key)
                            .ToList();
                        break;
                }

                // Plus the roles SRAU gave the person in the app; none when SRAU disabled them or the roles together break
                // the segregation of duties (the API applies the same rules).
                string conflict;
                bool disabled;
                var roles = AccessRules.Resolve(catalog, session.UserName, otherRoles, out conflict, out disabled);
                user.UserDisabled = disabled;
                if (conflict != null)
                {
                    logger.LogWarning("{User} gets no role: {Conflict}", session.UserName, conflict);
                    user.RoleConflict = conflict;
                }

                user.Roles = roles.ToList();
                user.Permissions = new HashSet<string>(catalog.PermissionsOf(roles), StringComparer.Ordinal);
            }
            catch (Exception ex)
            {
                if (!IsApiFailure(ex))
                {
                    throw;
                }

                logger.LogError(ex, "The roles of {User} could not be read from the FRP Mapper API.", session.UserName);
                user.AccessUnavailable = true;
            }

            return user;
        }

        /// <summary>A call to the API failed: unreachable, timed out, or refused.</summary>
        public static bool IsApiFailure(Exception ex)
        {
            return ex is HttpRequestException || ex is TaskCanceledException || ex is ApiException;
        }

        internal static bool IsInRole(IPrincipal user, string group)
        {
            try
            {
                return user.IsInRole(group);
            }
            catch (SystemException)
            {
                // A group name Windows cannot resolve grants nothing.
                return false;
            }
        }
    }
}
