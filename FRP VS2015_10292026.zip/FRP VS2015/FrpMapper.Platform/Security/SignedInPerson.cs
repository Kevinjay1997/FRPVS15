namespace FrpMapper.Platform.Security
{
    /// <summary>The person a request is made for: their session, their roles and permissions, and their network address.</summary>
    public sealed class SignedInPerson
    {
        public SignedInPerson(PlatformSession session, AppUser user, string address)
        {
            Session = session;
            User = user;
            Address = address;
        }

        public PlatformSession Session { get; private set; }

        public AppUser User { get; private set; }

        /// <summary>The address for the audit trail (null when unknown).</summary>
        public string Address { get; private set; }
    }
}
