using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Security.Principal;
using FrpMapper.Platform.Hosting;
using FrpMapper.Shared.Hosting;
using Microsoft.Win32.SafeHandles;

namespace FrpMapper.Platform.Security
{
    /// <summary>The outcome of checking an Active Directory user name and password.</summary>
    public sealed class DirectorySignInResult
    {
        public DirectorySignInResult()
        {
            Groups = new List<string>();
        }

        public bool Succeeded { get; set; }

        /// <summary>The account as Windows names it (DOMAIN\user).</summary>
        public string AccountName { get; set; }

        /// <summary>The account's groups (DOMAIN\group), including nested and built-in groups.</summary>
        public IReadOnlyList<string> Groups { get; set; }

        /// <summary>For the person signing in; never says whether the user name exists.</summary>
        public string Error { get; set; }

        /// <summary>For the log only (never shown): the Windows error code.</summary>
        public int? ErrorCode { get; set; }
    }

    /// <summary>Checks an Active Directory user name and password and reads the account's groups.</summary>
    public interface IDirectoryCredentialValidator
    {
        DirectorySignInResult Validate(string userName, string password);

        /// <summary>
        /// The account the typed user name refers to, in the DOMAIN\name form Windows reports on success, so failed and
        /// successful sign-ins are counted against the same account: DOMAIN\name as typed; a bare name with
        /// Authentication:DefaultDomain (the NetBIOS domain name) or the server's domain. A UPN (name@domain) is kept as
        /// typed (its NetBIOS domain is not known without a directory lookup; the domain's own lockout still applies).
        /// </summary>
        string AccountKey(string userName);
    }

    /// <summary>
    /// Checks the password with the domain controller through Windows (LogonUser, network logon: nothing is cached and no
    /// interactive session is created), the same way Windows sign-in does, so the domain's password, lockout and expiry
    /// policies apply. The Platform must run on a Windows server that is a member of the domain (or trusts it).
    /// User names can be DOMAIN\user, user@domain (UPN) or just user (then Authentication:DefaultDomain, or the
    /// server's own domain, is used).
    /// </summary>
    public sealed class WindowsDirectoryCredentialValidator : IDirectoryCredentialValidator
    {
        private const int LogonNetwork = 3;
        private const int ProviderDefault = 0;

        private const int ErrorLogonFailure = 1326;
        private const int ErrorAccountRestriction = 1327;
        private const int ErrorInvalidLogonHours = 1328;
        private const int ErrorInvalidWorkstation = 1329;
        private const int ErrorPasswordExpired = 1330;
        private const int ErrorAccountDisabled = 1331;
        private const int ErrorNoLogonServers = 1311;
        private const int ErrorLogonTypeNotGranted = 1385;
        private const int ErrorAccountExpired = 1793;
        private const int ErrorPasswordMustChange = 1907;
        private const int ErrorAccountLockedOut = 1909;

        private readonly PlatformSettings settings;
        private readonly ILogger logger;

        public WindowsDirectoryCredentialValidator(PlatformSettings settings, ILogger<WindowsDirectoryCredentialValidator> logger)
        {
            this.settings = settings;
            this.logger = logger;
        }

        public DirectorySignInResult Validate(string userName, string password)
        {
            string user;
            string domain;
            Split(userName.Trim(), out user, out domain);
            TokenHandle token;
            if (!LogonUser(user, domain, password, LogonNetwork, ProviderDefault, out token))
            {
                var code = Marshal.GetLastWin32Error();
                return new DirectorySignInResult { ErrorCode = code, Error = Message(code) };
            }

            using (token)
            using (var identity = new WindowsIdentity(token.DangerousGetHandle()))
            {
                var groups = new List<string>();
                if (identity.Groups != null)
                {
                    foreach (var sid in identity.Groups)
                    {
                        try
                        {
                            groups.Add(((NTAccount)sid.Translate(typeof(NTAccount))).Value);
                        }
                        catch (SystemException)
                        {
                            // A group whose name cannot be resolved (e.g. from an untrusted domain) cannot grant a role.
                            logger.LogDebug("A group ({Sid}) of {User} has no name.", sid.Value, identity.Name);
                        }
                    }
                }

                return new DirectorySignInResult { Succeeded = true, AccountName = identity.Name, Groups = groups };
            }
        }

        public string AccountKey(string userName)
        {
            string user;
            string domain;
            Split(userName.Trim(), out user, out domain);
            return domain == null ? user : domain + "\\" + user;
        }

        private void Split(string userName, out string user, out string domain)
        {
            var slash = userName.IndexOf('\\');
            if (slash > 0)
            {
                user = userName.Substring(slash + 1);
                domain = userName.Substring(0, slash);
                return;
            }

            user = userName;
            if (userName.IndexOf('@') >= 0)
            {
                domain = null; // a UPN carries its domain
                return;
            }

            domain = string.IsNullOrWhiteSpace(settings.DefaultDomain) ? Environment.UserDomainName : settings.DefaultDomain;
        }

        private static string Message(int code)
        {
            switch (code)
            {
                case ErrorPasswordExpired:
                case ErrorPasswordMustChange:
                    return "Your password has expired or must be changed. Change it in Windows, then sign in again.";
                case ErrorNoLogonServers:
                    return "The domain cannot be reached to check your password. Try again in a moment or contact your administrator.";
                case ErrorLogonTypeNotGranted:
                case ErrorInvalidWorkstation:
                    return "Your account is not allowed to sign in to this server. Contact your administrator.";
                case ErrorLogonFailure:
                case ErrorAccountLockedOut:
                case ErrorAccountDisabled:
                case ErrorAccountExpired:
                case ErrorAccountRestriction:
                case ErrorInvalidLogonHours:
                    // Wrong password, unknown user, locked, disabled, expired or restricted account: one message, so the page
                    // never reveals which user names exist or what state an account is in.
                    return "The user name or password is incorrect, or the account cannot sign in right now.";
                default:
                    return "You could not be signed in. Try again, or contact your administrator if it keeps happening.";
            }
        }

        [DllImport("advapi32.dll", EntryPoint = "LogonUserW", SetLastError = true, CharSet = CharSet.Unicode)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool LogonUser(string userName, string domain, string password, int logonType, int logonProvider, out TokenHandle token);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CloseHandle(IntPtr handle);

        /// <summary>
        /// The Windows logon token, closed when disposed. .NET Framework 4.5.2 has no SafeAccessTokenHandle (4.6); this
        /// does the same for LogonUser's token.
        /// </summary>
        private sealed class TokenHandle : Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            private TokenHandle()
                : base(true)
            {
            }

            protected override bool ReleaseHandle()
            {
                return CloseHandle(handle);
            }
        }
    }
}
