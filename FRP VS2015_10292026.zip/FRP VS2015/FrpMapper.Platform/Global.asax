<%@ Application Codebehind="Global.asax.cs" Inherits="FrpMapper.Platform.Global" Language="C#" %>
