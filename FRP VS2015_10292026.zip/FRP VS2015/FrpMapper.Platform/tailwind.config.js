/** Tailwind build for FrpMapper.Platform. css/tailwind.css is committed, so Visual Studio needs nothing else; rebuild it only
 *  after changing classes in js/*.js, Hosting/*.cs, Site.Master(.cs) or Pages/*.aspx(.cs) (needs Node.js):
 *    npm install && npm run build:css
 *
 * Design tokens: one accent colour, neutral ink/muted/line/surface/canvas, one corner radius (8px),
 * Manrope for display text and Inter for body text.
 */
module.exports = {
  content: ['./js/**/*.js', './Hosting/**/*.cs', './Pages/**/*.aspx', './Pages/**/*.cs', './Site.Master', './Site.Master.cs'],
  theme: {
    extend: {
      colors: {
        accent: { DEFAULT: '#1d4ed8', hover: '#1e40af', soft: '#eff6ff', line: '#bfdbfe' },
        ink: '#0f172a',
        muted: '#475569',
        subtle: '#64748b',
        line: '#e2e8f0',
        surface: '#ffffff',
        canvas: '#f8fafc'
      },
      borderRadius: { app: '8px' },
      fontFamily: {
        display: ['Manrope', 'Inter', 'Arial', 'sans-serif'],
        body: ['Inter', 'Arial', 'Helvetica', 'sans-serif']
      },
      maxWidth: { prose: '70ch' }
    }
  },
  plugins: []
};
