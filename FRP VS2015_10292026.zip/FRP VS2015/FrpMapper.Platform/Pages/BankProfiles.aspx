<%@ Page Language="C#" AutoEventWireup="false" Async="true" ValidateRequest="false" MasterPageFile="~/Site.Master" CodeBehind="BankProfiles.aspx.cs" Inherits="FrpMapper.Platform.WebForms.BankProfiles" %>
<%@ MasterType VirtualPath="~/Site.Master" %>
<asp:Content ID="BankProfilesContent" ContentPlaceHolderID="Main" runat="server">
<div class="px-6 py-8 lg:px-10 lg:py-10">
    <h1 class="font-display text-3xl font-bold text-ink">Bank profiles</h1>
    <p class="mt-2 text-muted">Provider codes, BSP bank details, branches and sandbox reference data. A Maker requests each change; a Checker approves it before it applies.</p>

    <asp:Literal ID="Notices" runat="server" Mode="PassThrough" EnableViewState="false" />

    <asp:PlaceHolder ID="Body" runat="server" Visible="false">

    <%-- ============================================================ changes waiting for a Checker --%>
    <section class="mt-6" aria-labelledby="pending-title">
        <h2 id="pending-title" class="font-display text-xl font-bold text-ink">Waiting for approval</h2>
        <asp:PlaceHolder ID="NothingPending" runat="server">
            <p class="mt-2 text-sm text-muted">Nothing is waiting for approval.</p>
        </asp:PlaceHolder>
        <asp:PlaceHolder ID="PendingList" runat="server">
        <ul class="mt-3 space-y-3">
        <asp:Repeater ID="PendingRequests" runat="server">
            <ItemTemplate>
                <li class="rounded-app border border-amber-200 bg-amber-50/60 p-5">
                    <div class="flex flex-wrap items-start justify-between gap-4">
                        <div class="min-w-0">
                            <p class="font-semibold text-ink">Bank <span class="font-mono"><%# Encode(Eval("BankKey")) %></span><%# (long)Eval("BaseVersion") == 0 ? " (new)" : "" %></p>
                            <p class="mt-1 text-xs text-subtle">Requested by <%# Encode(Eval("RequestedBy")) %> · <%# Encode(FormatDate((DateTimeOffset?)Eval("RequestedAt"), true)) %></p>
                        </div>
                        <div class="flex shrink-0 flex-wrap items-center gap-2">
                            <asp:PlaceHolder ID="Mine" runat="server">
                                <span class="text-xs text-muted">A Checker must approve your change.</span>
                                <asp:Button ID="CancelRequest" runat="server" data-confirm="Cancel your change?" data-confirm-text="The bank profile stays as it is now." data-confirm-label="Cancel change" data-confirm-danger="true" Text="Cancel change" CommandName="cancel" CssClass="rounded-app border border-line bg-surface px-4 py-2 text-sm font-semibold disabled:opacity-50" />
                            </asp:PlaceHolder>
                            <asp:PlaceHolder ID="Waiting" runat="server">
                                <span class="text-xs text-muted">Waiting for a Checker.</span>
                            </asp:PlaceHolder>
                        </div>
                    </div>
                    <div class="mt-3 overflow-x-auto rounded-app border border-line bg-surface">
                        <table class="w-full min-w-[560px] text-left text-sm">
                            <thead class="border-b border-line text-xs font-semibold text-subtle"><tr><th class="px-4 py-2">Field</th><th class="px-4 py-2">Before</th><th class="px-4 py-2">After</th></tr></thead>
                            <tbody>
                                <asp:Repeater ID="Changes" runat="server" EnableViewState="false">
                                    <ItemTemplate>
                                        <tr class="border-b border-line align-top last:border-0"><td class="px-4 py-2 font-semibold text-ink"><%# Encode(Eval("Field")) %></td><td class="px-4 py-2 text-muted"><%# Encode(Eval("Before")) %></td><td class="px-4 py-2 text-ink"><%# Encode(Eval("After")) %></td></tr>
                                    </ItemTemplate>
                                </asp:Repeater>
                            </tbody>
                        </table>
                    </div>
                    <asp:PlaceHolder ID="Review" runat="server">
                        <div class="mt-3 flex flex-wrap items-center gap-2">
                            <asp:Label ID="CommentLabel" runat="server" AssociatedControlID="Comment" CssClass="sr-only" Text="Comment" />
                            <asp:TextBox ID="Comment" runat="server" MaxLength="1000" autocomplete="off" placeholder="Comment (required to reject)" CssClass="h-9 w-72 max-w-full rounded-app border border-line bg-surface px-3 text-sm outline-none focus:border-accent" />
                            <asp:Button ID="Approve" runat="server" data-confirm="Approve this bank profile change?" data-confirm-text="New validations and sample exports use it." data-confirm-label="Approve" Text="Approve" CommandName="approve" CssClass="inline-flex h-9 items-center gap-1.5 rounded-app bg-accent px-3 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50" />
                            <asp:Button ID="Reject" runat="server" data-confirm="Reject this bank profile change?" data-confirm-text="Your comment is sent to the Maker." data-confirm-label="Reject" data-confirm-danger="true" Text="Reject" CommandName="reject" CssClass="inline-flex h-9 items-center gap-1.5 rounded-app bg-red-700 px-3 text-sm font-semibold text-white transition hover:bg-red-800 disabled:opacity-50" />
                        </div>
                    </asp:PlaceHolder>
                </li>
            </ItemTemplate>
        </asp:Repeater>
        </ul>
        </asp:PlaceHolder>
    </section>

    <%-- ============================================================ the bank being viewed or edited --%>
    <div class="mt-8 space-y-6">
        <div class="flex flex-wrap items-end gap-3">
            <label class="block text-sm">Bank
                <asp:DropDownList ID="BankList" runat="server" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" />
            </label>
            <asp:Button ID="OpenBank" runat="server" Text="Open" CssClass="rounded-app border border-line bg-surface px-4 py-2 text-sm font-semibold disabled:opacity-50" />
            <asp:Button ID="AddBank" runat="server" Text="Add bank" CssClass="rounded-app border border-line bg-surface px-4 py-2 text-sm font-semibold disabled:opacity-50" />
        </div>
        <asp:PlaceHolder ID="ReviewOnly" runat="server">
            <p class="text-sm text-muted">You review changes; a Maker requests them.</p>
        </asp:PlaceHolder>
        <asp:PlaceHolder ID="BankPendingNote" runat="server">
            <p class="text-sm font-semibold text-amber-800" role="status">This bank has a change waiting for approval; request a new one after it is decided.</p>
        </asp:PlaceHolder>

        <section class="rounded-app border border-line bg-surface p-6">
            <h2 class="font-display text-xl font-bold">BSP bank details</h2>
            <div class="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <label class="block text-sm">Bank key<asp:TextBox ID="KeyBox" runat="server" MaxLength="32" autocomplete="off" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></label>
                <label class="block text-sm">BSP undertaking name<asp:TextBox ID="NameBox" runat="server" autocomplete="off" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></label>
                <label class="block text-sm">Provider code<asp:TextBox ID="ProviderCodeBox" runat="server" MaxLength="10" inputmode="numeric" autocomplete="off" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></label>
                <label class="block text-sm">BSP API undertaking code<asp:TextBox ID="UndertakingCodeBox" runat="server" MaxLength="20" inputmode="numeric" placeholder="Not set" autocomplete="off" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></label>
                <label class="block text-sm">Bank group<asp:TextBox ID="BankGroupBox" runat="server" placeholder="Unknown" autocomplete="off" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></label>
                <label class="block text-sm">Parent bank group<asp:TextBox ID="ParentBankGroupBox" runat="server" placeholder="Unknown" autocomplete="off" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></label>
                <label class="block text-sm">Subsidiary count<asp:TextBox ID="SubsidiaryCountBox" runat="server" MaxLength="9" inputmode="numeric" autocomplete="off" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></label>
                <label class="block text-sm">Domestic<asp:DropDownList ID="DomesticList" runat="server" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></label>
                <label class="block text-sm">Subsidiary of a foreign bank<asp:DropDownList ID="SubsidiaryForeignList" runat="server" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></label>
                <label class="block text-sm">Branch of a foreign bank<asp:DropDownList ID="BranchForeignList" runat="server" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></label>
                <label class="block text-sm">Trust licence<asp:DropDownList ID="TrustLicenseList" runat="server" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></label>
                <label class="block text-sm">E-money licence<asp:DropDownList ID="EmoneyLicenseList" runat="server" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></label>
            </div>
            <p class="mt-4 text-sm text-muted">Unknown values stay unevaluated. Enter the group codes supplied by BSP; UNI and RB are profile labels.
                The BSP API undertaking code is the code BSP issued for Report API submissions (digits only); BSP submission sends it with this bank's reports.</p>
        </section>

        <section class="rounded-app border border-line bg-surface p-6">
            <h2 class="font-display text-xl font-bold">Branches</h2>
            <p class="mt-2 text-sm text-muted">Excel or CSV: Code, Region, IsDomestic, Name in columns A–D, with a header row. Format codes as text to preserve leading zeros. A branch listed more than once is kept once; the bank's own name is left out of branch names. Import replaces this draft list; submit it for approval to apply.</p>
            <asp:PlaceHolder ID="BranchImport" runat="server">
                <div class="mt-4 flex flex-wrap items-center gap-3">
                    <label class="text-sm">Branch file <asp:FileUpload ID="BranchFile" runat="server" accept=".xlsx,.csv" CssClass="ml-1 text-sm" /></label>
                    <asp:Button ID="ImportBranches" runat="server" Text="Import branches" CssClass="rounded-app border border-line bg-surface px-4 py-2 text-sm font-semibold disabled:opacity-50" />
                </div>
            </asp:PlaceHolder>
            <label class="mt-4 block text-sm"><asp:CheckBox ID="CompleteRegister" runat="server" /> This is the complete BSP branch register</label>
            <p class="mt-2 text-sm"><asp:Literal ID="BranchCount" runat="server" Mode="Encode" EnableViewState="false" /></p>
            <div class="mt-4 max-h-80 overflow-auto">
                <table class="w-full text-left text-sm">
                    <thead><tr><th>Branch code</th><th>Name</th><th>Region</th><th>Domestic</th><th></th></tr></thead>
                    <tbody>
                        <asp:Repeater ID="Branches" runat="server">
                            <ItemTemplate>
                                <tr>
                                    <td><asp:TextBox ID="Code" runat="server" EnableViewState="false" autocomplete="off" aria-label="Branch code" Text='<%# Eval("Code") %>' CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></td>
                                    <td><asp:TextBox ID="BranchName" runat="server" EnableViewState="false" autocomplete="off" aria-label="Branch name" MaxLength="120" Text='<%# Eval("Name") %>' CssClass="mt-1 block w-full min-w-[12rem] rounded-app border border-line bg-surface px-3 py-2 text-sm" /></td>
                                    <td><asp:TextBox ID="Region" runat="server" EnableViewState="false" autocomplete="off" aria-label="Region" Text='<%# Eval("Region") %>' CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" /></td>
                                    <td><asp:CheckBox ID="Domestic" runat="server" EnableViewState="false" Checked='<%# (bool)Eval("IsDomestic") %>' aria-label="Domestic" /></td>
                                    <td><asp:Button ID="RemoveBranch" runat="server" Text="Remove" CommandName="remove" CommandArgument='<%# Container.ItemIndex %>' CssClass="px-2 text-sm font-semibold text-muted hover:text-ink" /></td>
                                </tr>
                            </ItemTemplate>
                        </asp:Repeater>
                    </tbody>
                </table>
            </div>
            <asp:Button ID="AddBranch" runat="server" Text="Add branch" CssClass="mt-4 rounded-app border border-line bg-surface px-4 py-2 text-sm font-semibold disabled:opacity-50" />
        </section>
        <asp:Button ID="SubmitBank" runat="server" data-confirm="Submit this bank profile for approval?" data-confirm-text="A Checker must approve it before it applies." data-confirm-label="Submit for approval" Text="Submit for approval" CssClass="inline-flex h-9 items-center gap-1.5 rounded-app bg-accent px-3 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50" />
    </div>

    <%-- ============================================================ the bank's BSP certificate --%>
    <section class="mt-6 rounded-app border border-line bg-surface p-6" aria-labelledby="certificate-title">
        <h2 id="certificate-title" class="font-display text-xl font-bold">BSP certificate</h2>
        <p class="mt-2 text-sm text-muted">The .pfx BSP submission uses for <asp:Literal ID="CertificateBank" runat="server" Mode="Encode" EnableViewState="false" />, so people do not upload it each time. A Maker uploads it; it is used only after a different Checker approves it. It is stored encrypted and never shown or downloaded again.</p>
        <asp:PlaceHolder ID="CertificateNeedsBank" runat="server">
            <p class="mt-4 text-sm text-muted">Approve this bank profile first; then its certificate can be uploaded.</p>
        </asp:PlaceHolder>
        <asp:PlaceHolder ID="CertificateBody" runat="server">
            <asp:PlaceHolder ID="ActiveCertificate" runat="server">
                <div class="mt-4 rounded-app border border-emerald-200 bg-emerald-50/60 p-5">
                    <p class="flex items-center gap-2 font-semibold text-emerald-900"><i class="ph ph-seal-check text-lg text-emerald-700" aria-hidden="true"></i> In use for BSP submission</p>
                    <asp:Literal ID="ActiveDetails" runat="server" Mode="PassThrough" EnableViewState="false" />
                    <asp:PlaceHolder ID="RemoveCertificateBox" runat="server">
                        <details class="mt-3">
                            <summary class="cursor-pointer text-sm font-semibold text-red-700 hover:underline">Remove…</summary>
                            <div class="mt-3 flex flex-wrap items-center gap-2">
                                <asp:Label ID="RemoveCommentLabel" runat="server" AssociatedControlID="RemoveComment" CssClass="sr-only" Text="Why is it removed?" />
                                <asp:TextBox ID="RemoveComment" runat="server" MaxLength="1000" autocomplete="off" placeholder="Why is it removed? (required)" CssClass="h-9 w-72 max-w-full rounded-app border border-line bg-surface px-3 text-sm outline-none focus:border-accent" />
                                <asp:Button ID="RemoveCertificate" runat="server" data-confirm="Remove the certificate?" data-confirm-text="BSP submission will ask for a PFX with each request for this bank." data-confirm-label="Remove certificate" data-confirm-danger="true" Text="Remove certificate" CssClass="inline-flex h-9 items-center gap-1.5 rounded-app bg-red-700 px-3 text-sm font-semibold text-white transition hover:bg-red-800 disabled:opacity-50" />
                            </div>
                        </details>
                    </asp:PlaceHolder>
                </div>
            </asp:PlaceHolder>
            <asp:PlaceHolder ID="NoActiveCertificate" runat="server">
                <p class="mt-4 text-sm text-muted">No certificate in use. BSP submission asks for a PFX with each request for this bank.</p>
            </asp:PlaceHolder>

            <asp:PlaceHolder ID="PendingCertificate" runat="server">
                <div class="mt-4 rounded-app border border-amber-200 bg-amber-50/60 p-5">
                    <p class="font-semibold text-ink"><asp:Literal ID="PendingTitle" runat="server" Mode="Encode" EnableViewState="false" /></p>
                    <asp:Literal ID="PendingDetails" runat="server" Mode="PassThrough" EnableViewState="false" />
                    <div class="mt-3 flex flex-wrap items-center gap-2">
                        <asp:PlaceHolder ID="PendingMine" runat="server">
                            <span class="text-xs text-muted">A different Checker must approve your upload.</span>
                            <asp:Button ID="CancelCertificate" runat="server" data-confirm="Cancel the certificate upload?" data-confirm-text="The uploaded certificate is discarded." data-confirm-label="Cancel upload" data-confirm-danger="true" Text="Cancel upload" CssClass="rounded-app border border-line bg-surface px-4 py-2 text-sm font-semibold disabled:opacity-50" />
                        </asp:PlaceHolder>
                        <asp:PlaceHolder ID="PendingWaiting" runat="server">
                            <span class="text-xs text-muted">Waiting for a Checker.</span>
                        </asp:PlaceHolder>
                        <asp:PlaceHolder ID="PendingReview" runat="server">
                            <asp:Label ID="CertificateCommentLabel" runat="server" AssociatedControlID="CertificateComment" CssClass="sr-only" Text="Comment" />
                            <asp:TextBox ID="CertificateComment" runat="server" MaxLength="1000" autocomplete="off" placeholder="Comment (required to reject)" CssClass="h-9 w-72 max-w-full rounded-app border border-line bg-surface px-3 text-sm outline-none focus:border-accent" />
                            <asp:Button ID="ApproveCertificate" runat="server" data-confirm="Approve this certificate?" data-confirm-text="BSP submission uses it for this bank from now on." data-confirm-label="Approve" Text="Approve" CssClass="inline-flex h-9 items-center gap-1.5 rounded-app bg-accent px-3 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50" />
                            <asp:Button ID="RejectCertificate" runat="server" data-confirm="Reject this certificate?" data-confirm-text="Your comment is sent to the Maker; the certificate is discarded." data-confirm-label="Reject" data-confirm-danger="true" Text="Reject" CssClass="inline-flex h-9 items-center gap-1.5 rounded-app bg-red-700 px-3 text-sm font-semibold text-white transition hover:bg-red-800 disabled:opacity-50" />
                        </asp:PlaceHolder>
                    </div>
                </div>
            </asp:PlaceHolder>

            <asp:PlaceHolder ID="UploadCertificateBox" runat="server">
                <div class="mt-5 border-t border-line pt-5">
                    <h3 class="font-semibold text-ink"><asp:Literal ID="UploadTitle" runat="server" Mode="Encode" EnableViewState="false" /></h3>
                    <p class="mt-1 text-sm text-muted">The bank's .pfx (or .p12) with its private key, up to 2 MB, and its password. It is checked, encrypted and stored; nobody can download it or see the password again.</p>
                    <div class="mt-3 grid gap-4 md:grid-cols-2">
                        <label class="block text-sm font-semibold">Certificate (.pfx)
                            <asp:FileUpload ID="CertificateFile" runat="server" accept=".pfx,.p12" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" />
                        </label>
                        <label class="block text-sm font-semibold">Certificate password
                            <asp:TextBox ID="CertificatePassword" runat="server" TextMode="Password" autocomplete="new-password" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" />
                        </label>
                    </div>
                    <asp:Button ID="UploadCertificate" runat="server" data-confirm="Upload the certificate for approval?" data-confirm-text="A different Checker must approve it before BSP submission uses it." data-confirm-label="Upload" Text="Upload for approval" CssClass="mt-4 inline-flex h-9 items-center gap-1.5 rounded-app bg-accent px-3 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50" />
                </div>
            </asp:PlaceHolder>

            <asp:PlaceHolder ID="HistoryBox" runat="server">
                <details class="mt-5 text-sm"><summary class="cursor-pointer font-semibold text-muted">Earlier certificates</summary><ul class="mt-2 space-y-1">
                <asp:Repeater ID="CertificateHistory" runat="server" EnableViewState="false">
                    <ItemTemplate><li><%# HistoryLine((FrpMapper.Shared.Models.BankCertificateDto)Container.DataItem) %></li></ItemTemplate>
                </asp:Repeater>
                </ul></details>
            </asp:PlaceHolder>
        </asp:PlaceHolder>
    </section>

    <%-- ============================================================ BSP sandbox result (Makers) --%>
    <asp:PlaceHolder ID="ImportSection" runat="server">
    <section class="mt-6 rounded-app border border-line bg-surface p-6">
        <h2 class="font-display text-xl font-bold">Import BSP sandbox result</h2>
        <p class="mt-2 text-sm text-muted">Choose the project, the text export (.txt) of BSP's sandbox processing result, and the XML submitted to BSP. Preview identifies exact exclusions and historical figures. Saving keeps these scoped to this bank, report version and period.</p>
        <label class="mt-4 block text-sm">Project
            <asp:DropDownList ID="ProjectList" runat="server" CssClass="mt-1 block w-full rounded-app border border-line bg-surface px-3 py-2 text-sm" />
        </label>
        <label class="mt-4 block text-sm">BSP report <asp:FileUpload ID="ReportFile" runat="server" accept=".txt" CssClass="ml-1 text-sm" /></label>
        <label class="mt-4 block text-sm">Submitted XML <asp:FileUpload ID="XmlFile" runat="server" accept=".xml" CssClass="ml-1 text-sm" /></label>
        <asp:Button ID="PreviewImport" runat="server" Text="Preview import" CssClass="mt-4 rounded-app border border-line bg-surface px-4 py-2 text-sm font-semibold disabled:opacity-50" />
        <asp:PlaceHolder ID="ImportPreview" runat="server">
            <div class="mt-4 space-y-3" role="status">
                <asp:Literal ID="PreviewSummary" runat="server" Mode="PassThrough" EnableViewState="false" />
                <details><summary class="cursor-pointer">Review extracted data</summary>
                    <div class="max-h-80 overflow-auto text-sm"><asp:Literal ID="PreviewDetails" runat="server" Mode="PassThrough" EnableViewState="false" /></div>
                </details>
                <asp:Button ID="SaveImport" runat="server" data-confirm="Save the imported BSP reference data?" data-confirm-text="New validations and sample exports will use it." data-confirm-label="Save" Text="Save imported reference data" CssClass="rounded-app border border-line bg-surface px-4 py-2 text-sm font-semibold disabled:opacity-50" />
            </div>
        </asp:PlaceHolder>
        <h3 class="mt-6 font-semibold">Saved imports for <asp:Literal ID="ImportsBank" runat="server" Mode="Encode" EnableViewState="false" /></h3>
        <asp:Repeater ID="SavedImports" runat="server" EnableViewState="false">
            <ItemTemplate><p class="mt-2 text-sm"><%# ImportLine((FrpMapper.Shared.Models.SandboxImportDto)Container.DataItem) %></p></ItemTemplate>
        </asp:Repeater>
    </section>
    </asp:PlaceHolder>

    <%-- ============================================================ recent decisions --%>
    <asp:PlaceHolder ID="DecidedSection" runat="server">
    <section class="mt-8" aria-labelledby="decided-title">
        <h2 id="decided-title" class="font-display text-xl font-bold text-ink">Recent decisions</h2>
        <ul class="mt-3 divide-y divide-line rounded-app border border-line bg-surface">
            <asp:Repeater ID="Decided" runat="server" EnableViewState="false">
                <ItemTemplate>
                    <li class="px-5 py-3 text-sm"><%# DecisionLine((FrpMapper.Shared.Models.BankProfileRequestDto)Container.DataItem) %></li>
                </ItemTemplate>
            </asp:Repeater>
        </ul>
    </section>
    </asp:PlaceHolder>

    </asp:PlaceHolder>
</div>
</asp:Content>
