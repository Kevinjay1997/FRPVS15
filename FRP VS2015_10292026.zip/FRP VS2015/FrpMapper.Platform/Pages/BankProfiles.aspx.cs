using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using FrpMapper.Platform.Hosting;
using FrpMapper.Platform.Services;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;

namespace FrpMapper.Platform.WebForms
{
    /// <summary>
    /// Bank profiles (ASP.NET Web Forms): provider codes, BSP bank details, branches, each bank's BSP certificate and the
    /// imported BSP sandbox results. A Maker (reference.manage) requests each change; a different Checker
    /// (reference.approve) approves it before it applies. Every call goes to the API for the signed-in person
    /// (<see cref="UserApiClient"/>); the API checks the permissions and the segregation of duties itself, and this page
    /// only hides what the person cannot do.
    ///
    /// What is kept between posts (in the view state, MAC-protected and bound to the session): the bank being edited (not
    /// yet submitted), the version of each item a button decides, and the token of the files of a sandbox preview. The
    /// rest is read from the API again for every request, after the button's action, so the page always shows what the
    /// database holds.
    /// </summary>
    public partial class BankProfiles : FrpPage
    {
        private const string DraftKey = "Draft";
        private const string SubsidiaryTextKey = "SubsidiaryText";
        private const string ActiveCertificateKey = "ActiveCertificate";
        private const string PendingCertificateKey = "PendingCertificate";
        private const string ImportTokenKey = "ImportToken";
        private const string ImportBankKey = "ImportBank";
        private const string ImportProjectKey = "ImportProject";

        private bool canMake;
        private bool canCheck;
        private ReferenceDataDto data;
        private List<BankCertificateDto> certificates = new List<BankCertificateDto>();
        private List<ProjectSummaryDto> projects = new List<ProjectSummaryDto>();
        private SandboxImportDto preview;
        private string selectKey;
        private string error;
        private string message;

        /// <summary>The bank being viewed or edited (kept between posts until it is submitted or another bank is opened).</summary>
        private BankProfileDto Draft
        {
            get
            {
                var json = ViewState[DraftKey] as string;
                return json == null ? null : JsonSerializer.Deserialize<BankProfileDto>(json, ApiConnection.Json);
            }

            set
            {
                ViewState[DraftKey] = value == null ? null : JsonSerializer.Serialize(value, ApiConnection.Json);
            }
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            PendingRequests.ItemDataBound += PendingRequests_ItemDataBound;
            PendingRequests.ItemCommand += PendingRequests_ItemCommand;
            Branches.ItemCommand += Branches_ItemCommand;
            OpenBank.Click += OpenBank_Click;
            AddBank.Click += AddBank_Click;
            ImportBranches.Click += ImportBranches_Click;
            AddBranch.Click += AddBranch_Click;
            SubmitBank.Click += SubmitBank_Click;
            UploadCertificate.Click += UploadCertificate_Click;
            CancelCertificate.Click += (s, a) => DecideCertificate(PendingCertificateKey, "cancel", null);
            ApproveCertificate.Click += (s, a) => DecideCertificate(PendingCertificateKey, "approve", CertificateComment.Text);
            RejectCertificate.Click += (s, a) => DecideCertificate(PendingCertificateKey, "reject", CertificateComment.Text);
            RemoveCertificate.Click += (s, a) => DecideCertificate(ActiveCertificateKey, "remove", RemoveComment.Text);
            PreviewImport.Click += PreviewImport_Click;
            SaveImport.Click += SaveImport_Click;
            foreach (var list in YesNoLists())
            {
                list.Items.Add(new ListItem("Unknown", ""));
                list.Items.Add(new ListItem("Yes", "true"));
                list.Items.Add(new ListItem("No", "false"));
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Master.PageTitle = "Bank profiles";
            Master.ActiveLink = PlatformPipeline.BankProfilesPage;
            canMake = Can(Permissions.ReferenceManage);
            canCheck = Can(Permissions.ReferenceApprove);
            if (IsPostBack && canMake && Draft != null)
            {
                // What the Maker typed is kept whichever button was pressed.
                Draft = ReadEditor(Draft);
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            if (!canMake && !canCheck)
            {
                Notices.Text = Notice("Warning", "Not available to your role", "Only the Makers and Checkers of bank profiles can open this page.");
                Body.Visible = false;
                return;
            }

            // After the button's own action (registered first), read everything again and draw it.
            RunAsync(RefreshAsync);
        }

        // ---------------------------------------------------------------- bank profile changes

        private void PendingRequests_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            var request = e.Item.DataItem as BankProfileRequestDto;
            if (request == null)
            {
                return;
            }

            var mine = SameName(request.RequestedBy, Person.User.Name);
            var argument = request.Id + "|" + request.Version + "|" + request.BankKey;
            e.Item.FindControl("Mine").Visible = mine;
            var cancel = (Button)e.Item.FindControl("CancelRequest");
            cancel.Visible = canMake;
            cancel.CommandArgument = argument;
            e.Item.FindControl("Waiting").Visible = !mine && !canCheck;
            e.Item.FindControl("Review").Visible = !mine && canCheck;
            ((Button)e.Item.FindControl("Approve")).CommandArgument = argument;
            ((Button)e.Item.FindControl("Reject")).CommandArgument = argument;
            var changes = (Repeater)e.Item.FindControl("Changes");
            changes.DataSource = request.Changes;
            changes.DataBind();
        }

        private void PendingRequests_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            var decision = e.CommandName;
            string id, rest, version, bankKey;
            if ((decision != "approve" && decision != "reject" && decision != "cancel")
                || !Split(e.CommandArgument as string, out id, out rest) || !Split(rest, out version, out bankKey))
            {
                return;
            }

            var commentBox = e.Item.FindControl("Comment") as TextBox;
            var comment = decision == "cancel" || commentBox == null ? null : NullIfBlank(commentBox.Text);
            RunAsync(cancellation => ActAsync(async () =>
            {
                var done = await Api.PostJsonNoContentAsync("/api/reference/banks/requests/" + Uri.EscapeDataString(id) + "/" + decision,
                    new AccessDecisionRequest { Version = version, Comment = comment }, Person, cancellation);
                if (!done)
                {
                    throw new ApiException(System.Net.HttpStatusCode.NotFound, "The change is no longer waiting for a decision. Reload the page.");
                }

                selectKey = bankKey;
                message = decision == "approve" ? "Approved: bank " + bankKey + ". New validations and sample exports use it."
                    : decision == "reject" ? "Rejected: bank " + bankKey + "."
                    : "Cancelled your change to bank " + bankKey + ".";
            }));
        }

        private void OpenBank_Click(object sender, EventArgs e)
        {
            selectKey = BankList.SelectedValue;
            ForgetImport();
        }

        private void AddBank_Click(object sender, EventArgs e)
        {
            if (canMake)
            {
                Draft = NewBank();
                ViewState[SubsidiaryTextKey] = null;
                ForgetImport();
            }
        }

        private void AddBranch_Click(object sender, EventArgs e)
        {
            var draft = Draft;
            if (canMake && draft != null)
            {
                draft.Branches.Add(new BankBranchDto { Code = "", Region = "", IsDomestic = true, Name = "" });
                Draft = draft;
            }
        }

        private void Branches_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            int index;
            var draft = Draft;
            if (canMake && draft != null && e.CommandName == "remove"
                && int.TryParse(e.CommandArgument as string, NumberStyles.None, CultureInfo.InvariantCulture, out index) && index >= 0 && index < draft.Branches.Count)
            {
                draft.Branches.RemoveAt(index);
                Draft = draft;
            }
        }

        private void ImportBranches_Click(object sender, EventArgs e)
        {
            if (!canMake)
            {
                return;
            }

            if (!BranchFile.HasFile)
            {
                error = "Choose a branch file (Excel or CSV).";
                return;
            }

            var file = new UploadedFile("file", BranchFile.FileName, BranchFile.FileBytes);
            RunAsync(cancellation => ActAsync(async () =>
            {
                var branches = await Api.PostFormAsync<List<BankBranchDto>>("/api/reference/branches", null, new[] { file }, Person, cancellation);
                var draft = Draft;
                // Names are kept without the bank's own name ("EAST WEST BANKING CORP -168 MALL" is "168 MALL").
                draft.Branches = branches.Select(b => new BankBranchDto { Code = b.Code, Region = b.Region, IsDomestic = b.IsDomestic, Name = BankBranchNames.Short(b.Name, draft.Name) }).ToList();
                draft.BranchRegisterComplete = false;
                Draft = draft;
                message = branches.Count + " branches imported into this draft. Submit it for approval to apply.";
            }));
        }

        private void SubmitBank_Click(object sender, EventArgs e)
        {
            var draft = Draft;
            if (!canMake || draft == null)
            {
                return;
            }

            if (ViewState[SubsidiaryTextKey] != null)
            {
                error = "Subsidiary count must be a whole number (0 or more), or empty when unknown.";
                return;
            }

            RunAsync(cancellation => ActAsync(async () =>
            {
                var request = await Api.PostJsonAsync<BankProfileRequestDto>("/api/reference/banks/requests", draft, Person, cancellation);
                selectKey = request.BankKey;
                message = "Sent for approval: " + request.Summary + " A Checker must approve it before it applies.";
            }));
        }

        // ---------------------------------------------------------------- the bank's BSP certificate

        private void UploadCertificate_Click(object sender, EventArgs e)
        {
            var draft = Draft;
            if (!canMake || draft == null || draft.Version == 0)
            {
                return;
            }

            if (!CertificateFile.HasFile)
            {
                error = "Choose the bank's PFX certificate.";
                return;
            }

            var bankKey = draft.Key;
            var password = CertificatePassword.Text;
            var file = new UploadedFile("certificate", CertificateFile.FileName, CertificateFile.FileBytes);
            RunAsync(cancellation => ActAsync(async () =>
            {
                var fields = new Dictionary<string, string> { { "bank", bankKey }, { "password", password } };
                var certificate = await Api.PostFormAsync<BankCertificateDto>("/api/reference/certificates", fields, new[] { file }, Person, cancellation);
                message = "Certificate for " + bankKey + " sent for approval: " + certificate.Subject + ". A different Checker must approve it before BSP submission uses it.";
            }));
        }

        private void DecideCertificate(string which, string decision, string comment)
        {
            string id, version;
            if (!Split(ViewState[which] as string, out id, out version))
            {
                return;
            }

            var bankKey = Draft == null ? "" : Draft.Key;
            RunAsync(cancellation => ActAsync(async () =>
            {
                var done = await Api.PostJsonNoContentAsync("/api/reference/certificates/" + Uri.EscapeDataString(id) + "/" + decision,
                    new AccessDecisionRequest { Version = version, Comment = NullIfBlank(comment) }, Person, cancellation);
                if (!done)
                {
                    throw new ApiException(System.Net.HttpStatusCode.NotFound, "The certificate is no longer waiting for this decision. Reload the page.");
                }

                CertificateComment.Text = "";
                RemoveComment.Text = "";
                message = decision == "approve" ? "Approved: BSP submission now uses this certificate for " + bankKey + "."
                    : decision == "reject" ? "Rejected the certificate for " + bankKey + "."
                    : decision == "remove" ? "Removed the certificate of " + bankKey + ". BSP submission now needs a PFX uploaded with each request for this bank."
                    : "Cancelled your certificate upload for " + bankKey + ".";
            }));
        }

        // ---------------------------------------------------------------- BSP sandbox result

        private void PreviewImport_Click(object sender, EventArgs e)
        {
            var draft = Draft;
            if (!canMake || draft == null)
            {
                return;
            }

            ForgetImport();
            var project = ProjectList.SelectedValue;
            if (draft.Version == 0 || string.IsNullOrEmpty(project) || !ReportFile.HasFile || !XmlFile.HasFile)
            {
                error = draft.Version == 0 ? "Approve this bank profile first; then BSP results can be imported for it."
                    : "Choose the project, the BSP report (.txt) and the submitted XML.";
                return;
            }

            var files = new List<UploadedFile>
            {
                new UploadedFile("report", ReportFile.FileName, ReportFile.FileBytes),
                new UploadedFile("xml", XmlFile.FileName, XmlFile.FileBytes)
            };
            var bankKey = draft.Key;
            RunAsync(cancellation => ActAsync(async () =>
            {
                preview = await ImportAsync(bankKey, project, files, false, cancellation);
                ViewState[ImportTokenKey] = Services.GetRequiredService<PendingUploads>().Keep(Person.User.Name, files);
                ViewState[ImportBankKey] = bankKey;
                ViewState[ImportProjectKey] = project;
            }));
        }

        private void SaveImport_Click(object sender, EventArgs e)
        {
            var token = ViewState[ImportTokenKey] as string;
            var bankKey = ViewState[ImportBankKey] as string;
            var project = ViewState[ImportProjectKey] as string;
            var files = canMake ? Services.GetRequiredService<PendingUploads>().Find(token, Person.User.Name) : null;
            if (files == null || bankKey == null || project == null)
            {
                ForgetImport();
                error = "The preview has expired. Choose the files and preview the import again.";
                return;
            }

            RunAsync(cancellation => ActAsync(async () =>
            {
                await ImportAsync(bankKey, project, files, true, cancellation);
                ForgetImport();
                message = "BSP reference data saved. New validations and sample exports will use it.";
            }));
        }

        private Task<SandboxImportDto> ImportAsync(string bankKey, string project, IReadOnlyList<UploadedFile> files, bool save, CancellationToken cancellation)
        {
            var fields = new Dictionary<string, string> { { "bank", bankKey }, { "project", project }, { "save", save ? "true" : "false" } };
            return Api.PostFormAsync<SandboxImportDto>("/api/reference/sandbox", fields, files, Person, cancellation);
        }

        private void ForgetImport()
        {
            Services.GetRequiredService<PendingUploads>().Forget(ViewState[ImportTokenKey] as string);
            ViewState[ImportTokenKey] = null;
            ViewState[ImportBankKey] = null;
            ViewState[ImportProjectKey] = null;
            preview = null;
        }

        // ---------------------------------------------------------------- reading and drawing

        private async Task RefreshAsync(CancellationToken cancellation)
        {
            try
            {
                data = await Api.GetAsync<ReferenceDataDto>("/api/reference", Person, cancellation);
                certificates = await Api.GetAsync<List<BankCertificateDto>>("/api/reference/certificates", Person, cancellation);
                projects = canMake ? await Api.GetAsync<List<ProjectSummaryDto>>("/api/projects", Person, cancellation) : new List<ProjectSummaryDto>();
            }
            catch (Exception ex) when (ex is ApiException || ex is ApiUnavailableException)
            {
                error = ex.Message;
                data = null;
            }

            if (data == null)
            {
                Body.Visible = false;
                ShowNotices();
                return;
            }

            var draft = Draft;
            if (selectKey != null || draft == null)
            {
                // Open the bank (after a decision or a submit: as the database holds it now), else the first one.
                var bank = data.Banks.FirstOrDefault(b => b.Key == selectKey) ?? (draft == null || selectKey != null ? data.Banks.FirstOrDefault() : null);
                draft = bank == null ? NewBank() : Copy(bank);
                ViewState[SubsidiaryTextKey] = null;
                Draft = draft;
            }

            Body.Visible = true;
            BindPending();
            BindEditor(draft);
            BindCertificates(draft);
            BindImports(draft);
            Decided.DataSource = data.Requests.Where(r => r.Status != "Pending").Take(20).ToList();
            Decided.DataBind();
            DecidedSection.Visible = Decided.Items.Count > 0;
            ShowNotices();
        }

        private void BindPending()
        {
            var pending = data.Requests.Where(r => r.Status == "Pending").ToList();
            NothingPending.Visible = pending.Count == 0;
            PendingRequests.DataSource = pending;
            PendingRequests.DataBind();
            PendingList.Visible = pending.Count > 0;
        }

        private void BindEditor(BankProfileDto draft)
        {
            BankList.Items.Clear();
            if (draft.Version == 0 && !data.Banks.Any(b => b.Key == draft.Key))
            {
                BankList.Items.Add(new ListItem("New bank (not yet approved)", ""));
            }

            foreach (var bank in data.Banks)
            {
                BankList.Items.Add(new ListItem(bank.Key + " · " + bank.ProviderCode, bank.Key));
            }

            var selected = BankList.Items.FindByValue(draft.Version == 0 && !data.Banks.Any(b => b.Key == draft.Key) ? "" : draft.Key);
            if (selected != null)
            {
                BankList.ClearSelection();
                selected.Selected = true;
            }

            BankList.Attributes["data-submit"] = OpenBank.ClientID;
            AddBank.Visible = canMake;
            ReviewOnly.Visible = !canMake;
            var bankPending = data.Requests.Any(r => r.Status == "Pending" && r.BankKey == draft.Key && draft.Key.Length > 0);
            BankPendingNote.Visible = bankPending && canMake;

            KeyBox.Text = draft.Key;
            NameBox.Text = draft.Name;
            ProviderCodeBox.Text = draft.ProviderCode;
            UndertakingCodeBox.Text = draft.BspUndertakingCode ?? "";
            BankGroupBox.Text = draft.BankGroup ?? "";
            ParentBankGroupBox.Text = draft.ParentBankGroup ?? "";
            SubsidiaryCountBox.Text = ViewState[SubsidiaryTextKey] as string
                ?? (draft.SubsidiaryCount == null ? "" : draft.SubsidiaryCount.Value.ToString(CultureInfo.InvariantCulture));
            SetYesNo(DomesticList, draft.IsDomestic);
            SetYesNo(SubsidiaryForeignList, draft.IsSubsidiaryForeign);
            SetYesNo(BranchForeignList, draft.IsBranchForeign);
            SetYesNo(TrustLicenseList, draft.HasTrustLicense);
            SetYesNo(EmoneyLicenseList, draft.HasEmoneyLicense);
            CompleteRegister.Checked = draft.BranchRegisterComplete;
            BranchCount.Text = draft.Branches.Count + (draft.Branches.Count == 1 ? " branch" : " branches");
            Branches.DataSource = draft.Branches;
            Branches.DataBind();

            // Only a Maker edits; the bank key of an approved bank never changes.
            foreach (var box in new[] { KeyBox, NameBox, ProviderCodeBox, UndertakingCodeBox, BankGroupBox, ParentBankGroupBox, SubsidiaryCountBox })
            {
                box.Enabled = canMake;
            }

            KeyBox.Enabled = canMake && draft.Version == 0;
            foreach (var list in YesNoLists())
            {
                list.Enabled = canMake;
            }

            CompleteRegister.Enabled = canMake;
            foreach (RepeaterItem item in Branches.Items)
            {
                ((TextBox)item.FindControl("Code")).Enabled = canMake;
                ((TextBox)item.FindControl("Region")).Enabled = canMake;
                ((TextBox)item.FindControl("BranchName")).Enabled = canMake;
                ((CheckBox)item.FindControl("Domestic")).Enabled = canMake;
                item.FindControl("RemoveBranch").Visible = canMake;
            }

            BranchImport.Visible = canMake;
            AddBranch.Visible = canMake;
            SubmitBank.Visible = canMake;
            SubmitBank.Enabled = !bankPending;
        }

        private void BindCertificates(BankProfileDto draft)
        {
            ViewState[ActiveCertificateKey] = null;
            ViewState[PendingCertificateKey] = null;
            CertificateBank.Text = draft.Key.Length > 0 ? draft.Key : "this bank";
            CertificateNeedsBank.Visible = draft.Version == 0;
            CertificateBody.Visible = draft.Version > 0;
            if (draft.Version == 0)
            {
                return;
            }

            var forBank = certificates.Where(c => c.BankKey == draft.Key).ToList();
            var active = forBank.FirstOrDefault(c => c.Status == BankCertificateStatus.Active);
            var pending = forBank.FirstOrDefault(c => c.Status == BankCertificateStatus.Pending);
            var history = forBank.Where(c => c.Status != BankCertificateStatus.Active && c.Status != BankCertificateStatus.Pending).Take(5).ToList();

            ActiveCertificate.Visible = active != null;
            NoActiveCertificate.Visible = active == null;
            if (active != null)
            {
                ActiveDetails.Text = CertificateDetails(active);
                RemoveCertificateBox.Visible = canCheck;
                ViewState[ActiveCertificateKey] = active.Id + "|" + active.Version;
            }

            PendingCertificate.Visible = pending != null;
            if (pending != null)
            {
                var mine = SameName(pending.RequestedBy, Person.User.Name);
                PendingTitle.Text = "Waiting for approval" + (active != null ? " (replaces the certificate in use)" : "");
                PendingDetails.Text = CertificateDetails(pending);
                PendingMine.Visible = mine;
                CancelCertificate.Visible = mine && canMake;
                PendingWaiting.Visible = !mine && !canCheck;
                PendingReview.Visible = !mine && canCheck;
                ViewState[PendingCertificateKey] = pending.Id + "|" + pending.Version;
            }

            UploadCertificateBox.Visible = canMake && pending == null;
            UploadTitle.Text = active != null ? "Upload a replacement" : "Upload the certificate";
            CertificateHistory.DataSource = history;
            CertificateHistory.DataBind();
            HistoryBox.Visible = history.Count > 0;
        }

        private void BindImports(BankProfileDto draft)
        {
            ImportSection.Visible = canMake;
            if (!canMake)
            {
                return;
            }

            var chosen = ProjectList.SelectedValue;
            ProjectList.Items.Clear();
            ProjectList.Items.Add(new ListItem("Choose project", ""));
            foreach (var project in projects)
            {
                ProjectList.Items.Add(new ListItem(project.Name, project.Id));
            }

            var keep = ProjectList.Items.FindByValue(chosen ?? "");
            if (keep != null)
            {
                ProjectList.ClearSelection();
                keep.Selected = true;
            }

            ImportPreview.Visible = preview != null;
            if (preview != null)
            {
                PreviewSummary.Text = PreviewSummaryHtml(preview);
                PreviewDetails.Text = PreviewDetailsHtml(preview);
            }

            ImportsBank.Text = draft.Key;
            SavedImports.DataSource = data.Imports.Where(i => i.BankKey == draft.Key).OrderByDescending(i => i.ImportedAt).ToList();
            SavedImports.DataBind();
        }

        /// <summary>The bank fields and branch rows as posted, on top of the draft (the bank key of an approved bank stays).</summary>
        private BankProfileDto ReadEditor(BankProfileDto draft)
        {
            if (draft.Version == 0)
            {
                draft.Key = KeyBox.Text.Trim();
            }

            draft.Name = NameBox.Text;
            draft.ProviderCode = ProviderCodeBox.Text;
            draft.BspUndertakingCode = NullIfBlank(UndertakingCodeBox.Text);
            draft.BankGroup = NullIfBlank(BankGroupBox.Text);
            draft.ParentBankGroup = NullIfBlank(ParentBankGroupBox.Text);
            var subsidiary = SubsidiaryCountBox.Text.Trim();
            int count;
            if (subsidiary.Length == 0)
            {
                draft.SubsidiaryCount = null;
                ViewState[SubsidiaryTextKey] = null;
            }
            else if (int.TryParse(subsidiary, NumberStyles.None, CultureInfo.InvariantCulture, out count))
            {
                draft.SubsidiaryCount = count;
                ViewState[SubsidiaryTextKey] = null;
            }
            else
            {
                // Kept as typed, so the Maker sees what to correct; the request is not sent until it is a number.
                ViewState[SubsidiaryTextKey] = subsidiary;
            }

            draft.IsDomestic = YesNo(DomesticList);
            draft.IsSubsidiaryForeign = YesNo(SubsidiaryForeignList);
            draft.IsBranchForeign = YesNo(BranchForeignList);
            draft.HasTrustLicense = YesNo(TrustLicenseList);
            draft.HasEmoneyLicense = YesNo(EmoneyLicenseList);
            draft.BranchRegisterComplete = CompleteRegister.Checked;
            if (Branches.Items.Count == draft.Branches.Count)
            {
                draft.Branches = Branches.Items.Cast<RepeaterItem>().Select(item => new BankBranchDto
                {
                    Code = ((TextBox)item.FindControl("Code")).Text,
                    Region = ((TextBox)item.FindControl("Region")).Text,
                    IsDomestic = ((CheckBox)item.FindControl("Domestic")).Checked,
                    Name = ((TextBox)item.FindControl("BranchName")).Text
                }).ToList();
            }

            return draft;
        }

        private async Task ActAsync(Func<Task> action)
        {
            try
            {
                await action();
            }
            catch (ApiException ex)
            {
                error = ex.Message;
            }
            catch (ApiUnavailableException ex)
            {
                error = ex.Message;
            }
        }

        private void ShowNotices()
        {
            var html = new StringBuilder();
            // Shown as a toast by js/webforms.js (the app's default for what happened); without script, as a notice.
            if (error != null)
            {
                html.Append("<div class=\"mt-4\" data-toast=\"Error\" data-toast-text=\"").Append(Encode(error)).Append("\">").Append(Notice("Error", null, error)).Append("</div>");
            }

            if (message != null)
            {
                html.Append("<div class=\"mt-4\" data-toast=\"Success\" data-toast-text=\"").Append(Encode(message)).Append("\">").Append(Notice("Success", null, message)).Append("</div>");
            }

            Notices.Text = html.ToString();
        }

        // ---------------------------------------------------------------- text the markup shows (always encoded)

        protected string HistoryLine(BankCertificateDto c)
        {
            return "<span class=\"font-semibold\">" + Encode(c.Status) + "</span> · " + Encode(c.Subject) + " · valid until " + Encode(FormatDate(c.ValidUntil, false))
                + " · uploaded by " + Encode(c.RequestedBy) + (c.DecidedBy != null ? ", " + Encode(c.Status.ToLowerInvariant()) + " by " + Encode(c.DecidedBy) : "")
                + (string.IsNullOrEmpty(c.DecisionComment) ? "" : " · “" + Encode(c.DecisionComment) + "”");
        }

        protected string ImportLine(SandboxImportDto item)
        {
            return Encode(item.Report) + " · " + Encode(item.Period) + " · " + Encode(item.FileName) + " · " + item.Exclusions.Count + " exclusions / "
                + item.HistoricalValues.Count + " historical values";
        }

        protected string DecisionLine(BankProfileRequestDto request)
        {
            return "<span class=\"font-semibold " + (request.Status == "Approved" ? "text-emerald-700" : "text-muted") + "\">" + Encode(request.Status) + "</span>"
                + "<span class=\"font-mono text-ink\"> " + Encode(request.BankKey) + "</span> — " + Encode(request.Summary)
                + "<span class=\"block text-xs text-subtle\">Requested by " + Encode(request.RequestedBy) + "; " + Encode((request.Status ?? "").ToLowerInvariant()) + " by "
                + Encode(request.DecidedBy) + " " + Encode(FormatDate(request.DecidedAt, true))
                + (string.IsNullOrEmpty(request.DecisionComment) ? "" : " · “" + Encode(request.DecisionComment) + "”") + "</span>";
        }

        private static string CertificateDetails(BankCertificateDto c)
        {
            var now = DateTime.UtcNow;
            var days = (int)Math.Floor((c.ValidUntil - now).TotalDays);
            var expiry = c.ValidUntil <= now ? " <span class=\"font-semibold text-red-700\">Expired</span>"
                : days < 30 ? " <span class=\"font-semibold text-amber-800\">Expires in " + days + " day" + (days == 1 ? "" : "s") + "</span>" : "";
            var html = new StringBuilder("<dl class=\"mt-3 grid grid-cols-[auto_minmax(0,1fr)] gap-x-6 gap-y-1 text-sm\">");
            html.Append("<dt class=\"text-subtle\">Subject</dt><dd class=\"min-w-0 break-words text-ink\">").Append(Encode(c.Subject)).Append("</dd>")
                .Append("<dt class=\"text-subtle\">Issuer</dt><dd class=\"min-w-0 break-words text-ink\">").Append(Encode(c.Issuer)).Append("</dd>")
                .Append("<dt class=\"text-subtle\">Valid</dt><dd class=\"text-ink\">").Append(Encode(FormatDate(c.ValidFrom, false))).Append(" – ")
                .Append(Encode(FormatDate(c.ValidUntil, false))).Append(expiry).Append("</dd>")
                .Append("<dt class=\"text-subtle\">Thumbprint</dt><dd class=\"min-w-0 break-all font-mono text-xs text-ink\">").Append(Encode(c.Thumbprint)).Append("</dd>")
                .Append("<dt class=\"text-subtle\">File</dt><dd class=\"min-w-0 truncate text-ink\">").Append(Encode(c.FileName)).Append("</dd>")
                .Append("<dt class=\"text-subtle\">Uploaded</dt><dd class=\"text-ink\">").Append(Encode(c.RequestedBy)).Append(" · ").Append(Encode(FormatDate(c.RequestedAt, true))).Append("</dd>");
            if (c.DecidedBy != null)
            {
                html.Append("<dt class=\"text-subtle\">Approved</dt><dd class=\"text-ink\">").Append(Encode(c.DecidedBy)).Append(" · ").Append(Encode(FormatDate(c.DecidedAt, true))).Append("</dd>");
            }

            return html.Append("</dl>").ToString();
        }

        private static string PreviewSummaryHtml(SandboxImportDto p)
        {
            var html = new StringBuilder();
            html.Append("<p><strong>").Append(Encode(p.Report)).Append(" · ").Append(Encode(p.Period)).Append(" · ").Append(Encode(p.ProviderCode)).Append("</strong></p>")
                .Append("<p>").Append(p.FindingCount).Append(" findings; ").Append(p.Exclusions.Count).Append(" field exclusions; ")
                .Append(p.HistoricalValues.Count).Append(" historical expressions.</p>");
            foreach (var warning in p.Warnings)
            {
                html.Append("<p class=\"text-sm\">").Append(Encode(warning)).Append("</p>");
            }

            return html.ToString();
        }

        private static string PreviewDetailsHtml(SandboxImportDto p)
        {
            var html = new StringBuilder();
            foreach (var item in p.Exclusions)
            {
                html.Append("<p>").Append(Encode(item.Reference)).Append(" — do not report</p>");
            }

            foreach (var item in p.HistoricalValues)
            {
                html.Append("<p>").Append(Encode(item.RuleCode)).Append(": ").Append(Encode(item.Formula)).Append(" = ")
                    .Append(Encode(item.Value.ToString("N2", CultureInfo.InvariantCulture))).Append("</p>");
            }

            return html.ToString();
        }

        /// <summary>An inline message as the other screens show it (js/components.js notice). kind: Success, Warning, Error.</summary>
        private static string Notice(string kind, string title, string body)
        {
            var classes = kind == "Success" ? "border-emerald-200 bg-emerald-50 text-emerald-900"
                : kind == "Warning" ? "border-amber-200 bg-amber-50 text-amber-900"
                : kind == "Error" ? "border-red-200 bg-red-50 text-red-900" : "border-accent-line bg-accent-soft text-ink";
            var icon = kind == "Success" ? "ph-check-circle text-emerald-700"
                : kind == "Warning" ? "ph-warning text-amber-700"
                : kind == "Error" ? "ph-x-circle text-red-700" : "ph-info text-accent";
            return "<div class=\"flex gap-3 rounded-app border px-4 py-3 text-sm leading-6 " + classes + "\" role=\"" + (kind == "Error" || kind == "Warning" ? "alert" : "status") + "\">"
                + "<i class=\"ph " + icon + " mt-0.5 text-lg\" aria-hidden=\"true\"></i><div class=\"min-w-0 max-w-prose\">"
                + (title == null ? "" : "<p class=\"font-semibold\">" + Encode(title) + "</p>") + Encode(body) + "</div></div>";
        }

        // ---------------------------------------------------------------- small helpers

        private IEnumerable<DropDownList> YesNoLists()
        {
            return new[] { DomesticList, SubsidiaryForeignList, BranchForeignList, TrustLicenseList, EmoneyLicenseList };
        }

        private static void SetYesNo(DropDownList list, bool? value)
        {
            list.ClearSelection();
            list.Items.FindByValue(value == true ? "true" : value == false ? "false" : "").Selected = true;
        }

        private static bool? YesNo(DropDownList list)
        {
            return list.SelectedValue == "true" ? true : list.SelectedValue == "false" ? (bool?)false : null;
        }

        private static string NullIfBlank(string text)
        {
            return string.IsNullOrWhiteSpace(text) ? null : text.Trim();
        }

        private static bool Split(string argument, out string id, out string version)
        {
            id = version = null;
            var bar = argument == null ? -1 : argument.IndexOf('|');
            if (bar <= 0)
            {
                return false;
            }

            id = argument.Substring(0, bar);
            version = argument.Substring(bar + 1);
            return true;
        }

        private static BankProfileDto NewBank()
        {
            return new BankProfileDto { Key = "", Name = "", ProviderCode = "", BranchRegisterComplete = false, Branches = new List<BankBranchDto>(), Version = 0 };
        }

        private static BankProfileDto Copy(BankProfileDto bank)
        {
            var copy = JsonSerializer.Deserialize<BankProfileDto>(JsonSerializer.Serialize(bank, ApiConnection.Json), ApiConnection.Json);
            copy.Branches = (copy.Branches ?? new List<BankBranchDto>()).Select(b => new BankBranchDto { Code = b.Code, Region = b.Region, IsDomestic = b.IsDomestic, Name = b.Name ?? "" }).ToList();
            return copy;
        }
    }
}
