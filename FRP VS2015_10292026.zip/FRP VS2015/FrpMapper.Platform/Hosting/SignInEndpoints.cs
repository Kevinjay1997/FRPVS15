using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using FrpMapper.Platform.Security;
using FrpMapper.Platform.Services;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Platform.Hosting
{
    /// <summary>
    /// The sign-in page. Authentication:Mode = ActiveDirectory: an Active Directory user name and password, checked by
    /// Windows with the domain controller. Authentication:Mode = Development: the test users in the database
    /// (frp.DevelopmentUser, read through the API). In Windows mode this page does not exist (Windows signs people in).
    /// </summary>
    public static class SignInEndpoints
    {
        private const int WrongUserNameOrPassword = 1326;
        private const string UnavailableMessage = "Your sign-in could not be checked because the FRP Mapper API cannot be reached. Try again in a moment.";

        public static async Task HandleAsync(HttpContextBase context, ServiceProvider services, PlatformSettings settings, CancellationToken cancellation)
        {
            var request = context.Request;
            var view = new SignInView
            {
                Mode = settings.Mode,
                Notice = settings.SignInNotice,
                ReturnUrl = request.HttpMethod == "POST" ? request.Unvalidated.Form["ReturnUrl"] : request.QueryString["ReturnUrl"]
            };

            if (request.HttpMethod != "POST")
            {
                view.SignedOutMessage = SignedOutMessage(PlatformPipeline.SignedOutReason(context), settings);
                view.AntiforgeryToken = PlatformPipeline.AntiforgeryToken(context, true);
                if (settings.Mode == AuthenticationMode.ActiveDirectory)
                {
                    bool expired;
                    var current = services.GetRequiredService<SessionStore>().Find(Http.Cookie(context, PlatformPipeline.SessionCookie(settings)), out expired);
                    if (current != null)
                    {
                        Http.Redirect(context, SafeReturnUrl(context, view.ReturnUrl));
                        return;
                    }
                }
                else
                {
                    await LoadUsersAsync(services, view, cancellation);
                }

                await WriteAsync(context, 200, view);
                return;
            }

            // Every sign-in form carries the page's token (the cookie and the field must match).
            var form = request.Unvalidated.Form;
            var expected = PlatformPipeline.AntiforgeryToken(context, false);
            if (expected == null || !SessionStore.SameToken(expected, form["__RequestVerificationToken"]))
            {
                await Http.WriteHtmlAsync(context, 400, Pages.FormExpired(context, PlatformApplication.Versions));
                return;
            }

            view.AntiforgeryToken = expected;
            if (settings.Mode == AuthenticationMode.Development)
            {
                await DevelopmentSignInAsync(context, services, view, form["userName"], cancellation);
                return;
            }

            if (request.QueryString["handler"] != "Directory")
            {
                await Http.WriteTextAsync(context, 404, "text/plain; charset=utf-8", "Not found.");
                return;
            }

            await DirectorySignInAsync(context, services, settings, view, form["UserName"], form["password"], cancellation);
        }

        private static async Task DevelopmentSignInAsync(HttpContextBase context, ServiceProvider services, SignInView view, string userName, CancellationToken cancellation)
        {
            if (!await LoadUsersAsync(services, view, cancellation))
            {
                await WriteAsync(context, 200, view);
                return;
            }

            var user = view.Users.FirstOrDefault(u => string.Equals(u.Name, userName, StringComparison.OrdinalIgnoreCase));
            if (user == null)
            {
                await Http.WriteTextAsync(context, 400, "text/plain; charset=utf-8", "Bad request.");
                return;
            }

            var sessionId = SessionStore.NewSessionId();
            var signIn = await RecordSuccessAsync(context, services, view, new SignInSucceededDto
            {
                UserName = user.Name, Detail = "Development test user.", Roles = user.Roles, SessionId = sessionId
            }, cancellation);
            if (signIn == null)
            {
                await WriteAsync(context, 200, view);
                return;
            }

            // The roles are checked against the database again on every request (AccessResolver).
            StartSession(context, services, new PlatformSession
            {
                UserName = user.Name,
                Mode = AuthenticationMode.Development,
                SessionId = sessionId,
                DevelopmentRoles = user.Roles.ToList()
            }, signIn);
            Http.Redirect(context, SafeReturnUrl(context, view.ReturnUrl));
        }

        private static async Task DirectorySignInAsync(HttpContextBase context, ServiceProvider services, PlatformSettings settings, SignInView view,
            string typedUserName, string password, CancellationToken cancellation)
        {
            var logger = PlatformApplication.Logger;
            var reference = services.GetRequiredService<ApiReferenceClient>();
            var userName = (typedUserName ?? "").Trim();
            view.UserName = userName;
            if (!settings.IsDevelopment && !context.Request.IsSecureConnection)
            {
                view.Error = "Sign-in needs a secure (https) connection. Open FRP Mapper with an https address.";
                await WriteAsync(context, 200, view);
                return;
            }

            if (userName.Length == 0 || string.IsNullOrEmpty(password))
            {
                view.Error = "Enter your user name and password.";
                await WriteAsync(context, 200, view);
                return;
            }

            if (userName.Length > Pages.MaxUserNameLength || password.Length > Pages.MaxPasswordLength || userName.Any(char.IsControl))
            {
                view.Error = "The user name or password is incorrect, or the account cannot sign in right now.";
                await WriteAsync(context, 200, view);
                return;
            }

            var throttle = services.GetRequiredService<SignInThrottle>();
            var validator = services.GetRequiredService<IDirectoryCredentialValidator>();
            // Throttle, lockout, delay and the audit trail count against the account (DOMAIN\name), however it was typed.
            var account = validator.AccountKey(userName);
            var address = ClientAddress.Of(context) ?? "unknown";
            var auditAddress = ClientAddress.Of(context);
            if (throttle.IsBlocked(account, address))
            {
                logger.LogWarning("Sign-in refused for {User} from {Address}: too many failed attempts.", userName, address);
                await RecordBlockedAsync(reference, account, "From " + address + "; too many failed sign-ins from this address.", auditAddress, cancellation);
                view.Error = "Too many failed sign-in attempts. Wait " + SignInThrottle.Window.TotalMinutes.ToString("0", CultureInfo.InvariantCulture) + " minutes, then try again.";
                await WriteAsync(context, 200, view);
                return;
            }

            // An administrator account is delayed (not locked) after too many failed sign-ins: its password is not tried.
            DateTimeOffset? delayedUntil;
            try
            {
                delayedUntil = await reference.GetSignInDelayAsync(account, auditAddress, cancellation);
            }
            catch (Exception ex)
            {
                if (!AccessResolver.IsApiFailure(ex))
                {
                    throw;
                }

                logger.LogError(ex, "The sign-in state of {User} could not be read from the FRP Mapper API.", userName);
                view.Error = UnavailableMessage;
                await WriteAsync(context, 200, view);
                return;
            }

            if (delayedUntil.HasValue)
            {
                var until = delayedUntil.Value;
                logger.LogWarning("Sign-in refused for {User} from {Address}: delayed until {Until}.", userName, address, until);
                await RecordBlockedAsync(reference, account, "From " + address + "; sign-in delayed until " + until.ToString("u", CultureInfo.InvariantCulture) + " after failed sign-ins.", auditAddress, cancellation);
                var minutes = Math.Max(1, Math.Ceiling((until - DateTimeOffset.UtcNow).TotalMinutes));
                view.Error = "Too many failed sign-in attempts. Wait " + minutes.ToString("0", CultureInfo.InvariantCulture) + " minutes, then try again.";
                await WriteAsync(context, 200, view);
                return;
            }

            DirectorySignInResult result;
            try
            {
                result = validator.Validate(userName, password);
            }
            catch (Exception ex)
            {
                if (!(ex is PlatformNotSupportedException || ex is System.ComponentModel.Win32Exception || ex is System.Security.SecurityException
                    || ex is UnauthorizedAccessException || ex is ArgumentException))
                {
                    throw;
                }

                logger.LogError(ex, "The password of {User} could not be checked.", userName);
                view.Error = "Your password could not be checked right now. Try again in a moment or contact your administrator.";
                await WriteAsync(context, 200, view);
                return;
            }

            if (!result.Succeeded || string.IsNullOrWhiteSpace(result.AccountName))
            {
                throttle.RecordFailure(account, address);
                logger.LogWarning("Sign-in failed for {User} from {Address} (Windows error {Code}).", userName, address, result.ErrorCode);
                // Only a wrong user name or password (1326) counts toward the lockout; an expired or disabled domain
                // account, or an unreachable domain controller, is audited but not counted.
                await RecordFailureAsync(reference, new SignInFailedDto
                {
                    UserName = account,
                    Detail = "From " + address + "; Windows error " + result.ErrorCode + ".",
                    CountsTowardLockout = result.ErrorCode == WrongUserNameOrPassword
                }, auditAddress, cancellation);
                view.Error = result.Error ?? "The user name or password is incorrect, or the account cannot sign in right now.";
                await WriteAsync(context, 200, view);
                return;
            }

            // Only the groups that grant an FRP Mapper role are kept with the session; which role each group grants is read
            // from the database again on every request (AccessResolver).
            List<string> roleGroups;
            try
            {
                var catalog = await reference.GetCatalogAsync(cancellation);
                var configured = new HashSet<string>(catalog.Roles.SelectMany(r => r.DirectoryGroups).Select(g => g.Trim()).Where(g => g.Length > 0), StringComparer.OrdinalIgnoreCase);
                roleGroups = result.Groups.Where(configured.Contains).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            }
            catch (Exception ex)
            {
                if (!AccessResolver.IsApiFailure(ex))
                {
                    throw;
                }

                logger.LogError(ex, "The role groups could not be read from the FRP Mapper API while {User} signed in.", result.AccountName);
                view.Error = "Your access could not be checked because the FRP Mapper API cannot be reached. Try again in a moment.";
                await WriteAsync(context, 200, view);
                return;
            }

            var sessionId = SessionStore.NewSessionId();
            var signIn = await RecordSuccessAsync(context, services, view, new SignInSucceededDto
            {
                UserName = result.AccountName, Detail = "From " + address + ".", DirectoryGroups = roleGroups, SessionId = sessionId
            }, cancellation);
            if (signIn == null)
            {
                await WriteAsync(context, 200, view);
                return;
            }

            throttle.RecordSuccess(account, address);
            StartSession(context, services, new PlatformSession
            {
                UserName = result.AccountName,
                Mode = AuthenticationMode.ActiveDirectory,
                SessionId = sessionId,
                DirectoryGroups = roleGroups
            }, signIn);
            logger.LogInformation("{User} signed in from {Address} ({Groups} role group(s)).", result.AccountName, address, roleGroups.Count);
            Http.Redirect(context, SafeReturnUrl(context, view.ReturnUrl));
        }

        private static void StartSession(HttpContextBase context, ServiceProvider services, PlatformSession session, SignInResultDto signIn)
        {
            session.Address = ClientAddress.Of(context);
            session.PreviousSignInAt = signIn.PreviousSignInAt;
            session.FailedSinceLast = signIn.FailedSinceLast;
            var store = services.GetRequiredService<SessionStore>();
            // A session cookie of an earlier sign-in in this browser ends now.
            store.Remove(Http.Cookie(context, PlatformPipeline.SessionCookie(PlatformApplication.Settings)));
            store.Create(session);
            Http.SetCookie(context, PlatformPipeline.SessionCookie(PlatformApplication.Settings), session.Token,
                PlatformApplication.Settings.Mode == AuthenticationMode.ActiveDirectory && !PlatformApplication.Settings.IsDevelopment);
        }

        /// <summary>
        /// Asks the API whether the person may sign in (records the sign-in, or why it was refused). Null, with
        /// <see cref="SignInView.Refusal"/> or <see cref="SignInView.Error"/> set, when they may not.
        /// </summary>
        private static async Task<SignInResultDto> RecordSuccessAsync(HttpContextBase context, ServiceProvider services, SignInView view, SignInSucceededDto success, CancellationToken cancellation)
        {
            var logger = PlatformApplication.Logger;
            SignInResultDto signIn;
            try
            {
                signIn = await services.GetRequiredService<ApiReferenceClient>().RecordSignInSuccessAsync(success, ClientAddress.Of(context), cancellation);
            }
            catch (Exception ex)
            {
                if (!AccessResolver.IsApiFailure(ex))
                {
                    throw;
                }

                logger.LogError(ex, "The sign-in of {User} could not be recorded by the FRP Mapper API.", success.UserName);
                view.Error = UnavailableMessage;
                return null;
            }

            if (signIn.Outcome == SignInOutcomes.SignedIn)
            {
                return signIn;
            }

            logger.LogWarning("Sign-in refused for {User}: {Outcome}.", success.UserName, signIn.Outcome);
            switch (signIn.Outcome)
            {
                case SignInOutcomes.Locked:
                    view.Refusal = "Your account is locked after too many failed sign-in attempts in a row. Ask SRAU to re-enable it.";
                    break;
                case SignInOutcomes.Dormant:
                    view.Refusal = "Your account was deactivated because it was not used for more than " + signIn.InactiveDays + " days. Ask SRAU to re-enable it.";
                    break;
                case SignInOutcomes.Expired:
                    view.Refusal = "Your access to this application has ended. Ask SRAU if you still need it.";
                    break;
                default:
                    view.Refusal = "Your access to this application is disabled. Ask SRAU if you need access.";
                    break;
            }

            return null;
        }

        /// <summary>A failed sign-in for the audit trail and the lockout; a failure to record it is logged only.</summary>
        private static async Task RecordFailureAsync(ApiReferenceClient reference, SignInFailedDto failure, string address, CancellationToken cancellation)
        {
            try
            {
                var outcome = await reference.RecordSignInFailureAsync(failure, address, cancellation);
                if (outcome != SignInOutcomes.Failed)
                {
                    PlatformApplication.Logger.LogWarning("After a failed sign-in, the account {User} is now {Outcome}.", failure.UserName, outcome);
                }
            }
            catch (Exception ex)
            {
                if (!AccessResolver.IsApiFailure(ex))
                {
                    throw;
                }

                PlatformApplication.Logger.LogError(ex, "The failed sign-in of {User} could not be recorded by the FRP Mapper API.", failure.UserName);
            }
        }

        private static async Task RecordBlockedAsync(ApiReferenceClient reference, string userName, string detail, string address, CancellationToken cancellation)
        {
            try
            {
                await reference.RecordSignInBlockedAsync(new SignInFailedDto { UserName = userName, Detail = detail }, address, cancellation);
            }
            catch (Exception ex)
            {
                if (!AccessResolver.IsApiFailure(ex))
                {
                    throw;
                }

                PlatformApplication.Logger.LogError(ex, "The blocked sign-in of {User} could not be recorded by the FRP Mapper API.", userName);
            }
        }

        private static async Task<bool> LoadUsersAsync(ServiceProvider services, SignInView view, CancellationToken cancellation)
        {
            try
            {
                view.Users = (await services.GetRequiredService<ApiReferenceClient>().GetDevelopmentUsersAsync(cancellation))
                    .Where(u => !string.IsNullOrWhiteSpace(u.Name))
                    .ToList();
                return true;
            }
            catch (Exception ex)
            {
                if (!AccessResolver.IsApiFailure(ex))
                {
                    throw;
                }

                PlatformApplication.Logger.LogError(ex, "The development users could not be read from the FRP Mapper API.");
                view.Error = "The FRP Mapper API cannot be reached, so the test users cannot be listed. Start FrpMapper.Api and reload this page.";
                return false;
            }
        }

        private static Task WriteAsync(HttpContextBase context, int status, SignInView view)
        {
            return Http.WriteHtmlAsync(context, status, Pages.SignIn(context, view, PlatformApplication.Versions));
        }

        private static string SignedOutMessage(string reason, PlatformSettings settings)
        {
            switch (reason)
            {
                case "elsewhere":
                    return "You were signed out because your account signed in on another browser or computer. Only one session at a time is allowed.";
                case "idle":
                    var minutes = settings.IdleTimeout.TotalMinutes;
                    return "You were signed out after " + minutes.ToString("0", CultureInfo.InvariantCulture) + " minute" + (minutes == 1 ? "" : "s")
                        + " without activity. Sign in again to continue.";
                default:
                    return null;
            }
        }

        /// <summary>Only a page of this application (never another site, nor the sign-in pages themselves).</summary>
        private static string SafeReturnUrl(HttpContextBase context, string returnUrl)
        {
            var basePath = Http.BasePath(context);
            if (string.IsNullOrEmpty(returnUrl) || !returnUrl.StartsWith(basePath, StringComparison.Ordinal) || returnUrl.StartsWith("//", StringComparison.Ordinal)
                || returnUrl.Contains("\\") || returnUrl.Any(char.IsControl)
                || returnUrl.StartsWith(basePath + "account/", StringComparison.OrdinalIgnoreCase))
            {
                return basePath;
            }

            return returnUrl;
        }
    }
}
