using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Hosting;
using FrpMapper.Platform.Security;
using FrpMapper.Platform.Services;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Platform.Hosting
{
    /// <summary>
    /// The Platform's composition root (the services part of the .NET 9 version's Program.cs): settings, logging and
    /// every service. Started once from Global.asax; it fails at start, not on the first request, when a secret or
    /// setting is missing or wrong.
    /// </summary>
    public static class PlatformApplication
    {
        private static readonly object Gate = new object();

        public static ServiceProvider Services { get; private set; }

        public static PlatformSettings Settings { get; private set; }

        public static ILogger Logger { get; private set; }

        /// <summary>The folder the application runs from (static files: css, js, vendor, img).</summary>
        public static string Root { get; private set; }

        /// <summary>A short content hash of each script and style sheet, added to their links so a new version is loaded at once.</summary>
        public static IDictionary<string, string> Versions { get; private set; }

        /// <param name="customize">Changes to the registrations before they are built (tests replace the password check).</param>
        public static void Start(Action<ServiceCollection> customize = null)
        {
            lock (Gate)
            {
                if (Services != null)
                {
                    return;
                }

                var configuration = new AppConfiguration();
                var root = HostingEnvironment.ApplicationPhysicalPath ?? AppDomain.CurrentDomain.BaseDirectory;
                var environment = new HostEnvironment(configuration["Environment"], root);
                var settings = PlatformSettings.Read(configuration, environment);
                var logFile = configuration["Logging:FilePath"];
                if (!string.IsNullOrWhiteSpace(logFile) && !Path.IsPathRooted(logFile))
                {
                    logFile = Path.Combine(root, logFile);
                }

                LogLevel level;
                if (!Enum.TryParse(configuration["Logging:LogLevel:Default"], true, out level))
                {
                    level = LogLevel.Information;
                }

                var loggerFactory = new LoggerFactory(level, logFile);
                var services = new ServiceCollection();
                services.AddSingleton<IConfiguration>(configuration);
                services.AddSingleton<IHostEnvironment>(environment);
                services.AddSingleton<ILoggerFactory>(loggerFactory);
                services.AddSingleton(settings);
                services.AddSingleton(TimeProvider.System);
                services.AddSingleton<IMemoryCache, MemoryCache>();
                services.AddSingleton<SessionStore>();
                services.AddSingleton<SignInThrottle>();
                services.AddSingleton<ApiConnection>();
                services.AddSingleton<ApiReferenceClient>();
                services.AddSingleton<AccessResolver>();
                services.AddSingleton<ApiProxy>();
                services.AddSingleton<ValueChecks>();
                services.AddSingleton<UserApiClient>();
                services.AddSingleton<PendingUploads>();
                if (settings.Mode == AuthenticationMode.ActiveDirectory)
                {
                    services.AddSingleton<IDirectoryCredentialValidator, WindowsDirectoryCredentialValidator>();
                }

                if (customize != null)
                {
                    customize(services);
                }

                var built = services.Build();
                // Fail at start when the password check cannot be made: it needs Windows, in the domain.
                if (settings.Mode == AuthenticationMode.ActiveDirectory
                    && built.GetRequiredService<IDirectoryCredentialValidator>() is WindowsDirectoryCredentialValidator && !CompatOs.IsWindows())
                {
                    throw new InvalidOperationException(
                        "Authentication:Mode 'ActiveDirectory' checks passwords through Windows, so the Platform must run on a Windows server in the domain. "
                        + "On this machine, use Authentication:Mode 'Development' with Environment 'Development'.");
                }

                Root = root;
                Versions = Pages.Scripts.Concat(Pages.Styles).Concat(Pages.WebFormsScripts).Distinct(StringComparer.Ordinal)
                    .ToDictionary(file => file, file => Http.Version(Path.Combine(root, file.Replace('/', Path.DirectorySeparatorChar))), StringComparer.Ordinal);
                Settings = settings;
                Logger = loggerFactory.CreateLogger("FrpMapper.Platform");
                Services = built;
                Logger.LogInformation("FRP Mapper Platform started ({Environment}, sign-in: {Mode}, API: {Api}).", environment.EnvironmentName, settings.Mode, settings.ApiBaseUrl);
            }
        }
    }
}
