using System;
using System.Globalization;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using FrpMapper.Platform.Security;
using FrpMapper.Platform.Services;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Platform.Hosting
{
    /// <summary>
    /// The base of every ASP.NET Web Forms page of the Platform. Global.asax has already checked the request the same way
    /// as every other request (security headers, https, the session, the person's roles) before the page runs; the page
    /// finds the person in <see cref="Person"/>. Form posts are bound to the session: the session's token is part of the
    /// view state's MAC (ViewStateUserKey), so a post made from another site or another session's page is refused.
    /// </summary>
    public abstract class FrpPage : Page
    {
        /// <summary>Where Global.asax leaves the signed-in person for the page (HttpContext.Items).</summary>
        public const string PersonKey = "FrpMapper.Person";

        /// <summary>The hidden field with the session's token in every form post of a page.</summary>
        private const string TokenField = "__FrpToken";

        /// <summary>The signed-in person this request is made for.</summary>
        public SignedInPerson Person { get; private set; }

        protected static ServiceProvider Services
        {
            get { return PlatformApplication.Services; }
        }

        protected UserApiClient Api
        {
            get { return Services.GetRequiredService<UserApiClient>(); }
        }

        /// <summary>The application's base path for links ("/" or "/FrpMapper/").</summary>
        public string BasePath
        {
            get { return Http.BasePath(new HttpContextWrapper(Context)); }
        }

        public bool Can(string permission)
        {
            return Person.User.Can(permission);
        }

        public static string Encode(object value)
        {
            return HttpUtility.HtmlEncode(Convert.ToString(value, CultureInfo.InvariantCulture));
        }

        /// <summary>"13 Oct 2026" or "13 Oct 2026, 11:25", in the server's time zone (the people's own).</summary>
        public static string FormatDate(DateTimeOffset? value, bool time)
        {
            if (value == null)
            {
                return "";
            }

            var local = value.Value.ToLocalTime();
            return local.ToString(time ? "d MMM yyyy, HH:mm" : "d MMM yyyy", CultureInfo.InvariantCulture);
        }

        public static string FormatDate(DateTime value, bool time)
        {
            return FormatDate(new DateTimeOffset(DateTime.SpecifyKind(value, DateTimeKind.Utc)), time);
        }

        public static bool SameName(string a, string b)
        {
            return string.Equals((a ?? "").Trim(), (b ?? "").Trim(), StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Runs <paramref name="work"/> as the page's asynchronous task (after the click handlers, before the page is
        /// drawn). Tasks run in the order they are registered.
        /// </summary>
        protected void RunAsync(Func<CancellationToken, Task> work)
        {
            RegisterAsyncTask(new PageAsyncTask(work));
        }

        protected override void OnPreInit(EventArgs e)
        {
            Person = Context.Items[PersonKey] as SignedInPerson;
            if (Person == null)
            {
                // Global.asax checks every .aspx request first; without its result the page is never drawn.
                throw new InvalidOperationException("The page was requested without the sign-in check.");
            }

            base.OnPreInit(e);
        }

        protected override void OnInit(EventArgs e)
        {
            // A form post must come from a page of this session: the session's token is in the post (a hidden field the
            // page carries, as the other screens send it in X-Frp-Csrf) and is part of the view state's MAC.
            if (IsPostBack && !SessionStore.SameToken(Person.Session.CsrfToken, Request.Unvalidated.Form[TokenField]))
            {
                throw new FormTokenException();
            }

            ViewStateUserKey = Person.Session.CsrfToken;
            base.OnInit(e);
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            ClientScript.RegisterHiddenField(TokenField, Person.Session.CsrfToken);
        }

        /// <summary>An unexpected error: logged with the details, shown as the Platform's error page without them.</summary>
        protected override void OnError(EventArgs e)
        {
            var error = Server.GetLastError();
            Server.ClearError();
            var context = new HttpContextWrapper(Context);
            Response.Clear();
            Response.TrySkipIisCustomErrors = true;
            Response.ContentType = "text/html; charset=utf-8";
            if (IsViewStateFailure(error))
            {
                // A page from before a restart or another session, or a post that did not come from this page.
                PlatformApplication.Logger.LogWarning("A form post to {Path} was refused: its view state is not valid for this session.", Request.Path);
                Response.StatusCode = 400;
                Response.Write(Pages.FormExpired(context, PlatformApplication.Versions));
            }
            else
            {
                PlatformApplication.Logger.LogError(error, "Unhandled error for {Path}", Request.Path);
                Response.StatusCode = 500;
                Response.Write(Pages.Error(context, PlatformApplication.Versions));
            }

            Context.ApplicationInstance.CompleteRequest();
        }

        private static bool IsViewStateFailure(Exception error)
        {
            for (var current = error; current != null; current = current.InnerException)
            {
                if (current is ViewStateException || current is FormTokenException)
                {
                    return true;
                }

                var http = current as HttpException;
                if (http != null && http.Message.IndexOf("viewstate", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }

            return false;
        }
    }

    /// <summary>A form post without this session's token (a page from another session or site, or from before a restart).</summary>
    public sealed class FormTokenException : Exception
    {
        public FormTokenException() : base("The form post does not carry this session's token.")
        {
        }
    }
}
