using System;
using System.Globalization;
using FrpMapper.Shared.Compat;
using FrpMapper.Shared.Hosting;

namespace FrpMapper.Platform.Hosting
{
    /// <summary>How people sign in (Authentication:Mode).</summary>
    public enum AuthenticationMode
    {
        /// <summary>Windows / Active Directory sign-in by IIS (Windows Authentication on, Anonymous Authentication off).</summary>
        Windows,

        /// <summary>A sign-in page for the Active Directory user name and password, checked by Windows with the domain controller.</summary>
        ActiveDirectory,

        /// <summary>A sign-in page listing the test users in the database (frp.DevelopmentUser); only in the Development environment.</summary>
        Development
    }

    /// <summary>
    /// The Platform's settings (web.config appSettings, environment variables, or the secrets file named in web.config).
    /// Every setting is checked when the application starts, so a missing secret or a wrong value stops it at once
    /// instead of failing on the first request.
    /// </summary>
    public sealed class PlatformSettings
    {
        /// <summary>The security checklist allows at most 15 minutes without activity.</summary>
        public const int MaxIdleMinutes = 15;

        public string EnvironmentName { get; private set; }

        public bool IsDevelopment { get; private set; }

        /// <summary>FrpMapper.Api's address (ApiBaseUrl).</summary>
        public Uri ApiBaseUrl { get; private set; }

        /// <summary>How long a call to the API may take (ApiTimeoutMinutes): analyzing a large BSP report can take minutes.</summary>
        public TimeSpan ApiTimeout { get; private set; }

        public AuthenticationMode Mode { get; private set; }

        /// <summary>Authentication:DefaultDomain: the NetBIOS domain for user names typed without one.</summary>
        public string DefaultDomain { get; private set; }

        /// <summary>Access:CacheSeconds: how long roles, permissions and upload limits read from the API are kept.</summary>
        public int AccessCacheSeconds { get; private set; }

        /// <summary>Session:IdleMinutes (1 to 15): a session ends after this long without activity.</summary>
        public TimeSpan IdleTimeout { get; private set; }

        /// <summary>SignIn:Notice: the organization's warning shown on the sign-in page, or null.</summary>
        public string SignInNotice { get; private set; }

        /// <summary>InternalApi:Key: the secret shared with FrpMapper.Api (never in web.config itself).</summary>
        public string InternalApiKey { get; private set; }

        public static PlatformSettings Read(IConfiguration configuration, IHostEnvironment environment)
        {
            var settings = new PlatformSettings
            {
                EnvironmentName = environment.EnvironmentName,
                IsDevelopment = environment.IsDevelopment(),
                DefaultDomain = (configuration["Authentication:DefaultDomain"] ?? "").Trim(),
                SignInNotice = string.IsNullOrWhiteSpace(configuration["SignIn:Notice"]) ? null : configuration["SignIn:Notice"].Trim()
            };

            var apiBaseUrl = configuration["ApiBaseUrl"];
            Uri apiUri;
            if (string.IsNullOrWhiteSpace(apiBaseUrl) || !Uri.TryCreate(apiBaseUrl.Trim(), UriKind.Absolute, out apiUri)
                || (apiUri.Scheme != Uri.UriSchemeHttp && apiUri.Scheme != Uri.UriSchemeHttps))
            {
                throw new InvalidOperationException("ApiBaseUrl is not set (or not an http/https address) in web.config.");
            }

            // The user's identity and data travel between the Platform and the API: outside Development that connection
            // must be encrypted (https) unless the API runs on this same machine.
            if (!settings.IsDevelopment && apiUri.Scheme != Uri.UriSchemeHttps && !apiUri.IsLoopback)
            {
                throw new InvalidOperationException("ApiBaseUrl must use https when the API is on another server (" + apiUri.Host + ").");
            }

            settings.ApiBaseUrl = apiUri;
            var timeout = Int(configuration, "ApiTimeoutMinutes", 0);
            if (timeout <= 0)
            {
                throw new InvalidOperationException("ApiTimeoutMinutes must be set to 1 or more in web.config.");
            }

            settings.ApiTimeout = TimeSpan.FromMinutes(timeout);
            settings.AccessCacheSeconds = Int(configuration, "Access:CacheSeconds", 0);
            var idle = Int(configuration, "Session:IdleMinutes", MaxIdleMinutes);
            if (idle < 1 || idle > MaxIdleMinutes)
            {
                throw new InvalidOperationException("Session:IdleMinutes must be between 1 and " + MaxIdleMinutes
                    + " (the security checklist allows at most " + MaxIdleMinutes + " minutes).");
            }

            settings.IdleTimeout = TimeSpan.FromMinutes(idle);

            var key = configuration["InternalApi:Key"];
            if (string.IsNullOrWhiteSpace(key) || key.Length < 32)
            {
                throw new InvalidOperationException(
                    "InternalApi:Key is not configured (or shorter than 32 characters). Set the same secret for FrpMapper.Api and "
                    + "FrpMapper.Platform (the environment variable InternalApi__Key, or InternalApi:Key in each project's Web.config appSettings).");
            }

            settings.InternalApiKey = key;

            var mode = (configuration["Authentication:Mode"] ?? "Windows").Trim();
            if (string.Equals(mode, "Development", StringComparison.OrdinalIgnoreCase))
            {
                if (!settings.IsDevelopment)
                {
                    throw new InvalidOperationException(
                        "Authentication:Mode 'Development' is allowed only when the Environment setting is Development. Use 'Windows' or 'ActiveDirectory' in other environments.");
                }

                settings.Mode = AuthenticationMode.Development;
            }
            else if (string.Equals(mode, "ActiveDirectory", StringComparison.OrdinalIgnoreCase))
            {
                // The password is checked through Windows; PlatformApplication refuses to start elsewhere.
                settings.Mode = AuthenticationMode.ActiveDirectory;
            }
            else if (string.Equals(mode, "Windows", StringComparison.OrdinalIgnoreCase))
            {
                if (!CompatOs.IsWindows())
                {
                    throw new InvalidOperationException(
                        "Windows / Active Directory sign-in needs Windows (IIS with Windows Authentication). On this machine, use "
                        + "Environment 'Development' and Authentication:Mode 'Development'.");
                }

                settings.Mode = AuthenticationMode.Windows;
            }
            else
            {
                throw new InvalidOperationException("Authentication:Mode must be 'ActiveDirectory', 'Windows' or 'Development', not '" + mode + "'.");
            }

            return settings;
        }

        private static int Int(IConfiguration configuration, string key, int fallback)
        {
            var text = configuration[key];
            if (string.IsNullOrWhiteSpace(text))
            {
                return fallback;
            }

            int value;
            if (!int.TryParse(text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out value))
            {
                throw new InvalidOperationException("The setting " + key + " must be a whole number.");
            }

            return value;
        }
    }
}
