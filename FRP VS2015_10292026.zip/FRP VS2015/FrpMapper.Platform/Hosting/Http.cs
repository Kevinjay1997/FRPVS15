using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using FrpMapper.Platform.Services;
using FrpMapper.Shared.Json;

namespace FrpMapper.Platform.Hosting
{
    /// <summary>Small helpers for writing responses and cookies with System.Web.</summary>
    public static class Http
    {
        /// <summary>The application's virtual path ("/" or "/FrpMapper"), without a trailing slash except for the root.</summary>
        public static string AppPath(HttpContextBase context)
        {
            string path;
            try
            {
                path = context.Request.ApplicationPath;
            }
            catch (NotImplementedException)
            {
                path = null;
            }

            return string.IsNullOrEmpty(path) ? "/" : path;
        }

        /// <summary>The application's base URL path for links ("/" or "/FrpMapper/").</summary>
        public static string BasePath(HttpContextBase context)
        {
            var path = AppPath(context);
            return path.EndsWith("/", StringComparison.Ordinal) ? path : path + "/";
        }

        /// <summary>The request path inside the application, without the leading slash ("projects/abc").</summary>
        public static string LocalPath(HttpContextBase context)
        {
            var path = context.Request.Path ?? "/";
            var app = AppPath(context);
            if (app != "/" && path.StartsWith(app, StringComparison.OrdinalIgnoreCase))
            {
                path = path.Substring(app.Length);
            }

            return path.TrimStart('/');
        }

        public static Task WriteJsonAsync(HttpContextBase context, int status, object value)
        {
            var text = value == null ? "null" : JsonSerializer.Serialize(value, value.GetType(), ApiConnection.Json);
            return WriteTextAsync(context, status, "application/json; charset=utf-8", text);
        }

        public static Task WriteHtmlAsync(HttpContextBase context, int status, string html)
        {
            return WriteTextAsync(context, status, "text/html; charset=utf-8", html);
        }

        public static async Task WriteTextAsync(HttpContextBase context, int status, string contentType, string text)
        {
            var response = context.Response;
            response.StatusCode = status;
            response.ContentType = contentType;
            var bytes = Encoding.UTF8.GetBytes(text);
            if (!string.Equals(context.Request.HttpMethod, "HEAD", StringComparison.OrdinalIgnoreCase))
            {
                await response.OutputStream.WriteAsync(bytes, 0, bytes.Length);
            }
        }

        public static void Redirect(HttpContextBase context, string location)
        {
            context.Response.StatusCode = 302;
            context.Response.RedirectLocation = location;
        }

        public static void NoContent(HttpContextBase context)
        {
            context.Response.StatusCode = 204;
        }

        /// <summary>The value of a request cookie, or null.</summary>
        public static string Cookie(HttpContextBase context, string name)
        {
            var header = context.Request.Headers["Cookie"];
            if (string.IsNullOrEmpty(header))
            {
                return null;
            }

            foreach (var part in header.Split(';'))
            {
                var equals = part.IndexOf('=');
                if (equals > 0 && string.Equals(part.Substring(0, equals).Trim(), name, StringComparison.Ordinal))
                {
                    return part.Substring(equals + 1).Trim();
                }
            }

            return null;
        }

        /// <summary>
        /// Sets a cookie with HttpOnly and SameSite=Strict (System.Web's HttpCookie of .NET 4.5.2 has no SameSite, so the
        /// header is written directly). Secure when the request is https or <paramref name="secure"/> says so.
        /// </summary>
        public static void SetCookie(HttpContextBase context, string name, string value, bool secure, TimeSpan? maxAge = null)
        {
            var header = new StringBuilder();
            header.Append(name).Append('=').Append(value).Append("; Path=").Append(BasePath(context)).Append("; HttpOnly; SameSite=Strict");
            if (secure || context.Request.IsSecureConnection)
            {
                header.Append("; Secure");
            }

            if (maxAge.HasValue)
            {
                header.Append("; Max-Age=").Append((long)maxAge.Value.TotalSeconds);
            }

            context.Response.AppendHeader("Set-Cookie", header.ToString());
        }

        public static void DeleteCookie(HttpContextBase context, string name)
        {
            context.Response.AppendHeader("Set-Cookie", name + "=; Path=" + BasePath(context) + "; HttpOnly; SameSite=Strict; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT");
        }

        public static string Encode(string text)
        {
            return HttpUtility.HtmlEncode(text ?? "");
        }

        /// <summary>A file's version for cache busting (asp-append-version): a short hash of its content.</summary>
        public static string Version(string physicalPath)
        {
            try
            {
                using (var stream = File.OpenRead(physicalPath))
                {
                    var hash = FrpMapper.Shared.Compat.CompatHash.Sha256(stream);
                    return Convert.ToBase64String(hash, 0, 9).Replace('+', '-').Replace('/', '_');
                }
            }
            catch (IOException)
            {
                return "0";
            }
        }
    }
}
