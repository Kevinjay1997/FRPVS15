using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using FrpMapper.Platform.Security;
using FrpMapper.Platform.Services;
using FrpMapper.Shared.Hosting;
using FrpMapper.Shared.Json;
using FrpMapper.Shared.Models;

namespace FrpMapper.Platform.Hosting
{
    /// <summary>Every request (web.config maps all paths here).</summary>
    public sealed class PlatformHandler : HttpTaskAsyncHandler
    {
        public override bool IsReusable
        {
            get { return true; }
        }

        public override Task ProcessRequestAsync(HttpContext context)
        {
            return PlatformPipeline.ProcessAsync(new HttpContextWrapper(context));
        }
    }

    /// <summary>
    /// The Platform's request pipeline, in the order of the .NET 9 version's middleware:
    /// 1. Only GET, HEAD and POST (others 405): the browser never needs more (the API calls that change data go through
    ///    POST with the API method in X-Frp-Method).
    /// 2. Security headers (Content-Security-Policy, no framing, no sniffing), HTTPS outside Development.
    /// 3. Static files (css, js, fonts, images).
    /// 4. No caching for anything else.
    /// 5. The person: the session cookie (sign-in page modes) or the Windows user from IIS; the session must still be
    ///    the account's newest one, and it ends after Session:IdleMinutes without activity.
    /// 6. The sign-in and sign-out pages, the keep-alive, the data requests (forwarded to the API with the person's
    ///    name and roles), downloads, and the application page for every screen.
    /// </summary>
    public static class PlatformPipeline
    {
        private const string AntiforgeryCookie = "FrpMapper.Antiforgery";
        private const string SignedOutCookie = "FrpMapper.SignedOut";
        private const string CsrfHeader = "X-Frp-Csrf";
        private const string MethodHeader = "X-Frp-Method";
        private const int MaxJsonBytes = 64 * 1024 * 1024;

        private static readonly Regex ProjectId = new Regex("^[0-9a-f]{32}$", RegexOptions.CultureInvariant);
        private static readonly Regex TokenFormat = new Regex("^[A-Za-z0-9_-]{20,100}$", RegexOptions.CultureInvariant);

        private static readonly Dictionary<string, string> StaticTypes = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { ".css", "text/css; charset=utf-8" },
            { ".js", "application/javascript; charset=utf-8" },
            { ".svg", "image/svg+xml" },
            { ".png", "image/png" },
            { ".woff2", "font/woff2" },
            { ".woff", "font/woff" },
            { ".txt", "text/plain; charset=utf-8" }
        };

        private static readonly string[] StaticFolders = { "css/", "js/", "vendor/", "img/" };
        private static readonly string[] StaticFiles = { "favicon.svg", "favicon.png", "icon-192.png" };

        public static async Task ProcessAsync(HttpContextBase context)
        {
            var request = context.Request;
            var response = context.Response;
            var method = request.HttpMethod;
            if (method != "GET" && method != "HEAD" && method != "POST")
            {
                response.StatusCode = 405;
                response.AddHeader("Allow", "GET, HEAD, POST");
                return;
            }

            var settings = PlatformApplication.Settings;
            if (!ApplySecurityHeaders(context, settings))
            {
                return;
            }

            var path = Http.LocalPath(context);
            if (method != "POST" && await TryStaticFileAsync(context, path))
            {
                return;
            }

            NoStore(context);

            var services = PlatformApplication.Services;
            var cancellation = response.ClientDisconnectedToken;
            try
            {
                await RouteAsync(context, services, settings, path, cancellation);
            }
            catch (Exception ex)
            {
                if (ex is OperationCanceledException && cancellation.IsCancellationRequested)
                {
                    return;
                }

                PlatformApplication.Logger.LogError(ex, "Unhandled error for {Path}", request.Path);
                if (response.HeadersWritten)
                {
                    return;
                }

                response.ClearContent();
                if (path.StartsWith("app/", StringComparison.Ordinal))
                {
                    await Http.WriteJsonAsync(context, 500, new { message = "The request could not be completed. It has been logged; try again." });
                }
                else
                {
                    await Http.WriteHtmlAsync(context, 500, Pages.Error(context, PlatformApplication.Versions));
                }
            }
        }

        private static async Task RouteAsync(HttpContextBase context, ServiceProvider services, PlatformSettings settings, string path, CancellationToken cancellation)
        {
            var method = context.Request.HttpMethod;
            if (path == "favicon.ico")
            {
                context.Response.StatusCode = 301;
                context.Response.RedirectLocation = Http.BasePath(context) + "favicon.svg";
                return;
            }

            if (path == "Error")
            {
                await Http.WriteHtmlAsync(context, 200, Pages.Error(context, PlatformApplication.Versions));
                return;
            }

            if (path == "account/signin")
            {
                if (settings.Mode == AuthenticationMode.Windows)
                {
                    await NotFoundAsync(context, path);
                    return;
                }

                await SignInEndpoints.HandleAsync(context, services, settings, cancellation);
                return;
            }

            if (path == "account/signout")
            {
                if (settings.Mode == AuthenticationMode.Windows || method != "POST")
                {
                    await NotFoundAsync(context, path);
                    return;
                }

                await SignOutAsync(context, services, settings, cancellation);
                return;
            }

            if (path == "bank-profile" && method != "POST")
            {
                // Bank profiles is an ASP.NET page (Pages/BankProfiles.aspx); earlier links and bookmarks still open it.
                Http.Redirect(context, Http.BasePath(context) + BankProfilesPage);
                return;
            }

            // Everything else needs a signed-in person.
            var person = await SignInCheckAsync(context, services, settings, path, cancellation);
            if (person == null)
            {
                return;
            }

            var session = person.Session;
            var user = person.User;
            var address = person.Address;

            if (path == "account/keepalive")
            {
                // The page calls this while the person uses the mouse or keyboard, so an active session is not ended.
                Http.NoContent(context);
                return;
            }

            if (path == "app/session")
            {
                await Http.WriteJsonAsync(context, 200, await SessionDataAsync(services, settings, session, user, cancellation));
                return;
            }

            if (path.StartsWith("app/", StringComparison.Ordinal))
            {
                // Data requests: only from the application's own page (the token is in the page, not in a cookie).
                if (!SessionStore.SameToken(session.CsrfToken, context.Request.Headers[CsrfHeader]))
                {
                    await Http.WriteJsonAsync(context, 403, new { message = "The page is out of date. Reload it and try again." });
                    return;
                }

                await DataAsync(context, services, path, user, address, cancellation);
                return;
            }

            if (path.StartsWith("download/", StringComparison.Ordinal))
            {
                await DownloadAsync(context, services, path, user, address, cancellation);
                return;
            }

            if (method == "POST")
            {
                await NotFoundAsync(context, path);
                return;
            }

            // Every screen of the application is drawn by the page's scripts.
            await Http.WriteHtmlAsync(context, 200, Pages.Shell(context, JsonSerializer.Serialize(await SessionDataAsync(services, settings, session, user, cancellation), ApiConnection.Json),
                (int)settings.IdleTimeout.TotalMinutes, PlatformApplication.Versions));
        }

        /// <summary>The Bank profiles page (ASP.NET Web Forms), relative to the application's base path.</summary>
        public const string BankProfilesPage = "Pages/BankProfiles.aspx";

        /// <summary>
        /// The security headers every response carries (Content-Security-Policy, no framing, no sniffing) and, outside
        /// Development, https only. False when the request was redirected to https (nothing else is to be written).
        /// </summary>
        public static bool ApplySecurityHeaders(HttpContextBase context, PlatformSettings settings)
        {
            var request = context.Request;
            var response = context.Response;
            response.AddHeader("X-Content-Type-Options", "nosniff");
            response.AddHeader("X-Frame-Options", "DENY");
            response.AddHeader("Referrer-Policy", "same-origin");
            response.AddHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
            response.AddHeader("Content-Security-Policy",
                "default-src 'self'; script-src 'self'; connect-src 'self'; img-src 'self' data:; "
                + "style-src 'self' 'unsafe-inline'; font-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
            if (!settings.IsDevelopment)
            {
                if (!request.IsSecureConnection)
                {
                    // Outside Development the Platform is used over https only.
                    response.StatusCode = 307;
                    response.RedirectLocation = "https://" + request.Url.Host + request.RawUrl;
                    return false;
                }

                response.AddHeader("Strict-Transport-Security", "max-age=2592000");
            }

            return true;
        }

        /// <summary>Pages, downloads and data are never kept in the browser's or a proxy's cache (static files are).</summary>
        public static void NoStore(HttpContextBase context)
        {
            var response = context.Response;
            response.AddHeader("Cache-Control", "no-store, no-cache, max-age=0");
            response.AddHeader("Pragma", "no-cache");
            response.AddHeader("Expires", "0");
        }

        /// <summary>
        /// The signed-in person of this request: the session (still the account's newest, not idle), their roles from the
        /// database and their address. Null when nobody is signed in; the response (the sign-in page, or 401 for data and
        /// form posts) has then been written.
        /// </summary>
        public static async Task<SignedInPerson> SignInCheckAsync(HttpContextBase context, ServiceProvider services, PlatformSettings settings, string path,
            CancellationToken cancellation)
        {
            var signedOut = (string)null;
            var session = await CurrentSessionAsync(context, services, settings, cancellation, out signedOut);
            if (session == null)
            {
                await NotSignedInAsync(context, settings, path, signedOut);
                return null;
            }

            services.GetRequiredService<SessionStore>().Touch(session);
            var user = await services.GetRequiredService<AccessResolver>().ResolveAsync(session, context.User, cancellation);
            return new SignedInPerson(session, user, ClientAddress.Of(context) ?? ClientAddress.Checked(session.Address));
        }

        /// <summary>
        /// The signed-in session, or null. A session of an account that signed in again elsewhere ends here (only the newest
        /// session may be used); <paramref name="signedOut"/> then says why.
        /// </summary>
        private static Task<PlatformSession> CurrentSessionAsync(HttpContextBase context, ServiceProvider services, PlatformSettings settings,
            CancellationToken cancellation, out string signedOut)
        {
            signedOut = null;
            var store = services.GetRequiredService<SessionStore>();
            var cookieName = SessionCookie(settings);
            var token = Http.Cookie(context, cookieName);
            bool expired;
            var session = store.Find(token, out expired);
            if (settings.Mode == AuthenticationMode.Windows)
            {
                // IIS signed the person in with Windows; the session only holds the page's token and the activity.
                var identity = context.User == null ? null : context.User.Identity;
                if (identity == null || !identity.IsAuthenticated || string.IsNullOrEmpty(identity.Name))
                {
                    return Task.FromResult<PlatformSession>(null);
                }

                if (session == null || !string.Equals(session.UserName, identity.Name, StringComparison.OrdinalIgnoreCase))
                {
                    store.Remove(token);
                    return StartWindowsSessionAsync(context, services, settings, identity.Name, cancellation);
                }

                return Task.FromResult(session);
            }

            if (expired)
            {
                signedOut = "idle";
            }

            if (session == null)
            {
                return Task.FromResult<PlatformSession>(null);
            }

            return CheckCurrentAsync(context, services, session, cancellation);
        }

        /// <summary>
        /// The first request of a Windows-signed-in person in this browser: the same sign-in rules as the sign-in page
        /// (the API refuses a locked, deactivated, expired or disabled account and records the sign-in in the audit
        /// trail), then a session. Null when refused; the reason is then in <see cref="WindowsRefusalKey"/>.
        /// </summary>
        private static async Task<PlatformSession> StartWindowsSessionAsync(HttpContextBase context, ServiceProvider services, PlatformSettings settings, string userName,
            CancellationToken cancellation)
        {
            var reference = services.GetRequiredService<ApiReferenceClient>();
            var address = ClientAddress.Of(context);
            var sessionId = SessionStore.NewSessionId();
            SignInResultDto signIn = null;
            try
            {
                // The roles the person's Windows groups give, for the audit trail (each request reads them again).
                var catalog = await reference.GetCatalogAsync(cancellation);
                var roles = catalog.Roles
                    .Where(role => role.DirectoryGroups.Any(group => !string.IsNullOrWhiteSpace(group) && AccessResolver.IsInRole(context.User, group.Trim())))
                    .Select(role => role.Key)
                    .ToList();
                signIn = await reference.RecordSignInSuccessAsync(new SignInSucceededDto
                {
                    UserName = userName, Detail = "Windows sign-in from " + (address ?? "unknown") + ".", Roles = roles, SessionId = sessionId
                }, address, cancellation);
            }
            catch (Exception ex)
            {
                if (!AccessResolver.IsApiFailure(ex) || cancellation.IsCancellationRequested)
                {
                    throw;
                }

                // Without the API nothing else works either; the sign-in is recorded on the next first request.
                PlatformApplication.Logger.LogWarning(ex, "The Windows sign-in of {User} could not be recorded by the FRP Mapper API.", userName);
                return null;
            }

            if (signIn.Outcome != SignInOutcomes.SignedIn)
            {
                PlatformApplication.Logger.LogWarning("Windows sign-in refused for {User}: {Outcome}.", userName, signIn.Outcome);
                context.Items[WindowsRefusalKey] = signIn.Outcome == SignInOutcomes.Locked
                    ? "Your account is locked after too many failed sign-in attempts in a row. Ask SRAU to re-enable it."
                    : signIn.Outcome == SignInOutcomes.Dormant
                        ? "Your account was deactivated because it was not used for more than " + signIn.InactiveDays + " days. Ask SRAU to re-enable it."
                        : signIn.Outcome == SignInOutcomes.Expired
                            ? "Your access to this application has ended. Ask SRAU if you still need it."
                            : "Your access to this application is disabled. Ask SRAU if you need access.";
                return null;
            }

            var session = services.GetRequiredService<SessionStore>().Create(new PlatformSession
            {
                UserName = userName, Mode = AuthenticationMode.Windows, SessionId = sessionId, Address = address,
                PreviousSignInAt = signIn.PreviousSignInAt, FailedSinceLast = signIn.FailedSinceLast
            });
            Http.SetCookie(context, SessionCookie(settings), session.Token, !settings.IsDevelopment);
            PlatformApplication.Logger.LogInformation("{User} signed in with Windows from {Address}.", userName, address ?? "unknown");
            return session;
        }

        /// <summary>Why a Windows sign-in was refused (HttpContext.Items), for the page shown instead of the application.</summary>
        private const string WindowsRefusalKey = "FrpMapper.WindowsRefusal";

        private static async Task<PlatformSession> CheckCurrentAsync(HttpContextBase context, ServiceProvider services, PlatformSession session, CancellationToken cancellation)
        {
            bool current;
            try
            {
                current = await services.GetRequiredService<ApiReferenceClient>().IsSessionCurrentAsync(session.UserName, session.SessionId, cancellation);
            }
            catch (Exception ex)
            {
                if (!AccessResolver.IsApiFailure(ex) || cancellation.IsCancellationRequested)
                {
                    throw;
                }

                // Without the API nothing else works either; the check runs again on the next request.
                PlatformApplication.Logger.LogWarning(ex, "The session of {User} could not be checked.", session.UserName);
                return session;
            }

            if (current)
            {
                return session;
            }

            PlatformApplication.Logger.LogInformation("A session of {User} was ended: the account signed in again elsewhere.", session.UserName);
            services.GetRequiredService<SessionStore>().Remove(session.Token);
            Http.DeleteCookie(context, SessionCookie(PlatformApplication.Settings));
            Http.SetCookie(context, SignedOutCookie, "elsewhere", !PlatformApplication.Settings.IsDevelopment, TimeSpan.FromMinutes(5));
            return null;
        }

        private static async Task NotSignedInAsync(HttpContextBase context, PlatformSettings settings, string path, string signedOut)
        {
            if (settings.Mode == AuthenticationMode.Windows)
            {
                var refusal = context.Items[WindowsRefusalKey] as string;
                if (path.StartsWith("app/", StringComparison.Ordinal) || path == "account/keepalive")
                {
                    await Http.WriteJsonAsync(context, refusal != null ? 403 : 401, new { message = refusal ?? "Your Windows sign-in was not received. Reload the page." });
                    return;
                }

                await Http.WriteHtmlAsync(context, refusal != null ? 403 : 401, refusal != null
                    ? Pages.WindowsSignInRefused(context, refusal, PlatformApplication.Versions)
                    : Pages.WindowsSignInMissing(context, PlatformApplication.Versions));
                return;
            }

            if (signedOut != null)
            {
                Http.DeleteCookie(context, SessionCookie(settings));
            }

            // A form post of an ASP.NET page goes back to the sign-in page, then to the page (its post cannot be repeated).
            var pagePost = context.Request.HttpMethod == "POST" && path.EndsWith(".aspx", StringComparison.OrdinalIgnoreCase);
            if (path.StartsWith("app/", StringComparison.Ordinal) || path == "account/keepalive" || (context.Request.HttpMethod == "POST" && !pagePost))
            {
                await Http.WriteJsonAsync(context, 401, new { message = "Your session has ended. Sign in again to continue.", signedOut = signedOut ?? "" });
                return;
            }

            if (signedOut != null && pagePost)
            {
                Http.Redirect(context, Http.BasePath(context) + "account/signin?signedOut=" + Uri.EscapeDataString(signedOut) + "&ReturnUrl=" + Uri.EscapeDataString(context.Request.RawUrl));
                return;
            }

            var returnUrl = context.Request.RawUrl;
            Http.Redirect(context, Http.BasePath(context) + "account/signin" + (string.IsNullOrEmpty(path) ? "" : "?ReturnUrl=" + Uri.EscapeDataString(returnUrl)));
        }

        private static async Task SignOutAsync(HttpContextBase context, ServiceProvider services, PlatformSettings settings, CancellationToken cancellation)
        {
            var form = context.Request.Unvalidated.Form;
            var idle = form["reason"] == "idle";
            var store = services.GetRequiredService<SessionStore>();
            var token = Http.Cookie(context, SessionCookie(settings));
            bool expired;
            var session = store.Find(token, out expired);
            var basePath = Http.BasePath(context);
            if (session != null)
            {
                if (!SessionStore.SameToken(session.CsrfToken, form["__RequestVerificationToken"]))
                {
                    await Http.WriteHtmlAsync(context, 400, Pages.FormExpired(context, PlatformApplication.Versions));
                    return;
                }

                PlatformApplication.Logger.LogInformation(idle ? "{User} was signed out after the idle timeout." : "{User} signed out.", session.UserName);
                store.Remove(session.Token);
                try
                {
                    // End the session on the server too, so this cookie (or a copy of it) cannot be used again.
                    await services.GetRequiredService<ApiReferenceClient>().EndSessionAsync(session.UserName, session.SessionId, idle, ClientAddress.Of(context), cancellation);
                }
                catch (Exception ex)
                {
                    if (!AccessResolver.IsApiFailure(ex))
                    {
                        throw;
                    }

                    PlatformApplication.Logger.LogWarning(ex, "The session of {User} could not be ended on the server; the sign-in cookie is still removed.", session.UserName);
                }
            }

            Http.DeleteCookie(context, SessionCookie(settings));
            Http.Redirect(context, basePath + (idle || expired ? "account/signin?signedOut=idle" : "account/signin"));
        }

        private static async Task DataAsync(HttpContextBase context, ServiceProvider services, string path, AppUser user, string address, CancellationToken cancellation)
        {
            var method = context.Request.HttpMethod;
            if (path.StartsWith("app/api/", StringComparison.Ordinal))
            {
                var apiMethod = method;
                var overrideMethod = context.Request.Headers[MethodHeader];
                if (!string.IsNullOrEmpty(overrideMethod))
                {
                    if (method != "POST" || (overrideMethod != "PUT" && overrideMethod != "DELETE"))
                    {
                        await Http.WriteJsonAsync(context, 400, new { message = "The request is not valid." });
                        return;
                    }

                    apiMethod = overrideMethod;
                }

                if (apiMethod == "HEAD")
                {
                    apiMethod = "GET";
                }

                var apiPath = "/api/" + path.Substring("app/api/".Length);
                if (!ApiProxy.IsAllowed(apiMethod, apiPath))
                {
                    await Http.WriteJsonAsync(context, 404, new { message = "There is nothing at this address." });
                    return;
                }

                await services.GetRequiredService<ApiProxy>().ForwardAsync(context, apiMethod, apiPath, user, address, cancellation);
                return;
            }

            if (path == "app/util/value-errors" && method == "POST")
            {
                var check = await ReadJsonAsync<ValueCheckRequest>(context);
                if (check == null || check.ProjectId == null || !ProjectId.IsMatch(check.ProjectId) || check.Items == null || check.Items.Count > ValueChecks.MaxItems)
                {
                    await Http.WriteJsonAsync(context, 400, new { message = "The request is not valid." });
                    return;
                }

                try
                {
                    var errors = await services.GetRequiredService<ValueChecks>().CheckAsync(check, user, address, cancellation);
                    await Http.WriteJsonAsync(context, 200, new { errors = errors });
                }
                catch (ApiException ex)
                {
                    await Http.WriteJsonAsync(context, (int)ex.StatusCode, new { message = ex.Message });
                }
                catch (System.Net.Http.HttpRequestException)
                {
                    await Http.WriteJsonAsync(context, 502, new { message = "The FRP Mapper API cannot be reached.", unreachable = true });
                }

                return;
            }

            if (path == "app/util/access-conflict" && method == "POST")
            {
                var request = await ReadJsonAsync<PermissionList>(context);
                var conflict = AccessRules.Conflict(request == null || request.Permissions == null ? new List<string>() : request.Permissions);
                await Http.WriteJsonAsync(context, 200, new { conflict = conflict });
                return;
            }

            await Http.WriteJsonAsync(context, 404, new { message = "There is nothing at this address." });
        }

        private static async Task DownloadAsync(HttpContextBase context, ServiceProvider services, string path, AppUser user, string address, CancellationToken cancellation)
        {
            // download/{projectId}/template | sample-xml | submission
            var parts = path.Split('/');
            if (parts.Length != 3 || !ProjectId.IsMatch(parts[1]) || context.Request.HttpMethod == "POST")
            {
                await NotFoundAsync(context, path);
                return;
            }

            if (!user.Can(Permissions.ProjectRead))
            {
                await Http.WriteHtmlAsync(context, 403, Pages.DownloadUnavailable(context, "Your roles do not allow this download.", parts[1]));
                return;
            }

            var id = parts[1];
            var query = context.Request.QueryString;
            var bank = Uri.EscapeDataString(query["bank"] ?? "");
            string apiPath;
            switch (parts[2])
            {
                case "template":
                    var values = query["values"];
                    if (values != "blank" && values != "sample" && values != "mapped")
                    {
                        await Http.WriteHtmlAsync(context, 400, Pages.DownloadUnavailable(context, "Choose which values the template should contain.", id));
                        return;
                    }

                    apiPath = "/api/projects/" + id + "/export/template?values=" + values + "&bank=" + bank;
                    break;
                case "sample-xml":
                    apiPath = "/api/projects/" + id + "/export/xml?values=sample&bank=" + bank;
                    break;
                case "submission":
                    apiPath = "/api/projects/" + id + "/submission";
                    break;
                default:
                    await NotFoundAsync(context, path);
                    return;
            }

            await services.GetRequiredService<ApiProxy>().DownloadAsync(context, apiPath, id, user, address, cancellation);
        }

        /// <summary>What the page needs to know about the person and the application.</summary>
        private static async Task<object> SessionDataAsync(ServiceProvider services, PlatformSettings settings, PlatformSession session, AppUser user, CancellationToken cancellation)
        {
            var reference = services.GetRequiredService<ApiReferenceClient>();
            FileSettingsDto files = null;
            AccessCatalogDto catalog = null;
            try
            {
                files = await reference.GetFileSettingsAsync(cancellation);
                catalog = await reference.GetCatalogAsync(cancellation);
            }
            catch (Exception ex)
            {
                if (!AccessResolver.IsApiFailure(ex))
                {
                    throw;
                }

                // Uploads stay disabled and the access pages say why.
            }

            // The groups that grant each role are shown to those who may see them (access.view) and to people without a
            // role (so they know which group to ask for); the app's own user list never leaves the server.
            var showGroups = user.Can(Permissions.AccessView) || user.Roles.Count == 0;
            return new
            {
                user = new
                {
                    name = user.Name,
                    roles = user.Roles,
                    permissions = user.Permissions.OrderBy(p => p, StringComparer.Ordinal).ToList(),
                    accessUnavailable = user.AccessUnavailable,
                    userDisabled = user.UserDisabled,
                    roleConflict = user.RoleConflict,
                    previousSignInAt = session.PreviousSignInAt,
                    failedSinceLast = session.FailedSinceLast
                },
                mode = settings.Mode.ToString(),
                csrf = session.CsrfToken,
                idleMinutes = (int)settings.IdleTimeout.TotalMinutes,
                apiBaseUrl = settings.ApiBaseUrl.ToString(),
                apiTimeoutMinutes = (int)settings.ApiTimeout.TotalMinutes,
                fileSettings = files,
                catalog = catalog == null ? null : new
                {
                    roles = catalog.Roles.Select(r => new
                    {
                        key = r.Key,
                        displayName = r.DisplayName,
                        description = r.Description,
                        directoryGroups = showGroups ? r.DirectoryGroups : new List<string>()
                    }).ToList(),
                    permissions = catalog.Permissions,
                    grants = catalog.Grants
                }
            };
        }

        private static async Task<T> ReadJsonAsync<T>(HttpContextBase context) where T : class
        {
            var request = context.Request;
            if ((request.ContentType ?? "").IndexOf("application/json", StringComparison.OrdinalIgnoreCase) < 0 || request.ContentLength > MaxJsonBytes)
            {
                return null;
            }

            using (var reader = new StreamReader(request.InputStream, Encoding.UTF8))
            {
                var text = await reader.ReadToEndAsync();
                try
                {
                    return JsonSerializer.Deserialize<T>(text, ApiConnection.Json);
                }
                catch (JsonException)
                {
                    return null;
                }
            }
        }

        private static async Task<bool> TryStaticFileAsync(HttpContextBase context, string path)
        {
            if (!StaticFiles.Contains(path, StringComparer.Ordinal) && !StaticFolders.Any(folder => path.StartsWith(folder, StringComparison.Ordinal)))
            {
                return false;
            }

            string type;
            var extension = Path.GetExtension(path);
            // Only known file types, no ".." or other tricks: the name must stay inside the application folder.
            if (path.Contains("..") || path.Contains("\\") || path.Contains(":") || !StaticTypes.TryGetValue(extension, out type))
            {
                await NotFoundAsync(context, path);
                return true;
            }

            var root = Path.GetFullPath(PlatformApplication.Root);
            var file = Path.GetFullPath(Path.Combine(root, path.Replace('/', Path.DirectorySeparatorChar)));
            if (!file.StartsWith(root, StringComparison.OrdinalIgnoreCase) || !File.Exists(file))
            {
                await NotFoundAsync(context, path);
                return true;
            }

            var response = context.Response;
            response.StatusCode = 200;
            response.ContentType = type;
            // Links to scripts and styles carry their content hash (?v=), so a new version is fetched at once.
            response.AddHeader("Cache-Control", "public, max-age=" + (string.IsNullOrEmpty(context.Request.QueryString["v"]) ? "3600" : "604800"));
            if (context.Request.HttpMethod == "HEAD")
            {
                return true;
            }

            using (var stream = File.OpenRead(file))
            {
                await stream.CopyToAsync(response.OutputStream);
            }

            return true;
        }

        private static Task NotFoundAsync(HttpContextBase context, string path)
        {
            if (path.StartsWith("app/", StringComparison.Ordinal))
            {
                return Http.WriteJsonAsync(context, 404, new { message = "There is nothing at this address." });
            }

            return Http.WriteTextAsync(context, 404, "text/plain; charset=utf-8", "Not found.");
        }

        public static string SessionCookie(PlatformSettings settings)
        {
            switch (settings.Mode)
            {
                case AuthenticationMode.Development:
                    return "FrpMapper.Dev";
                case AuthenticationMode.ActiveDirectory:
                    return "FrpMapper.Session";
                default:
                    return "FrpMapper.Windows";
            }
        }

        /// <summary>The form token of the sign-in page (double submit: cookie and hidden field must match).</summary>
        public static string AntiforgeryToken(HttpContextBase context, bool create)
        {
            var token = Http.Cookie(context, AntiforgeryCookie);
            if (token != null && TokenFormat.IsMatch(token))
            {
                return token;
            }

            if (!create)
            {
                return null;
            }

            token = SessionStore.NewToken();
            Http.SetCookie(context, AntiforgeryCookie, token, !PlatformApplication.Settings.IsDevelopment);
            return token;
        }

        /// <summary>Why the person was signed out (shown once on the sign-in page): ?signedOut=, or the cookie set when the session ended.</summary>
        public static string SignedOutReason(HttpContextBase context)
        {
            var reason = context.Request.QueryString["signedOut"];
            if (string.IsNullOrEmpty(reason))
            {
                reason = Http.Cookie(context, SignedOutCookie);
                if (!string.IsNullOrEmpty(reason))
                {
                    Http.DeleteCookie(context, SignedOutCookie);
                }
            }

            return reason;
        }

        private sealed class PermissionList
        {
            public List<string> Permissions { get; set; }
        }
    }
}
