﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web.UI;
using FrpMapper.Platform.Hosting;
using FrpMapper.Shared.Models;

namespace FrpMapper.Platform
{
    /// <summary>
    /// The layout of the Platform's ASP.NET pages: the same menu, person and sign-out as the other screens (js/components.js
    /// navMenu), the page in the middle, and the idle timeout (js/webforms.js).
    /// </summary>
    public partial class SiteMaster : MasterPage
    {
        private const string LinkClass = "flex shrink-0 items-center gap-2.5 rounded-app px-3 py-2 text-sm font-medium text-muted transition hover:bg-canvas hover:text-ink";

        private static readonly string[] Administration = { Permissions.UsersManage, Permissions.UsersApprove, Permissions.RolesManage, Permissions.RolesApprove };

        private static readonly string[] Reports =
        {
            Permissions.UsersManage, Permissions.UsersApprove, Permissions.RolesManage, Permissions.RolesApprove, Permissions.ReferenceManage, Permissions.ReferenceApprove
        };

        /// <summary>The page's name, before " · FRP Mapper" in the browser's tab.</summary>
        public string PageTitle { get; set; }

        /// <summary>The menu entry of this page ("bank-profile"), shown as the current one.</summary>
        public string ActiveLink { get; set; }

        public string BasePath
        {
            get { return Current.BasePath; }
        }

        protected int IdleMinutes
        {
            get { return (int)PlatformApplication.Settings.IdleTimeout.TotalMinutes; }
        }

        private FrpPage Current
        {
            get { return (FrpPage)Page; }
        }

        /// <summary>A script or style sheet with its content hash, so a new version is loaded at once.</summary>
        protected string Asset(string file)
        {
            string version;
            return BasePath + file + "?v=" + (PlatformApplication.Versions != null && PlatformApplication.Versions.TryGetValue(file, out version) ? version : "0");
        }

        /// <summary>The menu on the left (top on small screens), with the person and the sign-out button.</summary>
        protected string NavigationHtml()
        {
            var person = Current.Person;
            var user = person.User;
            var session = person.Session;
            var mode = PlatformApplication.Settings.Mode;
            var html = new StringBuilder();
            html.Append("<aside class=\"flex flex-col border-b border-line bg-surface lg:sticky lg:top-0 lg:h-screen lg:border-b-0 lg:border-r print:hidden\">\n")
                .Append("<a class=\"flex items-center gap-3 px-5 py-5\" href=\"").Append(FrpPage.Encode(BasePath)).Append("\">\n")
                .Append("<span class=\"grid h-9 w-9 place-items-center rounded-app bg-accent text-white\" aria-hidden=\"true\"><i class=\"ph ph-table text-lg\"></i></span>\n")
                .Append("<span><strong class=\"block font-display text-base font-bold leading-5 text-ink\">FRP Mapper</strong>")
                .Append("<span class=\"block text-xs text-subtle\">BSP submissions</span></span>\n</a>\n")
                .Append("<nav class=\"flex gap-1 overflow-x-auto px-3 pb-3 lg:flex-col lg:overflow-visible lg:pb-0\" aria-label=\"Main\">\n");
            Link(html, user.Can(Permissions.ProjectRead), "", "ph-folders", "Projects");
            Link(html, user.Can(Permissions.ProjectCreate), "projects/new", "ph-plus-circle", "New project");
            Link(html, user.Can(Permissions.ProjectRead), "validate", "ph-seal-check", "Validate");
            Link(html, user.Can(Permissions.AuditReadAll), "audit", "ph-clock-counter-clockwise", "Audit trail");
            Link(html, user.Can(Permissions.SubmissionPrepare) || user.Can(Permissions.ReferenceManage) || user.Can(Permissions.ReferenceApprove),
                "sandbox", "ph-paper-plane-tilt", "BSP submission");
            Link(html, user.Can(Permissions.SubmissionPrepare) || user.Can(Permissions.ReferenceManage) || user.Can(Permissions.ReferenceApprove),
                "cocree", "ph-database", "COCREE");
            Link(html, user.Can(Permissions.SubmissionPrepare) || user.Can(Permissions.ReferenceManage) || user.Can(Permissions.ReferenceApprove),
                "xml-tools", "ph-brackets-angle", "XML tools");
            Link(html, user.Can(Permissions.ReferenceManage) || user.Can(Permissions.ReferenceApprove), PlatformPipeline.BankProfilesPage, "ph-bank", "Bank profiles");
            Link(html, Administration.Any(user.Can), "admin/access", "ph-users-three", "Access administration");
            Link(html, Reports.Any(user.Can), "reports", "ph-table", "Reports");
            Link(html, true, "access", "ph-shield-check", "Roles & access");
            Link(html, user.Can(Permissions.AuditReadAll), "logs", "ph-scroll", "Logs");
            Link(html, true, "versions", "ph-info", "Version history");
            html.Append("</nav>\n")
                .Append("<div class=\"flex items-center justify-between gap-4 border-t border-line px-5 py-3 lg:mt-auto lg:block lg:py-4\">\n<div class=\"min-w-0\">\n")
                .Append("<p class=\"truncate text-sm font-semibold text-ink\" title=\"").Append(FrpPage.Encode(user.Name)).Append("\">").Append(FrpPage.Encode(user.Name)).Append("</p>\n")
                .Append("<p class=\"mt-0.5 text-xs text-subtle\">").Append(FrpPage.Encode(user.Roles.Count > 0 ? string.Join(" · ", user.Roles) : "No role")).Append("</p>\n");
            if (session.FailedSinceLast != null)
            {
                html.Append("<p class=\"mt-1 text-xs text-subtle\">")
                    .Append(FrpPage.Encode(session.PreviousSignInAt != null ? "Last sign-in: " + FrpPage.FormatDate(session.PreviousSignInAt, true) : "First sign-in")).Append("</p>\n");
                var failed = session.FailedSinceLast.Value;
                if (failed > 0)
                {
                    html.Append("<p class=\"mt-0.5 text-xs font-semibold text-amber-800\" role=\"status\">").Append(failed.ToString(CultureInfo.InvariantCulture))
                        .Append(" failed sign-in attempt").Append(failed == 1 ? "" : "s").Append(" since then</p>\n");
                }
            }

            html.Append("</div>\n");
            if (mode == AuthenticationMode.Development || mode == AuthenticationMode.ActiveDirectory)
            {
                // A plain form outside the page's own form: signing out ends the session on the server (account/signout).
                html.Append("<form id=\"frp-signout\" method=\"post\" action=\"").Append(FrpPage.Encode(BasePath + "account/signout")).Append("\" class=\"shrink-0 lg:mt-3\">\n")
                    .Append("<input type=\"hidden\" name=\"reason\" value=\"\" />\n")
                    .Append("<input type=\"hidden\" name=\"__RequestVerificationToken\" value=\"").Append(FrpPage.Encode(session.CsrfToken)).Append("\" />\n")
                    .Append("<button class=\"inline-flex items-center gap-1.5 text-xs font-semibold text-muted transition hover:text-accent\">")
                    .Append("<i class=\"ph ph-sign-out\"></i> ").Append(mode == AuthenticationMode.Development ? "Switch test user" : "Sign out").Append("</button>\n</form>\n");
            }
            else
            {
                html.Append("<p class=\"shrink-0 text-xs text-subtle lg:mt-3\">Signed in with Windows</p>\n");
            }

            html.Append("</div>\n</aside>\n");
            return html.ToString();
        }

        private void Link(StringBuilder html, bool visible, string href, string icon, string label)
        {
            if (!visible)
            {
                return;
            }

            var active = string.Equals(href, ActiveLink, StringComparison.Ordinal);
            html.Append("<a class=\"").Append(LinkClass).Append(active ? " !bg-accent-soft !text-accent" : "").Append("\" href=\"").Append(FrpPage.Encode(BasePath + href)).Append("\"")
                .Append(active ? " aria-current=\"page\"" : "").Append(">\n<i class=\"ph ").Append(icon).Append(" text-lg\"></i> ").Append(FrpPage.Encode(label)).Append("\n</a>\n");
        }
    }
}
