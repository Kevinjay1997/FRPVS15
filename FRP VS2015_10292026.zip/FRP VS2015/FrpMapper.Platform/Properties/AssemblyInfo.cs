﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("FrpMapper.Platform")]
[assembly: AssemblyDescription("FRP Mapper Platform: the web application people use (sign-in, screens, downloads).")]
[assembly: AssemblyProduct("FRP Mapper")]
[assembly: AssemblyCopyright("")]
[assembly: ComVisible(false)]
[assembly: Guid("bc19157d-7776-401b-8da0-14fdfdbdf601")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
