﻿// Version history: what changed in FRP Mapper, newest first (the Workbench's Help › Version History). Kept here with the
// code it describes; add an entry with each change that people will notice.
(function () {
    "use strict";
    var F = window.Frp, html = F.html;

    var history = [
        { date: "2026-10-29", title: "Forms entered as rows", changes: [
            "Input templates are flexible: every repeating item of the XSD is a table with one row per item (CAR_Part_IV_1d per currency, CAR_Part_V_2abc per year, CAR_Part_IV_2 per country, FRP_11A234 per book code, …): type another row for another item. Above each column are the form's headings and its account code; each column has the XSD's validation.",
            "A value the XSD allows only once in a list (xs:unique, e.g. Currency, Year) turns red when it is repeated.",
            "Forms with lists inside each item (CAR_Part_IV_4c, LCR, INTRA, …): copy the sheet for another item (e.g. another currency); the app reads every copy.",
            "The sample template shows forms that BSP's specification leaves out in the same layout, without values.",
            "Mappings › Sheet shows each sheet as the downloaded template lays it out: a list entered one row per item shows its fields on the table's row, each standing for its cell on the BSP form.",
            "Exports: the \"XSD sample values\" template is no longer offered (the sample XML still is)."
        ] },
        { date: "2026-10-28", title: "The rest of the Regulatory Reports Workbench", changes: [
            "COCREE › Validate: Stage 1, the preliminary checks and BSP's validation rules (cocree_validations.xlsx) on CSDF files, with the Workbench's reports, and the check against BSP's COCREE XSD.",
            "COCREE › Settings: the validation rules workbook and BSP's XSD are part of the configuration a Checker approves.",
            "XML tools: merge the report parts of an XML file (merge.csv), leave out empty elements (cleanup.csv), keep one reporting period (reportperiod.csv), normalize with the XSD, and check any XML file against any XSD.",
            "Logs: the API's log files for the people who read the whole audit trail, with secrets masked.",
            "When the database scripts of a new version have not been run, pages say so instead of \"The request failed\"."
        ] },
        { date: "2026-10-27", title: "COCREE v2.0 and validation details", changes: [
            "COCREE › Generate: the CSDF XML from the BU's COCREE input workbooks, as the Workbench made it, with its checks and error report.",
            "COCREE › Header totals: a submission's totals written into every file's Header.",
            "COCREE › Settings: the configuration workbooks, uploaded by a Maker and approved by a Checker.",
            "Validation results show the difference against the tolerance and the computation with the values filled in.",
            "Validation in the BSP sandbox can be turned on and off."
        ] },
        { date: "2026-10-20", title: "BSP environments", changes: [
            "BSP environments (sandbox and production addresses) are reference data with Maker / Checker approval.",
            "A project can be validated in the BSP sandbox."
        ] },
        { date: "2026-10-15", title: "Projects and the audit trail", changes: [
            "A project's files can be replaced and its name changed while it is a draft.",
            "Intraday reporting rules; account scripts for the database logins.",
            "The audit trail is paged; long checks show their progress.",
            "HTTPS on the server and to BSP."
        ] },
        { date: "2026-10-14", title: "Mapping", changes: [
            "Sample values for the mapped template; messages as toasts; the sheet mapping view."
        ] },
        { date: "2026-10-13", title: "Bank profiles, sign-in and certificates", changes: [
            "Bank profiles page; each bank's BSP certificate approved by a Checker.",
            "Windows sign-in; values BSP derives are shown; built for .NET Framework 4.5.2 (Visual Studio 2015)."
        ] },
        { date: "2026-10-12", title: "BSP submission", changes: [
            "Submitting to BSP; secrets kept out of web.config."
        ] }
    ];

    var Versions = F.page(function (app) {
        F.Page.call(this, app);
    }, {
        title: function () { return "Version history · FRP Mapper"; },

        render: function () {
            return html`<div class="px-6 py-8 lg:px-10 lg:py-10">
    <header class="border-b border-line pb-8">
        <h1 class="font-display text-3xl font-bold tracking-tight text-ink">Version history</h1>
        <p class="mt-2 max-w-prose text-base leading-7 text-muted">What changed in FRP Mapper, newest first.</p>
    </header>
    <ol class="mt-8 max-w-3xl space-y-8 border-l border-line pl-6">
        ${history.map(function (entry) {
            return html`<li class="relative">
            <span class="absolute -left-[1.94rem] top-1.5 h-3 w-3 rounded-full border-2 border-surface bg-accent" aria-hidden="true"></span>
            <p class="text-xs font-semibold uppercase tracking-wide text-subtle"><time datetime="${entry.date}">${F.date(entry.date)}</time></p>
            <h2 class="mt-1 font-semibold text-ink">${entry.title}</h2>
            <ul class="mt-2 list-disc space-y-1 pl-5 text-sm leading-6 text-muted">
                ${entry.changes.map(function (change) { return html`<li>${change}</li>`; })}
            </ul>
        </li>`;
        })}
    </ol>
</div>`;
        }
    });

    F.routes.push({ pattern: /^versions$/, create: function (app) { return new Versions(app); } });
})();
