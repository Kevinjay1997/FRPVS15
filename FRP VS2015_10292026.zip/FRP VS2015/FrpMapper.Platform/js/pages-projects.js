// Projects (Home) and New project.
(function () {
    "use strict";

    var Frp = window.Frp;
    var html = Frp.html;
    var C = Frp.components;
    var P = Frp.Permissions;

    // ---------- Projects ----------

    var Home = Frp.page(function (app) {
        Frp.Page.call(this, app);
        this.projects = null;
        this.error = null;
        this.search = "";
        this.activeTab = "all";
        this.userName = Frp.session.user.name;
        this.canCreate = Frp.can(P.ProjectCreate);
        this.canReview = Frp.can(P.SubmissionReview);
        this.canDelete = Frp.can(P.ProjectDelete);
        this.confirmDelete = null;
        this.deleting = false;
        this.deleteMessage = null;
        this.deleteKind = "Success";
    }, {
        title: function () { return "Projects · FRP Mapper"; },

        init: function () {
            var self = this;
            return Frp.api.get("projects").then(function (projects) {
                self.projects = projects;
                var review = self.tabs().filter(function (t) { return t.key === "review"; })[0];
                if (self.canReview && review && projects.some(review.filter)) {
                    self.activeTab = "review";
                }
            }, function (error) {
                self.error = error.unreachable ? Frp.unreachable() : Frp.messageOf(error);
            });
        },

        tabs: function () {
            var userName = this.userName;
            var tabs = [{ key: "all", label: "All", filter: function () { return true; } }];
            if (this.canReview) {
                tabs.push({
                    key: "review",
                    label: "Needs my review",
                    filter: function (p) {
                        return p.status === "InReview"
                            && !p.contributors.some(function (c) { return Frp.sameName(c, userName); })
                            && !Frp.sameName(p.createdBy, userName);
                    }
                });
            }

            tabs.push({ key: "prepare", label: "Drafts & returned", filter: function (p) { return p.status === "Draft" || p.status === "Returned"; } });
            tabs.push({ key: "inreview", label: "In review", filter: function (p) { return p.status === "InReview"; } });
            tabs.push({ key: "approved", label: "Approved", filter: function (p) { return p.status === "Approved"; } });
            return tabs;
        },

        visible: function () {
            var self = this;
            var tab = self.tabs().filter(function (t) { return t.key === self.activeTab; })[0];
            var filter = tab ? tab.filter : function () { return true; };
            var text = self.search.trim();
            return (self.projects || []).filter(filter).filter(function (p) {
                return !text || Frp.containsText(p.name, text) || Frp.containsText(p.rootElement, text)
                    || Frp.containsText(p.createdBy, text) || Frp.containsText(p.lastModifiedBy, text);
            });
        },

        /** The API decides; this only hides the button where it would be refused (not your project, or not a draft). */
        mayDelete: function (project) {
            return this.canDelete && (project.status === "Draft" || project.status === "Returned") && Frp.sameName(project.createdBy, this.userName);
        },

        remove: function (project) {
            var self = this;
            self.deleting = true;
            self.update();
            return Frp.api.remove("projects/" + project.id).then(function () {
                self.projects = self.projects.filter(function (p) { return p.id !== project.id; });
                Frp.toast("Success", "Project deleted", project.name + " was deleted. Its history stays in the audit trail.");
            }, function (error) {
                Frp.toast("Error", "The project was not deleted", error.status === 404 ? "The project no longer exists." : Frp.messageOf(error));
            }).then(function () {
                self.deleting = false;
                self.confirmDelete = null;
                self.update();
            });
        },

        render: function () {
            var self = this;
            var header = html`<header class="flex flex-col gap-6 border-b border-line pb-8 lg:flex-row lg:items-end lg:justify-between">
        <div>
            <h1 class="font-display text-3xl font-bold tracking-tight text-ink">Projects</h1>
            <p class="mt-2 max-w-prose text-base leading-7 text-muted">
                Each project maps one BSP report (XSD) to its Excel template. A Maker prepares it, a different Checker
                reviews the submission file, and only an approved file can be downloaded for BSP.
            </p>
        </div>
        ${self.canCreate ? html`<a class="inline-flex h-10 shrink-0 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover" href="projects/new">
            <i class="ph ph-plus"></i> New project
        </a>` : ""}
    </header>`;
            var body;
            if (self.error) {
                body = html`<div class="mt-8">${C.notice("Error", "Projects could not be loaded", self.error)}</div>`;
            } else if (!self.projects) {
                body = C.pageLoading("Loading the projects");
            } else if (!self.projects.length) {
                body = html`<div class="mt-8">${C.emptyState("No projects yet",
                    self.canCreate
                        ? "Create a project from a BSP XSD. Add BSP's Excel input template and specification if you have them; without a template the app generates one from the XSD."
                        : "Projects appear here when a Maker creates one. You will see them as soon as they exist, and Checkers can review them once they are submitted.",
                    "img/workspace-mappings.png",
                    "A draft project: the Prepare step with the submission file and Submit for review, above the mappings check results.",
                    "A draft project: the Maker attaches the submission file and sends it to a Checker.",
                    self.canCreate ? html`<a class="inline-flex h-10 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover" href="projects/new">
                        <i class="ph ph-plus"></i> Create the first project
                    </a>` : null)}</div>`;
            } else {
                var rows = self.visible();
                body = html`
        <div class="mt-8 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div class="flex flex-wrap gap-1" role="tablist" aria-label="Filter by status">
                ${self.tabs().map(function (tab) {
                    var count = self.projects.filter(tab.filter).length;
                    var active = self.activeTab === tab.key;
                    return html`<button role="tab" aria-selected="${active ? "true" : "false"}"
                        class="inline-flex h-9 items-center gap-2 rounded-app px-3 text-sm font-medium transition ${active ? "bg-ink text-white" : "text-muted hover:bg-surface hover:text-ink"}"
                        data-click="${self.on(function () { self.activeTab = tab.key; self.update(); })}">
                    ${tab.label}
                    <span class="rounded-app px-1.5 text-xs ${active ? "bg-white/20" : "bg-line/70"}">${count}</span>
                </button>`;
                })}
            </div>
            <label class="relative block lg:w-72">
                <span class="sr-only">Search projects</span>
                <i class="ph ph-magnifying-glass pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-subtle"></i>
                <input autocomplete="off" class="h-10 w-full rounded-app border border-line bg-surface pl-9 pr-3 text-sm outline-none transition placeholder:text-subtle hover:border-slate-300 focus:border-accent"
                       placeholder="Search by name, report or person" value="${self.search}" data-input="${self.on(function (e) { self.search = e.target.value; self.update(); })}" />
            </label>
        </div>
        ${!rows.length ? html`<div class="mt-6 rounded-app border border-dashed border-line bg-surface px-6 py-10">
            <p class="font-semibold text-ink">No projects match</p>
            <p class="mt-1 max-w-prose text-sm text-muted">
                ${self.activeTab === "review" ? "Nothing is waiting for your review. Projects you prepared yourself never appear here." : "Try another status or clear the search."}
            </p>
            <button class="mt-4 text-sm font-semibold text-accent hover:underline" data-click="${self.on(function () { self.activeTab = "all"; self.search = ""; self.update(); })}">Show all projects</button>
        </div>` : html`<div class="mt-6 overflow-x-auto rounded-app border border-line bg-surface">
            <table class="w-full min-w-[760px] text-left text-sm">
                <thead class="border-b border-line text-xs font-semibold text-subtle">
                    <tr>
                        <th class="px-5 py-3 font-semibold">Project</th>
                        <th class="px-5 py-3 font-semibold">Status</th>
                        <th class="px-5 py-3 font-semibold">Prepared by</th>
                        <th class="px-5 py-3 font-semibold">Last change</th>
                        <th class="px-5 py-3 font-semibold">Validation</th>
                        ${self.canDelete ? html`<th class="px-5 py-3"><span class="sr-only">Delete</span></th>` : ""}
                    </tr>
                </thead>
                <tbody>
                    ${rows.map(function (project) { return self.row(project); })}
                </tbody>
            </table>
        </div>`}`;
            }

            return html`<div class="px-6 py-8 lg:px-10 lg:py-10">${header}${body}</div>`;
        },

        row: function (project) {
            var self = this;
            var validation = project.lastValidationValid === true
                ? html`<span class="inline-flex items-center gap-1.5 text-emerald-700"><i class="ph ph-check-circle"></i> Valid</span>`
                : project.lastValidationValid === false
                    ? html`<span class="inline-flex items-center gap-1.5 text-red-700"><i class="ph ph-x-circle"></i> ${project.lastValidationErrors} error(s)</span>`
                    : html`<span class="text-subtle">Not run</span>`;
            var deleteCell = "";
            if (self.canDelete) {
                var stop = self.on(function (e) { e.stopPropagation(); });
                var inner;
                if (!self.mayDelete(project)) {
                    inner = html`<span class="sr-only">Cannot be deleted</span>`;
                } else {
                    inner = html`<button class="grid h-8 w-8 place-items-center rounded-app text-subtle transition hover:bg-red-50 hover:text-red-700"
                            title="Delete project" aria-label="${"Delete " + project.name}" ${Frp.attr("disabled", self.deleting)} data-click="${self.on(function (e) {
                                e.stopPropagation();
                                return Frp.confirm({
                                    title: "Delete " + project.name + "?",
                                    message: "The project is removed from the list. Its history stays in the audit trail.",
                                    confirmLabel: "Delete",
                                    danger: true
                                }).then(function (yes) { return yes ? self.remove(project) : undefined; });
                            })}">
                        <i class="ph ph-trash" aria-hidden="true"></i>
                    </button>`;
                }

                deleteCell = html`<td class="whitespace-nowrap px-5 py-4 text-right" data-click="${stop}">${inner}</td>`;
            }

            return html`<tr data-key="${project.id}" class="group cursor-pointer border-b border-line last:border-0 transition hover:bg-canvas" data-click="${self.on(function (e) { if (!e.target.closest("a")) { self.app.navigate("projects/" + project.id); } })}">
    <td class="px-5 py-4">
        <a class="font-semibold text-ink group-hover:text-accent" href="projects/${project.id}">${project.name}</a>
        <span class="mt-0.5 block text-xs text-subtle">${project.rootElement} · ${Frp.n0(project.mappingCount)} mappings</span>
    </td>
    <td class="px-5 py-4">${C.statusBadge(project.status)}</td>
    <td class="px-5 py-4 text-muted">${Frp.shortName(project.createdBy)}</td>
    <td class="px-5 py-4 text-muted">
        ${Frp.date(project.updatedAt, true)}
        ${project.lastModifiedBy ? html`<span class="block text-xs text-subtle">by ${Frp.shortName(project.lastModifiedBy)}</span>` : ""}
    </td>
    <td class="px-5 py-4">${validation}</td>
    ${deleteCell}
</tr>`;
        }
    });

    // ---------- New project ----------

    var NewProject = Frp.page(function (app) {
        Frp.Page.call(this, app);
        var self = this;
        self.projectName = "";
        self.busy = false;
        self.error = null;
        self.sameFiles = [];
        self.progress = null;
        self.existing = [];
        self.projectsNote = null;
        self.sourceProjectId = null;
        self.source = null;
        self.loadingSource = false;
        self.sourceRequest = 0;
        self.reuse = { xsd: false, template: false, specification: false };
        function picker(kind, label, help, required, key) {
            return new C.FilePicker(self, {
                kind: kind,
                label: label,
                help: help,
                required: required,
                onSelected: function () { self.sameFiles = []; self.update(); },
                onError: function (message) { Frp.toast("Error", "This file cannot be used", message); self.update(); }
            });
        }

        self.xsd = picker(Frp.UploadKinds.Xsd, "BSP XSD", "The report schema from BSP, for example FRP_v16.0_SOLO.xsd.", true);
        self.template = picker(Frp.UploadKinds.Template, "BSP Excel input template",
            "Optional. BSP's template keeps its layout and XML bindings. Without it, the app builds a template from the XSD.", false);
        self.specification = picker(Frp.UploadKinds.Specification, "BSP specification",
            "Optional but recommended. Adds BSP's titles and row labels, and its validation rules (totals, allowed codes, required schedules).", false);
    }, {
        title: function () { return "New project · FRP Mapper"; },

        init: function () {
            var self = this;
            if (!Frp.files.settings()) {
                self.error = "The upload settings could not be read from the FRP Mapper API. Start FrpMapper.Api and reload the page.";
            }

            if (!Frp.can(P.ProjectRead)) {
                return Promise.resolve();
            }

            return Frp.api.get("projects").then(function (projects) {
                self.existing = projects;
            }, function () {
                self.projectsNote = "The existing projects could not be listed; you can still create a new project.";
            });
        },

        reusingXsd: function () {
            return !!(this.source && this.source.xsd && this.reuse.xsd);
        },

        hasXsd: function () {
            return !!this.xsd.file || this.reusingXsd();
        },

        xsdName: function () {
            return this.reusingXsd() ? this.source.xsd.fileName : this.xsd.file ? this.xsd.file.name : "";
        },

        chooseSource: function (selected) {
            var self = this;
            var request = ++self.sourceRequest;
            self.error = null;
            self.sameFiles = [];
            self.source = null;
            self.reuse = { xsd: false, template: false, specification: false };
            self.sourceProjectId = selected || null;
            if (!self.sourceProjectId) {
                self.update();
                return Promise.resolve();
            }

            self.loadingSource = true;
            self.update();
            return Frp.api.get("projects/" + self.sourceProjectId + "/uploads").then(function (files) {
                if (request !== self.sourceRequest) {
                    return;
                }

                self.source = files;
                // Reuse every stored file except where a new file was already chosen.
                self.reuse.xsd = !!files.xsd && !self.xsd.file;
                self.reuse.template = !!files.template && !self.template.file;
                self.reuse.specification = !!files.specification && !self.specification.file;
            }, function (error) {
                if (request === self.sourceRequest) {
                    self.sourceProjectId = null;
                    Frp.toast("Error", "The files of the selected project could not be read", error.unreachable
                        ? Frp.unreachable("Start FrpMapper.Api and try again.")
                        : error.message);
                }
            }).then(function () {
                if (request === self.sourceRequest) {
                    self.loadingSource = false;
                }

                self.update();
            });
        },

        create: function () {
            var self = this;
            if (!self.hasXsd() || self.busy || self.loadingSource) {
                return Promise.resolve();
            }

            self.busy = true;
            self.error = null;
            self.sameFiles = [];
            self.update();
            var source = self.source;
            var reuse = {
                xsd: self.reusingXsd(),
                template: !!(source && source.template && self.reuse.template),
                specification: !!(source && source.specification && self.reuse.specification)
            };
            var files = { xsd: reuse.xsd ? null : self.xsd.file, template: reuse.template ? null : self.template.file, specification: reuse.specification ? null : self.specification.file };

            function sha(file) {
                return file ? (file.sha256 ? Promise.resolve(file.sha256) : Frp.sha256(file)) : Promise.resolve(null);
            }

            // Checked before sending the files: only their SHA-256 goes to the API. The API checks again when creating.
            return Promise.all([sha(files.xsd), sha(files.template), sha(files.specification)]).then(function (hashes) {
                return Frp.api.post("projects/matching-files", {
                    xsdSha256: hashes[0],
                    templateSha256: hashes[1],
                    specificationSha256: hashes[2],
                    sourceProjectId: source ? source.projectId : null,
                    reuseXsd: reuse.xsd,
                    reuseTemplate: reuse.template,
                    reuseSpecification: reuse.specification
                }).catch(function () {
                    // Not fatal: creating the project checks the files again and reports a duplicate.
                    return [];
                });
            }).then(function (same) {
                self.sameFiles = same || [];
                if (self.sameFiles.length) {
                    Frp.toast("Warning", "A project with these files already exists", "No new project was created. Open the existing one from the list below the files.");
                    self.busy = false;
                    self.update();
                    return undefined;
                }

                var sending = [files.xsd, files.template, files.specification].filter(function (f) { return f; });
                self.progress = new C.Progress(self, "Analyzing " + self.xsdName());
                self.progress.show({
                    percent: 0,
                    stage: sending.length ? "Sending the files to the API" : "Asking the API to start",
                    detail: sending.length ? sending.map(function (f) { return f.name + " (" + Frp.size(f.size) + ")"; }).join(" · ") : null
                });
                // Scrolled into view below the file fields.
                setTimeout(function () {
                    var box = document.getElementById("analysis-progress");
                    if (box) {
                        box.focus();
                    }
                }, 0);
                var fields = { projectName: source ? source.projectName : self.projectName.trim() };
                if (source && (reuse.xsd || reuse.template || reuse.specification)) {
                    fields.sourceProjectId = source.projectId;
                    fields.reuseXsd = reuse.xsd ? "true" : "false";
                    fields.reuseTemplate = reuse.template ? "true" : "false";
                    fields.reuseSpecification = reuse.specification ? "true" : "false";
                }

                fields.xsdFile = files.xsd;
                fields.templateFile = files.template;
                fields.specificationFile = files.specification;
                var form = new FormData();
                Object.keys(fields).forEach(function (key) {
                    var value = fields[key];
                    if (value === null || value === undefined) {
                        return;
                    }

                    if (value instanceof Blob) {
                        form.append(key, value, value.name);
                    } else {
                        form.append(key, value);
                    }
                });
                return Frp.api.stream("POST", "projects/analyze", { form: form }, function (update) { self.progress.show(update); },
                    function (item) { return item.project; }, "The project was not created.").then(function (project) {
                    self.progress.stop();
                    self.app.navigate("projects/" + project.id);
                }, function (error) {
                    self.progress.stop();
                    self.progress = null;
                    self.busy = false;
                    Frp.toast("Error", "The project was not created", error.timeout ? error.message : error.unreachable ? Frp.unreachable("Start FrpMapper.Api and try again.") : Frp.messageOf(error));
                    self.update();
                });
            });
        },

        useStored: function (stored, use) {
            var self = this;
            if (!self.source || !stored) {
                return "";
            }

            return html`<button type="button" class="-mt-6 inline-flex items-center gap-1.5 text-xs font-semibold text-accent transition hover:text-accent-hover disabled:opacity-50"
        ${Frp.attr("disabled", self.busy)} data-click="${self.on(function () { use(); self.update(); })}">
    <i class="ph ph-copy-simple" aria-hidden="true"></i>${"Use " + stored.fileName + " from " + self.source.projectName + " instead"}
</button>`;
        },

        fileField: function (picker, key, label, help, required) {
            var self = this;
            var stored = self.source ? self.source[key] : null;
            if (self.source && self.reuse[key] && stored) {
                return C.reusedFileCard(self, {
                    label: label,
                    help: help,
                    required: required,
                    file: stored,
                    projectName: self.source.projectName,
                    disabled: self.busy,
                    onReplace: function () { self.reuse[key] = false; self.update(); },
                    onRemove: function () { self.reuse[key] = false; self.update(); }
                });
            }

            return html`${picker.render(self.busy)}${self.useStored(stored, function () { picker.clear(); self.reuse[key] = true; })}`;
        },

        render: function () {
            var self = this;
            var source = self.source;
            return html`<div class="px-6 py-8 lg:px-10 lg:py-10">
    <a class="inline-flex items-center gap-1.5 text-sm font-medium text-muted transition hover:text-accent" href="">
        <i class="ph ph-arrow-left"></i> Projects
    </a>
    <header class="mt-4 border-b border-line pb-8">
        <h1 class="font-display text-3xl font-bold tracking-tight text-ink">New project</h1>
        <p class="mt-2 max-w-prose text-base leading-7 text-muted">
            The app reads the XSD, maps every field to a cell of the Excel template and fills sample values that
            pass the XSD and the BSP specification. You can review and change the mappings afterwards.
        </p>
    </header>

    <div class="mt-8 grid gap-10 xl:grid-cols-[minmax(0,1fr)_320px]">
        <form class="max-w-3xl space-y-8" data-submit="${self.on(function () { return self.create(); })}">
            <div>
                <label class="block text-sm font-semibold text-ink" for="sourceProject">Project</label>
                <p class="mt-1 max-w-prose text-sm text-muted">
                    Pick a project that was already uploaded to reuse some of its files (for example the same XSD and specification with a new template), or start a new one. Each set of XSD, template and specification has one project.
                </p>
                <select autocomplete="off" id="sourceProject" class="mt-2 h-11 w-full max-w-md rounded-app border border-line bg-surface px-3 text-sm outline-none transition hover:border-slate-300 focus:border-accent disabled:opacity-60"
                        ${Frp.attr("disabled", self.busy || self.loadingSource)} data-change="${self.on(function (e) { return self.chooseSource(e.target.value); })}">
                    <option value=""${Frp.attr("selected", !self.sourceProjectId)}>+ New project</option>
                    ${self.existing.map(function (p) {
                        return html`<option value="${p.id}"${Frp.attr("selected", self.sourceProjectId === p.id)}>${p.name} · created ${Frp.date(p.createdAt, true)} by ${p.createdBy}</option>`;
                    })}
                </select>
                ${self.projectsNote ? html`<p class="mt-2 text-xs text-subtle">${self.projectsNote}</p>` : ""}
                ${!self.sourceProjectId ? html`
                    <label class="mt-4 block text-sm font-semibold text-ink" for="projectName">Project name</label>
                    <p class="mt-1 text-sm text-muted">Optional. Defaults to the XSD file name.</p>
                    <input autocomplete="off" id="projectName" class="mt-2 h-11 w-full max-w-md rounded-app border border-line bg-surface px-3 text-sm outline-none transition placeholder:text-subtle hover:border-slate-300 focus:border-accent"
                           value="${self.projectName}" placeholder="Example: FRP solo, March 2026" maxlength="200"${Frp.attr("disabled", self.busy)}
                           data-input="${self.on(function (e) { self.projectName = e.target.value; })}" />`
                : self.loadingSource ? html`<p class="mt-3 flex items-center gap-2 text-sm text-muted" role="status">
                        <span class="h-4 w-4 animate-spin rounded-full border-2 border-accent-line border-t-accent" aria-hidden="true"></span>
                        Reading the files of the selected project…
                    </p>`
                : source ? html`<p class="mt-3 max-w-prose text-sm text-muted">
                        A new project named <span class="font-semibold text-ink">${source.projectName}</span> is created from these files.
                        The selected project itself is not changed.
                    </p>` : ""}
            </div>

            ${self.fileField(self.xsd, "xsd", "BSP XSD", "The report schema from BSP, for example FRP_v16.0_SOLO.xsd.", true)}
            ${self.fileField(self.template, "template", "BSP Excel input template",
                source && self.reuse.template && source.template ? "BSP's template keeps its layout and XML bindings." : self.template.options.help, false)}
            ${self.fileField(self.specification, "specification", "BSP specification",
                source && self.reuse.specification && source.specification ? "Adds BSP's titles and row labels, and its validation rules (totals, allowed codes, required schedules)." : self.specification.options.help, false)}

            ${self.sameFiles.length ? C.notice("Warning", "A project with these files already exists", html`
                <p>Each set of XSD, Excel template and specification has one project, so no new project was created. Open the existing one:</p>
                <ul class="mt-2 space-y-1">
                    ${self.sameFiles.map(function (existing) {
                        return html`<li>
                        <a class="font-semibold text-accent underline" href="${"projects/" + existing.id}">${existing.name}</a>
                        <span class="text-muted"> · ${existing.rootElement} · ${existing.status} · updated ${Frp.date(existing.updatedAt, true)}</span>
                    </li>`;
                    })}
                </ul>`) : ""}
            ${self.error ? C.notice("Error", "Files cannot be uploaded", self.error) : ""}
            ${self.busy && self.progress ? html`<div id="analysis-progress" tabindex="-1" class="outline-none">${self.progress.render()}</div>` : ""}

            <div class="flex items-center gap-3 border-t border-line pt-6">
                <button type="submit" class="inline-flex h-11 items-center gap-2 rounded-app bg-accent px-5 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-50"
                        ${Frp.attr("disabled", self.busy || self.loadingSource || !self.hasXsd())}>
                    <i class="ph ph-sparkle"></i> Create project
                </button>
                <a class="inline-flex h-11 items-center rounded-app px-4 text-sm font-semibold text-muted transition hover:bg-surface hover:text-ink" href="">Cancel</a>
            </div>
        </form>

        <aside class="h-fit rounded-app border border-line bg-surface p-6 text-sm leading-6 text-muted">
            <h2 class="font-display text-base font-bold text-ink">What happens next</h2>
            <ol class="mt-4 space-y-4">
                <li class="flex gap-3"><span class="font-semibold text-accent">1</span><span>You review the mappings and values, and export the Excel template to fill in.</span></li>
                <li class="flex gap-3"><span class="font-semibold text-accent">2</span><span>You attach the submission XML (exported from Excel, or built from the project) and submit it for review.</span></li>
                <li class="flex gap-3"><span class="font-semibold text-accent">3</span><span>A different person with the Checker role approves it or returns it with a comment.</span></li>
            </ol>
        </aside>
    </div>
</div>`;
        },

        close: function () {
            Frp.Page.prototype.close.call(this);
            if (this.progress) {
                this.progress.stop();
            }
        }
    });

    Frp.routes.push({ pattern: /^(projects)?$/, permission: P.ProjectRead, create: function (app) { return new Home(app); } });
    Frp.routes.push({ pattern: /^projects\/new$/, permission: P.ProjectCreate, create: function (app) { return new NewProject(app); } });
})();
