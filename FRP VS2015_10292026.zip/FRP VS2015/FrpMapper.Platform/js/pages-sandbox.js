// BSP submission: send a report XML to a BSP Report API environment (Sandbox, Production, … approved on the Settings tab)
// with the bank's own certificate (a UNI, RB or other bank PFX), then check its status and download BSP's results. The
// certificate and its password stay on this page only while it is open: they are never written to browser storage and are
// sent to the server only with a request. The Settings tab is where bank profile Makers propose environments and Checkers
// approve them; the hosts an environment may use are set by IT in the API's configuration.
(function () {
    "use strict";
    var F = window.Frp, html = F.html, C = F.components;

    var inputClass = "mt-2 h-11 w-full rounded-app border border-line bg-surface px-3 text-sm outline-none transition hover:border-slate-300 focus:border-accent disabled:opacity-60";
    var primaryClass = "inline-flex h-10 items-center gap-2 rounded-app bg-accent px-5 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-50";
    var secondaryClass = "inline-flex h-10 items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:cursor-not-allowed disabled:opacity-50";
    var quietClass = "inline-flex h-10 items-center gap-2 rounded-app px-3 text-sm font-semibold text-muted transition hover:bg-canvas hover:text-ink disabled:opacity-50";
    var guidPattern = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi;
    var dangerClass = "inline-flex h-10 items-center gap-2 rounded-app bg-red-700 px-5 text-sm font-semibold text-white transition hover:bg-red-800 disabled:cursor-not-allowed disabled:opacity-50";
    var smallPrimary = "inline-flex h-9 items-center gap-1.5 rounded-app bg-accent px-3 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50";
    var smallSecondary = "inline-flex h-9 items-center gap-1.5 rounded-app border border-line bg-surface px-3 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:opacity-50";
    var smallDanger = "inline-flex h-9 items-center gap-1.5 rounded-app bg-red-700 px-3 text-sm font-semibold text-white transition hover:bg-red-800 disabled:opacity-50";
    var maxCertificateBytes = 2 * 1024 * 1024, maxXmlBytes = 20 * 1024 * 1024;
    var tokenText = "{submissionId}";
    // The operations of BSP's Report API, as the Settings tab and the API (BspEndpointRules) name them.
    var operations = [
        { field: "submitPath", label: "Submit report", method: "POST", follow: false },
        { field: "statusPath", label: "Status", method: "GET", follow: true },
        { field: "resultPdfPath", label: "Validation result (PDF)", method: "GET", follow: true },
        { field: "resultXmlPath", label: "Validation result (XML)", method: "GET", follow: true },
        { field: "resultExcelPath", label: "Excel visualization", method: "GET", follow: true },
        { field: "receiptPath", label: "Submission receipt", method: "GET", follow: true }
    ];
    var pathPattern = /^(?:[A-Za-z0-9_-][A-Za-z0-9_.-]*|\{submissionId\})(?:\/(?:[A-Za-z0-9_-][A-Za-z0-9_.-]*|\{submissionId\}))*$/;
    var baseUrlPattern = /^https:\/\/([A-Za-z0-9.-]+)((?:\/[A-Za-z0-9_-][A-Za-z0-9_.-]*)*)\/?$/;
    var downloads = [
        { operation: "pdf", icon: "ph-file-pdf", label: "Validation result (PDF)" },
        { operation: "xml", icon: "ph-file-code", label: "Validation result (XML)" },
        { operation: "receipt", icon: "ph-receipt", label: "Submission receipt" },
        { operation: "excel", icon: "ph-file-xls", label: "Excel visualization" }
    ];
    var labels = { certificate: "Opening the certificate…", submit: "Sending the report to BSP…", status: "Asking BSP for the status…",
        pdf: "Downloading the validation result…", xml: "Downloading the validation result…", receipt: "Downloading the receipt…", excel: "Downloading the Excel visualization…" };

    /** The same comparison as the API (BankReferenceContext.Code): leading zeros do not count. */
    function code(value) {
        var c = String(value || "").trim().replace(/^0+/, "");
        return c.length ? c : "0";
    }

    function extension(name) {
        var dot = (name || "").lastIndexOf(".");
        return dot < 0 ? "" : name.substring(dot).toLowerCase();
    }

    function childNamed(element, name) {
        if (!element) {
            return null;
        }

        for (var node = element.firstElementChild; node; node = node.nextElementSibling) {
            if (node.localName === name) {
                return node;
            }
        }

        return null;
    }

    function pretty(text) {
        try {
            return JSON.stringify(JSON.parse(text), null, 2);
        } catch (e) {
            return text || "";
        }
    }

    function idsIn(text) {
        var seen = [];
        (String(text || "").match(guidPattern) || []).forEach(function (id) {
            id = id.toLowerCase();
            if (seen.indexOf(id) < 0) {
                seen.push(id);
            }
        });
        return seen;
    }

    function isProduction(environment) {
        return !!environment && environment.kind === "Production";
    }

    function kindBadge(kind) {
        return kind === "Production"
            ? html`<span class="inline-flex items-center gap-1.5 rounded-app border border-red-200 bg-red-50 px-2 py-0.5 text-xs font-semibold text-red-800"><i class="ph ph-warning-octagon" aria-hidden="true"></i> Production</span>`
            : html`<span class="inline-flex items-center gap-1.5 rounded-app border border-amber-200 bg-amber-50 px-2 py-0.5 text-xs font-semibold text-amber-800"><i class="ph ph-flask" aria-hidden="true"></i> Test</span>`;
    }

    /** The same checks as the API (BspEndpointRules): why a proposed environment cannot be sent, or null. */
    function environmentProblem(form, allowedHosts) {
        if (!/^[A-Z][A-Z0-9_]{1,31}$/.test(form.key.trim().toUpperCase())) return "The key is 2 to 32 letters, digits or underscores, starting with a letter (for example PRODUCTION).";
        if (!form.name.trim() || form.name.trim().length > 100) return "Enter a name of up to 100 characters.";
        if (form.kind !== "Test" && form.kind !== "Production") return "Choose Test or Production.";
        if (!/^\d{1,3}$/.test(String(form.sortOrder).trim())) return "The order is a whole number from 0 to 999.";
        var match = baseUrlPattern.exec(form.baseUrl.trim());
        if (!match || form.baseUrl.trim().length > 300) return "The base URL is https:// followed by the host and a plain path (no port, query or fragment).";
        if (allowedHosts.indexOf(match[1].toLowerCase()) < 0) return "The host " + match[1].toLowerCase() + " is not allowed on this server. Allowed: " + allowedHosts.join(", ") + ".";
        for (var i = 0; i < operations.length; i++) {
            var operation = operations[i], value = form[operation.field].trim().replace(/^\/+/, "");
            var count = value.split(tokenText).length - 1;
            if (!value || value.length > 200 || !pathPattern.test(value)) return operation.label + ": write a path relative to the base URL (letters, digits, '-', '_', '.', with '/' between parts).";
            if (operation.follow && count !== 1) return operation.label + ": the path must contain " + tokenText + " exactly once.";
            if (!operation.follow && count !== 0) return operation.label + ": the submit path cannot contain " + tokenText + ".";
        }

        return null;
    }

    function baseOf(url) {
        var text = String(url || "").trim();
        return text && text.charAt(text.length - 1) !== "/" ? text + "/" : text;
    }

    var Submission = F.page(function (app, match, query) {
        F.Page.call(this, app);
        this.canSubmit = F.can(F.Permissions.SubmissionPrepare);
        this.canManage = F.can(F.Permissions.ReferenceManage);
        this.canApprove = F.can(F.Permissions.ReferenceApprove);
        this.canSettings = this.canManage || this.canApprove;
        this.tab = !this.canSubmit || (query && query.get("tab") === "settings" && this.canSettings) ? "settings" : "submit";
        this.environments = null; this.environmentKey = ""; this.confirmText = "";
        this.settings = null; this.settingsError = null; this.settingsBusy = false; this.form = null; this.deciding = null; this.decisionComment = "";
        this.banks = null; this.loadError = null; this.bankKey = "";
        this.certificate = null; this.password = ""; this.certificateInfo = null; this.generation = 0; this.certificateSource = "upload";
        this.file = null; this.xmlHeader = null; this.xmlToken = 0; this.reportCode = ""; this.period = ""; this.confirm = false;
        // The reportInfo as edited by the person, or null while it is generated from the fields.
        this.reportInfoText = null;
        this.submissionId = ""; this.response = null; this.responseIds = []; this.error = null; this.message = null;
        this.busy = null; this.history = []; this.noticeStep = 1;
    }, {
        title: function () { return (this.tab === "settings" ? "BSP environments" : "BSP submission") + " · FRP Mapper"; },

        init: function () {
            var self = this, loads = [];
            if (self.canSubmit) {
                loads.push(Promise.all([F.api.get("sandbox/banks"), F.api.get("sandbox/environments")]).then(function (results) {
                    self.banks = results[0] || [];
                    self.environments = results[1] || [];
                    if (self.banks.length === 1) {
                        self.chooseBank(self.banks[0].key);
                    }

                    var usable = self.environments.filter(function (e) { return e.canUse; });
                    var firstTest = usable.filter(function (e) { return !isProduction(e); })[0];
                    // Never preselect Production: the person chooses it.
                    if (firstTest) {
                        self.environmentKey = firstTest.key;
                    }
                }, function (e) {
                    self.loadError = F.messageOf(e);
                }));
            }

            if (self.canSettings) {
                loads.push(self.loadSettings());
            }

            return Promise.all(loads);
        },

        loadSettings: function () {
            var self = this;
            return F.api.get("reference/bsp-environments").then(function (settings) {
                self.settings = settings;
                self.settingsError = null;
            }, function (e) {
                self.settingsError = F.messageOf(e);
            });
        },

        /** The submission form's environments again, after the Settings tab changed one. */
        reloadEnvironments: function () {
            var self = this;
            if (!self.canSubmit) {
                return Promise.resolve();
            }

            return F.api.get("sandbox/environments", null, { quiet: true }).then(function (list) {
                self.environments = list || [];
                if (!self.environment()) {
                    self.environmentKey = "";
                    self.confirmText = "";
                }
            }, function () { });
        },

        environment: function () {
            var key = this.environmentKey;
            return (this.environments || []).filter(function (e) { return e.key === key; })[0] || null;
        },

        chooseEnvironment: function (key) {
            this.environmentKey = key;
            this.confirmText = "";
            this.confirm = false;
            this.response = null; this.responseIds = [];
        },

        switchTo: function (tab) {
            this.tab = tab;
            this.form = null; this.deciding = null;
            try {
                window.history.replaceState(window.history.state, "", tab === "settings" ? "sandbox?tab=settings" : "sandbox");
            } catch (e) { }
            document.title = this.title();
            this.update();
        },

        close: function () {
            this.forgetCertificate();
            this.file = null;
            F.Page.prototype.close.call(this);
        },

        /** A bank with an approved stored certificate uses it unless the person chooses to upload one for this request. */
        chooseBank: function (key) {
            this.bankKey = key;
            var bank = this.bank();
            this.certificateSource = bank && bank.storedCertificate ? "stored" : "upload";
            this.certificateInfo = null;
            this.confirm = false;
            this.error = null;
        },

        usesStored: function () {
            var bank = this.bank();
            return this.certificateSource === "stored" && !!(bank && bank.storedCertificate);
        },

        hasCertificate: function () {
            return this.usesStored() || !!this.certificate;
        },

        bank: function () {
            var key = this.bankKey;
            return (this.banks || []).filter(function (b) { return b.key === key; })[0] || null;
        },

        forgetCertificate: function () {
            this.certificate = null; this.password = ""; this.certificateInfo = null; this.confirm = false; this.generation++;
        },

        chooseCertificate: function (file) {
            this.error = null; this.message = null; this.noticeStep = 1;
            this.certificateInfo = null; this.confirm = false;
            if (file && [".pfx", ".p12"].indexOf(extension(file.name)) < 0) {
                this.certificate = null;
                F.toast("Error", null, file.name + " is not a PFX certificate. Choose the bank's .pfx (or .p12) file.");
            } else if (file && file.size > maxCertificateBytes) {
                this.certificate = null;
                F.toast("Error", null, file.name + " is larger than 2 MB, which no bank certificate is. Choose the bank's PFX file.");
            } else {
                this.certificate = file || null;
            }

            this.update();
        },

        chooseXml: function (file) {
            var self = this;
            self.error = null; self.message = null; self.confirm = false; self.xmlHeader = null; self.noticeStep = 2;
            var token = ++self.xmlToken;
            if (file && extension(file.name) !== ".xml") {
                self.file = null;
                F.toast("Error", null, file.name + " is not an XML file.");
                self.update();
                return Promise.resolve();
            }

            if (file && file.size > maxXmlBytes) {
                self.file = null;
                F.toast("Error", null, file.name + " is larger than the 20 MB limit for a BSP submission.");
                self.update();
                return Promise.resolve();
            }

            self.file = file || null;
            self.update();
            if (!file) {
                return Promise.resolve();
            }

            // Read only to show which bank the report says it is for; the API checks it again before sending.
            return file.arrayBuffer().then(function (buffer) {
                if (token !== self.xmlToken || self.closed) {
                    return;
                }

                var doc = new DOMParser().parseFromString(new TextDecoder("utf-8").decode(buffer), "application/xml");
                if (doc.getElementsByTagName("parsererror").length || !doc.documentElement) {
                    self.xmlHeader = { error: true };
                } else {
                    var header = childNamed(doc.documentElement, "Header");
                    var undertaking = childNamed(header, "Undertaking"), year = childNamed(header, "Year"), month = childNamed(header, "Period");
                    self.xmlHeader = { root: doc.documentElement.localName, undertaking: undertaking ? undertaking.textContent.trim() : "",
                        year: year ? year.textContent.trim() : "", period: month ? month.textContent.trim() : "" };
                    self.fillFromXml();
                }

                self.update();
            }, function () {
                if (token === self.xmlToken && !self.closed) {
                    self.xmlHeader = { error: true };
                    self.update();
                }
            });
        },

        /**
         * The report code (the root element: BSP's XSDs have no code in the Header), the period (Header Year and Period)
         * and the bank (provider code = Header Undertaking) taken from the chosen XML. A value the person typed or chose
         * is kept; one filled from an earlier XML is replaced.
         */
        fillFromXml: function () {
            var header = this.xmlHeader, auto = this.fromXml || {};
            if (!header || header.error) return;
            var reportCode = /^[A-Za-z0-9_]{1,40}$/.test(header.root) ? header.root : "";
            var month = /^\d{1,2}$/.test(header.period) ? Number(header.period) : 0;
            var period = /^\d{4}$/.test(header.year) && month >= 1 && month <= 12 ? header.year + "-" + (month < 10 ? "0" : "") + month : "";
            var matching = header.undertaking ? (this.banks || []).filter(function (b) { return code(b.providerCode) === code(header.undertaking); }) : [];
            var bank = matching.length === 1 ? matching[0].key : "";
            if (reportCode && (!this.reportCode || this.reportCode === auto.reportCode)) this.reportCode = reportCode;
            if (period && (!this.period || this.period === auto.period)) this.period = period;
            if (bank && (!this.bankKey || this.bankKey === auto.bank) && bank !== this.bankKey) this.chooseBank(bank);
            this.fromXml = { reportCode: reportCode, period: period, bank: bank };
        },

        /** "From the XML" next to a field filled from it and not changed since. */
        fromXmlNote: function (field, value) {
            return this.fromXml && this.fromXml[field] && this.fromXml[field] === value
                ? html`<span class="ml-1.5 inline-flex items-center gap-1 rounded bg-accent-soft px-1.5 py-0.5 text-xs font-semibold text-accent"><i class="ph ph-file-code" aria-hidden="true"></i> From the XML</span>` : "";
        },

        /** Why the report cannot be sent yet, or null. */
        submitProblem: function () {
            var environment = this.environment();
            if (!environment) return "Choose the BSP environment.";
            if (!environment.canUse) return "Your role cannot use " + environment.name + ".";
            var bank = this.bank();
            if (!bank) return "Choose the bank the report is for.";
            if (!bank.undertakingCode) return "Bank profile " + bank.key + " has no BSP API undertaking code yet.";
            if (!this.hasCertificate()) return "Choose the bank's PFX certificate.";
            if (!this.usesStored() && !this.certificateInfo) return "Check the certificate.";
            if (this.reportInfoText === null) {
                if (!/^[A-Za-z0-9_]{1,40}$/.test(this.reportCode)) return "Enter the BSP report code.";
                if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(this.period)) return "Enter the reporting period.";
            }

            if (!this.file) return "Choose the report XML.";
            if (this.xmlHeader && this.xmlHeader.error) return "The XML cannot be read. Choose a well-formed report XML.";
            if (this.headerMismatch()) return "The XML is for another bank.";
            if (isProduction(environment) && this.confirmText.trim() !== environment.key) return "Type " + environment.key + " to confirm a real submission.";
            return this.reportInfoProblem();
        },

        /** The reportInfo generated from the fields (what is sent while the person has not edited it). */
        generatedReportInfo: function () {
            var bank = this.bank();
            return { reportCode: this.reportCode, undertakingCode: bank && bank.undertakingCode ? bank.undertakingCode : "",
                period: this.period, mainFile: { filename: this.file ? this.file.name : "" } };
        },

        /** The reportInfo text shown in the editor: the person's own, or the generated one. */
        reportInfoShown: function () {
            return this.reportInfoText !== null ? this.reportInfoText : JSON.stringify(this.generatedReportInfo(), null, 2);
        },

        /** The edited reportInfo as an object, or null when it is not a JSON object. */
        parsedReportInfo: function () {
            try {
                var value = JSON.parse(this.reportInfoText);
                return value && typeof value === "object" && !Array.isArray(value) ? value : null;
            } catch (e) {
                return null;
            }
        },

        /** Only JSON object structure is checked here; BSP decides which fields and values are valid for the report. */
        reportInfoProblem: function () {
            if (this.reportInfoText === null) return null;
            var info;
            try {
                info = JSON.parse(this.reportInfoText);
            } catch (e) {
                return "reportInfo is not valid JSON: " + e.message;
            }
            return info && typeof info === "object" && !Array.isArray(info) ? null : "reportInfo must be a JSON object { … }.";
        },

        /** The edited body is independent of the fields used to generate the initial body. */
        editReportInfo: function (text) {
            this.reportInfoText = text;
            this.confirm = false;
        },

        headerMismatch: function () {
            var bank = this.bank(), header = this.xmlHeader;
            return !!(bank && header && !header.error && header.undertaking && code(header.undertaking) !== code(bank.providerCode));
        },

        execute: function (operation) {
            var self = this;
            if (self.busy) {
                return Promise.resolve();
            }

            self.noticeStep = operation === "certificate" ? 1 : operation === "submit" ? 2 : 3;
            var environment = self.environment();
            if (operation !== "certificate" && !(environment && environment.canUse)) {
                F.toast("Error", null, "Choose the BSP environment first.");
                self.update();
                return Promise.resolve();
            }

            if (!self.hasCertificate()) {
                F.toast("Error", null, self.certificateSource === "stored" ? "Choose the bank whose stored certificate to use." : "Choose the bank's PFX certificate first.");
                self.update();
                return Promise.resolve();
            }

            if (operation === "submit" && self.submitProblem()) {
                F.toast("Error", null, self.submitProblem());
                self.update();
                return Promise.resolve();
            }

            // The stored certificate is opened on the server: the page sends only which bank's.
            var fields = self.usesStored() ? { certificateSource: "stored", bank: self.bankKey } : { certificateSource: "upload", certificate: self.certificate, password: self.password };
            if (operation !== "certificate") {
                fields.environment = environment.key;
            }

            if (operation === "submit") {
                fields.bank = self.bankKey;
                fields.reportCode = self.reportCode;
                fields.period = self.period;
                if (isProduction(environment)) {
                    fields.confirmEnvironment = self.confirmText.trim();
                }

                fields.file = self.file;
                if (self.reportInfoText !== null) {
                    fields.reportInfo = self.reportInfoText;
                }
            } else if (operation !== "certificate") {
                fields.submissionId = self.submissionId.trim();
            }

            var download = downloads.some(function (d) { return d.operation === operation; });
            var editedInfo = self.reportInfoText !== null ? self.parsedReportInfo() : null;
            var sentFor = { environment: environment ? environment.name : "", bank: self.bankKey,
                reportCode: editedInfo ? (typeof editedInfo.reportCode === "string" ? editedInfo.reportCode : "—") : self.reportCode,
                period: editedInfo ? (typeof editedInfo.period === "string" ? editedInfo.period : "—") : self.period,
                file: self.file ? self.file.name : "" };
            self.busy = operation; self.error = null; self.message = null;
            if (operation !== "certificate") {
                self.response = null; self.responseIds = [];
            }

            self.update();
            return (download ? F.api.file("sandbox/" + operation, fields) : F.api.upload("sandbox/" + operation, fields))
                .then(function (result) {
                    if (self.closed) return;
                    if (operation === "certificate") {
                        self.certificateInfo = result;
                        return;
                    }

                    if (download) {
                        F.saveFile(result.name, result.blob);
                        F.toast("Success", null, "Downloaded " + result.name + ".");
                        return;
                    }

                    self.response = { operation: operation, statusCode: result.statusCode, body: result.body || "" };
                    self.responseIds = idsIn(result.body);
                    if (operation === "submit") {
                        self.confirm = false;
                        self.confirmText = "";
                        self.history.unshift({ at: new Date(), environment: sentFor.environment, bank: sentFor.bank, reportCode: sentFor.reportCode, period: sentFor.period, file: sentFor.file,
                            statusCode: result.statusCode, id: self.responseIds.length === 1 ? self.responseIds[0] : "" });
                    }
                }, function (e) {
                    if (self.closed) return;
                    F.toast("Error", null, F.messageOf(e));
                    if (e && e.details && e.details.bspResponse) {
                        self.response = { operation: operation, statusCode: null, body: e.details.bspResponse };
                    }
                })
                .then(function () {
                    self.busy = null;
                    self.update();
                });
        },

        renderEnvironment: function () {
            var self = this, environment = self.environment(), off = !!self.busy, list = self.environments || [];
            if (!list.length) {
                return C.notice("Warning", "No BSP environment is approved yet", html`<p>A bank profile Maker adds one (for example the BSP sandbox) on the
                    ${self.canSettings ? html`<button type="button" class="font-semibold text-accent underline" data-click="${self.on(function () { self.switchTo("settings"); })}">Settings tab</button>` : "Settings tab"}
                    and a Checker approves it.</p>`);
            }

            return html`<div>
    <label class="block text-sm font-semibold text-ink" for="bspEnvironment">BSP environment</label>
    <p class="mt-1 max-w-prose text-sm text-muted">Where the report and the follow-up requests go. Environments are approved on the Settings tab.</p>
    <select id="bspEnvironment" autocomplete="off" class="${inputClass} max-w-xl"${F.attr("disabled", off)}
            data-change="${self.on(function (e) { self.chooseEnvironment(e.target.value); self.update(); })}">
        <option value=""${F.attr("selected", !environment)}>Choose the environment</option>
        ${list.map(function (e) {
            return html`<option value="${e.key}"${F.attr("selected", environment && environment.key === e.key)}${F.attr("disabled", !e.canUse)}>${e.name} · ${e.kind}${e.canUse ? "" : " (needs submission.production)"}</option>`;
        })}
    </select>
    ${environment ? html`<dl class="mt-3 grid max-w-xl grid-cols-[auto_minmax(0,1fr)] gap-x-6 gap-y-1 rounded-app border ${isProduction(environment) ? "border-red-200 bg-red-50/60" : "border-line"} px-4 py-3 text-sm">
        <dt class="text-subtle">Kind</dt><dd>${kindBadge(environment.kind)}</dd>
        <dt class="text-subtle">Submit</dt><dd class="min-w-0 break-all font-mono text-xs text-ink">POST ${environment.submitUrl}</dd>
        <dt class="text-subtle">Status</dt><dd class="min-w-0 break-all font-mono text-xs text-ink">GET ${environment.statusUrl}</dd>
    </dl>
    ${isProduction(environment) ? html`<div class="mt-3 max-w-xl">${C.notice("Error", "Production: real submissions", html`<p>Reports sent here are official submissions to BSP. Use the Sandbox to test.</p>`)}</div>` : ""}` : ""}
</div>`;
        },

        renderBank: function () {
            var self = this, bank = self.bank(), off = !!self.busy;
            if (!self.banks.length) {
                return C.notice("Warning", "No bank profiles yet", html`<p>A bank profile Maker adds the bank (for example UNI and RB) on Bank profiles, and a Checker approves it.</p>`);
            }

            return html`<div>
    <label class="block text-sm font-semibold text-ink" for="bspBank">Bank${self.fromXmlNote("bank", self.bankKey)}</label>
    <p class="mt-1 max-w-prose text-sm text-muted">The bank the report and the certificate belong to; chosen from the XML's Header/Undertaking when you choose the XML. Its BSP API undertaking code comes from its approved bank profile.</p>
    <select id="bspBank" autocomplete="off" class="${inputClass} max-w-xl"${F.attr("disabled", off)}
            data-change="${self.on(function (e) { self.chooseBank(e.target.value); self.update(); })}">
        <option value=""${F.attr("selected", !bank)}>Choose the bank (UNI, RB…)</option>
        ${self.banks.map(function (b) { return html`<option value="${b.key}"${F.attr("selected", bank && bank.key === b.key)}>${b.key} · ${b.name}</option>`; })}
    </select>
    ${bank ? html`<dl class="mt-3 grid max-w-xl grid-cols-[auto_minmax(0,1fr)] gap-x-6 gap-y-1 rounded-app border border-line px-4 py-3 text-sm">
        <dt class="text-subtle">Provider code</dt><dd class="font-mono text-ink">${bank.providerCode}</dd>
        <dt class="text-subtle">BSP API undertaking code</dt>
        <dd>${bank.undertakingCode ? html`<span class="font-mono text-ink">${bank.undertakingCode}</span>`
            : html`<span class="inline-flex items-center gap-1.5 font-semibold text-amber-800"><i class="ph ph-warning" aria-hidden="true"></i> Not set</span>`}</dd>
    </dl>
    ${!bank.undertakingCode ? html`<div class="mt-3 max-w-xl">${C.notice("Warning", null, html`<p>Bank profile ${bank.key} has no BSP API undertaking code, so its reports cannot be sent yet. A bank profile Maker adds it on
        ${F.can(F.Permissions.ReferenceManage) ? html`<a class="font-semibold text-accent underline" href="Pages/BankProfiles.aspx">Bank profiles</a>` : "Bank profiles"} and a Checker approves it. You can still check a certificate and follow up an earlier submission.</p>`)}</div>` : ""}` : ""}
</div>`;
        },

        renderCertificate: function () {
            var self = this, info = self.certificateInfo, off = !!self.busy, file = self.certificate, bank = self.bank();
            var stored = bank && bank.storedCertificate;
            var chooser = stored ? html`<fieldset class="mb-5">
    <legend class="text-sm font-semibold text-ink">Certificate</legend>
    <div class="mt-2 flex flex-wrap gap-x-6 gap-y-2 text-sm">
        <label class="flex items-center gap-2"><input type="radio" name="bspSource" value="stored"${F.attr("checked", self.certificateSource === "stored")}${F.attr("disabled", off)}
            data-change="${self.on(function () { self.certificateSource = "stored"; self.certificateInfo = null; self.confirm = false; self.update(); })}" /> Use ${bank.key}'s stored certificate</label>
        <label class="flex items-center gap-2"><input type="radio" name="bspSource" value="upload"${F.attr("checked", self.certificateSource === "upload")}${F.attr("disabled", off)}
            data-change="${self.on(function () { self.certificateSource = "upload"; self.certificateInfo = null; self.confirm = false; self.update(); })}" /> Upload a certificate for this request</label>
    </div>
</fieldset>` : "";
            if (self.usesStored()) {
                var until = new Date(stored.validUntil).getTime(), days = Math.floor((until - Date.now()) / 86400000);
                return html`${chooser}<div class="rounded-app border border-accent-line bg-accent-soft px-4 py-3 text-sm">
    <p class="flex items-center gap-2 font-semibold text-ink"><i class="ph ph-seal-check text-lg text-accent" aria-hidden="true"></i> ${bank.key}'s approved certificate</p>
    <dl class="mt-2 grid grid-cols-[auto_minmax(0,1fr)] gap-x-6 gap-y-1">
        <dt class="text-subtle">Subject</dt><dd class="min-w-0 break-words text-ink">${stored.subject}</dd>
        <dt class="text-subtle">Valid until</dt><dd class="text-ink">${F.date(stored.validUntil)}${until <= Date.now() ? html` <span class="font-semibold text-red-700">Expired</span>` : days < 30 ? html` <span class="font-semibold text-amber-800">Expires in ${days} day${days === 1 ? "" : "s"}</span>` : ""}</dd>
        <dt class="text-subtle">Thumbprint</dt><dd class="min-w-0 break-all font-mono text-xs text-ink">${stored.thumbprint}</dd>
    </dl>
    <p class="mt-2 text-xs text-muted">Stored on Bank profiles and opened on the server for each request; no upload or password needed.</p>
</div>`;
            }

            return html`${chooser}<div class="grid gap-6 lg:grid-cols-2">
    <div>
        <span class="block text-sm font-semibold text-ink">Certificate (.pfx)</span>
        <p class="mt-1 text-sm text-muted">The bank's own BSP certificate with its private key, for example the UNI or the RB one.</p>
        <label data-key="${"pfx-" + self.generation}" class="mt-2 flex cursor-pointer items-center gap-3 rounded-app border border-dashed px-4 py-3 text-sm transition ${!file ? "border-line bg-surface hover:border-accent hover:bg-accent-soft" : "border-accent-line bg-accent-soft"} ${off ? "pointer-events-none opacity-60" : ""}">
            <i class="ph ${!file ? "ph-certificate" : "ph-check-circle"} text-lg ${!file ? "text-subtle" : "text-accent"}" aria-hidden="true"></i>
            <span class="min-w-0 flex-1">
                ${!file ? html`<span class="font-medium text-ink">Choose a certificate</span> <span class="text-subtle">.pfx or .p12 · up to 2 MB</span>`
                    : html`<span class="block truncate font-medium text-ink">${file.name}</span><span class="text-xs text-subtle">${F.size(file.size)} · click to replace</span>`}
            </span>
            <input type="file" class="sr-only" accept=".pfx,.p12"${F.attr("disabled", off)}
                   data-change="${self.on(function (e) { var chosen = e.target.files[0]; e.target.value = ""; if (chosen) { self.chooseCertificate(chosen); } })}" />
        </label>
    </div>
    <div>
        <label class="block text-sm font-semibold text-ink" for="bspPassword">Certificate password</label>
        <p class="mt-1 text-sm text-muted">Leave empty if the PFX has no password. It is never saved.</p>
        <input id="bspPassword" type="password" autocomplete="new-password" class="${inputClass}" value="${self.password}"${F.attr("disabled", off)}
               data-input="${self.on(function (e) { self.password = e.target.value; self.certificateInfo = null; self.confirm = false; self.update(); })}" />
    </div>
</div>
<div class="mt-4 flex flex-wrap items-center gap-2">
    <button type="button" class="${secondaryClass}"${F.attr("disabled", off || !file)} data-click="${self.on(function () { return self.execute("certificate"); })}">
        ${self.busy === "certificate" ? html`<span class="h-4 w-4 animate-spin rounded-full border-2 border-accent/30 border-t-accent" aria-hidden="true"></span>` : html`<i class="ph ph-shield-check" aria-hidden="true"></i>`}
        Check certificate
    </button>
    ${file ? html`<button type="button" class="${quietClass}"${F.attr("disabled", off)} data-click="${self.on(function () { self.forgetCertificate(); self.update(); })}">
        <i class="ph ph-x" aria-hidden="true"></i> Remove certificate
    </button>` : ""}
</div>
${info ? html`<div class="mt-4 rounded-app border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm">
    <p class="flex items-center gap-2 font-semibold text-emerald-900"><i class="ph ph-check-circle text-lg text-emerald-700" aria-hidden="true"></i> ${info.name || "Certificate"} opened</p>
    <dl class="mt-2 grid grid-cols-[auto_minmax(0,1fr)] gap-x-6 gap-y-1">
        <dt class="text-subtle">Subject</dt><dd class="min-w-0 break-words text-ink">${info.subject}</dd>
        <dt class="text-subtle">Issuer</dt><dd class="min-w-0 break-words text-ink">${info.issuer}</dd>
        <dt class="text-subtle">Valid</dt><dd class="text-ink">${F.date(info.validFrom)} – ${F.date(info.validUntil)}</dd>
        <dt class="text-subtle">Thumbprint</dt><dd class="min-w-0 break-all font-mono text-xs text-ink">${info.thumbprint}</dd>
    </dl>
    <p class="mt-2 text-xs text-muted">${info.otherCertificates ? info.otherCertificates + " issuer certificate" + (info.otherCertificates === 1 ? " in the PFX is" : "s in the PFX are") + " not sent. " : ""}Check that this is the certificate of the bank chosen above. BSP checks it when a request is sent.</p>
</div>` : ""}`;
        },

        renderSubmit: function () {
            var self = this, bank = self.bank(), header = self.xmlHeader, off = !!self.busy, file = self.file, environment = self.environment();
            var production = isProduction(environment);
            var problem = self.submitProblem();
            var edited = self.reportInfoText !== null, shown = self.reportInfoShown(), infoProblem = self.reportInfoProblem();
            var rows = Math.min(24, Math.max(8, shown.split("\n").length + 1));
            var headerNote = "";
            if (file && header) {
                if (header.error) {
                    headerNote = html`<p class="mt-2 flex items-center gap-1.5 text-xs font-semibold text-red-700"><i class="ph ph-x-circle" aria-hidden="true"></i> This file is not well-formed XML.</p>`;
                } else if (self.headerMismatch()) {
                    headerNote = html`<p class="mt-2 flex items-start gap-1.5 text-xs font-semibold text-red-700"><i class="ph ph-x-circle mt-0.5" aria-hidden="true"></i>
                        Header/Undertaking is ${header.undertaking}, but ${bank.key}'s provider code is ${bank.providerCode}. Choose the matching bank and its certificate.</p>`;
                } else if (header.undertaking) {
                    headerNote = html`<p class="mt-2 flex items-center gap-1.5 text-xs text-muted"><i class="ph ph-check-circle text-emerald-700" aria-hidden="true"></i>
                        ${header.root} · Header/Undertaking ${header.undertaking}${bank ? " matches " + bank.key : ""}</p>`;
                } else {
                    headerNote = html`<p class="mt-2 text-xs text-muted">${header.root} · no Header/Undertaking found</p>`;
                }
            }

            return html`<div class="grid gap-6 lg:grid-cols-2">
    <div>
        <label class="block text-sm font-semibold text-ink" for="bspReportCode">Report code${self.fromXmlNote("reportCode", self.reportCode)}</label>
        <p class="mt-1 text-sm text-muted">Filled from the XML's root element when you choose it. Used to generate the initial JSON body.</p>
        <input id="bspReportCode" autocomplete="off" maxlength="40" class="${inputClass} font-mono" value="${self.reportCode}"${F.attr("disabled", off)}
               data-input="${self.on(function (e) { self.reportCode = e.target.value.trim(); self.confirm = false; self.update(); })}" />
    </div>
    <div>
        <label class="block text-sm font-semibold text-ink" for="bspPeriod">Reporting period${self.fromXmlNote("period", self.period)}</label>
        <p class="mt-1 text-sm text-muted">Filled from the XML's Header Year and Period. Used to generate the initial JSON body.</p>
        <input id="bspPeriod" type="month" autocomplete="off" class="${inputClass}" value="${self.period}"${F.attr("disabled", off)}
               data-input="${self.on(function (e) { self.period = e.target.value; self.confirm = false; self.update(); })}" />
    </div>
    <div class="lg:col-span-2">
        <span class="block text-sm font-semibold text-ink">Report XML</span>
        <p class="mt-1 max-w-prose text-sm text-muted">Validate it on the Validate page first. Sent exactly as chosen.</p>
        <label class="mt-2 flex cursor-pointer items-center gap-3 rounded-app border border-dashed px-4 py-3 text-sm transition ${!file ? "border-line bg-surface hover:border-accent hover:bg-accent-soft" : "border-accent-line bg-accent-soft"} ${off ? "pointer-events-none opacity-60" : ""}">
            <i class="ph ${!file ? "ph-upload-simple" : "ph-file-code"} text-lg ${!file ? "text-subtle" : "text-accent"}" aria-hidden="true"></i>
            <span class="min-w-0 flex-1">
                ${!file ? html`<span class="font-medium text-ink">Choose a file</span> <span class="text-subtle">.xml · up to 20 MB</span>`
                    : html`<span class="block truncate font-medium text-ink">${file.name}</span><span class="text-xs text-subtle">${F.size(file.size)} · click to replace</span>`}
            </span>
            <input type="file" class="sr-only" accept=".xml"${F.attr("disabled", off)}
                   data-change="${self.on(function (e) { var chosen = e.target.files[0]; e.target.value = ""; if (chosen) { return self.chooseXml(chosen); } })}" />
        </label>
        ${headerNote}
    </div>
</div>
<div class="mt-6">
    <span class="block text-sm font-semibold text-ink">What BSP receives</span>
    <div class="mt-2 rounded-app border border-line bg-canvas px-4 py-3 text-sm">
    <span class="block font-semibold text-ink">POST</span>
    <p class="mt-1 min-w-0 break-all font-mono text-xs text-ink">${environment ? environment.submitUrl : "Choose the BSP environment in step 1."}</p>
    <p class="mt-1 text-xs text-muted">From the approved ${environment ? environment.name : "environment"} settings. A bank profile Maker proposes changes on the Settings tab.</p>
    <div class="mt-4 min-w-0">
            <label class="block font-semibold text-ink" for="bspReportInfo">Body · reportInfo</label>
            <p class="mt-1 text-xs text-muted">Edit any fields for this BSP report. Only JSON object structure is checked here; BSP checks the report content.</p>
            <textarea id="bspReportInfo" rows="${rows}" spellcheck="false" autocomplete="off" aria-describedby="bspReportInfoNote"
                class="mt-2 block w-full min-w-0 rounded-app border ${infoProblem ? "border-red-300" : "border-line"} bg-surface px-3 py-2 font-mono text-xs text-ink outline-none transition hover:border-slate-300 focus:border-accent disabled:opacity-60" style="resize:vertical"${F.attr("disabled", off)}
                data-input="${self.on(function (e) { self.editReportInfo(e.target.value); self.update(); })}">${shown}</textarea>
            <div id="bspReportInfoNote" class="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
                ${infoProblem ? html`<span class="flex items-start gap-1.5 font-semibold text-red-700"><i class="ph ph-x-circle mt-0.5" aria-hidden="true"></i>${infoProblem}</span>`
                    : edited ? html`<span class="flex items-center gap-1.5 font-semibold text-amber-700"><i class="ph ph-pencil-simple" aria-hidden="true"></i>Edited · sent exactly as written; fields above will not overwrite it</span>`
                    : html`<span class="text-muted">Generated from the fields above. You can replace or extend this JSON.</span>`}
                ${edited ? html`<button type="button" class="font-semibold text-accent underline"${F.attr("disabled", off)}
                    data-click="${self.on(function () { self.reportInfoText = null; self.confirm = false; self.update(); })}">Reset to generated</button>` : ""}
            </div>
    </div>
    <dl class="mt-4 grid grid-cols-[auto_minmax(0,1fr)] gap-x-6 gap-y-1">
        <dt class="text-subtle">file</dt><dd class="min-w-0 truncate font-mono text-xs text-ink">${file ? file.name : "…"}</dd>
        <dt class="text-subtle">Certificate</dt><dd class="min-w-0 truncate text-xs text-ink">${self.usesStored() ? bank.storedCertificate.subject + " (stored)" : self.certificateInfo ? self.certificateInfo.name || self.certificateInfo.subject : "…"}</dd>
    </dl>
    </div>
</div>
${production ? html`<div class="mt-6 max-w-xl rounded-app border border-red-200 bg-red-50/60 px-4 py-3">
    <label class="block text-sm font-semibold text-red-900" for="bspConfirmEnvironment">Type ${environment.key} to confirm a real submission</label>
    <input id="bspConfirmEnvironment" autocomplete="off" spellcheck="false" class="${inputClass} font-mono" value="${self.confirmText}"${F.attr("disabled", off)}
           data-input="${self.on(function (e) { self.confirmText = e.target.value; self.update(); })}" />
</div>` : ""}
<div class="mt-4 flex flex-wrap items-center gap-3">
    <button type="button" class="${production ? dangerClass : primaryClass}"${F.attr("disabled", off || !!problem)} data-click="${self.on(function () {
        return F.confirm({
            title: production ? "Send a real submission to " + environment.name + "?" : "Send this test submission to " + environment.name + "?",
            message: "POST " + environment.submitUrl + ". " + (edited
                ? "Bank " + bank.key + ", file " + (file ? file.name : "") + ". The edited reportInfo is sent exactly as shown. Check its contents before you send."
                : "Bank " + bank.key + ", report " + self.reportCode + ", period " + self.period + ", file " + (file ? file.name : "") + ". Check them before you send."),
            confirmLabel: production ? "Submit to production" : "Submit",
            danger: production
        }).then(function (yes) { return yes ? self.execute("submit") : undefined; });
    })}">
        ${self.busy === "submit" ? html`<span class="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" aria-hidden="true"></span>` : html`<i class="ph ph-paper-plane-tilt" aria-hidden="true"></i>`}
        ${environment ? "Submit to " + environment.name : "Submit to BSP"}
    </button>
    ${problem && !off ? html`<span class="text-sm text-subtle">${problem}</span>` : ""}
</div>`;
        },

        renderFollowUp: function () {
            var self = this, off = !!self.busy;
            var validId = /^\s*[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\s*$/i.test(self.submissionId);
            var environment = self.environment();
            var blocked = off || !self.hasCertificate() || !validId || !(environment && environment.canUse);
            function button(operation, icon, label) {
                return html`<button type="button" class="${secondaryClass}"${F.attr("disabled", blocked)} data-click="${self.on(function () { return self.execute(operation); })}">
                    ${self.busy === operation ? html`<span class="h-4 w-4 animate-spin rounded-full border-2 border-accent/30 border-t-accent" aria-hidden="true"></span>` : html`<i class="ph ${icon}" aria-hidden="true"></i>`}
                    ${label}
                </button>`;
            }

            return html`<div class="max-w-xl">
    <label class="block text-sm font-semibold text-ink" for="bspSubmissionId">BSP submission ID</label>
    <p class="mt-1 text-sm text-muted">From BSP's answer to the submission. Use the certificate of the bank that submitted it.</p>
    <input id="bspSubmissionId" autocomplete="off" spellcheck="false" class="${inputClass} font-mono" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" value="${self.submissionId}"${F.attr("disabled", off)}
           data-input="${self.on(function (e) { self.submissionId = e.target.value; self.update(); })}" />
</div>
<div class="mt-4 flex flex-wrap gap-2">
    ${button("status", "ph-hourglass-medium", "Check status")}
    ${downloads.map(function (d) { return button(d.operation, d.icon, d.label); })}
</div>
${!(environment && environment.canUse) ? html`<p class="mt-3 text-sm text-subtle">Choose the BSP environment the submission was sent to in step 1 first.</p>`
    : !self.hasCertificate() ? html`<p class="mt-3 text-sm text-subtle">Choose the bank's certificate in step 1 first.</p>`
    : self.submissionId && !validId ? html`<p class="mt-3 text-sm text-subtle">A submission ID looks like 7735089b-81d6-405e-8e67-255338dbce9a.</p>` : ""}`;
        },

        renderResponse: function () {
            var self = this, response = self.response;
            if (!response) {
                return "";
            }

            var ok = response.statusCode >= 200 && response.statusCode < 300;
            return html`<section class="rounded-app border ${ok ? "border-line" : "border-red-200"} bg-surface p-6" aria-live="polite">
    <div class="flex flex-wrap items-center gap-3">
        <h2 class="font-display text-xl font-bold text-ink">BSP's answer</h2>
        ${response.statusCode !== null ? html`<span class="inline-flex items-center gap-1.5 rounded-app border px-2 py-0.5 text-xs font-semibold ${ok ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-red-200 bg-red-50 text-red-800"}">HTTP ${response.statusCode}</span>` : ""}
    </div>
    ${response.operation === "submit" ? html`<p class="mt-2 max-w-prose text-sm text-muted">An HTTP acknowledgment does not mean the report passed BSP's validation. Keep the submission ID and check its status.</p>` : ""}
    ${self.responseIds.length === 1 && self.responseIds[0] !== self.submissionId.trim().toLowerCase() ? html`<div class="mt-3 flex flex-wrap items-center gap-3 text-sm">
        <span>BSP's answer contains the ID <code class="font-mono text-ink">${self.responseIds[0]}</code>.</span>
        <button type="button" class="${secondaryClass}" data-click="${self.on(function () { self.submissionId = self.responseIds[0]; self.update(); })}"><i class="ph ph-arrow-down" aria-hidden="true"></i> Use as submission ID</button>
    </div>` : ""}
    <pre class="mt-4 max-h-96 overflow-auto whitespace-pre-wrap break-words rounded-app border border-line bg-canvas p-4 font-mono text-xs text-ink">${pretty(response.body) || "(empty answer)"}</pre>
</section>`;
        },

        renderHistory: function () {
            var self = this;
            if (!self.history.length) {
                return "";
            }

            return html`<section>
    <h2 class="font-display text-xl font-bold text-ink">Sent from this page</h2>
    <p class="mt-1 text-sm text-muted">Only while this page is open. Every request is also in the audit trail.</p>
    <div class="mt-3 overflow-x-auto rounded-app border border-line bg-surface">
        <table class="w-full min-w-[760px] text-left text-sm">
            <thead class="border-b border-line text-xs font-semibold text-subtle"><tr><th class="px-4 py-2">Sent</th><th class="px-4 py-2">Environment</th><th class="px-4 py-2">Bank</th><th class="px-4 py-2">Report</th><th class="px-4 py-2">File</th><th class="px-4 py-2">BSP</th><th class="px-4 py-2">Submission ID</th></tr></thead>
            <tbody>
                ${self.history.map(function (h) {
                    return html`<tr class="border-b border-line align-top last:border-0">
                        <td class="px-4 py-2 text-muted">${F.date(h.at, true, true)}</td><td class="px-4 py-2 text-ink">${h.environment}</td><td class="px-4 py-2 font-semibold text-ink">${h.bank}</td>
                        <td class="px-4 py-2 text-ink">${h.reportCode} · ${h.period}</td><td class="max-w-[14rem] truncate px-4 py-2 text-muted" title="${h.file}">${h.file}</td>
                        <td class="px-4 py-2 text-ink">HTTP ${h.statusCode}</td>
                        <td class="px-4 py-2">${h.id ? html`<button type="button" class="font-mono text-xs text-accent underline" data-click="${self.on(function () { self.submissionId = h.id; self.update(); })}">${h.id}</button>` : html`<span class="text-subtle">See BSP's answer</span>`}</td>
                    </tr>`;
                })}
            </tbody>
        </table>
    </div>
</section>`;
        },

        // ---------- Settings tab: BSP environments (Maker / Checker) ----------

        newForm: function (environment) {
            var form = { isNew: !environment, key: "", name: "", kind: "Test", sortOrder: "100", baseUrl: "" };
            operations.forEach(function (operation) { form[operation.field] = ""; });
            if (environment) {
                form.key = environment.key; form.name = environment.name; form.kind = environment.kind; form.sortOrder = String(environment.sortOrder);
                form.baseUrl = environment.baseUrl;
                operations.forEach(function (operation) { form[operation.field] = environment[operation.field]; });
            } else {
                // The Report API's operation paths as BSP's sandbox uses them; check them against BSP's documentation.
                var sandbox = (this.settings.environments || []).filter(function (e) { return e.status === "Active" && e.key === "SANDBOX"; })[0];
                if (sandbox) {
                    operations.forEach(function (operation) { form[operation.field] = sandbox[operation.field]; });
                }
            }

            return form;
        },

        propose: function () {
            var self = this, form = self.form;
            var problem = environmentProblem(form, self.settings.allowedHosts);
            if (problem) {
                F.toast("Error", null, problem);
                return Promise.resolve();
            }

            var body = { key: form.key.trim().toUpperCase(), name: form.name.trim(), kind: form.kind, sortOrder: parseInt(form.sortOrder, 10), baseUrl: baseOf(form.baseUrl) };
            operations.forEach(function (operation) { body[operation.field] = form[operation.field].trim().replace(/^\/+/, ""); });
            self.settingsBusy = true;
            self.update();
            return F.api.post("reference/bsp-environments", body, { busy: "Sending for approval" }).then(function () {
                self.form = null;
                F.toast("Success", null, body.key + " was sent for approval. A Checker of bank profiles must approve it before it is used.");
                return self.loadSettings();
            }, function (e) {
                F.toast("Error", null, F.messageOf(e));
            }).then(function () {
                self.settingsBusy = false;
                self.update();
            });
        },

        decide: function (environment, decision) {
            var self = this, comment = self.decisionComment.trim();
            if ((decision === "reject" || decision === "remove") && !comment) {
                F.toast("Error", null, decision === "reject" ? "Say why the change is rejected." : "Say why the environment is removed.");
                return Promise.resolve();
            }

            var ask = decision === "remove"
                ? F.confirm({ title: "Remove " + environment.name + "?", message: "BSP submission can no longer use " + environment.key + " until a new version is approved.", confirmLabel: "Remove", danger: true })
                : decision === "approve" && isProduction(environment)
                    ? F.confirm({ title: "Approve the Production environment " + environment.name + "?", message: "Reports sent to " + environment.baseUrl + " are real submissions to BSP.", confirmLabel: "Approve" })
                    : Promise.resolve(true);
            return ask.then(function (yes) {
                if (!yes) {
                    return undefined;
                }

                self.settingsBusy = true;
                self.update();
                return F.api.post("reference/bsp-environments/" + environment.id + "/" + decision, { version: environment.version, comment: comment || null }).then(function () {
                    var done = { approve: "approved", reject: "rejected", cancel: "cancelled", remove: "removed" }[decision];
                    F.toast("Success", null, environment.key + " " + (decision === "cancel" ? "change cancelled" : done) + ".");
                    self.deciding = null; self.decisionComment = "";
                    return Promise.all([self.loadSettings(), self.reloadEnvironments()]);
                }, function (e) {
                    F.toast("Error", null, F.messageOf(e));
                    return self.loadSettings();
                }).then(function () {
                    self.settingsBusy = false;
                    self.update();
                });
            });
        },

        /** The operations of an environment as full URLs. */
        renderOperations: function (environment, compareTo) {
            var base = baseOf(environment.baseUrl);
            return html`<div class="mt-3 overflow-x-auto">
    <table class="w-full min-w-[560px] text-left text-sm">
        <thead class="text-xs font-semibold text-subtle"><tr><th class="py-1 pr-4">Operation</th><th class="py-1 pr-4">Method</th><th class="py-1">URL</th></tr></thead>
        <tbody>
            ${operations.map(function (operation) {
                var changed = compareTo && (compareTo[operation.field] !== environment[operation.field] || baseOf(compareTo.baseUrl) !== base);
                return html`<tr class="align-top">
                    <td class="py-1 pr-4 text-ink">${operation.label}</td>
                    <td class="py-1 pr-4 font-mono text-xs text-muted">${operation.method}</td>
                    <td class="min-w-0 break-all py-1 font-mono text-xs ${changed ? "font-semibold text-amber-900" : "text-ink"}">${base}${environment[operation.field]}${changed ? html` <span class="font-sans text-amber-800">(was ${baseOf(compareTo.baseUrl)}${compareTo[operation.field]})</span>` : ""}</td>
                </tr>`;
            })}
        </tbody>
    </table>
</div>`;
        },

        renderPendingEnvironments: function (pending, active) {
            var self = this, me = F.session.user.name, off = self.settingsBusy;
            return html`<section aria-labelledby="bsp-pending-title">
    <h2 id="bsp-pending-title" class="font-display text-xl font-bold text-ink">Waiting for approval</h2>
    ${!pending.length ? html`<p class="mt-2 text-sm text-muted">Nothing is waiting for approval.</p>` : html`<ul class="mt-4 space-y-3">
        ${pending.map(function (environment) {
            var mine = F.sameName(environment.requestedBy, me);
            var current = active.filter(function (a) { return a.key === environment.key; })[0] || null;
            var actions;
            if (mine) {
                actions = html`<span class="text-xs text-muted">Another Checker of bank profiles must approve your change.</span>
                    ${self.canManage ? html`<button type="button" class="${smallSecondary}"${F.attr("disabled", off)} data-click="${self.on(function () { return self.decide(environment, "cancel"); })}">Cancel change</button>` : ""}`;
            } else if (!self.canApprove) {
                actions = html`<span class="text-xs text-muted">Waiting for a Checker of bank profiles.</span>`;
            } else if (self.deciding === environment.id) {
                actions = html`<label class="sr-only" for="${"bsp-comment-" + environment.id}">Comment</label>
                    <input autocomplete="off" id="${"bsp-comment-" + environment.id}" class="h-9 w-64 rounded-app border border-line bg-surface px-3 text-sm outline-none focus:border-accent"
                           placeholder="Comment (required to reject)" maxlength="1000" value="${self.decisionComment}" data-input="${self.on(function (e) { self.decisionComment = e.target.value; })}" />
                    <button type="button" class="${smallPrimary}"${F.attr("disabled", off)} data-click="${self.on(function () { return self.decide(environment, "approve"); })}"><i class="ph ph-check" aria-hidden="true"></i> Approve</button>
                    <button type="button" class="${smallDanger}"${F.attr("disabled", off)} data-click="${self.on(function () { return self.decide(environment, "reject"); })}"><i class="ph ph-x" aria-hidden="true"></i> Reject</button>
                    <button type="button" class="text-sm font-semibold text-muted hover:text-ink"${F.attr("disabled", off)} data-click="${self.on(function () { self.deciding = null; self.update(); })}">Close</button>`;
            } else {
                actions = html`<button type="button" class="${smallPrimary}" data-click="${self.on(function () { self.deciding = environment.id; self.decisionComment = ""; self.update(); })}">Review</button>`;
            }

            return html`<li class="rounded-app border border-amber-200 bg-amber-50/60 p-5" data-key="${environment.id}">
            <div class="flex flex-wrap items-start justify-between gap-4">
                <div class="min-w-0">
                    <p class="flex flex-wrap items-center gap-2 font-semibold text-ink">${current ? "Change to" : "New environment"} ${environment.name} <span class="font-mono text-sm">${environment.key}</span> ${kindBadge(environment.kind)}</p>
                    ${current && (current.name !== environment.name || current.kind !== environment.kind || current.sortOrder !== environment.sortOrder)
                        ? html`<p class="mt-1 text-sm text-amber-900">Now: ${current.name} · ${current.kind} · order ${current.sortOrder}. Proposed: ${environment.name} · ${environment.kind} · order ${environment.sortOrder}.</p>` : ""}
                    <p class="mt-1 text-xs text-subtle">Proposed by ${environment.requestedBy} · ${F.date(environment.requestedAt, true)}</p>
                </div>
                <div class="flex shrink-0 flex-wrap items-center gap-2">${actions}</div>
            </div>
            ${self.renderOperations(environment, current)}
        </li>`;
        })}
    </ul>`}
</section>`;
        },

        renderActiveEnvironments: function (active, pending) {
            var self = this, off = self.settingsBusy;
            return html`<section aria-labelledby="bsp-active-title">
    <div class="flex flex-wrap items-center justify-between gap-3">
        <h2 id="bsp-active-title" class="font-display text-xl font-bold text-ink">Environments in use</h2>
        ${self.canManage && !self.form ? html`<button type="button" class="${secondaryClass}"${F.attr("disabled", off)} data-click="${self.on(function () { self.form = self.newForm(null); self.update(); })}">
            <i class="ph ph-plus" aria-hidden="true"></i> Add environment</button>` : ""}
    </div>
    ${self.form && self.form.isNew ? self.renderEnvironmentForm() : ""}
    ${!active.length ? html`<p class="mt-2 text-sm text-muted">No environment is approved, so nothing can be sent to BSP.</p>` : html`<ul class="mt-4 space-y-3">
        ${active.map(function (environment) {
            var waiting = pending.some(function (p) { return p.key === environment.key; });
            var removing = self.deciding === "remove-" + environment.id;
            var editing = self.form && !self.form.isNew && self.form.key === environment.key;
            return html`<li class="rounded-app border ${isProduction(environment) ? "border-red-200" : "border-line"} bg-surface p-5" data-key="${environment.id}">
            <div class="flex flex-wrap items-start justify-between gap-4">
                <div class="min-w-0">
                    <p class="flex flex-wrap items-center gap-2 font-semibold text-ink">${environment.name} <span class="font-mono text-sm text-muted">${environment.key}</span> ${kindBadge(environment.kind)}</p>
                    <p class="mt-1 text-xs text-subtle">Order ${environment.sortOrder} · approved by ${environment.decidedBy}${environment.decidedAt ? " · " + F.date(environment.decidedAt, true) : ""}</p>
                </div>
                <div class="flex shrink-0 flex-wrap items-center gap-2">
                    ${waiting ? html`<span class="text-xs font-semibold text-amber-800">A change is waiting for approval</span>` : ""}
                    ${self.canManage && !waiting && !self.form ? html`<button type="button" class="${smallSecondary}"${F.attr("disabled", off)} data-click="${self.on(function () { self.form = self.newForm(environment); self.update(); })}"><i class="ph ph-pencil-simple" aria-hidden="true"></i> Propose a change</button>` : ""}
                    ${self.canApprove && !removing ? html`<button type="button" class="${smallSecondary}"${F.attr("disabled", off)} data-click="${self.on(function () { self.deciding = "remove-" + environment.id; self.decisionComment = ""; self.update(); })}"><i class="ph ph-trash" aria-hidden="true"></i> Remove</button>` : ""}
                </div>
            </div>
            ${removing ? html`<div class="mt-3 flex flex-wrap items-center gap-2">
                <label class="sr-only" for="${"bsp-remove-" + environment.id}">Reason</label>
                <input autocomplete="off" id="${"bsp-remove-" + environment.id}" class="h-9 w-72 rounded-app border border-line bg-surface px-3 text-sm outline-none focus:border-accent"
                       placeholder="Why it is removed (required)" maxlength="1000" value="${self.decisionComment}" data-input="${self.on(function (e) { self.decisionComment = e.target.value; })}" />
                <button type="button" class="${smallDanger}"${F.attr("disabled", off)} data-click="${self.on(function () { return self.decide(environment, "remove"); })}">Remove</button>
                <button type="button" class="text-sm font-semibold text-muted hover:text-ink" data-click="${self.on(function () { self.deciding = null; self.update(); })}">Close</button>
            </div>` : ""}
            ${self.renderOperations(environment, null)}
            ${editing ? self.renderEnvironmentForm() : ""}
        </li>`;
        })}
    </ul>`}
</section>`;
        },

        renderEnvironmentForm: function () {
            var self = this, form = self.form, off = self.settingsBusy, hosts = self.settings.allowedHosts;
            var problem = environmentProblem(form, hosts);
            var base = baseOf(form.baseUrl);
            function field(id, label, value, set, extra) {
                return html`<label class="block text-sm font-semibold text-ink" for="${id}">${label}
                    <input id="${id}" autocomplete="off" spellcheck="false" class="${inputClass} ${extra || ""}" value="${value}"${F.attr("disabled", off)}
                           data-input="${self.on(function (e) { set(e.target.value); self.update(); })}" />
                </label>`;
            }

            return html`<div class="mt-5 rounded-app border border-accent-line bg-surface p-6">
    <h3 class="font-semibold text-ink">${form.isNew ? "Add a BSP environment" : "Propose a change to " + form.key}</h3>
    <p class="mt-1 max-w-prose text-sm text-muted">A Checker of bank profiles approves it before BSP submission uses it. Allowed hosts on this server: <span class="font-mono">${hosts.join(", ")}</span> (set by IT in FrpMapper.Api's configuration, Bsp:AllowedHosts).</p>
    <div class="mt-4 grid gap-4 sm:grid-cols-2">
        ${form.isNew ? field("bspEnvKey", "Key", form.key, function (v) { form.key = v.toUpperCase(); }, "font-mono uppercase")
            : html`<div class="text-sm font-semibold text-ink">Key<p class="mt-2 font-mono text-sm font-normal text-ink">${form.key}</p></div>`}
        ${field("bspEnvName", "Name", form.name, function (v) { form.name = v; })}
        <fieldset>
            <legend class="text-sm font-semibold text-ink">Kind</legend>
            <div class="mt-2 flex flex-wrap gap-x-6 gap-y-2 text-sm">
                <label class="flex items-center gap-2"><input type="radio" name="bspEnvKind" value="Test"${F.attr("checked", form.kind === "Test")}${F.attr("disabled", off)}
                    data-change="${self.on(function () { form.kind = "Test"; self.update(); })}" /> Test (sandbox)</label>
                <label class="flex items-center gap-2"><input type="radio" name="bspEnvKind" value="Production"${F.attr("checked", form.kind === "Production")}${F.attr("disabled", off)}
                    data-change="${self.on(function () { form.kind = "Production"; self.update(); })}" /> Production (real submissions)</label>
            </div>
        </fieldset>
        ${field("bspEnvOrder", "Order in the list (0–999)", form.sortOrder, function (v) { form.sortOrder = v; }, "block max-w-[8rem]")}
        <div class="sm:col-span-2">${field("bspEnvBase", "Base URL", form.baseUrl, function (v) { form.baseUrl = v; }, "font-mono")}</div>
        ${operations.map(function (operation) {
            return field("bspEnv-" + operation.field, operation.label + " path" + (operation.follow ? " (with " + tokenText + ")" : ""), form[operation.field],
                function (v) { form[operation.field] = v; }, "font-mono");
        })}
    </div>
    ${form.isNew ? html`<p class="mt-3 text-xs text-muted">The operation paths are copied from the approved sandbox. Check every URL against BSP's documentation for this environment.</p>` : ""}
    <div class="mt-4 rounded-app border border-line bg-canvas px-4 py-3">
        <p class="text-xs font-semibold text-subtle">Preview</p>
        <ul class="mt-1 space-y-0.5 font-mono text-xs text-ink">
            ${operations.map(function (operation) { return html`<li class="break-all">${operation.method} ${base}${form[operation.field].trim().replace(/^\/+/, "")}</li>`; })}
        </ul>
    </div>
    ${form.kind === "Production" ? html`<div class="mt-4">${C.notice("Warning", "Production environment", html`<p>Only people whose role holds submission.production can send to it, and each submission must be confirmed by typing its key.</p>`)}</div>` : ""}
    <div class="mt-5 flex flex-wrap items-center gap-3">
        <button type="button" class="${primaryClass}"${F.attr("disabled", off || !!problem)} data-click="${self.on(function () { return self.propose(); })}"><i class="ph ph-paper-plane-right" aria-hidden="true"></i> Send for approval</button>
        <button type="button" class="${quietClass}"${F.attr("disabled", off)} data-click="${self.on(function () { self.form = null; self.update(); })}">Cancel</button>
        ${problem ? html`<span class="text-sm text-subtle">${problem}</span>` : ""}
    </div>
</div>`;
        },

        renderSettings: function () {
            var self = this, settings = self.settings;
            if (self.settingsError) {
                return html`<div class="mt-8 max-w-3xl">${C.notice("Error", "The BSP environments could not be loaded", html`<p>${self.settingsError}</p>`)}</div>`;
            }

            if (!settings) {
                return C.pageLoading("Loading the BSP environments", { classes: "mt-8 max-w-5xl" });
            }

            var list = settings.environments || [];
            var active = list.filter(function (e) { return e.status === "Active"; });
            var pending = list.filter(function (e) { return e.status === "Pending"; });
            var decided = list.filter(function (e) { return e.status !== "Active" && e.status !== "Pending"; }).slice(0, 20);
            return html`<div class="mt-8 max-w-5xl space-y-10">
    <p class="max-w-prose text-sm text-muted">The BSP Report API environments BSP submission can send to. A bank profile Maker proposes an environment or a change; a different Checker approves it. Every step is in the audit trail.</p>
    ${self.renderPendingEnvironments(pending, active)}
    ${self.renderActiveEnvironments(active, pending)}
    ${decided.length ? html`<section aria-labelledby="bsp-decided-title">
        <h2 id="bsp-decided-title" class="font-display text-xl font-bold text-ink">Recent decisions</h2>
        <ul class="mt-4 divide-y divide-line rounded-app border border-line bg-surface">
            ${decided.map(function (environment) {
                return html`<li class="px-5 py-3 text-sm" data-key="${environment.id}">
                    <span class="font-semibold ${environment.status === "Replaced" ? "text-muted" : environment.status === "Removed" || environment.status === "Rejected" ? "text-red-700" : "text-muted"}">${environment.status}</span>
                    <span class="text-ink"> · ${environment.name} <span class="font-mono">${environment.key}</span></span>
                    <span class="text-subtle"> · proposed by ${environment.requestedBy}${environment.decidedBy ? ", decided by " + environment.decidedBy : ""}${environment.decidedAt ? " · " + F.date(environment.decidedAt, true) : ""}</span>
                    ${environment.decisionComment ? html`<p class="mt-1 text-xs text-muted">${environment.decisionComment}</p>` : ""}
                </li>`;
            })}
        </ul>
    </section>` : ""}
</div>`;
        },

        render: function () {
            var self = this;
            function notices(number) {
                if (self.noticeStep !== number) return "";
                return html`${self.busy ? html`<p class="mt-5 flex items-center gap-2 text-sm text-muted" role="status"><span class="h-4 w-4 animate-spin rounded-full border-2 border-accent/30 border-t-accent" aria-hidden="true"></span>${labels[self.busy]} Keep this page open.</p>` : ""}`;
            }

            function step(number, title, text, body) {
                return html`<section class="rounded-app border border-line bg-surface p-6">
    <div class="flex items-start gap-3">
        <span class="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-accent-soft text-sm font-bold text-accent" aria-hidden="true">${number}</span>
        <div class="min-w-0">
            <h2 class="font-display text-xl font-bold text-ink">${title}</h2>
            <p class="mt-1 max-w-prose text-sm text-muted">${text}</p>
        </div>
    </div>
    ${notices(number)}
    <div class="mt-5">${body}</div>
</section>`;
            }

            var environment = self.environment();
            var body;
            if (self.tab === "settings") {
                body = self.renderSettings();
            } else if (self.loadError) {
                body = html`<div class="mt-8 max-w-3xl">${C.notice("Error", "BSP submission could not be loaded", html`<p>${self.loadError}</p>`)}</div>`;
            } else if (!self.banks || !self.environments) {
                body = C.pageLoading("Loading the bank profiles and BSP environments", { classes: "mt-8 max-w-5xl" });
            } else {
                body = html`<div class="mt-8 max-w-5xl space-y-6">
    ${step(1, "Environment, bank and certificate", "Choose where the report goes and the bank. The bank's approved certificate from Bank profiles is used, or upload one for this request. A UNI report needs the UNI certificate; an RB report the RB one.",
        html`${self.renderEnvironment()}<div class="mt-6 border-t border-line pt-6">${self.renderBank()}</div><div class="mt-6 border-t border-line pt-6">${self.renderCertificate()}</div>`)}
    ${step(2, "Submit the report", "The report goes to the chosen BSP environment with the bank's undertaking code from its profile.", self.renderSubmit())}
    ${step(3, "Status and downloads", "Follow up a submission in the same environment: its status, BSP's validation result, the receipt and the Excel visualization.", self.renderFollowUp())}
    ${self.renderResponse()}
    ${self.renderHistory()}
</div>`;
            }

            var waiting = self.settings ? (self.settings.environments || []).filter(function (e) { return e.status === "Pending"; }).length : 0;
            var tabs = [];
            if (self.canSubmit) tabs.push({ key: "submit", label: "Submit" });
            if (self.canSettings) tabs.push({ key: "settings", label: "Settings", count: waiting });
            return html`<div class="px-6 py-8 lg:px-10 lg:py-10">
    <header class="border-b border-line pb-8">
        <div class="flex flex-wrap items-center gap-3">
            <h1 class="font-display text-3xl font-bold tracking-tight text-ink">BSP submission</h1>
            ${self.tab === "submit" && environment ? kindBadge(environment.kind) : ""}
        </div>
        <p class="mt-2 max-w-prose text-base leading-7 text-muted">
            Send a report XML to a BSP Report API environment with the bank's own certificate, then check its status and
            download BSP's results. Sandbox submissions are test submissions; Production ones are real.
        </p>
    </header>
    ${tabs.length > 1 ? html`<div class="mt-8 flex flex-wrap gap-1" role="tablist" aria-label="Section">
        ${tabs.map(function (tab) {
            return html`<button type="button" role="tab" aria-selected="${self.tab === tab.key ? "true" : "false"}" class="inline-flex h-9 items-center rounded-app px-3 text-sm font-medium transition ${self.tab === tab.key ? "bg-ink text-white" : "text-muted hover:bg-surface hover:text-ink"}"
                data-click="${self.on(function () { self.switchTo(tab.key); })}">
                ${tab.label}
                ${tab.count ? html`<span class="ml-2 rounded-app bg-amber-100 px-1.5 text-xs font-semibold text-amber-900">${tab.count}</span>` : ""}
            </button>`;
        })}
    </div>` : ""}
    ${body}
</div>`;
        }
    });

    F.routes.push({ pattern: /^sandbox$/, permission: [F.Permissions.SubmissionPrepare, F.Permissions.ReferenceManage, F.Permissions.ReferenceApprove],
        create: function (app, match, query) { return new Submission(app, match, query); } });
})();
