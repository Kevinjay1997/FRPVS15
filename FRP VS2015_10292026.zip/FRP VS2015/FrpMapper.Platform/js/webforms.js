// FRP Mapper Platform: the small script of the ASP.NET Web Forms pages (Pages/*.aspx). The pages work without it; it adds
// the idle timeout (as js/app.js does for the other screens) and opens a choice in a list at once.
(function () {
    "use strict";

    var body = document.body;
    var basePath = body.getAttribute("data-base") || "/";

    var Frp = window.Frp || {};

    // ---------- messages from the server (data-toast) are shown as toasts, as on the other screens ----------
    if (Frp.toast) {
        Array.prototype.forEach.call(document.querySelectorAll("[data-toast]"), function (notice) {
            Frp.toast(notice.getAttribute("data-toast"), null, notice.getAttribute("data-toast-text") || notice.textContent);
            notice.parentNode.removeChild(notice); // without script, the notice stays on the page instead
        });
    }

    // ---------- a button marked data-confirm asks first (a toast), then does its work ----------
    document.addEventListener("click", function (event) {
        var button = event.target && event.target.closest ? event.target.closest("[data-confirm]") : null;
        if (!button || !Frp.confirm || button.disabled) {
            return;
        }

        if (button.getAttribute("data-confirmed") === "true") {
            button.removeAttribute("data-confirmed");
            return; // confirmed: the post goes ahead
        }

        event.preventDefault();
        event.stopPropagation();
        Frp.confirm({
            title: button.getAttribute("data-confirm"),
            message: button.getAttribute("data-confirm-text"),
            confirmLabel: button.getAttribute("data-confirm-label") || "Confirm",
            danger: button.getAttribute("data-confirm-danger") === "true"
        }).then(function (yes) {
            if (yes) {
                button.setAttribute("data-confirmed", "true");
                button.click();
            }
        });
    }, true);

    // ---------- a list marked data-submit="<button id>" presses that button when the choice changes ----------
    Array.prototype.forEach.call(document.querySelectorAll("select[data-submit]"), function (select) {
        select.addEventListener("change", function () {
            var button = document.getElementById(select.getAttribute("data-submit"));
            if (button && !button.disabled) {
                button.click();
            }
        });
    });

    // ---------- a form post shows that it is working and is not sent twice ----------
    Array.prototype.forEach.call(document.querySelectorAll("form"), function (form) {
        form.addEventListener("submit", function () {
            if (form.getAttribute("data-sending") === "true") {
                return;
            }

            form.setAttribute("data-sending", "true");
            window.setTimeout(function () {
                Array.prototype.forEach.call(form.querySelectorAll("input[type=submit], button"), function (button) {
                    if (!button.disabled) {
                        button.setAttribute("data-enabled", "true");
                        button.disabled = true;
                    }
                });
            }, 0);
        });
    });

    // Back to this page from the browser's history: the buttons work again.
    window.addEventListener("pageshow", function (event) {
        if (event.persisted) {
            Array.prototype.forEach.call(document.querySelectorAll("form[data-sending]"), function (form) {
                form.removeAttribute("data-sending");
                Array.prototype.forEach.call(form.querySelectorAll("input[type=submit][data-enabled], button[data-enabled]"), function (button) {
                    button.disabled = false;
                });
            });
        }
    });

    // ---------- idle timeout (Application Security Checklist: sessions end after 15 minutes of inactivity) ----------
    var idleMinutes = Number(body.getAttribute("data-idle-minutes"));
    if (!(idleMinutes > 0)) {
        return;
    }

    var idleMs = idleMinutes * 60000;
    var warnMs = Math.min(60000, idleMs / 2);
    var pingEveryMs = Math.min(60000, idleMs / 3);
    var lastActivity = Date.now();
    var lastPing = Date.now();
    var ended = false;
    var warning = null;

    function hideWarning() {
        if (warning) {
            warning.close();
            warning = null;
        }
    }

    /** A toast that counts down; any activity closes it. */
    function showWarning(seconds) {
        var text = "You will be signed out in " + seconds + " seconds because of inactivity. Move the mouse or press a key to stay signed in.";
        if (!warning) {
            warning = window.Frp.toast("Warning", "Still there?", text, { sticky: true });
        } else {
            warning.setMessage(text);
        }
    }

    function signOut() {
        ended = true;
        var form = document.getElementById("frp-signout");
        if (form) {
            var reason = form.querySelector("input[name=reason]");
            if (reason) {
                reason.value = "idle";
            }

            form.submit();
        } else {
            // Windows sign-in has no sign-out: reload, which asks Windows again.
            window.location.reload();
        }
    }

    function onActivity() {
        if (!ended) {
            lastActivity = Date.now();
            hideWarning();
        }
    }

    ["mousemove", "mousedown", "keydown", "wheel", "scroll", "touchstart"].forEach(function (name) {
        window.addEventListener(name, onActivity, { passive: true, capture: true });
    });

    window.setInterval(function () {
        if (ended) {
            return;
        }

        var now = Date.now();
        var idle = now - lastActivity;
        if (idle >= idleMs) {
            hideWarning();
            signOut();
            return;
        }

        if (idle >= idleMs - warnMs) {
            showWarning(Math.max(1, Math.ceil((idleMs - idle) / 1000)));
        }

        if (lastActivity > lastPing && now - lastPing >= pingEveryMs) {
            lastPing = now;
            fetch(basePath + "account/keepalive", { credentials: "same-origin", cache: "no-store", redirect: "follow" })
                .then(function (response) {
                    // The sign-in ended on the server (e.g. signed in elsewhere): show the sign-in page.
                    if (response.redirected || response.status === 401 || response.status === 403) {
                        ended = true;
                        window.location.reload();
                    }
                })
                .catch(function () { /* offline for a moment: try again at the next activity */ });
        }
    }, 1000);
})();
