// XML tools: the Regulatory Reports Workbench's general tools for report XML. Three tabs:
//   Merge             an existing report XML file → merged (merge.csv), cleaned (cleanup.csv), optionally kept to one
//                     reporting period (reportperiod.csv), and with an XSD normalized and checked (submission.prepare);
//   Validate with XSD any XML file checked against any XSD (submission.prepare);
//   Settings          merge.csv, cleanup.csv, reportperiod.csv and the normalizer's kept rows: a Maker (reference.manage)
//                     uploads them, a different Checker (reference.approve) approves them.
(function () {
    "use strict";
    var F = window.Frp, html = F.html, C = F.components;

    var labelClass = "block text-sm font-semibold text-ink";
    var hintClass = "mt-1 block text-xs font-normal leading-5 text-subtle";
    var inputClass = "mt-2 h-11 w-full rounded-app border border-line bg-surface px-3 text-sm outline-none transition hover:border-slate-300 focus:border-accent disabled:opacity-60";
    var primaryClass = "inline-flex h-10 items-center gap-2 rounded-app bg-accent px-5 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-50";
    var smallSecondary = "inline-flex h-9 items-center gap-1.5 rounded-app border border-line bg-surface px-3 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:opacity-50";

    function extension(name) {
        var dot = (name || "").lastIndexOf(".");
        return dot < 0 ? "" : name.substring(dot).toLowerCase();
    }

    /** A file input that keeps one chosen file of the given extension. */
    function fileInput(page, accept, off, onChosen) {
        return html`<input type="file" accept="${accept}" class="mt-2 block w-full text-sm"${F.attr("disabled", off)}
            data-change="${page.on(function (e) {
                var file = e.target.files[0] || null;
                if (file && extension(file.name) !== accept) {
                    F.toast("Error", file.name, "Choose a " + accept + " file.");
                    e.target.value = "";
                    file = null;
                }
                onChosen(file);
                page.update();
            })}" />`;
    }

    /** The XSD check's result: passed, or the first messages with their line and the elements open there. */
    function schemaResult(page, schema, download) {
        if (!schema) return "";
        return html`<section class="mt-4 rounded-app border border-line bg-surface" aria-label="XSD check">
    <header class="flex flex-wrap items-center justify-between gap-2 border-b border-line px-5 py-3">
        <h3 class="font-semibold text-ink">XSD check · ${schema.xsdFileName}</h3>
        <span class="rounded-app px-2 py-0.5 text-xs font-semibold ${schema.valid ? "bg-emerald-50 text-emerald-800" : "bg-red-50 text-red-800"}">${schema.valid ? "Passed" : "Failed"}${schema.issueCount ? " · " + F.n0(schema.issueCount) + " messages" : ""}</span>
    </header>
    ${schema.report ? html`<div class="px-5 pt-3"><button type="button" class="${smallSecondary}" data-click="${page.on(function () { return download(schema.report); })}"><i class="ph ph-file-csv" aria-hidden="true"></i> All messages (.csv)</button></div>` : ""}
    ${schema.issues.length ? html`<ul class="relative mt-3 max-h-[28rem] divide-y divide-line/70 overflow-auto border-t border-line text-sm">
        ${schema.issues.map(function (issue) {
            return html`<li class="px-5 py-2.5">
            <span class="font-mono text-xs text-subtle">line ${issue.line}${issue.position ? ", " + issue.position : ""} · ${issue.severity}</span>
            <span class="block break-words text-ink">${issue.message}</span>
            ${issue.path ? html`<span class="block break-all font-mono text-xs text-subtle">${issue.path}</span>` : ""}
        </li>`;
        })}
    </ul>` : html`<p class="px-5 py-4 text-sm text-muted">The file passed the XSD check without any message.</p>`}
    ${schema.issueCount > schema.issues.length ? html`<p class="border-t border-line px-5 py-2 text-xs text-subtle">The first ${F.n0(schema.issues.length)} of ${F.n0(schema.issueCount)} messages are listed; the .csv has all of them.</p>` : ""}
</section>`;
    }

    var XmlTools = F.page(function (app, match, query) {
        F.Page.call(this, app);
        var self = this;
        this.canUse = F.can(F.Permissions.SubmissionPrepare);
        this.canSettings = F.can(F.Permissions.ReferenceManage) || F.can(F.Permissions.ReferenceApprove);
        var wanted = query && query.get("tab");
        this.tab = !this.canUse ? "settings" : (wanted === "settings" && this.canSettings) || wanted === "validate" ? wanted : "merge";

        this.setup = null; this.setupError = null;
        this.merge = { xml: null, xsd: null, period: "", normalize: true };
        this.mergeBusy = false; this.mergeProgress = null; this.mergeResult = null;
        this.check = { xml: null, xsd: null };
        this.checkBusy = false; this.checkResult = null;

        this.settings = !this.canSettings ? null : new C.WorkbenchSettings(this, {
            api: "xml-tools/config",
            title: "XML tools configuration",
            intro: html`The Workbench's merge.csv (From,To), cleanup.csv (Clean) and reportperiod.csv (Report, Daily … Yearly, Remarks), as
                they were in its Config folder, and the _Item rows the normalizer keeps when they have a value (its FRP.NonRemovableItems
                setting). They are checked first; a Checker other than you approves them.`,
            files: [
                { field: "mergeFile", label: "Elements to merge (merge.csv)", accept: ".csv" },
                { field: "cleanupFile", label: "Elements to clean up (cleanup.csv)", accept: ".csv" },
                { field: "reportPeriodFile", label: "Reports per period (reportperiod.csv)", accept: ".csv" }
            ],
            texts: [{ field: "nonRemovableItems", label: "_Item rows the normalizer keeps", value: "MAIN_Y1_Item", hint: "Comma-separated element names, e.g. MAIN_Y1_Item." }],
            downloads: [
                { file: "merge", label: "merge.csv", icon: "ph-file-csv" },
                { file: "cleanup", label: "cleanup.csv", icon: "ph-file-csv" },
                { file: "reportperiod", label: "reportperiod.csv", icon: "ph-file-csv" }
            ],
            onApproved: function () { if (self.canUse) self.loadSetup(); }
        });
    }, {
        title: function () { return "XML tools · FRP Mapper"; },

        init: function () {
            var loads = [];
            if (this.canUse) loads.push(this.loadSetup());
            if (this.settings) loads.push(this.settings.load());
            return Promise.all(loads);
        },

        loadSetup: function () {
            var self = this;
            return F.api.get("xml-tools/setup").then(function (setup) {
                self.setup = setup;
                self.setupError = null;
                self.update();
            }, function (e) {
                self.setupError = F.messageOf(e);
                self.update();
            });
        },

        download: function (runId, name) {
            return F.api.file("xml-tools/outputs/" + runId + "/" + encodeURIComponent(name), null, { busy: "Downloading " + name }).then(function (file) {
                F.saveFile(file.name, file.blob);
            }, function (e) {
                F.toast("Error", "The file was not downloaded", F.messageOf(e));
            });
        },

        // ---------- Merge ----------

        runMerge: function () {
            var self = this, m = self.merge;
            if (!m.xml) { F.toast("Error", null, "Choose the XML file."); return Promise.resolve(); }
            var form = new FormData();
            form.append("xmlFile", m.xml, m.xml.name);
            if (m.xsd) form.append("xsdFile", m.xsd, m.xsd.name);
            form.append("reportPeriod", m.period);
            form.append("normalize", m.xsd && m.normalize ? "true" : "false");
            self.mergeBusy = true;
            self.mergeResult = null;
            self.mergeProgress = new C.Progress(self, "Merging " + m.xml.name);
            self.mergeProgress.show({ percent: 0, stage: "Sending the file to the API" });
            return F.api.stream("POST", "xml-tools/merge", { form: form }, function (update) { self.mergeProgress.show(update); },
                function (item) { return item.xmlMerge; }, "The file was not merged.").then(function (result) {
                self.mergeResult = result;
                F.toast("Success", null, "The merged file is ready.");
            }, function (e) {
                F.toast("Error", "The file was not merged", F.messageOf(e));
            }).then(function () {
                self.mergeProgress.stop();
                self.mergeProgress = null;
                self.mergeBusy = false;
                self.update();
            });
        },

        renderMerge: function () {
            var self = this, setup = self.setup, m = self.merge, off = self.mergeBusy, result = self.mergeResult;
            if (self.setupError) return html`<div class="mt-8">${C.notice("Error", "The XML tools cannot be loaded", self.setupError)}</div>`;
            if (!setup) return html`<div class="mt-8">${C.loading("py-10", "Loading the XML tools")}</div>`;
            if (!setup.configured) {
                return html`<div class="mt-8">${C.notice("Warning", "No XML tools configuration has been approved yet",
                    html`<p>A Maker uploads merge.csv, cleanup.csv and reportperiod.csv on the Settings tab and a Checker approves them. Validate with XSD works without them.</p>`)}</div>`;
            }

            var download = function (name) { return self.download(result.outputId, name); };
            return html`<div class="mt-8 grid max-w-6xl gap-8 2xl:max-w-none 2xl:grid-cols-[minmax(0,1fr)_22rem]">
    <section class="min-w-0">
        <div class="rounded-app border border-line bg-surface p-6">
            <h2 class="font-semibold text-ink">Merge elements from an existing XML file</h2>
            <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                The report parts the Excel export splits (FRP_9A2, FRP_9A3, FRP_9A4 …) are merged into the element BSP expects (FRP_9A234),
                empty elements are left out, and with an XSD the file is normalized and checked against it, as the Workbench did.
            </p>
            <div class="mt-5 grid gap-5 sm:grid-cols-2">
                <label class="${labelClass}">Report XML file
                    ${fileInput(self, ".xml", off, function (file) { m.xml = file; self.mergeResult = null; })}
                </label>
                <label class="${labelClass}">XSD <span class="font-normal text-subtle">(optional)</span>
                    ${fileInput(self, ".xsd", off, function (file) { m.xsd = file; self.mergeResult = null; })}
                    <span class="${hintClass}">The report's XSD: the merged file is normalized with it and checked against it.</span>
                </label>
                <label class="${labelClass}">Reporting period <span class="font-normal text-subtle">(optional)</span>
                    <select class="${inputClass}"${F.attr("disabled", off)} data-change="${self.on(function (e) { m.period = e.target.value; self.mergeResult = null; self.update(); })}">
                        <option value=""${F.attr("selected", !m.period)}>All reports</option>
                        ${setup.reportPeriods.map(function (p) { return html`<option value="${p}"${F.attr("selected", m.period === p)}>${p}</option>`; })}
                    </select>
                    <span class="${hintClass}">Keeps the Header and the reports reportperiod.csv gives this period.</span>
                </label>
                <label class="flex items-start gap-3 self-center text-sm text-ink">
                    <input type="checkbox" class="mt-1 h-4 w-4 rounded border-line text-accent"${F.attr("checked", m.normalize)}${F.attr("disabled", off || !m.xsd)}
                           data-change="${self.on(function (e) { m.normalize = e.target.checked; self.update(); })}" />
                    <span><span class="font-semibold">Normalize with the XSD</span><span class="${hintClass}">Removes zero or incomplete _Item rows and the tables and sections left empty.</span></span>
                </label>
            </div>
            <button type="button" class="${primaryClass} mt-6"${F.attr("disabled", off || !m.xml)} data-click="${self.on(function () { return self.runMerge(); })}">
                ${off ? html`<span class="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" aria-hidden="true"></span>` : html`<i class="ph ph-git-merge" aria-hidden="true"></i>`}
                Merge file
            </button>
        </div>
        ${self.mergeProgress ? html`<div class="mt-6">${self.mergeProgress.render()}</div>` : ""}
        ${result ? html`<section class="mt-6" aria-label="Result">
            ${C.notice("Success", "The merged file is ready", html`<p>${result.merged.length} elements merged, ${result.removedEmpty.length} empty and ${result.outsidePeriod.length} outside the period left out.</p>`)}
            <ul class="mt-4 divide-y divide-line/70 rounded-app border border-line bg-surface" aria-label="Result files">
                ${[[result.outputFile, "Merged file"], [result.normalizedFile, "Normalized file"], [result.normalizerLog, "Normalizer log"]].filter(function (f) { return f[0]; }).map(function (f) {
                    return html`<li class="flex flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3">
                    <div class="min-w-0 flex-1 basis-64"><p class="text-xs font-semibold text-subtle">${f[1]}</p><p class="break-all font-mono text-sm text-ink">${f[0]}</p></div>
                    <button type="button" class="${smallSecondary}" data-click="${self.on(function () { return download(f[0]); })}"><i class="ph ph-download-simple" aria-hidden="true"></i> Download</button>
                </li>`;
                })}
            </ul>
            ${schemaResult(self, result.schema, download)}
            <details class="mt-4 rounded-app border border-line bg-surface">
                <summary class="cursor-pointer px-5 py-3 text-sm font-semibold text-ink">What was done</summary>
                <div class="grid gap-3 border-t border-line px-5 py-4 text-sm text-muted">
                    ${result.merged.length ? html`<p><span class="font-semibold text-ink">Merged:</span> ${result.merged.join(" · ")}</p>` : ""}
                    ${result.removedEmpty.length ? html`<p><span class="font-semibold text-ink">Empty, left out:</span> ${result.removedEmpty.join(" · ")}</p>` : ""}
                    ${result.outsidePeriod.length ? html`<p><span class="font-semibold text-ink">Not in ${m.period}:</span> ${result.outsidePeriod.join(" · ")}</p>` : ""}
                    <p><span class="font-semibold text-ink">Written (${result.elements.length}):</span> ${result.elements.join(" · ")}</p>
                    ${result.log.map(function (line) { return html`<p>${line}</p>`; })}
                </div>
            </details>
        </section>` : ""}
    </section>
    <aside class="grid min-w-0 content-start gap-4 sm:grid-cols-2 2xl:grid-cols-1">
        <div class="rounded-app border border-line bg-surface p-5">
            <h2 class="font-semibold text-ink">Configuration in use</h2>
            <p class="mt-1 text-sm text-muted">${setup.configuration.sourceFiles}</p>
            <p class="mt-1 text-xs text-subtle">Approved by ${setup.configuration.decidedBy} · ${F.date(setup.configuration.decidedAt)}</p>
            <p class="mt-2 text-xs text-muted">${F.n0(setup.mergeRules)} merge rules · cleaned: ${setup.cleanupElements.join(", ") || "none"}</p>
        </div>
    </aside>
</div>`;
        },

        // ---------- Validate with XSD ----------

        runCheck: function () {
            var self = this, c = self.check;
            if (!c.xml || !c.xsd) { F.toast("Error", null, "Choose the XML file and the XSD."); return Promise.resolve(); }
            self.checkBusy = true;
            self.checkResult = null;
            self.update();
            return F.api.upload("xml-tools/validate", { xmlFile: c.xml, xsdFile: c.xsd }, { busy: "Checking " + c.xml.name }).then(function (result) {
                self.checkResult = result;
                F.toast(result.schema.valid ? "Success" : "Warning", null, result.schema.valid ? "The file passed the XSD check." : "The file does not pass the XSD check.");
            }, function (e) {
                F.toast("Error", "The file was not checked", F.messageOf(e));
            }).then(function () {
                self.checkBusy = false;
                self.update();
            });
        },

        renderCheck: function () {
            var self = this, c = self.check, off = self.checkBusy, result = self.checkResult;
            return html`<div class="mt-8 max-w-5xl">
    <div class="rounded-app border border-line bg-surface p-6">
        <h2 class="font-semibold text-ink">Validate an XML file using an XSD</h2>
        <p class="mt-1 max-w-prose text-sm leading-6 text-muted">Any XML file and any XSD: every error and warning is listed with its line and the elements open there.</p>
        <div class="mt-5 grid gap-5 sm:grid-cols-2">
            <label class="${labelClass}">XML file ${fileInput(self, ".xml", off, function (file) { c.xml = file; self.checkResult = null; })}</label>
            <label class="${labelClass}">XSD ${fileInput(self, ".xsd", off, function (file) { c.xsd = file; self.checkResult = null; })}</label>
        </div>
        <button type="button" class="${primaryClass} mt-6"${F.attr("disabled", off || !c.xml || !c.xsd)} data-click="${self.on(function () { return self.runCheck(); })}">
            ${off ? html`<span class="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" aria-hidden="true"></span>` : html`<i class="ph ph-seal-check" aria-hidden="true"></i>`}
            Validate
        </button>
    </div>
    ${result ? schemaResult(self, result.schema, function (name) { return self.download(result.outputId, name); }) : ""}
</div>`;
        },

        render: function () {
            var self = this, tabs = [];
            if (self.canUse) {
                tabs.push({ key: "merge", label: "Merge" });
                tabs.push({ key: "validate", label: "Validate with XSD" });
            }

            if (self.settings) tabs.push({ key: "settings", label: "Settings", count: self.settings.waiting() });
            var body = self.tab === "settings" ? self.settings.render() : self.tab === "validate" ? self.renderCheck() : self.renderMerge();
            return html`<div class="px-6 py-8 lg:px-10 lg:py-10">
    <header class="border-b border-line pb-8">
        <h1 class="font-display text-3xl font-bold tracking-tight text-ink">XML tools</h1>
        <p class="mt-2 max-w-prose text-base leading-7 text-muted">
            Merge the report parts of an XML file into the elements BSP expects, leave out empty ones, keep the reports of one period,
            normalize the file with its XSD, and check any XML file against any XSD, as the Regulatory Reports Workbench did.
        </p>
    </header>
    ${tabs.length > 1 ? html`<div class="mt-8 flex flex-wrap gap-1" role="tablist" aria-label="Section">
        ${tabs.map(function (tab) {
            return html`<button type="button" role="tab" aria-selected="${self.tab === tab.key ? "true" : "false"}" class="inline-flex h-9 items-center rounded-app px-3 text-sm font-medium transition ${self.tab === tab.key ? "bg-ink text-white" : "text-muted hover:bg-surface hover:text-ink"}"
                data-click="${self.on(function () { self.tab = tab.key; self.update(); })}">
                ${tab.label}
                ${tab.count ? html`<span class="ml-2 rounded-app bg-amber-100 px-1.5 text-xs font-semibold text-amber-900">${tab.count}</span>` : ""}
            </button>`;
        })}
    </div>` : ""}
    ${body}
</div>`;
        }
    });

    F.routes.push({ pattern: /^xml-tools$/, permission: [F.Permissions.SubmissionPrepare, F.Permissions.ReferenceManage, F.Permissions.ReferenceApprove],
        create: function (app, match, query) { return new XmlTools(app, match, query); } });
})();
