// FRP Mapper Platform: toasts, the default way to tell people what happened and to ask them to confirm.
//   Frp.toast(kind, title, message[, options]) shows a message: kind is "Success", "Info", "Warning" or "Error".
//     Success and Info close by themselves after a few seconds (the timer stops while the pointer is on the toast);
//     Warning and Error stay until closed, so they can be read. options: sticky, timeout (ms), action { label, run }
//     (a button in the toast), progress (0–100: shows a progress bar and percentage, e.g. while the API works).
//     Returns { close(), setMessage(text), setProgress(percent[, text]) }.
//   Frp.confirm({ title, message, confirmLabel, cancelLabel, danger }) asks a question and resolves to true (confirmed)
//     or false (cancelled, Esc, or closed). One question is asked at a time; others wait their turn.
// Toasts live in their own region at the end of <body>, outside #app, so redrawing a page never removes them. This file
// needs nothing else, so the ASP.NET Web Forms pages (Site.Master) use it too. Every text is set with textContent.
(function () {
    "use strict";

    var Frp = window.Frp = window.Frp || {};
    var maxToasts = 5;
    var closeAfter = { Success: 5000, Info: 6000 };

    var styles = {
        Success: { bar: "bg-emerald-500", icon: "ph-check-circle text-emerald-600", role: "status" },
        Info: { bar: "bg-accent", icon: "ph-info text-accent", role: "status" },
        Warning: { bar: "bg-amber-500", icon: "ph-warning text-amber-600", role: "alert" },
        Error: { bar: "bg-red-600", icon: "ph-x-circle text-red-600", role: "alert" }
    };

    var region = null;
    var questions = [];
    var asking = null;

    function element(tag, className, text) {
        var node = document.createElement(tag);
        if (className) {
            node.className = className;
        }

        if (text !== undefined && text !== null) {
            node.textContent = String(text);
        }

        return node;
    }

    /** The region the toasts are shown in (bottom right, the newest nearest the corner; full width on a phone), made once. */
    function toastRegion() {
        if (region && document.body.contains(region)) {
            return region;
        }

        region = element("div", "pointer-events-none fixed inset-x-0 bottom-0 z-[70] flex flex-col-reverse items-center gap-2 p-4 sm:left-auto sm:right-0 sm:items-end");
        region.id = "frp-toasts";
        region.setAttribute("aria-live", "polite");
        region.setAttribute("aria-relevant", "additions");
        document.body.appendChild(region);
        return region;
    }

    function card(kind, title, message) {
        var style = styles[kind] || styles.Info;
        var box = element("div", "frp-toast pointer-events-auto relative flex w-full max-w-sm gap-3 overflow-hidden rounded-app border border-line bg-surface py-3 pl-4 pr-3 text-sm shadow-lg ring-1 ring-black/5 transition duration-200 ease-out translate-y-[6px] opacity-0");
        box.appendChild(element("span", "absolute inset-y-0 left-0 w-1 " + style.bar));
        var icon = element("i", "ph " + style.icon + " mt-0.5 text-lg");
        icon.setAttribute("aria-hidden", "true");
        box.appendChild(icon);
        var text = element("div", "min-w-0 flex-1");
        if (title) {
            text.appendChild(element("p", "font-semibold text-ink", title));
        }

        if (message) {
            text.appendChild(element("p", "mt-0.5 break-words leading-5 text-muted", message));
        }

        box.appendChild(text);
        return { box: box, text: text };
    }

    function show(box) {
        var list = toastRegion();
        list.appendChild(box);
        // Oldest messages go first when there are too many (a question is never dropped).
        var shown = list.querySelectorAll(".frp-toast:not([data-question])");
        for (var i = 0; i < shown.length - maxToasts; i++) {
            shown[i].parentNode.removeChild(shown[i]);
        }

        window.requestAnimationFrame(function () {
            box.classList.remove("translate-y-[6px]", "opacity-0");
        });
    }

    function remove(box) {
        if (!box.parentNode) {
            return;
        }

        // Gone at once for people and screen readers; it fades out on screen.
        box.removeAttribute("role");
        box.removeAttribute("data-key");
        box.setAttribute("aria-hidden", "true");
        box.classList.add("opacity-0", "pointer-events-none");
        window.setTimeout(function () {
            if (box.parentNode) {
                box.parentNode.removeChild(box);
            }
        }, 200);
    }

    function closeButton(onClose) {
        var button = element("button", "grid h-7 w-7 shrink-0 place-items-center rounded-app text-subtle transition hover:bg-canvas hover:text-ink");
        button.type = "button";
        button.setAttribute("aria-label", "Close");
        button.appendChild(element("i", "ph ph-x"));
        button.addEventListener("click", onClose);
        return button;
    }

    /** Shows a message. The same message shown again while it is still up is not repeated. */
    Frp.toast = function (kind, title, message, options) {
        options = options || {};
        if (!title && !message) {
            return { close: function () { } };
        }

        var key = (kind || "") + "\u001f" + (title || "") + "\u001f" + (message || "");
        var list = toastRegion();
        var same = Array.prototype.filter.call(list.querySelectorAll(".frp-toast"), function (b) { return b.getAttribute("data-key") === key; })[0];
        if (same) {
            remove(same);
        }

        var made = card(kind, title, message);
        var box = made.box;
        var style = styles[kind] || styles.Info;
        box.setAttribute("role", style.role);
        box.setAttribute("data-key", key);
        var timer = null;
        var close = function () {
            window.clearTimeout(timer);
            remove(box);
        };
        if (options.action && options.action.label) {
            var act = element("button", "mt-2 text-sm font-semibold text-accent underline hover:text-accent-hover", options.action.label);
            act.type = "button";
            act.addEventListener("click", function () {
                close();
                options.action.run();
            });
            made.text.appendChild(act);
        }

        var bar = null;
        var percent = null;
        if (typeof options.progress === "number") {
            var row = element("div", "mt-2 flex items-center gap-2");
            var track = element("div", "h-1.5 flex-1 overflow-hidden rounded-full bg-line/70");
            bar = element("div", "h-full rounded-full bg-accent transition-[width] duration-150 ease-out");
            track.appendChild(bar);
            percent = element("span", "w-10 shrink-0 text-right text-xs font-semibold tabular-nums text-accent");
            row.appendChild(track);
            row.appendChild(percent);
            made.text.appendChild(row);
            box.setAttribute("aria-busy", "true");
            // The percentage is read once by screen readers (the bar changes too often to be announced).
            row.setAttribute("aria-hidden", "true");
        }

        var setProgress = function (value, text) {
            if (!bar) {
                return;
            }

            value = Math.max(0, Math.min(100, Math.floor(value || 0)));
            bar.style.width = value + "%";
            percent.textContent = value + "%";
            if (value >= 100) {
                box.removeAttribute("aria-busy");
            }

            if (text !== undefined && text !== null) {
                var line = made.text.querySelector("p.text-muted");
                if (line && line.textContent !== String(text)) {
                    line.textContent = String(text);
                }
            }
        };
        if (bar) {
            setProgress(options.progress);
        }

        box.appendChild(closeButton(close));
        var wait = options.sticky ? 0 : options.timeout || closeAfter[kind] || 0;
        if (wait) {
            var start = function () { timer = window.setTimeout(close, wait); };
            box.addEventListener("mouseenter", function () { window.clearTimeout(timer); });
            box.addEventListener("mouseleave", start);
            box.addEventListener("focusin", function () { window.clearTimeout(timer); });
            start();
        }

        show(box);
        return {
            close: close,
            /** Changes the message (e.g. a countdown) without showing a new toast. */
            setMessage: function (text) {
                var line = made.text.querySelector("p.text-muted");
                if (line) {
                    line.textContent = String(text);
                }
            },
            /** Moves the progress bar (a toast made with options.progress); text replaces the message. */
            setProgress: setProgress
        };
    };

    /** Asks a question in a toast; resolves to true when it is confirmed. */
    Frp.confirm = function (options) {
        return new Promise(function (resolve) {
            questions.push({ options: options || {}, resolve: resolve });
            next();
        });
    };

    function next() {
        if (asking || !questions.length) {
            return;
        }

        asking = questions.shift();
        var options = asking.options;
        var made = card(options.danger ? "Error" : "Warning", options.title || "Are you sure?", options.message);
        var box = made.box;
        var id = "frp-question-" + Math.random().toString(36).substring(2, 9);
        box.setAttribute("role", "alertdialog");
        box.setAttribute("aria-modal", "false");
        box.setAttribute("data-question", "true");
        box.classList.add("ring-2", options.danger ? "ring-red-200" : "ring-amber-200");
        made.text.firstChild.id = id + "-title";
        box.setAttribute("aria-labelledby", id + "-title");
        if (made.text.childNodes[1]) {
            made.text.childNodes[1].id = id + "-text";
            box.setAttribute("aria-describedby", id + "-text");
        }

        var previous = document.activeElement;
        var answered = false;
        var answer = function (value) {
            if (answered) {
                return;
            }

            answered = true;
            document.removeEventListener("keydown", onKey, true);
            remove(box);
            var done = asking;
            asking = null;
            if (previous && previous.focus && document.body.contains(previous)) {
                previous.focus({ preventScroll: true });
            }

            done.resolve(value);
            next();
        };
        var onKey = function (event) {
            if (event.key === "Escape") {
                event.preventDefault();
                event.stopPropagation();
                answer(false);
            }
        };

        var buttons = element("div", "mt-3 flex flex-wrap justify-end gap-2");
        var cancel = element("button", "inline-flex h-9 items-center rounded-app border border-line bg-surface px-3 text-sm font-semibold text-ink transition hover:border-slate-300", options.cancelLabel || "Cancel");
        cancel.type = "button";
        cancel.addEventListener("click", function () { answer(false); });
        var confirm = element("button", "inline-flex h-9 items-center rounded-app px-3 text-sm font-semibold text-white transition "
            + (options.danger ? "bg-red-700 hover:bg-red-800" : "bg-accent hover:bg-accent-hover"), options.confirmLabel || "Confirm");
        confirm.type = "button";
        confirm.addEventListener("click", function () { answer(true); });
        buttons.appendChild(cancel);
        buttons.appendChild(confirm);
        made.text.appendChild(buttons);
        box.appendChild(closeButton(function () { answer(false); }));
        document.addEventListener("keydown", onKey, true);
        show(box);
        confirm.focus({ preventScroll: true });
    }
})();
