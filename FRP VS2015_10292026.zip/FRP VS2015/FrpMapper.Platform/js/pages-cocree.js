// COCREE v2.0: BSP's credit data submission (CSDF XML), the Workbench's four steps. Four tabs:
//   Generate       the BU's input workbooks → CSDF XML files, with the approved configuration (submission.prepare);
//   Validate       CSDF files → Stage 1, the preliminary checks, BSP's validation rules and the XSD (submission.prepare);
//   Header totals  the files of one submission → their totals written into every file's Header (submission.prepare);
//   Settings       the configuration (the Workbench's cocree_config.xlsx, cocree_dropdown_options.xlsx,
//                  cocree_validations.xlsx and BSP's XSD): a Maker (reference.manage) uploads it, a different Checker
//                  (reference.approve) approves it.
// Files are read and checked by the API; this page only collects them and shows the results.
(function () {
    "use strict";
    var F = window.Frp, html = F.html, C = F.components;

    var inputClass = "mt-2 h-11 w-full rounded-app border border-line bg-surface px-3 text-sm outline-none transition hover:border-slate-300 focus:border-accent disabled:opacity-60";
    var primaryClass = "inline-flex h-10 items-center gap-2 rounded-app bg-accent px-5 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-50";
    var secondaryClass = "inline-flex h-10 items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:cursor-not-allowed disabled:opacity-50";
    var smallPrimary = "inline-flex h-9 items-center gap-1.5 rounded-app bg-accent px-3 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50";
    var smallSecondary = "inline-flex h-9 items-center gap-1.5 rounded-app border border-line bg-surface px-3 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:opacity-50";
    var smallDanger = "inline-flex h-9 items-center gap-1.5 rounded-app bg-red-700 px-3 text-sm font-semibold text-white transition hover:bg-red-800 disabled:opacity-50";
    var labelClass = "block text-sm font-semibold text-ink";
    var hintClass = "mt-1 text-xs leading-5 text-subtle";

    /** The last day of the previous month as yyyy-MM-dd (the usual COCREE reference date). */
    function lastMonthEnd() {
        var today = new Date();
        var end = new Date(today.getFullYear(), today.getMonth(), 0);
        return end.getFullYear() + "-" + ("0" + (end.getMonth() + 1)).slice(-2) + "-" + ("0" + end.getDate()).slice(-2);
    }

    function todayText() {
        var t = new Date();
        return t.getFullYear() + "-" + ("0" + (t.getMonth() + 1)).slice(-2) + "-" + ("0" + t.getDate()).slice(-2);
    }

    function n0(value) {
        return F.n0 ? F.n0(value || 0) : String(value || 0);
    }

    function extension(name) {
        var dot = (name || "").lastIndexOf(".");
        return dot < 0 ? "" : name.substring(dot).toLowerCase();
    }

    /** A count from a configuration version's summary, e.g. fact(version, "validation rules"). */
    function fact(version, label) {
        var found = ((version.summary || {}).facts || []).filter(function (f) { return f.label.indexOf(label) === 0; })[0];
        return found ? found.count : 0;
    }

    function setupHasRules(setup) {
        return !!(setup && setup.configured && setup.validationRules);
    }

    function severityIcon(severity) {
        return { Error: "ph-x-circle text-red-700", Warning: "ph-warning text-amber-700" }[severity] || "ph-info text-accent";
    }

    /** "1. OLR - Installments.xlsx › Subject › row 12 › ID - Gender" */
    function where(issue) {
        var parts = [];
        if (issue.file) parts.push(issue.file);
        if (issue.sheet) parts.push(issue.sheet);
        if (issue.row) parts.push("row " + issue.row);
        if (issue.column) parts.push(issue.column);
        return parts.join(" › ");
    }

    /** The messages of a run, errors first; at most 300 are listed (the counts say how many there are). */
    function issueList(issues) {
        if (!issues || !issues.length) {
            return "";
        }

        var order = { Error: 0, Warning: 1, Info: 2 };
        var sorted = issues.slice().sort(function (a, b) { return (order[a.severity] || 0) - (order[b.severity] || 0); });
        var counts = ["Error", "Warning", "Info"].map(function (s) {
            var count = issues.filter(function (i) { return i.severity === s; }).length;
            return count ? count + " " + { Error: "error", Warning: "warning", Info: "note" }[s] + (count === 1 ? "" : "s") : null;
        }).filter(Boolean).join(", ");
        return html`<section class="mt-6 rounded-app border border-line bg-surface" aria-label="Messages">
    <header class="flex flex-wrap items-center justify-between gap-2 border-b border-line px-5 py-3">
        <h3 class="font-semibold text-ink">Messages</h3>
        <span class="text-sm text-muted">${counts}</span>
    </header>
    <ul class="relative max-h-[28rem] divide-y divide-line/70 overflow-auto">
        ${sorted.slice(0, 300).map(function (issue) {
            return html`<li class="flex gap-3 px-5 py-3 text-sm">
            <i class="ph ${severityIcon(issue.severity)} mt-0.5 shrink-0 self-start text-lg" aria-hidden="true"></i>
            <div class="min-w-0">
                <p class="break-words text-ink"><span class="sr-only">${issue.severity}: </span>${issue.code ? html`<span class="mr-1.5 rounded bg-slate-100 px-1.5 py-0.5 font-mono text-xs font-semibold">${issue.code}</span>` : ""}${issue.message}</p>
                ${where(issue) ? html`<p class="mt-0.5 break-words text-xs text-subtle">${where(issue)}</p>` : ""}
                ${issue.providerSubjectNo || issue.providerContractNo ? html`<p class="mt-0.5 font-mono text-xs text-muted">${issue.element ? issue.element + " · " : ""}${issue.providerSubjectNo ? "subject " + issue.providerSubjectNo : ""}${issue.providerContractNo ? " · contract " + issue.providerContractNo : ""}</p>` : ""}
            </div>
        </li>`;
        })}
    </ul>
    ${sorted.length > 300 ? html`<p class="border-t border-line px-5 py-2 text-xs text-subtle">The first 300 of ${n0(sorted.length)} messages are listed.</p>` : ""}
</section>`;
    }

    var Cocree = F.page(function (app, match, query) {
        F.Page.call(this, app);
        this.canPrepare = F.can(F.Permissions.SubmissionPrepare);
        this.canManage = F.can(F.Permissions.ReferenceManage);
        this.canApprove = F.can(F.Permissions.ReferenceApprove);
        this.canSettings = this.canManage || this.canApprove;
        var wanted = query && query.get("tab");
        this.tab = !this.canPrepare ? "settings" : (wanted === "settings" && this.canSettings) || wanted === "totals" || wanted === "validate" ? wanted : "generate";

        // Generate
        this.setup = null; this.setupError = null;
        this.form = { providerCode: "", referenceDate: lastMonthEnd(), submissionType: "0", version: "1.0", providerComments: "", maxRecordsPerFile: "300000" };
        this.inputs = []; this.progress = null; this.running = false; this.result = null; this.showLog = false;

        // Validate
        this.checkFiles = []; this.checkProgress = null; this.checkRunning = false; this.checkResult = null; this.checkRunId = null;

        // Header totals
        this.totalsDate = lastMonthEnd(); this.totalsFiles = []; this.totalsResult = null; this.totalsBusy = false;

        // Settings
        var self = this;
        this.settings = !this.canSettings ? null : new C.WorkbenchSettings(this, {
            api: "cocree/config",
            title: "COCREE configuration",
            intro: html`The files the Regulatory Reports Workbench kept in its Config folder. Download the ones in use below, change them in
                Excel and upload them together. BSP's COCREE XSD is optional: with it, Validate also checks the files against it. Everything
                is checked first; a Checker other than you approves it.`,
            files: [
                { field: "configFile", label: "Configuration (cocree_config.xlsx)", accept: ".xlsx" },
                { field: "codeListFile", label: "Code lists (cocree_dropdown_options.xlsx)", accept: ".xlsx" },
                { field: "validationFile", label: "Validation rules (cocree_validations.xlsx)", accept: ".xlsx" },
                { field: "xsdFile", label: "BSP's COCREE XSD (.xsd)", accept: ".xsd", optional: true }
            ],
            downloads: [
                { file: "config", label: "Configuration", icon: "ph-microsoft-excel-logo" },
                { file: "code-lists", label: "Code lists", icon: "ph-microsoft-excel-logo" },
                { file: "validations", label: "Validation rules", icon: "ph-microsoft-excel-logo", when: function (v) { return fact(v, "validation rules") > 0; } },
                { file: "xsd", label: "XSD", icon: "ph-file-code", when: function (v) { return fact(v, "XSD") > 0; } }
            ],
            onApproved: function () {
                if (self.canPrepare) {
                    F.api.get("cocree/setup").then(function (setup) { self.setup = setup; self.update(); });
                }
            }
        });
    }, {
        title: function () { return "COCREE · FRP Mapper"; },

        init: function () {
            var self = this, loads = [];
            if (self.canPrepare) {
                loads.push(F.api.get("cocree/setup").then(function (setup) {
                    self.setup = setup;
                    if (setup.providers.length === 1) {
                        self.form.providerCode = setup.providers[0].code;
                    }
                }, function (e) {
                    self.setupError = F.messageOf(e);
                }));
            }

            if (self.settings) {
                loads.push(self.settings.load());
            }

            return Promise.all(loads);
        },

        switchTo: function (tab) {
            this.tab = tab;
            this.update();
        },

        // ---------- Generate ----------

        addInputs: function (list) {
            var self = this, maxBytes = self.setup ? self.setup.maxUploadBytes : 0;
            Array.prototype.forEach.call(list || [], function (file) {
                if (extension(file.name) !== ".xlsx") {
                    F.toast("Error", file.name, "Only Excel .xlsx workbooks can be read (save a .xlsb or .xls as .xlsx first).");
                } else if (maxBytes && file.size > maxBytes) {
                    F.toast("Error", file.name, "The file is larger than " + F.size(maxBytes) + ".");
                } else if (self.inputs.some(function (f) { return f.name === file.name; })) {
                    F.toast("Warning", file.name, "This workbook is already in the list.");
                } else {
                    self.inputs.push(file);
                }
            });
            self.result = null;
            self.update();
        },

        removeInput: function (index) {
            this.inputs.splice(index, 1);
            this.result = null;
            this.update();
        },

        /** Sends the workbooks; the API streams its progress, then the result. */
        generate: function () {
            var self = this, form = self.form;
            if (!form.providerCode) { F.toast("Error", null, "Choose the provider code."); return Promise.resolve(); }
            if (!self.inputs.length) { F.toast("Error", null, "Choose the COCREE input workbooks."); return Promise.resolve(); }
            if (form.referenceDate > todayText()) { F.toast("Error", null, "The file reference date cannot be in the future."); return Promise.resolve(); }

            self.running = true;
            self.result = null;
            self.progress = new C.Progress(self, "Generating the COCREE XML");
            self.progress.show({ percent: 0, stage: "Sending the workbooks to the API", detail: self.inputs.length + " workbooks · " + F.size(self.inputs.reduce(function (t, f) { return t + f.size; }, 0)) });
            var fields = {
                files: self.inputs, providerCode: form.providerCode, referenceDate: form.referenceDate, submissionType: form.submissionType,
                version: form.version, providerComments: form.providerComments, maxRecordsPerFile: form.maxRecordsPerFile
            };
            var formData = new FormData();
            Object.keys(fields).forEach(function (key) {
                if (Array.isArray(fields[key])) {
                    fields[key].forEach(function (file) { formData.append(key, file, file.name); });
                } else {
                    formData.append(key, String(fields[key]));
                }
            });
            return F.api.stream("POST", "cocree/export", { form: formData }, function (update) { self.progress.show(update); },
                function (item) { return item.cocree; }, "The COCREE XML was not generated.").then(function (result) {
                self.result = result;
                if (result.succeeded) {
                    F.toast("Success", null, result.files.length + (result.files.length === 1 ? " file" : " files") + " generated.");
                }
            }, function (e) {
                F.toast("Error", "The COCREE XML was not generated", F.messageOf(e));
            }).then(function () {
                self.progress.stop();
                self.progress = null;
                self.running = false;
                self.update();
            });
        },

        /** A file of a run (or all.zip). */
        download: function (runId, name) {
            return F.api.file("cocree/outputs/" + runId + "/" + encodeURIComponent(name), null, { busy: "Downloading " + name }).then(function (file) {
                F.saveFile(file.name, file.blob);
            }, function (e) {
                F.toast("Error", "The file was not downloaded", F.messageOf(e));
            });
        },

        renderGenerate: function () {
            var self = this, setup = self.setup, form = self.form, off = self.running;
            if (self.setupError) {
                return html`<div class="mt-8">${C.notice("Error", "COCREE cannot be loaded", self.setupError)}</div>`;
            }

            if (!setup) {
                return html`<div class="mt-8">${C.loading("py-10", "Loading the COCREE configuration")}</div>`;
            }

            if (!setup.configured) {
                return html`<div class="mt-8">${C.notice("Warning", "No COCREE configuration has been approved yet",
                    html`<p>A Maker uploads the configuration workbooks on the Settings tab and a Checker approves them. Then XML can be generated here.</p>`)}</div>`;
            }

            if (!setup.providers.length) {
                return html`<div class="mt-8">${C.notice("Warning", "No provider code", html`<p>No approved bank profile has a 10-digit provider code. Add it on Bank profiles.</p>`)}</div>`;
            }

            var bind = function (field) {
                return self.on(function (e) { form[field] = e.target.value; self.result = null; self.update(); });
            };
            return html`<div class="mt-8 grid max-w-6xl gap-8 2xl:max-w-none 2xl:grid-cols-[minmax(0,1fr)_22rem]">
    <section class="min-w-0">
        <div class="rounded-app border border-line bg-surface p-6">
            <h2 class="font-semibold text-ink">1. Header of the files</h2>
            <div class="mt-4 grid gap-5 sm:grid-cols-2">
                <label class="${labelClass}">Provider code
                    <select class="${inputClass}"${F.attr("disabled", off)} data-change="${bind("providerCode")}">
                        <option value="">Choose…</option>
                        ${setup.providers.map(function (p) { return html`<option value="${p.code}"${F.attr("selected", form.providerCode === p.code)}>${p.code} · ${p.bankKey} · ${p.bankName}</option>`; })}
                    </select>
                </label>
                <label class="${labelClass}">File reference date
                    <input type="date" class="${inputClass}" value="${form.referenceDate}" max="${todayText()}"${F.attr("disabled", off)} data-change="${bind("referenceDate")}" />
                    <span class="${hintClass}">Every workbook's File Info sheet must be for this month and year.</span>
                </label>
                <label class="${labelClass}">Submission type
                    <select class="${inputClass}"${F.attr("disabled", off)} data-change="${bind("submissionType")}">
                        ${setup.submissionTypes.map(function (t) { return html`<option value="${t}"${F.attr("selected", form.submissionType === t)}>${t}</option>`; })}
                    </select>
                </label>
                <label class="${labelClass}">Version
                    <input class="${inputClass}" value="${form.version}" maxlength="10"${F.attr("disabled", off)} data-input="${bind("version")}" />
                </label>
                <label class="${labelClass} sm:col-span-2">Provider comments <span class="font-normal text-subtle">(optional)</span>
                    <input class="${inputClass}" value="${form.providerComments}" maxlength="500"${F.attr("disabled", off)} data-input="${bind("providerComments")}" />
                </label>
                <label class="${labelClass}">Records per file
                    <input type="number" class="${inputClass}" value="${form.maxRecordsPerFile}" min="1" max="${setup.maxRecordsPerFile}" step="1"${F.attr("disabled", off)} data-input="${bind("maxRecordsPerFile")}" />
                    <span class="${hintClass}">${n0(setup.bspRecordsPerFile)} is BSP's limit. A subject always stays in one file with its exposures.</span>
                </label>
            </div>
        </div>

        <div class="mt-6 rounded-app border border-line bg-surface p-6">
            <h2 class="font-semibold text-ink">2. Input workbooks</h2>
            <p class="mt-1 text-sm leading-6 text-muted">The BU's COCREE input files (.xlsx), each starting with its File Info sheet. Choose all the files of the submission together.</p>
            <label class="${secondaryClass} mt-4 cursor-pointer ${off ? "pointer-events-none opacity-50" : ""}">
                <i class="ph ph-file-plus" aria-hidden="true"></i> Add workbooks
                <input type="file" class="sr-only" accept=".xlsx" multiple${F.attr("disabled", off)}
                       data-change="${self.on(function (e) { var files = e.target.files; self.addInputs(files); e.target.value = ""; })}" />
            </label>
            ${self.inputs.length ? html`<ul class="mt-4 divide-y divide-line rounded-app border border-line">
                ${self.inputs.map(function (file, index) {
                    return html`<li class="flex items-center gap-3 px-4 py-2.5 text-sm">
                    <i class="ph ph-microsoft-excel-logo text-lg text-emerald-700" aria-hidden="true"></i>
                    <span class="min-w-0 flex-1 truncate text-ink" title="${file.name}">${file.name}</span>
                    <span class="shrink-0 tabular-nums text-subtle">${F.size(file.size)}</span>
                    <button type="button" class="shrink-0 rounded-app p-1.5 text-muted transition hover:bg-canvas hover:text-red-700" aria-label="Remove ${file.name}"${F.attr("disabled", off)}
                            data-click="${self.on(function () { self.removeInput(index); })}"><i class="ph ph-x" aria-hidden="true"></i></button>
                </li>`;
                })}
            </ul>` : html`<p class="mt-4 text-sm text-subtle">No workbook chosen yet.</p>`}
            <div class="mt-6 flex flex-wrap items-center gap-3">
                <button type="button" class="${primaryClass}"${F.attr("disabled", off || !self.inputs.length || !form.providerCode)} data-click="${self.on(function () { return self.generate(); })}">
                    ${off ? html`<span class="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" aria-hidden="true"></span>` : html`<i class="ph ph-file-code" aria-hidden="true"></i>`}
                    Generate XML
                </button>
                <span class="text-xs text-subtle">The workbooks are checked first; nothing is written when a check fails.</span>
            </div>
        </div>

        ${self.progress ? html`<div class="mt-6">${self.progress.render()}</div>` : ""}
        ${self.result ? self.renderResult(self.result) : ""}
    </section>

    <aside class="grid min-w-0 content-start gap-4 sm:grid-cols-2 2xl:grid-cols-1">
        <div class="rounded-app border border-line bg-surface p-5">
            <h2 class="font-semibold text-ink">Configuration in use</h2>
            <p class="mt-1 text-sm text-muted">${setup.configuration.sourceFiles}</p>
            <p class="mt-1 text-xs text-subtle">Approved by ${setup.configuration.decidedBy} · ${F.date(setup.configuration.decidedAt)}</p>
            <p class="mt-2 text-xs text-muted">${n0(setup.validationRules)} validation rules · ${setup.xsdFileName ? "XSD " + setup.xsdFileName : "no XSD"}</p>
            <details class="mt-4">
                <summary class="cursor-pointer text-sm font-semibold text-accent">The ${setup.inputFiles.length} input files it knows</summary>
                <ol class="mt-3 space-y-2 text-sm">
                    ${setup.inputFiles.map(function (f) {
                        return html`<li><span class="text-ink">${f.name}</span><span class="block text-xs text-subtle">${f.sheets.join(" · ")} · hierarchy ${f.subjectHierarchy}</span></li>`;
                    })}
                </ol>
            </details>
        </div>
        <div class="rounded-app border border-line bg-surface p-5 text-sm leading-6 text-muted">
            <h2 class="font-semibold text-ink">What is checked</h2>
            <ul class="mt-2 list-disc space-y-1 pl-5">
                <li>File Info first, a known input file, the reference month and year</li>
                <li>The configured sheets, with the configured columns in order</li>
                <li>Wording turned into BSP codes; unknown wording is flagged</li>
                <li>Subjects without exposures, exposures without a subject, duplicate contract numbers</li>
                <li>A subject in several files is kept once (lowest hierarchy)</li>
            </ul>
        </div>
    </aside>
</div>`;
        },

        renderResult: function (result) {
            var self = this;
            var errors = result.issues.filter(function (i) { return i.severity === "Error"; }).length;
            var head = result.succeeded
                ? C.notice("Success", result.files.length + (result.files.length === 1 ? " file generated" : " files generated"),
                    html`<p>Download the files below. Each is UTF-8 without BOM, as BSP requires.${result.issues.length ? " Read the messages: warnings do not stop the export but BSP may reject what they describe." : ""}</p>`)
                : C.notice("Error", "No XML was written",
                    html`<p>${errors} ${errors === 1 ? "problem stops" : "problems stop"} the export. Correct the workbooks and generate again.</p>`);
            return html`<section class="mt-6" aria-label="Result">
    ${head}
    ${result.succeeded ? html`<div class="mt-4 grid gap-3 sm:grid-cols-4">
        ${C.metric("Subjects", n0(result.subjects))}
        ${C.metric("Contracts", n0(result.contracts))}
        ${C.metric("Negative events", n0(result.negativeEvents))}
        ${C.metric("Files", n0(result.files.length))}
    </div>` : ""}
    ${result.files.length ? html`<ul class="mt-4 divide-y divide-line/70 rounded-app border border-line bg-surface" aria-label="Generated files">
        ${result.files.map(function (file) {
            return html`<li class="flex flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3">
            <div class="min-w-0 flex-1 basis-64">
                <p class="break-all font-mono text-sm text-ink">${file.name}</p>
                <p class="mt-0.5 text-xs text-subtle">${n0(file.records)} records · ${F.size(file.size)} · ${file.elements.map(function (e) { return e.element + " " + n0(e.count); }).join(" · ")}</p>
            </div>
            <button type="button" class="${smallSecondary}" data-click="${self.on(function () { return self.download(result.outputId, file.name); })}"><i class="ph ph-download-simple" aria-hidden="true"></i> Download</button>
        </li>`;
        })}
    </ul>
    <div class="mt-3 flex flex-wrap gap-3">
        ${result.files.length > 1 ? html`<button type="button" class="${secondaryClass}" data-click="${self.on(function () { return self.download(result.outputId, "all.zip"); })}"><i class="ph ph-file-zip" aria-hidden="true"></i> Download all (.zip)</button>` : ""}
        ${setupHasRules(self.setup) ? html`<button type="button" class="${secondaryClass}" data-click="${self.on(function () { return self.validateRun(result.outputId, result.files.length); })}"><i class="ph ph-list-checks" aria-hidden="true"></i> Validate these files</button>` : ""}
    </div>` : ""}
    ${result.errorReport ? html`<button type="button" class="${secondaryClass} mt-4" data-click="${self.on(function () { return self.download(result.outputId, result.errorReport); })}">
        <i class="ph ph-file-x" aria-hidden="true"></i> Download the error report (${result.errorReport})
    </button>` : ""}
    ${issueList(result.issues)}
    <details class="mt-6 rounded-app border border-line bg-surface"${F.attr("open", self.showLog)}>
        <summary class="cursor-pointer px-5 py-3 text-sm font-semibold text-ink">Log (${result.log.length} lines)</summary>
        <pre class="max-h-80 overflow-auto whitespace-pre-wrap border-t border-line px-5 py-3 font-mono text-xs leading-5 text-muted">${result.log.join("\n")}</pre>
    </details>
</section>`;
        },

        // ---------- Validate ----------

        addCheckFiles: function (list) {
            var self = this, maxBytes = self.setup ? self.setup.maxUploadBytes : 0;
            Array.prototype.forEach.call(list || [], function (file) {
                if (extension(file.name) !== ".xml") {
                    F.toast("Error", file.name, "Choose the CSDF XML files.");
                } else if (maxBytes && file.size > maxBytes) {
                    F.toast("Error", file.name, "The file is larger than " + F.size(maxBytes) + ".");
                } else if (!self.checkFiles.some(function (f) { return f.name === file.name; })) {
                    self.checkFiles.push(file);
                }
            });
            self.checkRunId = null;
            self.checkResult = null;
            self.update();
        },

        /** Validates the files of a Generate run (they are on the server already). */
        validateRun: function (runId, count) {
            this.tab = "validate";
            this.checkFiles = [];
            this.checkRunId = { id: runId, count: count };
            return this.validate();
        },

        /** Sends the files (or the run's id); the API streams its progress, then one result per file. */
        validate: function () {
            var self = this;
            var formData = new FormData();
            if (self.checkRunId) {
                formData.append("runId", self.checkRunId.id);
            } else {
                if (!self.checkFiles.length) { F.toast("Error", null, "Choose the CSDF XML files."); return Promise.resolve(); }
                self.checkFiles.forEach(function (file) { formData.append("files", file, file.name); });
            }

            self.checkRunning = true;
            self.checkResult = null;
            self.checkProgress = new C.Progress(self, "Validating the COCREE files");
            self.checkProgress.show({ percent: 0, stage: self.checkRunId ? "Reading the generated files" : "Sending the files to the API" });
            return F.api.stream("POST", "cocree/validate", { form: formData }, function (update) { self.checkProgress.show(update); },
                function (item) { return item.cocreeValidation; }, "The files were not validated.").then(function (result) {
                self.checkResult = result;
                F.toast(result.succeeded ? "Success" : "Warning", null, result.succeeded ? "Every file passed." : "Some files have problems: read the results.");
            }, function (e) {
                F.toast("Error", "The files were not validated", F.messageOf(e));
            }).then(function () {
                self.checkProgress.stop();
                self.checkProgress = null;
                self.checkRunning = false;
                self.update();
            });
        },

        renderValidate: function () {
            var self = this, setup = self.setup, off = self.checkRunning;
            if (self.setupError) return html`<div class="mt-8">${C.notice("Error", "COCREE cannot be loaded", self.setupError)}</div>`;
            if (!setup) return html`<div class="mt-8">${C.loading("py-10", "Loading the COCREE configuration")}</div>`;
            if (!setupHasRules(setup)) {
                return html`<div class="mt-8">${C.notice("Warning", "No validation rules have been approved yet",
                    html`<p>A Maker uploads the configuration with cocree_validations.xlsx (and BSP's XSD) on the Settings tab and a Checker approves it.</p>`)}</div>`;
            }

            return html`<div class="mt-8 grid max-w-6xl gap-8 2xl:max-w-none 2xl:grid-cols-[minmax(0,1fr)_22rem]">
    <section class="min-w-0">
        <div class="rounded-app border border-line bg-surface p-6">
            <h2 class="font-semibold text-ink">CSDF files to validate</h2>
            <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                Files generated here or anywhere else. Each gets the Workbench's report: the preliminary checks when they find problems,
                otherwise every BSP rule with the records it finds wrong${setup.xsdFileName ? ", and the XSD check" : ""}.
            </p>
            ${self.checkRunId ? html`<p class="mt-4 text-sm text-ink"><i class="ph ph-link mr-1 text-accent" aria-hidden="true"></i>The ${self.checkRunId.count} files just generated ·
                <button type="button" class="font-semibold text-accent" data-click="${self.on(function () { self.checkRunId = null; self.checkResult = null; self.update(); })}">Choose other files</button></p>` : html`
            <label class="${secondaryClass} mt-4 cursor-pointer ${off ? "pointer-events-none opacity-50" : ""}">
                <i class="ph ph-file-plus" aria-hidden="true"></i> Add files
                <input type="file" class="sr-only" accept=".xml" multiple data-change="${self.on(function (e) { var files = e.target.files; self.addCheckFiles(files); e.target.value = ""; })}" />
            </label>
            ${self.checkFiles.length ? html`<p class="mt-2 text-sm text-muted">${self.checkFiles.length} ${self.checkFiles.length === 1 ? "file" : "files"} · ${F.size(self.checkFiles.reduce(function (t, f) { return t + f.size; }, 0))} ·
                <button type="button" class="font-semibold text-accent" data-click="${self.on(function () { self.checkFiles = []; self.checkResult = null; self.update(); })}">Clear</button></p>` : ""}`}
            <div class="mt-6">
                <button type="button" class="${primaryClass}"${F.attr("disabled", off || (!self.checkRunId && !self.checkFiles.length))} data-click="${self.on(function () { return self.validate(); })}">
                    ${off ? html`<span class="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" aria-hidden="true"></span>` : html`<i class="ph ph-list-checks" aria-hidden="true"></i>`}
                    Validate
                </button>
            </div>
        </div>
        ${self.checkProgress ? html`<div class="mt-6">${self.checkProgress.render()}</div>` : ""}
        ${self.checkResult ? self.renderValidation(self.checkResult) : ""}
    </section>
    <aside class="grid min-w-0 content-start gap-4 sm:grid-cols-2 2xl:grid-cols-1">
        <div class="rounded-app border border-line bg-surface p-5 text-sm leading-6 text-muted">
            <h2 class="font-semibold text-ink">What is checked</h2>
            <ol class="mt-2 list-decimal space-y-1 pl-5">
                <li>Stage 1: the file name, UTF-8 without BOM, one Header, Body and Footer, known record types</li>
                <li>Preliminary: duplicate subjects and contracts, links and negative events without their subject, dates, numbers and amounts</li>
                <li>BSP's ${n0(setup.validationRules)} rules (only when the preliminary checks pass, as in the Workbench)</li>
                <li>${setup.xsdFileName ? "The XSD " + setup.xsdFileName : "The XSD, once one is in the configuration"}</li>
            </ol>
        </div>
    </aside>
</div>`;
        },

        renderValidation: function (result) {
            var self = this;
            var outcome = function (file) {
                return { Passed: "bg-emerald-50 text-emerald-800", Failed: "bg-red-50 text-red-800", Stopped: "bg-amber-50 text-amber-900" }[file.outcome] || "bg-slate-100 text-ink";
            };
            return html`<section class="mt-6 grid gap-4" aria-label="Validation results">
    ${result.succeeded ? C.notice("Success", "Every file passed", html`<p>No rule found a wrong record${result.xsdChecked ? " and the XSD check passed" : ""}.</p>`)
        : C.notice("Warning", "Some files have problems", html`<p>Download a file's report for the full list. Correct the input workbooks, generate again and validate the new files.</p>`)}
    ${result.files.length > 1 ? html`<button type="button" class="${secondaryClass} justify-self-start" data-click="${self.on(function () { return self.download(result.outputId, "all.zip"); })}"><i class="ph ph-file-zip" aria-hidden="true"></i> Download every report (.zip)</button>` : ""}
    ${result.files.map(function (file) {
        return html`<article class="rounded-app border border-line bg-surface">
        <header class="flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-line px-5 py-3">
            <p class="min-w-0 flex-1 basis-64 break-all font-mono text-sm text-ink">${file.name}</p>
            <span class="rounded-app px-2 py-0.5 text-xs font-semibold ${outcome(file)}">${file.outcome}${file.stage === "Preliminary" ? " · preliminary checks" : ""}</span>
        </header>
        <div class="px-5 py-4">
            <p class="text-sm text-muted">${n0(file.records)} records · ${F.size(file.size)}${file.stage === "Rules" ? " · " + n0(file.rulesApplied) + " rules applied · " + n0(file.recordErrors) + " wrong" + (file.undecided ? " · " + n0(file.undecided) + " undecided" : "") : ""}${file.xsdValid === true ? " · XSD passed" : file.xsdValid === false ? " · XSD: " + n0(file.xsdIssueCount) + " messages" : ""}</p>
            <div class="mt-3 flex flex-wrap gap-2">
                ${file.report ? html`<button type="button" class="${smallSecondary}" data-click="${self.on(function () { return self.download(result.outputId, file.report); })}"><i class="ph ph-download-simple" aria-hidden="true"></i> Report (${file.stage === "Preliminary" ? "preliminary" : "rules"})</button>` : ""}
                ${file.xsdReport ? html`<button type="button" class="${smallSecondary}" data-click="${self.on(function () { return self.download(result.outputId, file.xsdReport); })}"><i class="ph ph-file-csv" aria-hidden="true"></i> XSD messages (.csv)</button>` : ""}
            </div>
            ${file.rules.length ? html`<div class="relative mt-4 max-h-[32rem] overflow-auto rounded-app border border-line">
                <table class="w-full min-w-[640px] text-left text-sm">
                    <thead class="sticky top-0 border-b border-line bg-surface text-xs font-semibold text-subtle"><tr>
                        <th class="px-3 py-2">Rule</th><th class="px-3 py-2">Element</th><th class="px-3 py-2">Message</th><th class="px-3 py-2 text-right">Wrong</th><th class="px-3 py-2 text-right">Undecided</th>
                    </tr></thead>
                    <tbody class="divide-y divide-line/70">
                        ${file.rules.slice(0, 50).map(function (rule) {
                            return html`<tr class="align-top">
                            <td class="px-3 py-2 font-mono text-xs font-semibold">${rule.code}</td>
                            <td class="px-3 py-2">${rule.element}</td>
                            <td class="px-3 py-2"><span class="text-ink">${rule.message}</span>${rule.examples.length ? html`<span class="mt-0.5 block font-mono text-xs text-subtle">${rule.examples.slice(0, 2).join(" · ")}</span>` : ""}</td>
                            <td class="px-3 py-2 text-right tabular-nums">${n0(rule.errors)}</td>
                            <td class="px-3 py-2 text-right tabular-nums">${n0(rule.undecided)}</td>
                        </tr>`;
                        })}
                    </tbody>
                </table>
                ${file.rules.length > 50 ? html`<p class="border-t border-line px-3 py-2 text-xs text-subtle">The 50 rules with the most wrong records of ${n0(file.rules.length)}; the report has all of them.</p>` : ""}
            </div>` : ""}
            ${issueList(file.issues)}
            ${file.xsdIssues.length ? html`<details class="mt-4 rounded-app border border-line">
                <summary class="cursor-pointer px-4 py-2 text-sm font-semibold text-ink">XSD messages (${n0(file.xsdIssueCount)})</summary>
                <ul class="relative max-h-80 divide-y divide-line/70 overflow-auto border-t border-line text-sm">
                    ${file.xsdIssues.slice(0, 200).map(function (issue) {
                        return html`<li class="px-4 py-2"><span class="font-mono text-xs text-subtle">line ${issue.line} · ${issue.severity}</span>
                        <span class="block break-words text-ink">${issue.message}</span>
                        ${issue.path ? html`<span class="block break-all font-mono text-xs text-subtle">${issue.path}</span>` : ""}</li>`;
                    })}
                </ul>
            </details>` : ""}
        </div>
    </article>`;
    })}
</section>`;
        },

        // ---------- Header totals ----------

        addTotalsFiles: function (list) {
            var self = this;
            Array.prototype.forEach.call(list || [], function (file) {
                if (extension(file.name) !== ".xml") {
                    F.toast("Error", file.name, "Choose the CSDF XML files.");
                } else if (!self.totalsFiles.some(function (f) { return f.name === file.name; })) {
                    self.totalsFiles.push(file);
                }
            });
            self.totalsResult = null;
            self.update();
        },

        /** Reads the files (apply false) or writes the totals into them (apply true). */
        totals: function (apply) {
            var self = this;
            var ask = apply
                ? F.confirm({ title: "Write the totals into every file's Header?", message: "New copies of the " + self.totalsFiles.length + " files are made with the submission's totals; your files are not changed.", confirmLabel: "Write totals" })
                : Promise.resolve(true);
            return ask.then(function (yes) {
                if (!yes) return undefined;
                self.totalsBusy = true;
                self.update();
                return F.api.upload("cocree/header-totals", { files: self.totalsFiles, referenceDate: self.totalsDate, apply: apply ? "true" : "false" },
                    { busy: apply ? "Writing the totals" : "Reading the files" }).then(function (result) {
                    self.totalsResult = result;
                    if (apply && result.outputId) F.toast("Success", null, "The totals were written. Download the files below.");
                }, function (e) {
                    F.toast("Error", null, F.messageOf(e));
                }).then(function () {
                    self.totalsBusy = false;
                    self.update();
                });
            });
        },

        renderTotals: function () {
            var self = this, result = self.totalsResult, off = self.totalsBusy;
            return html`<div class="mt-8 max-w-5xl">
    <div class="rounded-app border border-line bg-surface p-6">
        <h2 class="font-semibold text-ink">Add up the records of a submission's files</h2>
        <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
            When a submission has several CSDF files, every file's Header must give the totals of the whole submission. Choose all its
            files: they are checked (layout, file name, reference date) and their records counted; then the totals can be written into each Header.
        </p>
        <div class="mt-5 grid gap-5 sm:grid-cols-[14rem_minmax(0,1fr)]">
            <label class="${labelClass}">File reference date
                <input type="date" class="${inputClass}" value="${self.totalsDate}"${F.attr("disabled", off)}
                       data-change="${self.on(function (e) { self.totalsDate = e.target.value; self.totalsResult = null; self.update(); })}" />
            </label>
            <div>
                <span class="${labelClass}">CSDF XML files</span>
                <label class="${secondaryClass} mt-2 cursor-pointer ${off ? "pointer-events-none opacity-50" : ""}">
                    <i class="ph ph-file-plus" aria-hidden="true"></i> Add files
                    <input type="file" class="sr-only" accept=".xml" multiple data-change="${self.on(function (e) { var files = e.target.files; self.addTotalsFiles(files); e.target.value = ""; })}" />
                </label>
                ${self.totalsFiles.length ? html`<p class="mt-2 text-sm text-muted">${self.totalsFiles.length} ${self.totalsFiles.length === 1 ? "file" : "files"} ·
                    <button type="button" class="font-semibold text-accent" data-click="${self.on(function () { self.totalsFiles = []; self.totalsResult = null; self.update(); })}">Clear</button></p>` : ""}
            </div>
        </div>
        <div class="mt-6 flex flex-wrap gap-3">
            <button type="button" class="${primaryClass}"${F.attr("disabled", off || !self.totalsFiles.length)} data-click="${self.on(function () { return self.totals(false); })}">
                <i class="ph ph-calculator" aria-hidden="true"></i> Check and add up
            </button>
            ${result && result.succeeded && !result.outputId ? html`<button type="button" class="${secondaryClass}"${F.attr("disabled", off)} data-click="${self.on(function () { return self.totals(true); })}">
                <i class="ph ph-pencil-simple-line" aria-hidden="true"></i> Write the totals into the files
            </button>` : ""}
        </div>
    </div>
    ${result ? html`<section class="mt-6">
        ${result.succeeded ? "" : C.notice("Error", "The files have problems", html`<p>Correct them before writing the totals.</p>`)}
        <div class="mt-4 grid gap-3 sm:grid-cols-3">
            ${C.metric("Subjects", n0(result.subjects))}
            ${C.metric("Contracts", n0(result.contracts))}
            ${C.metric("Negative events", n0(result.negativeEvents))}
        </div>
        <div class="mt-4 overflow-x-auto rounded-app border border-line bg-surface">
            <table class="w-full min-w-[640px] text-left text-sm">
                <thead class="border-b border-line text-xs font-semibold text-subtle"><tr>
                    <th class="px-4 py-2">File</th><th class="px-4 py-2 text-right">Subjects</th><th class="px-4 py-2 text-right">Contracts</th><th class="px-4 py-2 text-right">Negative events</th>
                    ${result.outputId ? html`<th class="px-4 py-2"><span class="sr-only">Download</span></th>` : ""}
                </tr></thead>
                <tbody class="divide-y divide-line/70">
                    ${result.files.map(function (file) {
                        return html`<tr>
                        <td class="px-4 py-2 font-mono text-xs">${file.name}</td>
                        <td class="px-4 py-2 text-right tabular-nums">${n0(file.subjects)}</td>
                        <td class="px-4 py-2 text-right tabular-nums">${n0(file.contracts)}</td>
                        <td class="px-4 py-2 text-right tabular-nums">${n0(file.negativeEvents)}</td>
                        ${result.outputId ? html`<td class="px-4 py-2 text-right"><button type="button" class="${smallSecondary}" data-click="${self.on(function () { return self.download(result.outputId, file.name); })}"><i class="ph ph-download-simple" aria-hidden="true"></i> Download</button></td>` : ""}
                    </tr>`;
                    })}
                </tbody>
            </table>
        </div>
        ${result.outputId && result.files.length > 1 ? html`<button type="button" class="${secondaryClass} mt-3" data-click="${self.on(function () { return self.download(result.outputId, "all.zip"); })}"><i class="ph ph-file-zip" aria-hidden="true"></i> Download all (.zip)</button>` : ""}
        ${issueList(result.issues)}
    </section>` : ""}
</div>`;
        },

        render: function () {
            var self = this, tabs = [];
            if (self.canPrepare) {
                tabs.push({ key: "generate", label: "Generate" });
                tabs.push({ key: "validate", label: "Validate" });
                tabs.push({ key: "totals", label: "Header totals" });
            }

            if (self.settings) tabs.push({ key: "settings", label: "Settings", count: self.settings.waiting() });
            var body = self.tab === "settings" ? self.settings.render() : self.tab === "totals" ? self.renderTotals()
                : self.tab === "validate" ? self.renderValidate() : self.renderGenerate();
            return html`<div class="px-6 py-8 lg:px-10 lg:py-10">
    <header class="border-b border-line pb-8">
        <h1 class="font-display text-3xl font-bold tracking-tight text-ink">COCREE</h1>
        <p class="mt-2 max-w-prose text-base leading-7 text-muted">
            Build the credit data submission (CSDF XML) from the BU's COCREE input workbooks, validate it with BSP's rules and XSD, and add
            up the header totals of a submission's files, as the Regulatory Reports Workbench did.
        </p>
    </header>
    ${tabs.length > 1 ? html`<div class="mt-8 flex flex-wrap gap-1" role="tablist" aria-label="Section">
        ${tabs.map(function (tab) {
            return html`<button type="button" role="tab" aria-selected="${self.tab === tab.key ? "true" : "false"}" class="inline-flex h-9 items-center rounded-app px-3 text-sm font-medium transition ${self.tab === tab.key ? "bg-ink text-white" : "text-muted hover:bg-surface hover:text-ink"}"
                data-click="${self.on(function () { self.switchTo(tab.key); })}">
                ${tab.label}
                ${tab.count ? html`<span class="ml-2 rounded-app bg-amber-100 px-1.5 text-xs font-semibold text-amber-900">${tab.count}</span>` : ""}
            </button>`;
        })}
    </div>` : ""}
    ${body}
</div>`;
        }
    });

    F.routes.push({ pattern: /^cocree$/, permission: [F.Permissions.SubmissionPrepare, F.Permissions.ReferenceManage, F.Permissions.ReferenceApprove],
        create: function (app, match, query) { return new Cocree(app, match, query); } });
})();
