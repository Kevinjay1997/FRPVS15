// FRP Mapper Platform: the router, the layout, the event wiring and the idle timeout. Loaded last.
(function () {
    "use strict";

    var Frp = window.Frp;
    var html = Frp.html;
    var C = Frp.components;
    var root = document.getElementById("app");
    var basePath = new URL(document.baseURI).pathname;

    /** The path inside the application ("projects/abc"), from a URL. */
    function localPath(url) {
        var path = url.pathname;
        if (path.indexOf(basePath) === 0) {
            path = path.substring(basePath.length);
        } else {
            path = path.replace(/^\//, "");
        }

        return decodeURIComponent(path).replace(/\/+$/, "");
    }

    var NotFound = Frp.page(function (app) {
        Frp.Page.call(this, app);
    }, {
        title: function () { return "Not found · FRP Mapper"; },
        render: function () {
            return html`<div class="px-6 py-10 lg:px-10">
    <h1 class="font-display text-3xl font-bold text-ink">Page not found</h1>
    <p class="mt-3 max-w-prose text-base leading-7 text-muted">There is nothing at this address.</p>
    <a class="mt-6 inline-flex h-10 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover" href="">
        <i class="ph ph-arrow-left"></i> Back to projects
    </a>
</div>`;
        }
    });

    var Denied = Frp.page(function (app) {
        Frp.Page.call(this, app);
    }, {
        title: function () { return "Access · FRP Mapper"; },
        render: function () { return C.accessDenied(); }
    });

    var app = {
        page: null,
        path: "",

        /** Opens the screen of a URL (in this application). */
        open: function (url, focusHeading) {
            if (this.page) {
                this.page.close();
            }

            var path = localPath(url);
            var query = url.searchParams;
            this.path = path;
            var page = null;
            for (var i = 0; i < Frp.routes.length && !page; i++) {
                var route = Frp.routes[i];
                var match = route.pattern.exec(path);
                if (match) {
                    // A route's permission is one key, or a list of keys of which the person needs any one.
                    var allowed = !route.permission || (Array.isArray(route.permission) ? route.permission.some(function (p) { return Frp.can(p); }) : Frp.can(route.permission));
                    page = !allowed ? new Denied(this) : route.create(this, match, query);
                }
            }

            this.page = page || new NotFound(this);
            window.scrollTo(0, 0);
            this.draw(this.page);
            if (focusHeading) {
                // As Blazor's FocusOnNavigate: screen readers start at the new page's heading.
                var heading = root.querySelector("h1");
                if (heading) {
                    heading.setAttribute("tabindex", "-1");
                    heading.focus({ preventScroll: true });
                }
            }

            var current = this.page;
            current.init().catch(function (error) {
                showError(error);
            }).then(function () {
                if (current === app.page) {
                    current.update();
                }
            });
        },

        /** Draws the layout and the page (patching what is already on screen). */
        draw: function (page) {
            if (page !== this.page) {
                return;
            }

            page.handlers = [];
            var content = page.render();
            document.title = page.title();
            Frp.morph(root, html`<div class="min-h-screen bg-canvas lg:grid lg:grid-cols-[248px_minmax(0,1fr)] print:block print:bg-white">
    ${C.navMenu(this.path)}
    <main class="min-w-0">${content}</main>
</div>`);
        },

        navigate: function (href, replace) {
            var url = new URL(href, document.baseURI);
            if (replace) {
                history.replaceState(null, "", url.href);
            } else {
                history.pushState(null, "", url.href);
            }

            this.open(url, !replace);
        }
    };

    Frp.app = app;

    // ---------- events: one listener per kind, calling the handler named in the element's data attribute ----------

    function dispatch(kind) {
        root.addEventListener(kind, function (event) {
            var page = app.page;
            var element = event.target.closest ? event.target.closest("[data-" + kind + "]") : null;
            if (!element || !page || !root.contains(element)) {
                return;
            }

            var handler = page.handlers[Number(element.getAttribute("data-" + kind))];
            if (!handler) {
                return;
            }

            if (kind === "submit") {
                event.preventDefault();
            }

            try {
                var result = handler(event, element);
                if (result && typeof result.catch === "function") {
                    result.catch(showError);
                }
            } catch (error) {
                showError(error);
            }
        }, kind === "submit" || kind === "click" ? false : false);
    }

    ["click", "input", "change", "submit", "keydown"].forEach(dispatch);

    // Links inside the application open their screen without reloading the page; downloads and other sites load normally.
    root.addEventListener("click", function (event) {
        if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
            return;
        }

        var link = event.target.closest ? event.target.closest("a[href]") : null;
        if (!link || link.getAttribute("data-native") || link.target || link.hasAttribute("download")) {
            return;
        }

        var url = new URL(link.getAttribute("href"), document.baseURI);
        if (url.origin !== location.origin || url.pathname.indexOf(basePath) !== 0) {
            return;
        }

        var path = localPath(url);
        if (path.indexOf("download/") === 0 || path.indexOf("account/") === 0 || /\.aspx$/i.test(path)) {
            // Downloads, sign-out and the ASP.NET pages (Pages/*.aspx) load from the server.
            return;
        }

        event.preventDefault();
        app.navigate(url.href);
    });

    window.addEventListener("popstate", function () {
        app.open(new URL(location.href), true);
    });

    // ---------- unexpected errors: a bar at the bottom, as the Blazor version showed ----------


    /** A failed action: the API's message, or (an unexpected error) a prompt to reload, in a toast. */
    function showError(error) {
        if (window.console) {
            console.error(error);
        }

        if (error instanceof Frp.ApiError) {
            if (!error.signedOut) {
                Frp.toast("Error", null, error.message);
            }

            return;
        }

        Frp.toast("Error", "Something went wrong", "Reload the page to continue.", {
            action: { label: "Reload", run: function () { location.reload(); } }
        });
    }

    window.addEventListener("error", function (event) {
        showError(event.error || event.message);
    });
    window.addEventListener("unhandledrejection", function (event) {
        showError(event.reason);
    });

    // ---------- idle timeout (Application Security Checklist: sessions end after 15 minutes of inactivity) ----------
    // While the person uses the mouse or keyboard the page tells the server it is still in use; after Session:IdleMinutes
    // without activity it signs the person out. One minute before, it shows a warning.
    (function () {
        var idleMinutes = Number(document.body.getAttribute("data-idle-minutes"));
        if (!(idleMinutes > 0)) {
            return;
        }

        var idleMs = idleMinutes * 60000;
        var warnMs = Math.min(60000, idleMs / 2);
        var pingEveryMs = Math.min(60000, idleMs / 3);
        var lastActivity = Date.now();
        var lastPing = Date.now();
        var ended = false;
        var warning = null;

        function hideWarning() {
            if (warning) {
                warning.close();
                warning = null;
            }
        }

        /** A toast that counts down; any activity closes it. */
        function showWarning(seconds) {
            var text = "You will be signed out in " + seconds + " seconds because of inactivity. Move the mouse or press a key to stay signed in.";
            if (!warning) {
                warning = window.Frp.toast("Warning", "Still there?", text, { sticky: true });
            } else {
                warning.setMessage(text);
            }
        }

        function signOut() {
            ended = true;
            var form = document.getElementById("frp-signout");
            if (form) {
                var reason = form.querySelector("input[name=reason]");
                if (reason) {
                    reason.value = "idle";
                }

                form.submit();
            } else {
                // Windows sign-in has no sign-out: reload, which asks Windows again.
                window.location.reload();
            }
        }

        function onActivity() {
            if (!ended) {
                lastActivity = Date.now();
                hideWarning();
            }
        }

        ["mousemove", "mousedown", "keydown", "wheel", "scroll", "touchstart"].forEach(function (name) {
            window.addEventListener(name, onActivity, { passive: true, capture: true });
        });

        window.setInterval(function () {
            if (ended) {
                return;
            }

            var now = Date.now();
            var idle = now - lastActivity;
            if (idle >= idleMs) {
                hideWarning();
                signOut();
                return;
            }

            if (idle >= idleMs - warnMs) {
                showWarning(Math.max(1, Math.ceil((idleMs - idle) / 1000)));
            }

            if (lastActivity > lastPing && now - lastPing >= pingEveryMs) {
                lastPing = now;
                fetch("account/keepalive", { credentials: "same-origin", cache: "no-store", redirect: "follow" })
                    .then(function (response) {
                        // The sign-in ended on the server (e.g. signed in elsewhere): show the sign-in page.
                        if (response.redirected || response.status === 401 || response.status === 403) {
                            ended = true;
                            window.location.reload();
                        }
                    })
                    .catch(function () { /* offline for a moment: try again at the next activity */ });
            }
        }, 1000);
    })();

    app.open(new URL(location.href), false);
})();
