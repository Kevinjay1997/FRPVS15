// Audit trail, Roles & access, Access administration and Reports.
(function () {
    "use strict";

    var Frp = window.Frp;
    var html = Frp.html;
    var C = Frp.components;
    var P = Frp.Permissions;

    // ---------- Audit trail ----------

    var Audit = Frp.page(function (app) {
        Frp.Page.call(this, app);
        this.list = new C.PagedList(this, "audit/page", "frp.auditPageSize");
    }, {
        title: function () { return "Audit trail · FRP Mapper"; },

        init: function () {
            return this.list.load();
        },

        render: function () {
            var self = this;
            var list = self.list;
            var data = list.data;
            var body;
            if (!data && list.error) {
                body = html`<div class="mt-8">${C.notice("Error", "The audit trail could not be loaded", list.error)}</div>`;
            } else if (!data) {
                body = C.pageLoading("Loading the audit trail");
            } else if (list.empty()) {
                body = html`<div class="mt-8">${C.emptyState("Nothing recorded yet",
                    "Entries appear here as soon as a Maker creates a project. Each project’s History tab shows the same entries for that project.",
                    "img/workspace-history.png",
                    "An approved project: who prepared and approved it, the XSD and BSP rule results, and the file's SHA-256 fingerprint.",
                    "An approved project records who prepared it, who approved it, and the exact file released.")}</div>`;
            } else {
                body = html`<div class="mt-8">${list.filters(self.on.bind(self))}</div>
        ${list.error ? html`<div class="mt-4">${C.notice("Error", null, list.error)}</div>` : ""}
        ${list.pager(self.on.bind(self))}
        <div class="mt-3 overflow-x-auto rounded-app border border-line bg-surface transition-opacity ${list.loading ? "opacity-60" : ""}"${Frp.raw(list.loading ? " aria-busy=\"true\"" : "")}>
            <table class="w-full min-w-[1100px] text-left text-sm">
                <thead class="border-b border-line text-xs text-subtle">
                    <tr>
                        <th class="px-5 py-3 font-semibold">When</th>
                        <th class="px-5 py-3 font-semibold">Who</th>
                        <th class="px-5 py-3 font-semibold">From address</th>
                        <th class="px-5 py-3 font-semibold">Action</th>
                        <th class="px-5 py-3 font-semibold">Project</th>
                        <th class="px-5 py-3 font-semibold">Details</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.entries.map(function (entry) {
                        return html`<tr class="border-b border-line align-top transition last:border-0 hover:bg-canvas" data-key="${entry.id}">
                        <td class="whitespace-nowrap px-5 py-3 text-muted">${Frp.date(entry.at, true, true)}</td>
                        <td class="whitespace-nowrap px-5 py-3 text-ink">${entry.user}</td>
                        <td class="whitespace-nowrap px-5 py-3 font-mono text-xs text-muted">${entry.address || "—"}</td>
                        <td class="px-5 py-3">
                            <span class="inline-flex items-center gap-2 whitespace-nowrap font-medium text-ink"><span class="h-2 w-2 shrink-0 rounded-full ${C.historyDot(entry.action)}"></span>${entry.action}</span>
                        </td>
                        <td class="px-5 py-3">
                            ${entry.projectId ? html`<a class="whitespace-nowrap font-medium text-accent hover:underline" href="${"projects/" + entry.projectId}">${entry.projectName}</a>` : ""}
                        </td>
                        <td class="px-5 py-3 text-muted"><span class="line-clamp-2 max-w-[60ch] break-all" title="${entry.details || ""}">${entry.details}</span></td>
                    </tr>`;
                    })}
                </tbody>
            </table>
            ${!data.entries.length ? html`<p class="px-5 py-8 text-sm text-subtle">No entries match.</p>` : ""}
        </div>
        ${data.total > data.pageSize ? list.pager(self.on.bind(self)) : ""}`;
            }

            return html`<div class="px-6 py-8 lg:px-10 lg:py-10">
    <header class="border-b border-line pb-8">
        <h1 class="font-display text-3xl font-bold tracking-tight text-ink">Audit trail</h1>
        <p class="mt-2 max-w-prose text-base leading-7 text-muted">
            Who created, changed, submitted, reviewed and released each project, and every refused action.
            The trail is append-only; the application never changes or deletes an entry.
        </p>
    </header>
    ${body}
</div>`;
        }
    });

    // ---------- Roles & access ----------

    var Access = Frp.page(function (app) {
        Frp.Page.call(this, app);
    }, {
        title: function () { return "Roles & access · FRP Mapper"; },

        render: function () {
            var session = Frp.session;
            var user = session.user;
            var roles = user.roles;
            var catalog = session.catalog;
            var modeText = session.mode === "Windows" ? "Signed in with Windows. Your roles come from your Active Directory groups."
                : session.mode === "ActiveDirectory" ? "Signed in with your Active Directory account. Your roles come from the groups you were in when you signed in; sign out and in again after a group change."
                : "Development sign-in with a test user. Production uses Active Directory accounts and groups.";
            var body;
            if (!catalog) {
                body = html`<div class="mt-10 max-w-3xl">${C.notice("Error", "Roles and permissions could not be loaded", "The FRP Mapper API cannot be reached, so the roles and permissions cannot be shown.")}</div>`;
            } else if (!catalog.roles.length || !catalog.permissions.length) {
                body = html`<div class="mt-10 max-w-3xl">${C.notice("Warning", "No roles or permissions are set up",
                    "The database has no active roles or permissions. Add them to frp.AppRole, frp.AppPermission and frp.RolePermission.")}</div>`;
            } else {
                var granted = {};
                catalog.grants.forEach(function (g) { granted[g.roleKey + "\u001f" + g.permissionKey] = true; });
                body = html`<section class="mt-10">
            <h2 class="font-display text-xl font-bold text-ink">Who can do what</h2>
            <p class="mt-1 max-w-prose text-sm leading-6 text-muted">From the database (frp.RolePermission); the API enforces exactly these grants.</p>
            <div class="mt-5 overflow-x-auto rounded-app border border-line bg-surface">
                <table class="w-full min-w-[720px] text-left text-sm">
                    <thead class="border-b border-line text-xs text-subtle">
                        <tr>
                            <th class="px-5 py-3 font-semibold">Action</th>
                            ${catalog.roles.map(function (role) {
                                return html`<th class="px-5 py-3 text-center font-semibold ${roles.indexOf(role.key) >= 0 ? "text-accent" : ""}" title="${role.description || ""}">${role.displayName}</th>`;
                            })}
                        </tr>
                    </thead>
                    <tbody>
                        ${catalog.permissions.map(function (permission) {
                            return html`<tr class="border-b border-line transition last:border-0 hover:bg-canvas">
                            <td class="px-5 py-3 text-ink">${permission.displayName}</td>
                            ${catalog.roles.map(function (role) {
                                return html`<td class="px-5 py-3 text-center">${granted[role.key + "\u001f" + permission.key]
                                    ? html`<i class="ph ph-check text-emerald-700" aria-label="Allowed"></i>`
                                    : html`<span class="text-subtle" aria-label="Not allowed">—</span>`}</td>`;
                            })}
                        </tr>`;
                        })}
                    </tbody>
                </table>
            </div>
            <p class="mt-3 max-w-prose text-sm leading-6 text-muted">
                A person may hold several roles. They can then prepare some projects and review others,
                but never review a project they created, edited, attached a file to or submitted.
            </p>
        </section>
        ${Frp.can(P.AccessView) || !roles.length ? html`<section class="mt-10">
            <h2 class="font-display text-xl font-bold text-ink">Active Directory groups</h2>
            <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                Membership of these groups grants each role (database table <code>frp.RoleDirectoryGroup</code>).
            </p>
            ${C.roleGroupList(catalog.roles)}
        </section>` : ""}`;
            }

            return html`<div class="px-6 py-8 lg:px-10 lg:py-10">
    <header class="border-b border-line pb-8">
        <h1 class="font-display text-3xl font-bold tracking-tight text-ink">Roles &amp; access</h1>
        <p class="mt-2 max-w-prose text-base leading-7 text-muted">
            Segregation of duties: the person who prepares a submission can never be the person who approves it.
            The API enforces these rules on every request, not only this screen.
        </p>
    </header>
    <section class="mt-8 max-w-3xl rounded-app border border-line bg-surface p-6">
        <p class="text-sm text-subtle">Signed in as</p>
        <p class="mt-1 font-display text-xl font-bold text-ink">${user.name}</p>
        <div class="mt-3 flex flex-wrap gap-2">
            ${user.accessUnavailable ? html`<span class="rounded-app border border-red-200 bg-red-50 px-2 py-0.5 text-xs font-semibold text-red-800">Roles could not be checked</span>`
                : !roles.length ? html`<span class="rounded-app border border-amber-200 bg-amber-50 px-2 py-0.5 text-xs font-semibold text-amber-800">No role</span>` : ""}
            ${roles.map(function (role) { return html`<span class="rounded-app border border-accent-line bg-accent-soft px-2 py-0.5 text-xs font-semibold text-accent">${role}</span>`; })}
        </div>
        <p class="mt-4 text-sm text-muted">${modeText}</p>
    </section>
    ${body}
</div>`;
        }
    });

    // ---------- Access administration ----------

    var inputClass = "mt-1.5 block w-full rounded-app border border-line bg-surface px-3 h-10 text-sm font-normal outline-none transition hover:border-slate-300 focus:border-accent disabled:bg-canvas disabled:text-muted";
    var primaryButton = "inline-flex h-9 items-center gap-1.5 rounded-app bg-accent px-3 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50";
    var secondaryButton = "inline-flex h-9 items-center gap-1.5 rounded-app border border-line bg-surface px-3 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:opacity-50";
    var dangerButton = "inline-flex h-9 items-center gap-1.5 rounded-app bg-red-700 px-3 text-sm font-semibold text-white transition hover:bg-red-800 disabled:opacity-50";

    var Teams = {
        name: function (team) { return team === "Users" ? "SRAU" : "PARAM"; },
        withArticle: function (team) { return team === "Users" ? "an SRAU" : "a PARAM"; }
    };

    var AccessAdmin = Frp.page(function (app) {
        Frp.Page.call(this, app);
        var self = this;
        self.userName = Frp.session.user.name;
        self.myRoles = Frp.session.user.roles;
        self.usersMaker = Frp.can(P.UsersManage);
        self.usersChecker = Frp.can(P.UsersApprove);
        self.rolesMaker = Frp.can(P.RolesManage);
        self.rolesChecker = Frp.can(P.RolesApprove);
        self.canUsers = self.usersMaker || self.usersChecker;
        self.canRoles = self.rolesMaker || self.rolesChecker;
        self.myDuty = self.usersMaker ? "SRAU Maker" : self.usersChecker ? "SRAU Checker" : self.rolesMaker ? "PARAM Maker" : self.rolesChecker ? "PARAM Checker" : null;
        self.tab = self.canUsers ? "User" : self.canRoles ? "Role" : "Groups";
        self.state = null;
        self.loadError = null;
        self.confirmDelete = null;
        self.busy = false;
        self.message = null;
        self.messageKind = "Success";
        self.deciding = null;
        self.decisionComment = "";
        self.userForm = null;
        self.roleForm = null;
        self.groupsForm = null;
        self.activityFor = null;
        self.activity = null;
        self.activityError = null;
        self.conflicts = {};
    }, {
        title: function () { return "Access administration · FRP Mapper"; },

        init: function () {
            return this.canUsers || this.canRoles ? this.load() : Promise.resolve();
        },

        load: function () {
            var self = this;
            return Frp.api.get("admin/access").then(function (state) {
                self.state = state;
                self.loadError = null;
            }, function (error) {
                self.loadError = error instanceof Frp.ApiError && !error.unreachable ? error.message : "The FRP Mapper API did not respond. Reload the page.";
            });
        },

        tabs: function () {
            var tabs = [];
            if (this.canUsers) {
                tabs.push({ kind: "User", label: "People (SRAU)" });
            }

            if (this.canRoles) {
                tabs.push({ kind: "Role", label: "Roles (PARAM)" });
            }

            tabs.push({ kind: "Groups", label: "AD groups" });
            return tabs;
        },

        switchTo: function (kind) {
            this.tab = kind;
            this.userForm = null;
            this.roleForm = null;
            this.groupsForm = null;
            this.confirmDelete = null;
            this.activityFor = null;
            this.activity = null;
            this.deciding = null;
            this.message = null;
            this.update();
        },

        /** The Checker of the requester's team decides (the API checks this again). */
        canDecide: function (request) {
            return request.team === "Users" ? this.usersChecker : this.rolesChecker;
        },

        holdsRole: function (key) {
            return this.myRoles.some(function (r) { return r.toLowerCase() === key.toLowerCase(); });
        },

        isSelfTarget: function (request) {
            return request.kind === "User" ? Frp.sameName(request.targetKey, this.userName) : this.holdsRole(request.targetKey);
        },

        /** Why these permissions cannot be held together (the shared C# rule, asked from the Platform), or null. */
        conflict: function (permissions) {
            var self = this;
            var key = permissions.slice().sort().join(",");
            if (!(key in self.conflicts)) {
                self.conflicts[key] = null;
                Frp.api.util("access-conflict", { permissions: permissions }).then(function (answer) {
                    self.conflicts[key] = answer.conflict || null;
                    self.update();
                }, function () { /* only a hint; the API checks again */ });
            }

            return self.conflicts[key];
        },

        run: function (action) {
            var self = this;
            self.busy = true;
            self.message = null;
            self.update();
            return action().then(function (done) {
                return self.load().then(function () {
                    Frp.toast("Success", null, done);
                });
            }, function (error) {
                Frp.toast("Error", "Not done", error instanceof Frp.ApiError && !error.unreachable ? error.message : "The FRP Mapper API did not respond. Try again.");
            }).then(function () {
                self.busy = false;
                self.update();
            });
        },

        decide: function (request, decision) {
            var self = this;
            var questions = {
                approve: { title: "Approve this request?", message: request.summary + " It applies within a minute.", confirmLabel: "Approve" },
                reject: { title: "Reject this request?", message: request.summary, confirmLabel: "Reject", danger: true },
                cancel: { title: "Cancel your request?", message: request.summary, confirmLabel: "Cancel request", cancelLabel: "Keep it", danger: true }
            };
            return Frp.confirm(questions[decision]).then(function (yes) {
                return yes ? self.sendDecision(request, decision) : undefined;
            });
        },

        sendDecision: function (request, decision) {
            var self = this;
            return self.run(function () {
                return Frp.api.post("admin/access/requests/" + encodeURIComponent(request.id) + "/" + decision, { version: request.version, comment: self.decisionComment || null })
                    .catch(function (error) {
                        if (error instanceof Frp.ApiError && error.status === 404) {
                            throw new Frp.ApiError(404, "The request is no longer waiting for a decision. Reload the page.");
                        }

                        throw error;
                    }).then(function () {
                        self.deciding = null;
                        self.decisionComment = "";
                        return decision === "approve" ? "Approved: " + request.targetKey + ". It applies within a minute (people may need to sign in again)."
                            : decision === "reject" ? "Rejected: " + request.targetKey + "."
                            : "Cancelled your request for " + request.targetKey + ".";
                    });
            });
        },

        showActivity: function (account) {
            var self = this;
            self.activityFor = account;
            self.activity = null;
            self.activityError = null;
            self.update();
            return Frp.api.get("admin/access/activity", { user: account }).then(function (activity) {
                self.activity = activity;
            }, function (error) {
                self.activityError = error instanceof Frp.ApiError && !error.unreachable ? error.message : "The FRP Mapper API did not respond. Try again.";
            }).then(function () { self.update(); });
        },

        render: function () {
            var self = this;
            var state = self.state;
            var body;
            if (!self.canUsers && !self.canRoles) {
                body = html`<div class="mt-8 max-w-3xl">${C.notice("Warning", "Not available to your role", "Only the SRAU and PARAM teams can open access administration.")}</div>`;
            } else if (self.loadError) {
                body = html`<div class="mt-8 max-w-3xl">${C.notice("Error", "Access administration could not be loaded", self.loadError)}</div>`;
            } else if (!state) {
                body = C.pageLoading("Loading access administration", { classes: "mt-8 max-w-5xl" });
            } else {
                var pending = state.requests.filter(function (r) { return r.kind === self.tab && r.status === "Pending"; });
                var decided = state.requests.filter(function (r) { return r.kind === self.tab && r.status !== "Pending"; }).slice(0, 20);
                body = html`<div class="mt-8 flex flex-wrap gap-1" role="tablist" aria-label="Section">
            ${self.tabs().map(function (tab) {
                var waiting = state.requests.filter(function (r) { return r.kind === tab.kind && r.status === "Pending"; }).length;
                return html`<button role="tab" aria-selected="${self.tab === tab.kind ? "true" : "false"}" class="inline-flex h-9 items-center rounded-app px-3 text-sm font-medium transition ${self.tab === tab.kind ? "bg-ink text-white" : "text-muted hover:bg-surface hover:text-ink"}"
                    data-click="${self.on(function () { self.switchTo(tab.kind); })}">
                ${tab.label}
                ${waiting > 0 ? html`<span class="ml-2 rounded-app bg-amber-100 px-1.5 text-xs font-semibold text-amber-900">${waiting}</span>` : ""}
            </button>`;
            })}
        </div>
        ${self.renderPending(pending)}
        ${self.tab === "User" ? self.renderPeople(pending) : self.tab === "Groups" ? self.renderGroups(pending) : self.renderRoles(pending)}
        ${decided.length ? html`<section class="mt-10" aria-labelledby="decided-title">
            <h2 id="decided-title" class="font-display text-xl font-bold text-ink">Recent decisions</h2>
            <ul class="mt-4 divide-y divide-line rounded-app border border-line bg-surface">
                ${decided.map(function (request) {
                    return html`<li class="px-5 py-3 text-sm" data-key="${request.id}">
                    <span class="font-semibold ${request.status === "Approved" ? "text-emerald-700" : "text-muted"}">${request.status}</span>
                    <span class="font-mono text-ink"> ${request.targetKey}</span> — ${request.summary}
                    <span class="block text-xs text-subtle">Requested by ${request.requestedBy}; ${request.status.toLowerCase()} by ${request.decidedBy}
                        ${Frp.date(request.decidedAt, true)}${request.decisionComment ? " · “" + request.decisionComment + "”" : ""}</span>
                </li>`;
                })}
            </ul>
        </section>` : ""}`;
            }

            return html`<div class="px-6 py-8 lg:px-10 lg:py-10">
    <header class="border-b border-line pb-8">
        <p class="text-sm font-semibold text-accent">Administration${self.myDuty ? " · " + self.myDuty : ""}</p>
        <h1 class="mt-1 font-display text-3xl font-bold tracking-tight text-ink">Access administration</h1>
        <p class="mt-2 max-w-prose text-base leading-7 text-muted">
            SRAU creates, changes and deletes people and the roles they hold, and sees their activity; PARAM creates, changes
            and deletes roles and their permissions; both can
            change which Active Directory groups grant a role. In each team the Maker requests a change and the Checker
            approves or rejects it, and nobody can change their own access.
        </p>
    </header>
    ${body}
</div>`;
        },

        renderPending: function (pending) {
            var self = this;
            var subject = { User: "Person", Groups: "AD groups of role" };
            return html`<section class="mt-8" aria-labelledby="pending-title">
    <h2 id="pending-title" class="font-display text-xl font-bold text-ink">Waiting for approval</h2>
    ${!pending.length ? html`<p class="mt-2 text-sm text-muted">Nothing is waiting for approval.</p>` : html`<ul class="mt-4 space-y-3">
        ${pending.map(function (request) {
            var mine = Frp.sameName(request.requestedBy, self.userName);
            var actions;
            if (mine) {
                actions = html`<span class="text-xs text-muted">${Frp.capital(Teams.withArticle(request.team))} Checker must approve your request.</span>
                    <button class="${secondaryButton}"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () { return self.decide(request, "cancel"); })}">Cancel request</button>`;
            } else if (!self.canDecide(request)) {
                actions = html`<span class="text-xs text-muted">Waiting for ${Teams.withArticle(request.team)} Checker.</span>`;
            } else if (self.isSelfTarget(request)) {
                actions = html`<span class="text-xs text-muted">This changes your own access: another Checker must decide.</span>`;
            } else if (self.deciding === request.id) {
                actions = html`<label class="sr-only" for="${"comment-" + request.id}">Comment</label>
                    <input autocomplete="off" id="${"comment-" + request.id}" class="h-9 w-64 rounded-app border border-line bg-surface px-3 text-sm outline-none focus:border-accent"
                           placeholder="Comment (required to reject)" maxlength="1000" value="${self.decisionComment}" data-input="${self.on(function (e) { self.decisionComment = e.target.value; })}" />
                    <button class="${primaryButton}"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () { return self.decide(request, "approve"); })}"><i class="ph ph-check"></i> Approve</button>
                    <button class="${dangerButton}"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () { return self.decide(request, "reject"); })}"><i class="ph ph-x"></i> Reject</button>
                    <button class="text-sm font-semibold text-muted hover:text-ink"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () { self.deciding = null; self.update(); })}">Close</button>`;
            } else {
                actions = html`<button class="${primaryButton}" data-click="${self.on(function () { self.deciding = request.id; self.decisionComment = ""; self.update(); })}">Review</button>`;
            }

            return html`<li class="rounded-app border border-amber-200 bg-amber-50/60 p-5" data-key="${request.id}">
            <div class="flex flex-wrap items-start justify-between gap-4">
                <div class="min-w-0">
                    <p class="font-semibold text-ink">${subject[request.kind] || "Role"} <span class="font-mono">${request.targetKey}</span></p>
                    <p class="mt-1 text-sm leading-6 text-ink">${request.summary}</p>
                    <p class="mt-1 text-xs text-subtle">Requested by ${request.requestedBy} (${Teams.name(request.team)}) · ${Frp.date(request.requestedAt, true)}</p>
                </div>
                <div class="flex shrink-0 flex-wrap items-center gap-2">${actions}</div>
            </div>
        </li>`;
        })}
    </ul>`}
</section>`;
        },

        renderPeople: function (pending) {
            var self = this;
            var state = self.state;
            var form = self.userForm;
            var today = Frp.today();

            function disabledReason(reason) {
                return reason === "Locked" ? "Locked: too many failed sign-ins in a row"
                    : reason === "Dormant" ? "Deactivated: not signed in within the inactivity period" : null;
            }

            var formMarkup = "";
            if (form) {
                var held = state.roles.filter(function (r) { return r.isActive && form.roles.indexOf(r.key) >= 0; });
                var permissions = [];
                held.forEach(function (r) { r.permissions.forEach(function (p) { if (permissions.indexOf(p) < 0) { permissions.push(p); } }); });
                var conflict = form.isActive ? self.conflict(permissions) : null;
                formMarkup = html`<div class="mt-5 max-w-3xl rounded-app border border-accent-line bg-surface p-6">
            <h3 class="font-semibold text-ink">${form.isNew ? "Add a person" : "Change " + form.userName}</h3>
            <div class="mt-4 grid gap-4 sm:grid-cols-2">
                <label class="block text-sm font-semibold text-ink">Active Directory account
                    <input class="${inputClass}" value="${form.userName}"${Frp.attr("disabled", !form.isNew)} maxlength="256" placeholder="CORP\\jdelacruz" autocomplete="off"
                           data-input="${self.on(function (e) { form.userName = e.target.value; })}" />
                </label>
                <label class="block text-sm font-semibold text-ink">Display name <span class="font-normal text-subtle">(optional)</span>
                    <input autocomplete="off" class="${inputClass}" value="${form.displayName}" maxlength="200" data-input="${self.on(function (e) { form.displayName = e.target.value; })}" />
                </label>
                <label class="block text-sm font-semibold text-ink">Branch / department <span class="font-normal text-subtle">(optional)</span>
                    <input autocomplete="off" class="${inputClass}" value="${form.department}" maxlength="100" data-input="${self.on(function (e) { form.department = e.target.value; })}" />
                </label>
                <label class="block text-sm font-semibold text-ink">Access until <span class="font-normal text-subtle">(last day; empty = no end)</span>
                    <input autocomplete="off" type="date" class="${inputClass}" value="${form.accessUntil}" data-change="${self.on(function (e) { form.accessUntil = e.target.value; })}" />
                </label>
            </div>
            <fieldset class="mt-5">
                <legend class="text-sm font-semibold text-ink">Roles</legend>
                <div class="mt-2 grid gap-2 sm:grid-cols-2">
                    ${state.roles.filter(function (r) { return r.isActive || form.roles.indexOf(r.key) >= 0; }).map(function (role) {
                        return html`<label class="flex items-start gap-2 rounded-app border border-line px-3 py-2 text-sm" title="${role.description || ""}">
                        <input type="checkbox" class="mt-1 h-4 w-4 accent-[#1d4ed8]"${Frp.attr("checked", form.roles.indexOf(role.key) >= 0)}
                               data-change="${self.on(function (e) {
                                   if (e.target.checked) { if (form.roles.indexOf(role.key) < 0) { form.roles.push(role.key); } } else { form.roles = form.roles.filter(function (k) { return k !== role.key; }); }
                                   self.update();
                               })}" />
                        <span><span class="font-semibold text-ink">${role.displayName}</span>${role.isActive ? "" : " (disabled)"}
                            <span class="block text-xs text-subtle">${role.permissions.length} permission(s)</span></span>
                    </label>`;
                    })}
                </div>
            </fieldset>
            <label class="mt-4 inline-flex items-center gap-2 text-sm text-ink">
                <input type="checkbox" class="h-4 w-4 accent-[#1d4ed8]"${Frp.attr("checked", form.isActive)} data-change="${self.on(function (e) { form.isActive = e.target.checked; self.update(); })}" /> Active (unticked: the person has no access at all)
            </label>
            ${conflict ? html`<div class="mt-4">${C.notice("Warning", "These roles cannot be held together", conflict)}</div>` : ""}
            <div class="mt-5 flex flex-wrap gap-2">
                <button class="${primaryButton}"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () {
                    return self.run(function () {
                        return Frp.api.post("admin/access/users", {
                            userName: form.userName, displayName: form.displayName || null, isActive: form.isActive, roles: form.roles,
                            department: form.department || null, accessUntil: form.accessUntil || null
                        }).then(function (request) {
                            self.userForm = null;
                            return "Sent for approval: " + request.summary + " An SRAU Checker must approve it.";
                        });
                    });
                })}"><i class="ph ph-paper-plane-tilt"></i> Submit for approval</button>
                <button class="${secondaryButton}"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () { self.userForm = null; self.update(); })}">Cancel</button>
            </div>
        </div>`;
            }

            function newForm(userName) {
                return { isNew: true, userName: userName || "", displayName: "", department: "", accessUntil: "", isActive: true, roles: [] };
            }

            var activity = "";
            if (self.activityFor) {
                var a = self.activity;
                activity = html`<section class="mt-8 rounded-app border border-accent-line bg-surface p-6" aria-labelledby="activity-title">
            <div class="flex flex-wrap items-start justify-between gap-3">
                <div>
                    <h3 id="activity-title" class="font-semibold text-ink">Activity of <span class="font-mono">${self.activityFor}</span></h3>
                    ${a ? html`<p class="mt-1 text-sm text-muted">Last sign-in: ${a.lastSignInAt ? Frp.date(a.lastSignInAt, true) : "never"}</p>` : ""}
                </div>
                <button class="text-sm font-semibold text-muted hover:text-ink" data-click="${self.on(function () { self.activityFor = null; self.activity = null; self.update(); })}">Close</button>
            </div>
            ${self.activityError ? html`<div class="mt-4">${C.notice("Error", null, self.activityError)}</div>`
                : !a ? C.pageLoading("Loading the activity", { classes: "mt-4", compact: true })
                : html`${a.accessChanges.length ? html`<h4 class="mt-5 text-sm font-semibold text-ink">Access changes</h4>
                <ul class="mt-2 space-y-1 text-sm">
                    ${a.accessChanges.map(function (change) {
                        return html`<li><span class="font-semibold">${change.status}</span> · ${change.summary}
                        <span class="text-xs text-subtle">(requested by ${change.requestedBy}${change.decidedBy ? ", " + change.status.toLowerCase() + " by " + change.decidedBy : ""})</span></li>`;
                    })}
                </ul>` : ""}
                <h4 class="mt-5 text-sm font-semibold text-ink">What they did (latest ${a.entries.length})</h4>
                ${!a.entries.length ? html`<p class="mt-2 text-sm text-muted">Nothing recorded yet.</p>` : html`<div class="mt-2 max-h-96 overflow-auto rounded-app border border-line">
                    <table class="w-full min-w-[640px] text-left text-sm">
                        <thead class="sticky top-0 border-b border-line bg-surface text-xs font-semibold text-subtle">
                            <tr><th class="px-4 py-2">When</th><th class="px-4 py-2">Action</th><th class="px-4 py-2">From address</th><th class="px-4 py-2">Project</th><th class="px-4 py-2">Details</th></tr>
                        </thead>
                        <tbody>
                            ${a.entries.map(function (entry) {
                                var bad = Frp.containsText(entry.action, "failed") || Frp.containsText(entry.action, "refused");
                                return html`<tr class="border-b border-line align-top last:border-0" data-key="${entry.id}">
                                <td class="whitespace-nowrap px-4 py-2 text-xs text-muted">${Frp.date(entry.at, true)}</td>
                                <td class="px-4 py-2 ${bad ? "text-red-700" : "text-ink"}">${entry.action}</td>
                                <td class="whitespace-nowrap px-4 py-2 font-mono text-xs text-muted">${entry.address || "—"}</td>
                                <td class="px-4 py-2 text-xs text-muted">${entry.projectName || "—"}</td>
                                <td class="px-4 py-2 text-xs text-muted">${entry.details}</td>
                            </tr>`;
                            })}
                        </tbody>
                    </table>
                </div>`}`}
        </section>`;
            }

            return html`<section class="mt-10" aria-labelledby="people-title">
    <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
            <h2 id="people-title" class="font-display text-xl font-bold text-ink">People</h2>
            <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                Roles given here are added to those a person's Active Directory groups give. A disabled person has no access at all.
            </p>
        </div>
        ${!form && self.usersMaker ? html`<button class="${primaryButton}" data-click="${self.on(function () { self.userForm = newForm(); self.message = null; self.update(); })}"><i class="ph ph-user-plus"></i> Add person</button>` : ""}
    </div>
    ${formMarkup}
    <div class="mt-5 overflow-x-auto rounded-app border border-line bg-surface">
        <table class="w-full min-w-[760px] text-left text-sm">
            <thead class="border-b border-line text-xs font-semibold text-subtle">
                <tr><th class="px-5 py-3">Account</th><th class="px-5 py-3">Roles given in the app</th><th class="px-5 py-3">Branch / department</th><th class="px-5 py-3">Status</th><th class="px-5 py-3">Last sign-in</th><th class="px-5 py-3">Last change</th><th class="px-5 py-3"><span class="sr-only">Actions</span></th></tr>
            </thead>
            <tbody>
                ${!state.users.length ? html`<tr><td colspan="7" class="px-5 py-6 text-muted">No one has been added yet. People still get the roles of their Active Directory groups.</td></tr>` : ""}
                ${state.users.map(function (person) {
                    var open = pending.some(function (r) { return Frp.sameName(r.targetKey, person.userName); });
                    var target = "user:" + person.userName;
                    var why = !person.isActive ? disabledReason(person.disabledReason) : null;
                    var actions;
                    if (Frp.sameName(person.userName, self.userName)) {
                        actions = html`<span class="ml-2 text-xs text-subtle">Your own access</span>`;
                    } else if (!open && self.usersMaker) {
                        actions = html`<button class="${secondaryButton}" data-click="${self.on(function () {
                                self.userForm = { isNew: false, userName: person.userName, displayName: person.displayName || "", department: person.department || "",
                                    accessUntil: person.accessUntil || "", isActive: person.isActive, roles: person.roles.slice() };
                                self.message = null;
                                self.update();
                            })}">Change</button>
                            <button class="${secondaryButton}"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () {
                                return Frp.confirm({
                                    title: "Delete " + person.userName + " from the list?",
                                    message: "This sends a request: an SRAU Checker must approve it. Their AD group roles still apply.",
                                    confirmLabel: "Request deletion",
                                    danger: true
                                }).then(function (yes) {
                                    return !yes ? undefined : self.run(function () {
                                        return Frp.api.post("admin/access/users", { userName: person.userName, delete: true }).then(function (request) {
                                            return "Sent for approval: " + request.summary + " An SRAU Checker must approve it.";
                                        });
                                    });
                                });
                            })}"><i class="ph ph-trash"></i> Delete</button>`;
                    } else {
                        actions = "";
                    }

                    return html`<tr class="border-b border-line last:border-0" data-key="${person.userName}">
                    <td class="px-5 py-3"><span class="font-mono text-ink">${person.userName}</span>
                        ${person.displayName ? html`<span class="block text-xs text-subtle">${person.displayName}</span>` : ""}</td>
                    <td class="px-5 py-3">${person.roles.length ? person.roles.join(", ") : "—"}</td>
                    <td class="px-5 py-3 text-xs text-muted">${person.department || "—"}</td>
                    <td class="px-5 py-3">
                        ${person.isActive ? html`<span class="text-emerald-700">Active</span>` : html`<span class="text-red-700">Disabled</span>`}
                        ${why ? html`<span class="block text-xs text-red-700">${why}</span>` : ""}
                        ${person.accessUntil ? html`<span class="block text-xs ${person.accessUntil < today ? "text-red-700" : "text-subtle"}">${person.accessUntil < today ? "Access ended" : "Access until"} ${Frp.day(person.accessUntil)}</span>` : ""}
                        ${open ? html`<span class="ml-2 rounded-app bg-amber-100 px-1.5 py-0.5 text-xs text-amber-900">Change waiting</span>` : ""}
                    </td>
                    <td class="px-5 py-3 text-xs text-muted">${person.lastSignInAt ? Frp.date(person.lastSignInAt, true) : "Never"}</td>
                    <td class="px-5 py-3 text-xs text-subtle">${Frp.date(person.updatedAtUtc, true)} ${person.updatedBy ? "· " + person.updatedBy : ""}</td>
                    <td class="whitespace-nowrap px-5 py-3 text-right">
                        <button class="${secondaryButton}" data-click="${self.on(function () { return self.showActivity(person.userName); })}">Activity</button>
                        ${actions}
                    </td>
                </tr>`;
                })}
            </tbody>
        </table>
    </div>
    ${state.otherSignIns.length ? html`<h3 class="mt-8 font-semibold text-ink">Signed in but not in the list above</h3>
    <p class="mt-1 max-w-prose text-sm leading-6 text-muted">Their password was accepted; their roles (if any) come only from their Active Directory groups. Add one to give roles in the app or to disable them.</p>
    <div class="mt-3 overflow-x-auto rounded-app border border-line bg-surface">
        <table class="w-full min-w-[560px] text-left text-sm">
            <thead class="border-b border-line text-xs font-semibold text-subtle">
                <tr><th class="px-5 py-3">Account</th><th class="px-5 py-3">Last sign-in</th><th class="px-5 py-3"><span class="sr-only">Actions</span></th></tr>
            </thead>
            <tbody>
                ${state.otherSignIns.map(function (seen) {
                    return html`<tr class="border-b border-line last:border-0" data-key="${seen.userName}">
                    <td class="px-5 py-3 font-mono text-ink">${seen.userName}</td>
                    <td class="px-5 py-3 text-xs text-muted">${Frp.date(seen.lastSignInAt, true)}</td>
                    <td class="whitespace-nowrap px-5 py-3 text-right">
                        <button class="${secondaryButton}" data-click="${self.on(function () { return self.showActivity(seen.userName); })}">Activity</button>
                        ${!Frp.sameName(seen.userName, self.userName) && !form && self.usersMaker ? html`<button class="${secondaryButton}" data-click="${self.on(function () { self.userForm = newForm(seen.userName); self.message = null; self.update(); })}">Add to the list</button>` : ""}
                    </td>
                </tr>`;
                })}
            </tbody>
        </table>
    </div>` : ""}
    ${activity}
</section>`;
        },

        renderGroups: function (pending) {
            var self = this;
            var form = self.groupsForm;
            return html`<section class="mt-10" aria-labelledby="groups-title">
    <h2 id="groups-title" class="font-display text-xl font-bold text-ink">Active Directory groups</h2>
    <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
        Members of a role's groups hold that role when they sign in. The SRAU Maker or the PARAM Maker requests a change;
        the Checker of the same team approves it. You cannot change the groups of a role you hold.
    </p>
    ${form ? html`<div class="mt-5 max-w-3xl rounded-app border border-accent-line bg-surface p-6">
        <h3 class="font-semibold text-ink">AD groups of role ${form.roleKey}</h3>
        <label class="mt-4 block text-sm font-semibold text-ink">Groups <span class="font-normal text-subtle">(one per line, e.g. CORP\\FRP-Makers)</span>
            <textarea autocomplete="off" class="${inputClass} h-32 py-2 font-mono" data-input="${self.on(function (e) { form.groups = e.target.value; })}">${form.groups}</textarea>
        </label>
        <div class="mt-5 flex flex-wrap gap-2">
            <button class="${primaryButton}"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () {
                return self.run(function () {
                    var groups = form.groups.split("\n").map(function (g) { return g.trim(); }).filter(function (g) { return g.length > 0; });
                    return Frp.api.post("admin/access/groups", { roleKey: form.roleKey, directoryGroups: groups }).then(function (request) {
                        self.groupsForm = null;
                        return "Sent for approval: " + request.summary + " " + Frp.capital(Teams.withArticle(request.team)) + " Checker must approve it.";
                    });
                });
            })}"><i class="ph ph-paper-plane-tilt"></i> Submit for approval</button>
            <button class="${secondaryButton}"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () { self.groupsForm = null; self.update(); })}">Cancel</button>
        </div>
    </div>` : ""}
    <div class="mt-5 overflow-x-auto rounded-app border border-line bg-surface">
        <table class="w-full min-w-[640px] text-left text-sm">
            <thead class="border-b border-line text-xs font-semibold text-subtle">
                <tr><th class="px-5 py-3">Role</th><th class="px-5 py-3">Active Directory groups</th><th class="px-5 py-3"><span class="sr-only">Actions</span></th></tr>
            </thead>
            <tbody>
                ${self.state.roles.filter(function (r) { return r.isActive; }).map(function (role) {
                    var open = pending.some(function (r) { return Frp.sameName(r.targetKey, role.key); });
                    return html`<tr class="border-b border-line align-top last:border-0" data-key="${role.key}">
                    <td class="px-5 py-3"><span class="font-semibold text-ink">${role.displayName}</span><span class="block font-mono text-xs text-subtle">${role.key}</span></td>
                    <td class="px-5 py-3 font-mono text-xs leading-5 text-muted">${role.directoryGroups.length ? role.directoryGroups.join(", ") : "—"}
                        ${open ? html`<span class="mt-1 block w-fit rounded-app bg-amber-100 px-1.5 py-0.5 font-body text-xs text-amber-900">Change waiting</span>` : ""}</td>
                    <td class="px-5 py-3 text-right">
                        ${self.holdsRole(role.key) ? html`<span class="text-xs text-subtle">You hold this role</span>`
                            : !open && !form && (self.usersMaker || self.rolesMaker) ? html`<button class="${secondaryButton}" data-click="${self.on(function () {
                                self.groupsForm = { roleKey: role.key, groups: role.directoryGroups.join("\n") };
                                self.message = null;
                                self.update();
                            })}">Change groups</button>` : ""}
                    </td>
                </tr>`;
                })}
            </tbody>
        </table>
    </div>
</section>`;
        },

        renderRoles: function (pending) {
            var self = this;
            var state = self.state;
            var form = self.roleForm;
            var formMarkup = "";
            if (form) {
                var conflict = self.conflict(form.permissions);
                formMarkup = html`<div class="mt-5 max-w-4xl rounded-app border border-accent-line bg-surface p-6">
        <h3 class="font-semibold text-ink">${form.isNew ? "New role" : "Change role " + form.key}</h3>
        <div class="mt-4 grid gap-4 sm:grid-cols-2">
            <label class="block text-sm font-semibold text-ink">Key
                <input class="${inputClass}" value="${form.key}"${Frp.attr("disabled", !form.isNew)} maxlength="50" placeholder="Viewer" autocomplete="off" data-input="${self.on(function (e) { form.key = e.target.value; })}" />
            </label>
            <label class="block text-sm font-semibold text-ink">Name
                <input autocomplete="off" class="${inputClass}" value="${form.displayName}" maxlength="100" data-input="${self.on(function (e) { form.displayName = e.target.value; })}" />
            </label>
        </div>
        <label class="mt-4 block text-sm font-semibold text-ink">Description <span class="font-normal text-subtle">(optional)</span>
            <textarea autocomplete="off" class="${inputClass} h-20 py-2" maxlength="500" data-input="${self.on(function (e) { form.description = e.target.value; })}">${form.description}</textarea>
        </label>
        <fieldset class="mt-5">
            <legend class="text-sm font-semibold text-ink">Permissions</legend>
            <div class="mt-2 grid gap-2 md:grid-cols-2">
                ${state.permissions.map(function (permission) {
                    return html`<label class="flex items-start gap-2 rounded-app border border-line px-3 py-2 text-sm">
                    <input type="checkbox" class="mt-1 h-4 w-4 accent-[#1d4ed8]"${Frp.attr("checked", form.permissions.indexOf(permission.key) >= 0)}
                           data-change="${self.on(function (e) {
                               if (e.target.checked) { if (form.permissions.indexOf(permission.key) < 0) { form.permissions.push(permission.key); } } else { form.permissions = form.permissions.filter(function (k) { return k !== permission.key; }); }
                               self.update();
                           })}" />
                    <span><span class="text-ink">${permission.displayName}</span><span class="block font-mono text-xs text-subtle">${permission.key}</span></span>
                </label>`;
                })}
            </div>
        </fieldset>
        ${conflict ? html`<div class="mt-4">${C.notice("Warning", "These permissions cannot be held together", conflict)}</div>` : ""}
        <label class="mt-4 inline-flex items-center gap-2 text-sm text-ink">
            <input type="checkbox" class="h-4 w-4 accent-[#1d4ed8]"${Frp.attr("checked", form.isActive)} data-change="${self.on(function (e) { form.isActive = e.target.checked; })}" /> Active (unticked: nobody gets this role)
        </label>
        <div class="mt-5 flex flex-wrap gap-2">
            <button class="${primaryButton}"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () {
                return self.run(function () {
                    return Frp.api.post("admin/access/roles", {
                        key: form.key, displayName: form.displayName, description: form.description || null, isActive: form.isActive, permissions: form.permissions
                    }).then(function (request) {
                        self.roleForm = null;
                        return "Sent for approval: " + request.summary + " A PARAM Checker must approve it.";
                    });
                });
            })}"><i class="ph ph-paper-plane-tilt"></i> Submit for approval</button>
            <button class="${secondaryButton}"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () { self.roleForm = null; self.update(); })}">Cancel</button>
        </div>
    </div>`;
            }

            return html`<section class="mt-10" aria-labelledby="roles-title">
    <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
            <h2 id="roles-title" class="font-display text-xl font-bold text-ink">Roles</h2>
            <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                A role's permissions decide what its holders can do. Which AD groups grant it is on the AD groups tab.
                You cannot change a role you hold.
            </p>
        </div>
        ${!form && self.rolesMaker ? html`<button class="${primaryButton}" data-click="${self.on(function () {
            self.roleForm = { isNew: true, key: "", displayName: "", description: "", isActive: true, permissions: [] };
            self.message = null;
            self.update();
        })}"><i class="ph ph-plus"></i> New role</button>` : ""}
    </div>
    ${formMarkup}
    <div class="mt-5 overflow-x-auto rounded-app border border-line bg-surface">
        <table class="w-full min-w-[760px] text-left text-sm">
            <thead class="border-b border-line text-xs font-semibold text-subtle">
                <tr><th class="px-5 py-3">Role</th><th class="px-5 py-3">Permissions</th><th class="px-5 py-3">Active Directory groups</th><th class="px-5 py-3">Status</th><th class="px-5 py-3"><span class="sr-only">Actions</span></th></tr>
            </thead>
            <tbody>
                ${state.roles.map(function (role) {
                    var open = pending.some(function (r) { return Frp.sameName(r.targetKey, role.key); });
                    var target = "role:" + role.key;
                    var actions;
                    if (self.holdsRole(role.key)) {
                        actions = html`<span class="text-xs text-subtle">You hold this role</span>`;
                    } else if (!open && self.rolesMaker) {
                        actions = html`<span class="inline-flex gap-2">
                            <button class="${secondaryButton}" data-click="${self.on(function () {
                                self.roleForm = { isNew: false, key: role.key, displayName: role.displayName, description: role.description || "", isActive: role.isActive, permissions: role.permissions.slice() };
                                self.message = null;
                                self.update();
                            })}">Change</button>
                            <button class="${secondaryButton}"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () {
                                return Frp.confirm({
                                    title: "Delete the role " + role.displayName + "?",
                                    message: "This sends a request: a PARAM Checker must approve it.",
                                    confirmLabel: "Request deletion",
                                    danger: true
                                }).then(function (yes) {
                                    return !yes ? undefined : self.run(function () {
                                        return Frp.api.post("admin/access/roles", { key: role.key, delete: true }).then(function (request) {
                                            return "Sent for approval: " + request.summary + " A PARAM Checker must approve it.";
                                        });
                                    });
                                });
                            })}"><i class="ph ph-trash"></i> Delete</button>
                        </span>`;
                    } else {
                        actions = "";
                    }

                    return html`<tr class="border-b border-line align-top last:border-0" data-key="${role.key}">
                    <td class="px-5 py-3"><span class="font-semibold text-ink">${role.displayName}</span><span class="block font-mono text-xs text-subtle">${role.key}</span></td>
                    <td class="px-5 py-3 text-xs leading-5 text-muted">${role.permissions.length ? role.permissions.join(", ") : "—"}</td>
                    <td class="px-5 py-3 font-mono text-xs leading-5 text-muted">${role.directoryGroups.length ? role.directoryGroups.join(", ") : "—"}</td>
                    <td class="px-5 py-3">
                        ${role.isActive ? html`<span class="text-emerald-700">Active</span>` : html`<span class="text-red-700">Disabled</span>`}
                        ${open ? html`<span class="mt-1 block w-fit rounded-app bg-amber-100 px-1.5 py-0.5 text-xs text-amber-900">Change waiting</span>` : ""}
                    </td>
                    <td class="px-5 py-3 text-right">${actions}</td>
                </tr>`;
                })}
            </tbody>
        </table>
    </div>
</section>`;
        }
    });

    // ---------- Reports ----------

    var reportInput = "mt-1 block h-9 rounded-app border border-line bg-surface px-3 text-sm font-normal outline-none focus:border-accent";
    var reportPrimary = "inline-flex h-9 items-center gap-1.5 rounded-app bg-accent px-3 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50";
    var reportSecondary = "inline-flex h-9 items-center gap-1.5 rounded-app border border-line bg-surface px-3 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent";

    var Reports = Frp.page(function (app) {
        Frp.Page.call(this, app);
        var srau = Frp.can(P.UsersManage) || Frp.can(P.UsersApprove);
        var param = Frp.can(P.RolesManage) || Frp.can(P.RolesApprove);
        var bank = Frp.can(P.ReferenceManage) || Frp.can(P.ReferenceApprove);
        this.tabs = [];
        if (srau) { this.tabs.push({ key: "user-maintenance", label: "User maintenance" }); }
        if (srau || param || bank) { this.tabs.push({ key: "parameter-maintenance", label: "Parameter maintenance" }); }
        if (srau) { this.tabs.push({ key: "users", label: "User extraction" }); }
        if (srau) { this.tabs.push({ key: "sign-ins", label: "Sign-in attempts" }); }
        this.tab = this.tabs.length ? this.tabs[0].key : "";
        this.from = Frp.today();
        this.to = Frp.today();
        this.account = "";
        this.clearFilters();
        this.maintenance = null;
        this.users = null;
        this.signIns = null;
        this.busy = false;
        this.error = null;
    }, {
        title: function () { return "Reports · FRP Mapper"; },

        clearFilters: function () {
            this.category = "";
            this.field = "";
            this.status = "";
            this.search = "";
        },

        filtered: function () {
            return !!(this.category || this.field || this.status || this.search.trim());
        },

        filterText: function () {
            return [
                this.category ? "category " + this.category : null,
                this.field ? "field " + this.field : null,
                this.status ? "status " + this.status : null,
                this.search.trim() ? "ID or name contains “" + this.search.trim() + "”" : null
            ].filter(function (x) { return x; }).join(", ");
        },

        generate: function () {
            var self = this;
            self.busy = true;
            self.error = null;
            self.maintenance = null;
            self.users = null;
            self.signIns = null;
            self.update();
            var call;
            switch (self.tab) {
                case "user-maintenance":
                case "parameter-maintenance":
                    call = Frp.api.get("reports/" + self.tab, { from: self.from, to: self.to }).then(function (report) { self.maintenance = report; });
                    break;
                case "users":
                    call = Frp.api.get("reports/users").then(function (report) { self.users = report; });
                    break;
                default:
                    call = Frp.api.get("reports/sign-ins", { from: self.from, to: self.to, user: self.account || "" }).then(function (report) { self.signIns = report; });
                    break;
            }

            return call.catch(function (error) {
                Frp.toast("Error", "The report was not generated", error instanceof Frp.ApiError && !error.unreachable ? error.message : "The FRP Mapper API did not respond. Try again.");
            }).then(function () {
                self.busy = false;
                self.update();
            });
        },

        hasResult: function () {
            return !this.busy && (this.tab === "users" ? !!this.users : this.tab === "sign-ins" ? !!this.signIns : !!this.maintenance);
        },

        render: function () {
            var self = this;
            if (!self.tabs.length) {
                return html`<div class="px-6 py-8 lg:px-10 lg:py-10 print:p-0">${self.header()}
    <div class="mt-8 max-w-3xl">${C.notice("Warning", "Not available to your role", "Your roles do not include any report.")}</div></div>`;
            }

            function when(at) {
                return at ? Frp.date(at, true) : "—";
            }

            function textInput(value, assign, extra) {
                return html`<input autocomplete="off" class="${reportInput}" value="${value}"${extra || ""} data-input="${self.on(function (e) { assign(e.target.value); self.update(); })}" />`;
            }

            function select(value, assign, options) {
                return html`<select autocomplete="off" class="${reportInput}" data-change="${self.on(function (e) { assign(e.target.value); self.update(); })}">${options.map(function (o) {
                    return html`<option value="${o.value}"${Frp.attr("selected", o.value === value)}>${o.label}</option>`;
                })}</select>`;
            }

            function distinctSorted(items) {
                return items.filter(function (x, i, all) { return all.indexOf(x) === i; }).sort(function (a, b) { return a < b ? -1 : a > b ? 1 : 0; });
            }

            var result = "";
            if (!self.busy && self.maintenance && (self.tab === "user-maintenance" || self.tab === "parameter-maintenance")) {
                var report = self.maintenance;
                var users = self.tab === "user-maintenance";
                var text = self.search.trim();
                var rows = report.rows.filter(function (r) {
                    return (!self.category || r.category === self.category) && (!self.field || r.field === self.field) && (!self.status || r.status === self.status)
                        && (!text || Frp.containsText(r.targetId, text) || Frp.containsText(r.targetName, text));
                });
                result = html`<section class="mt-6" aria-labelledby="report-title">
            <h2 id="report-title" class="font-display text-xl font-bold text-ink">${users ? "User maintenance" : "Parameter maintenance"}</h2>
            <p class="mt-1 text-sm text-muted">${Frp.day(report.from)} to ${Frp.day(report.to)} · generated by ${report.generatedBy} on ${Frp.date(report.generatedAt, true)} · ${rows.length} of ${report.rows.length} row(s)${self.filtered() ? " · filtered: " + self.filterText() : ""}</p>
            <div class="mt-4 flex flex-wrap items-end gap-3 print:hidden">
                ${report.categories.length > 1 ? html`<label class="text-sm font-semibold text-ink">Category${select(self.category, function (v) { self.category = v; },
                    [{ value: "", label: "All" }].concat(report.categories.map(function (c) { return { value: c, label: c }; })))}</label>` : ""}
                <label class="text-sm font-semibold text-ink">Field${select(self.field, function (v) { self.field = v; },
                    [{ value: "", label: "All fields" }].concat(distinctSorted(report.rows.map(function (r) { return r.field; })).map(function (f) { return { value: f, label: f }; })))}</label>
                <label class="text-sm font-semibold text-ink">Status${select(self.status, function (v) { self.status = v; },
                    [{ value: "", label: "All" }, { value: "Approved", label: "Approved" }, { value: "Rejected", label: "Rejected" }, { value: "Cancelled", label: "Cancelled" }])}</label>
                <label class="text-sm font-semibold text-ink">ID or name${textInput(self.search, function (v) { self.search = v; })}</label>
            </div>
            <div class="mt-4 overflow-x-auto rounded-app border border-line bg-surface print:overflow-visible print:border-0">
                <table class="w-full min-w-[1200px] text-left text-xs print:min-w-0">
                    <thead class="border-b border-line font-semibold text-subtle">
                        <tr>
                            ${!users ? html`<th class="px-3 py-2">Category</th>` : ""}
                            <th class="px-3 py-2">${users ? "User ID" : "Group / profile ID"}</th><th class="px-3 py-2">Name</th><th class="px-3 py-2">Date created</th><th class="px-3 py-2">Last modified</th>
                            <th class="px-3 py-2">Field</th><th class="px-3 py-2">Original value</th><th class="px-3 py-2">New value</th><th class="px-3 py-2">Status</th>
                            <th class="px-3 py-2">Processed by (Maker)</th><th class="px-3 py-2">Approved by (Checker)</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${!rows.length ? html`<tr><td colspan="11" class="px-3 py-6 text-sm text-muted">No changes were processed in this range${self.filtered() ? " that match the filters" : ""}.</td></tr>` : ""}
                        ${rows.map(function (row) {
                            return html`<tr class="border-b border-line align-top last:border-0">
                            ${!users ? html`<td class="px-3 py-2">${row.category}</td>` : ""}
                            <td class="px-3 py-2 font-mono text-ink">${row.targetId}</td>
                            <td class="px-3 py-2">${row.targetName || "—"}</td>
                            <td class="whitespace-nowrap px-3 py-2">${when(row.createdAt)}</td>
                            <td class="whitespace-nowrap px-3 py-2">${when(row.lastModifiedAt)}</td>
                            <td class="px-3 py-2 font-semibold text-ink">${row.field}</td>
                            <td class="px-3 py-2 text-muted">${row.before}</td>
                            <td class="px-3 py-2 text-ink">${row.after}</td>
                            <td class="px-3 py-2">${row.status}${row.comment ? " · “" + row.comment + "”" : ""}</td>
                            <td class="px-3 py-2">${row.maker}<span class="block text-subtle">${when(row.requestedAt)}</span></td>
                            <td class="px-3 py-2">${row.approver || "—"}<span class="block text-subtle">${when(row.decidedAt)}</span></td>
                        </tr>`;
                        })}
                    </tbody>
                </table>
            </div>
        </section>`;
            }

            if (!self.busy && self.users && self.tab === "users") {
                var search = self.search.trim();
                var accounts = self.users.rows.filter(function (r) {
                    return (!search || Frp.containsText(r.userId, search) || Frp.containsText(r.userName, search)) && (!self.status || r.status.indexOf(self.status) === 0);
                });
                result = html`<section class="mt-6" aria-labelledby="users-title">
            <h2 id="users-title" class="font-display text-xl font-bold text-ink">User extraction</h2>
            <p class="mt-1 text-sm text-muted">Generated by ${self.users.generatedBy} on ${Frp.date(self.users.generatedAt, true)} · ${accounts.length} of ${self.users.rows.length} account(s)${self.filtered() ? " · filtered: " + self.filterText() : ""}</p>
            <div class="mt-4 flex flex-wrap items-end gap-3 print:hidden">
                <label class="text-sm font-semibold text-ink">Status${select(self.status, function (v) { self.status = v; },
                    [{ value: "", label: "All" }].concat(distinctSorted(self.users.rows.map(function (r) { return r.status; })).map(function (s) { return { value: s, label: s }; })))}</label>
                <label class="text-sm font-semibold text-ink">ID or name${textInput(self.search, function (v) { self.search = v; })}</label>
            </div>
            <div class="mt-4 overflow-x-auto rounded-app border border-line bg-surface print:overflow-visible print:border-0">
                <table class="w-full min-w-[1100px] text-left text-xs print:min-w-0">
                    <thead class="border-b border-line font-semibold text-subtle">
                        <tr><th class="px-3 py-2">User ID</th><th class="px-3 py-2">User name</th><th class="px-3 py-2">Profile / group access</th><th class="px-3 py-2">Branch / department</th>
                            <th class="px-3 py-2">Date created</th><th class="px-3 py-2">Account status</th><th class="px-3 py-2">Last modified</th><th class="px-3 py-2">Expiration date</th><th class="px-3 py-2">Last login</th><th class="px-3 py-2">Source</th></tr>
                    </thead>
                    <tbody>
                        ${!accounts.length ? html`<tr><td colspan="10" class="px-3 py-6 text-sm text-muted">No accounts match.</td></tr>` : ""}
                        ${accounts.map(function (row) {
                            return html`<tr class="border-b border-line align-top last:border-0">
                            <td class="px-3 py-2 font-mono text-ink">${row.userId}</td>
                            <td class="px-3 py-2">${row.userName || "—"}</td>
                            <td class="px-3 py-2">${row.roles}</td>
                            <td class="px-3 py-2">${row.department || "—"}</td>
                            <td class="whitespace-nowrap px-3 py-2">${when(row.createdAt)}</td>
                            <td class="px-3 py-2">${row.status}</td>
                            <td class="whitespace-nowrap px-3 py-2">${when(row.lastModifiedAt)}</td>
                            <td class="whitespace-nowrap px-3 py-2">${row.accessUntil ? Frp.day(row.accessUntil) : "No end"}</td>
                            <td class="whitespace-nowrap px-3 py-2">${when(row.lastSignInAt)}</td>
                            <td class="px-3 py-2 text-subtle">${row.source}</td>
                        </tr>`;
                        })}
                    </tbody>
                </table>
            </div>
        </section>`;
            }

            if (!self.busy && self.signIns && self.tab === "sign-ins") {
                var signIns = self.signIns;
                result = html`<section class="mt-6" aria-labelledby="signins-title">
            <h2 id="signins-title" class="font-display text-xl font-bold text-ink">Sign-in attempts</h2>
            <p class="mt-1 text-sm text-muted">${Frp.day(signIns.from)} to ${Frp.day(signIns.to)} · generated by ${signIns.generatedBy} on ${Frp.date(signIns.generatedAt, true)} · ${signIns.entries.length} attempt(s)</p>
            ${signIns.truncated ? html`<div class="mt-3 max-w-3xl">${C.notice("Warning", null, "Only the newest " + signIns.entries.length + " attempts are shown. Narrow the range or choose an account.")}</div>` : ""}
            <h3 class="mt-5 font-semibold text-ink">By account</h3>
            <div class="mt-2 overflow-x-auto rounded-app border border-line bg-surface print:overflow-visible print:border-0">
                <table class="w-full min-w-[900px] text-left text-xs print:min-w-0">
                    <thead class="border-b border-line font-semibold text-subtle">
                        <tr><th class="px-3 py-2">Account</th><th class="px-3 py-2">Signed in</th><th class="px-3 py-2">Failed</th><th class="px-3 py-2">Blocked / delayed</th><th class="px-3 py-2">Refused</th><th class="px-3 py-2">Locked / deactivated</th><th class="px-3 py-2">Last failure</th><th class="px-3 py-2">Failed from</th></tr>
                    </thead>
                    <tbody>
                        ${!signIns.summary.length ? html`<tr><td colspan="8" class="px-3 py-6 text-sm text-muted">No sign-in attempts in this range.</td></tr>` : ""}
                        ${signIns.summary.map(function (s) {
                            return html`<tr class="border-b border-line last:border-0 ${s.failed + s.blocked + s.locked > 0 ? "bg-amber-50/60" : ""}">
                            <td class="px-3 py-2 font-mono text-ink">${s.userName}</td><td class="px-3 py-2">${s.signedIn}</td><td class="px-3 py-2">${s.failed}</td><td class="px-3 py-2">${s.blocked}</td>
                            <td class="px-3 py-2">${s.refused}</td><td class="px-3 py-2">${s.locked}</td><td class="whitespace-nowrap px-3 py-2">${when(s.lastFailedAt)}</td><td class="px-3 py-2">${s.failedFrom.length ? s.failedFrom.join(", ") : "—"}</td>
                        </tr>`;
                        })}
                    </tbody>
                </table>
            </div>
            <h3 class="mt-6 font-semibold text-ink">All attempts</h3>
            <div class="mt-2 overflow-x-auto rounded-app border border-line bg-surface print:overflow-visible print:border-0">
                <table class="w-full min-w-[800px] text-left text-xs print:min-w-0">
                    <thead class="border-b border-line font-semibold text-subtle"><tr><th class="px-3 py-2">When</th><th class="px-3 py-2">Account</th><th class="px-3 py-2">From address</th><th class="px-3 py-2">Result</th><th class="px-3 py-2">Details</th></tr></thead>
                    <tbody>
                        ${signIns.entries.map(function (e) {
                            return html`<tr class="border-b border-line align-top last:border-0">
                            <td class="whitespace-nowrap px-3 py-2">${Frp.date(e.at, true, true)}</td>
                            <td class="px-3 py-2 font-mono">${e.user}</td>
                            <td class="whitespace-nowrap px-3 py-2 font-mono">${e.address || "—"}</td>
                            <td class="px-3 py-2 ${e.action === "Signed in" ? "text-emerald-700" : "text-red-700"}">${e.action}</td>
                            <td class="px-3 py-2 text-muted">${e.details}</td>
                        </tr>`;
                        })}
                    </tbody>
                </table>
            </div>
        </section>`;
            }

            return html`<div class="px-6 py-8 lg:px-10 lg:py-10 print:p-0">
    ${self.header()}
    <div class="mt-6 flex flex-wrap gap-1 print:hidden" role="tablist" aria-label="Report">
        ${self.tabs.map(function (tab) {
            return html`<button role="tab" aria-selected="${self.tab === tab.key ? "true" : "false"}" class="inline-flex h-9 items-center rounded-app px-3 text-sm font-medium transition ${self.tab === tab.key ? "bg-ink text-white" : "text-muted hover:bg-surface hover:text-ink"}"
                data-click="${self.on(function () {
                    self.tab = tab.key;
                    self.maintenance = null;
                    self.users = null;
                    self.signIns = null;
                    self.error = null;
                    self.clearFilters();
                    self.update();
                })}">${tab.label}</button>`;
        })}
    </div>
    <div class="mt-6 flex flex-wrap items-end gap-3 print:hidden">
        ${self.tab !== "users" ? html`<label class="text-sm font-semibold text-ink">From<input autocomplete="off" type="date" class="${reportInput}" value="${self.from}" data-change="${self.on(function (e) { self.from = e.target.value; })}" /></label>
            <label class="text-sm font-semibold text-ink">To<input autocomplete="off" type="date" class="${reportInput}" value="${self.to}" data-change="${self.on(function (e) { self.to = e.target.value; })}" /></label>` : ""}
        ${self.tab === "sign-ins" ? html`<label class="text-sm font-semibold text-ink">Account <span class="font-normal text-subtle">(optional)</span>${textInput(self.account, function (v) { self.account = v; }, Frp.raw(" maxlength=\"256\" placeholder=\"CORP\\name\""))}</label>` : ""}
        <button class="${reportPrimary}"${Frp.attr("disabled", self.busy)} data-click="${self.on(function () { return self.generate(); })}"><i class="ph ph-table"></i> Generate</button>
        ${self.hasResult() ? html`<button class="${reportSecondary}" data-click="${self.on(function () { window.print(); })}"><i class="ph ph-printer"></i> Print</button>` : ""}
    </div>
    ${self.busy ? C.pageLoading("Generating the report", { classes: "mt-6" }) : ""}
    ${result}
</div>`;
        },

        header: function () {
            return html`<header class="border-b border-line pb-6 print:pb-3">
        <h1 class="font-display text-3xl font-bold tracking-tight text-ink print:text-2xl">Reports</h1>
        <p class="mt-2 max-w-prose text-base leading-7 text-muted print:hidden">
            Maintenance of people and parameters with original and new values, the user extraction, and sign-in attempts.
            Choose a date range, filter the rows, and print. Every report you generate is recorded in the audit trail.
        </p>
    </header>`;
        }
    });

    Frp.routes.push({ pattern: /^audit$/, permission: P.AuditReadAll, create: function (app) { return new Audit(app); } });
    Frp.routes.push({ pattern: /^access$/, create: function (app) { return new Access(app); } });
    Frp.routes.push({ pattern: /^access-denied$/, create: function (app) { return new (Frp.page(function (a) { Frp.Page.call(this, a); }, { render: function () { return C.accessDenied(); } }))(app); } });
    Frp.routes.push({ pattern: /^admin\/access$/, create: function (app) { return new AccessAdmin(app); } });
    Frp.routes.push({ pattern: /^reports$/, create: function (app) { return new Reports(app); } });
})();
