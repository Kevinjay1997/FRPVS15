// Logs: the Workbench's "View Logs" for the server. The API's log files, newest first, for the people who may read the
// whole audit trail (audit.read-all). The API masks values that look like secrets before any line is sent.
(function () {
    "use strict";
    var F = window.Frp, html = F.html, C = F.components;

    var smallSecondary = "inline-flex h-9 items-center gap-1.5 rounded-app border border-line bg-surface px-3 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:opacity-50";
    var inputClass = "h-9 rounded-app border border-line bg-surface px-3 text-sm outline-none transition hover:border-slate-300 focus:border-accent";

    /** Error and Warning entries stand out; continuation lines (stack traces) are dimmed. */
    function lineClass(line) {
        if (/^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d{3} (Error|Critical)/.test(line)) return "text-red-700";
        if (/^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d{3} Warning/.test(line)) return "text-amber-800";
        if (/^\d{4}-\d\d-\d\d /.test(line)) return "text-ink";
        return "text-subtle";
    }

    var Logs = F.page(function (app) {
        F.Page.call(this, app);
        this.files = null; this.error = null;
        this.selected = null; this.content = null; this.loading = false;
        this.lines = 500; this.filter = ""; this.onlyProblems = false;
    }, {
        title: function () { return "Logs · FRP Mapper"; },

        init: function () {
            var self = this;
            return F.api.get("logs").then(function (list) {
                self.files = list.files;
                if (list.files.length) return self.open(list.files[0].name);
                return undefined;
            }, function (e) {
                self.error = F.messageOf(e);
            });
        },

        open: function (name) {
            var self = this;
            self.selected = name;
            self.loading = true;
            self.update();
            return F.api.get("logs/" + encodeURIComponent(name) + "?lines=" + self.lines).then(function (content) {
                self.content = content;
            }, function (e) {
                self.content = null;
                F.toast("Error", "The log was not read", F.messageOf(e));
            }).then(function () {
                self.loading = false;
                self.update();
            });
        },

        download: function () {
            var name = this.selected;
            return F.api.file("logs/" + encodeURIComponent(name) + "/download", null, { busy: "Downloading " + name }).then(function (file) {
                F.saveFile(file.name, file.blob);
            }, function (e) {
                F.toast("Error", "The log was not downloaded", F.messageOf(e));
            });
        },

        /** The lines shown: all, or only the Error / Warning entries with their stack traces; then the filter text. */
        shownLines: function () {
            var self = this, lines = self.content ? self.content.lines : [], shown = [], keep = false;
            lines.forEach(function (line) {
                if (/^\d{4}-\d\d-\d\d /.test(line)) keep = !self.onlyProblems || /^\S+ \S+ (Error|Critical|Warning)/.test(line);
                if (keep) shown.push(line);
            });
            var text = self.filter.trim().toLowerCase();
            return text ? shown.filter(function (line) { return line.toLowerCase().indexOf(text) >= 0; }) : shown;
        },

        render: function () {
            var self = this, content = self.content;
            var body;
            if (self.error) body = C.notice("Error", "The logs cannot be read", self.error);
            else if (!self.files) body = C.loading("py-10", "Loading the logs");
            else if (!self.files.length) body = C.notice("Info", "No log files", html`<p>The API writes no log file (Logging:FilePath is empty), or it has not written one yet.</p>`);
            else {
                var shown = self.shownLines();
                body = html`<div class="grid gap-6 xl:grid-cols-[16rem_minmax(0,1fr)]">
    <nav class="min-w-0" aria-label="Log files">
        <ul class="max-h-[32rem] divide-y divide-line/70 overflow-auto rounded-app border border-line bg-surface text-sm">
            ${self.files.map(function (file) {
                var active = file.name === self.selected;
                return html`<li><button type="button" class="flex w-full items-center justify-between gap-3 px-4 py-2.5 text-left transition ${active ? "bg-accent-soft text-accent" : "hover:bg-canvas"}"
                    ${active ? F.raw("aria-current=\"true\"") : ""} data-click="${self.on(function () { return self.open(file.name); })}">
                    <span class="truncate font-mono text-xs">${file.name}</span><span class="shrink-0 text-xs text-subtle">${F.size(file.size)}</span>
                </button></li>`;
            })}
        </ul>
    </nav>
    <section class="min-w-0 rounded-app border border-line bg-surface" aria-label="Log">
        <header class="flex flex-wrap items-center gap-3 border-b border-line px-4 py-3">
            <h2 class="mr-auto font-mono text-sm font-semibold text-ink">${self.selected}</h2>
            ${content ? html`<span class="text-xs text-muted">${F.n0(content.errors)} ${content.errors === 1 ? "error" : "errors"} · ${F.n0(content.warnings)} ${content.warnings === 1 ? "warning" : "warnings"}</span>` : ""}
            <label class="flex items-center gap-2 text-xs text-muted"><input type="checkbox" class="h-4 w-4 rounded border-line"${F.attr("checked", self.onlyProblems)}
                data-change="${self.on(function (e) { self.onlyProblems = e.target.checked; self.update(); })}" /> Errors and warnings only</label>
            <input class="${inputClass} w-44" type="search" placeholder="Filter" aria-label="Filter the lines" value="${self.filter}"
                   data-input="${self.on(function (e) { self.filter = e.target.value; self.update(); })}" />
            <select class="${inputClass}" aria-label="Lines" data-change="${self.on(function (e) { self.lines = parseInt(e.target.value, 10); return self.open(self.selected); })}">
                ${[200, 500, 2000, 5000].map(function (n) { return html`<option value="${n}"${F.attr("selected", self.lines === n)}>Last ${F.n0(n)} lines</option>`; })}
            </select>
            <button type="button" class="${smallSecondary}" data-click="${self.on(function () { return self.open(self.selected); })}"><i class="ph ph-arrow-clockwise" aria-hidden="true"></i> Refresh</button>
            <button type="button" class="${smallSecondary}" data-click="${self.on(function () { return self.download(); })}"><i class="ph ph-download-simple" aria-hidden="true"></i> Download</button>
        </header>
        ${self.loading ? C.loading("py-10", "Reading the log") : !content ? "" : html`
        ${content.truncated ? html`<p class="border-b border-line px-4 py-2 text-xs text-subtle">The last ${F.n0(content.lines.length)} lines; download the file for all of them.</p>` : ""}
        <pre class="relative max-h-[40rem] overflow-auto px-4 py-3 font-mono text-xs leading-5">${shown.length ? shown.map(function (line) {
            return html`<span class="block whitespace-pre-wrap break-all ${lineClass(line)}">${line}</span>`;
        }) : html`<span class="text-subtle">No line to show.</span>`}</pre>`}
    </section>
</div>`;
            }

            return html`<div class="px-6 py-8 lg:px-10 lg:py-10">
    <header class="border-b border-line pb-8">
        <h1 class="font-display text-3xl font-bold tracking-tight text-ink">Logs</h1>
        <p class="mt-2 max-w-prose text-base leading-7 text-muted">
            The API's log files, one per day: errors with their details, warnings and what the API did. Passwords, keys and tokens are
            masked. What people did is in the audit trail.
        </p>
    </header>
    <div class="mt-8">${body}</div>
</div>`;
        }
    });

    F.routes.push({ pattern: /^logs$/, permission: [F.Permissions.AuditReadAll], create: function (app) { return new Logs(app); } });
})();
