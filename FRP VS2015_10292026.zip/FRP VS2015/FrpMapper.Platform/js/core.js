// FRP Mapper Platform: the page's core. Every screen is a page object whose render() returns HTML (built with the html``
// template, which escapes every value); the app patches the page in place (morph), so typing, focus and scrolling are kept
// while the screen updates. Events are wired by data-click / data-input / data-change / data-submit / data-keydown
// attributes that name a handler of the current render (see Page.on).
(function () {
    "use strict";

    var Frp = window.Frp = window.Frp || {};

    // ---------- HTML ----------

    function Raw(text) {
        this.text = text;
    }

    Raw.prototype.toString = function () {
        return this.text;
    };

    var escapes = { "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" };

    function esc(value) {
        return value === null || value === undefined ? "" : String(value).replace(/[&<>"']/g, function (c) { return escapes[c]; });
    }

    function part(value) {
        if (value === null || value === undefined || value === false || value === true) {
            return "";
        }

        if (value instanceof Raw) {
            return value.text;
        }

        if (Array.isArray(value)) {
            return value.map(part).join("");
        }

        return esc(value);
    }

    /** html`<p>${text}</p>`: values are escaped (arrays joined, null/false/true left out); raw() and nested html`` are kept. */
    Frp.html = function (strings) {
        var out = strings[0];
        for (var i = 1; i < strings.length; i++) {
            out += part(arguments[i]) + strings[i];
        }

        return new Raw(out);
    };

    /** Markup that is already safe (never user data). */
    Frp.raw = function (text) {
        return new Raw(text);
    };

    Frp.esc = esc;

    /** An attribute that is present or not: ${Frp.attr("disabled", busy)}. */
    Frp.attr = function (name, on) {
        return new Raw(on ? " " + name : "");
    };

    // ---------- patching the page in place ----------

    function keyOf(node) {
        return node.nodeType === 1 ? node.getAttribute("data-key") : null;
    }

    function sameKind(a, b) {
        return a.nodeType === b.nodeType && (a.nodeType !== 1 || (a.tagName === b.tagName && (a.getAttribute("type") || "") === (b.getAttribute("type") || "")));
    }

    function morphAttributes(from, to) {
        var i;
        for (i = from.attributes.length - 1; i >= 0; i--) {
            var name = from.attributes[i].name;
            if (!to.hasAttribute(name)) {
                from.removeAttribute(name);
            }
        }

        for (i = 0; i < to.attributes.length; i++) {
            var attribute = to.attributes[i];
            if (from.getAttribute(attribute.name) !== attribute.value) {
                from.setAttribute(attribute.name, attribute.value);
            }
        }
    }

    function morphNode(from, to) {
        if (from.nodeType !== 1) {
            if (from.nodeValue !== to.nodeValue) {
                from.nodeValue = to.nodeValue;
            }

            return;
        }

        if (from.hasAttribute("data-morph-skip") && to.hasAttribute("data-morph-skip")) {
            return;
        }

        morphAttributes(from, to);
        var tag = from.tagName;
        var focused = from === document.activeElement;
        if (tag === "INPUT") {
            var type = (from.getAttribute("type") || "text").toLowerCase();
            if (type === "checkbox" || type === "radio") {
                from.checked = to.hasAttribute("checked");
            } else if (type !== "file" && !focused) {
                var value = to.getAttribute("value") || "";
                if (from.value !== value) {
                    from.value = value;
                }
            }

            return;
        }

        if (tag === "TEXTAREA") {
            if (!focused && from.value !== to.textContent) {
                from.value = to.textContent;
            }

            return;
        }

        morphChildren(from, to);
        if (tag === "SELECT") {
            var selected = to.querySelector("option[selected]");
            var wanted = selected ? (selected.hasAttribute("value") ? selected.getAttribute("value") : selected.textContent) : (from.options.length ? from.options[0].value : "");
            if (from.value !== wanted) {
                from.value = wanted;
            }
        }
    }

    function morphChildren(fromParent, toParent) {
        var keyed = {};
        var child;
        for (child = fromParent.firstChild; child; child = child.nextSibling) {
            var key = keyOf(child);
            if (key !== null) {
                keyed[key] = child;
            }
        }

        var current = fromParent.firstChild;
        var target = toParent.firstChild;
        while (target) {
            var next = target.nextSibling;
            var targetKey = keyOf(target);
            var match = null;
            if (targetKey !== null) {
                match = keyed[targetKey] || null;
                if (match && !sameKind(match, target)) {
                    match = null;
                }

                if (match) {
                    delete keyed[targetKey];
                }
            } else if (current && keyOf(current) === null && sameKind(current, target)) {
                match = current;
            }

            if (match) {
                if (match === current) {
                    current = current.nextSibling;
                } else {
                    fromParent.insertBefore(match, current);
                }

                morphNode(match, target);
            } else {
                fromParent.insertBefore(target, current);
            }

            target = next;
        }

        while (current) {
            var following = current.nextSibling;
            fromParent.removeChild(current);
            current = following;
        }
    }

    /** Makes the children of element look like the given markup, keeping the elements that stay. */
    Frp.morph = function (element, markup) {
        var template = document.createElement("template");
        template.innerHTML = String(markup);
        morphChildren(element, template.content);
    };

    // ---------- formatting (en-US, the person's local time, as the Blazor version showed it) ----------

    var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    function pad(n) {
        return n < 10 ? "0" + n : String(n);
    }

    /** "d MMM yyyy", "d MMM yyyy, HH:mm" or "d MMM yyyy, HH:mm:ss" in local time; "" when there is no date. */
    Frp.date = function (value, time, seconds) {
        if (!value) {
            return "";
        }

        var d = value instanceof Date ? value : new Date(value);
        if (isNaN(d.getTime())) {
            return "";
        }

        var text = d.getDate() + " " + months[d.getMonth()] + " " + d.getFullYear();
        if (time) {
            text += ", " + pad(d.getHours()) + ":" + pad(d.getMinutes()) + (seconds ? ":" + pad(d.getSeconds()) : "");
        }

        return text;
    };

    /** A date without a time (yyyy-MM-dd, e.g. a report's range) as "d MMM yyyy", without time zone conversion. */
    Frp.day = function (value) {
        var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(value || "");
        return m ? Number(m[3]) + " " + months[Number(m[2]) - 1] + " " + m[1] : "";
    };

    /** Today as yyyy-MM-dd (local date). */
    Frp.today = function () {
        var d = new Date();
        return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
    };

    var integers = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
    var twoDecimals = new Intl.NumberFormat("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    /** Like .NET's "N0": 12,345. */
    Frp.n0 = function (value) {
        return integers.format(Number(value || 0));
    };

    /** Like .NET's "N2": 12,345.60. */
    Frp.n2 = function (value) {
        return twoDecimals.format(Number(value || 0));
    };

    /** 1.2 MB, 340 KB, 12 B. */
    Frp.size = function (bytes) {
        if (bytes >= 1024 * 1024) {
            return (bytes / (1024 * 1024)).toFixed(1) + " MB";
        }

        if (bytes >= 1024) {
            return Math.round(bytes / 1024) + " KB";
        }

        return bytes + " B";
    };

    /** "CORP\jdoe" shows as "jdoe"; the full name is kept in the project's history. */
    Frp.shortName = function (name) {
        if (!name) {
            return "";
        }

        var slash = name.lastIndexOf("\\");
        return slash >= 0 ? name.substring(slash + 1) : name;
    };

    Frp.sameName = function (a, b) {
        return (a || "").trim().toLowerCase() === (b || "").trim().toLowerCase();
    };

    Frp.containsText = function (text, part) {
        return (text || "").toLowerCase().indexOf((part || "").toLowerCase()) >= 0;
    };

    Frp.capital = function (text) {
        return text ? text.charAt(0).toUpperCase() + text.substring(1) : text;
    };

    /** Elapsed time: "12 s" or "3 min 4 s". */
    Frp.elapsed = function (ms) {
        var seconds = Math.max(0, Math.floor(ms / 1000));
        return seconds >= 60 ? Math.floor(seconds / 60) + " min " + (seconds % 60) + " s" : seconds + " s";
    };

    // ---------- the signed-in person ----------

    var sessionElement = document.getElementById("frp-session");
    Frp.session = sessionElement ? JSON.parse(sessionElement.textContent) : { user: { roles: [], permissions: [] } };

    Frp.can = function (permission) {
        return Frp.session.user.permissions.indexOf(permission) >= 0;
    };

    Frp.Permissions = {
        ReferenceManage: "reference.manage",
        ReferenceApprove: "reference.approve",
        ProjectRead: "project.read",
        ProjectReadAll: "project.read-all",
        ProjectDelete: "project.delete",
        UsersManage: "users.manage",
        UsersApprove: "users.approve",
        RolesManage: "roles.manage",
        RolesApprove: "roles.approve",
        ProjectCreate: "project.create",
        ProjectEdit: "project.edit",
        SubmissionPrepare: "submission.prepare",
        SubmissionProduction: "submission.production",
        SubmissionWithdraw: "submission.withdraw",
        SubmissionReopen: "submission.reopen",
        SubmissionDownloadInReview: "submission.download-in-review",
        SubmissionReview: "submission.review",
        SubmissionDownloadApproved: "submission.download-approved",
        AuditReadAll: "audit.read-all",
        AccessView: "access.view"
    };

    Frp.Administration = ["users.manage", "users.approve", "roles.manage", "roles.approve"];

    // ---------- upload limits (the API's FileStorage settings) ----------

    Frp.UploadKinds = {
        Xsd: "Xsd",
        Template: "Template",
        Specification: "Specification",
        SubmissionXml: "SubmissionXml",
        XmlToValidate: "XmlToValidate",
        WorkbookToCheck: "WorkbookToCheck"
    };

    Frp.files = {
        settings: function () {
            return Frp.session.fileSettings || null;
        },
        extensionsFor: function (kind) {
            var settings = Frp.files.settings();
            return settings && settings.allowedExtensions && settings.allowedExtensions[kind] ? settings.allowedExtensions[kind] : [];
        },
        /** For an input's accept attribute, e.g. ".xlsx,.xlsm". */
        acceptFor: function (kind) {
            return Frp.files.extensionsFor(kind).join(",");
        },
        allows: function (kind, fileName) {
            var dot = fileName.lastIndexOf(".");
            var extension = dot >= 0 ? fileName.substring(dot).toLowerCase() : "";
            return Frp.files.extensionsFor(kind).some(function (e) { return e.toLowerCase() === extension; });
        },
        maxMegabytes: function () {
            var settings = Frp.files.settings();
            return settings ? Math.floor(settings.maxUploadBytes / (1024 * 1024)) : 0;
        },
        /** Why a chosen file cannot be used, or null. */
        problem: function (kind, file) {
            var settings = Frp.files.settings();
            if (!settings) {
                return "The upload settings could not be read from the FRP Mapper API.";
            }

            if (!Frp.files.allows(kind, file.name) || file.size > settings.maxUploadBytes) {
                return "Choose a " + Frp.files.extensionsFor(kind).join(" or ") + " file of at most " + Frp.files.maxMegabytes() + " MB.";
            }

            return null;
        },
        /** Why a bank reference file (branch register, sandbox report, source XML) is too large, or null. */
        referenceProblem: function (file) {
            var settings = Frp.files.settings();
            if (!settings || !settings.maxReferenceFileBytes) {
                return "The upload settings could not be read from the FRP Mapper API.";
            }

            return file.size > settings.maxReferenceFileBytes
                ? file.name + " is larger than the " + Math.floor(settings.maxReferenceFileBytes / 1000000) + " MB limit."
                : null;
        }
    };

    // ---------- calls to the API (through the Platform, which adds the person and their roles) ----------

    function ApiError(status, message, details) {
        this.name = "ApiError";
        this.status = status;
        this.message = message;
        this.unreachable = !!(details && details.unreachable);
        this.timeout = !!(details && details.timeout);
        this.signedOut = !!(details && details.signedOut !== undefined);
        /** The API's error body (e.g. bspResponse: what BSP answered when it sent no download), or null. */
        this.details = details || null;
    }

    ApiError.prototype = Object.create(Error.prototype);
    Frp.ApiError = ApiError;

    function statusMessage(status, statusText) {
        switch (status) {
            case 401:
                return "The API did not accept the sign-in. Check that InternalApi:Key is the same for the API and the Platform.";
            case 403:
                return "Your roles do not allow this action.";
            case 404:
                return "The project was not found.";
            default:
                return "The API returned " + status + " " + (statusText || "") + ".";
        }
    }

    function errorOf(response, text) {
        var body = null;
        try {
            body = text ? JSON.parse(text) : null;
        } catch (e) {
            body = null;
        }

        if (response.status === 401 && body && body.signedOut !== undefined) {
            // The session ended (idle, signed out, or signed in elsewhere): show the sign-in page.
            Frp.sessionEnded();
        }

        var message = body && typeof body.message === "string" && body.message ? body.message : statusMessage(response.status, response.statusText);
        return new ApiError(response.status, message, body);
    }

    // ---------- loading progress (0–100%) ----------
    // Every API call reports how far it is, and Frp.progress adds the calls running now into one percentage for the
    // loading screens (C.pageLoading) and the progress toast. Sending files and receiving the answer are measured in
    // bytes; the time the API spends working is estimated (it does not say how far it is), so that part rises quickly
    // at first and then slows down, and never reaches 100% before the answer is in.

    var progress = (function () {
        var tasks = [];
        var finished = 0;
        var shown = 0;
        var ticker = null;
        var resetTimer = null;
        var listeners = [];
        // Shares of the bar: sending a file 0–40%, the API working up to 85%, receiving the answer 85–100%.
        var sentAt = 40;
        var answeredAt = 85;

        function taskPercent(task) {
            if (task.done) {
                return 100;
            }

            var elapsed = Date.now() - task.since;
            if (task.phase === "sending") {
                return sentAt * task.fraction;
            }

            if (task.phase === "receiving") {
                return task.total > 0
                    ? answeredAt + (100 - answeredAt) * Math.min(1, task.loaded / task.total)
                    : answeredAt + (99 - answeredAt) * (1 - Math.exp(-elapsed / 1500));
            }

            return task.base + (answeredAt - task.base) * (1 - Math.exp(-elapsed / 2500));
        }

        function stageOf(task) {
            if (!task) {
                return "Done";
            }

            return task.phase === "sending" ? "Sending your files"
                : task.phase === "receiving" ? "Receiving the data"
                    : "Waiting for the server (estimated)";
        }

        function current() {
            if (!tasks.length) {
                return finished ? 100 : 0;
            }

            var sum = finished * 100;
            tasks.forEach(function (t) { sum += taskPercent(t); });
            // Never goes back while a load is running (a call that joins late does not pull the bar down) and only
            // shows 100% when every call has finished.
            shown = Math.max(shown, Math.min(99, sum / (tasks.length + finished)));
            return Math.floor(shown);
        }

        function slowest() {
            var task = null;
            tasks.forEach(function (t) {
                if (!task || taskPercent(t) < taskPercent(task)) {
                    task = t;
                }
            });
            return task;
        }

        function paint() {
            var value = current();
            var stage = stageOf(slowest());
            var nodes = document.querySelectorAll("[data-frp-progress]");
            for (var i = 0; i < nodes.length; i++) {
                setBar(nodes[i], value, stage);
            }

            listeners.slice().forEach(function (fn) { fn(value, stage); });
        }

        function start() {
            window.clearTimeout(resetTimer);
            resetTimer = null;
            if (!tasks.length) {
                finished = 0;
                shown = 0;
            }

            if (!ticker) {
                ticker = window.setInterval(paint, 120);
            }
        }

        function finish(task) {
            if (task.done) {
                return;
            }

            task.done = true;
            var index = tasks.indexOf(task);
            if (index >= 0) {
                tasks.splice(index, 1);
                finished++;
            }

            if (!tasks.length) {
                shown = 100;
                paint();
                window.clearInterval(ticker);
                ticker = null;
                resetTimer = window.setTimeout(function () {
                    finished = 0;
                    shown = 0;
                }, 800);
            }
        }

        return {
            /** Starts tracking a call; the task is told each step (sending, waiting, receiving) and end(). */
            begin: function () {
                start();
                var task = { phase: "waiting", since: Date.now(), base: 0, fraction: 0, total: 0, loaded: 0, done: false };
                tasks.push(task);
                return {
                    percent: function () { return Math.floor(taskPercent(task)); },
                    stage: function () { return stageOf(task.done ? null : task); },
                    sending: function (fraction) {
                        if (task.phase !== "sending") {
                            task.phase = "sending";
                            task.since = Date.now();
                        }

                        task.fraction = Math.max(0, Math.min(1, fraction || 0));
                    },
                    waiting: function () {
                        if (task.phase !== "waiting" || task.base === 0) {
                            task.base = task.phase === "sending" ? sentAt : Math.max(task.base, 0);
                            task.phase = "waiting";
                            task.since = Date.now();
                        }
                    },
                    receiving: function (loaded, total) {
                        if (task.phase !== "receiving") {
                            task.phase = "receiving";
                            task.since = Date.now();
                        }

                        task.loaded = loaded || 0;
                        task.total = total || 0;
                    },
                    end: function () { finish(task); }
                };
            },
            /** 0–100 for everything loading now (100 just after the last call finished). */
            percent: current,
            /** What is being waited for: "Sending your files", "Waiting for the server (estimated)" or "Receiving the data". */
            stage: function () { return stageOf(slowest()); },
            /** True while any call is running. */
            busy: function () { return tasks.length > 0; },
            /** fn(percent, stage) on every change; returns a function that stops it. */
            on: function (fn) {
                listeners.push(fn);
                return function () {
                    var index = listeners.indexOf(fn);
                    if (index >= 0) {
                        listeners.splice(index, 1);
                    }
                };
            }
        };
    })();

    Frp.progress = progress;

    /** Shows a percentage on a loading screen (an element with data-frp-progress, made by C.pageLoading). */
    function setBar(node, value, stage) {
        node.setAttribute("aria-valuenow", String(value));
        var text = node.querySelector("[data-frp-progress-text]");
        if (text && text.textContent !== value + "%") {
            text.textContent = value + "%";
        }

        var bar = node.querySelector("[data-frp-progress-bar]");
        if (bar) {
            bar.style.width = value + "%";
        }

        var note = node.querySelector("[data-frp-progress-note]");
        if (note && stage && note.textContent !== stage) {
            note.textContent = stage;
        }
    }

    Frp.setProgressBar = setBar;

    /**
     * The progress toast: a call that is still running after a moment, when no loading screen is showing the
     * percentage already, shows "Working on it · 42%" until it ends. Calls with quiet: true (their screen shows its own
     * progress, e.g. the sheet's autosave) never show it.
     */
    function progressToast(task, method, options) {
        if (options.quiet || !Frp.toast) {
            return function () { };
        }

        var toast = null;
        var stop = null;
        var timer = window.setTimeout(function () {
            if (document.querySelector("[data-frp-progress]")) {
                return;
            }

            var title = options.busy || (method === "GET" ? "Loading" : method === "DELETE" ? "Deleting" : method === "PUT" ? "Saving" : "Working on it");
            toast = Frp.toast("Info", title, task.stage(), { sticky: true, progress: task.percent() });
            stop = progress.on(function () {
                toast.setProgress(task.percent(), task.stage());
            });
        }, 700);
        return function () {
            window.clearTimeout(timer);
            if (stop) {
                stop();
            }

            if (toast) {
                toast.setProgress(100, "Done");
                window.setTimeout(toast.close, 300);
            }
        };
    }

    /**
     * Calls the API: path is the API path after /api/ (e.g. "projects/abc"). options: query (object), json (body),
     * form (FormData), method override for PUT/DELETE, accept.
     */
    function send(method, path, options) {
        options = options || {};
        var url = "app/api/" + path;
        if (options.query) {
            var parts = [];
            Object.keys(options.query).forEach(function (key) {
                var value = options.query[key];
                if (value !== undefined && value !== null) {
                    parts.push(encodeURIComponent(key) + "=" + encodeURIComponent(value));
                }
            });
            if (parts.length) {
                url += "?" + parts.join("&");
            }
        }

        var headers = { "X-Frp-Csrf": Frp.session.csrf, "Accept": options.accept || "application/json" };
        var body;
        var browserMethod = method;
        if (method === "PUT" || method === "DELETE") {
            // The Platform only takes GET and POST; the API method travels in a header (and is checked against the allowed calls).
            browserMethod = "POST";
            headers["X-Frp-Method"] = method;
        }

        if (options.json !== undefined) {
            headers["Content-Type"] = "application/json";
            body = JSON.stringify(options.json);
        } else if (options.form) {
            body = options.form;
        }

        if (options.measure && body instanceof FormData && window.XMLHttpRequest) {
            // A file upload: XMLHttpRequest reports how much of it has been sent (fetch cannot).
            return sendMeasured(browserMethod, url, headers, body, options);
        }

        return fetch(url, { method: browserMethod, headers: headers, body: body, credentials: "same-origin", cache: "no-store", redirect: "error", signal: options.signal })
            .catch(function () {
                throw new ApiError(0, "The FRP Mapper Platform did not respond. Check your connection and try again.", { unreachable: true });
            });
    }

    /** As fetch, for an upload whose sending is measured; resolves to { ok, status, statusText, text } (the answer read). */
    function sendMeasured(method, url, headers, body, options) {
        var task = options.measure;
        return new Promise(function (resolve, reject) {
            var xhr = new XMLHttpRequest();
            var expected = new URL(url, document.baseURI).href;
            var failed = function () {
                reject(new ApiError(0, "The FRP Mapper Platform did not respond. Check your connection and try again.", { unreachable: true }));
            };
            xhr.open(method, url, true);
            Object.keys(headers).forEach(function (name) { xhr.setRequestHeader(name, headers[name]); });
            xhr.withCredentials = true;
            xhr.upload.onprogress = function (e) {
                task.sending(e.lengthComputable && e.total ? e.loaded / e.total : 0);
            };
            xhr.upload.onload = function () { task.waiting(); };
            xhr.onprogress = function (e) {
                task.receiving(e.loaded, e.lengthComputable ? e.total : 0);
            };
            xhr.onerror = failed;
            xhr.onabort = function () {
                reject(new DOMException("The request was cancelled.", "AbortError"));
            };
            xhr.onload = function () {
                // As fetch's redirect: "error": an answer from another address (e.g. a sign-in page) is not the API's.
                if (xhr.responseURL && xhr.responseURL !== expected) {
                    failed();
                    return;
                }

                resolve({ ok: xhr.status >= 200 && xhr.status < 300, status: xhr.status, statusText: xhr.statusText, text: xhr.responseText || "" });
            };
            if (options.signal) {
                if (options.signal.aborted) {
                    xhr.abort();
                    return;
                }

                options.signal.addEventListener("abort", function () { xhr.abort(); });
            }

            task.sending(0);
            xhr.send(body);
        });
    }

    /** Reads a fetch answer as text, telling the task how much has arrived (of Content-Length when the server gives it). */
    function readMeasured(response, task) {
        var total = parseInt(response.headers.get("Content-Length") || "0", 10) || 0;
        task.receiving(0, total);
        if (!response.body || !response.body.getReader || typeof TextDecoder === "undefined") {
            return response.text();
        }

        var reader = response.body.getReader();
        var decoder = new TextDecoder("utf-8");
        var parts = [];
        var loaded = 0;
        function read() {
            return reader.read().then(function (chunk) {
                if (chunk.done) {
                    parts.push(decoder.decode());
                    return parts.join("");
                }

                loaded += chunk.value.length;
                task.receiving(loaded, total);
                parts.push(decoder.decode(chunk.value, { stream: true }));
                return read();
            });
        }

        return read();
    }

    Frp.api = {
        /** The answer as JSON (null for an empty answer). */
        // options also take quiet (no progress toast) and busy (the progress toast's title, e.g. "Saving the mappings").
        call: function (method, path, options) {
            options = options || {};
            var task = progress.begin();
            var stopToast = progressToast(task, method, options);
            options.measure = task;
            var done = function () {
                task.end();
                stopToast();
            };
            return send(method, path, options).then(function (response) {
                if (typeof response.text === "string") {
                    return response;
                }

                task.waiting();
                return readMeasured(response, task).then(function (text) {
                    return { ok: response.ok, status: response.status, statusText: response.statusText, text: text };
                });
            }).then(function (answer) {
                done();
                if (!answer.ok) {
                    throw errorOf(answer, answer.text);
                }

                return answer.text ? JSON.parse(answer.text) : null;
            }, function (error) {
                done();
                throw error;
            });
        },
        get: function (path, query, options) {
            return Frp.api.call("GET", path, extend({ query: query }, options));
        },
        post: function (path, json, options) {
            return Frp.api.call("POST", path, extend({ json: json === undefined ? null : json }, options));
        },
        put: function (path, json, options) {
            return Frp.api.call("PUT", path, extend({ json: json }, options));
        },
        remove: function (path, options) {
            return Frp.api.call("DELETE", path, extend({}, options));
        },
        upload: function (path, fields, options) {
            return Frp.api.call("POST", path, extend({ form: formData(fields) }, options));
        },
        /** A file the API builds (e.g. the merged XML): its name and content. Without fields it is fetched with GET. */
        file: function (path, fields, options) {
            options = options || {};
            var task = progress.begin();
            var stopToast = progressToast(task, "POST", { quiet: options.quiet, busy: options.busy || "Preparing the file" });
            var done = function () {
                task.end();
                stopToast();
            };
            return send(fields ? "POST" : "GET", path, fields ? { form: formData(fields) } : {}).then(function (response) {
                if (!response.ok) {
                    return response.text().then(function (text) { throw errorOf(response, text); });
                }

                task.receiving(0, parseInt(response.headers.get("Content-Length") || "0", 10) || 0);
                var disposition = response.headers.get("Content-Disposition") || "";
                return response.blob().then(function (blob) {
                    return { name: fileNameOf(disposition) || "download", blob: blob };
                });
            }).then(function (file) {
                done();
                return file;
            }, function (error) {
                done();
                throw error;
            });
        },
        /**
         * A request whose progress the API streams (application/x-ndjson): onProgress gets each update; resolves with
         * pick(the result line).
         */
        stream: function (method, path, options, onProgress, pick, failure) {
            options = options || {};
            options.accept = "application/x-ndjson";
            return send(method, path, options).then(function (response) {
                if (!response.ok) {
                    return response.text().then(function (text) { throw errorOf(response, text); });
                }

                var reader = response.body.getReader();
                var decoder = new TextDecoder("utf-8");
                var buffer = "";

                function handle(line) {
                    if (!line.trim()) {
                        return undefined;
                    }

                    var item;
                    try {
                        item = JSON.parse(line);
                    } catch (e) {
                        throw new ApiError(502, "The API sent an unreadable progress update.");
                    }

                    if (item.type === "progress" && item.progress) {
                        onProgress(item.progress);
                    } else if (item.type === "result" && pick(item)) {
                        if (item.progress) {
                            onProgress(item.progress);
                        }

                        return { answer: pick(item) };
                    } else if (item.type === "error") {
                        throw new ApiError(item.status || 500, item.message || failure);
                    }

                    return undefined;
                }

                function read() {
                    return reader.read().then(function (chunk) {
                        if (chunk.done) {
                            var last = handle(buffer);
                            if (last) {
                                return last.answer;
                            }

                            throw new ApiError(502, "The API stopped before it finished. Try again.");
                        }

                        buffer += decoder.decode(chunk.value, { stream: true });
                        var newline;
                        while ((newline = buffer.indexOf("\n")) >= 0) {
                            var line = buffer.substring(0, newline);
                            buffer = buffer.substring(newline + 1);
                            var done = handle(line);
                            if (done) {
                                reader.cancel().catch(function () { });
                                return done.answer;
                            }
                        }

                        return read();
                    });
                }

                return read();
            });
        },
        /** Platform helpers (not API calls): checks that use the shared C# rules. */
        util: function (name, json) {
            return fetch("app/util/" + name, {
                method: "POST",
                headers: { "X-Frp-Csrf": Frp.session.csrf, "Content-Type": "application/json", "Accept": "application/json" },
                body: JSON.stringify(json),
                credentials: "same-origin",
                cache: "no-store",
                redirect: "error"
            }).catch(function () {
                throw new ApiError(0, "The FRP Mapper Platform did not respond.", { unreachable: true });
            }).then(function (response) {
                return response.text().then(function (text) {
                    if (!response.ok) {
                        throw errorOf(response, text);
                    }

                    return JSON.parse(text);
                });
            });
        }
    };

    function extend(target, extra) {
        if (extra) {
            Object.keys(extra).forEach(function (key) { target[key] = extra[key]; });
        }

        return target;
    }

    function formData(fields) {
        var form = new FormData();
        Object.keys(fields).forEach(function (key) {
            var value = fields[key];
            if (value === undefined || value === null) {
                return;
            }

            if (Array.isArray(value)) {
                // Several files under one name (e.g. the COCREE input workbooks).
                value.forEach(function (file) { form.append(key, file, file.name || key); });
            } else if (value instanceof Blob) {
                form.append(key, value, value.name || key);
            } else {
                form.append(key, String(value));
            }
        });
        return form;
    }

    function fileNameOf(disposition) {
        var star = /filename\*=UTF-8''([^;]+)/i.exec(disposition);
        if (star) {
            try {
                return decodeURIComponent(star[1]);
            } catch (e) {
                return star[1];
            }
        }

        var plain = /filename="?([^";]+)"?/i.exec(disposition);
        return plain ? plain[1] : null;
    }

    /**
     * The message for a failed call, as the Blazor version showed it: the API's own message, or that the API did not
     * respond. reached: the text when the Platform could not reach the API at all.
     */
    Frp.messageOf = function (error, unreachable) {
        if (error instanceof ApiError) {
            if (error.unreachable && error.status !== 0) {
                return unreachable || "The FRP Mapper API did not respond. Try again.";
            }

            return error.message;
        }

        return "The FRP Mapper API did not respond. Try again.";
    };

    /** "The FRP Mapper API at http://… cannot be reached. …" (the address the Platform uses). */
    Frp.unreachable = function (then) {
        return ("The FRP Mapper API at " + Frp.session.apiBaseUrl + " cannot be reached. " + (then === undefined ? "Start FrpMapper.Api and reload." : then)).trim();
    };

    /** The session ended on the server: reload, which shows the sign-in page (and why). */
    Frp.sessionEnded = function () {
        if (!Frp.sessionEndedOnce) {
            Frp.sessionEndedOnce = true;
            window.location.reload();
        }
    };

    // ---------- files ----------

    /** Saves a file through the browser's download. */
    Frp.saveFile = function (name, blob) {
        var url = URL.createObjectURL(blob);
        var link = document.createElement("a");
        link.href = url;
        link.download = name;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(function () { URL.revokeObjectURL(url); }, 10000);
    };

    /** The SHA-256 of a file as lowercase hex (as the API records it). */
    Frp.sha256 = function (file) {
        return file.arrayBuffer().then(function (buffer) {
            if (window.crypto && window.crypto.subtle && window.isSecureContext) {
                return window.crypto.subtle.digest("SHA-256", buffer).then(hex);
            }

            // Plain http (not localhost): the browser offers no crypto.subtle, so it is computed here.
            return hex(sha256(new Uint8Array(buffer)));
        });
    };

    function hex(buffer) {
        var bytes = new Uint8Array(buffer);
        var text = "";
        for (var i = 0; i < bytes.length; i++) {
            text += (bytes[i] < 16 ? "0" : "") + bytes[i].toString(16);
        }

        return text;
    }

    var K = new Uint32Array([
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
        0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
        0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
        0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ]);

    function sha256(data) {
        var h = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
        var length = data.length;
        var blocks = Math.ceil((length + 9) / 64);
        var padded = new Uint8Array(blocks * 64);
        padded.set(data);
        padded[length] = 0x80;
        var bits = length * 8;
        var view = new DataView(padded.buffer);
        view.setUint32(padded.length - 4, bits >>> 0);
        view.setUint32(padded.length - 8, Math.floor(bits / 0x100000000));
        var w = new Uint32Array(64);
        for (var block = 0; block < blocks; block++) {
            var i;
            for (i = 0; i < 16; i++) {
                w[i] = view.getUint32(block * 64 + i * 4);
            }

            for (i = 16; i < 64; i++) {
                var x = w[i - 15];
                var y = w[i - 2];
                var s0 = ((x >>> 7) | (x << 25)) ^ ((x >>> 18) | (x << 14)) ^ (x >>> 3);
                var s1 = ((y >>> 17) | (y << 15)) ^ ((y >>> 19) | (y << 13)) ^ (y >>> 10);
                w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
            }

            var a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], k = h[7];
            for (i = 0; i < 64; i++) {
                var S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
                var ch = (e & f) ^ (~e & g);
                var t1 = (k + S1 + ch + K[i] + w[i]) >>> 0;
                var S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
                var maj = (a & b) ^ (a & c) ^ (b & c);
                var t2 = (S0 + maj) >>> 0;
                k = g;
                g = f;
                f = e;
                e = (d + t1) >>> 0;
                d = c;
                c = b;
                b = a;
                a = (t1 + t2) >>> 0;
            }

            h[0] = (h[0] + a) >>> 0;
            h[1] = (h[1] + b) >>> 0;
            h[2] = (h[2] + c) >>> 0;
            h[3] = (h[3] + d) >>> 0;
            h[4] = (h[4] + e) >>> 0;
            h[5] = (h[5] + f) >>> 0;
            h[6] = (h[6] + g) >>> 0;
            h[7] = (h[7] + k) >>> 0;
        }

        var out = new Uint8Array(32);
        var outView = new DataView(out.buffer);
        for (var j = 0; j < 8; j++) {
            outView.setUint32(j * 4, h[j]);
        }

        return out.buffer;
    }

    Frp.sha256Bytes = function (bytes) {
        return hex(sha256(bytes));
    };

    // ---------- sheet copies (the same rules as FrpMapper.Shared.Models.SheetSplitNames) ----------

    var maxSheetNameLength = 31;

    function partLetters(sheetName) {
        var end = sheetName.length;
        var start = end;
        while (start > 0 && /[a-z]/.test(sheetName.charAt(start - 1))) {
            start--;
        }

        var letters = sheetName.substring(start, end);
        var distinct = letters.split("").filter(function (c, i, all) { return all.indexOf(c) === i; }).length === letters.length;
        return letters.length >= 2 && start > 0 && /[0-9]/.test(sheetName.charAt(start - 1)) && distinct ? letters : null;
    }

    function partName(baseSheet, value) {
        var letters = partLetters(baseSheet);
        if (!letters || !/^[0-9]+$/.test(value)) {
            return null;
        }

        var number = parseInt(value, 10);
        if (number < 1 || number > letters.length || String(number) !== value) {
            return null;
        }

        return baseSheet.substring(0, baseSheet.length - letters.length) + letters.charAt(number - 1);
    }

    function withSuffix(baseSheet, value) {
        var suffix = " (" + value + ")";
        var room = maxSheetNameLength - suffix.length;
        var prefix = baseSheet.length <= room ? baseSheet : baseSheet.substring(0, Math.max(room, 1)).replace(/\s+$/, "");
        return prefix + suffix;
    }

    /** The sheet of one value: "Base (value)", or the part's letter ("CAR_Part_V_2abc" with 2 gives "CAR_Part_V_2b"). */
    Frp.sheetCopyName = function (baseSheet, value) {
        return partName(baseSheet, value) || withSuffix(baseSheet, value);
    };

    /** The account code on the row of a cell (e.g. E9) of the template, or null. */
    Frp.accountCode = function (codes, sheetName, cellAddress) {
        if (!codes || !codes.sheets || !sheetName || !cellAddress) {
            return null;
        }

        var rows = codes.sheets[sheetName];
        if (!rows) {
            return null;
        }

        var row = cellAddress.replace(/^[A-Za-z]+/, "");
        if (!/^[0-9]+$/.test(row)) {
            return null;
        }

        var code = rows[String(parseInt(row, 10))];
        return code === undefined ? null : code;
    };

    // ---------- pages ----------

    /**
     * A screen. render() returns its HTML; on(handler) gives the id to put in a data-click / data-input / data-change /
     * data-submit / data-keydown attribute; update() draws the screen again.
     */
    function Page(app) {
        this.app = app;
        this.handlers = [];
        this.closed = false;
    }

    Page.prototype.on = function (handler) {
        this.handlers.push(handler);
        return String(this.handlers.length - 1);
    };

    Page.prototype.update = function () {
        if (!this.closed) {
            this.app.draw(this);
        }
    };

    Page.prototype.title = function () {
        return "FRP Mapper";
    };

    Page.prototype.init = function () {
        return Promise.resolve();
    };

    Page.prototype.close = function () {
        this.closed = true;
    };

    Frp.Page = Page;

    /** The screens: { pattern, permission (needed to open it, else the access page), create(app, match, query) }. */
    Frp.routes = [];

    /** Sub-classes: Frp.page(constructor, { render: ..., ... }). */
    Frp.page = function (constructor, methods) {
        constructor.prototype = Object.create(Page.prototype);
        constructor.prototype.constructor = constructor;
        Object.keys(methods).forEach(function (name) {
            constructor.prototype[name] = methods[name];
        });
        return constructor;
    };
})();
