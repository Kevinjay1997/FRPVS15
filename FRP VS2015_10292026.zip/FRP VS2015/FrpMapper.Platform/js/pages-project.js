// A project: the workflow panel and the Mappings, Sheet copies, Validation, Exports, Details and History tabs.
(function () {
    "use strict";

    var Frp = window.Frp;
    var html = Frp.html;
    var C = Frp.components;
    var P = Frp.Permissions;
    var T = Frp.projectTabs = {};

    function lower(text) {
        return (text || "").toLowerCase();
    }

    function startsWithIgnoreCase(text, prefix) {
        return lower(text).indexOf(lower(prefix)) === 0;
    }

    /** A mapping's value on screen: its own value; "" when its sample value was removed; the sample value when it has none (null). */
    function valueOf(defaultValue, node) {
        return defaultValue === null || defaultValue === undefined ? (node ? node.testValue : null) : defaultValue;
    }

    Frp.mappingValue = valueOf;

    function readOnlyReason(status, what) {
        return status === "InReview" ? "Read only: the project is in review."
            : status === "Approved" ? "Read only: the project is approved."
            : "Read only: only a Maker can change " + what + ".";
    }

    // ---------- the workflow panel ----------

    T.Workflow = function (page) {
        this.page = page;
        this.comment = "";
        this.busy = false;
        this.pending = null;
        this.message = null;
        this.messageKind = "Info";
    };

    T.Workflow.prototype.show = function (kind, text) {
        Frp.toast(kind, null, text);
    };

    T.Workflow.prototype.isContributor = function (project) {
        var name = Frp.session.user.name;
        return project.workflow.contributors.some(function (c) { return Frp.sameName(c, name); }) || Frp.sameName(project.workflow.createdBy, name);
    };

    /** Runs a call that returns the changed project. */
    T.Workflow.prototype.call = function (call, success, keepComment) {
        var self = this;
        var page = self.page;
        self.busy = true;
        self.message = null;
        page.update();
        return call().then(function (updated) {
            self.pending = null;
            if (!keepComment) {
                self.comment = "";
            }

            self.show("Success", success);
            page.changed(updated);
        }, function (error) {
            self.pending = null;
            if (error instanceof Frp.ApiError && !error.unreachable) {
                self.show(error.status === 403 ? "Warning" : "Error", error.message);
            } else {
                self.show("Error", "The FRP Mapper API did not respond. Try again.");
            }
        }).then(function () {
            self.busy = false;
            page.update();
        });
    };

    T.Workflow.prototype.run = function (action) {
        var self = this;
        var project = self.page.project;
        var comment = self.comment.trim() ? self.comment.trim() : null;
        var messages = {
            Submit: "Submitted for review. The project is locked until a Checker decides.",
            Withdraw: "Withdrawn. The project is a draft again.",
            Approve: "Approved. The file can now be downloaded for BSP.",
            Return: "Returned to the Maker with your comment.",
            Reopen: "Reopened. The approval is void and the project is a draft again."
        };
        return self.call(function () {
            return Frp.api.post("projects/" + project.id + "/" + action.toLowerCase(), { comment: comment });
        }, messages[action] || "Done.");
    };

    T.Workflow.prototype.upload = function (file) {
        var self = this;
        var project = self.page.project;
        var problem = Frp.files.problem(Frp.UploadKinds.SubmissionXml, file);
        if (problem) {
            self.show("Error", problem);
            self.page.update();
            return Promise.resolve();
        }

        return self.call(function () {
            return Frp.api.upload("projects/" + project.id + "/submission", { xmlFile: file });
        }, file.name + " was attached and validated.", true);
    };

    T.Workflow.prototype.render = function () {
        var self = this;
        var page = self.page;
        var project = page.project;
        var workflow = project.workflow;
        var status = workflow.status;
        var canPrepare = Frp.can(P.SubmissionPrepare);
        var canReview = Frp.can(P.SubmissionReview);
        var canDownloadInReview = Frp.can(P.SubmissionDownloadInReview);
        var canWithdraw = Frp.can(P.SubmissionWithdraw);
        var canReopen = Frp.can(P.SubmissionReopen);
        var canDownloadApproved = Frp.can(P.SubmissionDownloadApproved);
        var isContributor = self.isContributor(project);
        var busy = self.busy;

        var steps = [
            { index: 1, label: status === "Returned" ? "Prepare (returned)" : "Prepare", done: status === "InReview" || status === "Approved", current: status === "Draft" || status === "Returned" },
            { index: 2, label: "Review", done: status === "Approved", current: status === "InReview" },
            { index: 3, label: "Approved", done: status === "Approved", current: false }
        ];

        function commentBox(id, rows) {
            return html`<textarea autocomplete="off" id="${id}" rows="${rows}" maxlength="2000" class="mt-2 w-full max-w-prose rounded-app border border-line bg-surface px-3 py-2 text-sm outline-none transition hover:border-slate-300 focus:border-accent"
                ${Frp.attr("disabled", busy)} data-input="${page.on(function (e) { self.comment = e.target.value; page.update(); })}">${self.comment}</textarea>`;
        }

        // Every workflow step is confirmed in a toast first.
        var questions = {
            Submit: { title: "Submit for review?", message: "The project is locked while a Checker reviews it.", confirmLabel: "Submit" },
            Approve: { title: "Approve and release this file?", message: "Exactly this file (its SHA-256 is recorded) becomes the one to send to BSP.", confirmLabel: "Approve" },
            Return: { title: "Return the project to the Maker?", message: "Your comment goes with it, and the Maker can change the project again.", confirmLabel: "Return" },
            Withdraw: { title: "Withdraw from review?", message: "The project becomes a draft again and can be changed.", confirmLabel: "Withdraw" },
            Reopen: { title: "Void the approval and reopen?", message: "The approved file is no longer valid for BSP; the reason is recorded in the audit trail.", confirmLabel: "Reopen", danger: true }
        };

        function confirm(options) {
            options.busy = busy;
            options.onRequest = function (action) {
                return Frp.confirm(questions[action] || { title: "Continue?" }).then(function (yes) {
                    return yes ? self.run(action) : undefined;
                });
            };
            return C.confirmActions(page, options);
        }

        var body;
        if (status === "Draft" || status === "Returned") {
            var specFailed = workflow.submission ? workflow.submission.specRulesFailed || 0 : 0;
            body = html`
            ${status === "Returned" ? html`<div class="mb-6">${C.notice("Warning", "Returned by " + Frp.shortName(workflow.reviewedBy) + " on " + Frp.date(workflow.reviewedAt, true),
                html`<p class="whitespace-pre-line">${workflow.reviewComment}</p>`)}</div>` : ""}
            ${canPrepare ? html`<div class="grid gap-8 lg:grid-cols-2">
                <div>
                    <h3 class="font-display text-lg font-bold text-ink">Submission file</h3>
                    <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                        The XML the Checker reviews and, once approved, the file you send to BSP. Upload the XML exported
                        from the Excel template, or build it from the project's values.
                    </p>
                    ${C.submissionFacts(workflow.submission)}
                    <div class="mt-4 flex flex-wrap gap-2">
                        <label class="inline-flex h-10 cursor-pointer items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent ${busy ? "pointer-events-none opacity-50" : ""}">
                            <i class="ph ph-upload-simple"></i> ${!workflow.submission ? "Upload XML" : "Replace with an XML file"}
                            <input type="file" class="sr-only" accept="${Frp.files.acceptFor(Frp.UploadKinds.SubmissionXml)}"${Frp.attr("disabled", busy || !Frp.files.settings())}
                                   data-change="${page.on(function (e) { var file = e.target.files[0]; e.target.value = ""; return file ? self.upload(file) : undefined; })}" />
                        </label>
                        <button class="inline-flex h-10 items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:opacity-50"
                                ${Frp.attr("disabled", busy)} data-click="${page.on(function () {
                                    return self.call(function () { return Frp.api.post("projects/" + project.id + "/submission/generate"); },
                                        "The submission file was built from the project values and validated.", true);
                                })}">
                            <i class="ph ph-file-code"></i> Build from project values
                        </button>
                    </div>
                </div>
                <div class="lg:border-l lg:border-line lg:pl-8">
                    <h3 class="font-display text-lg font-bold text-ink">Submit for review</h3>
                    <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                        The project is locked while it is in review. A Checker who did not work on it approves it or returns it to you.
                    </p>
                    <label class="mt-4 block text-sm font-semibold text-ink" for="submitComment">
                        Note for the Checker ${specFailed > 0 ? "(required)" : "(optional)"}
                    </label>
                    ${specFailed > 0 ? html`<p class="mt-1 text-sm text-amber-800">${specFailed} BSP specification rule(s) fail for this file. Explain why it should still be approved.</p>` : ""}
                    ${commentBox("submitComment", 3)}
                    <div class="mt-4">
                        <button class="inline-flex h-10 items-center gap-2 rounded-app bg-accent px-5 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-50"
                                ${Frp.attr("disabled", busy || (workflow.submission && !workflow.submission.xsdValid) || (specFailed > 0 && !self.comment.trim()))}
                                data-click="${page.on(function () { return Frp.confirm(questions.Submit).then(function (yes) { return yes ? self.run("Submit") : undefined; }); })}">
                            <i class="ph ph-paper-plane-tilt"></i> Submit for review
                        </button>
                        ${!workflow.submission ? html`<p class="mt-2 text-xs text-subtle">No file attached yet: the XML built from the project values will be submitted.</p>`
                            : !workflow.submission.xsdValid ? html`<p class="mt-2 text-xs text-red-700">The file is not XSD-valid, so it cannot be submitted.</p>` : ""}
                    </div>
                </div>
            </div>` : html`<p class="max-w-prose text-sm leading-6 text-muted">
                ${Frp.shortName(workflow.lastModifiedBy || workflow.createdBy)} is preparing this project.
                It can be reviewed once it is submitted.
            </p>`}`;
        } else if (status === "InReview") {
            var review;
            if (canReview && !isContributor) {
                review = html`<h3 class="font-display text-lg font-bold text-ink">Your review</h3>
                    <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                        Check the validation results and the file. Approving releases exactly this file (its SHA-256 is recorded);
                        returning sends the project back to the Maker with your comment.
                    </p>
                    <label class="mt-4 block text-sm font-semibold text-ink" for="reviewComment">Comment (required to return)</label>
                    ${commentBox("reviewComment", 3)}
                    ${confirm({
                        primary: "Approve", primaryLabel: "Approve", primaryIcon: "ph-seal-check",
                        secondary: "Return", secondaryLabel: "Return for changes", secondaryIcon: "ph-arrow-u-up-left",
                        secondaryDisabled: !self.comment.trim()
                    })}`;
            } else if (canReview) {
                review = C.notice("Info", "Another Checker must review this project",
                    "Segregation of duties: you prepared or changed this project, so you cannot approve or return it.");
            } else if (canWithdraw) {
                review = html`<h3 class="font-display text-lg font-bold text-ink">Waiting for a Checker</h3>
                    <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                        The project is locked. Withdraw it if you need to change something; it goes back to draft.
                    </p>
                    ${confirm({ secondary: "Withdraw", secondaryLabel: "Withdraw from review", secondaryIcon: "ph-arrow-counter-clockwise" })}`;
            } else {
                review = html`<p class="text-sm text-muted">Waiting for a Checker.</p>`;
            }

            body = html`<div class="grid gap-8 lg:grid-cols-2">
                <div>
                    <h3 class="font-display text-lg font-bold text-ink">In review</h3>
                    <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                        Submitted by ${Frp.shortName(workflow.submittedBy)} on ${Frp.date(workflow.submittedAt, true)}.
                    </p>
                    ${workflow.submissionComment ? html`<blockquote class="mt-3 max-w-prose border-l-2 border-line pl-4 text-sm leading-6 text-ink whitespace-pre-line">${workflow.submissionComment}</blockquote>` : ""}
                    ${C.submissionFacts(workflow.submission)}
                    ${canDownloadInReview && !isContributor ? html`<a class="mt-4 inline-flex h-10 items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent"
                        href="${"download/" + project.id + "/submission"}" data-native="true">
                        <i class="ph ph-download-simple"></i> Download the file under review
                    </a>` : ""}
                </div>
                <div class="lg:border-l lg:border-line lg:pl-8">${review}</div>
            </div>`;
        } else if (status === "Approved") {
            body = html`<div class="grid gap-8 lg:grid-cols-2">
                <div>
                    ${C.notice("Success", "Approved by " + Frp.shortName(workflow.reviewedBy) + " on " + Frp.date(workflow.reviewedAt, true), html`
                        ${workflow.reviewComment ? html`<p class="whitespace-pre-line">${workflow.reviewComment}</p>` : ""}
                        <p>Prepared by ${Frp.shortName(workflow.submittedBy)}. The approved file below is the one to send to BSP.</p>`)}
                    ${C.submissionFacts(workflow.submission)}
                    ${canDownloadApproved ? html`<a class="mt-4 inline-flex h-10 items-center gap-2 rounded-app bg-accent px-5 text-sm font-semibold text-white transition hover:bg-accent-hover"
                        href="${"download/" + project.id + "/submission"}" data-native="true">
                        <i class="ph ph-download-simple"></i> Download approved XML
                    </a>` : ""}
                </div>
                ${canReopen ? html`<div class="lg:border-l lg:border-line lg:pl-8">
                    <h3 class="font-display text-lg font-bold text-ink">Need a correction?</h3>
                    <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                        Reopening voids the approval and makes the project a draft again. The reason is recorded in the audit trail.
                    </p>
                    <label class="mt-4 block text-sm font-semibold text-ink" for="reopenComment">Reason (required)</label>
                    ${commentBox("reopenComment", 2)}
                    ${confirm({ secondary: "Reopen", secondaryLabel: "Reopen and void approval", secondaryIcon: "ph-lock-open", secondaryDisabled: !self.comment.trim() })}
                </div>` : ""}
            </div>`;
        }

        return html`<section class="rounded-app border border-line bg-surface" aria-labelledby="workflow-title">
    <ol class="grid border-b border-line text-sm sm:grid-cols-3">
        ${steps.map(function (step) {
            return html`<li class="flex items-center gap-3 px-6 py-4 ${step.current ? "text-ink" : step.done ? "text-muted" : "text-subtle"}">
            <span class="grid h-7 w-7 shrink-0 place-items-center rounded-app border text-xs font-semibold ${step.current ? "border-accent bg-accent text-white" : step.done ? "border-emerald-300 bg-emerald-50 text-emerald-700" : "border-line text-subtle"}">
                ${step.done ? html`<i class="ph ph-check"></i>` : step.index}
            </span>
            <span class="font-medium">${step.label}</span>
        </li>`;
        })}
    </ol>
    <div class="p-6 lg:p-8">
        <h2 id="workflow-title" class="sr-only">Workflow</h2>
        ${body}
    </div>
</section>`;
    };

    // ---------- Mappings ----------

    var pageSizes = [25, 50, 100, 250];

    T.Mappings = function (page) {
        this.page = page;
        this.loaded = null;
        this.rows = [];
        this.nodes = {};
        this.leafPaths = [];
        this.sheetCounts = [];
        this.copies = {};
        this.splitSheets = {};
        this.validation = null;
        this.issues = [];
        this.issueList = new C.IssueList();
        this.sheetFilter = "";
        this.search = "";
        this.invalidOnly = false;
        this.busy = false;
        this.dirty = false;
        this.message = null;
        this.messageKind = "Info";
        this.accountCodes = null;
        this.accountCodesFor = null;
        this.currentPage = 1;
        this.pageSize = 50;
        this.refilling = false;
        this.confirmRefill = false;
        // XSD checks of each (path, value), from the Platform (the shared C# rules); undefined while being checked.
        this.checks = {};
        this.checkQueue = {};
        this.checkTimer = null;
        this.checksFailed = null;
        this.nextId = 1;
        this.view = "table"; // "table" (every mapping as a row) or "sheet" (a template sheet as a grid)
        this.sheetView = null;
    };

    T.Mappings.prototype.node = function (path) {
        return path ? this.nodes[lower(path)] || null : null;
    };

    /** Loads the project's mappings when the project object changed (a save gives a new one). */
    T.Mappings.prototype.prepare = function () {
        var self = this;
        var project = self.page.project;
        if (self.loaded === project) {
            return;
        }

        self.loaded = project;
        self.nodes = {};
        project.schemaNodes.forEach(function (node) {
            var key = lower(node.path);
            if (!self.nodes[key]) {
                self.nodes[key] = node;
            }
        });
        self.leafPaths = project.schemaNodes.filter(function (n) { return n.dataType !== "complex"; }).map(function (n) { return n.path; });
        self.loadSheetList();
        if (!self.sheetCounts.some(function (s) { return s.name === self.sheetFilter; })) {
            self.sheetFilter = "";
        }

        self.rows = project.mappings.map(function (m) {
            var node = self.node(m.schemaPath);
            return {
                id: m.id,
                sheetName: m.sheetName,
                cellAddress: m.cellAddress,
                schemaPath: m.schemaPath,
                defaultValue: valueOf(m.defaultValue, node),
                source: m.source,
                key: "m" + (self.nextId++)
            };
        });
        self.validation = project.validation;
        self.issues = project.issues.slice();
        self.dirty = false;
        self.currentPage = 1;
        self.checks = {};
        self.checkQueue = {};
        self.checksFailed = null;
        self.fillDataList();
        self.requestChecks(self.rows);

        // The template's account codes are read once per project (the API reads the workbook and keeps the result).
        if (self.accountCodesFor !== project.id) {
            self.accountCodesFor = project.id;
            self.accountCodes = null;
            Frp.api.get("projects/" + project.id + "/account-codes").then(function (codes) {
                self.accountCodes = codes;
            }, function () {
                self.accountCodes = { sheets: {} }; // the column shows "–"; mappings work as before
            }).then(function () { self.page.update(); });
        }
    };

    /** The XSD paths offered while typing a path (a datalist outside the page, filled once per project). */
    T.Mappings.prototype.fillDataList = function () {
        var list = document.getElementById("schemaPaths");
        if (!list) {
            list = document.createElement("datalist");
            list.id = "schemaPaths";
            document.body.appendChild(list);
        }

        list.innerHTML = "";
        if (!this.page.canEdit()) {
            return;
        }

        var fragment = document.createDocumentFragment();
        this.leafPaths.forEach(function (path) {
            var option = document.createElement("option");
            option.value = path;
            fragment.appendChild(option);
        });
        list.appendChild(fragment);
    };

    /**
     * The Sheet list: every mapped sheet, except that a split form's sheet is listed as its copies (as in the downloaded
     * template), each with the form's mappings.
     */
    T.Mappings.prototype.loadSheetList = function () {
        var self = this;
        var project = self.page.project;
        self.copies = {};
        self.splitSheets = {};
        (project.sheetSplits || []).forEach(function (split) {
            var prefix = lower(split.groupPath + "/");
            var fields = project.mappings.filter(function (m) { return lower(m.schemaPath).indexOf(prefix) === 0; });
            var sheets = [];
            fields.forEach(function (m) {
                if (!sheets.some(function (s) { return lower(s) === lower(m.sheetName); })) {
                    sheets.push(m.sheetName);
                }
            });
            var key = fields.filter(function (m) { return lower(m.schemaPath) === lower(split.keyPath); })[0];
            if (sheets.length !== 1 || !key || !split.values.length
                || project.mappings.some(function (m) { return lower(m.sheetName) === lower(sheets[0]) && fields.indexOf(m) < 0; })) {
                return; // not used by the API either (see the validation's warning)
            }

            // The project's values go on the first copy, as in the template (the one Excel's XML map binds).
            var valuesCopy = split.values[0];
            self.splitSheets[lower(sheets[0])] = split.values.length;
            var keyNode = self.node(split.keyPath);
            split.values.forEach(function (value) {
                var name = Frp.sheetCopyName(sheets[0], value);
                self.copies[lower(name)] = {
                    name: name,
                    baseSheet: sheets[0],
                    groupPath: split.groupPath,
                    keyPath: split.keyPath,
                    keyName: keyNode ? keyNode.name : "Key",
                    value: value,
                    count: split.values.length,
                    holdsValues: value === valuesCopy,
                    valuesCopy: valuesCopy
                };
            });
        });

        self.sheetCounts = [];
        var groups = [];
        var byName = {};
        project.mappings.forEach(function (m) {
            var key = lower(m.sheetName);
            if (!byName[key]) {
                byName[key] = { name: m.sheetName, count: 0 };
                groups.push(byName[key]);
            }

            byName[key].count++;
        });
        groups.forEach(function (group) {
            if (self.splitSheets[lower(group.name)]) {
                Object.keys(self.copies).forEach(function (k) {
                    var copy = self.copies[k];
                    if (lower(copy.baseSheet) === lower(group.name)) {
                        self.sheetCounts.push({ name: copy.name, label: copy.name + " (" + group.count + ")" });
                    }
                });
            } else {
                self.sheetCounts.push({ name: group.name, label: group.name + " (" + group.count + ")" });
            }
        });
    };

    T.Mappings.prototype.selectedCopy = function () {
        return this.sheetFilter ? this.copies[lower(this.sheetFilter)] || null : null;
    };

    /** The selected sheet copy, when the row belongs to its form. */
    T.Mappings.prototype.copyOf = function (row) {
        var copy = this.selectedCopy();
        return copy && lower(row.sheetName) === lower(copy.baseSheet) && startsWithIgnoreCase(row.schemaPath, copy.groupPath + "/") ? copy : null;
    };

    T.Mappings.prototype.accountCode = function (row) {
        return Frp.accountCode(this.accountCodes, row.sheetName, row.cellAddress);
    };

    function checkKey(row) {
        return (row.schemaPath || "") + "\u001f" + (row.defaultValue || "");
    }

    /** XSD facet errors for the row's value (a blank value is an empty cell): [] when valid, undefined while being checked. */
    T.Mappings.prototype.rowErrors = function (row) {
        return this.checks[checkKey(row)];
    };

    /** Asks the Platform to check the values of these rows (batched, the C# rules the API also applies). */
    T.Mappings.prototype.requestChecks = function (rows) {
        var self = this;
        rows.forEach(function (row) {
            var key = checkKey(row);
            if (!(key in self.checks)) {
                self.checkQueue[key] = [row.schemaPath || "", row.defaultValue || ""];
            }
        });
        if (self.checkTimer) {
            return;
        }

        self.checkTimer = setTimeout(function () {
            self.checkTimer = null;
            var keys = Object.keys(self.checkQueue);
            if (!keys.length) {
                return;
            }

            var items = keys.map(function (k) { return self.checkQueue[k]; });
            var project = self.page.project;
            self.checkQueue = {};
            var batches = [];
            for (var i = 0; i < items.length; i += 20000) {
                batches.push({ keys: keys.slice(i, i + 20000), items: items.slice(i, i + 20000) });
            }

            batches.reduce(function (previous, batch) {
                return previous.then(function () {
                    return Frp.api.util("value-errors", { projectId: project.id, version: project.updatedAt, items: batch.items }).then(function (answer) {
                        if (self.page.project.id !== project.id) {
                            return;
                        }

                        batch.keys.forEach(function (key, index) {
                            self.checks[key] = answer.errors[String(index)] || [];
                        });
                        self.checksFailed = null;
                        self.page.update();
                    });
                });
            }, Promise.resolve()).catch(function (error) {
                self.checksFailed = "The values could not be checked: " + Frp.messageOf(error);
                self.page.update();
            });
        }, 250);
    };

    T.Mappings.prototype.filtered = function () {
        var self = this;
        var query = self.rows;
        var copy = self.selectedCopy();
        if (copy) {
            query = query.filter(function (r) { return lower(r.sheetName) === lower(copy.baseSheet) && startsWithIgnoreCase(r.schemaPath, copy.groupPath + "/"); });
        } else if (self.sheetFilter) {
            query = query.filter(function (r) { return lower(r.sheetName) === lower(self.sheetFilter); });
        }

        var text = self.search.trim();
        if (text) {
            var low = lower(text);
            query = query.filter(function (r) {
                var code = self.accountCode(r);
                return lower(r.schemaPath).indexOf(low) >= 0
                    || lower(r.cellAddress) === low
                    || lower(r.sheetName + "!" + r.cellAddress) === low
                    || (code !== null && code.indexOf(text) === 0);
            });
        }

        if (self.invalidOnly) {
            query = query.filter(function (r) { var errors = self.rowErrors(r); return errors && errors.length > 0; });
        }

        return query;
    };

    T.Mappings.prototype.buildRequest = function () {
        var self = this;
        return self.rows.filter(function (m) {
            return m.schemaPath && m.schemaPath.trim() && m.sheetName && m.sheetName.trim() && m.cellAddress && m.cellAddress.trim();
        }).map(function (m) {
            var node = self.node(m.schemaPath);
            return {
                id: m.id,
                sheetName: m.sheetName.trim(),
                cellAddress: m.cellAddress.trim().toUpperCase(),
                schemaPath: m.schemaPath,
                defaultValue: valueOf(m.defaultValue, node),
                source: m.source
            };
        });
    };

    T.Mappings.prototype.show = function (kind, text) {
        Frp.toast(kind, null, text);
    };

    T.Mappings.prototype.call = function (action) {
        var self = this;
        self.busy = true;
        self.message = null;
        self.page.update();
        return action().catch(function (error) {
            self.show("Error", Frp.messageOf(error));
        }).then(function () {
            self.busy = false;
            self.page.update();
        });
    };

    T.Mappings.prototype.save = function () {
        var self = this;
        var project = self.page.project;
        return self.call(function () {
            return Frp.api.put("projects/" + project.id + "/mappings", { mappings: self.buildRequest() }).then(function (saved) {
                var invalid = saved.validation && saved.validation.isValid === false;
                self.show(invalid ? "Warning" : "Success", invalid ? "Saved. Validation found " + saved.validation.errorCount + " error(s)." : "Saved and validated.");
                self.page.changed(saved);
            });
        });
    };

    T.Mappings.prototype.check = function () {
        var self = this;
        var project = self.page.project;
        return self.call(function () {
            return Frp.api.post("projects/" + project.id + "/validate", { mappings: self.buildRequest() }).then(function (validation) {
                self.validation = validation;
                self.issues = validation.issues || [];
                self.show(validation.isValid ? "Success" : "Warning", validation.isValid
                    ? "All values and the generated XML pass the XSD and the evaluated BSP rules (unsaved changes included)."
                    : validation.errorCount + " error(s) found (unsaved changes included).");
            });
        });
    };

    /**
     * The API gives every XSD field a new unique, valid sample value (solved for the BSP rules), saves those values and the
     * mapped cells in the database, and returns the saved project.
     */
    T.Mappings.prototype.refill = function () {
        var self = this;
        var project = self.page.project;
        self.confirmRefill = false;
        self.refilling = true;
        return self.call(function () {
            return Frp.api.post("projects/" + project.id + "/mappings/sample-values").then(function (result) {
                self.page.changed(result.project);
                var checked = result.unique + result.shared;
                var summary = "New sample values saved: " + Frp.n0(result.unique) + " of " + Frp.n0(checked) + " amounts, numbers and texts have a value of their own"
                    + (result.shared > 0 ? " (" + Frp.n0(result.shared) + " share one because the BSP rules require it, e.g. 0 or equal totals)" : "")
                    + "; " + Frp.n0(result.refilled) + " mapped cells updated. ";
                var outcome = result.xsdValid
                    ? "The XML from these values passes the XSD and " + Frp.n0(result.rulesPassed) + " BSP rules."
                    : "The XML from these values has " + Frp.n0(result.xsdErrors) + " XSD error(s) and " + Frp.n0(result.rulesFailed) + " failed BSP rule(s); see the validation below.";
                self.show(result.xsdValid ? "Success" : "Warning", summary + outcome);
            });
        }).then(function () {
            self.refilling = false;
            self.page.update();
        });
    };

    /** How many rows (on one sheet, or all) still hold their sample value, and how many are empty. */
    T.Mappings.prototype.sampleCounts = function (sheetName) {
        var self = this;
        var counts = { sample: 0, empty: 0 };
        self.rows.forEach(function (row) {
            if (sheetName && lower(row.sheetName) !== lower(sheetName)) {
                return;
            }

            var node = self.node(row.schemaPath);
            if (row.defaultValue === "") {
                counts.empty++;
            } else if (node && row.defaultValue === node.testValue) {
                counts.sample++;
            }
        });
        return counts;
    };

    /**
     * Removes (action "remove") or restores ("restore") the sample values of one sheet or, with no sheet, every sheet.
     * Values people entered are kept. Asked in a toast first; saved at once (POST projects/{id}/values/samples).
     */
    T.Mappings.prototype.changeSamples = function (action, sheetName) {
        var self = this;
        var page = self.page;
        var project = page.project;
        if (self.dirty) {
            Frp.toast("Warning", "Save your changes first", "Save the mapping changes on this tab, then " + (action === "remove" ? "remove" : "restore") + " the sample values.");
            return Promise.resolve();
        }

        var where = sheetName ? "on " + sheetName : "on every sheet";
        var question = action === "remove"
            ? { title: "Remove the sample values " + where + "?", message: "Fields that still hold a sample value become empty cells, ready for the bank's figures. Values you entered are kept. You can restore the sample values later.", confirmLabel: "Remove sample values", danger: true }
            : { title: "Restore the sample values " + where + "?", message: "Empty cells get their sample value again. Values you entered are kept.", confirmLabel: "Restore sample values" };
        return Frp.confirm(question).then(function (yes) {
            if (!yes) {
                return undefined;
            }

            self.busy = true;
            page.update();
            return Frp.api.post("projects/" + project.id + "/values/samples", { action: action, sheetName: sheetName || null }).then(function (result) {
                Frp.toast("Success", action === "remove" ? "Sample values removed" : "Sample values restored",
                    !result.changed ? "Nothing to change " + where + "."
                        : Frp.n0(result.changed) + " field(s) " + where + (action === "remove" ? " are now empty." : " have their sample value again."));
                page.changed(result.project);
            }, function (error) {
                Frp.toast("Error", "The sample values were not changed", Frp.messageOf(error));
            }).then(function () {
                self.busy = false;
                page.update();
            });
        });
    };

    /** The Remove / Restore sample values buttons (for a sheet, or every sheet). */
    T.Mappings.prototype.sampleButtons = function (sheetName) {
        var self = this;
        var page = self.page;
        var counts = self.sampleCounts(sheetName);
        var button = "inline-flex h-10 items-center gap-2 rounded-app px-3 text-sm font-semibold text-muted transition hover:bg-surface hover:text-ink disabled:opacity-50";
        return html`<button class="${button}" ${Frp.attr("disabled", self.busy || !counts.sample)}
                title="${Frp.n0(counts.sample) + " field(s) " + (sheetName ? "on this sheet " : "") + "still hold a sample value"}"
                data-click="${page.on(function () { return self.changeSamples("remove", sheetName); })}">
            <i class="ph ph-eraser"></i> Remove sample values
        </button>
        <button class="${button}" ${Frp.attr("disabled", self.busy || !counts.empty)}
                title="${Frp.n0(counts.empty) + " empty field(s) " + (sheetName ? "on this sheet" : "") + " can get their sample value back"}"
                data-click="${page.on(function () { return self.changeSamples("restore", sheetName); })}">
            <i class="ph ph-arrow-counter-clockwise"></i> Restore sample values
        </button>`;
    };

    T.Mappings.prototype.addMapping = function () {
        var self = this;
        var project = self.page.project;
        var copy = self.selectedCopy();
        var sheet = copy ? copy.baseSheet
            : !self.sheetFilter ? (project.workbook && project.workbook.sheets.length ? project.workbook.sheets[0].name : "Mapped Template") : self.sheetFilter;
        var path = self.leafPaths.length ? self.leafPaths[0] : "";
        var node = self.node(path);
        var row = { id: Frp.newId(), sheetName: sheet, cellAddress: "", schemaPath: path, defaultValue: node ? node.testValue : null, source: "Manual", key: "m" + (self.nextId++) };
        self.rows.unshift(row);
        self.search = "";
        self.invalidOnly = false;
        self.currentPage = 1; // the new row is first
        self.dirty = true;
        self.requestChecks([row]);
    };

    T.Mappings.prototype.focusIssue = function (issue) {
        var self = this;
        if (!issue.schemaPath || !issue.schemaPath.trim()) {
            return;
        }

        self.invalidOnly = false;
        self.sheetFilter = issue.sheetName && issue.sheetName.trim() && self.sheetCounts.some(function (s) { return s.name === issue.sheetName; }) ? issue.sheetName : "";
        self.search = issue.schemaPath;
        self.currentPage = 1;
        self.page.update();
    };

    T.Mappings.prototype.render = function () {
        var self = this;
        var page = self.page;
        var project = page.project;
        var canEdit = page.canEdit();
        self.prepare();
        var busy = self.busy;
        var visible = self.filtered();
        var pages = Math.max(1, Math.ceil(visible.length / self.pageSize));
        self.currentPage = Math.max(1, Math.min(self.currentPage, pages));
        var first = (self.currentPage - 1) * self.pageSize;
        var pageRows = visible.slice(first, first + self.pageSize);
        var selected = self.selectedCopy();
        var pending = pageRows.some(function (r) { return self.rowErrors(r) === undefined; });
        var validation = self.validation;
        var navButton = "inline-flex h-9 items-center gap-1 rounded-app border border-line bg-surface px-3 font-medium text-ink transition hover:border-accent hover:text-accent disabled:cursor-not-allowed disabled:opacity-40";

        function rowMarkup(row) {
            var copy = self.copyOf(row);
            var code = self.accountCode(row);
            var errors = self.rowErrors(row);
            var node = self.node(row.schemaPath);
            var editable = "rounded-app border border-transparent bg-transparent px-2 transition enabled:hover:border-line enabled:focus:border-accent enabled:focus:bg-surface";
            var sheetTitle = self.splitSheets[lower(row.sheetName)]
                ? "Entered on " + self.splitSheets[lower(row.sheetName)] + " sheet copies (Sheet copies tab); choose a copy in the Sheet list to see it." : null;
            var value;
            if (copy && lower(row.schemaPath) === lower(copy.keyPath)) {
                value = html`<span class="px-2 font-mono text-sm text-ink" title="Set by the sheet copy (Sheet copies tab)">${copy.value}</span>`;
            } else if (copy && !copy.holdsValues) {
                value = html`<span class="px-2 text-xs text-subtle" title="${"The project's values are on the " + copy.valuesCopy + " copy; this copy starts empty"}">Blank on this copy</span>`;
            } else {
                value = html`<input autocomplete="off" class="h-9 rounded-app border px-2 text-sm transition ${errors && errors.length ? "border-red-300 bg-red-50" : "border-transparent bg-transparent enabled:hover:border-line enabled:focus:border-accent enabled:focus:bg-surface"}"
                    value="${row.defaultValue || ""}" placeholder="${node && node.isRequired ? "Empty (required)" : "Empty"}" aria-label="Value"${Frp.attr("disabled", !canEdit)}
                    title="${row.defaultValue === "" ? "No value: the sample value was removed" : node && row.defaultValue === node.testValue ? "Sample value" : "Entered value"}"
                    data-change="${page.on(function (e) { row.defaultValue = e.target.value; self.dirty = true; self.requestChecks([row]); page.update(); })}" />`;
            }

            var check = row.defaultValue === ""
                ? html`<span class="text-xs ${node && node.isRequired ? "text-amber-800" : "text-subtle"}">Empty${node && node.isRequired ? " (required)" : ""}</span>`
                : errors === undefined
                ? html`<span class="text-xs text-subtle">Checking…</span>`
                : !errors.length
                    ? html`<span class="flex items-center gap-1.5 text-xs text-emerald-700"><i class="ph ph-check-circle"></i> ${node ? node.dataType : ""}</span>`
                    : html`<span class="line-clamp-2 text-xs leading-4 text-red-700" title="${errors.join(" ")}">${errors[0]}</span>`;

            return html`<div data-key="${row.key}" class="grid h-[58px] grid-cols-[170px_80px_170px_minmax(320px,1fr)_190px_210px_44px] items-center gap-2 border-b border-line/70 transition hover:bg-canvas">
    ${copy ? html`<span class="truncate px-2 text-sm text-ink" title="${"Copy of " + copy.baseSheet + " for " + copy.keyName + " " + copy.value + ": the same cells as every copy. Change the sheet in the All sheets view."}">${copy.name}</span>`
        : html`<input autocomplete="off" class="h-9 ${editable} text-sm" value="${row.sheetName}" aria-label="Sheet name"${Frp.attr("disabled", !canEdit)}${sheetTitle ? Frp.raw(" title=\"" + Frp.esc(sheetTitle) + "\"") : ""}
            data-change="${page.on(function (e) { row.sheetName = e.target.value; self.dirty = true; page.update(); })}" />`}
    <input autocomplete="off" class="h-9 ${editable} font-mono text-sm" value="${row.cellAddress}" aria-label="Cell address"${Frp.attr("disabled", !canEdit)}
        data-change="${page.on(function (e) { row.cellAddress = e.target.value; self.dirty = true; page.update(); })}" />
    <span class="truncate px-2 font-mono text-xs ${code === null ? "text-subtle" : "text-ink"}" title="${code !== null ? code : !self.accountCodes ? "Loading account codes…" : "No account code on this row of the template"}">${code !== null ? code : !self.accountCodes ? "…" : "–"}</span>
    <input autocomplete="off" class="h-9 min-w-0 ${editable} font-mono text-xs text-muted" list="schemaPaths" value="${row.schemaPath}" title="${row.schemaPath}" aria-label="XSD path"${Frp.attr("disabled", !canEdit)}
        data-change="${page.on(function (e) {
            row.schemaPath = e.target.value;
            var changed = self.node(row.schemaPath);
            row.defaultValue = changed ? changed.testValue : null;
            self.dirty = true;
            self.requestChecks([row]);
            page.update();
        })}" />
    ${value}
    ${check}
    ${canEdit ? html`<button class="grid h-9 w-9 place-items-center rounded-app text-subtle transition hover:bg-red-50 hover:text-red-700" title="Remove mapping" aria-label="Remove mapping"
        data-click="${page.on(function () { self.rows.splice(self.rows.indexOf(row), 1); self.dirty = true; page.update(); })}">
        <i class="ph ph-trash"></i>
    </button>` : ""}
</div>`;
        }

        return html`<section aria-labelledby="mappings-title">
    <div class="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
            <h2 id="mappings-title" class="font-display text-xl font-bold text-ink">Mappings</h2>
            <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                Each XSD field and the Excel cell it is bound to. Every field starts with a sample value, for testing; remove the
                sample values to start from empty cells, and restore them at any time. A blank value leaves the cell empty.
                ${!canEdit ? html`<span class="font-medium text-ink">${readOnlyReason(project.workflow.status, "mappings")}</span>` : ""}
            </p>
        </div>
        ${canEdit ? html`<div class="flex flex-wrap gap-2">
            <button class="inline-flex h-10 items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:opacity-50"
                    ${Frp.attr("disabled", busy)} data-click="${page.on(function () { return self.check(); })}">
                <i class="ph ph-list-checks"></i> Check values
            </button>
            <button class="inline-flex h-10 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50"
                    ${Frp.attr("disabled", busy || !self.dirty)} data-click="${page.on(function () { return self.save(); })}">
                <i class="ph ph-floppy-disk"></i> ${self.dirty ? "Save changes" : "Saved"}
            </button>
        </div>` : ""}
    </div>

    ${self.checksFailed ? html`<div class="mt-6">${C.notice("Warning", null, self.checksFailed)}</div>` : ""}

    ${validation ? html`<div class="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            ${C.metric("Result", validation.isValid ? "Valid" : validation.errorCount + " error(s)")}
            ${C.metric("Values checked", Frp.n0(validation.checkedValues))}
            ${C.metric("XSD sheets fully mapped", validation.mappedSheets + " of " + validation.totalSheets)}
            ${C.metric("BSP rules passed / failed", validation.specificationChecked ? Frp.n0(validation.specRulesPassed) + " / " + Frp.n0(validation.specRulesFailed) : "No specification")}
        </div>
        <div class="mt-4">${self.issueList.render(page, self.issues, function (issue) { self.focusIssue(issue); })}</div>` : ""}

    <div class="mt-8 inline-flex rounded-app border border-line bg-surface p-0.5" role="tablist" aria-label="Mappings view">
        ${[["table", "Table", "ph-rows"], ["sheet", "Sheet", "ph-grid-nine"]].map(function (v) {
            var active = self.view === v[0];
            return html`<button role="tab" aria-selected="${active ? "true" : "false"}"
                class="inline-flex h-9 items-center gap-2 rounded-[6px] px-4 text-sm font-semibold transition ${active ? "bg-accent-soft text-accent" : "text-muted hover:text-ink"}"
                title="${v[0] === "sheet" ? "Each template sheet as Excel shows it, with the mapped cells marked" : "Every mapping as a row"}"
                data-click="${page.on(function () { self.view = v[0]; page.update(); })}"><i class="ph ${v[2]}"></i> ${v[1]}</button>`;
        })}
    </div>

    ${self.view === "sheet" ? (self.sheetView || (self.sheetView = new T.MappingSheet(self))).render() : html`<div class="mt-4 flex flex-wrap items-end gap-3">
        <div>
            <label class="block text-xs font-medium text-subtle" for="sheetFilter">Sheet</label>
            <select autocomplete="off" id="sheetFilter" class="mt-1 h-10 max-w-[260px] rounded-app border border-line bg-surface px-3 text-sm transition hover:border-slate-300 focus:border-accent"
                    data-change="${page.on(function (e) { self.sheetFilter = e.target.value; self.currentPage = 1; page.update(); })}">
                <option value=""${Frp.attr("selected", !self.sheetFilter)}>All sheets (${Frp.n0(self.rows.length)})</option>
                ${self.sheetCounts.map(function (sheet) { return html`<option value="${sheet.name}"${Frp.attr("selected", self.sheetFilter === sheet.name)}>${sheet.label}</option>`; })}
            </select>
        </div>
        <div>
            <label class="block text-xs font-medium text-subtle" for="mappingSearch">Search</label>
            <input autocomplete="off" id="mappingSearch" class="mt-1 h-10 w-64 rounded-app border border-line bg-surface px-3 text-sm outline-none transition placeholder:text-subtle hover:border-slate-300 focus:border-accent"
                   value="${self.search}" placeholder="XSD path, cell or account code" data-input="${page.on(function (e) { self.search = e.target.value; self.currentPage = 1; page.update(); })}" />
        </div>
        <label class="inline-flex h-10 items-center gap-2 text-sm text-muted">
            <input type="checkbox" class="h-4 w-4 rounded border-line accent-[#1d4ed8]"${Frp.attr("checked", self.invalidOnly)}
                   data-change="${page.on(function (e) { self.invalidOnly = e.target.checked; self.currentPage = 1; page.update(); })}" /> Invalid only
        </label>
        ${canEdit ? html`<div class="ml-auto flex flex-wrap gap-2">
            <button class="inline-flex h-10 items-center gap-2 rounded-app px-3 text-sm font-semibold text-muted transition hover:bg-surface hover:text-ink disabled:opacity-50" ${Frp.attr("disabled", busy)}
                    title="Gives every XSD field a new unique, valid sample value that passes the BSP rules, saves it and puts it in every mapped cell"
                    data-click="${page.on(function () {
                        if (!self.dirty) {
                            return self.refill();
                        }

                        return Frp.confirm({
                            title: "Replace your unsaved changes?",
                            message: "Your unsaved changes on this tab are replaced by the new sample values, which are saved at once.",
                            confirmLabel: "Replace and fill",
                            cancelLabel: "Keep my changes"
                        }).then(function (yes) { return yes ? self.refill() : undefined; });
                    })}">
                <i class="ph ${self.refilling ? "ph-spinner animate-spin" : "ph-magic-wand"}"></i> ${self.refilling ? "Filling sample values…" : "Fill new sample values"}
            </button>
            ${self.sampleButtons(null)}
            <button class="inline-flex h-10 items-center gap-2 rounded-app px-3 text-sm font-semibold text-muted transition hover:bg-surface hover:text-ink" data-click="${page.on(function () { self.addMapping(); page.update(); })}">
                <i class="ph ph-plus"></i> Add mapping
            </button>
        </div>` : ""}
    </div>

    ${selected ? html`<p class="mt-3 max-w-prose text-xs leading-5 text-muted">
        <span class="font-mono text-ink">${selected.name}</span> is one of ${selected.count} sheet copies of
        <span class="font-mono text-ink">${selected.baseSheet}</span> (Sheet copies tab). Every copy uses these cells, so a change of a
        cell or XSD path here applies to all of them; its ${selected.keyName} cell holds <span class="font-mono text-ink">${selected.value}</span>.
        ${selected.holdsValues ? "The project's values are on this copy." : "This copy starts empty in the downloaded template; the project's values are on the " + selected.valuesCopy + " copy."}
    </p>` : ""}

    <p class="mt-3 text-xs text-subtle">
        ${!visible.length ? "0" : Frp.n0(first + 1) + "–" + Frp.n0(first + pageRows.length)} of ${Frp.n0(visible.length)}
        ${visible.length === self.rows.length ? "mappings" : "matching (" + Frp.n0(self.rows.length) + " mappings in all)"}
        ${self.invalidOnly && Object.keys(self.checkQueue).length + (self.checkTimer ? 1 : 0) > 0 ? " · still checking values" : ""}
    </p>
    <div class="mt-2 overflow-x-auto rounded-app border border-line bg-surface">
        <div class="min-w-[1230px]">
            <div class="grid grid-cols-[170px_80px_170px_minmax(320px,1fr)_190px_210px_44px] gap-2 border-b border-line px-4 py-3 text-xs font-semibold text-subtle">
                <span>Sheet</span><span>Cell</span><span title="From the Excel input template: the Account Code column on the cell's row">Account code</span><span>XSD path</span><span>Value</span><span>XSD check</span><span></span>
            </div>
            <div class="max-h-[640px] overflow-y-auto px-4"${pending ? Frp.raw(" aria-busy=\"true\"") : ""}>
                ${!visible.length ? html`<div class="py-10 text-sm">
                    <p class="font-semibold text-ink">No mappings match</p>
                    <button class="mt-1 text-accent hover:underline" data-click="${page.on(function () { self.sheetFilter = ""; self.search = ""; self.invalidOnly = false; self.currentPage = 1; page.update(); })}">Clear the filters</button>
                </div>` : ""}
                ${pageRows.map(rowMarkup)}
            </div>
        </div>
    </div>

    ${visible.length ? html`<nav class="mt-3 flex flex-col gap-3 text-sm sm:flex-row sm:items-center sm:justify-between" aria-label="Mappings pages">
        <label class="inline-flex items-center gap-2 text-muted">
            Rows per page
            <select autocomplete="off" class="h-9 rounded-app border border-line bg-surface px-2 text-sm text-ink transition hover:border-slate-300 focus:border-accent" aria-label="Rows per page"
                    data-change="${page.on(function (e) {
                        var size = Number(e.target.value);
                        if (pageSizes.indexOf(size) >= 0) {
                            // Keep the first row of the current page in view.
                            var firstRow = (self.currentPage - 1) * self.pageSize;
                            self.pageSize = size;
                            self.currentPage = Math.floor(firstRow / size) + 1;
                        }

                        page.update();
                    })}">
                ${pageSizes.map(function (size) { return html`<option value="${size}"${Frp.attr("selected", size === self.pageSize)}>${size}</option>`; })}
            </select>
        </label>
        <div class="flex flex-wrap items-center gap-1">
            <button class="${navButton}" ${Frp.attr("disabled", self.currentPage <= 1)} aria-label="First page" data-click="${page.on(function () { self.currentPage = 1; page.update(); })}"><i class="ph ph-caret-double-left"></i> First</button>
            <button class="${navButton}" ${Frp.attr("disabled", self.currentPage <= 1)} aria-label="Previous page" data-click="${page.on(function () { self.currentPage = Math.max(1, self.currentPage - 1); page.update(); })}"><i class="ph ph-caret-left"></i> Previous</button>
            <label class="mx-2 inline-flex items-center gap-2 text-muted">
                Page
                <input type="number" min="1" max="${pages}" autocomplete="off" aria-label="Page number"
                       class="h-9 w-20 rounded-app border border-line bg-surface px-2 text-center text-sm text-ink transition hover:border-slate-300 focus:border-accent"
                       value="${self.currentPage}" data-change="${page.on(function (e) { var n = parseInt(e.target.value, 10); if (!isNaN(n)) { self.currentPage = Math.max(1, n); } page.update(); })}" />
                of ${Frp.n0(pages)}
            </label>
            <button class="${navButton}" ${Frp.attr("disabled", self.currentPage >= pages)} aria-label="Next page" data-click="${page.on(function () { self.currentPage++; page.update(); })}">Next <i class="ph ph-caret-right"></i></button>
            <button class="${navButton}" ${Frp.attr("disabled", self.currentPage >= pages)} aria-label="Last page" data-click="${page.on(function () { self.currentPage = pages; page.update(); })}">Last <i class="ph ph-caret-double-right"></i></button>
        </div>
    </nav>` : ""}`}
</section>`;
    };

    // ---------- Sheet copies ----------

    var safeValue = /^[A-Za-z0-9](?:[A-Za-z0-9 ._-]*[A-Za-z0-9._-])?$/;
    var maxValueLength = 20;

    T.Copies = function (page) {
        this.page = page;
        this.settings = null;
        this.forms = [];
        this.loadError = null;
        this.loadedFor = null;
        this.busy = false;
        this.dirty = false;
        this.message = null;
        this.messageKind = "Info";
    };

    T.Copies.prototype.prepare = function () {
        var self = this;
        var project = self.page.project;
        // Loaded once per project version: a save (here or on another tab) gives a new project.
        var version = project.id + "|" + project.updatedAt;
        if (self.loadedFor === version) {
            return;
        }

        self.loadedFor = version;
        self.loadError = null;
        Frp.api.get("projects/" + project.id + "/sheet-splits").then(function (settings) {
            self.settings = settings;
            self.load();
        }, function (error) {
            self.loadError = Frp.messageOf(error);
        }).then(function () { self.page.update(); });
    };

    T.Copies.prototype.load = function () {
        var settings = this.settings;
        this.forms = settings.options.map(function (option, index) {
            var split = settings.splits.filter(function (s) { return s.groupPath === option.groupPath; })[0];
            return {
                index: index,
                option: option,
                enabled: !!split,
                keyPath: split ? split.keyPath : option.keyFields[0].path,
                values: split ? split.values.slice() : [],
                draft: "",
                error: null
            };
        });
        this.dirty = false;
    };

    function keyOf(form) {
        return form.option.keyFields.filter(function (k) { return k.path === form.keyPath; })[0] || null;
    }

    /** The same checks as the API: a code from the XSD's list (its own spelling), a safe sheet-name part, not twice. */
    T.Copies.prototype.add = function (form) {
        form.error = null;
        var key = keyOf(form);
        var value = (form.draft || "").trim();
        if (!value || !key) {
            return;
        }

        if (value.length > maxValueLength || !safeValue.test(value)) {
            form.error = "\"" + value + "\" cannot name a sheet. Use letters, digits, spaces, '.', '-' or '_' (at most " + maxValueLength + " characters).";
            return;
        }

        if (key.allowedValues.length) {
            var match = key.allowedValues.filter(function (a) { return lower(a) === lower(value); })[0];
            if (!match) {
                form.error = value + " is not an allowed " + key.name + " in the XSD.";
                return;
            }

            value = match;
        }

        if (form.values.some(function (v) { return lower(v) === lower(value); })) {
            form.error = value + " is already listed.";
            return;
        }

        if (form.values.length >= this.settings.maxValues) {
            form.error = "At most " + this.settings.maxValues + " sheet copies.";
            return;
        }

        form.values.push(value);
        form.draft = "";
        this.dirty = true;
    };

    T.Copies.prototype.save = function () {
        var self = this;
        var project = self.page.project;
        self.busy = true;
        self.message = null;
        self.page.update();
        var splits = self.forms.filter(function (f) { return f.enabled; }).map(function (f) {
            return { groupPath: f.option.groupPath, keyPath: f.keyPath, values: f.values.slice() };
        });
        return Frp.api.put("projects/" + project.id + "/sheet-splits", { splits: splits }).then(function (saved) {
            self.settings.splits = saved.sheetSplits;
            self.load();
            self.loadedFor = saved.id + "|" + saved.updatedAt;
            var sheets = splits.reduce(function (sum, s) { return sum + s.values.length; }, 0);
            Frp.toast("Success", "Sheet copies saved", !splits.length
                ? "No form is split. Download the input template again."
                : sheets + " sheet(s) for " + splits.length + " form(s). Download the input template again to get them.");
            self.page.changed(saved);
        }, function (error) {
            Frp.toast("Error", "The sheet copies were not saved", Frp.messageOf(error));
        }).then(function () {
            self.busy = false;
            self.page.update();
        });
    };

    T.Copies.prototype.render = function () {
        var self = this;
        var page = self.page;
        var project = page.project;
        var canEdit = page.canEdit();
        self.prepare();
        var settings = self.settings;
        var busy = self.busy;
        var hasErrors = self.forms.some(function (f) { return f.enabled && !f.values.length; });
        var body;
        if (self.loadError) {
            body = html`<div class="mt-6">${C.notice("Error", "The sheet copies could not be loaded", self.loadError)}</div>`;
        } else if (!settings) {
            body = C.pageLoading("Loading the sheet copies", { classes: "mt-6" });
        } else if (!settings.options.length) {
            body = html`<div class="mt-6">${C.notice("Info", "No form can be split",
                "Only a form whose repeating item is laid out on a sheet of its own (all of its fields mapped to that one sheet, on more than one row) and has a field of its own to tell the copies apart, such as Currency, can have sheet copies.")}</div>`;
        } else {
            body = html`<p class="mt-6 text-xs text-subtle">${settings.options.length} form(s) can be split · ${self.forms.filter(function (f) { return f.enabled; }).length} split</p>
        <ul class="mt-3 space-y-3">
            ${self.forms.map(function (form) {
                var key = keyOf(form);
                var keyName = key ? key.name : "value";
                var allowed = key ? key.allowedValues.filter(function (a) { return !form.values.some(function (v) { return lower(v) === lower(a); }); }) : [];
                return html`<li data-key="${form.option.groupPath}" class="rounded-app border ${form.enabled ? "border-accent-line" : "border-line"} bg-surface p-4">
                <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div class="min-w-0">
                        <p class="font-semibold text-ink">${form.option.form}</p>
                        <p class="mt-0.5 text-xs text-muted">
                            Sheet <span class="font-mono">${form.option.sheetName}</span> · ${Frp.n0(form.option.fieldCount)} fields
                            ${form.option.hasNestedLists ? html`<span> · has lists inside (read row by row)</span>` : ""}
                        </p>
                    </div>
                    <label class="inline-flex shrink-0 items-center gap-2 text-sm font-medium text-ink">
                        <input type="checkbox" class="h-4 w-4 rounded border-line accent-[#1d4ed8]"${Frp.attr("checked", form.enabled)}${Frp.attr("disabled", !canEdit || busy)}
                               data-change="${page.on(function (e) { form.enabled = e.target.checked; form.error = null; self.dirty = true; page.update(); })}" />
                        One sheet per ${keyName}
                    </label>
                </div>
                ${form.enabled ? html`<div class="mt-4 border-t border-line pt-4">
                    ${form.option.keyFields.length > 1 ? html`<label class="block text-xs font-medium text-subtle" for="${"key-" + form.index}">Field that tells the sheets apart</label>
                        <select id="${"key-" + form.index}" class="mt-1 h-10 rounded-app border border-line bg-surface px-3 text-sm focus:border-accent"${Frp.attr("disabled", !canEdit || busy)}
                                data-change="${page.on(function (e) {
                                    var path = e.target.value;
                                    if (path && path !== form.keyPath) {
                                        form.keyPath = path;
                                        form.values = []; // values of the old field do not apply to the new one
                                        form.error = null;
                                        self.dirty = true;
                                    }

                                    page.update();
                                })}">
                            ${form.option.keyFields.map(function (field) { return html`<option value="${field.path}"${Frp.attr("selected", field.path === form.keyPath)}>${field.name} (cell ${field.cellAddress})</option>`; })}
                        </select>` : ""}
                    <p class="mt-2 text-xs font-medium text-subtle">${key ? key.name : ""} values, one sheet each, in this order (${form.values.length} of at most ${settings.maxValues})</p>
                    <div class="mt-2 flex flex-wrap gap-2" role="list" aria-label="${(key ? key.name : "") + " values of " + form.option.form}">
                        ${!form.values.length ? html`<span class="text-sm text-muted">No values yet: add at least one.</span>` : ""}
                        ${form.values.map(function (value, position) {
                            return html`<span role="listitem" class="inline-flex items-center gap-1 rounded-full border border-line bg-canvas py-1 pl-3 pr-1 text-sm">
                            <span class="font-mono">${value}</span>
                            ${canEdit ? html`<button class="grid h-6 w-6 place-items-center rounded-full text-subtle transition hover:bg-surface hover:text-ink disabled:opacity-40" title="Move earlier" aria-label="${"Move " + value + " earlier"}"
                                    ${Frp.attr("disabled", position === 0 || busy)} data-click="${page.on(function () {
                                        var moved = form.values[position - 1];
                                        form.values[position - 1] = form.values[position];
                                        form.values[position] = moved;
                                        self.dirty = true;
                                        page.update();
                                    })}"><i class="ph ph-caret-left"></i></button>
                                <button class="grid h-6 w-6 place-items-center rounded-full text-subtle transition hover:bg-red-50 hover:text-red-700" title="Remove" aria-label="${"Remove " + value}"
                                    ${Frp.attr("disabled", busy)} data-click="${page.on(function () { form.values.splice(position, 1); self.dirty = true; page.update(); })}"><i class="ph ph-x"></i></button>` : ""}
                        </span>`;
                        })}
                    </div>
                    ${canEdit ? html`<div class="mt-3 flex flex-wrap items-end gap-2">
                        <div>
                            <label class="block text-xs font-medium text-subtle" for="${"add-" + form.index}">Add a ${key ? key.name : ""}</label>
                            <input id="${"add-" + form.index}" autocomplete="off" list="${"allowed-" + form.index}"
                                   class="mt-1 h-10 w-48 rounded-app border border-line bg-surface px-3 font-mono text-sm outline-none transition placeholder:font-sans placeholder:text-subtle hover:border-slate-300 focus:border-accent"
                                   placeholder="${key && key.allowedValues.length ? "e.g. " + key.allowedValues[0] : "Value"}" value="${form.draft}"${Frp.attr("disabled", busy)}
                                   data-input="${page.on(function (e) { form.draft = e.target.value; page.update(); })}"
                                   data-keydown="${page.on(function (e) { if (e.key === "Enter") { e.preventDefault(); self.add(form); page.update(); } })}" />
                            <datalist id="${"allowed-" + form.index}">
                                ${allowed.map(function (a) { return html`<option value="${a}"></option>`; })}
                            </datalist>
                        </div>
                        <button class="inline-flex h-10 items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:opacity-50"
                                ${Frp.attr("disabled", busy || !(form.draft || "").trim())} data-click="${page.on(function () { self.add(form); page.update(); })}">
                            <i class="ph ph-plus"></i> Add
                        </button>
                    </div>
                    ${form.error ? html`<p class="mt-2 text-sm text-red-700" role="alert">${form.error}</p>` : ""}` : ""}
                    ${form.values.length ? html`<p class="mt-3 text-xs text-muted">
                        Sheets: <span class="font-mono text-ink">${form.values.slice(0, 3).map(function (v) { return Frp.sheetCopyName(form.option.sheetName, v); }).join(", ")}${form.values.length > 3 ? ", … (" + form.values.length + " in all)" : ""}</span>
                    </p>` : ""}
                </div>` : ""}
            </li>`;
            })}
        </ul>
        <p class="mt-4 max-w-prose text-xs leading-5 text-subtle">
            Every sheet copy is mapped in the template's XML map. Excel maps an element only once, so the first sheet is
            mapped under the XSD's names (e.g. CAR_Part_IV_4c) and each other sheet under its own name (e.g.
            CAR_Part_IV_4c_USD). An XML from Excel's Developer &gt; Export XML therefore has those extra elements, which
            BSP's XSD does not accept: run it through "Download the merged XML" on the Validate page before it goes to BSP
            (or upload the filled template to the app). With one value per form, Excel's XML passes as it is. Download the
            input template again after a change.
        </p>`;
        }

        return html`<section aria-labelledby="copies-title">
    <div class="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
            <h2 id="copies-title" class="font-display text-xl font-bold text-ink">Sheet copies</h2>
            <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
                Some forms hold one item per currency, year or book code. Turn on one sheet per value and the input
                template gets a copy of the form's sheet for each value, named like <span class="font-mono text-ink">CAR_Part_IV_4c (USD)</span>,
                with the same layout and checks. Each copy's value cell is filled in; the app reads every copy that has
                values when it builds the XML. A copy left empty is not reported.
                ${!canEdit ? html`<span class="font-medium text-ink">${readOnlyReason(project.workflow.status, "the sheet copies")}</span>` : ""}
            </p>
        </div>
        ${canEdit && settings && settings.options.length ? html`<button class="inline-flex h-10 shrink-0 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:opacity-50"
                ${Frp.attr("disabled", busy || !self.dirty || hasErrors)} data-click="${page.on(function () { return self.save(); })}">
            <i class="ph ${busy ? "ph-spinner animate-spin" : "ph-floppy-disk"}"></i> ${busy ? "Saving…" : self.dirty ? "Save changes" : "Saved"}
        </button>` : ""}
    </div>

    ${body}
</section>`;
    };

    // ---------- Validation (the last mapping check; files are validated on the Validate page) ----------

    T.Validation = function (page) {
        this.page = page;
        this.issueList = new C.IssueList();
    };

    T.Validation.prototype.render = function () {
        var page = this.page;
        var project = page.project;
        var validation = project.validation;
        return html`<section aria-labelledby="validation-title" class="space-y-10">
    <div>
        <h2 id="validation-title" class="font-display text-xl font-bold text-ink">Validation</h2>
        <div class="mt-4 flex flex-wrap items-center gap-4 rounded-app border border-line bg-surface px-5 py-4">
            <i class="ph ph-seal-check text-2xl text-accent" aria-hidden="true"></i>
            <p class="min-w-[14rem] flex-1 text-sm leading-6 text-muted">
                Check a filled Excel template, the XML built from this project, or any XML file against this project's XSD
                and BSP specification. The Validate page works at any time, whatever the project's status.
            </p>
            <a class="inline-flex h-10 items-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover" href="${"validate?project=" + project.id}">
                <i class="ph ph-arrow-right"></i> Open Validate
            </a>
        </div>
    </div>
    <div>
        <h3 class="font-display text-lg font-bold text-ink">Last mapping check</h3>
        <p class="mt-1 max-w-prose text-sm leading-6 text-muted">From the last save or analysis: every mapped value against the XSD facets and the generated XML against the full schema.</p>
        ${validation ? html`<div class="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            ${C.metric("Result", validation.isValid ? "Valid" : validation.errorCount + " error(s)")}
            ${C.metric("Warnings", Frp.n0(validation.warningCount))}
            ${C.metric("Values checked", Frp.n0(validation.checkedValues))}
            ${C.metric("BSP rules passed / failed", validation.specificationChecked ? Frp.n0(validation.specRulesPassed) + " / " + Frp.n0(validation.specRulesFailed) : "No specification")}
        </div>
        <div class="mt-4">${this.issueList.render(page, project.issues, null)}</div>` : html`<p class="mt-4 text-sm text-subtle">Not run yet.</p>`}
    </div>
</section>`;
    };

    // ---------- Exports ----------

    T.Exports = function (page) {
        this.page = page;
        this.sampleBank = "";
        this.banks = [];
        this.coverage = null;
        this.busy = false;
        this.error = null;
        var self = this;
        Frp.api.get("reference").then(function (data) {
            self.banks = data.banks || [];
            page.update();
        }, function () {
            // Sample exports without a bank still work.
        });
    };

    T.Exports.prototype.run = function (call) {
        var self = this;
        self.busy = true;
        self.error = null;
        self.page.update();
        return call().then(function (coverage) {
            self.coverage = coverage;
        }, function (error) {
            Frp.toast("Error", "The Excel file could not be checked", Frp.messageOf(error));
        }).then(function () {
            self.busy = false;
            self.page.update();
        });
    };

    T.Exports.prototype.render = function () {
        var self = this;
        var page = self.page;
        var project = page.project;
        var bank = encodeURIComponent(self.sampleBank);
        var base = "download/" + project.id;
        return html`<div class="mb-6 rounded-app border border-line bg-surface p-5">
    <label class="block text-sm font-semibold" for="sample-bank">Bank for sample exports</label>
    <select autocomplete="off" id="sample-bank" class="mt-2 rounded-app border border-line p-2" data-change="${page.on(function (e) { self.sampleBank = e.target.value; page.update(); })}">
        <option value=""${Frp.attr("selected", !self.sampleBank)}>No bank (placeholder provider code)</option>
        ${self.banks.map(function (b) { return html`<option value="${b.key}"${Frp.attr("selected", self.sampleBank === b.key)}>${b.key} · ${b.providerCode}</option>`; })}
    </select>
    <p class="mt-2 text-sm text-muted">The sample XML uses this bank's provider code and branch codes and, when a BSP sandbox result was imported for this report, its period, prior-period figures and the fields BSP says not to report. ${Frp.can(P.ReferenceManage) ? html`<a class="font-semibold text-accent underline" href="Pages/BankProfiles.aspx">Manage bank profiles</a>` : ""}</p>
</div>
<section aria-labelledby="exports-title" class="space-y-10">
    <div>
        <h2 id="exports-title" class="font-display text-xl font-bold text-ink">Excel templates</h2>
        <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
            The blank and project-values files retain the project's XML mappings: single cells for one-off values,
            XML list tables for repeating rows. In Excel, Developer &gt; Export produces the XML to attach for review.
            ${project.templateGenerated ? html`<span>No BSP template was uploaded, so these use the template the app generated from the XSD.</span>` : ""}
        </p>
        <div class="mt-5 grid gap-3 lg:grid-cols-3">
            ${C.downloadCard(base + "/template?values=blank", "ph-file-xls", "Blank · full report mapping", "Empty input cells with the project's full export mappings. Enter the bank’s figures here.")}
            ${C.downloadCard(base + "/template?values=mapped", "ph-file-xls", "Project values · full report mapping", "Current project values in the mapped input cells, including forms omitted from the sample.")}
        </div>
    </div>
    <div>
        <h2 class="font-display text-xl font-bold text-ink">XML</h2>
        <div class="mt-5 grid gap-3 lg:grid-cols-3">
            ${C.downloadCard(base + "/sample-xml?bank=" + bank, "ph-flask", "Sample XML", "Built from the sample values. For testing only, never for BSP.")}
            ${project.workflow.status === "Approved"
                ? C.downloadCard(base + "/submission", "ph-seal-check", "Approved submission XML", "Approved by " + Frp.shortName(project.workflow.reviewedBy) + ". The file to send to BSP.", true)
                : html`<div class="rounded-app border border-dashed border-line p-5">
                <p class="flex items-center gap-2 font-semibold text-ink"><i class="ph ph-lock-simple text-subtle"></i> Submission XML</p>
                <p class="mt-2 text-sm leading-6 text-muted">Released only after a Checker approves it (segregation of duties). Attach and submit it from the workflow above.</p>
            </div>`}
        </div>
    </div>
    <div>
        <h2 class="font-display text-xl font-bold text-ink">Check a template’s XML map</h2>
        <p class="mt-1 max-w-prose text-sm leading-6 text-muted">
            Confirms every XSD field is bound in the workbook’s Excel XML map, the fields Excel’s XML Source pane shows in bold.
        </p>
        <div class="mt-5 flex flex-wrap gap-2">
            <button class="inline-flex h-10 items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent disabled:opacity-50"
                    ${Frp.attr("disabled", self.busy)} data-click="${page.on(function () { return self.run(function () { return Frp.api.get("projects/" + project.id + "/export/template/check", { values: "blank" }); }); })}">
                <i class="ph ph-list-magnifying-glass"></i> Check the blank template
            </button>
            <label class="inline-flex h-10 cursor-pointer items-center gap-2 rounded-app border border-line bg-surface px-4 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent ${self.busy ? "pointer-events-none opacity-50" : ""}">
                <i class="ph ph-upload-simple"></i> Check an Excel file
                <input type="file" class="sr-only" accept="${Frp.files.acceptFor(Frp.UploadKinds.WorkbookToCheck)}"${Frp.attr("disabled", self.busy || !Frp.files.settings())}
                       data-change="${page.on(function (e) {
                           var file = e.target.files[0];
                           e.target.value = "";
                           if (!file) {
                               return undefined;
                           }

                           var problem = Frp.files.problem(Frp.UploadKinds.WorkbookToCheck, file);
                           if (problem) {
                               Frp.toast("Error", "This file cannot be checked", problem);
                               return undefined;
                           }

                           return self.run(function () { return Frp.api.upload("projects/" + project.id + "/check-template", { templateFile: file }); });
                       })}" />
            </label>
        </div>
        ${self.coverage ? html`<div class="mt-6">${C.coverageResult(self.coverage)}</div>` : ""}
    </div>
</section>`;
    };

    // ---------- Edit project (name and files) ----------

    /**
     * Renames the project, or replaces its XSD, Excel template and/or BSP specification (or generates the template from
     * the XSD, or removes the specification). A Maker, while the project is a draft or returned. The API reads the project
     * again from its files and carries over the mappings and entered values; the result says what changed.
     */
    T.ProjectEditor = function (page) {
        var self = this;
        self.page = page;
        self.open = false;
        self.reset();
        var picker = function (kind, label, help) {
            return new C.FilePicker(page, {
                label: label, help: help, kind: kind, required: false,
                onSelected: function () {
                    if (kind === Frp.UploadKinds.Template) {
                        self.generate = false;
                    }

                    if (kind === Frp.UploadKinds.Specification) {
                        self.removeSpecification = false;
                    }

                    self.result = null;
                },
                onError: function (message) { Frp.toast("Error", "The file cannot be used", message); }
            });
        };
        self.xsd = picker(Frp.UploadKinds.Xsd, "New XSD", "A new BSP version of the report. Fields are matched by their path; fields no longer in the XSD lose their mapping.");
        self.template = picker(Frp.UploadKinds.Template, "New Excel template", "BSP's input template for this report.");
        self.specification = picker(Frp.UploadKinds.Specification, "New BSP specification", "Rules, allowed values and labels; sample values are chosen again to pass them.");
    };

    T.ProjectEditor.prototype.reset = function () {
        this.name = this.page.project ? this.page.project.name : "";
        this.generate = false;
        this.removeSpecification = false;
        this.keepCells = false;
        this.busy = false;
        this.progress = null;
        if (this.xsd) {
            this.xsd.clear();
            this.template.clear();
            this.specification.clear();
        }
    };

    T.ProjectEditor.prototype.show = function () {
        this.reset();
        this.result = null;
        this.open = true;
        this.page.update();
        window.setTimeout(function () {
            var field = document.getElementById("project-name");
            if (field) {
                field.focus();
                field.scrollIntoView({ block: "center", behavior: "smooth" });
            }
        }, 0);
    };

    T.ProjectEditor.prototype.close = function () {
        this.open = false;
        this.reset();
        this.page.update();
    };

    T.ProjectEditor.prototype.filesChosen = function () {
        return !!(this.xsd.file || this.template.file || this.specification.file || this.generate || this.removeSpecification);
    };

    T.ProjectEditor.prototype.rename = function () {
        var self = this;
        var page = self.page;
        var name = self.name.trim();
        if (!name) {
            Frp.toast("Warning", "Give the project a name", "The name cannot be empty.");
            return undefined;
        }

        self.busy = true;
        page.update();
        return Frp.api.put("projects/" + page.project.id + "/name", { name: name }, { busy: "Renaming the project" }).then(function (project) {
            self.busy = false;
            Frp.toast("Success", "Project renamed", "It is now called " + project.name + ".");
            self.name = project.name;
            return Frp.api.get("projects/" + page.project.id).then(function (fresh) { page.changed(fresh); });
        }, function (error) {
            self.busy = false;
            Frp.toast("Error", "The project was not renamed", Frp.messageOf(error));
            page.update();
        });
    };

    T.ProjectEditor.prototype.replace = function () {
        var self = this;
        var page = self.page;
        var project = page.project;
        var changes = [];
        if (self.xsd.file) {
            changes.push("the XSD with " + self.xsd.file.name);
        }

        if (self.template.file) {
            changes.push("the Excel template with " + self.template.file.name);
        } else if (self.generate) {
            changes.push("the Excel template with one generated from the XSD");
        }

        if (self.specification.file) {
            changes.push((project.specificationFile ? "the BSP specification with " : "a BSP specification: ") + self.specification.file.name);
        } else if (self.removeSpecification) {
            changes.push("no BSP specification");
        }

        var attached = !!(project.workflow && project.workflow.submission);
        return Frp.confirm({
            title: "Replace the project's files?",
            message: "Use " + changes.join(", ") + ". Your mappings and entered values are carried over; sample values are chosen again"
                + (attached ? "; the XML attached for review is removed" : "") + ". The old files stay in the history.",
            confirmLabel: "Replace files"
        }).then(function (yes) {
            if (!yes) {
                return undefined;
            }

            var form = new FormData();
            if (self.xsd.file) {
                form.append("xsdFile", self.xsd.file, self.xsd.file.name);
            }

            if (self.template.file) {
                form.append("templateFile", self.template.file, self.template.file.name);
            }

            if (self.specification.file) {
                form.append("specificationFile", self.specification.file, self.specification.file.name);
            }

            if (self.generate) {
                form.append("generateTemplate", "true");
            }

            if (self.removeSpecification) {
                form.append("removeSpecification", "true");
            }

            if (self.keepCells && self.template.file) {
                form.append("keepCells", "true");
            }

            var name = self.name.trim();
            if (name && name !== project.name) {
                form.append("projectName", name);
            }

            self.busy = true;
            self.progress = new C.Progress(page, "Reading the new files");
            page.update();
            return Frp.api.stream("POST", "projects/" + project.id + "/files", { form: form }, function (update) { self.progress.show(update); },
                function (item) { return item.edit; }, "The files were not replaced.").then(function (edit) {
                self.progress.stop();
                self.result = edit.summary;
                self.open = false;
                self.reset();
                Frp.toast("Success", "Files replaced", self.summaryLine(edit.summary));
                return Frp.api.get("projects/" + project.id).then(function (fresh) {
                    // The tabs show the new fields, sheets and mappings.
                    page.tabObjects = { details: page.tabObjects.details };
                    page.changed(fresh);
                });
            }, function (error) {
                if (self.progress) {
                    self.progress.stop();
                }

                self.progress = null;
                self.busy = false;
                Frp.toast("Error", "The files were not replaced", error.timeout ? error.message : Frp.messageOf(error));
                page.update();
            });
        });
    };

    T.ProjectEditor.prototype.summaryLine = function (summary) {
        return summary.filesReplaced.join(", ") + ": " + Frp.n0(summary.mappingsKept + summary.mappingsFromTemplate) + " mappings, "
            + Frp.n0(summary.valuesKept) + " entered value" + (summary.valuesKept === 1 ? "" : "s") + " kept"
            + (summary.mappingsDropped ? ", " + Frp.n0(summary.mappingsDropped) + " field" + (summary.mappingsDropped === 1 ? "" : "s") + " no longer mapped" : "") + ".";
    };

    /** What the last replacement changed (until the editor is opened again). */
    T.ProjectEditor.prototype.renderResult = function () {
        var self = this;
        var s = self.result;
        if (!s) {
            return "";
        }

        var on = self.page.on.bind(self.page);
        var row = function (label, value, tone) {
            return html`<div class="flex items-baseline justify-between gap-4 border-b border-line/70 py-2 last:border-0">
            <dt class="text-muted">${label}</dt><dd class="font-semibold tabular-nums ${tone || "text-ink"}">${value}</dd>
        </div>`;
        };
        return html`<section class="max-w-3xl rounded-app border border-emerald-200 bg-emerald-50/60 p-5" aria-labelledby="edit-result-title">
    <div class="flex items-start justify-between gap-4">
        <div>
            <h3 id="edit-result-title" class="flex items-center gap-2 font-semibold text-ink"><i class="ph ph-check-circle text-emerald-700" aria-hidden="true"></i> Files replaced</h3>
            <p class="mt-1 text-sm text-muted">${s.filesReplaced.join(" · ")}</p>
        </div>
        <button type="button" class="text-sm font-semibold text-muted hover:text-ink" data-click="${on(function () { self.result = null; self.page.update(); })}">Dismiss</button>
    </div>
    <dl class="mt-4 grid gap-x-8 text-sm sm:grid-cols-2">
        <div>
            ${row("Mappings kept", Frp.n0(s.mappingsKept))}
            ${row("Mappings from the new files", Frp.n0(s.mappingsFromTemplate))}
            ${row("Fields no longer mapped", Frp.n0(s.mappingsDropped), s.mappingsDropped ? "text-amber-700" : "")}
            ${row("New XSD fields", Frp.n0(s.fieldsAdded))}
        </div>
        <div>
            ${row("Entered values kept", Frp.n0(s.valuesKept))}
            ${row("Entered values dropped", Frp.n0(s.valuesDropped), s.valuesDropped ? "text-amber-700" : "")}
            ${row("Sheet copies removed", Frp.n0(s.sheetCopiesDropped), s.sheetCopiesDropped ? "text-amber-700" : "")}
            ${row("Attached XML removed", s.submissionRemoved ? "Yes" : "No", s.submissionRemoved ? "text-amber-700" : "")}
        </div>
    </dl>
    ${s.fieldsRemovedCount ? html`<details class="mt-3 text-sm">
        <summary class="cursor-pointer font-semibold text-ink hover:text-accent">${Frp.n0(s.fieldsRemovedCount)} mapped field${s.fieldsRemovedCount === 1 ? " is" : "s are"} no longer in the XSD</summary>
        <ul class="mt-2 max-h-48 space-y-1 overflow-auto font-mono text-xs text-muted">
            ${s.fieldsRemoved.map(function (path) { return html`<li class="break-all">${path}</li>`; })}
            ${s.fieldsRemovedCount > s.fieldsRemoved.length ? html`<li>… and ${Frp.n0(s.fieldsRemovedCount - s.fieldsRemoved.length)} more (see History)</li>` : ""}
        </ul>
    </details>` : ""}
    <p class="mt-3 text-xs text-subtle">Sample values were chosen again for the new files. Check the Mappings and Validation tabs before submitting.</p>
</section>`;
    };

    T.ProjectEditor.prototype.render = function () {
        var self = this;
        var page = self.page;
        var project = page.project;
        var on = page.on.bind(page);
        if (!self.open) {
            return self.renderResult();
        }

        var busy = self.busy;
        var nameChanged = self.name.trim() && self.name.trim() !== project.name;
        var current = function (label, file, extra) {
            return html`<p class="text-xs text-subtle">Now: <span class="font-medium text-ink">${file}</span>${extra ? " " + extra : ""}</p>`;
        };
        var check = function (checked, disabled, label, help, onChange) {
            return html`<label class="mt-3 flex items-start gap-3 text-sm ${disabled ? "opacity-50" : "cursor-pointer"}">
            <input type="checkbox" class="mt-0.5 h-4 w-4 rounded border-line text-accent"${Frp.attr("checked", checked)}${Frp.attr("disabled", disabled || busy)}
                   data-change="${on(function (e) { onChange(e.target.checked); self.page.update(); })}" />
            <span><span class="font-medium text-ink">${label}</span>${help ? html`<span class="block text-xs text-muted">${help}</span>` : ""}</span>
        </label>`;
        };
        return html`<section class="max-w-3xl rounded-app border border-accent-line bg-surface p-5 shadow-sm sm:p-6" aria-labelledby="edit-project-title">
    <div class="flex items-start justify-between gap-4">
        <div>
            <h2 id="edit-project-title" class="font-display text-xl font-bold text-ink">Edit project</h2>
            <p class="mt-1 max-w-prose text-sm text-muted">Rename it, or replace its files when BSP releases a new version. Your mapped fields and entered values are kept.</p>
        </div>
        <button type="button" class="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-app px-3 text-sm font-semibold text-muted transition hover:bg-canvas hover:text-ink"${Frp.attr("disabled", busy)}
                data-click="${on(function () { self.close(); })}"><i class="ph ph-x" aria-hidden="true"></i> Close</button>
    </div>

    <div class="mt-6">
        <label for="project-name" class="block text-sm font-semibold text-ink">Project name</label>
        <div class="mt-2 flex flex-col gap-2 sm:flex-row">
            <input id="project-name" autocomplete="off" maxlength="200" class="h-10 min-w-0 flex-1 rounded-app border border-line bg-surface px-3 text-sm outline-none transition hover:border-slate-300 focus:border-accent"
                   value="${self.name}"${Frp.attr("disabled", busy)}
                   data-input="${on(function (e) { self.name = e.target.value; self.page.update(); })}"
                   data-keydown="${on(function (e) { if (e.key === "Enter" && nameChanged && !self.filesChosen()) { e.preventDefault(); return self.rename(); } return undefined; })}" />
            ${!self.filesChosen() ? html`<button type="button" class="inline-flex h-10 items-center justify-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-50"
                    ${Frp.attr("disabled", busy || !nameChanged)} data-click="${on(function () { return self.rename(); })}"><i class="ph ph-pencil-simple" aria-hidden="true"></i> Rename</button>` : ""}
        </div>
        ${self.filesChosen() && nameChanged ? html`<p class="mt-1 text-xs text-muted">The new name is saved with the files.</p>` : ""}
    </div>

    <div class="mt-8 border-t border-line pt-6">
        <h3 class="font-semibold text-ink">Replace files</h3>
        <p class="mt-1 max-w-prose text-sm text-muted">Choose only the files that changed; the others stay. The project is read again from its files, as when it was created.</p>
        <div class="mt-5 space-y-6">
            <div>
                ${self.xsd.render(busy)}
                <div class="mt-1">${current("XSD", project.xsdFile ? project.xsdFile.originalName : "—", project.rootElement ? "(" + project.rootElement + ")" : "")}</div>
            </div>
            <div>
                ${self.template.render(busy || self.generate)}
                <div class="mt-1">${current("Excel template", project.templateGenerated ? "generated from the XSD" : project.templateFile ? project.templateFile.originalName : "—")}</div>
                ${!project.templateGenerated ? check(self.generate, !!self.template.file, "Generate the template from the XSD instead",
                    "For a report without a BSP template. Your entered values are kept; fields are laid out by the app.",
                    function (value) { self.generate = value; }) : ""}
                ${self.template.file ? html`<fieldset class="mt-4 rounded-app border border-line bg-canvas px-4 py-3 text-sm">
                    <legend class="px-1 text-xs font-semibold text-subtle">Mapped cells</legend>
                    <label class="flex cursor-pointer items-start gap-3 py-1">
                        <input type="radio" name="keep-cells" class="mt-0.5 h-4 w-4 border-line text-accent"${Frp.attr("checked", !self.keepCells)}${Frp.attr("disabled", busy)}
                               data-change="${on(function () { self.keepCells = false; self.page.update(); })}" />
                        <span><span class="font-medium text-ink">Use the new template's cells</span> <span class="text-xs font-semibold text-accent">Recommended</span>
                        <span class="block text-xs text-muted">BSP templates carry their own mapping; fields it does not map keep your cell when the sheet is still there.</span></span>
                    </label>
                    <label class="flex cursor-pointer items-start gap-3 py-1">
                        <input type="radio" name="keep-cells" class="mt-0.5 h-4 w-4 border-line text-accent"${Frp.attr("checked", self.keepCells)}${Frp.attr("disabled", busy)}
                               data-change="${on(function () { self.keepCells = true; self.page.update(); })}" />
                        <span><span class="font-medium text-ink">Keep my cells</span>
                        <span class="block text-xs text-muted">Where the sheet is still in the new template. Use this when only the template's look changed.</span></span>
                    </label>
                </fieldset>` : ""}
            </div>
            <div>
                ${self.specification.render(busy || self.removeSpecification)}
                <div class="mt-1">${current("BSP specification", project.specificationFile ? project.specificationFile.originalName : "none")}</div>
                ${project.specificationFile ? check(self.removeSpecification, !!self.specification.file, "Remove the specification",
                    "The BSP rules are no longer checked for this project.", function (value) { self.removeSpecification = value; }) : ""}
            </div>
        </div>
        ${self.progress ? html`<div class="mt-6">${self.progress.render()}</div>` : ""}
        <div class="mt-6 flex flex-col gap-3 border-t border-line pt-5 sm:flex-row sm:items-center sm:justify-between">
            <p class="text-xs text-subtle">${project.workflow.submission ? "The XML attached for review will be removed: it was made for the current files." : "Fields no longer in the XSD lose their mapping and value; History records every change."}</p>
            <button type="button" class="inline-flex h-10 items-center justify-center gap-2 rounded-app bg-accent px-4 text-sm font-semibold text-white transition hover:bg-accent-hover disabled:cursor-not-allowed disabled:opacity-50"
                    ${Frp.attr("disabled", busy || !self.filesChosen())} data-click="${on(function () { return self.replace(); })}">
                ${busy && self.progress ? html`<span class="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" aria-hidden="true"></span>` : html`<i class="ph ph-arrows-clockwise" aria-hidden="true"></i>`} Replace files
            </button>
        </div>
    </div>
</section>`;
    };

    // ---------- Details ----------

    function fileSize(file) {
        return !file || !file.size ? "" : "· " + Frp.size(file.size);
    }

    T.Details = function (page) {
        this.page = page;
    };

    T.Details.prototype.render = function () {
        var page = this.page;
        var project = page.project;
        var workbook = project.workbook;
        var editor = page.editor;
        return html`<section aria-labelledby="details-title" class="space-y-10">
    ${editor.open || editor.result ? editor.render() : ""}
    <div>
        <div class="flex flex-wrap items-center justify-between gap-3 max-w-3xl">
            <h2 id="details-title" class="font-display text-xl font-bold text-ink">Source files</h2>
            ${page.canEdit() && !editor.open ? html`<button type="button" class="inline-flex h-9 items-center gap-2 rounded-app border border-line bg-surface px-3 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent"
                    data-click="${page.on(function () { editor.show(); })}"><i class="ph ph-pencil-simple" aria-hidden="true"></i> Edit project</button>` : ""}
        </div>
        <dl class="mt-5 grid max-w-3xl grid-cols-[auto_minmax(0,1fr)] gap-x-8 gap-y-3 rounded-app border border-line bg-surface px-5 py-4 text-sm">
            <dt class="text-subtle">XSD</dt>
            <dd class="text-ink">${project.xsdFile ? project.xsdFile.originalName : "—"} <span class="text-subtle">${fileSize(project.xsdFile)}</span></dd>
            <dt class="text-subtle">Excel template</dt>
            <dd class="text-ink">${project.templateGenerated ? "Generated from the XSD" : project.templateFile ? project.templateFile.originalName : "—"} <span class="text-subtle">${fileSize(project.templateFile)}</span></dd>
            <dt class="text-subtle">BSP specification</dt>
            <dd class="text-ink">${project.specificationFile ? project.specificationFile.originalName : "Not uploaded"} <span class="text-subtle">${fileSize(project.specificationFile)}</span></dd>
            <dt class="text-subtle">Namespace</dt>
            <dd class="min-w-0 break-all font-mono text-xs text-muted">${project.targetNamespace}</dd>
        </dl>
    </div>
    <div class="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        ${C.metric("Report (root element)", project.rootElement)}
        ${C.metric("XSD elements", Frp.n0(project.schemaNodes.length))}
        ${C.metric("Mappings", Frp.n0(project.mappings.length))}
        ${C.metric("Workbook sheets", Frp.n0(workbook ? workbook.sheets.length : 0))}
    </div>
    ${project.sampleOmittedForms.length ? C.notice("Info", "Sample values follow the BSP specification",
        project.sampleOmittedForms.length + " form(s) are left out of the sample XML because the specification says they are not submitted for the sample’s Header values: "
        + project.sampleOmittedForms.join(", ") + ".") : ""}
    ${workbook ? html`<div>
        <h2 class="font-display text-xl font-bold text-ink">Template sheets</h2>
        <div class="mt-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            ${workbook.sheets.map(function (sheet) {
                return html`<div class="rounded-app border border-line bg-surface px-4 py-3">
                <p class="truncate text-sm font-semibold text-ink" title="${sheet.name}">${sheet.name}</p>
                <p class="text-xs text-subtle">${Frp.n0(sheet.totalStoredCellCount)} cells read</p>
            </div>`;
            })}
        </div>
        ${workbook.existingMappings.length ? html`<details class="mt-4 text-sm">
            <summary class="cursor-pointer font-semibold text-ink hover:text-accent">Existing Excel XML map bindings in the template (${Frp.n0(Math.max(workbook.existingMappingCount, workbook.existingMappings.length))})</summary>
            <div class="mt-2 max-h-80 overflow-auto rounded-app border border-line bg-surface">
                ${workbook.existingMappings.slice(0, 200).map(function (map) {
                    return html`<div class="grid gap-2 border-b border-line/70 px-4 py-2 last:border-0 md:grid-cols-[180px_minmax(0,1fr)]">
                    <span class="font-medium text-ink">${map.sheetName + "!" + map.cellAddress}</span>
                    <code class="break-all text-xs text-muted">${map.xPath}</code>
                </div>`;
                })}
            </div>
        </details>` : ""}
    </div>` : ""}
</section>`;
    };

    // ---------- History ----------

    T.History = function (page) {
        this.page = page;
        this.list = new C.PagedList(page, "projects/" + page.project.id + "/audit/page", "frp.historyPageSize");
        this.loadedVersion = -1;
    };

    T.History.prototype.render = function () {
        var self = this;
        var page = self.page;
        var list = self.list;
        var on = page.on.bind(page);
        if (self.loadedVersion !== page.historyVersion) {
            // New entries (the project changed): reload the page shown.
            self.loadedVersion = page.historyVersion;
            list.load();
        }

        var data = list.data;
        var body;
        if (!data && list.error) {
            body = html`<div class="mt-5">${C.notice("Error", "The history could not be loaded", list.error)}</div>`;
        } else if (!data) {
            body = C.pageLoading("Loading the history", { classes: "mt-5" });
        } else if (list.empty()) {
            body = html`<p class="mt-5 rounded-app border border-dashed border-line px-5 py-8 text-sm text-subtle">No history yet. Projects created before sign-in was added have no earlier entries.</p>`;
        } else {
            body = html`<div class="mt-5">${list.filters(on, "Person, address or details")}</div>
        ${list.error ? html`<div class="mt-4">${C.notice("Error", null, list.error)}</div>` : ""}
        ${list.pager(on)}
        ${data.entries.length ? html`<ol class="mt-6 max-w-4xl transition-opacity ${list.loading ? "opacity-60" : ""}"${Frp.raw(list.loading ? " aria-busy=\"true\"" : "")}>
            ${data.entries.map(function (entry) {
                return html`<li class="grid grid-cols-[20px_minmax(0,1fr)] gap-4 pb-6 last:pb-0" data-key="${entry.id}">
                <span class="mt-1.5 flex flex-col items-center">
                    <span class="h-2.5 w-2.5 rounded-full ${C.historyDot(entry.action)}"></span>
                </span>
                <div class="min-w-0">
                    <p class="text-sm"><span class="font-semibold text-ink">${entry.action}</span> <span class="text-muted">by ${entry.user}</span></p>
                    <p class="text-xs text-subtle">${Frp.date(entry.at, true, true)}${entry.address ? " · from " + entry.address : ""}</p>
                    ${entry.details ? html`<p class="mt-1 max-w-prose break-words text-sm leading-6 text-muted whitespace-pre-line">${entry.details}</p>` : ""}
                </div>
            </li>`;
            })}
        </ol>` : html`<p class="mt-5 rounded-app border border-dashed border-line px-5 py-8 text-sm text-subtle">No entries match.</p>`}
        ${data.total > data.pageSize ? list.pager(on) : ""}`;
        }

        return html`<section aria-labelledby="history-title">
    <h2 id="history-title" class="font-display text-xl font-bold text-ink">History</h2>
    <p class="mt-1 max-w-prose text-sm leading-6 text-muted">Every change, review decision and release of this project, newest first. Entries cannot be edited.</p>
    ${body}
</section>`;
    };

    // ---------- the project page ----------

    var tabs = [
        { key: "mappings", label: "Mappings", icon: "ph-table", create: T.Mappings },
        { key: "copies", label: "Sheet copies", icon: "ph-copy", create: T.Copies },
        { key: "validation", label: "Validation", icon: "ph-shield-check", create: T.Validation },
        { key: "exports", label: "Exports", icon: "ph-download-simple", create: T.Exports },
        { key: "details", label: "Details", icon: "ph-info", create: T.Details },
        { key: "history", label: "History", icon: "ph-clock-counter-clockwise", create: T.History }
    ];

    var ProjectPage = Frp.page(function (app, projectId) {
        Frp.Page.call(this, app);
        this.projectId = projectId;
        this.project = null;
        this.error = null;
        this.tab = "mappings";
        this.historyVersion = 0;
        this.workflow = new T.Workflow(this);
        this.editor = new T.ProjectEditor(this);
        this.tabObjects = {};
    }, {
        title: function () {
            return (this.project ? this.project.name : "Project") + " · FRP Mapper";
        },

        init: function () {
            var self = this;
            if (!/^[0-9a-f]{32}$/.test(self.projectId)) {
                self.error = "This is not a valid project address.";
                return Promise.resolve();
            }

            return Frp.api.get("projects/" + self.projectId).then(function (project) {
                self.project = project;
                // Reviewers start where their work is; preparers on the mappings.
                self.tab = Frp.can(P.SubmissionReview) && !Frp.can(P.ProjectEdit) ? "validation" : "mappings";
            }, function (error) {
                self.error = error.unreachable ? Frp.unreachable("") : Frp.messageOf(error);
            });
        },

        /** Only with the edit permission, and only while the project is a draft or was returned. */
        canEdit: function () {
            var project = this.project;
            return !!project && Frp.can(P.ProjectEdit) && (project.workflow.status === "Draft" || project.workflow.status === "Returned");
        },

        /** A tab or the workflow changed the project. */
        changed: function (updated) {
            this.project = updated;
            this.historyVersion++;
            this.update();
        },

        tabObject: function (key) {
            if (!this.tabObjects[key]) {
                var tab = tabs.filter(function (t) { return t.key === key; })[0];
                this.tabObjects[key] = new tab.create(this);
            }

            return this.tabObjects[key];
        },

        render: function () {
            var self = this;
            var project = self.project;
            var body;
            if (self.error) {
                body = html`<div class="mt-6">${C.notice("Error", "The project could not be opened", self.error)}</div>`;
            } else if (!project) {
                body = C.pageLoading("Loading the project", { classes: "mt-6" });
            } else {
                var workflow = project.workflow;
                var creator = workflow.createdBy ? workflow.createdBy : "(before sign-in)";
                body = html`<header class="mt-4 flex flex-col gap-3 border-b border-line pb-8">
            <div class="flex flex-wrap items-center gap-3">
                <h1 class="font-display text-3xl font-bold tracking-tight text-ink">${project.name}</h1>
                ${C.statusBadge(workflow.status)}
                ${self.canEdit() ? html`<button type="button" class="ml-auto inline-flex h-9 items-center gap-2 rounded-app border border-line bg-surface px-3 text-sm font-semibold text-ink transition hover:border-accent hover:text-accent"
                        data-click="${self.on(function () { self.tab = "details"; self.editor.show(); })}"><i class="ph ph-pencil-simple" aria-hidden="true"></i> Edit project</button>` : ""}
            </div>
            <p class="max-w-prose text-sm leading-6 text-muted">
                <span class="font-medium text-ink">${project.rootElement}</span>
                · created by ${Frp.shortName(creator)} on ${Frp.date(project.createdAt)}
                ${workflow.lastModifiedBy ? html`<span> · last change by ${Frp.shortName(workflow.lastModifiedBy)} on ${Frp.date(workflow.lastModifiedAt, true)}</span>` : ""}
            </p>
        </header>
        <div class="mt-8">${self.workflow.render()}</div>
        <nav class="mt-10 flex gap-1 overflow-x-auto border-b border-line" role="tablist" aria-label="Project sections">
            ${tabs.map(function (tab) {
                var active = self.tab === tab.key;
                return html`<button role="tab" aria-selected="${active ? "true" : "false"}"
                    class="-mb-px inline-flex shrink-0 items-center gap-2 border-b-2 px-4 py-3 text-sm font-medium transition ${active ? "border-accent text-accent" : "border-transparent text-muted hover:border-line hover:text-ink"}"
                    data-click="${self.on(function () { self.tab = tab.key; self.update(); })}">
                <i class="ph ${tab.icon}"></i> ${tab.label}
            </button>`;
            })}
        </nav>
        <div class="mt-8">${self.tabObject(self.tab).render()}</div>`;
            }

            return html`<div class="px-6 py-8 lg:px-10 lg:py-10">
    <a class="inline-flex items-center gap-1.5 text-sm font-medium text-muted transition hover:text-accent" href="">
        <i class="ph ph-arrow-left"></i> Projects
    </a>
    ${body}
</div>`;
        }
    });

    /** A new mapping's id (32 hex digits, as Guid.NewGuid().ToString("N")). */
    Frp.newId = function () {
        var bytes = new Uint8Array(16);
        window.crypto.getRandomValues(bytes);
        var text = "";
        for (var i = 0; i < bytes.length; i++) {
            text += (bytes[i] < 16 ? "0" : "") + bytes[i].toString(16);
        }

        return text;
    };

    Frp.routes.push({ pattern: /^projects\/([^/]+)$/, permission: P.ProjectRead, create: function (app, match) { return new ProjectPage(app, match[1]); } });
})();
