using System;
using System.Threading.Tasks;
using System.Web;
using FrpMapper.Platform.Hosting;

namespace FrpMapper.Platform
{
    /// <summary>
    /// Starts the Platform (settings, services), checks every ASP.NET page request before the page runs, and removes
    /// headers that name the server software.
    /// </summary>
    public class Global : HttpApplication
    {
        public override void Init()
        {
            base.Init();
            var check = new EventHandlerTaskAsyncHelper(CheckPageRequestAsync);
            AddOnPostAuthenticateRequestAsync(check.BeginEventHandler, check.EndEventHandler);
        }

        protected void Application_Start(object sender, EventArgs e)
        {
            PlatformApplication.Start();
        }

        protected void Application_PreSendRequestHeaders(object sender, EventArgs e)
        {
            // The response does not name the web server software (Application Security Checklist: server configuration).
            var response = HttpContext.Current == null ? null : HttpContext.Current.Response;
            if (response != null)
            {
                response.Headers.Remove("Server");
                response.Headers.Remove("X-AspNet-Version");
                response.Headers.Remove("X-Powered-By");
            }
        }

        /// <summary>
        /// A request for an .aspx page gets the same checks as every request of the Platform's own pipeline: only GET and
        /// POST, the security headers, https outside Development, no caching, and a signed-in person (the sign-in page
        /// otherwise). The person is left in HttpContext.Items for the page (<see cref="FrpPage"/>).
        /// </summary>
        private static async Task CheckPageRequestAsync(object sender, EventArgs e)
        {
            var application = (HttpApplication)sender;
            var context = application.Context;
            if (!string.Equals(context.Request.CurrentExecutionFilePathExtension, ".aspx", StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            var wrapper = new HttpContextWrapper(context);
            var method = context.Request.HttpMethod;
            if (method != "GET" && method != "HEAD" && method != "POST")
            {
                context.Response.StatusCode = 405;
                context.Response.AddHeader("Allow", "GET, HEAD, POST");
                application.CompleteRequest();
                return;
            }

            var settings = PlatformApplication.Settings;
            if (!PlatformPipeline.ApplySecurityHeaders(wrapper, settings))
            {
                application.CompleteRequest();
                return;
            }

            PlatformPipeline.NoStore(wrapper);
            var person = await PlatformPipeline.SignInCheckAsync(wrapper, PlatformApplication.Services, settings, Http.LocalPath(wrapper),
                context.Response.ClientDisconnectedToken);
            if (person == null)
            {
                // The sign-in page (or the reason the sign-in was refused) has been written instead.
                application.CompleteRequest();
                return;
            }

            context.Items[FrpPage.PersonKey] = person;
        }
    }
}
